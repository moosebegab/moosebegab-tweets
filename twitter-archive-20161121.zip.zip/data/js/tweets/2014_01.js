Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 50, 63 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/OszPQXzv43",
      "expanded_url" : "http:\/\/redemptionpictures.com\/2014\/01\/27\/heres-to-the-children\/",
      "display_url" : "redemptionpictures.com\/2014\/01\/27\/her\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429412037664337921",
  "text" : "Here's to the Children http:\/\/t.co\/OszPQXzv43 via @micahjmurray",
  "id" : 429412037664337921,
  "created_at" : "2014-02-01 00:33:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/429401718980235265\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/GfWqPTJnpU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfWKlp4CUAA-Mz4.jpg",
      "id_str" : "429401718984429568",
      "id" : 429401718984429568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfWKlp4CUAA-Mz4.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 736
      } ],
      "display_url" : "pic.twitter.com\/GfWqPTJnpU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429404834232799232",
  "text" : "RT @CUMALi_YILDIZ: Awesome http:\/\/t.co\/GfWqPTJnpU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/429401718980235265\/photo\/1",
        "indices" : [ 8, 30 ],
        "url" : "http:\/\/t.co\/GfWqPTJnpU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfWKlp4CUAA-Mz4.jpg",
        "id_str" : "429401718984429568",
        "id" : 429401718984429568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfWKlp4CUAA-Mz4.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 736
        } ],
        "display_url" : "pic.twitter.com\/GfWqPTJnpU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429401718980235265",
    "text" : "Awesome http:\/\/t.co\/GfWqPTJnpU",
    "id" : 429401718980235265,
    "created_at" : "2014-01-31 23:52:02 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 429404834232799232,
  "created_at" : "2014-02-01 00:04:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Keystone",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429363062702108672",
  "text" : "RT @Adenovir: Because cancer is a job creator. #Keystone",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Keystone",
        "indices" : [ 33, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429352517617856512",
    "text" : "Because cancer is a job creator. #Keystone",
    "id" : 429352517617856512,
    "created_at" : "2014-01-31 20:36:31 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 429363062702108672,
  "created_at" : "2014-01-31 21:18:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "California OneCare",
      "screen_name" : "CAOneCare",
      "indices" : [ 3, 13 ],
      "id_str" : "38363816",
      "id" : 38363816
    }, {
      "name" : "buzzflash",
      "screen_name" : "BuzzFlash",
      "indices" : [ 116, 126 ],
      "id_str" : "18634085",
      "id" : 18634085
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Md9OPSM0r7",
      "expanded_url" : "http:\/\/truth-out.org\/buzzflash\/commentary\/item\/18434-true-single-payer-healthcare-system-being-considered-in-new-york-assembly\/18434-true-single-payer-healthcare-system-being-considered-in-new-york-assembly",
      "display_url" : "truth-out.org\/buzzflash\/comm\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429361613226127360",
  "text" : "RT @CAOneCare: True Single-Payer Healthcare System Being Considered in New York Assembly http:\/\/t.co\/Md9OPSM0r7 via @buzzflash #SinglePayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "buzzflash",
        "screen_name" : "BuzzFlash",
        "indices" : [ 101, 111 ],
        "id_str" : "18634085",
        "id" : 18634085
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 112, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/Md9OPSM0r7",
        "expanded_url" : "http:\/\/truth-out.org\/buzzflash\/commentary\/item\/18434-true-single-payer-healthcare-system-being-considered-in-new-york-assembly\/18434-true-single-payer-healthcare-system-being-considered-in-new-york-assembly",
        "display_url" : "truth-out.org\/buzzflash\/comm\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429346731600277504",
    "text" : "True Single-Payer Healthcare System Being Considered in New York Assembly http:\/\/t.co\/Md9OPSM0r7 via @buzzflash #SinglePayer",
    "id" : 429346731600277504,
    "created_at" : "2014-01-31 20:13:32 +0000",
    "user" : {
      "name" : "California OneCare",
      "screen_name" : "CAOneCare",
      "protected" : false,
      "id_str" : "38363816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/201385520\/onecareO_normal.png",
      "id" : 38363816,
      "verified" : false
    }
  },
  "id" : 429361613226127360,
  "created_at" : "2014-01-31 21:12:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "California OneCare",
      "screen_name" : "CAOneCare",
      "indices" : [ 3, 13 ],
      "id_str" : "38363816",
      "id" : 38363816
    }, {
      "name" : "Kennebec Journal",
      "screen_name" : "KJ_Online",
      "indices" : [ 102, 112 ],
      "id_str" : "15345320",
      "id" : 15345320
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/VQ9RxHDL09",
      "expanded_url" : "http:\/\/www.kjonline.com\/politics\/Maine_lawmakers_to_look_into_single-payer_health_care_.html",
      "display_url" : "kjonline.com\/politics\/Maine\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "429361101739151360",
  "text" : "RT @CAOneCare: Maine lawmakers to consider single-payer health care system http:\/\/t.co\/VQ9RxHDL09 via @KJ_Online #SinglePayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kennebec Journal",
        "screen_name" : "KJ_Online",
        "indices" : [ 87, 97 ],
        "id_str" : "15345320",
        "id" : 15345320
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/VQ9RxHDL09",
        "expanded_url" : "http:\/\/www.kjonline.com\/politics\/Maine_lawmakers_to_look_into_single-payer_health_care_.html",
        "display_url" : "kjonline.com\/politics\/Maine\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "429345221965389824",
    "text" : "Maine lawmakers to consider single-payer health care system http:\/\/t.co\/VQ9RxHDL09 via @KJ_Online #SinglePayer",
    "id" : 429345221965389824,
    "created_at" : "2014-01-31 20:07:32 +0000",
    "user" : {
      "name" : "California OneCare",
      "screen_name" : "CAOneCare",
      "protected" : false,
      "id_str" : "38363816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/201385520\/onecareO_normal.png",
      "id" : 38363816,
      "verified" : false
    }
  },
  "id" : 429361101739151360,
  "created_at" : "2014-01-31 21:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/KerriFar\/status\/429359034274021376\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/O0olP2Pp61",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfVjxE-CAAA8Gbb.jpg",
      "id_str" : "429359034282409984",
      "id" : 429359034282409984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfVjxE-CAAA8Gbb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/O0olP2Pp61"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "birding",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/aHwDpP1vaC",
      "expanded_url" : "http:\/\/goo.gl\/2mlTEJ",
      "display_url" : "goo.gl\/2mlTEJ"
    } ]
  },
  "geo" : { },
  "id_str" : "429361037847314432",
  "text" : "RT @KerriFar: Young Cardinal Siblings ~ http:\/\/t.co\/aHwDpP1vaC ~ male and female ~ #birds #birding http:\/\/t.co\/O0olP2Pp61",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KerriFar\/status\/429359034274021376\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/O0olP2Pp61",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfVjxE-CAAA8Gbb.jpg",
        "id_str" : "429359034282409984",
        "id" : 429359034282409984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfVjxE-CAAA8Gbb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/O0olP2Pp61"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 69, 75 ]
      }, {
        "text" : "birding",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/aHwDpP1vaC",
        "expanded_url" : "http:\/\/goo.gl\/2mlTEJ",
        "display_url" : "goo.gl\/2mlTEJ"
      } ]
    },
    "geo" : { },
    "id_str" : "429359034274021376",
    "text" : "Young Cardinal Siblings ~ http:\/\/t.co\/aHwDpP1vaC ~ male and female ~ #birds #birding http:\/\/t.co\/O0olP2Pp61",
    "id" : 429359034274021376,
    "created_at" : "2014-01-31 21:02:25 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 429361037847314432,
  "created_at" : "2014-01-31 21:10:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pruitt",
      "screen_name" : "neoookami",
      "indices" : [ 0, 10 ],
      "id_str" : "38671125",
      "id" : 38671125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "429254539456180225",
  "geo" : { },
  "id_str" : "429258087485034498",
  "in_reply_to_user_id" : 38671125,
  "text" : "@neoookami DD got WiiU for xmas.. one cool system. the gamepad is what makes it so awesome!",
  "id" : 429258087485034498,
  "in_reply_to_status_id" : 429254539456180225,
  "created_at" : "2014-01-31 14:21:17 +0000",
  "in_reply_to_screen_name" : "neoookami",
  "in_reply_to_user_id_str" : "38671125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary (\u0E51\u2579\u25E1\u2579\u0E51)",
      "screen_name" : "SweetMarry6",
      "indices" : [ 3, 15 ],
      "id_str" : "1390438790",
      "id" : 1390438790
    }, {
      "name" : "Tammy 21st October",
      "screen_name" : "PinkChocoCandy",
      "indices" : [ 18, 33 ],
      "id_str" : "1004732078",
      "id" : 1004732078
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PinkChocoCandy\/status\/428925853896937472\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/0oybSOYhkI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPZypoCYAAdDTs.jpg",
      "id_str" : "428925853720797184",
      "id" : 428925853720797184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPZypoCYAAdDTs.jpg",
      "sizes" : [ {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0oybSOYhkI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428975925364260864",
  "text" : "RT @SweetMarry6: \u201C@PinkChocoCandy: How sweet are these birds... http:\/\/t.co\/0oybSOYhkI\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tammy 21st October",
        "screen_name" : "PinkChocoCandy",
        "indices" : [ 1, 16 ],
        "id_str" : "1004732078",
        "id" : 1004732078
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PinkChocoCandy\/status\/428925853896937472\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/0oybSOYhkI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPZypoCYAAdDTs.jpg",
        "id_str" : "428925853720797184",
        "id" : 428925853720797184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPZypoCYAAdDTs.jpg",
        "sizes" : [ {
          "h" : 219,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0oybSOYhkI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "428925853896937472",
    "geo" : { },
    "id_str" : "428968428817616896",
    "in_reply_to_user_id" : 1004732078,
    "text" : "\u201C@PinkChocoCandy: How sweet are these birds... http:\/\/t.co\/0oybSOYhkI\u201D",
    "id" : 428968428817616896,
    "in_reply_to_status_id" : 428925853896937472,
    "created_at" : "2014-01-30 19:10:17 +0000",
    "in_reply_to_screen_name" : "PinkChocoCandy",
    "in_reply_to_user_id_str" : "1004732078",
    "user" : {
      "name" : "Mary (\u0E51\u2579\u25E1\u2579\u0E51)",
      "screen_name" : "SweetMarry6",
      "protected" : false,
      "id_str" : "1390438790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3714250891\/537a2262bb820a40c23221bc9190d721_normal.jpeg",
      "id" : 1390438790,
      "verified" : false
    }
  },
  "id" : 428975925364260864,
  "created_at" : "2014-01-30 19:40:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary (\u0E51\u2579\u25E1\u2579\u0E51)",
      "screen_name" : "SweetMarry6",
      "indices" : [ 3, 15 ],
      "id_str" : "1390438790",
      "id" : 1390438790
    }, {
      "name" : "Marika Marku",
      "screen_name" : "MarikaMarku",
      "indices" : [ 18, 30 ],
      "id_str" : "1515693606",
      "id" : 1515693606
    }, {
      "name" : "Margarita",
      "screen_name" : "MCal54",
      "indices" : [ 33, 40 ],
      "id_str" : "301741887",
      "id" : 301741887
    }, {
      "name" : "Annie",
      "screen_name" : "BrinetAnnie",
      "indices" : [ 76, 88 ],
      "id_str" : "1253570628",
      "id" : 1253570628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BrinetAnnie\/status\/421731937926279168\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/GDuHjdBLhk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdpK9oWIMAEdt7b.jpg",
      "id_str" : "421731937775267841",
      "id" : 421731937775267841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdpK9oWIMAEdt7b.jpg",
      "sizes" : [ {
        "h" : 593,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 593,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GDuHjdBLhk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428975651136471040",
  "text" : "RT @SweetMarry6: \u201C@MarikaMarku: \u201C@MCal54: Awww! He could handle anything!\n\n\"@BrinetAnnie: http:\/\/t.co\/GDuHjdBLhk\"\u201D\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marika Marku",
        "screen_name" : "MarikaMarku",
        "indices" : [ 1, 13 ],
        "id_str" : "1515693606",
        "id" : 1515693606
      }, {
        "name" : "Margarita",
        "screen_name" : "MCal54",
        "indices" : [ 16, 23 ],
        "id_str" : "301741887",
        "id" : 301741887
      }, {
        "name" : "Annie",
        "screen_name" : "BrinetAnnie",
        "indices" : [ 59, 71 ],
        "id_str" : "1253570628",
        "id" : 1253570628
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BrinetAnnie\/status\/421731937926279168\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/GDuHjdBLhk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdpK9oWIMAEdt7b.jpg",
        "id_str" : "421731937775267841",
        "id" : 421731937775267841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdpK9oWIMAEdt7b.jpg",
        "sizes" : [ {
          "h" : 593,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 593,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GDuHjdBLhk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "428789868857421824",
    "geo" : { },
    "id_str" : "428970313880436736",
    "in_reply_to_user_id" : 1515693606,
    "text" : "\u201C@MarikaMarku: \u201C@MCal54: Awww! He could handle anything!\n\n\"@BrinetAnnie: http:\/\/t.co\/GDuHjdBLhk\"\u201D\u201D",
    "id" : 428970313880436736,
    "in_reply_to_status_id" : 428789868857421824,
    "created_at" : "2014-01-30 19:17:47 +0000",
    "in_reply_to_screen_name" : "MarikaMarku",
    "in_reply_to_user_id_str" : "1515693606",
    "user" : {
      "name" : "Mary (\u0E51\u2579\u25E1\u2579\u0E51)",
      "screen_name" : "SweetMarry6",
      "protected" : false,
      "id_str" : "1390438790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3714250891\/537a2262bb820a40c23221bc9190d721_normal.jpeg",
      "id" : 1390438790,
      "verified" : false
    }
  },
  "id" : 428975651136471040,
  "created_at" : "2014-01-30 19:38:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birds & Blooms",
      "screen_name" : "birdsblooms",
      "indices" : [ 3, 15 ],
      "id_str" : "28795138",
      "id" : 28795138
    }, {
      "name" : "Deborah",
      "screen_name" : "ButTwoPennies",
      "indices" : [ 39, 53 ],
      "id_str" : "152609764",
      "id" : 152609764
    }, {
      "name" : "Birds & Blooms",
      "screen_name" : "birdsblooms",
      "indices" : [ 55, 67 ],
      "id_str" : "28795138",
      "id" : 28795138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428974820366483456",
  "text" : "RT @birdsblooms: Definitely posing! RT @ButTwoPennies: @birdsblooms The mourning dove that posed on the fence for me this morning. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deborah",
        "screen_name" : "ButTwoPennies",
        "indices" : [ 22, 36 ],
        "id_str" : "152609764",
        "id" : 152609764
      }, {
        "name" : "Birds & Blooms",
        "screen_name" : "birdsblooms",
        "indices" : [ 38, 50 ],
        "id_str" : "28795138",
        "id" : 28795138
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ButTwoPennies\/status\/427536230562009088\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/VkUTAtrplg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Be7p77_CEAAqjrN.jpg",
        "id_str" : "427536230570397696",
        "id" : 427536230570397696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be7p77_CEAAqjrN.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VkUTAtrplg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427857415217106944",
    "text" : "Definitely posing! RT @ButTwoPennies: @birdsblooms The mourning dove that posed on the fence for me this morning. http:\/\/t.co\/VkUTAtrplg",
    "id" : 427857415217106944,
    "created_at" : "2014-01-27 17:35:31 +0000",
    "user" : {
      "name" : "Birds & Blooms",
      "screen_name" : "birdsblooms",
      "protected" : false,
      "id_str" : "28795138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573932224841523200\/pGrsijYv_normal.jpeg",
      "id" : 28795138,
      "verified" : false
    }
  },
  "id" : 428974820366483456,
  "created_at" : "2014-01-30 19:35:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Propane Jane\u2122",
      "screen_name" : "docrocktex26",
      "indices" : [ 3, 16 ],
      "id_str" : "16582131",
      "id" : 16582131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/g5mZENowLH",
      "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2014\/01\/30\/utah-kids-in-tears-after-school-seizes-and-tosses-out-40-lunches-over-debt\/",
      "display_url" : "rawstory.com\/rs\/2014\/01\/30\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428971040795262976",
  "text" : "RT @docrocktex26: Utah kids in tears after school seizes and tosses out 40 lunches over debt http:\/\/t.co\/g5mZENowLH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/g5mZENowLH",
        "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2014\/01\/30\/utah-kids-in-tears-after-school-seizes-and-tosses-out-40-lunches-over-debt\/",
        "display_url" : "rawstory.com\/rs\/2014\/01\/30\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428965274444771328",
    "text" : "Utah kids in tears after school seizes and tosses out 40 lunches over debt http:\/\/t.co\/g5mZENowLH",
    "id" : 428965274444771328,
    "created_at" : "2014-01-30 18:57:45 +0000",
    "user" : {
      "name" : "Propane Jane\u2122",
      "screen_name" : "docrocktex26",
      "protected" : false,
      "id_str" : "16582131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792431540143697922\/VrNOi_FD_normal.jpg",
      "id" : 16582131,
      "verified" : false
    }
  },
  "id" : 428971040795262976,
  "created_at" : "2014-01-30 19:20:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gayle duQuenoy",
      "screen_name" : "nakedwriterlady",
      "indices" : [ 3, 19 ],
      "id_str" : "2226335882",
      "id" : 2226335882
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nakedwriterlady\/status\/427794479223803907\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/SwqDhWqtkv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be_Uz_PCEAEfDBd.jpg",
      "id_str" : "427794479236386817",
      "id" : 427794479236386817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be_Uz_PCEAEfDBd.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 558
      } ],
      "display_url" : "pic.twitter.com\/SwqDhWqtkv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428962482565427200",
  "text" : "RT @nakedwriterlady: Isn't sharing a wonderful thing! http:\/\/t.co\/SwqDhWqtkv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nakedwriterlady\/status\/427794479223803907\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/SwqDhWqtkv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Be_Uz_PCEAEfDBd.jpg",
        "id_str" : "427794479236386817",
        "id" : 427794479236386817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be_Uz_PCEAEfDBd.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 558
        } ],
        "display_url" : "pic.twitter.com\/SwqDhWqtkv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427794479223803907",
    "text" : "Isn't sharing a wonderful thing! http:\/\/t.co\/SwqDhWqtkv",
    "id" : 427794479223803907,
    "created_at" : "2014-01-27 13:25:26 +0000",
    "user" : {
      "name" : "Gayle duQuenoy",
      "screen_name" : "nakedwriterlady",
      "protected" : false,
      "id_str" : "2226335882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644832221136863232\/5Alv2t9d_normal.jpg",
      "id" : 2226335882,
      "verified" : false
    }
  },
  "id" : 428962482565427200,
  "created_at" : "2014-01-30 18:46:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Protect All Animals\u24CB",
      "screen_name" : "JulieStaffysi",
      "indices" : [ 3, 17 ],
      "id_str" : "92036584",
      "id" : 92036584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428962006172172289",
  "text" : "RT @JulieStaffysi: \"@mikedowson222: Find your voice! Speak for animals! They need our help! http:\/\/t.co\/pVSDSZvRIE\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/pVSDSZvRIE",
        "expanded_url" : "https:\/\/twitter.com\/mikedowson222\/status\/416906029704560640\/photo\/1",
        "display_url" : "pic.twitter.com\/pVSDSZvRIE"
      } ]
    },
    "geo" : { },
    "id_str" : "417273422876770304",
    "text" : "\"@mikedowson222: Find your voice! Speak for animals! They need our help! http:\/\/t.co\/pVSDSZvRIE\"",
    "id" : 417273422876770304,
    "created_at" : "2013-12-29 12:38:31 +0000",
    "user" : {
      "name" : "Protect All Animals\u24CB",
      "screen_name" : "JulieStaffysi",
      "protected" : false,
      "id_str" : "92036584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785837548119724033\/GfrYxJ1a_normal.jpg",
      "id" : 92036584,
      "verified" : false
    }
  },
  "id" : 428962006172172289,
  "created_at" : "2014-01-30 18:44:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Wyland",
      "screen_name" : "kennywyland",
      "indices" : [ 3, 15 ],
      "id_str" : "17197717",
      "id" : 17197717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/FUJVdOS4ea",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=x0Tqde7OeZ8",
      "display_url" : "youtube.com\/watch?v=x0Tqde\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428960536400003072",
  "text" : "RT @kennywyland: Seriously, screw Kirk Cameron: http:\/\/t.co\/FUJVdOS4ea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/FUJVdOS4ea",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=x0Tqde7OeZ8",
        "display_url" : "youtube.com\/watch?v=x0Tqde\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428952873448124416",
    "text" : "Seriously, screw Kirk Cameron: http:\/\/t.co\/FUJVdOS4ea",
    "id" : 428952873448124416,
    "created_at" : "2014-01-30 18:08:29 +0000",
    "user" : {
      "name" : "Kenny Wyland",
      "screen_name" : "kennywyland",
      "protected" : false,
      "id_str" : "17197717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000733694211\/8e2f5afc73c47cd1aa96d51a3427a810_normal.png",
      "id" : 17197717,
      "verified" : false
    }
  },
  "id" : 428960536400003072,
  "created_at" : "2014-01-30 18:38:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "truther monkey",
      "screen_name" : "Thedyer1971",
      "indices" : [ 3, 15 ],
      "id_str" : "600061917",
      "id" : 600061917
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Thedyer1971\/status\/428928787787812864\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/MNkAJgkiRf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPcdbZIgAArC-I.jpg",
      "id_str" : "428928787657818112",
      "id" : 428928787657818112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPcdbZIgAArC-I.jpg",
      "sizes" : [ {
        "h" : 716,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MNkAJgkiRf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428957651574456320",
  "text" : "RT @Thedyer1971: What if ... http:\/\/t.co\/MNkAJgkiRf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Thedyer1971\/status\/428928787787812864\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/MNkAJgkiRf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPcdbZIgAArC-I.jpg",
        "id_str" : "428928787657818112",
        "id" : 428928787657818112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPcdbZIgAArC-I.jpg",
        "sizes" : [ {
          "h" : 716,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MNkAJgkiRf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428928787787812864",
    "text" : "What if ... http:\/\/t.co\/MNkAJgkiRf",
    "id" : 428928787787812864,
    "created_at" : "2014-01-30 16:32:46 +0000",
    "user" : {
      "name" : "truther monkey",
      "screen_name" : "Thedyer1971",
      "protected" : false,
      "id_str" : "600061917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504379669786161153\/4F-A9dQ4_normal.jpeg",
      "id" : 600061917,
      "verified" : false
    }
  },
  "id" : 428957651574456320,
  "created_at" : "2014-01-30 18:27:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426051128904531968",
  "geo" : { },
  "id_str" : "428949123253817344",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses wonderful news!",
  "id" : 428949123253817344,
  "in_reply_to_status_id" : 426051128904531968,
  "created_at" : "2014-01-30 17:53:35 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426359958691540992",
  "geo" : { },
  "id_str" : "428948767941746688",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses aww.. so content!",
  "id" : 428948767941746688,
  "in_reply_to_status_id" : 426359958691540992,
  "created_at" : "2014-01-30 17:52:10 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427285761004548096",
  "geo" : { },
  "id_str" : "428948086975504384",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses is she living with you now.. or just visiting?",
  "id" : 428948086975504384,
  "in_reply_to_status_id" : 427285761004548096,
  "created_at" : "2014-01-30 17:49:28 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427245202072297472",
  "geo" : { },
  "id_str" : "428947847614976000",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses \"atheist\" not athiest.. i'm a stickler for spelling..lol : )",
  "id" : 428947847614976000,
  "in_reply_to_status_id" : 427245202072297472,
  "created_at" : "2014-01-30 17:48:31 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "waltb31",
      "screen_name" : "waltb31",
      "indices" : [ 3, 11 ],
      "id_str" : "14820509",
      "id" : 14820509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/QJRHK7zSFw",
      "expanded_url" : "http:\/\/bit.ly\/1eiR2pt",
      "display_url" : "bit.ly\/1eiR2pt"
    } ]
  },
  "geo" : { },
  "id_str" : "428935344479035392",
  "text" : "RT @waltb31: Rand Paul: Cut Benefits To Single Moms So They'll Stop Being Sluts | Crooks and Liars http:\/\/t.co\/QJRHK7zSFw Really Kentucky? \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/QJRHK7zSFw",
        "expanded_url" : "http:\/\/bit.ly\/1eiR2pt",
        "display_url" : "bit.ly\/1eiR2pt"
      } ]
    },
    "geo" : { },
    "id_str" : "428919946341797888",
    "text" : "Rand Paul: Cut Benefits To Single Moms So They'll Stop Being Sluts | Crooks and Liars http:\/\/t.co\/QJRHK7zSFw Really Kentucky? You want Rand?",
    "id" : 428919946341797888,
    "created_at" : "2014-01-30 15:57:38 +0000",
    "user" : {
      "name" : "waltb31",
      "screen_name" : "waltb31",
      "protected" : false,
      "id_str" : "14820509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/129505712\/Walt_small_image_normal.jpeg",
      "id" : 14820509,
      "verified" : false
    }
  },
  "id" : 428935344479035392,
  "created_at" : "2014-01-30 16:58:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikey Walsh",
      "screen_name" : "thatbloodyMikey",
      "indices" : [ 3, 19 ],
      "id_str" : "125450387",
      "id" : 125450387
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thatbloodyMikey\/status\/425554566437150721\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/7vMOCuiVjd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Beffn5QIgAA3RzL.jpg",
      "id_str" : "425554566286180352",
      "id" : 425554566286180352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Beffn5QIgAA3RzL.jpg",
      "sizes" : [ {
        "h" : 973,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 973,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7vMOCuiVjd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428923222609113088",
  "text" : "RT @thatbloodyMikey: Now that's a pretty Damn Cool idea to sell books http:\/\/t.co\/7vMOCuiVjd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thatbloodyMikey\/status\/425554566437150721\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/7vMOCuiVjd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Beffn5QIgAA3RzL.jpg",
        "id_str" : "425554566286180352",
        "id" : 425554566286180352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Beffn5QIgAA3RzL.jpg",
        "sizes" : [ {
          "h" : 973,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 973,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7vMOCuiVjd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425554566437150721",
    "text" : "Now that's a pretty Damn Cool idea to sell books http:\/\/t.co\/7vMOCuiVjd",
    "id" : 425554566437150721,
    "created_at" : "2014-01-21 09:04:49 +0000",
    "user" : {
      "name" : "Mikey Walsh",
      "screen_name" : "thatbloodyMikey",
      "protected" : false,
      "id_str" : "125450387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794305207660347393\/d0R06qcf_normal.jpg",
      "id" : 125450387,
      "verified" : true
    }
  },
  "id" : 428923222609113088,
  "created_at" : "2014-01-30 16:10:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428921447877464064",
  "text" : "RT @cosmicaudino: I just put a price label change out that raised a product from $17 to $29, and at the same time a \"buy 2 get 1\" sale stic\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428919796931907584",
    "text" : "I just put a price label change out that raised a product from $17 to $29, and at the same time a \"buy 2 get 1\" sale sticker. Fucking crooks",
    "id" : 428919796931907584,
    "created_at" : "2014-01-30 15:57:03 +0000",
    "user" : {
      "name" : "\uD83D\uDC51Hillary\uD83D\uDC51",
      "screen_name" : "trustsuperjail",
      "protected" : false,
      "id_str" : "14364749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755988613427437568\/6rMS9eol_normal.jpg",
      "id" : 14364749,
      "verified" : false
    }
  },
  "id" : 428921447877464064,
  "created_at" : "2014-01-30 16:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/xgvZiVCpQx",
      "expanded_url" : "https:\/\/www.favsync.com",
      "display_url" : "favsync.com"
    } ]
  },
  "geo" : { },
  "id_str" : "428920886968586241",
  "text" : "started using this recently.. FavSync - The universal bookmarks manager https:\/\/t.co\/xgvZiVCpQx",
  "id" : 428920886968586241,
  "created_at" : "2014-01-30 16:01:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/O4wFLOnqp2",
      "expanded_url" : "http:\/\/amzn.to\/ViCObT",
      "display_url" : "amzn.to\/ViCObT"
    } ]
  },
  "geo" : { },
  "id_str" : "428735320180686850",
  "text" : "finished Six Earlier Days by David Levithan http:\/\/t.co\/O4wFLOnqp2",
  "id" : 428735320180686850,
  "created_at" : "2014-01-30 03:44:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/1cKFD0Rv63",
      "expanded_url" : "http:\/\/amzn.to\/PsU5wf",
      "display_url" : "amzn.to\/PsU5wf"
    } ]
  },
  "geo" : { },
  "id_str" : "428723631213273088",
  "text" : "finished Every Day by David Levithan http:\/\/t.co\/1cKFD0Rv63",
  "id" : 428723631213273088,
  "created_at" : "2014-01-30 02:57:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceDaily",
      "screen_name" : "ScienceDaily",
      "indices" : [ 3, 16 ],
      "id_str" : "18700629",
      "id" : 18700629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428255099606298624",
  "text" : "RT @ScienceDaily: Common crop pesticides kill honeybee larvae in the hive - Four pesticides commonly used on crops to kill insects a... htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2FHKLHErjh",
        "expanded_url" : "http:\/\/ow.ly\/2Djert",
        "display_url" : "ow.ly\/2Djert"
      } ]
    },
    "geo" : { },
    "id_str" : "427917707024281600",
    "text" : "Common crop pesticides kill honeybee larvae in the hive - Four pesticides commonly used on crops to kill insects a... http:\/\/t.co\/2FHKLHErjh",
    "id" : 427917707024281600,
    "created_at" : "2014-01-27 21:35:06 +0000",
    "user" : {
      "name" : "ScienceDaily",
      "screen_name" : "ScienceDaily",
      "protected" : false,
      "id_str" : "18700629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69944301\/apple-touch-icon_normal.png",
      "id" : 18700629,
      "verified" : false
    }
  },
  "id" : 428255099606298624,
  "created_at" : "2014-01-28 19:55:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SqueakyHollow",
      "indices" : [ 40, 54 ]
    }, {
      "text" : "WildlifeLIVE",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/qbgR64Awja",
      "expanded_url" : "http:\/\/wildlifegadgetman.com\/?page_id=98",
      "display_url" : "wildlifegadgetman.com\/?page_id=98"
    } ]
  },
  "geo" : { },
  "id_str" : "428254023607910400",
  "text" : "RT @WildlifeGadgets: Mice in and out of #SqueakyHollow too this evening. Watch the Live Cam here http:\/\/t.co\/qbgR64Awja #WildlifeLIVE http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/428251767780831232\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/wkUWCuPQfT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfF0trTCEAAz7sm.jpg",
        "id_str" : "428251767642394624",
        "id" : 428251767642394624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfF0trTCEAAz7sm.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 704
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/wkUWCuPQfT"
      } ],
      "hashtags" : [ {
        "text" : "SqueakyHollow",
        "indices" : [ 19, 33 ]
      }, {
        "text" : "WildlifeLIVE",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/qbgR64Awja",
        "expanded_url" : "http:\/\/wildlifegadgetman.com\/?page_id=98",
        "display_url" : "wildlifegadgetman.com\/?page_id=98"
      } ]
    },
    "geo" : { },
    "id_str" : "428251767780831232",
    "text" : "Mice in and out of #SqueakyHollow too this evening. Watch the Live Cam here http:\/\/t.co\/qbgR64Awja #WildlifeLIVE http:\/\/t.co\/wkUWCuPQfT",
    "id" : 428251767780831232,
    "created_at" : "2014-01-28 19:42:32 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 428254023607910400,
  "created_at" : "2014-01-28 19:51:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Seitz-Wald",
      "screen_name" : "aseitzwald",
      "indices" : [ 3, 14 ],
      "id_str" : "82167518",
      "id" : 82167518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Krvj55J7pq",
      "expanded_url" : "http:\/\/www.nationaljournal.com\/health-care\/republicans-unveil-their-obamacare-replacement-20140127",
      "display_url" : "nationaljournal.com\/health-care\/re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427977264819863552",
  "text" : "RT @aseitzwald: 3 key Republicans unveil Obamacare replacement: Pay more for health care. http:\/\/t.co\/Krvj55J7pq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/Krvj55J7pq",
        "expanded_url" : "http:\/\/www.nationaljournal.com\/health-care\/republicans-unveil-their-obamacare-replacement-20140127",
        "display_url" : "nationaljournal.com\/health-care\/re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427938001755598848",
    "text" : "3 key Republicans unveil Obamacare replacement: Pay more for health care. http:\/\/t.co\/Krvj55J7pq",
    "id" : 427938001755598848,
    "created_at" : "2014-01-27 22:55:44 +0000",
    "user" : {
      "name" : "Alex Seitz-Wald",
      "screen_name" : "aseitzwald",
      "protected" : false,
      "id_str" : "82167518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427978901881516033\/pzYpYwjl_normal.jpeg",
      "id" : 82167518,
      "verified" : true
    }
  },
  "id" : 427977264819863552,
  "created_at" : "2014-01-28 01:31:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427976502551261185",
  "text" : "RT @CoyoteSings: Maybe the problem is that we are looking for one \"fact,\" when indeed this is no one fact, but a universe of \"facts\" to be \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427971420144930817",
    "text" : "Maybe the problem is that we are looking for one \"fact,\" when indeed this is no one fact, but a universe of \"facts\" to be understood.",
    "id" : 427971420144930817,
    "created_at" : "2014-01-28 01:08:32 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 427976502551261185,
  "created_at" : "2014-01-28 01:28:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louise Botha",
      "screen_name" : "lbpaints",
      "indices" : [ 3, 12 ],
      "id_str" : "621821017",
      "id" : 621821017
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lbpaints\/status\/427089950954123264\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/haF4oscJAV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be1UDC4CcAAWPcZ.jpg",
      "id_str" : "427089950958317568",
      "id" : 427089950958317568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be1UDC4CcAAWPcZ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/haF4oscJAV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427976072484093952",
  "text" : "RT @lbpaints: Only in Canada....... http:\/\/t.co\/haF4oscJAV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lbpaints\/status\/427089950954123264\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/haF4oscJAV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Be1UDC4CcAAWPcZ.jpg",
        "id_str" : "427089950958317568",
        "id" : 427089950958317568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be1UDC4CcAAWPcZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/haF4oscJAV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427089950954123264",
    "text" : "Only in Canada....... http:\/\/t.co\/haF4oscJAV",
    "id" : 427089950954123264,
    "created_at" : "2014-01-25 14:45:54 +0000",
    "user" : {
      "name" : "Louise Botha",
      "screen_name" : "lbpaints",
      "protected" : false,
      "id_str" : "621821017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765644998218018816\/aDSsWjLK_normal.jpg",
      "id" : 621821017,
      "verified" : false
    }
  },
  "id" : 427976072484093952,
  "created_at" : "2014-01-28 01:27:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427974970300321792",
  "text" : "feeding my stray cat makes me happy.",
  "id" : 427974970300321792,
  "created_at" : "2014-01-28 01:22:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hesasaint",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427884009587105793",
  "text" : "fuck me.. i cant even vacuum without doing damage. DH should have replaced me years ago!! #hesasaint",
  "id" : 427884009587105793,
  "created_at" : "2014-01-27 19:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Voice of the Orcas",
      "screen_name" : "Voice_OT_Orcas",
      "indices" : [ 55, 70 ],
      "id_str" : "479840612",
      "id" : 479840612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/gDGOvs8NKf",
      "expanded_url" : "https:\/\/sites.google.com\/site\/voiceoftheorcas\/",
      "display_url" : "sites.google.com\/site\/voiceofth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427554590637056000",
  "text" : "end the captivity of orcas https:\/\/t.co\/gDGOvs8NKf via @Voice_OT_Orcas",
  "id" : 427554590637056000,
  "created_at" : "2014-01-26 21:32:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/z8ghfNytyr",
      "expanded_url" : "http:\/\/amzn.to\/166fUiz",
      "display_url" : "amzn.to\/166fUiz"
    } ]
  },
  "geo" : { },
  "id_str" : "427294695463862272",
  "text" : "finished Doomed by Chuck Palahniuk http:\/\/t.co\/z8ghfNytyr",
  "id" : 427294695463862272,
  "created_at" : "2014-01-26 04:19:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David A Johnson",
      "screen_name" : "infpwriter",
      "indices" : [ 3, 14 ],
      "id_str" : "507874515",
      "id" : 507874515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427270237684506624",
  "text" : "RT @infpwriter: \"If the U.S. can't afford to provide... then, what exactly is our bloated military budget defending?\" (Poster) http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/infpwriter\/status\/422911803710918656\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/qZrHRvHUPl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd58C3fCUAAv9-8.jpg",
        "id_str" : "422911803715112960",
        "id" : 422911803715112960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd58C3fCUAAv9-8.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/qZrHRvHUPl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422911803710918656",
    "text" : "\"If the U.S. can't afford to provide... then, what exactly is our bloated military budget defending?\" (Poster) http:\/\/t.co\/qZrHRvHUPl",
    "id" : 422911803710918656,
    "created_at" : "2014-01-14 02:03:26 +0000",
    "user" : {
      "name" : "David A Johnson",
      "screen_name" : "infpwriter",
      "protected" : false,
      "id_str" : "507874515",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781246136136839172\/h4VFo1GC_normal.jpg",
      "id" : 507874515,
      "verified" : false
    }
  },
  "id" : 427270237684506624,
  "created_at" : "2014-01-26 02:42:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Physics arXiv Blog",
      "screen_name" : "arxivblog",
      "indices" : [ 100, 110 ],
      "id_str" : "259771124",
      "id" : 259771124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/IWwDatdX7E",
      "expanded_url" : "https:\/\/medium.com\/the-physics-arxiv-blog\/5e7ed624986d",
      "display_url" : "medium.com\/the-physics-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427249070986362880",
  "text" : "\u201CWhy Physicists Are Saying  Consciousness Is A State Of Matter, Like a Solid, A Liquid Or A Gas\u201D by @arxivblog https:\/\/t.co\/IWwDatdX7E",
  "id" : 427249070986362880,
  "created_at" : "2014-01-26 01:18:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/n6lMmJcTLr",
      "expanded_url" : "http:\/\/msmagazine.com\/blog\/2013\/05\/24\/what-do-dress-codes-say-about-girls-bodies\/",
      "display_url" : "msmagazine.com\/blog\/2013\/05\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427201631969476608",
  "text" : "What Do Dress Codes Say About Girls\u2019 Bodies? http:\/\/t.co\/n6lMmJcTLr",
  "id" : 427201631969476608,
  "created_at" : "2014-01-25 22:09:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426859682032939008",
  "text" : "Got the cat to eat some pumpkin! (Good for constipation)",
  "id" : 426859682032939008,
  "created_at" : "2014-01-24 23:30:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "indices" : [ 0, 12 ],
      "id_str" : "27905866",
      "id" : 27905866
    }, {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 13, 26 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426852294001324032",
  "geo" : { },
  "id_str" : "426859249948708864",
  "in_reply_to_user_id" : 27905866,
  "text" : "@rev_heather @Chickypoo333 lol.. Great pic",
  "id" : 426859249948708864,
  "in_reply_to_status_id" : 426852294001324032,
  "created_at" : "2014-01-24 23:29:10 +0000",
  "in_reply_to_screen_name" : "rev_heather",
  "in_reply_to_user_id_str" : "27905866",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/426849527530663936\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/4STSitCUaY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bex5YjLCYAAlG2C.jpg",
      "id_str" : "426849527358709760",
      "id" : 426849527358709760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bex5YjLCYAAlG2C.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4STSitCUaY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426851654978519040",
  "text" : "RT @Chickypoo333: Caption this? http:\/\/t.co\/4STSitCUaY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/426849527530663936\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/4STSitCUaY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bex5YjLCYAAlG2C.jpg",
        "id_str" : "426849527358709760",
        "id" : 426849527358709760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bex5YjLCYAAlG2C.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4STSitCUaY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426849527530663936",
    "text" : "Caption this? http:\/\/t.co\/4STSitCUaY",
    "id" : 426849527530663936,
    "created_at" : "2014-01-24 22:50:32 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 426851654978519040,
  "created_at" : "2014-01-24 22:58:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426851423595528193",
  "text" : "Spent yesterday, today looking at different online bookmark managers.",
  "id" : 426851423595528193,
  "created_at" : "2014-01-24 22:58:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Coppock",
      "screen_name" : "MichelleCoppock",
      "indices" : [ 3, 19 ],
      "id_str" : "31959055",
      "id" : 31959055
    }, {
      "name" : "PM's Office of Japan",
      "screen_name" : "JPN_PMO",
      "indices" : [ 21, 29 ],
      "id_str" : "266991549",
      "id" : 266991549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweet4taiji",
      "indices" : [ 80, 92 ]
    }, {
      "text" : "opkillingbay",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "shuttaijidown",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426489043191209985",
  "text" : "RT @MichelleCoppock: @JPN_PMO Because enough blood has been needlessly spilled. #tweet4taiji #opkillingbay #shuttaijidown https:\/\/t.co\/yxfS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PM's Office of Japan",
        "screen_name" : "JPN_PMO",
        "indices" : [ 0, 8 ],
        "id_str" : "266991549",
        "id" : 266991549
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tweet4taiji",
        "indices" : [ 59, 71 ]
      }, {
        "text" : "opkillingbay",
        "indices" : [ 72, 85 ]
      }, {
        "text" : "shuttaijidown",
        "indices" : [ 86, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/yxfSqeI5Oi",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=9uPiCXWbsjE",
        "display_url" : "youtube.com\/watch?v=9uPiCX\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426477851735375872",
    "in_reply_to_user_id" : 266991549,
    "text" : "@JPN_PMO Because enough blood has been needlessly spilled. #tweet4taiji #opkillingbay #shuttaijidown https:\/\/t.co\/yxfSqeI5Oi",
    "id" : 426477851735375872,
    "created_at" : "2014-01-23 22:13:38 +0000",
    "in_reply_to_screen_name" : "JPN_PMO",
    "in_reply_to_user_id_str" : "266991549",
    "user" : {
      "name" : "Michelle Coppock",
      "screen_name" : "MichelleCoppock",
      "protected" : false,
      "id_str" : "31959055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757811196573523968\/E1MpffS5_normal.jpg",
      "id" : 31959055,
      "verified" : false
    }
  },
  "id" : 426489043191209985,
  "created_at" : "2014-01-23 22:58:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "petpeeve",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426154109876445184",
  "text" : "i do not like it when books use the movie covers #petpeeve",
  "id" : 426154109876445184,
  "created_at" : "2014-01-23 00:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/c4x0q9GMlF",
      "expanded_url" : "http:\/\/shar.es\/UeJTa",
      "display_url" : "shar.es\/UeJTa"
    } ]
  },
  "geo" : { },
  "id_str" : "426107029346742272",
  "text" : "ugh.. makes me sick &gt;&gt; Parenting Via Kirk Cameron: Kids Don\u2019t Need No Explanations http:\/\/t.co\/c4x0q9GMlF",
  "id" : 426107029346742272,
  "created_at" : "2014-01-22 21:40:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Happy Nature Garden",
      "screen_name" : "brynature",
      "indices" : [ 3, 13 ],
      "id_str" : "815131460",
      "id" : 815131460
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/brynature\/status\/424526017533714432\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/kAMpcrNwu2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeQ4Kd7CQAAz_if.jpg",
      "id_str" : "424526017361756160",
      "id" : 424526017361756160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeQ4Kd7CQAAz_if.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kAMpcrNwu2"
    } ],
    "hashtags" : [ {
      "text" : "robin",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425791985870712832",
  "text" : "RT @brynature: Met a lovely Robin on my river walk today .  #robin http:\/\/t.co\/kAMpcrNwu2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brynature\/status\/424526017533714432\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/kAMpcrNwu2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeQ4Kd7CQAAz_if.jpg",
        "id_str" : "424526017361756160",
        "id" : 424526017361756160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeQ4Kd7CQAAz_if.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kAMpcrNwu2"
      } ],
      "hashtags" : [ {
        "text" : "robin",
        "indices" : [ 45, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424526017533714432",
    "text" : "Met a lovely Robin on my river walk today .  #robin http:\/\/t.co\/kAMpcrNwu2",
    "id" : 424526017533714432,
    "created_at" : "2014-01-18 12:57:44 +0000",
    "user" : {
      "name" : "Happy Nature Garden",
      "screen_name" : "brynature",
      "protected" : false,
      "id_str" : "815131460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3307500193\/bdb5dcec0410b3f385322ca4b81ed863_normal.jpeg",
      "id" : 815131460,
      "verified" : false
    }
  },
  "id" : 425791985870712832,
  "created_at" : "2014-01-22 00:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "indices" : [ 3, 17 ],
      "id_str" : "74529629",
      "id" : 74529629
    }, {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 67, 73 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "physics",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/f7guITBTT3",
      "expanded_url" : "http:\/\/www.scientificamerican.com\/article\/study-bolsters-quantum-vibration-scent-theory\/",
      "display_url" : "scientificamerican.com\/article\/study-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425298313311948800",
  "text" : "RT @NewMindMirror: Study Bolsters Quantum Vibration Scent Theory - @SciAm  http:\/\/t.co\/f7guITBTT3 #science #physics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scientific American",
        "screen_name" : "sciam",
        "indices" : [ 48, 54 ],
        "id_str" : "14647570",
        "id" : 14647570
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 79, 87 ]
      }, {
        "text" : "physics",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/f7guITBTT3",
        "expanded_url" : "http:\/\/www.scientificamerican.com\/article\/study-bolsters-quantum-vibration-scent-theory\/",
        "display_url" : "scientificamerican.com\/article\/study-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425292727090028544",
    "text" : "Study Bolsters Quantum Vibration Scent Theory - @SciAm  http:\/\/t.co\/f7guITBTT3 #science #physics",
    "id" : 425292727090028544,
    "created_at" : "2014-01-20 15:44:22 +0000",
    "user" : {
      "name" : "Edward Craig",
      "screen_name" : "NewMindMirror",
      "protected" : false,
      "id_str" : "74529629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797462993403396097\/nYOdMPXe_normal.jpg",
      "id" : 74529629,
      "verified" : false
    }
  },
  "id" : 425298313311948800,
  "created_at" : "2014-01-20 16:06:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2021",
      "screen_name" : "salwahafiz",
      "indices" : [ 45, 56 ],
      "id_str" : "26468789",
      "id" : 26468789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425294578342580226",
  "geo" : { },
  "id_str" : "425296970006417408",
  "in_reply_to_user_id" : 26468789,
  "text" : "love is the only law &lt;3 RT @Lluminous_ RT @salwahafiz love is the law.",
  "id" : 425296970006417408,
  "in_reply_to_status_id" : 425294578342580226,
  "created_at" : "2014-01-20 16:01:13 +0000",
  "in_reply_to_screen_name" : "salwahafiz",
  "in_reply_to_user_id_str" : "26468789",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iPxH0fJ2xs",
      "expanded_url" : "http:\/\/buff.ly\/1dopeLq",
      "display_url" : "buff.ly\/1dopeLq"
    } ]
  },
  "geo" : { },
  "id_str" : "425296255661916160",
  "text" : "RT @rachelheldevans: \"The Bible was \u2018clear\u2019\u2026\" - But we've definitely got it all figured out this time...right? http:\/\/t.co\/iPxH0fJ2xs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/iPxH0fJ2xs",
        "expanded_url" : "http:\/\/buff.ly\/1dopeLq",
        "display_url" : "buff.ly\/1dopeLq"
      } ]
    },
    "geo" : { },
    "id_str" : "425295207991881728",
    "text" : "\"The Bible was \u2018clear\u2019\u2026\" - But we've definitely got it all figured out this time...right? http:\/\/t.co\/iPxH0fJ2xs",
    "id" : 425295207991881728,
    "created_at" : "2014-01-20 15:54:13 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 425296255661916160,
  "created_at" : "2014-01-20 15:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/X5TFU5m4r7",
      "expanded_url" : "http:\/\/tinyurl.com\/9h3k42u",
      "display_url" : "tinyurl.com\/9h3k42u"
    } ]
  },
  "geo" : { },
  "id_str" : "425295572346888192",
  "text" : "RT @Soulseedzforall: Every obnoxious act is a cry for help. Its rarely a personal attack. http:\/\/t.co\/X5TFU5m4r7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/X5TFU5m4r7",
        "expanded_url" : "http:\/\/tinyurl.com\/9h3k42u",
        "display_url" : "tinyurl.com\/9h3k42u"
      } ]
    },
    "geo" : { },
    "id_str" : "425295219450339328",
    "text" : "Every obnoxious act is a cry for help. Its rarely a personal attack. http:\/\/t.co\/X5TFU5m4r7",
    "id" : 425295219450339328,
    "created_at" : "2014-01-20 15:54:16 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 425295572346888192,
  "created_at" : "2014-01-20 15:55:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "425279434799976449",
  "geo" : { },
  "id_str" : "425290554537025536",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis Beautiful!",
  "id" : 425290554537025536,
  "in_reply_to_status_id" : 425279434799976449,
  "created_at" : "2014-01-20 15:35:44 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/eawaUTGIY2",
      "expanded_url" : "http:\/\/crystalstmarielewis.com\/2014\/01\/19\/where-is-god-audio-of-the-sermon-i-preached-today\/",
      "display_url" : "crystalstmarielewis.com\/2014\/01\/19\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "425289839420792832",
  "text" : "RT @CrystalLewis: ICYMI, here is my sermon audio, recorded yesterday. Topic was \"Where Is God?\" http:\/\/t.co\/eawaUTGIY2 #progressivechristia\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "progressivechristianity",
        "indices" : [ 101, 125 ]
      }, {
        "text" : "theology",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/eawaUTGIY2",
        "expanded_url" : "http:\/\/crystalstmarielewis.com\/2014\/01\/19\/where-is-god-audio-of-the-sermon-i-preached-today\/",
        "display_url" : "crystalstmarielewis.com\/2014\/01\/19\/whe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "425279434799976449",
    "text" : "ICYMI, here is my sermon audio, recorded yesterday. Topic was \"Where Is God?\" http:\/\/t.co\/eawaUTGIY2 #progressivechristianity #theology",
    "id" : 425279434799976449,
    "created_at" : "2014-01-20 14:51:33 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 425289839420792832,
  "created_at" : "2014-01-20 15:32:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "424956129974943744",
  "geo" : { },
  "id_str" : "424969536681824256",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 easy read. Enjoyed it. Loved the characters.",
  "id" : 424969536681824256,
  "in_reply_to_status_id" : 424956129974943744,
  "created_at" : "2014-01-19 18:20:07 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/rgQxuzIbpt",
      "expanded_url" : "http:\/\/amzn.to\/16uoJTp",
      "display_url" : "amzn.to\/16uoJTp"
    } ]
  },
  "geo" : { },
  "id_str" : "424954852431904768",
  "text" : "finished Somebody Up There Hates You: A Novel by Hollis Seamon http:\/\/t.co\/rgQxuzIbpt",
  "id" : 424954852431904768,
  "created_at" : "2014-01-19 17:21:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ze5iEvDBV3",
      "expanded_url" : "http:\/\/amzn.to\/oAT3Tg",
      "display_url" : "amzn.to\/oAT3Tg"
    } ]
  },
  "geo" : { },
  "id_str" : "424295667998396416",
  "text" : "finished Damned by Chuck Palahniuk http:\/\/t.co\/ze5iEvDBV3",
  "id" : 424295667998396416,
  "created_at" : "2014-01-17 21:42:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424180841162743808",
  "text" : "DH saved a sweet chickadee from feeder this am. hop hop hop flap flap flap...",
  "id" : 424180841162743808,
  "created_at" : "2014-01-17 14:06:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VisitScotland",
      "screen_name" : "VisitScotland",
      "indices" : [ 3, 17 ],
      "id_str" : "16557472",
      "id" : 16557472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423635236023721984",
  "text" : "RT @VisitScotland: Wow! MT @TobyMaloy: Northern Lights,Dunnet Head, Scotland, 2 Jan with @danny_ashton1 #NorthernLights #AuroraBorealis htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Danny Ashton",
        "screen_name" : "danny_ashton1",
        "indices" : [ 70, 84 ],
        "id_str" : "1702338306",
        "id" : 1702338306
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NorthernLights",
        "indices" : [ 85, 100 ]
      }, {
        "text" : "AuroraBorealis",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/OBBmnf3xjA",
        "expanded_url" : "https:\/\/twitter.com\/TobyMaloy\/status\/422507492372152320\/photo\/1",
        "display_url" : "pic.twitter.com\/OBBmnf3xjA"
      } ]
    },
    "geo" : { },
    "id_str" : "423025052334833664",
    "text" : "Wow! MT @TobyMaloy: Northern Lights,Dunnet Head, Scotland, 2 Jan with @danny_ashton1 #NorthernLights #AuroraBorealis http:\/\/t.co\/OBBmnf3xjA",
    "id" : 423025052334833664,
    "created_at" : "2014-01-14 09:33:26 +0000",
    "user" : {
      "name" : "VisitScotland",
      "screen_name" : "VisitScotland",
      "protected" : false,
      "id_str" : "16557472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793752584100188161\/cPit4jb5_normal.jpg",
      "id" : 16557472,
      "verified" : true
    }
  },
  "id" : 423635236023721984,
  "created_at" : "2014-01-16 01:58:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423630187310632962",
  "text" : "RT @AnAmericanMonk: Do not ask the world to change. Change yourself. Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423627049660866560",
    "text" : "Do not ask the world to change. Change yourself. Buddha",
    "id" : 423627049660866560,
    "created_at" : "2014-01-16 01:25:33 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 423630187310632962,
  "created_at" : "2014-01-16 01:38:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salvatore Terranova",
      "screen_name" : "SaTerPo",
      "indices" : [ 3, 11 ],
      "id_str" : "442127587",
      "id" : 442127587
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SaTerPo\/status\/372787861655142400\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/TsZNOg4M8P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSxolbxIEAEij35.jpg",
      "id_str" : "372787861483163649",
      "id" : 372787861483163649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSxolbxIEAEij35.jpg",
      "sizes" : [ {
        "h" : 599,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/TsZNOg4M8P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423619988499750912",
  "text" : "RT @SaTerPo: Evening quiet. http:\/\/t.co\/TsZNOg4M8P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SaTerPo\/status\/372787861655142400\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/TsZNOg4M8P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSxolbxIEAEij35.jpg",
        "id_str" : "372787861483163649",
        "id" : 372787861483163649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSxolbxIEAEij35.jpg",
        "sizes" : [ {
          "h" : 599,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/TsZNOg4M8P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372787861655142400",
    "text" : "Evening quiet. http:\/\/t.co\/TsZNOg4M8P",
    "id" : 372787861655142400,
    "created_at" : "2013-08-28 18:28:46 +0000",
    "user" : {
      "name" : "Salvatore Terranova",
      "screen_name" : "SaTerPo",
      "protected" : false,
      "id_str" : "442127587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512214041801261056\/D7e-2xK5_normal.jpeg",
      "id" : 442127587,
      "verified" : false
    }
  },
  "id" : 423619988499750912,
  "created_at" : "2014-01-16 00:57:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "indices" : [ 3, 16 ],
      "id_str" : "33427866",
      "id" : 33427866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/423618954234318848\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/1UwhZDIVXU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeD_McACYAET5hu.jpg",
      "id_str" : "423618954112688129",
      "id" : 423618954112688129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeD_McACYAET5hu.jpg",
      "sizes" : [ {
        "h" : 471,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 471,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1UwhZDIVXU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423619474655576064",
  "text" : "RT @Chickypoo333: Gorgeous Sunrise at Niagara Falls http:\/\/t.co\/1UwhZDIVXU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/423618954234318848\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/1UwhZDIVXU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeD_McACYAET5hu.jpg",
        "id_str" : "423618954112688129",
        "id" : 423618954112688129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeD_McACYAET5hu.jpg",
        "sizes" : [ {
          "h" : 471,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 471,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1UwhZDIVXU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423618954234318848",
    "text" : "Gorgeous Sunrise at Niagara Falls http:\/\/t.co\/1UwhZDIVXU",
    "id" : 423618954234318848,
    "created_at" : "2014-01-16 00:53:23 +0000",
    "user" : {
      "name" : "AJ",
      "screen_name" : "Chickypoo333",
      "protected" : false,
      "id_str" : "33427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578069282497527808\/nX8eneF6_normal.jpeg",
      "id" : 33427866,
      "verified" : false
    }
  },
  "id" : 423619474655576064,
  "created_at" : "2014-01-16 00:55:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423619330274652160",
  "text" : "makes me think it is that way w some ppl. no civility.. acting from instinct. they need kindness. to be shown over and over.",
  "id" : 423619330274652160,
  "created_at" : "2014-01-16 00:54:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423618285507063810",
  "text" : "stray cat hisses at me as i put out the food. no civility..lol. living as a feral cat is all he's known.",
  "id" : 423618285507063810,
  "created_at" : "2014-01-16 00:50:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F. Mualla Lovgren",
      "screen_name" : "MuallaLovgren",
      "indices" : [ 3, 17 ],
      "id_str" : "2245447826",
      "id" : 2245447826
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MuallaLovgren\/status\/422445455239155712\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/VJxhccX5et",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdzT50FCEAAYSZB.jpg",
      "id_str" : "422445455251738624",
      "id" : 422445455251738624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdzT50FCEAAYSZB.jpg",
      "sizes" : [ {
        "h" : 261,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/VJxhccX5et"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423609773922463744",
  "text" : "RT @MuallaLovgren: There is no psychiatrist in the world like a puppy licking your face. Bernard Williams http:\/\/t.co\/VJxhccX5et",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MuallaLovgren\/status\/422445455239155712\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/VJxhccX5et",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdzT50FCEAAYSZB.jpg",
        "id_str" : "422445455251738624",
        "id" : 422445455251738624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdzT50FCEAAYSZB.jpg",
        "sizes" : [ {
          "h" : 261,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/VJxhccX5et"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422445455239155712",
    "text" : "There is no psychiatrist in the world like a puppy licking your face. Bernard Williams http:\/\/t.co\/VJxhccX5et",
    "id" : 422445455239155712,
    "created_at" : "2014-01-12 19:10:19 +0000",
    "user" : {
      "name" : "F. Mualla Lovgren",
      "screen_name" : "MuallaLovgren",
      "protected" : false,
      "id_str" : "2245447826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579446708993699840\/naX_B-33_normal.png",
      "id" : 2245447826,
      "verified" : false
    }
  },
  "id" : 423609773922463744,
  "created_at" : "2014-01-16 00:16:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NORML",
      "screen_name" : "NORML",
      "indices" : [ 3, 9 ],
      "id_str" : "16668573",
      "id" : 16668573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423609369142755328",
  "text" : "RT @NORML: HISTORIC: New Hampshire General Assembly first full chamber in any state to approve marijuana legalization. http:\/\/t.co\/MUhZG1oj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/MUhZG1ojhS",
        "expanded_url" : "http:\/\/blog.norml.org\/2014\/01\/15\/after-lengthy-floor-debate-new-hampshire-general-assembly-approves-marijuana-legalization\/",
        "display_url" : "blog.norml.org\/2014\/01\/15\/aft\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423585758197202944",
    "text" : "HISTORIC: New Hampshire General Assembly first full chamber in any state to approve marijuana legalization. http:\/\/t.co\/MUhZG1ojhS",
    "id" : 423585758197202944,
    "created_at" : "2014-01-15 22:41:29 +0000",
    "user" : {
      "name" : "NORML",
      "screen_name" : "NORML",
      "protected" : false,
      "id_str" : "16668573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658666517995778048\/C4-qlh8T_normal.jpg",
      "id" : 16668573,
      "verified" : true
    }
  },
  "id" : 423609369142755328,
  "created_at" : "2014-01-16 00:15:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/mj6p3VftMp",
      "expanded_url" : "http:\/\/amzn.to\/ejEnPu",
      "display_url" : "amzn.to\/ejEnPu"
    } ]
  },
  "geo" : { },
  "id_str" : "422942789597667328",
  "text" : "finished The Pact by Jodi Picoult http:\/\/t.co\/mj6p3VftMp",
  "id" : 422942789597667328,
  "created_at" : "2014-01-14 04:06:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle MacEwan",
      "screen_name" : "michellemacewan",
      "indices" : [ 0, 16 ],
      "id_str" : "234946434",
      "id" : 234946434
    }, {
      "name" : "Adelheid",
      "screen_name" : "Adelheid16",
      "indices" : [ 17, 28 ],
      "id_str" : "481536894",
      "id" : 481536894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421900927038025728",
  "geo" : { },
  "id_str" : "422905071572373504",
  "in_reply_to_user_id" : 234946434,
  "text" : "@michellemacewan @Adelheid16 sweet",
  "id" : 422905071572373504,
  "in_reply_to_status_id" : 421900927038025728,
  "created_at" : "2014-01-14 01:36:40 +0000",
  "in_reply_to_screen_name" : "michellemacewan",
  "in_reply_to_user_id_str" : "234946434",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle MacEwan",
      "screen_name" : "michellemacewan",
      "indices" : [ 3, 19 ],
      "id_str" : "234946434",
      "id" : 234946434
    }, {
      "name" : "Adelheid",
      "screen_name" : "Adelheid16",
      "indices" : [ 21, 32 ],
      "id_str" : "481536894",
      "id" : 481536894
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/michellemacewan\/status\/421900927038025728\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/L7I033DPI4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdrkqF6CIAAtyiG.jpg",
      "id_str" : "421900926903787520",
      "id" : 421900926903787520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdrkqF6CIAAtyiG.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1147,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/L7I033DPI4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422905006841675777",
  "text" : "RT @michellemacewan: @Adelheid16 Kissed by a wattle bird - saved after a hawk raided from nest. http:\/\/t.co\/L7I033DPI4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adelheid",
        "screen_name" : "Adelheid16",
        "indices" : [ 0, 11 ],
        "id_str" : "481536894",
        "id" : 481536894
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/michellemacewan\/status\/421900927038025728\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/L7I033DPI4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdrkqF6CIAAtyiG.jpg",
        "id_str" : "421900926903787520",
        "id" : 421900926903787520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdrkqF6CIAAtyiG.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1147,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/L7I033DPI4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421900927038025728",
    "in_reply_to_user_id" : 481536894,
    "text" : "@Adelheid16 Kissed by a wattle bird - saved after a hawk raided from nest. http:\/\/t.co\/L7I033DPI4",
    "id" : 421900927038025728,
    "created_at" : "2014-01-11 07:06:34 +0000",
    "in_reply_to_screen_name" : "Adelheid16",
    "in_reply_to_user_id_str" : "481536894",
    "user" : {
      "name" : "Michelle MacEwan",
      "screen_name" : "michellemacewan",
      "protected" : false,
      "id_str" : "234946434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461027483681181696\/dUH7umqm_normal.jpeg",
      "id" : 234946434,
      "verified" : false
    }
  },
  "id" : 422905006841675777,
  "created_at" : "2014-01-14 01:36:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather",
      "screen_name" : "Angelflght13",
      "indices" : [ 3, 16 ],
      "id_str" : "31354175",
      "id" : 31354175
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Angelflght13\/status\/422865488083812352\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Olt8xipku6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd5R67kCcAAP0Zw.jpg",
      "id_str" : "422865487882514432",
      "id" : 422865487882514432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd5R67kCcAAP0Zw.jpg",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 882
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 882
      } ],
      "display_url" : "pic.twitter.com\/Olt8xipku6"
    } ],
    "hashtags" : [ {
      "text" : "Logic",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422874453610352640",
  "text" : "RT @Angelflght13: #Logic http:\/\/t.co\/Olt8xipku6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Angelflght13\/status\/422865488083812352\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/Olt8xipku6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd5R67kCcAAP0Zw.jpg",
        "id_str" : "422865487882514432",
        "id" : 422865487882514432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd5R67kCcAAP0Zw.jpg",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 653,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 882
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 882
        } ],
        "display_url" : "pic.twitter.com\/Olt8xipku6"
      } ],
      "hashtags" : [ {
        "text" : "Logic",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422865488083812352",
    "text" : "#Logic http:\/\/t.co\/Olt8xipku6",
    "id" : 422865488083812352,
    "created_at" : "2014-01-13 22:59:23 +0000",
    "user" : {
      "name" : "Heather",
      "screen_name" : "Angelflght13",
      "protected" : false,
      "id_str" : "31354175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000652323207\/bc12a5dd385c6e434e47c3250f180420_normal.jpeg",
      "id" : 31354175,
      "verified" : false
    }
  },
  "id" : 422874453610352640,
  "created_at" : "2014-01-13 23:35:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "indices" : [ 3, 15 ],
      "id_str" : "18256901",
      "id" : 18256901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/1uvfKpWlrG",
      "expanded_url" : "http:\/\/www.theatlantic.com\/business\/archive\/2014\/01\/it-is-expensive-to-be-poor\/282979\/",
      "display_url" : "theatlantic.com\/business\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422870221486321665",
  "text" : "RT @deonnakelli: It Is Expensive to Be Poor - Barbara Ehrenreich - The Atlantic http:\/\/t.co\/1uvfKpWlrG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/1uvfKpWlrG",
        "expanded_url" : "http:\/\/www.theatlantic.com\/business\/archive\/2014\/01\/it-is-expensive-to-be-poor\/282979\/",
        "display_url" : "theatlantic.com\/business\/archi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "422863460628582400",
    "text" : "It Is Expensive to Be Poor - Barbara Ehrenreich - The Atlantic http:\/\/t.co\/1uvfKpWlrG",
    "id" : 422863460628582400,
    "created_at" : "2014-01-13 22:51:20 +0000",
    "user" : {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "protected" : false,
      "id_str" : "18256901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796046774813200384\/-eoNtOic_normal.jpg",
      "id" : 18256901,
      "verified" : false
    }
  },
  "id" : 422870221486321665,
  "created_at" : "2014-01-13 23:18:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422831943395209217",
  "text" : "changing weather affects my sinuses. tis why i keep advil congestion on hand. bleh.",
  "id" : 422831943395209217,
  "created_at" : "2014-01-13 20:46:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "indices" : [ 38, 53 ],
      "id_str" : "20998647",
      "id" : 20998647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stormDIRECTV",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/nwaUuH2anG",
      "expanded_url" : "http:\/\/bit.ly\/1jpO8OM",
      "display_url" : "bit.ly\/1jpO8OM"
    } ]
  },
  "geo" : { },
  "id_str" : "422792448692088833",
  "text" : "I just spoke against DIRECTV dropping @weatherchannel. Join the fight: #stormDIRECTV http:\/\/t.co\/nwaUuH2anG",
  "id" : 422792448692088833,
  "created_at" : "2014-01-13 18:09:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bible Lied",
      "screen_name" : "antibible_t",
      "indices" : [ 0, 12 ],
      "id_str" : "825718357",
      "id" : 825718357
    }, {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 13, 23 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422524366614577152",
  "geo" : { },
  "id_str" : "422525914837430273",
  "in_reply_to_user_id" : 825718357,
  "text" : "@antibible_t @ZachsMind why does he have an alien head, I wonder...",
  "id" : 422525914837430273,
  "in_reply_to_status_id" : 422524366614577152,
  "created_at" : "2014-01-13 00:30:02 +0000",
  "in_reply_to_screen_name" : "antibible_t",
  "in_reply_to_user_id_str" : "825718357",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 3, 12 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/422495744658927617\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/sPc6mKgeeX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd0BpCxCcAAQb3N.jpg",
      "id_str" : "422495744671510528",
      "id" : 422495744671510528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd0BpCxCcAAQb3N.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 1008
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 1008
      } ],
      "display_url" : "pic.twitter.com\/sPc6mKgeeX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422501391748587520",
  "text" : "RT @BobTarte: I was very fortunate to get a photo of the extremely rare Leaf Sparrow. http:\/\/t.co\/sPc6mKgeeX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/422495744658927617\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/sPc6mKgeeX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd0BpCxCcAAQb3N.jpg",
        "id_str" : "422495744671510528",
        "id" : 422495744671510528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd0BpCxCcAAQb3N.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/sPc6mKgeeX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422495744658927617",
    "text" : "I was very fortunate to get a photo of the extremely rare Leaf Sparrow. http:\/\/t.co\/sPc6mKgeeX",
    "id" : 422495744658927617,
    "created_at" : "2014-01-12 22:30:09 +0000",
    "user" : {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "protected" : false,
      "id_str" : "490591746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570578729\/6y9pn9ap800am8pkqsku_normal.jpeg",
      "id" : 490591746,
      "verified" : false
    }
  },
  "id" : 422501391748587520,
  "created_at" : "2014-01-12 22:52:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 0, 9 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422495744658927617",
  "geo" : { },
  "id_str" : "422501362367492096",
  "in_reply_to_user_id" : 490591746,
  "text" : "@BobTarte ahh.. Very cool and very lucky!",
  "id" : 422501362367492096,
  "in_reply_to_status_id" : 422495744658927617,
  "created_at" : "2014-01-12 22:52:29 +0000",
  "in_reply_to_screen_name" : "BobTarte",
  "in_reply_to_user_id_str" : "490591746",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422441027392122882",
  "geo" : { },
  "id_str" : "422454747921002496",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind birthdays are like holidays, don't like 'em.. 48 in march. But my body thinks its much older o-O",
  "id" : 422454747921002496,
  "in_reply_to_status_id" : 422441027392122882,
  "created_at" : "2014-01-12 19:47:15 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422435876212195328",
  "geo" : { },
  "id_str" : "422441261174640641",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater awwwwwwwww!!!",
  "id" : 422441261174640641,
  "in_reply_to_status_id" : 422435876212195328,
  "created_at" : "2014-01-12 18:53:39 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422436526736166912",
  "geo" : { },
  "id_str" : "422440855543480320",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind omg.. I'm older than you! Lol",
  "id" : 422440855543480320,
  "in_reply_to_status_id" : 422436526736166912,
  "created_at" : "2014-01-12 18:52:03 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 29, 38 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422076471637995520",
  "text" : "RT @Squirrely007: so cute RT @BuzzFeed Little Girl\u2019s Reaction To Seeing Her Father\u2019s Twin Brother For The First Time Is Priceless http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 11, 20 ],
        "id_str" : "5695632",
        "id" : 5695632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/DcVXLj6mso",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/adamdavis\/this-little-girls-reaction-to-seeing-her-fathers-twin-brothe",
        "display_url" : "buzzfeed.com\/adamdavis\/this\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "422072640962973696",
    "geo" : { },
    "id_str" : "422073592746999808",
    "in_reply_to_user_id" : 5695632,
    "text" : "so cute RT @BuzzFeed Little Girl\u2019s Reaction To Seeing Her Father\u2019s Twin Brother For The First Time Is Priceless http:\/\/t.co\/DcVXLj6mso \u2026",
    "id" : 422073592746999808,
    "in_reply_to_status_id" : 422072640962973696,
    "created_at" : "2014-01-11 18:32:40 +0000",
    "in_reply_to_screen_name" : "BuzzFeed",
    "in_reply_to_user_id_str" : "5695632",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 422076471637995520,
  "created_at" : "2014-01-11 18:44:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422061734741164033",
  "text" : "I really despise those anti smoking commercials w the ppl wheezing. How about anti meth commercials??",
  "id" : 422061734741164033,
  "created_at" : "2014-01-11 17:45:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "indices" : [ 0, 12 ],
      "id_str" : "409492415",
      "id" : 409492415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422054232934465536",
  "geo" : { },
  "id_str" : "422057946982662144",
  "in_reply_to_user_id" : 409492415,
  "text" : "@Coyotetooth awww.. He's beautiful!",
  "id" : 422057946982662144,
  "in_reply_to_status_id" : 422054232934465536,
  "created_at" : "2014-01-11 17:30:30 +0000",
  "in_reply_to_screen_name" : "Coyotetooth",
  "in_reply_to_user_id_str" : "409492415",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422057403912581120",
  "text" : "RT @TheGodLight: The mind is a window into the unseen, if you look beyond your present understanding, you will see the unbridled truth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422056240613969921",
    "text" : "The mind is a window into the unseen, if you look beyond your present understanding, you will see the unbridled truth.",
    "id" : 422056240613969921,
    "created_at" : "2014-01-11 17:23:43 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 422057403912581120,
  "created_at" : "2014-01-11 17:28:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422055374162644993",
  "geo" : { },
  "id_str" : "422056850478358528",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time I raged a lot when I was younger. It scared me. I had trouble differentiating neg emotions.",
  "id" : 422056850478358528,
  "in_reply_to_status_id" : 422055374162644993,
  "created_at" : "2014-01-11 17:26:09 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422055463942115328",
  "text" : "..which means more work after death.. Ugh.",
  "id" : 422055463942115328,
  "created_at" : "2014-01-11 17:20:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "afterlife",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422055229220466688",
  "text" : "I don't believe in a literal Hell.. But I know there is #afterlife .. sometimes I get concerned I haven't done my job here..",
  "id" : 422055229220466688,
  "created_at" : "2014-01-11 17:19:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "introvert",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422043380290297856",
  "geo" : { },
  "id_str" : "422054480663023616",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ((hugs)) I've always been somewhat stoic and mostly like being alone. #introvert",
  "id" : 422054480663023616,
  "in_reply_to_status_id" : 422043380290297856,
  "created_at" : "2014-01-11 17:16:44 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422041310422245376",
  "text" : "i am lacking in emotion. i barely cried when my parents passed.",
  "id" : 422041310422245376,
  "created_at" : "2014-01-11 16:24:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicexistentialcrisis",
      "indices" : [ 95, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422040452871639040",
  "text" : "sometimes I think I haven't changed at all. how can I judge anyone when I may be no different? #chronicexistentialcrisis",
  "id" : 422040452871639040,
  "created_at" : "2014-01-11 16:20:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/XCQHHDzw84",
      "expanded_url" : "http:\/\/amzn.to\/1evlr1n",
      "display_url" : "amzn.to\/1evlr1n"
    } ]
  },
  "geo" : { },
  "id_str" : "421469032253239296",
  "text" : "finished The Rooms of Heaven (Vintage) by Mary Allen http:\/\/t.co\/XCQHHDzw84",
  "id" : 421469032253239296,
  "created_at" : "2014-01-10 02:30:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/epam.com\" rel=\"nofollow\"\u003ERead&Post\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.7728626, -73.6869284 ]
  },
  "id_str" : "421304987575418880",
  "text" : "trying out different twitter clients on my nexus ..",
  "id" : 421304987575418880,
  "created_at" : "2014-01-09 15:38:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/epam.com\" rel=\"nofollow\"\u003ERead&Post\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 0, 16 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421303190295158784",
  "geo" : { },
  "id_str" : "421304075209428992",
  "in_reply_to_user_id" : 727056229,
  "text" : "@CatskillCritter beautiful Hannah Bean! smooch!",
  "id" : 421304075209428992,
  "in_reply_to_status_id" : 421303190295158784,
  "created_at" : "2014-01-09 15:34:53 +0000",
  "in_reply_to_screen_name" : "CatskillCritter",
  "in_reply_to_user_id_str" : "727056229",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421291321618231296",
  "text" : "i lovelovelove using google keep with mic on my nexus 7.2 &lt;3 #android",
  "id" : 421291321618231296,
  "created_at" : "2014-01-09 14:44:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421289477659557888",
  "text" : "kari getting ear surgery today. i think DH needs a valium...",
  "id" : 421289477659557888,
  "created_at" : "2014-01-09 14:36:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421090020314075136",
  "geo" : { },
  "id_str" : "421095195460263936",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone hubby has been searching online.. EBay, amazon, etc. Will have to search using \"universal\"",
  "id" : 421095195460263936,
  "in_reply_to_status_id" : 421090020314075136,
  "created_at" : "2014-01-09 01:44:52 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421088735048916992",
  "text" : "and all these NEW razors have pivot heads. i cannot find a razor w a non-pivoting head.. argh!",
  "id" : 421088735048916992,
  "created_at" : "2014-01-09 01:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421088461219573760",
  "text" : "i don't want a NEW razor! im very happy w my Personal Touch razor but you cant find refills! : (",
  "id" : 421088461219573760,
  "created_at" : "2014-01-09 01:18:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/420924742544027648\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/BIn6eZkVQM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdds0rMCAAAsbXx.jpg",
      "id_str" : "420924742384615424",
      "id" : 420924742384615424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdds0rMCAAAsbXx.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BIn6eZkVQM"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "myyard",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420925276324134912",
  "text" : "RT @rm123077: Mr. And Mrs. House Finch sittin' in a tree... #birds #myyard http:\/\/t.co\/BIn6eZkVQM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/420924742544027648\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/BIn6eZkVQM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdds0rMCAAAsbXx.jpg",
        "id_str" : "420924742384615424",
        "id" : 420924742384615424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdds0rMCAAAsbXx.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BIn6eZkVQM"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 46, 52 ]
      }, {
        "text" : "myyard",
        "indices" : [ 53, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420924742544027648",
    "text" : "Mr. And Mrs. House Finch sittin' in a tree... #birds #myyard http:\/\/t.co\/BIn6eZkVQM",
    "id" : 420924742544027648,
    "created_at" : "2014-01-08 14:27:33 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 420925276324134912,
  "created_at" : "2014-01-08 14:29:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radical Something",
      "screen_name" : "SkepticismFirst",
      "indices" : [ 31, 47 ],
      "id_str" : "1118046115",
      "id" : 1118046115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420727472502878208",
  "text" : "@weakSquare exactly! @ElijiahT @SkepticismFirst",
  "id" : 420727472502878208,
  "created_at" : "2014-01-08 01:23:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419194922873659392",
  "text" : "Big crows in yard today getting some dog kibble. This am they were diving heads in snow for seed. So funny!",
  "id" : 419194922873659392,
  "created_at" : "2014-01-03 19:53:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419194232944222208",
  "text" : "RT @SangyeH: Many birds die of dehydration in winter storms. Put out a bowl of water for them. A tiny bit of sugar in it keeps it from free\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hercules",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419193553848242176",
    "text" : "Many birds die of dehydration in winter storms. Put out a bowl of water for them. A tiny bit of sugar in it keeps it from freezing\n#Hercules",
    "id" : 419193553848242176,
    "created_at" : "2014-01-03 19:48:26 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 419194232944222208,
  "created_at" : "2014-01-03 19:51:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419193553848242176",
  "geo" : { },
  "id_str" : "419194207036010496",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH sugar keeps from freezing? I didn't know that! Cool.. I put fresh water out daily for birds and asst critters.",
  "id" : 419194207036010496,
  "in_reply_to_status_id" : 419193553848242176,
  "created_at" : "2014-01-03 19:51:01 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419112103744925696",
  "geo" : { },
  "id_str" : "419113524959649792",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny WTF?",
  "id" : 419113524959649792,
  "in_reply_to_status_id" : 419112103744925696,
  "created_at" : "2014-01-03 14:30:25 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ActorBuster",
      "screen_name" : "ActorBuster",
      "indices" : [ 3, 15 ],
      "id_str" : "2588026416",
      "id" : 2588026416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418527948187402241",
  "text" : "RT @ActorBuster: Dear People Who Dive In Frozen Lakes For Fun: WHAT THE FUCK??!?!?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418526346709463041",
    "text" : "Dear People Who Dive In Frozen Lakes For Fun: WHAT THE FUCK??!?!?",
    "id" : 418526346709463041,
    "created_at" : "2014-01-01 23:37:11 +0000",
    "user" : {
      "name" : "We R Gonna Fix This",
      "screen_name" : "wtb6chiny",
      "protected" : false,
      "id_str" : "204947822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787487931212718080\/lpOT5NLK_normal.jpg",
      "id" : 204947822,
      "verified" : false
    }
  },
  "id" : 418527948187402241,
  "created_at" : "2014-01-01 23:43:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418493728215805952",
  "geo" : { },
  "id_str" : "418495636909330432",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 she's already much more comfy now. Its DD's cat. Good thing DD stayed home, didn't hear other ppl sobbing.. Oy!",
  "id" : 418495636909330432,
  "in_reply_to_status_id" : 418493728215805952,
  "created_at" : "2014-01-01 21:35:09 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wildlife",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418484274397208576",
  "text" : "RT @rm123077: Favorite animal sighting in 2013 was a mama moose and her calf that we saw near Grand Lake, Colorado #wildlife http:\/\/t.co\/x2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/418481914551357440\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/x2rfkbri2f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc6_FXoCYAAfCo0.jpg",
        "id_str" : "418481914354229248",
        "id" : 418481914354229248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc6_FXoCYAAfCo0.jpg",
        "sizes" : [ {
          "h" : 694,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/x2rfkbri2f"
      } ],
      "hashtags" : [ {
        "text" : "wildlife",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418481914551357440",
    "text" : "Favorite animal sighting in 2013 was a mama moose and her calf that we saw near Grand Lake, Colorado #wildlife http:\/\/t.co\/x2rfkbri2f",
    "id" : 418481914551357440,
    "created_at" : "2014-01-01 20:40:38 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 418484274397208576,
  "created_at" : "2014-01-01 20:50:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418484000232312832",
  "text" : "While waiting at vet.. Call came in about dog eaten gum w xylitol. $1000 est for treatment. Very toxic!",
  "id" : 418484000232312832,
  "created_at" : "2014-01-01 20:48:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418471738398486528",
  "geo" : { },
  "id_str" : "418472649254535168",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone thanks.. Will have to give it a try. Vet mentioned canned pumpkin daily. Freeze it in drops.",
  "id" : 418472649254535168,
  "in_reply_to_status_id" : 418471738398486528,
  "created_at" : "2014-01-01 20:03:49 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetlanes.com\" rel=\"nofollow\"\u003ETweet Lanes\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrangerGirl2",
      "screen_name" : "StrangerGirl2",
      "indices" : [ 0, 14 ],
      "id_str" : "24798779",
      "id" : 24798779
    }, {
      "name" : "Homunculus aka #Hom",
      "screen_name" : "HomunculusLoikm",
      "indices" : [ 20, 36 ],
      "id_str" : "233933230",
      "id" : 233933230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "418430564509556737",
  "geo" : { },
  "id_str" : "418466903511035904",
  "in_reply_to_user_id" : 24798779,
  "text" : "@StrangerGirl2 none @HomunculusLoikm",
  "id" : 418466903511035904,
  "in_reply_to_status_id" : 418430564509556737,
  "created_at" : "2014-01-01 19:40:59 +0000",
  "in_reply_to_screen_name" : "StrangerGirl2",
  "in_reply_to_user_id_str" : "24798779",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418451712479727616",
  "text" : "BUT while there.. someone lost their baby.. small dog or a cat. they left w empty carrier. : (",
  "id" : 418451712479727616,
  "created_at" : "2014-01-01 18:40:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418451414533173248",
  "text" : "cat to emergency vet this am due to lingering constipation. she just needed a little assistance. she'll be fine. feels much better now.",
  "id" : 418451414533173248,
  "created_at" : "2014-01-01 18:39:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]