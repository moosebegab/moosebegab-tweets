Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472794092179845120",
  "text" : "Dear Universe, please help my attitude. I'm really struggling here. Thank you.",
  "id" : 472794092179845120,
  "created_at" : "2014-05-31 17:37:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awayfromhome",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472536862100570112",
  "text" : "I miss my DH terribly : (( #awayfromhome",
  "id" : 472536862100570112,
  "created_at" : "2014-05-31 00:35:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "472001133905711104",
  "geo" : { },
  "id_str" : "472110923147005952",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre huh.. thx for pointing out. that is interesting. we love comparing at bible study the diff. versions.",
  "id" : 472110923147005952,
  "in_reply_to_status_id" : 472001133905711104,
  "created_at" : "2014-05-29 20:23:10 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471998313529479169",
  "text" : "RT @ChristianDems: 1 Cor 13:13 And now abide faith, hope, love, these three; but the greatest of these is love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471985008841097216",
    "text" : "1 Cor 13:13 And now abide faith, hope, love, these three; but the greatest of these is love.",
    "id" : 471985008841097216,
    "created_at" : "2014-05-29 12:02:49 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 471998313529479169,
  "created_at" : "2014-05-29 12:55:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GWWMike",
      "screen_name" : "CWWMIKE",
      "indices" : [ 3, 11 ],
      "id_str" : "272366187",
      "id" : 272366187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/URCPKOkufZ",
      "expanded_url" : "http:\/\/cheshirewildlifewatcher.blogspot.co.uk\/2014\/05\/wednesday-swan-rescue-and-sweet-reunion.html",
      "display_url" : "cheshirewildlifewatcher.blogspot.co.uk\/2014\/05\/wednes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471691229508689920",
  "text" : "RT @CWWMIKE: Swan rescue and a sweet reunion :-) http:\/\/t.co\/URCPKOkufZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/URCPKOkufZ",
        "expanded_url" : "http:\/\/cheshirewildlifewatcher.blogspot.co.uk\/2014\/05\/wednesday-swan-rescue-and-sweet-reunion.html",
        "display_url" : "cheshirewildlifewatcher.blogspot.co.uk\/2014\/05\/wednes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "471660794099535873",
    "text" : "Swan rescue and a sweet reunion :-) http:\/\/t.co\/URCPKOkufZ",
    "id" : 471660794099535873,
    "created_at" : "2014-05-28 14:34:31 +0000",
    "user" : {
      "name" : "GWWMike",
      "screen_name" : "CWWMIKE",
      "protected" : false,
      "id_str" : "272366187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763825085849407489\/Gq_TO6mz_normal.jpg",
      "id" : 272366187,
      "verified" : false
    }
  },
  "id" : 471691229508689920,
  "created_at" : "2014-05-28 16:35:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen J. Graham",
      "screen_name" : "sjggraham",
      "indices" : [ 3, 13 ],
      "id_str" : "1568067380",
      "id" : 1568067380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471662145961492480",
  "text" : "RT @sjggraham: God, Hell &amp; Philosophical Zombies, reflections on an argument by Justin Schieber @Justinsweh : http:\/\/t.co\/Pnz3k7VuKj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Pnz3k7VuKj",
        "expanded_url" : "http:\/\/stephenjgraham.wordpress.com\/2014\/05\/28\/god-hell-philosophical-zombies\/",
        "display_url" : "stephenjgraham.wordpress.com\/2014\/05\/28\/god\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "471556029474680832",
    "text" : "God, Hell &amp; Philosophical Zombies, reflections on an argument by Justin Schieber @Justinsweh : http:\/\/t.co\/Pnz3k7VuKj",
    "id" : 471556029474680832,
    "created_at" : "2014-05-28 07:38:13 +0000",
    "user" : {
      "name" : "Stephen J. Graham",
      "screen_name" : "sjggraham",
      "protected" : false,
      "id_str" : "1568067380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631891491468779521\/1W_Ch-ZW_normal.jpg",
      "id" : 1568067380,
      "verified" : false
    }
  },
  "id" : 471662145961492480,
  "created_at" : "2014-05-28 14:39:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471646388997332992",
  "text" : "Anger is dangerous.",
  "id" : 471646388997332992,
  "created_at" : "2014-05-28 13:37:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 0, 11 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471295036500746240",
  "geo" : { },
  "id_str" : "471331918110146560",
  "in_reply_to_user_id" : 93747129,
  "text" : "@moosebegab both were found and are safe!",
  "id" : 471331918110146560,
  "in_reply_to_status_id" : 471295036500746240,
  "created_at" : "2014-05-27 16:47:40 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 3, 17 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/sTL78lDUlV",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=daTI43ppEdQ",
      "display_url" : "youtube.com\/watch?v=daTI43\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471305171058716673",
  "text" : "RT @allthewayleft: The church of Scientology owns a ship, the Freewinds, is used for forced labor\nhttps:\/\/t.co\/sTL78lDUlV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/sTL78lDUlV",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=daTI43ppEdQ",
        "display_url" : "youtube.com\/watch?v=daTI43\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "471302833195585536",
    "text" : "The church of Scientology owns a ship, the Freewinds, is used for forced labor\nhttps:\/\/t.co\/sTL78lDUlV",
    "id" : 471302833195585536,
    "created_at" : "2014-05-27 14:52:06 +0000",
    "user" : {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "protected" : false,
      "id_str" : "345207173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000852111499\/8d917b25d9062fc1d0af08d0f98ccd71_normal.jpeg",
      "id" : 345207173,
      "verified" : false
    }
  },
  "id" : 471305171058716673,
  "created_at" : "2014-05-27 15:01:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/zk5eG1wgeR",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=10152128871406519&set=a.46190061518.60439.519621518&type=1",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "471295036500746240",
  "text" : "missing from Chittenango NY (central NY) young mom and 6yr old dau. https:\/\/t.co\/zk5eG1wgeR",
  "id" : 471295036500746240,
  "created_at" : "2014-05-27 14:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470958215237484544",
  "text" : "mental illness is not rational.",
  "id" : 470958215237484544,
  "created_at" : "2014-05-26 16:02:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Misener",
      "screen_name" : "jessmisener",
      "indices" : [ 67, 79 ],
      "id_str" : "56501671",
      "id" : 56501671
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 80, 89 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/c9XlzIGboG",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/jessicamisener\/why-i-miss-being-a-born-again-christian",
      "display_url" : "buzzfeed.com\/jessicamisener\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "470706807476727808",
  "text" : "Why I Miss Being A Born-Again Christian http:\/\/t.co\/c9XlzIGboG via @jessmisener @buzzfeed",
  "id" : 470706807476727808,
  "created_at" : "2014-05-25 23:23:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470641916141240320",
  "text" : "RT @petersonguides: Moose eat a lot of aquatic plants. Their nose has muscles and fatty pads that close the nostrils when underwater. #natu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "naturefacts",
        "indices" : [ 114, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470641721303236611",
    "text" : "Moose eat a lot of aquatic plants. Their nose has muscles and fatty pads that close the nostrils when underwater. #naturefacts",
    "id" : 470641721303236611,
    "created_at" : "2014-05-25 19:05:05 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 470641916141240320,
  "created_at" : "2014-05-25 19:05:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winter_Thur",
      "screen_name" : "winterthur",
      "indices" : [ 3, 14 ],
      "id_str" : "16474992",
      "id" : 16474992
    }, {
      "name" : "Nelson",
      "screen_name" : "Yardarm756DD",
      "indices" : [ 19, 32 ],
      "id_str" : "351114695",
      "id" : 351114695
    }, {
      "name" : "Reince Priebus",
      "screen_name" : "Reince",
      "indices" : [ 34, 41 ],
      "id_str" : "20733972",
      "id" : 20733972
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Yardarm756DD\/status\/428975841783992320\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/WT1lBRMRyL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfQHQVsCUAEWN8D.jpg",
      "id_str" : "428975841788186625",
      "id" : 428975841788186625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfQHQVsCUAEWN8D.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/WT1lBRMRyL"
    } ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "ACA",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "WOW",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "fem2",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470607162910461952",
  "text" : "RT @winterthur: RT @Yardarm756DD: @Reince I guess this dude didn't get the memo, huh? http:\/\/t.co\/WT1lBRMRyL | #GOP #ACA #WOW #fem2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nelson",
        "screen_name" : "Yardarm756DD",
        "indices" : [ 3, 16 ],
        "id_str" : "351114695",
        "id" : 351114695
      }, {
        "name" : "Reince Priebus",
        "screen_name" : "Reince",
        "indices" : [ 18, 25 ],
        "id_str" : "20733972",
        "id" : 20733972
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Yardarm756DD\/status\/428975841783992320\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/WT1lBRMRyL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfQHQVsCUAEWN8D.jpg",
        "id_str" : "428975841788186625",
        "id" : 428975841788186625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfQHQVsCUAEWN8D.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/WT1lBRMRyL"
      } ],
      "hashtags" : [ {
        "text" : "GOP",
        "indices" : [ 95, 99 ]
      }, {
        "text" : "ACA",
        "indices" : [ 100, 104 ]
      }, {
        "text" : "WOW",
        "indices" : [ 105, 109 ]
      }, {
        "text" : "fem2",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470604633376047105",
    "text" : "RT @Yardarm756DD: @Reince I guess this dude didn't get the memo, huh? http:\/\/t.co\/WT1lBRMRyL | #GOP #ACA #WOW #fem2",
    "id" : 470604633376047105,
    "created_at" : "2014-05-25 16:37:42 +0000",
    "user" : {
      "name" : "Winter_Thur",
      "screen_name" : "winterthur",
      "protected" : false,
      "id_str" : "16474992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410644074\/d0d8e32989fe0a360a90025d4307fac8_normal.jpeg",
      "id" : 16474992,
      "verified" : false
    }
  },
  "id" : 470607162910461952,
  "created_at" : "2014-05-25 16:47:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 45, 60 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470601152224980992",
  "geo" : { },
  "id_str" : "470602853480804354",
  "in_reply_to_user_id" : 105049016,
  "text" : "many times... always thinking, adjusting. RT @richarddoetsch Do you ever question your own beliefs... ?",
  "id" : 470602853480804354,
  "in_reply_to_status_id" : 470601152224980992,
  "created_at" : "2014-05-25 16:30:38 +0000",
  "in_reply_to_screen_name" : "richarddoetsch",
  "in_reply_to_user_id_str" : "105049016",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470582903089664001",
  "text" : "nothing will change until we realize we are all connected. everything is connected.. everything.",
  "id" : 470582903089664001,
  "created_at" : "2014-05-25 15:11:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/470543262902935553\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/wtWCKL0ejr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Boe0mroIAAAQ1VD.jpg",
      "id_str" : "470543262722555904",
      "id" : 470543262722555904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Boe0mroIAAAQ1VD.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/wtWCKL0ejr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470582445020942336",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/wtWCKL0ejr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/470543262902935553\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/wtWCKL0ejr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Boe0mroIAAAQ1VD.jpg",
        "id_str" : "470543262722555904",
        "id" : 470543262722555904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Boe0mroIAAAQ1VD.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/wtWCKL0ejr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470543262902935553",
    "text" : "http:\/\/t.co\/wtWCKL0ejr",
    "id" : 470543262902935553,
    "created_at" : "2014-05-25 12:33:50 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 470582445020942336,
  "created_at" : "2014-05-25 15:09:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 122, 125 ]
    }, {
      "text" : "tcot",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470582322912178176",
  "text" : "RT @MWM4444: If the free market works so perfectly, why do Big Oil, Big Ag, &amp; Big Pharma need such big tax subsidies? #p2 #tcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 109, 112 ]
      }, {
        "text" : "tcot",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470580212699508738",
    "text" : "If the free market works so perfectly, why do Big Oil, Big Ag, &amp; Big Pharma need such big tax subsidies? #p2 #tcot",
    "id" : 470580212699508738,
    "created_at" : "2014-05-25 15:00:40 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 470582322912178176,
  "created_at" : "2014-05-25 15:09:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 0, 12 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470580579524956160",
  "geo" : { },
  "id_str" : "470582162157096960",
  "in_reply_to_user_id" : 28461779,
  "text" : "@MartinBelan awww..",
  "id" : 470582162157096960,
  "in_reply_to_status_id" : 470580579524956160,
  "created_at" : "2014-05-25 15:08:25 +0000",
  "in_reply_to_screen_name" : "MartinBelan",
  "in_reply_to_user_id_str" : "28461779",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    }, {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 129, 135 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/tvmqsyGeSx",
      "expanded_url" : "http:\/\/www.salon.com\/2014\/05\/25\/the_1_percents_college_scam\/",
      "display_url" : "salon.com\/2014\/05\/25\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "470581995861708800",
  "text" : "RT @knittingknots: The trigger warning we need: \u201CCollege is a scam meant to perpetuate the 1 percent\u201D http:\/\/t.co\/tvmqsyGeSx via @Salon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Salon",
        "screen_name" : "Salon",
        "indices" : [ 110, 116 ],
        "id_str" : "16955991",
        "id" : 16955991
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/tvmqsyGeSx",
        "expanded_url" : "http:\/\/www.salon.com\/2014\/05\/25\/the_1_percents_college_scam\/",
        "display_url" : "salon.com\/2014\/05\/25\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "470581313146064899",
    "text" : "The trigger warning we need: \u201CCollege is a scam meant to perpetuate the 1 percent\u201D http:\/\/t.co\/tvmqsyGeSx via @Salon",
    "id" : 470581313146064899,
    "created_at" : "2014-05-25 15:05:02 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 470581995861708800,
  "created_at" : "2014-05-25 15:07:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 117, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470581705032876032",
  "text" : "RT @JALpalyul: Each one of us lives totally in our own mind stream. That is the totality of the experiences we have. #quote JAL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470580840188375040",
    "text" : "Each one of us lives totally in our own mind stream. That is the totality of the experiences we have. #quote JAL",
    "id" : 470580840188375040,
    "created_at" : "2014-05-25 15:03:09 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 470581705032876032,
  "created_at" : "2014-05-25 15:06:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 3, 15 ],
      "id_str" : "298992506",
      "id" : 298992506
    }, {
      "name" : "FSV Photography",
      "screen_name" : "FSVPhotography",
      "indices" : [ 20, 35 ],
      "id_str" : "2462107922",
      "id" : 2462107922
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 109, 121 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470579864995500032",
  "text" : "RT @wildlife_uk: RT @FSVPhotography: To start the day here is one of my favourite recent photos I have taken @wildlife_uk  http:\/\/t.co\/zKuW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FSV Photography",
        "screen_name" : "FSVPhotography",
        "indices" : [ 3, 18 ],
        "id_str" : "2462107922",
        "id" : 2462107922
      }, {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 92, 104 ],
        "id_str" : "298992506",
        "id" : 298992506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FSVPhotography\/status\/470474629426208768\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/zKuWrJBtz5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bod2LpDCIAEmSw0.jpg",
        "id_str" : "470474628452720641",
        "id" : 470474628452720641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bod2LpDCIAEmSw0.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/zKuWrJBtz5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470572573475225600",
    "text" : "RT @FSVPhotography: To start the day here is one of my favourite recent photos I have taken @wildlife_uk  http:\/\/t.co\/zKuWrJBtz5",
    "id" : 470572573475225600,
    "created_at" : "2014-05-25 14:30:18 +0000",
    "user" : {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "protected" : false,
      "id_str" : "298992506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543830606543478784\/DvQW3ag9_normal.png",
      "id" : 298992506,
      "verified" : false
    }
  },
  "id" : 470579864995500032,
  "created_at" : "2014-05-25 14:59:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470575025024942081",
  "text" : "if you tell people what they should not read.. that's oppressive. ps. i loved The Shack. very illuminating.",
  "id" : 470575025024942081,
  "created_at" : "2014-05-25 14:40:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 4, 17 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/b0fJhGxjhX",
      "expanded_url" : "http:\/\/bakerpublishinggroup.com\/bakerbooks\/baker-books-bloggers",
      "display_url" : "bakerpublishinggroup.com\/bakerbooks\/bak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "470571030898298880",
  "text" : "fyi @adamrshields http:\/\/t.co\/b0fJhGxjhX",
  "id" : 470571030898298880,
  "created_at" : "2014-05-25 14:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470562183093297153",
  "text" : "RT @TheGoldenMirror: Focusing on what gives you pain only keeps you in pain. Focusing on what gives you joy brings joy into your life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470561573661339649",
    "text" : "Focusing on what gives you pain only keeps you in pain. Focusing on what gives you joy brings joy into your life.",
    "id" : 470561573661339649,
    "created_at" : "2014-05-25 13:46:36 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 470562183093297153,
  "created_at" : "2014-05-25 13:49:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470330037984837632",
  "geo" : { },
  "id_str" : "470330915944529920",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny LOL",
  "id" : 470330915944529920,
  "in_reply_to_status_id" : 470330037984837632,
  "created_at" : "2014-05-24 22:30:03 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470008108644040707",
  "text" : "RT @BeasBookNook: My cell phone, which was on my leg, kept vibrating but whenever I checked, there was nothing new. Turned out, it was the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470007173800800257",
    "text" : "My cell phone, which was on my leg, kept vibrating but whenever I checked, there was nothing new. Turned out, it was the cat snoring.",
    "id" : 470007173800800257,
    "created_at" : "2014-05-24 01:03:37 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 470008108644040707,
  "created_at" : "2014-05-24 01:07:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "California Chromies",
      "screen_name" : "CalChrome",
      "indices" : [ 3, 13 ],
      "id_str" : "2382678470",
      "id" : 2382678470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/nAYky2HaRT",
      "expanded_url" : "http:\/\/nydn.us\/1vRrgR3",
      "display_url" : "nydn.us\/1vRrgR3"
    } ]
  },
  "geo" : { },
  "id_str" : "469989104785309696",
  "text" : "RT @CalChrome: SEE IT: Possum takes on Triple Crown hopeful California Chrome at Belmont Park Friday morning\u00A0 http:\/\/t.co\/nAYky2HaRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/nAYky2HaRT",
        "expanded_url" : "http:\/\/nydn.us\/1vRrgR3",
        "display_url" : "nydn.us\/1vRrgR3"
      } ]
    },
    "geo" : { },
    "id_str" : "469859872817676288",
    "text" : "SEE IT: Possum takes on Triple Crown hopeful California Chrome at Belmont Park Friday morning\u00A0 http:\/\/t.co\/nAYky2HaRT",
    "id" : 469859872817676288,
    "created_at" : "2014-05-23 15:18:17 +0000",
    "user" : {
      "name" : "California Chromies",
      "screen_name" : "CalChrome",
      "protected" : false,
      "id_str" : "2382678470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795799644899078145\/1DSbKlEl_normal.jpg",
      "id" : 2382678470,
      "verified" : false
    }
  },
  "id" : 469989104785309696,
  "created_at" : "2014-05-23 23:51:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469902950828371968",
  "text" : "dear Universe, thank you for all your compassion and blessings you rain down upon me.",
  "id" : 469902950828371968,
  "created_at" : "2014-05-23 18:09:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469845520148467713",
  "text" : "need to find my P spot...",
  "id" : 469845520148467713,
  "created_at" : "2014-05-23 14:21:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469821359195844608",
  "text" : "so blessed to wake up to a cat sleeping on my feet..lol",
  "id" : 469821359195844608,
  "created_at" : "2014-05-23 12:45:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469625544993026048",
  "text" : "im very immature for 40+. unfortunately, i will always be so.",
  "id" : 469625544993026048,
  "created_at" : "2014-05-22 23:47:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469598889486872577",
  "geo" : { },
  "id_str" : "469601947763609600",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone although.. TBH.. ive been guilty of righteous behaviour lately. conflicting! conflicting!",
  "id" : 469601947763609600,
  "in_reply_to_status_id" : 469598889486872577,
  "created_at" : "2014-05-22 22:13:23 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "469598889486872577",
  "geo" : { },
  "id_str" : "469600238353653760",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone ppl being righteous is a button w me. facebook.. argh..",
  "id" : 469600238353653760,
  "in_reply_to_status_id" : 469598889486872577,
  "created_at" : "2014-05-22 22:06:36 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469596256109469696",
  "text" : "No. just no. I am NOT going to share or agree.",
  "id" : 469596256109469696,
  "created_at" : "2014-05-22 21:50:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/469562944804900864\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/xtZqBq3b8K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQ5Ai1CUAAdzSB.jpg",
      "id_str" : "469562942665412608",
      "id" : 469562942665412608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQ5Ai1CUAAdzSB.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/xtZqBq3b8K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469563532775006210",
  "text" : "RT @CamoDave_: Collared Dove from garden today http:\/\/t.co\/xtZqBq3b8K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/469562944804900864\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/xtZqBq3b8K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQ5Ai1CUAAdzSB.jpg",
        "id_str" : "469562942665412608",
        "id" : 469562942665412608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQ5Ai1CUAAdzSB.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/xtZqBq3b8K"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469562944804900864",
    "text" : "Collared Dove from garden today http:\/\/t.co\/xtZqBq3b8K",
    "id" : 469562944804900864,
    "created_at" : "2014-05-22 19:38:24 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 469563532775006210,
  "created_at" : "2014-05-22 19:40:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/469535015827939328\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/JUUwKUvImi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQfm4fCEAE1iA0.jpg",
      "id_str" : "469535014011408385",
      "id" : 469535014011408385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQfm4fCEAE1iA0.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/JUUwKUvImi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469535791132475392",
  "text" : "RT @CUMALi_YILDIZ: Nonnengans (Branta leucopsis) http:\/\/t.co\/JUUwKUvImi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/469535015827939328\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/JUUwKUvImi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQfm4fCEAE1iA0.jpg",
        "id_str" : "469535014011408385",
        "id" : 469535014011408385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQfm4fCEAE1iA0.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/JUUwKUvImi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469535015827939328",
    "text" : "Nonnengans (Branta leucopsis) http:\/\/t.co\/JUUwKUvImi",
    "id" : 469535015827939328,
    "created_at" : "2014-05-22 17:47:25 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 469535791132475392,
  "created_at" : "2014-05-22 17:50:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/9qZOCp1xmx",
      "expanded_url" : "http:\/\/nakedpastor.com\/2014\/05\/jesus-the-bible-and-the-meat-grinder\/",
      "display_url" : "nakedpastor.com\/2014\/05\/jesus-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469281939187200000",
  "text" : "RT @nakedpastor: Bibliolatry betrays a disdain for the flesh. \"Jesus, the Bible, and the Meat Grinder\": http:\/\/t.co\/9qZOCp1xmx http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nakedpastor\/status\/469223757127487488\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/DgGNhpO2Pk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoMEhM4CUAATXa_.jpg",
        "id_str" : "469223754615115776",
        "id" : 469223754615115776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoMEhM4CUAATXa_.jpg",
        "sizes" : [ {
          "h" : 639,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DgGNhpO2Pk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/9qZOCp1xmx",
        "expanded_url" : "http:\/\/nakedpastor.com\/2014\/05\/jesus-the-bible-and-the-meat-grinder\/",
        "display_url" : "nakedpastor.com\/2014\/05\/jesus-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469223757127487488",
    "text" : "Bibliolatry betrays a disdain for the flesh. \"Jesus, the Bible, and the Meat Grinder\": http:\/\/t.co\/9qZOCp1xmx http:\/\/t.co\/DgGNhpO2Pk",
    "id" : 469223757127487488,
    "created_at" : "2014-05-21 21:10:36 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 469281939187200000,
  "created_at" : "2014-05-22 01:01:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 3, 12 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/469178902754394112\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/n8iuL3bk4S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoLbubFIEAAWXCT.jpg",
      "id_str" : "469178901789675520",
      "id" : 469178901789675520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoLbubFIEAAWXCT.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      } ],
      "display_url" : "pic.twitter.com\/n8iuL3bk4S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469179145226694658",
  "text" : "RT @BobTarte: Prothonotary Warbler in a thoughtful mood, Magee Marsh, Ohio, last week. http:\/\/t.co\/n8iuL3bk4S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/469178902754394112\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/n8iuL3bk4S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoLbubFIEAAWXCT.jpg",
        "id_str" : "469178901789675520",
        "id" : 469178901789675520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoLbubFIEAAWXCT.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/n8iuL3bk4S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469178902754394112",
    "text" : "Prothonotary Warbler in a thoughtful mood, Magee Marsh, Ohio, last week. http:\/\/t.co\/n8iuL3bk4S",
    "id" : 469178902754394112,
    "created_at" : "2014-05-21 18:12:22 +0000",
    "user" : {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "protected" : false,
      "id_str" : "490591746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570578729\/6y9pn9ap800am8pkqsku_normal.jpeg",
      "id" : 490591746,
      "verified" : false
    }
  },
  "id" : 469179145226694658,
  "created_at" : "2014-05-21 18:13:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goofydg1",
      "screen_name" : "goofydg1",
      "indices" : [ 3, 12 ],
      "id_str" : "18788609",
      "id" : 18788609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/fF0TVPl1PG",
      "expanded_url" : "https:\/\/wordpress.org\/plugins\/wp-reading-list\/",
      "display_url" : "wordpress.org\/plugins\/wp-rea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469162719770578944",
  "text" : "RT @goofydg1: WordPress \u203A WP Reading List \u00AB WordPress Plugins https:\/\/t.co\/fF0TVPl1PG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/fF0TVPl1PG",
        "expanded_url" : "https:\/\/wordpress.org\/plugins\/wp-reading-list\/",
        "display_url" : "wordpress.org\/plugins\/wp-rea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "455435538363727872",
    "text" : "WordPress \u203A WP Reading List \u00AB WordPress Plugins https:\/\/t.co\/fF0TVPl1PG",
    "id" : 455435538363727872,
    "created_at" : "2014-04-13 20:01:08 +0000",
    "user" : {
      "name" : "goofydg1",
      "screen_name" : "goofydg1",
      "protected" : false,
      "id_str" : "18788609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70289913\/gwd_logo_plain_normal.jpg",
      "id" : 18788609,
      "verified" : false
    }
  },
  "id" : 469162719770578944,
  "created_at" : "2014-05-21 17:08:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Atkin",
      "screen_name" : "alisonatkin",
      "indices" : [ 3, 15 ],
      "id_str" : "21301376",
      "id" : 21301376
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deafawareness",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469155612673077248",
  "text" : "RT @alisonatkin: It's #deafawareness week. Look at how adorable my hearing aids are (in addition to being badass medical technology)! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/alisonatkin\/status\/469154971146256385\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/eKIqi1Zuo2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoLF9ZiCQAA_9Zn.jpg",
        "id_str" : "469154969816285184",
        "id" : 469154969816285184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoLF9ZiCQAA_9Zn.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/eKIqi1Zuo2"
      } ],
      "hashtags" : [ {
        "text" : "deafawareness",
        "indices" : [ 5, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469154971146256385",
    "text" : "It's #deafawareness week. Look at how adorable my hearing aids are (in addition to being badass medical technology)! http:\/\/t.co\/eKIqi1Zuo2",
    "id" : 469154971146256385,
    "created_at" : "2014-05-21 16:37:16 +0000",
    "user" : {
      "name" : "Alison Atkin",
      "screen_name" : "alisonatkin",
      "protected" : false,
      "id_str" : "21301376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619918424001671170\/8PrJ9CFC_normal.jpg",
      "id" : 21301376,
      "verified" : false
    }
  },
  "id" : 469155612673077248,
  "created_at" : "2014-05-21 16:39:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indiegogo",
      "screen_name" : "Indiegogo",
      "indices" : [ 42, 52 ],
      "id_str" : "34732474",
      "id" : 34732474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/jogGWq4Ydg",
      "expanded_url" : "http:\/\/igg.me\/p\/758700\/twtr",
      "display_url" : "igg.me\/p\/758700\/twtr"
    } ]
  },
  "geo" : { },
  "id_str" : "469153630646304768",
  "text" : "Help make it happen for Solar Roadways on @indiegogo http:\/\/t.co\/jogGWq4Ydg Solar FREAKIN' Roadways!",
  "id" : 469153630646304768,
  "created_at" : "2014-05-21 16:31:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neon Nettle",
      "screen_name" : "NeonNettle",
      "indices" : [ 3, 14 ],
      "id_str" : "1911303422",
      "id" : 1911303422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NN",
      "indices" : [ 104, 107 ]
    }, {
      "text" : "WTC",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/lIscL8Tn8f",
      "expanded_url" : "http:\/\/neonnettle.com\/news\/211-ex-cia-pilot-gives-sworn-testimony-that-no-planes-hit-the-twin-towers",
      "display_url" : "neonnettle.com\/news\/211-ex-ci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468840875947085824",
  "text" : "RT @NeonNettle: - the Twin Towers story everyone\u2019s discussing: http:\/\/t.co\/lIscL8Tn8f -what do u think? #NN #WTC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NN",
        "indices" : [ 88, 91 ]
      }, {
        "text" : "WTC",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/lIscL8Tn8f",
        "expanded_url" : "http:\/\/neonnettle.com\/news\/211-ex-cia-pilot-gives-sworn-testimony-that-no-planes-hit-the-twin-towers",
        "display_url" : "neonnettle.com\/news\/211-ex-ci\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "468537308346875904",
    "geo" : { },
    "id_str" : "468690130753294336",
    "in_reply_to_user_id" : 1911303422,
    "text" : "- the Twin Towers story everyone\u2019s discussing: http:\/\/t.co\/lIscL8Tn8f -what do u think? #NN #WTC",
    "id" : 468690130753294336,
    "in_reply_to_status_id" : 468537308346875904,
    "created_at" : "2014-05-20 09:50:09 +0000",
    "in_reply_to_screen_name" : "NeonNettle",
    "in_reply_to_user_id_str" : "1911303422",
    "user" : {
      "name" : "Neon Nettle",
      "screen_name" : "NeonNettle",
      "protected" : false,
      "id_str" : "1911303422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732656342838726657\/Tcf25UF8_normal.jpg",
      "id" : 1911303422,
      "verified" : false
    }
  },
  "id" : 468840875947085824,
  "created_at" : "2014-05-20 19:49:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468528853783019520",
  "text" : "RT @modernevil: I\u2019m about to leave for the post office to send a few more, but the first reviewers have already started receiving Teratozoi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468526940593205248",
    "text" : "I\u2019m about to leave for the post office to send a few more, but the first reviewers have already started receiving Teratozoic. Exciting!",
    "id" : 468526940593205248,
    "created_at" : "2014-05-19 23:01:42 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 468528853783019520,
  "created_at" : "2014-05-19 23:09:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/aNx3GTgZN6",
      "expanded_url" : "http:\/\/www.psmag.com\/navigation\/health-and-behavior\/admitted-children-sex-primarily-pleasure-81691\/#.U3pSHlbixd0.twitter",
      "display_url" : "psmag.com\/navigation\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468463382970900480",
  "text" : "What If We Admitted to Children That Sex Is About Pleasure? - Pacific Standard: The Science of Society http:\/\/t.co\/aNx3GTgZN6",
  "id" : 468463382970900480,
  "created_at" : "2014-05-19 18:49:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468410635298934785",
  "text" : "im such a nerd (dork?) i get so excited when i find wordpress plugins that do neat things..lol",
  "id" : 468410635298934785,
  "created_at" : "2014-05-19 15:19:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 113, 126 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/VZ99qHrQmY",
      "expanded_url" : "http:\/\/wp.me\/p1ML21-zJ",
      "display_url" : "wp.me\/p1ML21-zJ"
    } ]
  },
  "geo" : { },
  "id_str" : "468169715081150464",
  "text" : "What Some Theologians Wish Everyone Knew About John 14's \"I am the way\" Proclamation: http:\/\/t.co\/VZ99qHrQmY via @CrystalLewis",
  "id" : 468169715081150464,
  "created_at" : "2014-05-18 23:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ra",
      "screen_name" : "Ra_Horakhty",
      "indices" : [ 3, 15 ],
      "id_str" : "3042393061",
      "id" : 3042393061
    }, {
      "name" : "Gabriele Corno",
      "screen_name" : "Gabriele_Corno",
      "indices" : [ 18, 33 ],
      "id_str" : "374752807",
      "id" : 374752807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gabriele_Corno\/status\/463976172435427329\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/fqLdTAF89Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnBf3oiCYAAkqtu.jpg",
      "id_str" : "463976170996785152",
      "id" : 463976170996785152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnBf3oiCYAAkqtu.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/fqLdTAF89Q"
    } ],
    "hashtags" : [ {
      "text" : "mystic",
      "indices" : [ 56, 63 ]
    }, {
      "text" : "CGE",
      "indices" : [ 64, 68 ]
    }, {
      "text" : "forest",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468123787528273921",
  "text" : "RT @Ra_Horakhty: \"@Gabriele_Corno Path by Rudi Restless #mystic #CGE #forest\" http:\/\/t.co\/fqLdTAF89Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabriele Corno",
        "screen_name" : "Gabriele_Corno",
        "indices" : [ 1, 16 ],
        "id_str" : "374752807",
        "id" : 374752807
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gabriele_Corno\/status\/463976172435427329\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/fqLdTAF89Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnBf3oiCYAAkqtu.jpg",
        "id_str" : "463976170996785152",
        "id" : 463976170996785152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnBf3oiCYAAkqtu.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/fqLdTAF89Q"
      } ],
      "hashtags" : [ {
        "text" : "mystic",
        "indices" : [ 39, 46 ]
      }, {
        "text" : "CGE",
        "indices" : [ 47, 51 ]
      }, {
        "text" : "forest",
        "indices" : [ 52, 59 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "463976172435427329",
    "geo" : { },
    "id_str" : "463980960141168640",
    "in_reply_to_user_id" : 374752807,
    "text" : "\"@Gabriele_Corno Path by Rudi Restless #mystic #CGE #forest\" http:\/\/t.co\/fqLdTAF89Q",
    "id" : 463980960141168640,
    "in_reply_to_status_id" : 463976172435427329,
    "created_at" : "2014-05-07 09:57:35 +0000",
    "in_reply_to_screen_name" : "Gabriele_Corno",
    "in_reply_to_user_id_str" : "374752807",
    "user" : {
      "name" : "Best Pictures",
      "screen_name" : "RA_BestPictures",
      "protected" : false,
      "id_str" : "1694425855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463691702599819264\/SLUO21IX_normal.jpeg",
      "id" : 1694425855,
      "verified" : false
    }
  },
  "id" : 468123787528273921,
  "created_at" : "2014-05-18 20:19:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "utk tun",
      "screen_name" : "utktun",
      "indices" : [ 3, 10 ],
      "id_str" : "2342619211",
      "id" : 2342619211
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/utktun\/status\/468112248397783040\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/cvkvujqYs5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bn8RmWoIIAA3HTH.jpg",
      "id_str" : "468112236876406784",
      "id" : 468112236876406784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bn8RmWoIIAA3HTH.jpg",
      "sizes" : [ {
        "h" : 371,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cvkvujqYs5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468123762496647169",
  "text" : "RT @utktun: L\u00E9onard Misonne (Belgian, 1870\u20131943)\nDie Kunst in der Photographie, 1900 http:\/\/t.co\/cvkvujqYs5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/utktun\/status\/468112248397783040\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/cvkvujqYs5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bn8RmWoIIAA3HTH.jpg",
        "id_str" : "468112236876406784",
        "id" : 468112236876406784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bn8RmWoIIAA3HTH.jpg",
        "sizes" : [ {
          "h" : 371,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/cvkvujqYs5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468112248397783040",
    "text" : "L\u00E9onard Misonne (Belgian, 1870\u20131943)\nDie Kunst in der Photographie, 1900 http:\/\/t.co\/cvkvujqYs5",
    "id" : 468112248397783040,
    "created_at" : "2014-05-18 19:33:51 +0000",
    "user" : {
      "name" : "utk tun",
      "screen_name" : "utktun",
      "protected" : false,
      "id_str" : "2342619211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760231604870676484\/kfj-opl0_normal.jpg",
      "id" : 2342619211,
      "verified" : false
    }
  },
  "id" : 468123762496647169,
  "created_at" : "2014-05-18 20:19:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elly K",
      "screen_name" : "ellyk_updates",
      "indices" : [ 3, 17 ],
      "id_str" : "396900704",
      "id" : 396900704
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ellyk_updates\/status\/467449286389542912\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/2QlWYc5IEI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bny2pWmCAAAzMj9.jpg",
      "id_str" : "467449282895675392",
      "id" : 467449282895675392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bny2pWmCAAAzMj9.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/2QlWYc5IEI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468037117663514624",
  "text" : "RT @ellyk_updates: Group of Canada geese and young in front of my apt this pm. I'm not a good photographer, lol. http:\/\/t.co\/2QlWYc5IEI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ellyk_updates\/status\/467449286389542912\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/2QlWYc5IEI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bny2pWmCAAAzMj9.jpg",
        "id_str" : "467449282895675392",
        "id" : 467449282895675392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bny2pWmCAAAzMj9.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/2QlWYc5IEI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467449286389542912",
    "text" : "Group of Canada geese and young in front of my apt this pm. I'm not a good photographer, lol. http:\/\/t.co\/2QlWYc5IEI",
    "id" : 467449286389542912,
    "created_at" : "2014-05-16 23:39:29 +0000",
    "user" : {
      "name" : "Elly K",
      "screen_name" : "ellyk_updates",
      "protected" : false,
      "id_str" : "396900704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446616139183828992\/pCtCV7jx_normal.jpeg",
      "id" : 396900704,
      "verified" : false
    }
  },
  "id" : 468037117663514624,
  "created_at" : "2014-05-18 14:35:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468036839283380225",
  "text" : "damn.. i missed a mauling opportunity.. the dog was outside.. sighhh.",
  "id" : 468036839283380225,
  "created_at" : "2014-05-18 14:34:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467740895555506176",
  "text" : "RT @PNHP: Former pharma exec Bernard Munos: \"\u201CEveryone is engaging in extreme prices because they can get away with it.\u201D http:\/\/t.co\/ASdyDz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/ASdyDzcdQC",
        "expanded_url" : "http:\/\/www.pnhp.org\/news\/2014\/may\/first-million-dollar-drug-near-after-prices-double-on-dozens-of-treatments",
        "display_url" : "pnhp.org\/news\/2014\/may\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466617569907331072",
    "text" : "Former pharma exec Bernard Munos: \"\u201CEveryone is engaging in extreme prices because they can get away with it.\u201D http:\/\/t.co\/ASdyDzcdQC",
    "id" : 466617569907331072,
    "created_at" : "2014-05-14 16:34:32 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 467740895555506176,
  "created_at" : "2014-05-17 18:58:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    }, {
      "name" : "Haasita",
      "screen_name" : "medschoolcookbk",
      "indices" : [ 13, 29 ],
      "id_str" : "426653690",
      "id" : 426653690
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insurance",
      "indices" : [ 54, 64 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/McM1umnEmh",
      "expanded_url" : "http:\/\/nyti.ms\/1ggikAu",
      "display_url" : "nyti.ms\/1ggikAu"
    } ]
  },
  "geo" : { },
  "id_str" : "467740755289595904",
  "text" : "RT @PNHP: RT @medschoolcookbk: Unfortunately, private #insurance does not equal choice! http:\/\/t.co\/McM1umnEmh #SinglePayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Haasita",
        "screen_name" : "medschoolcookbk",
        "indices" : [ 3, 19 ],
        "id_str" : "426653690",
        "id" : 426653690
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "insurance",
        "indices" : [ 44, 54 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/McM1umnEmh",
        "expanded_url" : "http:\/\/nyti.ms\/1ggikAu",
        "display_url" : "nyti.ms\/1ggikAu"
      } ]
    },
    "geo" : { },
    "id_str" : "466216395706236928",
    "text" : "RT @medschoolcookbk: Unfortunately, private #insurance does not equal choice! http:\/\/t.co\/McM1umnEmh #SinglePayer",
    "id" : 466216395706236928,
    "created_at" : "2014-05-13 14:00:25 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 467740755289595904,
  "created_at" : "2014-05-17 18:57:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Licata",
      "screen_name" : "BLicata",
      "indices" : [ 3, 11 ],
      "id_str" : "14298089",
      "id" : 14298089
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scichat",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "dinosaur",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/hzR15d4wRk",
      "expanded_url" : "http:\/\/pulse.me\/s\/1eKC9v",
      "display_url" : "pulse.me\/s\/1eKC9v"
    } ]
  },
  "geo" : { },
  "id_str" : "467739505236000768",
  "text" : "RT @BLicata: These Bones Might Be the Biggest Creature That Ever Walked the Earth http:\/\/t.co\/hzR15d4wRk #scichat #dinosaur",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scichat",
        "indices" : [ 92, 100 ]
      }, {
        "text" : "dinosaur",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/hzR15d4wRk",
        "expanded_url" : "http:\/\/pulse.me\/s\/1eKC9v",
        "display_url" : "pulse.me\/s\/1eKC9v"
      } ]
    },
    "geo" : { },
    "id_str" : "467736755731722240",
    "text" : "These Bones Might Be the Biggest Creature That Ever Walked the Earth http:\/\/t.co\/hzR15d4wRk #scichat #dinosaur",
    "id" : 467736755731722240,
    "created_at" : "2014-05-17 18:41:47 +0000",
    "user" : {
      "name" : "Brian Licata",
      "screen_name" : "BLicata",
      "protected" : false,
      "id_str" : "14298089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789981044774756352\/AoSJK2Dp_normal.jpg",
      "id" : 14298089,
      "verified" : false
    }
  },
  "id" : 467739505236000768,
  "created_at" : "2014-05-17 18:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blessed",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467735500543897600",
  "text" : "dear Universe.. again, thank you! : ) #blessed",
  "id" : 467735500543897600,
  "created_at" : "2014-05-17 18:36:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467110317449674752",
  "text" : "RT @ZachsMind: Every human being on this planet should have necessities provided. Shelter food &amp; water. This is not socialism. It's common \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467109347487936512",
    "text" : "Every human being on this planet should have necessities provided. Shelter food &amp; water. This is not socialism. It's common fucking decency.",
    "id" : 467109347487936512,
    "created_at" : "2014-05-16 01:08:41 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 467110317449674752,
  "created_at" : "2014-05-16 01:12:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 3, 16 ],
      "id_str" : "17068546",
      "id" : 17068546
    }, {
      "name" : "Darlene",
      "screen_name" : "SarcasticWonder",
      "indices" : [ 30, 46 ],
      "id_str" : "478686514",
      "id" : 478686514
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SarcasticWonder\/status\/467094747061161985\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/0SuwgJUCSM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnt0MlzIgAEslBQ.jpg",
      "id_str" : "467094746016808961",
      "id" : 467094746016808961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnt0MlzIgAEslBQ.jpg",
      "sizes" : [ {
        "h" : 890,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 890,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 890,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/0SuwgJUCSM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467107571053371392",
  "text" : "RT @TorontoLydia: Very cool. \u201C@SarcasticWonder: 5 -  the most interesting measuring cup in the WORLD! http:\/\/t.co\/0SuwgJUCSM\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darlene",
        "screen_name" : "SarcasticWonder",
        "indices" : [ 12, 28 ],
        "id_str" : "478686514",
        "id" : 478686514
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SarcasticWonder\/status\/467094747061161985\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/0SuwgJUCSM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnt0MlzIgAEslBQ.jpg",
        "id_str" : "467094746016808961",
        "id" : 467094746016808961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnt0MlzIgAEslBQ.jpg",
        "sizes" : [ {
          "h" : 890,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 890,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 890,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/0SuwgJUCSM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467105011898793984",
    "text" : "Very cool. \u201C@SarcasticWonder: 5 -  the most interesting measuring cup in the WORLD! http:\/\/t.co\/0SuwgJUCSM\u201D",
    "id" : 467105011898793984,
    "created_at" : "2014-05-16 00:51:27 +0000",
    "user" : {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "protected" : false,
      "id_str" : "17068546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2110881642\/LydiaTea_normal",
      "id" : 17068546,
      "verified" : false
    }
  },
  "id" : 467107571053371392,
  "created_at" : "2014-05-16 01:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/jOGc7IhAoV",
      "expanded_url" : "https:\/\/vine.co\/v\/MXXAL2u0q5d",
      "display_url" : "vine.co\/v\/MXXAL2u0q5d"
    } ]
  },
  "geo" : { },
  "id_str" : "467092790514446337",
  "text" : "RT @modernevil: Boxing preview copies of Teratozoic. The loop is real; I get to repeat this another ~40 times. https:\/\/t.co\/jOGc7IhAoV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/jOGc7IhAoV",
        "expanded_url" : "https:\/\/vine.co\/v\/MXXAL2u0q5d",
        "display_url" : "vine.co\/v\/MXXAL2u0q5d"
      } ]
    },
    "geo" : { },
    "id_str" : "467063031579811840",
    "text" : "Boxing preview copies of Teratozoic. The loop is real; I get to repeat this another ~40 times. https:\/\/t.co\/jOGc7IhAoV",
    "id" : 467063031579811840,
    "created_at" : "2014-05-15 22:04:39 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 467092790514446337,
  "created_at" : "2014-05-16 00:02:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467086959689482240",
  "text" : "jeeezus.. what is it with attacking smokers\/smoking?? ppl have been smoking for yrs. now it's evil???",
  "id" : 467086959689482240,
  "created_at" : "2014-05-15 23:39:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "indices" : [ 3, 13 ],
      "id_str" : "23539037",
      "id" : 23539037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467036603018653696",
  "text" : "RT @OhYouGirl: This day can suck it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467036349359734785",
    "text" : "This day can suck it.",
    "id" : 467036349359734785,
    "created_at" : "2014-05-15 20:18:37 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 467036603018653696,
  "created_at" : "2014-05-15 20:19:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "family",
      "indices" : [ 11, 18 ]
    }, {
      "text" : "baggage",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467004896382705664",
  "text" : "sighhh : ( #family #baggage",
  "id" : 467004896382705664,
  "created_at" : "2014-05-15 18:13:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "467003163460251648",
  "geo" : { },
  "id_str" : "467004497835732992",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH im so sorry ani-la! big (((hugs))) for you and dear Patches. : ((",
  "id" : 467004497835732992,
  "in_reply_to_status_id" : 467003163460251648,
  "created_at" : "2014-05-15 18:12:03 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/DuSMW9kqZ7",
      "expanded_url" : "http:\/\/www.biblegateway.com\/passage\/?search=Matthew+7%3A5&version=NASB",
      "display_url" : "biblegateway.com\/passage\/?searc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "466993547820802048",
  "text" : "damn.. DH got me with Matt 7:5 today. http:\/\/t.co\/DuSMW9kqZ7",
  "id" : 466993547820802048,
  "created_at" : "2014-05-15 17:28:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_2020mojo_",
      "screen_name" : "_2020mojo_",
      "indices" : [ 3, 14 ],
      "id_str" : "13547872",
      "id" : 13547872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466962018210430978",
  "text" : "RT @_2020mojo_: The world is the mind\u2019s hamster wheel.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466958854090412032",
    "text" : "The world is the mind\u2019s hamster wheel.",
    "id" : 466958854090412032,
    "created_at" : "2014-05-15 15:10:41 +0000",
    "user" : {
      "name" : "_2020mojo_",
      "screen_name" : "_2020mojo_",
      "protected" : false,
      "id_str" : "13547872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432215978009575425\/2jO6TjS2_normal.png",
      "id" : 13547872,
      "verified" : false
    }
  },
  "id" : 466962018210430978,
  "created_at" : "2014-05-15 15:23:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "_2020mojo_",
      "screen_name" : "_2020mojo_",
      "indices" : [ 0, 11 ],
      "id_str" : "13547872",
      "id" : 13547872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466958854090412032",
  "geo" : { },
  "id_str" : "466961954868056064",
  "in_reply_to_user_id" : 13547872,
  "text" : "@_2020mojo_ hmmm...",
  "id" : 466961954868056064,
  "in_reply_to_status_id" : 466958854090412032,
  "created_at" : "2014-05-15 15:23:00 +0000",
  "in_reply_to_screen_name" : "_2020mojo_",
  "in_reply_to_user_id_str" : "13547872",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/lVEEO6SXqU",
      "expanded_url" : "http:\/\/tinyurl.com\/l29faz9",
      "display_url" : "tinyurl.com\/l29faz9"
    } ]
  },
  "geo" : { },
  "id_str" : "466961274085990400",
  "text" : "RT @Seeds4Parents: Keep company only with people who uplift you, whose presence calls forth your best.http:\/\/t.co\/lVEEO6SXqU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/lVEEO6SXqU",
        "expanded_url" : "http:\/\/tinyurl.com\/l29faz9",
        "display_url" : "tinyurl.com\/l29faz9"
      } ]
    },
    "geo" : { },
    "id_str" : "466961119324553216",
    "text" : "Keep company only with people who uplift you, whose presence calls forth your best.http:\/\/t.co\/lVEEO6SXqU",
    "id" : 466961119324553216,
    "created_at" : "2014-05-15 15:19:41 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 466961274085990400,
  "created_at" : "2014-05-15 15:20:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "466626863641931776",
  "geo" : { },
  "id_str" : "466630846149976065",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray teehee. me, either.. and I'm a lot older! : )",
  "id" : 466630846149976065,
  "in_reply_to_status_id" : 466626863641931776,
  "created_at" : "2014-05-14 17:27:17 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 0, 16 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466612530685571072",
  "text" : "@KevinRDaugherty he wouldn't care for me, then, either. I've always been universalistic.. nothing else made sense to me.",
  "id" : 466612530685571072,
  "created_at" : "2014-05-14 16:14:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 0, 16 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466611892795244544",
  "text" : "@KevinRDaugherty excuse my ignorance.. what do you mean by individualistic?",
  "id" : 466611892795244544,
  "created_at" : "2014-05-14 16:11:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466357734338998274",
  "text" : "gay agenda! gay agenda! WTF about MY agenda??",
  "id" : 466357734338998274,
  "created_at" : "2014-05-13 23:22:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/sxgikkU1D4",
      "expanded_url" : "http:\/\/youtu.be\/oCp_9ljeGv8",
      "display_url" : "youtu.be\/oCp_9ljeGv8"
    } ]
  },
  "geo" : { },
  "id_str" : "466357306670587904",
  "text" : "((facepalm)) Anti-Gay HGTV Twin Doesn't 'Hate' Gays, Hates 'Gay Agenda': http:\/\/t.co\/sxgikkU1D4",
  "id" : 466357306670587904,
  "created_at" : "2014-05-13 23:20:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 100, 108 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/sxgikkU1D4",
      "expanded_url" : "http:\/\/youtu.be\/oCp_9ljeGv8",
      "display_url" : "youtu.be\/oCp_9ljeGv8"
    } ]
  },
  "geo" : { },
  "id_str" : "466357106472280064",
  "text" : "((facepalm)) Anti-Gay HGTV Twin Doesn't 'Hate' Gays, Hates 'Gay Agenda': http:\/\/t.co\/sxgikkU1D4 via @YouTube",
  "id" : 466357106472280064,
  "created_at" : "2014-05-13 23:19:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 100, 108 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/sxgikkU1D4",
      "expanded_url" : "http:\/\/youtu.be\/oCp_9ljeGv8",
      "display_url" : "youtu.be\/oCp_9ljeGv8"
    } ]
  },
  "geo" : { },
  "id_str" : "466357106677788672",
  "text" : "((facepalm)) Anti-Gay HGTV Twin Doesn't 'Hate' Gays, Hates 'Gay Agenda': http:\/\/t.co\/sxgikkU1D4 via @YouTube",
  "id" : 466357106677788672,
  "created_at" : "2014-05-13 23:19:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466274924449910784",
  "text" : "@Lluminous_ took me a looong time to figure this one out!",
  "id" : 466274924449910784,
  "created_at" : "2014-05-13 17:52:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466265199893180417",
  "text" : "none of us really knows if another carries demons within.",
  "id" : 466265199893180417,
  "created_at" : "2014-05-13 17:14:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465979585184530433",
  "text" : "i just read a book about the quiverfull movement and it literally turned my stomach. women are property transferred father to husband.",
  "id" : 465979585184530433,
  "created_at" : "2014-05-12 22:19:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathryn Brightbill",
      "screen_name" : "rynthetyn",
      "indices" : [ 3, 13 ],
      "id_str" : "14769495",
      "id" : 14769495
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HomeschoolKid",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465964425644494848",
  "text" : "RT @rynthetyn: #HomeschoolKid wears age appropriate dress to homeschool prom. Naturally homeschool dads have a problem with this. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HomeschoolKid",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/FEsd1T8hcE",
        "expanded_url" : "http:\/\/www.hannahettinger.com\/fuck-the-patriarchy-guest-post-by-clare\/",
        "display_url" : "hannahettinger.com\/fuck-the-patri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "465757608948019200",
    "text" : "#HomeschoolKid wears age appropriate dress to homeschool prom. Naturally homeschool dads have a problem with this. http:\/\/t.co\/FEsd1T8hcE",
    "id" : 465757608948019200,
    "created_at" : "2014-05-12 07:37:21 +0000",
    "user" : {
      "name" : "Kathryn Brightbill",
      "screen_name" : "rynthetyn",
      "protected" : false,
      "id_str" : "14769495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782844653527789568\/hLrN8T_D_normal.jpg",
      "id" : 14769495,
      "verified" : false
    }
  },
  "id" : 465964425644494848,
  "created_at" : "2014-05-12 21:19:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465943794962026497",
  "text" : "RT @CoyoteSings: \"I don't believe that consciousness is generated by the brain. I believe that the brain is more of a receiver of conscious\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465939687215882240",
    "text" : "\"I don't believe that consciousness is generated by the brain. I believe that the brain is more of a receiver of consciousness.\" G. Hancock",
    "id" : 465939687215882240,
    "created_at" : "2014-05-12 19:40:52 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 465943794962026497,
  "created_at" : "2014-05-12 19:57:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465943056332509184",
  "text" : "RT @TheGoldenMirror: We interpret other peoples behavior according to our own state of mind. We are what we see in others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465941210889478144",
    "text" : "We interpret other peoples behavior according to our own state of mind. We are what we see in others.",
    "id" : 465941210889478144,
    "created_at" : "2014-05-12 19:46:56 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 465943056332509184,
  "created_at" : "2014-05-12 19:54:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Life",
      "screen_name" : "MeetAnimals",
      "indices" : [ 3, 15 ],
      "id_str" : "953278568",
      "id" : 953278568
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MeetAnimals\/status\/465579598441639937\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/O6ZYT6DINo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnYSLYzIMAE-hpY.jpg",
      "id_str" : "465579598324183041",
      "id" : 465579598324183041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnYSLYzIMAE-hpY.jpg",
      "sizes" : [ {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/O6ZYT6DINo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465846294242537472",
  "text" : "RT @MeetAnimals: Caught in the middle of the argument, Pentet Bird by Sijanto Nature http:\/\/t.co\/O6ZYT6DINo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MeetAnimals\/status\/465579598441639937\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/O6ZYT6DINo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnYSLYzIMAE-hpY.jpg",
        "id_str" : "465579598324183041",
        "id" : 465579598324183041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnYSLYzIMAE-hpY.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/O6ZYT6DINo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465579598441639937",
    "text" : "Caught in the middle of the argument, Pentet Bird by Sijanto Nature http:\/\/t.co\/O6ZYT6DINo",
    "id" : 465579598441639937,
    "created_at" : "2014-05-11 19:50:00 +0000",
    "user" : {
      "name" : "Animal Life",
      "screen_name" : "MeetAnimals",
      "protected" : false,
      "id_str" : "953278568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676238326614106112\/YY_RxPPE_normal.jpg",
      "id" : 953278568,
      "verified" : false
    }
  },
  "id" : 465846294242537472,
  "created_at" : "2014-05-12 13:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "465189431461175296",
  "geo" : { },
  "id_str" : "465273598203027456",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields not all my books are kindle books. i finally found the clippings file but will I remember next time? noo..lol",
  "id" : 465273598203027456,
  "in_reply_to_status_id" : 465189431461175296,
  "created_at" : "2014-05-10 23:34:04 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465180751332265984",
  "text" : "who knew trying to get copy of My Clippings on #kindle onto PC would be such a project? argh. (finally did it)",
  "id" : 465180751332265984,
  "created_at" : "2014-05-10 17:25:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "indices" : [ 3, 12 ],
      "id_str" : "800652126",
      "id" : 800652126
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/464785221989445632\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ya2YwnSvCz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnM_sb-CMAAi1FP.jpg",
      "id_str" : "464785219204034560",
      "id" : 464785219204034560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnM_sb-CMAAi1FP.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/ya2YwnSvCz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464785658541006848",
  "text" : "RT @MrRat395: 2014 Corvette Stingray - nice looking rear end:-) http:\/\/t.co\/ya2YwnSvCz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/464785221989445632\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/ya2YwnSvCz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnM_sb-CMAAi1FP.jpg",
        "id_str" : "464785219204034560",
        "id" : 464785219204034560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnM_sb-CMAAi1FP.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/ya2YwnSvCz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464785221989445632",
    "text" : "2014 Corvette Stingray - nice looking rear end:-) http:\/\/t.co\/ya2YwnSvCz",
    "id" : 464785221989445632,
    "created_at" : "2014-05-09 15:13:26 +0000",
    "user" : {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "protected" : false,
      "id_str" : "800652126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779503692802240512\/iVwM-mwl_normal.jpg",
      "id" : 800652126,
      "verified" : false
    }
  },
  "id" : 464785658541006848,
  "created_at" : "2014-05-09 15:15:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hormones",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "goingcrazy",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464755739978776576",
  "text" : "i wouldnt let the dog out last night due to strange noise. im thinking ufo is going to take my dog. #hormones ? #goingcrazy",
  "id" : 464755739978776576,
  "created_at" : "2014-05-09 13:16:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/L8wtJPXrN4",
      "expanded_url" : "http:\/\/wp.me\/p1pu8r-8Uv",
      "display_url" : "wp.me\/p1pu8r-8Uv"
    } ]
  },
  "geo" : { },
  "id_str" : "464552365698605057",
  "text" : "RT @adamrshields: NoiseTrade has books, free if you want. Here are a few worth looking at. http:\/\/t.co\/L8wtJPXrN4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/L8wtJPXrN4",
        "expanded_url" : "http:\/\/wp.me\/p1pu8r-8Uv",
        "display_url" : "wp.me\/p1pu8r-8Uv"
      } ]
    },
    "geo" : { },
    "id_str" : "464058222001655809",
    "text" : "NoiseTrade has books, free if you want. Here are a few worth looking at. http:\/\/t.co\/L8wtJPXrN4",
    "id" : 464058222001655809,
    "created_at" : "2014-05-07 15:04:36 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 464552365698605057,
  "created_at" : "2014-05-08 23:48:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "indices" : [ 3, 14 ],
      "id_str" : "548388698",
      "id" : 548388698
    }, {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 105, 118 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/wvQxIxTI8V",
      "expanded_url" : "http:\/\/feedly.com\/e\/X82D82Jl",
      "display_url" : "feedly.com\/e\/X82D82Jl"
    } ]
  },
  "geo" : { },
  "id_str" : "464551936034107392",
  "text" : "RT @JohnUmland: Confessions of a Religious Asshole http:\/\/t.co\/wvQxIxTI8V me too...everyday man...thanks @micahjmurray",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Micah J. Murray",
        "screen_name" : "micahjmurray",
        "indices" : [ 89, 102 ],
        "id_str" : "94619438",
        "id" : 94619438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/wvQxIxTI8V",
        "expanded_url" : "http:\/\/feedly.com\/e\/X82D82Jl",
        "display_url" : "feedly.com\/e\/X82D82Jl"
      } ]
    },
    "geo" : { },
    "id_str" : "464429729546645504",
    "text" : "Confessions of a Religious Asshole http:\/\/t.co\/wvQxIxTI8V me too...everyday man...thanks @micahjmurray",
    "id" : 464429729546645504,
    "created_at" : "2014-05-08 15:40:50 +0000",
    "user" : {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "protected" : false,
      "id_str" : "548388698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797536354452340736\/6SfqJlHp_normal.jpg",
      "id" : 548388698,
      "verified" : false
    }
  },
  "id" : 464551936034107392,
  "created_at" : "2014-05-08 23:46:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464473625031372801",
  "geo" : { },
  "id_str" : "464476822730579968",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem you should see me run, then..lol. like watching a tape in slow motion! ; )",
  "id" : 464476822730579968,
  "in_reply_to_status_id" : 464473625031372801,
  "created_at" : "2014-05-08 18:47:58 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "464473907068534784",
  "geo" : { },
  "id_str" : "464476622431612928",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem diabetes is not necessarily curable.",
  "id" : 464476622431612928,
  "in_reply_to_status_id" : 464473907068534784,
  "created_at" : "2014-05-08 18:47:11 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464475744677003264",
  "text" : "how small our human lives are.. so very, very small.",
  "id" : 464475744677003264,
  "created_at" : "2014-05-08 18:43:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464470079506100225",
  "text" : "getting a headache from genealogy searching!",
  "id" : 464470079506100225,
  "created_at" : "2014-05-08 18:21:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/2RRSpHoMbo",
      "expanded_url" : "http:\/\/cjonline.com\/news\/2014-05-05\/fourth-phelps-roper-sibling-leaves-westboro-baptist-church#.U2rb1BkHREU.twitter",
      "display_url" : "cjonline.com\/news\/2014-05-0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "464213275521998848",
  "text" : "Fourth Phelps-Roper sibling leaves Westboro Baptist Church http:\/\/t.co\/2RRSpHoMbo",
  "id" : 464213275521998848,
  "created_at" : "2014-05-08 01:20:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/No5DYyuQpD",
      "expanded_url" : "http:\/\/ancestry.com",
      "display_url" : "ancestry.com"
    } ]
  },
  "geo" : { },
  "id_str" : "464055415081152513",
  "text" : "any recommends for family tree software? free or inexpensive. i've started tree on http:\/\/t.co\/No5DYyuQpD.",
  "id" : 464055415081152513,
  "created_at" : "2014-05-07 14:53:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@BBCNewsMagazin1",
      "screen_name" : "bbcnewsmagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "780330724557742081",
      "id" : 780330724557742081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewsfromElsewhere",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KBGAvUOiDC",
      "expanded_url" : "http:\/\/bbc.in\/1nnzRX5",
      "display_url" : "bbc.in\/1nnzRX5"
    } ]
  },
  "geo" : { },
  "id_str" : "464034017327591424",
  "text" : "RT @BBCNewsMagazine: Saudi man put a fridge on the street for people to leave food for the needy #NewsfromElsewhere http:\/\/t.co\/KBGAvUOiDC \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BBCNewsMagazine\/status\/463977637640404992\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rDeTSoPoG8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnBhM_lIUAAqAIx.jpg",
        "id_str" : "463977637472653312",
        "id" : 463977637472653312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnBhM_lIUAAqAIx.jpg",
        "sizes" : [ {
          "h" : 351,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 624
        } ],
        "display_url" : "pic.twitter.com\/rDeTSoPoG8"
      } ],
      "hashtags" : [ {
        "text" : "NewsfromElsewhere",
        "indices" : [ 76, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/KBGAvUOiDC",
        "expanded_url" : "http:\/\/bbc.in\/1nnzRX5",
        "display_url" : "bbc.in\/1nnzRX5"
      } ]
    },
    "geo" : { },
    "id_str" : "463977637640404992",
    "text" : "Saudi man put a fridge on the street for people to leave food for the needy #NewsfromElsewhere http:\/\/t.co\/KBGAvUOiDC http:\/\/t.co\/rDeTSoPoG8",
    "id" : 463977637640404992,
    "created_at" : "2014-05-07 09:44:23 +0000",
    "user" : {
      "name" : "BBC Stories",
      "screen_name" : "bbcstories",
      "protected" : false,
      "id_str" : "14697685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793410382215966720\/4xyicT-8_normal.jpg",
      "id" : 14697685,
      "verified" : true
    }
  },
  "id" : 464034017327591424,
  "created_at" : "2014-05-07 13:28:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463855153225801728",
  "geo" : { },
  "id_str" : "463855936205889537",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater really? weird.",
  "id" : 463855936205889537,
  "in_reply_to_status_id" : 463855153225801728,
  "created_at" : "2014-05-07 01:40:47 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463770791339765760",
  "text" : "been working on my family tree. someone shared theirs which helped me greatly to fill in.",
  "id" : 463770791339765760,
  "created_at" : "2014-05-06 20:02:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463697293007667200",
  "text" : "such a weird thing.. wasnt until mid 30s i stopped caring about my high school years. interesting what a strong effect they are.",
  "id" : 463697293007667200,
  "created_at" : "2014-05-06 15:10:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blossoming",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463696655997362176",
  "text" : "DD is doing very well at her internship. she's a hard worker and they just love her. she even eats while there! #blossoming",
  "id" : 463696655997362176,
  "created_at" : "2014-05-06 15:07:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/463693520562556928\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/LZ2gEuAv6F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm9ey-ICQAEYjVI.jpg",
      "id_str" : "463693516405620737",
      "id" : 463693516405620737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm9ey-ICQAEYjVI.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LZ2gEuAv6F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463696046913097728",
  "text" : "RT @rm123077: A pair of Collared Doves enjoying the sprinkler in my yard. http:\/\/t.co\/LZ2gEuAv6F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/463693520562556928\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/LZ2gEuAv6F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm9ey-ICQAEYjVI.jpg",
        "id_str" : "463693516405620737",
        "id" : 463693516405620737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm9ey-ICQAEYjVI.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LZ2gEuAv6F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463693520562556928",
    "text" : "A pair of Collared Doves enjoying the sprinkler in my yard. http:\/\/t.co\/LZ2gEuAv6F",
    "id" : 463693520562556928,
    "created_at" : "2014-05-06 14:55:24 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 463696046913097728,
  "created_at" : "2014-05-06 15:05:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Levin",
      "screen_name" : "jilevin",
      "indices" : [ 3, 11 ],
      "id_str" : "24733117",
      "id" : 24733117
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jilevin\/status\/345953677099560960\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/CnNBWsjqVZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM0TCVDCcAAPYnc.jpg",
      "id_str" : "345953677107949568",
      "id" : 345953677107949568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM0TCVDCcAAPYnc.jpg",
      "sizes" : [ {
        "h" : 214,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/CnNBWsjqVZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463695620679933952",
  "text" : "RT @jilevin: Besides repeatedly trying to repeal Obamacare, what is the most frequently bill passed in Congress? http:\/\/t.co\/CnNBWsjqVZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jilevin\/status\/345953677099560960\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/CnNBWsjqVZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BM0TCVDCcAAPYnc.jpg",
        "id_str" : "345953677107949568",
        "id" : 345953677107949568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM0TCVDCcAAPYnc.jpg",
        "sizes" : [ {
          "h" : 214,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 214,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/CnNBWsjqVZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463530379446865920",
    "text" : "Besides repeatedly trying to repeal Obamacare, what is the most frequently bill passed in Congress? http:\/\/t.co\/CnNBWsjqVZ",
    "id" : 463530379446865920,
    "created_at" : "2014-05-06 04:07:09 +0000",
    "user" : {
      "name" : "Jeffrey Levin",
      "screen_name" : "jilevin",
      "protected" : false,
      "id_str" : "24733117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744616664549908480\/0DRPI0oj_normal.jpg",
      "id" : 24733117,
      "verified" : false
    }
  },
  "id" : 463695620679933952,
  "created_at" : "2014-05-06 15:03:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463522275828826112",
  "geo" : { },
  "id_str" : "463682572628017152",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia you're just now replying to this? trying to confuse me, you are..lol @weakSquare",
  "id" : 463682572628017152,
  "in_reply_to_status_id" : 463522275828826112,
  "created_at" : "2014-05-06 14:11:54 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "indices" : [ 3, 13 ],
      "id_str" : "14320620",
      "id" : 14320620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/hEShiR34uu",
      "expanded_url" : "http:\/\/thefreethoughtproject.com\/wtf-wrong-america-public-schools-holding-disturbing-drills\/",
      "display_url" : "thefreethoughtproject.com\/wtf-wrong-amer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463681705807986688",
  "text" : "RT @vaxen_var: WTF is Wrong with you America? http:\/\/t.co\/hEShiR34uu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/hEShiR34uu",
        "expanded_url" : "http:\/\/thefreethoughtproject.com\/wtf-wrong-america-public-schools-holding-disturbing-drills\/",
        "display_url" : "thefreethoughtproject.com\/wtf-wrong-amer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463680858269163520",
    "text" : "WTF is Wrong with you America? http:\/\/t.co\/hEShiR34uu",
    "id" : 463680858269163520,
    "created_at" : "2014-05-06 14:05:06 +0000",
    "user" : {
      "name" : "vaxen_var",
      "screen_name" : "vaxen_var",
      "protected" : false,
      "id_str" : "14320620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529619056731488256\/bImjoejX_normal.png",
      "id" : 14320620,
      "verified" : false
    }
  },
  "id" : 463681705807986688,
  "created_at" : "2014-05-06 14:08:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    }, {
      "name" : "Aria",
      "screen_name" : "ariastarbright",
      "indices" : [ 62, 77 ],
      "id_str" : "2285980750",
      "id" : 2285980750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "463333807605968896",
  "geo" : { },
  "id_str" : "463360556586774528",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 ha! : D (ps. think im owned by a cat now. new addition.) @ariastarbright",
  "id" : 463360556586774528,
  "in_reply_to_status_id" : 463333807605968896,
  "created_at" : "2014-05-05 16:52:20 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aria",
      "screen_name" : "ariastarbright",
      "indices" : [ 3, 18 ],
      "id_str" : "2285980750",
      "id" : 2285980750
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ariastarbright\/status\/463317381587435520\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/J63LU12JdL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm4ItCPIcAEvy75.jpg",
      "id_str" : "463317381453213697",
      "id" : 463317381453213697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm4ItCPIcAEvy75.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 659
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 659
      } ],
      "display_url" : "pic.twitter.com\/J63LU12JdL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463331655852519424",
  "text" : "RT @ariastarbright: http:\/\/t.co\/J63LU12JdL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ariastarbright\/status\/463317381587435520\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/J63LU12JdL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm4ItCPIcAEvy75.jpg",
        "id_str" : "463317381453213697",
        "id" : 463317381453213697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm4ItCPIcAEvy75.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 659
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 659
        } ],
        "display_url" : "pic.twitter.com\/J63LU12JdL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463317381587435520",
    "text" : "http:\/\/t.co\/J63LU12JdL",
    "id" : 463317381587435520,
    "created_at" : "2014-05-05 14:00:46 +0000",
    "user" : {
      "name" : "Aria",
      "screen_name" : "ariastarbright",
      "protected" : false,
      "id_str" : "2285980750",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486310212891340800\/3EUl8sBZ_normal.jpeg",
      "id" : 2285980750,
      "verified" : false
    }
  },
  "id" : 463331655852519424,
  "created_at" : "2014-05-05 14:57:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463314030904758273",
  "text" : "hmm.. Arrow Paradox #woo",
  "id" : 463314030904758273,
  "created_at" : "2014-05-05 13:47:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463312782751191041",
  "text" : "amazing how much i have learned from twitter...",
  "id" : 463312782751191041,
  "created_at" : "2014-05-05 13:42:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logical Analysis",
      "screen_name" : "LogicalAnalysis",
      "indices" : [ 3, 19 ],
      "id_str" : "138509803",
      "id" : 138509803
    }, {
      "name" : "Matt Bruenig",
      "screen_name" : "MattBruenig",
      "indices" : [ 51, 63 ],
      "id_str" : "327337127",
      "id" : 327337127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/eKLP63OKRY",
      "expanded_url" : "http:\/\/mattbruenig.com\/2014\/05\/02\/rich-parents-planned-this\/",
      "display_url" : "mattbruenig.com\/2014\/05\/02\/ric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463308125463117824",
  "text" : "RT @LogicalAnalysis: Rich Parents Planned This via @MattBruenig http:\/\/t.co\/eKLP63OKRY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Bruenig",
        "screen_name" : "MattBruenig",
        "indices" : [ 30, 42 ],
        "id_str" : "327337127",
        "id" : 327337127
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/eKLP63OKRY",
        "expanded_url" : "http:\/\/mattbruenig.com\/2014\/05\/02\/rich-parents-planned-this\/",
        "display_url" : "mattbruenig.com\/2014\/05\/02\/ric\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463306417114341376",
    "text" : "Rich Parents Planned This via @MattBruenig http:\/\/t.co\/eKLP63OKRY",
    "id" : 463306417114341376,
    "created_at" : "2014-05-05 13:17:12 +0000",
    "user" : {
      "name" : "Logical Analysis",
      "screen_name" : "LogicalAnalysis",
      "protected" : false,
      "id_str" : "138509803",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792250209136812032\/6c2qUyu8_normal.jpg",
      "id" : 138509803,
      "verified" : false
    }
  },
  "id" : 463308125463117824,
  "created_at" : "2014-05-05 13:23:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "indices" : [ 3, 12 ],
      "id_str" : "64009474",
      "id" : 64009474
    }, {
      "name" : "Dr. Mark Hiatt",
      "screen_name" : "Mark_Hiatt",
      "indices" : [ 30, 41 ],
      "id_str" : "307550044",
      "id" : 307550044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Y9edyx4IAr",
      "expanded_url" : "http:\/\/www.nejm.org\/doi\/full\/10.1056\/NEJMp1401875",
      "display_url" : "nejm.org\/doi\/full\/10.10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463090616034148352",
  "text" : "RT @Adenovir: Interesting. RT @Mark_Hiatt: Swiss Medical Board: \"Stop widespread mammography screening\" (http:\/\/t.co\/Y9edyx4IAr)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Mark Hiatt",
        "screen_name" : "Mark_Hiatt",
        "indices" : [ 16, 27 ],
        "id_str" : "307550044",
        "id" : 307550044
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/Y9edyx4IAr",
        "expanded_url" : "http:\/\/www.nejm.org\/doi\/full\/10.1056\/NEJMp1401875",
        "display_url" : "nejm.org\/doi\/full\/10.10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463086542324776960",
    "text" : "Interesting. RT @Mark_Hiatt: Swiss Medical Board: \"Stop widespread mammography screening\" (http:\/\/t.co\/Y9edyx4IAr)",
    "id" : 463086542324776960,
    "created_at" : "2014-05-04 22:43:30 +0000",
    "user" : {
      "name" : "(((Ad Rock)))",
      "screen_name" : "Adenovir",
      "protected" : false,
      "id_str" : "64009474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796245390291075072\/QDDHsRWI_normal.jpg",
      "id" : 64009474,
      "verified" : false
    }
  },
  "id" : 463090616034148352,
  "created_at" : "2014-05-04 22:59:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordpress",
      "indices" : [ 7, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463086669529612288",
  "text" : "ohhh.. #wordpress took out the Links for new installs after 3.5. Have to use plugin or Menu system. Oy!",
  "id" : 463086669529612288,
  "created_at" : "2014-05-04 22:44:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordpress",
      "indices" : [ 4, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463083366242590720",
  "text" : "new #wordpress install in a new directory but there is no LINK section. any ideas why? Posts, Media, Pages, Comments. No Links!",
  "id" : 463083366242590720,
  "created_at" : "2014-05-04 22:30:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462994972560474113",
  "geo" : { },
  "id_str" : "462995862424399873",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino he's a keeper! : )",
  "id" : 462995862424399873,
  "in_reply_to_status_id" : 462994972560474113,
  "created_at" : "2014-05-04 16:43:10 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trisha La Comber",
      "screen_name" : "la_comber",
      "indices" : [ 3, 13 ],
      "id_str" : "2161228906",
      "id" : 2161228906
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/la_comber\/status\/462880543152291840\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/cEoM8Fyiz0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmx7ZryIEAAFkn3.jpg",
      "id_str" : "462880542892232704",
      "id" : 462880542892232704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmx7ZryIEAAFkn3.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cEoM8Fyiz0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462975471668703232",
  "text" : "RT @la_comber: The Cats Meeoow.....TLaC....my first painting....still unfinished   150 x 90 cm http:\/\/t.co\/cEoM8Fyiz0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/la_comber\/status\/462880543152291840\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/cEoM8Fyiz0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmx7ZryIEAAFkn3.jpg",
        "id_str" : "462880542892232704",
        "id" : 462880542892232704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmx7ZryIEAAFkn3.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cEoM8Fyiz0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462880543152291840",
    "text" : "The Cats Meeoow.....TLaC....my first painting....still unfinished   150 x 90 cm http:\/\/t.co\/cEoM8Fyiz0",
    "id" : 462880543152291840,
    "created_at" : "2014-05-04 09:04:56 +0000",
    "user" : {
      "name" : "Trisha La Comber",
      "screen_name" : "la_comber",
      "protected" : false,
      "id_str" : "2161228906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772395982164267008\/j7UOXsfv_normal.jpg",
      "id" : 2161228906,
      "verified" : false
    }
  },
  "id" : 462975471668703232,
  "created_at" : "2014-05-04 15:22:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462824331416838144",
  "geo" : { },
  "id_str" : "462948467040858113",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia i really need to read that book...",
  "id" : 462948467040858113,
  "in_reply_to_status_id" : 462824331416838144,
  "created_at" : "2014-05-04 13:34:50 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zbynek Kysela",
      "screen_name" : "cmelakigor",
      "indices" : [ 13, 24 ],
      "id_str" : "746140372808634368",
      "id" : 746140372808634368
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cmelakigor\/status\/460691012806258688\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jpCgXr2SFn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmS0CQBIAAAY9Uw.jpg",
      "id_str" : "460691012651057152",
      "id" : 460691012651057152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmS0CQBIAAAY9Uw.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/jpCgXr2SFn"
    } ],
    "hashtags" : [ {
      "text" : "500px",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/lLI9xOq3tu",
      "expanded_url" : "http:\/\/ift.tt\/1it0ofX",
      "display_url" : "ift.tt\/1it0ofX"
    } ]
  },
  "in_reply_to_status_id_str" : "460691012806258688",
  "geo" : { },
  "id_str" : "462666148283445250",
  "in_reply_to_user_id" : 85021241,
  "text" : "adorable! RT @cmelakigor Red and Berry on a post by Andre Villeneuve via http:\/\/t.co\/lLI9xOq3tu #500px http:\/\/t.co\/jpCgXr2SFn",
  "id" : 462666148283445250,
  "in_reply_to_status_id" : 460691012806258688,
  "created_at" : "2014-05-03 18:53:00 +0000",
  "in_reply_to_screen_name" : "DrKysela",
  "in_reply_to_user_id_str" : "85021241",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Because Reading \uD83D\uDE18",
      "screen_name" : "Limabean74",
      "indices" : [ 3, 14 ],
      "id_str" : "23750976",
      "id" : 23750976
    }, {
      "name" : "Mad Hatter Reads",
      "screen_name" : "madhatterreads",
      "indices" : [ 74, 89 ],
      "id_str" : "596698148",
      "id" : 596698148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/kFfl4c3rnv",
      "expanded_url" : "http:\/\/madhatterreads.com\/2014\/04\/help-wantedassociate-reviewer\/",
      "display_url" : "madhatterreads.com\/2014\/04\/help-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462653831999152129",
  "text" : "RT @Limabean74: Help Wanted~Associate Reviewer http:\/\/t.co\/kFfl4c3rnv via @madhatterreads",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mad Hatter Reads",
        "screen_name" : "madhatterreads",
        "indices" : [ 58, 73 ],
        "id_str" : "596698148",
        "id" : 596698148
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/kFfl4c3rnv",
        "expanded_url" : "http:\/\/madhatterreads.com\/2014\/04\/help-wantedassociate-reviewer\/",
        "display_url" : "madhatterreads.com\/2014\/04\/help-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461628218823286784",
    "text" : "Help Wanted~Associate Reviewer http:\/\/t.co\/kFfl4c3rnv via @madhatterreads",
    "id" : 461628218823286784,
    "created_at" : "2014-04-30 22:08:38 +0000",
    "user" : {
      "name" : "Because Reading \uD83D\uDE18",
      "screen_name" : "Limabean74",
      "protected" : false,
      "id_str" : "23750976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794646382590173185\/grqGfpQH_normal.jpg",
      "id" : 23750976,
      "verified" : false
    }
  },
  "id" : 462653831999152129,
  "created_at" : "2014-05-03 18:04:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blasphemy",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462653045843984384",
  "text" : "im using a multi-translation bible to hold bedroom door open (wind thru open windows slamming door closed) #blasphemy",
  "id" : 462653045843984384,
  "created_at" : "2014-05-03 18:00:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459525964666372096",
  "geo" : { },
  "id_str" : "462632569142771712",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia  i kissed a cow.. and I liked it.",
  "id" : 462632569142771712,
  "in_reply_to_status_id" : 459525964666372096,
  "created_at" : "2014-05-03 16:39:34 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458450693028728832",
  "geo" : { },
  "id_str" : "462632159740960768",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia again w the sheep.. poor sheep. baaaa!!",
  "id" : 462632159740960768,
  "in_reply_to_status_id" : 458450693028728832,
  "created_at" : "2014-05-03 16:37:56 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457511381562961920",
  "geo" : { },
  "id_str" : "462631820463325184",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia think of \"heaven\" as graded levels. like goes w\/ like. then no free will problem.",
  "id" : 462631820463325184,
  "in_reply_to_status_id" : 457511381562961920,
  "created_at" : "2014-05-03 16:36:35 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/yWUFjvyb0u",
      "expanded_url" : "http:\/\/wp.me\/p1pu8r-8Sc",
      "display_url" : "wp.me\/p1pu8r-8Sc"
    } ]
  },
  "geo" : { },
  "id_str" : "462407907452391424",
  "text" : "RT @adamrshields: Another Tired Ereaders Might be Bad Article http:\/\/t.co\/yWUFjvyb0u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/yWUFjvyb0u",
        "expanded_url" : "http:\/\/wp.me\/p1pu8r-8Sc",
        "display_url" : "wp.me\/p1pu8r-8Sc"
      } ]
    },
    "geo" : { },
    "id_str" : "462233875247149057",
    "text" : "Another Tired Ereaders Might be Bad Article http:\/\/t.co\/yWUFjvyb0u",
    "id" : 462233875247149057,
    "created_at" : "2014-05-02 14:15:18 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 462407907452391424,
  "created_at" : "2014-05-03 01:46:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Gt4uOmETHv",
      "expanded_url" : "http:\/\/goo.gl\/yfw6Ed",
      "display_url" : "goo.gl\/yfw6Ed"
    } ]
  },
  "geo" : { },
  "id_str" : "462406238446575616",
  "text" : "RT @KerriFar: Feathers of a Mourning Dove! ~ http:\/\/t.co\/Gt4uOmETHv ~ #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 56, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/Gt4uOmETHv",
        "expanded_url" : "http:\/\/goo.gl\/yfw6Ed",
        "display_url" : "goo.gl\/yfw6Ed"
      } ]
    },
    "geo" : { },
    "id_str" : "462399958931738624",
    "text" : "Feathers of a Mourning Dove! ~ http:\/\/t.co\/Gt4uOmETHv ~ #birds",
    "id" : 462399958931738624,
    "created_at" : "2014-05-03 01:15:15 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 462406238446575616,
  "created_at" : "2014-05-03 01:40:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Prine",
      "screen_name" : "randyprine",
      "indices" : [ 3, 14 ],
      "id_str" : "37990581",
      "id" : 37990581
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/randyprine\/status\/462069832137986049\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/B7Mn3oohku",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmmaD7OCAAEhUdy.jpg",
      "id_str" : "462069829009014785",
      "id" : 462069829009014785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmmaD7OCAAEhUdy.jpg",
      "sizes" : [ {
        "h" : 319,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/B7Mn3oohku"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462406095659888641",
  "text" : "RT @randyprine: This is what happens when addiction is treated as an illness not a crime. http:\/\/t.co\/B7Mn3oohku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randyprine\/status\/462069832137986049\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/B7Mn3oohku",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmmaD7OCAAEhUdy.jpg",
        "id_str" : "462069829009014785",
        "id" : 462069829009014785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmmaD7OCAAEhUdy.jpg",
        "sizes" : [ {
          "h" : 319,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 319,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 319,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/B7Mn3oohku"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462069832137986049",
    "text" : "This is what happens when addiction is treated as an illness not a crime. http:\/\/t.co\/B7Mn3oohku",
    "id" : 462069832137986049,
    "created_at" : "2014-05-02 03:23:27 +0000",
    "user" : {
      "name" : "Randy Prine",
      "screen_name" : "randyprine",
      "protected" : false,
      "id_str" : "37990581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797162319386120192\/uFycjy-b_normal.jpg",
      "id" : 37990581,
      "verified" : false
    }
  },
  "id" : 462406095659888641,
  "created_at" : "2014-05-03 01:39:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitch Albom",
      "screen_name" : "MitchAlbom",
      "indices" : [ 65, 76 ],
      "id_str" : "75066625",
      "id" : 75066625
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462310999803297792",
  "text" : "\"...and no soul remembered is ever really gone.\" &lt;3 Thank you @MitchAlbom",
  "id" : 462310999803297792,
  "created_at" : "2014-05-02 19:21:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "`Joshua",
      "screen_name" : "JoshuaTongol",
      "indices" : [ 3, 16 ],
      "id_str" : "353049578",
      "id" : 353049578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovetranscendsreligion",
      "indices" : [ 105, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/jok1wdQuyR",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Yl4B87LyXqQ",
      "display_url" : "youtube.com\/watch?v=Yl4B87\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "462296372918902784",
  "text" : "RT @JoshuaTongol: For those who missed it! New Video: \"Love TRANSCENDS Religion\" https:\/\/t.co\/jok1wdQuyR #lovetranscendsreligion #interfait\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lovetranscendsreligion",
        "indices" : [ 87, 110 ]
      }, {
        "text" : "interfaith",
        "indices" : [ 111, 122 ]
      }, {
        "text" : "unity",
        "indices" : [ 123, 129 ]
      }, {
        "text" : "tolerance",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/jok1wdQuyR",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Yl4B87LyXqQ",
        "display_url" : "youtube.com\/watch?v=Yl4B87\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "462293284082044931",
    "text" : "For those who missed it! New Video: \"Love TRANSCENDS Religion\" https:\/\/t.co\/jok1wdQuyR #lovetranscendsreligion #interfaith #unity #tolerance",
    "id" : 462293284082044931,
    "created_at" : "2014-05-02 18:11:22 +0000",
    "user" : {
      "name" : "`Joshua",
      "screen_name" : "JoshuaTongol",
      "protected" : false,
      "id_str" : "353049578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443510403192983553\/YGTApjCv_normal.jpeg",
      "id" : 353049578,
      "verified" : false
    }
  },
  "id" : 462296372918902784,
  "created_at" : "2014-05-02 18:23:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/w9e8Xv6AdK",
      "expanded_url" : "http:\/\/bit.ly\/SgUo5d",
      "display_url" : "bit.ly\/SgUo5d"
    } ]
  },
  "geo" : { },
  "id_str" : "462269038723620864",
  "text" : "RT @FreeRangeKids: What if we didn't try to teach kids ANYTHING in kindergarten?    http:\/\/t.co\/w9e8Xv6AdK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/w9e8Xv6AdK",
        "expanded_url" : "http:\/\/bit.ly\/SgUo5d",
        "display_url" : "bit.ly\/SgUo5d"
      } ]
    },
    "geo" : { },
    "id_str" : "462267357462036480",
    "text" : "What if we didn't try to teach kids ANYTHING in kindergarten?    http:\/\/t.co\/w9e8Xv6AdK",
    "id" : 462267357462036480,
    "created_at" : "2014-05-02 16:28:21 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 462269038723620864,
  "created_at" : "2014-05-02 16:35:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/gqAmeoDL1k",
      "expanded_url" : "http:\/\/wp.me\/p2Xrlp-1UfE",
      "display_url" : "wp.me\/p2Xrlp-1UfE"
    } ]
  },
  "geo" : { },
  "id_str" : "462262765239803904",
  "text" : "o-O &gt;&gt; Striking, Creepy Photos of Christian \"Purity Balls\": http:\/\/t.co\/gqAmeoDL1k",
  "id" : 462262765239803904,
  "created_at" : "2014-05-02 16:10:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Stewart",
      "screen_name" : "davestewart4444",
      "indices" : [ 3, 19 ],
      "id_str" : "1513709269",
      "id" : 1513709269
    }, {
      "name" : "David Coverdale",
      "screen_name" : "davidcoverdale",
      "indices" : [ 22, 37 ],
      "id_str" : "166665318",
      "id" : 166665318
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/davidcoverdale\/status\/462235652080164864\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/EeUwaMM9ID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmow4FsCMAAY7gN.jpg",
      "id_str" : "462235651916574720",
      "id" : 462235651916574720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmow4FsCMAAY7gN.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 955
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 955
      } ],
      "display_url" : "pic.twitter.com\/EeUwaMM9ID"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462237178509402114",
  "text" : "RT @davestewart4444: \u201C@davidcoverdale: Oops... http:\/\/t.co\/EeUwaMM9ID\u201D \n\nHate when that happens :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Coverdale",
        "screen_name" : "davidcoverdale",
        "indices" : [ 1, 16 ],
        "id_str" : "166665318",
        "id" : 166665318
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/davidcoverdale\/status\/462235652080164864\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/EeUwaMM9ID",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmow4FsCMAAY7gN.jpg",
        "id_str" : "462235651916574720",
        "id" : 462235651916574720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmow4FsCMAAY7gN.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 955
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 955
        } ],
        "display_url" : "pic.twitter.com\/EeUwaMM9ID"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462236969293348864",
    "text" : "\u201C@davidcoverdale: Oops... http:\/\/t.co\/EeUwaMM9ID\u201D \n\nHate when that happens :)",
    "id" : 462236969293348864,
    "created_at" : "2014-05-02 14:27:36 +0000",
    "user" : {
      "name" : "Dave Stewart",
      "screen_name" : "davestewart4444",
      "protected" : false,
      "id_str" : "1513709269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663624256346062848\/alijm_vO_normal.jpg",
      "id" : 1513709269,
      "verified" : false
    }
  },
  "id" : 462237178509402114,
  "created_at" : "2014-05-02 14:28:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462237074855563264",
  "text" : "\"stop planting flowers where they don't belong!\" DD to her villagers in animal crossing game..lol",
  "id" : 462237074855563264,
  "created_at" : "2014-05-02 14:28:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462235455225102336",
  "text" : "as im reading babble out loud \"careful.. you can catch the stupid.\" I love my DD..lol",
  "id" : 462235455225102336,
  "created_at" : "2014-05-02 14:21:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CG",
      "screen_name" : "acuriousgal1",
      "indices" : [ 3, 16 ],
      "id_str" : "2293715275",
      "id" : 2293715275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462210329762877440",
  "text" : "RT @acuriousgal1: Captured some lovely light the other morning, that, mixed with fog, makes a pretty picture.  Good Morning\uD83D\uDE4B http:\/\/t.co\/Ru\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/acuriousgal1\/status\/462208200037519360\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/RuKeqlo1Ui",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmoX56OCUAAg2Hn.jpg",
        "id_str" : "462208195407007744",
        "id" : 462208195407007744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmoX56OCUAAg2Hn.jpg",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RuKeqlo1Ui"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462208200037519360",
    "text" : "Captured some lovely light the other morning, that, mixed with fog, makes a pretty picture.  Good Morning\uD83D\uDE4B http:\/\/t.co\/RuKeqlo1Ui",
    "id" : 462208200037519360,
    "created_at" : "2014-05-02 12:33:16 +0000",
    "user" : {
      "name" : "CG",
      "screen_name" : "acuriousgal1",
      "protected" : false,
      "id_str" : "2293715275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676589567500095488\/jI9wzTBE_normal.jpg",
      "id" : 2293715275,
      "verified" : false
    }
  },
  "id" : 462210329762877440,
  "created_at" : "2014-05-02 12:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeterGray",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/w9e8Xv6AdK",
      "expanded_url" : "http:\/\/bit.ly\/SgUo5d",
      "display_url" : "bit.ly\/SgUo5d"
    } ]
  },
  "geo" : { },
  "id_str" : "462207534473154560",
  "text" : "RT @FreeRangeKids: It's possible kids learn MORE when they are instructed LESS.  Attn #PeterGray http:\/\/t.co\/w9e8Xv6AdK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PeterGray",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/w9e8Xv6AdK",
        "expanded_url" : "http:\/\/bit.ly\/SgUo5d",
        "display_url" : "bit.ly\/SgUo5d"
      } ]
    },
    "geo" : { },
    "id_str" : "462201961245577216",
    "text" : "It's possible kids learn MORE when they are instructed LESS.  Attn #PeterGray http:\/\/t.co\/w9e8Xv6AdK",
    "id" : 462201961245577216,
    "created_at" : "2014-05-02 12:08:29 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 462207534473154560,
  "created_at" : "2014-05-02 12:30:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wisdom Of  Words",
      "screen_name" : "wisdomofwords",
      "indices" : [ 3, 17 ],
      "id_str" : "87059006",
      "id" : 87059006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462206940584902657",
  "text" : "RT @wisdomofwords: Be where you are, otherwise you will miss your life: Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462189602955329536",
    "text" : "Be where you are, otherwise you will miss your life: Buddha",
    "id" : 462189602955329536,
    "created_at" : "2014-05-02 11:19:23 +0000",
    "user" : {
      "name" : "Wisdom Of  Words",
      "screen_name" : "wisdomofwords",
      "protected" : false,
      "id_str" : "87059006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699764089371934721\/KusExKGJ_normal.png",
      "id" : 87059006,
      "verified" : false
    }
  },
  "id" : 462206940584902657,
  "created_at" : "2014-05-02 12:28:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462205978503835648",
  "text" : "bleh. middle age hormones suck.",
  "id" : 462205978503835648,
  "created_at" : "2014-05-02 12:24:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Roy Accampo",
      "screen_name" : "DAccampoFamily",
      "indices" : [ 0, 15 ],
      "id_str" : "960687805",
      "id" : 960687805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "462191368270393345",
  "geo" : { },
  "id_str" : "462205588295147520",
  "in_reply_to_user_id" : 960687805,
  "text" : "@DAccampoFamily ahh.. its possible i did do that. many use the bible like a whip. not a fan of that.",
  "id" : 462205588295147520,
  "in_reply_to_status_id" : 462191368270393345,
  "created_at" : "2014-05-02 12:22:54 +0000",
  "in_reply_to_screen_name" : "DAccampoFamily",
  "in_reply_to_user_id_str" : "960687805",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461994192408170496",
  "text" : "i  found an inscribed book my 15 yo dad gave to his 21 yo brother for brothers bday. found pic of bro inside, too. he died at 22 yo.",
  "id" : 461994192408170496,
  "created_at" : "2014-05-01 22:22:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NaturalMind",
      "screen_name" : "naturalmind",
      "indices" : [ 3, 15 ],
      "id_str" : "23500066",
      "id" : 23500066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461878054089150464",
  "text" : "RT @naturalmind: The surest sign of spiritual progress is a total lack of concern about progress. - Ramesh Balsekar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461869811304525826",
    "text" : "The surest sign of spiritual progress is a total lack of concern about progress. - Ramesh Balsekar",
    "id" : 461869811304525826,
    "created_at" : "2014-05-01 14:08:38 +0000",
    "user" : {
      "name" : "NaturalMind",
      "screen_name" : "naturalmind",
      "protected" : false,
      "id_str" : "23500066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/328357234\/zendo4_normal.jpg",
      "id" : 23500066,
      "verified" : false
    }
  },
  "id" : 461878054089150464,
  "created_at" : "2014-05-01 14:41:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/Cfm3bIjDiN",
      "expanded_url" : "https:\/\/twitter.com\/UberFacts\/status\/461871934662508544",
      "display_url" : "twitter.com\/UberFacts\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "461877983461253120",
  "text" : "@Lluminous_ oops.. didnt reply right..lol. replying to this&gt;&gt; https:\/\/t.co\/Cfm3bIjDiN",
  "id" : 461877983461253120,
  "created_at" : "2014-05-01 14:41:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461876404888821761",
  "text" : "@Lluminous_ that almost sounds like fun :D",
  "id" : 461876404888821761,
  "created_at" : "2014-05-01 14:34:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Splashpals",
      "screen_name" : "Barbarystorm",
      "indices" : [ 3, 16 ],
      "id_str" : "551236136",
      "id" : 551236136
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Barbarystorm\/status\/461862260928151552\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/dOXd59fYFs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmjdRr9IQAIFlNv.jpg",
      "id_str" : "461862257732108290",
      "id" : 461862257732108290,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmjdRr9IQAIFlNv.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 889,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dOXd59fYFs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461870024190619648",
  "text" : "RT @Barbarystorm: Together. http:\/\/t.co\/dOXd59fYFs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Barbarystorm\/status\/461862260928151552\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/dOXd59fYFs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmjdRr9IQAIFlNv.jpg",
        "id_str" : "461862257732108290",
        "id" : 461862257732108290,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmjdRr9IQAIFlNv.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 889,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dOXd59fYFs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "461862260928151552",
    "text" : "Together. http:\/\/t.co\/dOXd59fYFs",
    "id" : 461862260928151552,
    "created_at" : "2014-05-01 13:38:38 +0000",
    "user" : {
      "name" : "Splashpals",
      "screen_name" : "Barbarystorm",
      "protected" : false,
      "id_str" : "551236136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755842839200673793\/Rs8eDLMF_normal.jpg",
      "id" : 551236136,
      "verified" : false
    }
  },
  "id" : 461870024190619648,
  "created_at" : "2014-05-01 14:09:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]