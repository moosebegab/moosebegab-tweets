Grailbird.data.tweets_2010_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "indices" : [ 3, 14 ],
      "id_str" : "30795207",
      "id" : 30795207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8508797568",
  "text" : "RT @AlphaMares: No act of kindness, no matter how small, is ever wasted. ~Aesop",
  "id" : 8508797568,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8508872050",
  "text" : "Cooking pasta to go with diced tomatoes.. Yum!!",
  "id" : 8508872050,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8510794262",
  "text" : "Ok, took some pepto.. Hope that calms my stomach..",
  "id" : 8510794262,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rusty Collins Smith",
      "screen_name" : "TheRustCat",
      "indices" : [ 0, 11 ],
      "id_str" : "69673823",
      "id" : 69673823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8511254488",
  "geo" : { },
  "id_str" : "8511895666",
  "in_reply_to_user_id" : 69673823,
  "text" : "@TheRustCat God bless you for caring for this baby. Sending you hugs and hope you get more time together.",
  "id" : 8511895666,
  "in_reply_to_status_id" : 8511254488,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "TheRustCat",
  "in_reply_to_user_id_str" : "69673823",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healing Inside",
      "screen_name" : "HealingInside",
      "indices" : [ 0, 14 ],
      "id_str" : "2176573952",
      "id" : 2176573952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8512771566",
  "text" : "@HealingInside woot woot!! Congrats - that's awesome!",
  "id" : 8512771566,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glowno Animal Asylum",
      "screen_name" : "AnimalAsylum",
      "indices" : [ 3, 16 ],
      "id_str" : "77779450",
      "id" : 77779450
    }, {
      "name" : "Evelina",
      "screen_name" : "waggytail2",
      "indices" : [ 18, 29 ],
      "id_str" : "3158905858",
      "id" : 3158905858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8512842043",
  "text" : "RT @AnimalAsylum: @waggytail2 It will be enough for about 3 days. We are grateful for this and will keep asking for help.",
  "id" : 8512842043,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8513409086",
  "text" : "Thinking I'm getting French toast for dinner : )",
  "id" : 8513409086,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8513879548",
  "geo" : { },
  "id_str" : "8514219280",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus dizzy! Lol",
  "id" : 8514219280,
  "in_reply_to_status_id" : 8513879548,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glowno Animal Asylum",
      "screen_name" : "AnimalAsylum",
      "indices" : [ 3, 16 ],
      "id_str" : "77779450",
      "id" : 77779450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8514307364",
  "text" : "RT @AnimalAsylum: Meet our dog friends: http:\/\/www.przytulisko.glowno.pl\/en\/psy\/index.html and some cats: http:\/\/www.przytulisko.glowno. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8513326685",
    "text" : "Meet our dog friends: http:\/\/www.przytulisko.glowno.pl\/en\/psy\/index.html and some cats: http:\/\/www.przytulisko.glowno.pl\/en\/koty\/index.html",
    "id" : 8513326685,
    "created_at" : "2010-02-01 20:54:12 +0000",
    "user" : {
      "name" : "Glowno Animal Asylum",
      "screen_name" : "AnimalAsylum",
      "protected" : false,
      "id_str" : "77779450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/439240674\/Rudzielec_normal.jpg",
      "id" : 77779450,
      "verified" : false
    }
  },
  "id" : 8514307364,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8514782117",
  "geo" : { },
  "id_str" : "8515127137",
  "in_reply_to_user_id" : 69126688,
  "text" : "@EducateBooks messages from your angels by Doreen Virtue",
  "id" : 8515127137,
  "in_reply_to_status_id" : 8514782117,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "DoTheMathBooks",
  "in_reply_to_user_id_str" : "69126688",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "indices" : [ 0, 14 ],
      "id_str" : "20640860",
      "id" : 20640860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8516285182",
  "geo" : { },
  "id_str" : "8516474004",
  "in_reply_to_user_id" : 20640860,
  "text" : "@homesteadwool Noodle is beautiful!",
  "id" : 8516474004,
  "in_reply_to_status_id" : 8516285182,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "homesteadwool",
  "in_reply_to_user_id_str" : "20640860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8516792860",
  "text" : "15 Crazy Ways People Make Money in Today\u2019s Economy: http:\/\/www.businesspundit.com\/15-crazy-ways-people-make-money-in-todays-economy\/",
  "id" : 8516792860,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8472766338",
  "text" : "RT @Ravish30: New In Pkg. Tupperware Ice Cream Sandwich Maker $20 value, $10.00 and incls. US Shipping! I got (cont) http:\/\/tl.gd\/6aqme",
  "id" : 8472766338,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8472982730",
  "text" : "RT @abandontheherd: Don't just tolerate stress, or assume it's inevitable, or worse - necessary! Read about our (cont) http:\/\/tl.gd\/6ar6h",
  "id" : 8472982730,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Umstattd",
      "screen_name" : "karenu",
      "indices" : [ 3, 10 ],
      "id_str" : "15877211",
      "id" : 15877211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8477282856",
  "text" : "RT @karenu: Thoughts To Ponder - Never miss an opportunity to make others happy, even if you have to leave them (cont) http:\/\/tl.gd\/6b54d",
  "id" : 8477282856,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coen",
      "screen_name" : "jerrycoen",
      "indices" : [ 13, 23 ],
      "id_str" : "99228713",
      "id" : 99228713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8477348309",
  "text" : "So true!! RT @jerrycoen: The only normal people are the ones you don't know very well. - Joe Ancis #quote",
  "id" : 8477348309,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8477542601",
  "geo" : { },
  "id_str" : "8477640748",
  "in_reply_to_user_id" : 75137401,
  "text" : "@ahkonlhamo Loved that one! Good story.",
  "id" : 8477640748,
  "in_reply_to_status_id" : 8477542601,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "JALpalyul",
  "in_reply_to_user_id_str" : "75137401",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8482218874",
  "text" : "RT @RevAnne1: EFT Affirm Today, I appreciate the health I enjoy, the love I feel, & the abundance I have. http:\/\/ThinkitBeitSeeit.com",
  "id" : 8482218874,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8492746361",
  "text" : "Your friends will steer you in the right direction today as me... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8492746361,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandeep",
      "screen_name" : "whylife",
      "indices" : [ 3, 11 ],
      "id_str" : "33431699",
      "id" : 33431699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8496352969",
  "text" : "RT @whylife: God enters by a private door into every individual.- Ralph Waldo Emerson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8429973661",
    "text" : "God enters by a private door into every individual.- Ralph Waldo Emerson",
    "id" : 8429973661,
    "created_at" : "2010-01-30 23:50:23 +0000",
    "user" : {
      "name" : "Mandeep",
      "screen_name" : "whylife",
      "protected" : false,
      "id_str" : "33431699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/147658553\/frontcover-why_normal.jpg",
      "id" : 33431699,
      "verified" : false
    }
  },
  "id" : 8496352969,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50 Best Tweets Ever \u2B50",
      "screen_name" : "DrJeffersnBoggs",
      "indices" : [ 3, 19 ],
      "id_str" : "15274836",
      "id" : 15274836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Quote",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8496418748",
  "text" : "RT @DrJeffersnBoggs: Staying angry with thoughtless people is like being mad at fire because it burns - Buddha  . #Quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Quote",
        "indices" : [ 93, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8487649790",
    "text" : "Staying angry with thoughtless people is like being mad at fire because it burns - Buddha  . #Quote",
    "id" : 8487649790,
    "created_at" : "2010-02-01 05:54:50 +0000",
    "user" : {
      "name" : "\u2B50 Best Tweets Ever \u2B50",
      "screen_name" : "DrJeffersnBoggs",
      "protected" : false,
      "id_str" : "15274836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549871819751051266\/qHOORH_h_normal.jpeg",
      "id" : 15274836,
      "verified" : false
    }
  },
  "id" : 8496418748,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8496454510",
  "text" : "RT @SpiritMaterial: I used to believe that something was wrong with me. The only thing wrong with me was that I believed there was somet ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8486755616",
    "text" : "I used to believe that something was wrong with me. The only thing wrong with me was that I believed there was something wrong with me.",
    "id" : 8486755616,
    "created_at" : "2010-02-01 05:23:24 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 8496454510,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8495681593",
  "geo" : { },
  "id_str" : "8496692283",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus I read the book. Trailers looked nothing like what I read...",
  "id" : 8496692283,
  "in_reply_to_status_id" : 8495681593,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8496739523",
  "text" : "G'Morn my Tweeties.. Enjoying coffee with hubs.",
  "id" : 8496739523,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8498163349",
  "text" : "RT @BeALegacy: Legacy News Updates Action Steps for Success #1 http:\/\/ow.ly\/16tfoZ",
  "id" : 8498163349,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8482661948",
  "geo" : { },
  "id_str" : "8498293343",
  "in_reply_to_user_id" : 75137401,
  "text" : "@ahkonlhamo just what hubs & I thought.. Wonder if they'll make sequel..",
  "id" : 8498293343,
  "in_reply_to_status_id" : 8482661948,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "JALpalyul",
  "in_reply_to_user_id_str" : "75137401",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "indices" : [ 3, 16 ],
      "id_str" : "22276232",
      "id" : 22276232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8498369643",
  "text" : "RT @successwalls: \"If you are clear about what you want, the world responds with clarity.\" \u2013Loretta Staples #quote",
  "id" : 8498369643,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Holland",
      "screen_name" : "jhollandmedium",
      "indices" : [ 3, 18 ],
      "id_str" : "62810990",
      "id" : 62810990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8498925010",
  "text" : "RT @jhollandmedium: Sometimes you have to remember WHO you were - to figure out WHO you want to be.",
  "id" : 8498925010,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Holland",
      "screen_name" : "jhollandmedium",
      "indices" : [ 3, 18 ],
      "id_str" : "62810990",
      "id" : 62810990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8498935048",
  "text" : "RT @jhollandmedium: Your spiritual gifts are like a rose unfolding - you cannot force the bloom.",
  "id" : 8498935048,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 24, 36 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Angela Petersen",
      "screen_name" : "angiepetersen33",
      "indices" : [ 41, 57 ],
      "id_str" : "50325523",
      "id" : 50325523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8499062488",
  "text" : "Always move forward! RT @brandonrofl: RT @angiepetersen33 Finish each day and be done with it. You have done what (cont) http:\/\/tl.gd\/6ed4l",
  "id" : 8499062488,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8499544376",
  "geo" : { },
  "id_str" : "8499674033",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus hmm.. so much to choose from..lol.. I'll say eating.",
  "id" : 8499674033,
  "in_reply_to_status_id" : 8499544376,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8499524924",
  "geo" : { },
  "id_str" : "8499737066",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 mm.. Fresh, warm bread! : )",
  "id" : 8499737066,
  "in_reply_to_status_id" : 8499524924,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8500473292",
  "geo" : { },
  "id_str" : "8500603011",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus I don't have to be in the car to do that.. Lol",
  "id" : 8500603011,
  "in_reply_to_status_id" : 8500473292,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8501417962",
  "geo" : { },
  "id_str" : "8503047153",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 try a saline nasal spray.. Plain not medicated (they're tricky)",
  "id" : 8503047153,
  "in_reply_to_status_id" : 8501417962,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8502164162",
  "geo" : { },
  "id_str" : "8503171654",
  "in_reply_to_user_id" : 75137401,
  "text" : "@ahkonlhamo so good to hear! : )",
  "id" : 8503171654,
  "in_reply_to_status_id" : 8502164162,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "JALpalyul",
  "in_reply_to_user_id_str" : "75137401",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "HoneyTrousers",
      "screen_name" : "DamaraSimmons",
      "indices" : [ 20, 34 ],
      "id_str" : "23776124",
      "id" : 23776124
    }, {
      "name" : "Kiera",
      "screen_name" : "AllAbtDogs",
      "indices" : [ 38, 49 ],
      "id_str" : "80217183",
      "id" : 80217183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8503485975",
  "text" : "RT @brandonrofl: RT @DamaraSimmons RT @AllAbtDogs: All animals except man know that the ultimate of life is to (cont) http:\/\/tl.gd\/6f5k6",
  "id" : 8503485975,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8504948080",
  "text" : "Thought sky was falling down.. We had jet fighters passing overhead! Yowza.. They are loud!!",
  "id" : 8504948080,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8505043498",
  "text" : "Took my pill on time, had breakfast but my head kinda funky.. Prob sinuses.. Is making tummy lil queesy",
  "id" : 8505043498,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8506545542",
  "geo" : { },
  "id_str" : "8507319024",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd it's the only reason I survived my teens! : )",
  "id" : 8507319024,
  "in_reply_to_status_id" : 8506545542,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8507482498",
  "text" : "So I'm not a big Dave Mathews fan but I love the song he sung at Grammys so now it's on my Touch..You & Me",
  "id" : 8507482498,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa kay",
      "screen_name" : "nymedium",
      "indices" : [ 3, 12 ],
      "id_str" : "32799607",
      "id" : 32799607
    }, {
      "name" : "Ann Tran",
      "screen_name" : "TrendyDC",
      "indices" : [ 17, 26 ],
      "id_str" : "188573761",
      "id" : 188573761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8508259073",
  "text" : "RT @nymedium: RT @TrendyDC: He who controls others may be powerful, but he who has mastered himself is mightier (cont) http:\/\/tl.gd\/6fp87",
  "id" : 8508259073,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8508342907",
  "text" : "RT @kpcmonk: Please follow @ahkonlhamo, you may find happiness there.  I have!  She is wise, funny and loving. (cont) http:\/\/tl.gd\/6fph5",
  "id" : 8508342907,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pema James",
      "screen_name" : "vacantsolace",
      "indices" : [ 3, 16 ],
      "id_str" : "15159771",
      "id" : 15159771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8508647844",
  "text" : "RT @vacantsolace: \"The Greatest enemy of knowledge is not ignorance, but the illusion of knowledge\"- Stephen Hawking",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8507594534",
    "text" : "\"The Greatest enemy of knowledge is not ignorance, but the illusion of knowledge\"- Stephen Hawking",
    "id" : 8507594534,
    "created_at" : "2010-02-01 17:59:46 +0000",
    "user" : {
      "name" : "Pema James",
      "screen_name" : "vacantsolace",
      "protected" : false,
      "id_str" : "15159771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/55613755\/2269139_icon_normal.jpg",
      "id" : 15159771,
      "verified" : false
    }
  },
  "id" : 8508647844,
  "created_at" : "2010-02-01 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 0, 11 ],
      "id_str" : "85670618",
      "id" : 85670618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8463140729",
  "in_reply_to_user_id" : 85670618,
  "text" : "@tweeterena having awful time setting up lists. Created list but can't add names, seems to lock up.. And lists not showing on my pc twitter",
  "id" : 8463140729,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tweeterena",
  "in_reply_to_user_id_str" : "85670618",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martina Clements",
      "screen_name" : "martisunshine",
      "indices" : [ 20, 34 ],
      "id_str" : "19203158",
      "id" : 19203158
    }, {
      "name" : "Shelly Skoog-Smith",
      "screen_name" : "LetsHelpAnimals",
      "indices" : [ 38, 54 ],
      "id_str" : "46791708",
      "id" : 46791708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8465844062",
  "text" : "RT @ahkonlhamo: RT: @martisunshine RT @LetsHelpAnimals TAKE ACTION sign Stop Wolf-Killing Bill in Utah: (cont) http:\/\/tl.gd\/6ab9c",
  "id" : 8465844062,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8465877264",
  "text" : "RT @DeepakChopra: Please don't sabotage your greatness with doubt. If in doubt, then doubt the doubter.",
  "id" : 8465877264,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 13, 28 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8465909273",
  "text" : "So true!! RT @abandontheherd: The less you fight with life the happier you'll be.",
  "id" : 8465909273,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8464904825",
  "geo" : { },
  "id_str" : "8465975160",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd exactly.. People tend to view surrender as bad which delays their \"awakening\"",
  "id" : 8465975160,
  "in_reply_to_status_id" : 8464904825,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8465982661",
  "text" : "RT @abandontheherd: \"Surrender\" does not mean weakness or helplessness. True surrender takes strength, courage and trust. Letting go = unity",
  "id" : 8465982661,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetHoneycutt",
      "screen_name" : "GetHoneycutt",
      "indices" : [ 7, 20 ],
      "id_str" : "18959152",
      "id" : 18959152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8466568718",
  "text" : "LOL RT @gethoneycutt: GetHoneycutt Fit Tip: My idea for exercise is a good, brisk sit. Phyllis Diller #quotes",
  "id" : 8466568718,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole",
      "screen_name" : "obnoxiousacorns",
      "indices" : [ 0, 16 ],
      "id_str" : "24719145",
      "id" : 24719145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8466320650",
  "geo" : { },
  "id_str" : "8466601025",
  "in_reply_to_user_id" : 24719145,
  "text" : "@obnoxiousacorns hehe that would be funny!",
  "id" : 8466601025,
  "in_reply_to_status_id" : 8466320650,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "obnoxiousacorns",
  "in_reply_to_user_id_str" : "24719145",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 14, 23 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omgfacts",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8467013162",
  "text" : "How sad... RT @OMGFacts: Each day, up to 150 species of life become extinct. #omgfacts",
  "id" : 8467013162,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8468046748",
  "text" : "Think hubs is trying to kill me. Fed me sausage & peppers for dinner. Tummy is not happy.",
  "id" : 8468046748,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glowno Animal Asylum",
      "screen_name" : "AnimalAsylum",
      "indices" : [ 3, 16 ],
      "id_str" : "77779450",
      "id" : 77779450
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ANIMALS",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "DONATE",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8468232957",
  "text" : "RT @AnimalAsylum PLZ! Visit http:\/\/bit.ly\/cguDQ7 NEED FOOD 4 #ANIMALS scroll down the page, you will find our paypal!#DONATE",
  "id" : 8468232957,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martina Clements",
      "screen_name" : "martisunshine",
      "indices" : [ 4, 18 ],
      "id_str" : "19203158",
      "id" : 19203158
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyFursday",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8468859921",
  "text" : "RT: @martisunshine Ginger @ Harrison County Dog Pound has been there 2 long & needs 2badopted\/rescued now #HappyFursday http:\/\/bit.ly\/aNglSq",
  "id" : 8468859921,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glowno Animal Asylum",
      "screen_name" : "AnimalAsylum",
      "indices" : [ 3, 16 ],
      "id_str" : "77779450",
      "id" : 77779450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8468993702",
  "text" : "RT @AnimalAsylum: Another call for help from us...Because of extremely low temperatures we ran out of everything, (cont) http:\/\/tl.gd\/6ahkd",
  "id" : 8468993702,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8469187847",
  "text" : "RT @twitingly: Knowledge is knowing a tomato is a fruit; Wisdom is not putting it in a fruit salad.",
  "id" : 8469187847,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Humane Cozumel",
      "screen_name" : "HumaneCozumel",
      "indices" : [ 3, 17 ],
      "id_str" : "85136920",
      "id" : 85136920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8469830020",
  "text" : "RT @HumaneCozumel: Out of heartworm med & need sponsors 2 treat Cuco, Nena & Puki can u help w immiticide (cont) http:\/\/tl.gd\/6ajff",
  "id" : 8469830020,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole",
      "screen_name" : "obnoxiousacorns",
      "indices" : [ 0, 16 ],
      "id_str" : "24719145",
      "id" : 24719145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8470694984",
  "geo" : { },
  "id_str" : "8470895722",
  "in_reply_to_user_id" : 24719145,
  "text" : "@obnoxiousacorns really?",
  "id" : 8470895722,
  "in_reply_to_status_id" : 8470694984,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "obnoxiousacorns",
  "in_reply_to_user_id_str" : "24719145",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole",
      "screen_name" : "obnoxiousacorns",
      "indices" : [ 0, 16 ],
      "id_str" : "24719145",
      "id" : 24719145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8470931738",
  "geo" : { },
  "id_str" : "8471073923",
  "in_reply_to_user_id" : 24719145,
  "text" : "@obnoxiousacorns hehe.. Well our DD name is Sojourn so we like different. We didn't get gender until she was pulled out.. Wldnt cooperate",
  "id" : 8471073923,
  "in_reply_to_status_id" : 8470931738,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "obnoxiousacorns",
  "in_reply_to_user_id_str" : "24719145",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 0, 12 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8470894257",
  "geo" : { },
  "id_str" : "8471121617",
  "in_reply_to_user_id" : 18694547,
  "text" : "@brandonrofl good one.. Might have to steal it! : )",
  "id" : 8471121617,
  "in_reply_to_status_id" : 8470894257,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8431371814",
  "text" : "watching \"Taken\" with Liam Neeson.. action-packed!",
  "id" : 8431371814,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "OTTAWA REALTOR\u00AE",
      "screen_name" : "AtifMirzaRemax",
      "indices" : [ 20, 35 ],
      "id_str" : "60449418",
      "id" : 60449418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "Atifremax",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8431395978",
  "text" : "RT @brandonrofl: RT @AtifMirzaRemax Never discourage anyone...who continually makes progress, no matter how slow. -Plato #quote #Atifremax",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OTTAWA REALTOR\u00AE",
        "screen_name" : "AtifMirzaRemax",
        "indices" : [ 3, 18 ],
        "id_str" : "60449418",
        "id" : 60449418
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 104, 110 ]
      }, {
        "text" : "Atifremax",
        "indices" : [ 111, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8431176620",
    "text" : "RT @AtifMirzaRemax Never discourage anyone...who continually makes progress, no matter how slow. -Plato #quote #Atifremax",
    "id" : 8431176620,
    "created_at" : "2010-01-31 00:28:02 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8431395978,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Illich",
      "screen_name" : "puffclean",
      "indices" : [ 20, 30 ],
      "id_str" : "53717298",
      "id" : 53717298
    }, {
      "name" : "Only4Humor",
      "screen_name" : "vtwit4u",
      "indices" : [ 34, 42 ],
      "id_str" : "92873835",
      "id" : 92873835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8433149486",
  "text" : "RT @ahkonlhamo: RT: @puffclean RT @vtwit4u Why do Americans choose from just two people to run for president and 50 for Miss America? (H ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Illich",
        "screen_name" : "puffclean",
        "indices" : [ 4, 14 ],
        "id_str" : "53717298",
        "id" : 53717298
      }, {
        "name" : "Only4Humor",
        "screen_name" : "vtwit4u",
        "indices" : [ 18, 26 ],
        "id_str" : "92873835",
        "id" : 92873835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8432772245",
    "text" : "RT: @puffclean RT @vtwit4u Why do Americans choose from just two people to run for president and 50 for Miss America? (Hummm!)",
    "id" : 8432772245,
    "created_at" : "2010-01-31 01:16:31 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 8433149486,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Banana",
      "screen_name" : "aniyeshi",
      "indices" : [ 20, 29 ],
      "id_str" : "53557868",
      "id" : 53557868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8433221024",
  "text" : "RT @ahkonlhamo: RT: @aniyeshi Help my friend reach 1,500 followers...she is amazing! Come on, help her out! @ahkonlhamo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lisa Banana",
        "screen_name" : "aniyeshi",
        "indices" : [ 4, 13 ],
        "id_str" : "53557868",
        "id" : 53557868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8431922302",
    "text" : "RT: @aniyeshi Help my friend reach 1,500 followers...she is amazing! Come on, help her out! @ahkonlhamo",
    "id" : 8431922302,
    "created_at" : "2010-01-31 00:51:05 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 8433221024,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8433278111",
  "text" : "my aura's a little off now.. so much violence. I still love Liam, though.",
  "id" : 8433278111,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "indices" : [ 0, 15 ],
      "id_str" : "48001363",
      "id" : 48001363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8434755581",
  "geo" : { },
  "id_str" : "8435212116",
  "in_reply_to_user_id" : 48001363,
  "text" : "@hippopotatomus how cute! : )",
  "id" : 8435212116,
  "in_reply_to_status_id" : 8434755581,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "hippopotatomus",
  "in_reply_to_user_id_str" : "48001363",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8435241693",
  "text" : "RT @BigBookofYou: Love is the only reality~Whn this truth takes root in yr heart, you'll not be tempted 2 waste so much time on trivialities",
  "id" : 8435241693,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amazing quotes",
      "screen_name" : "QuotesToSmile",
      "indices" : [ 3, 17 ],
      "id_str" : "488280964",
      "id" : 488280964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 94, 101 ]
    }, {
      "text" : "QTS",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8435911034",
  "text" : "RT @QuotesToSmile: \u00A8The most destructive element in the human mind is fear.\u00A8-Dorothy Thompson #quotes #QTS",
  "id" : 8435911034,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amazing quotes",
      "screen_name" : "QuotesToSmile",
      "indices" : [ 3, 17 ],
      "id_str" : "488280964",
      "id" : 488280964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 103, 110 ]
    }, {
      "text" : "QTS",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8437521773",
  "text" : "RT @QuotesToSmile: \u00A8I'm not afraid of storms, for I'm learning how to sail my ship.\u00A8-Louisa May Alcott #quotes #QTS",
  "id" : 8437521773,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8447181378",
  "text" : "If someone appears to be overly critical today, it may be a re... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8447181378,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Nool Music",
      "screen_name" : "noolmusic",
      "indices" : [ 20, 30 ],
      "id_str" : "45894634",
      "id" : 45894634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8453741806",
  "text" : "RT @brandonrofl: RT @noolmusic RT @Hyperspecialbd You teach best what you most need to learn. Richard Bach #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nool Music",
        "screen_name" : "noolmusic",
        "indices" : [ 3, 13 ],
        "id_str" : "45894634",
        "id" : 45894634
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8450704454",
    "text" : "RT @noolmusic RT @Hyperspecialbd You teach best what you most need to learn. Richard Bach #quote",
    "id" : 8450704454,
    "created_at" : "2010-01-31 12:34:07 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8453741806,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "T.PRO.MIX",
      "screen_name" : "TPROMIX",
      "indices" : [ 20, 28 ],
      "id_str" : "23685927",
      "id" : 23685927
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8453957602",
  "text" : "RT @brandonrofl: RT @tpromix \"u will not be punished FOR your anger; you will be punished... BY your anger\" ~Buddha #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "T.PRO.MIX",
        "screen_name" : "TPROMIX",
        "indices" : [ 3, 11 ],
        "id_str" : "23685927",
        "id" : 23685927
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8444313130",
    "text" : "RT @tpromix \"u will not be punished FOR your anger; you will be punished... BY your anger\" ~Buddha #quote",
    "id" : 8444313130,
    "created_at" : "2010-01-31 07:22:20 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8453957602,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8454428024",
  "text" : "RT @DrRus: Getting closer! I'm at 1998 followers! Will I make the 2000 mark today!?",
  "id" : 8454428024,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8454644430",
  "text" : "I'm grateful for Twitter & Facebook. Have met great people who inspire me, make me smile. Thank you!! : )",
  "id" : 8454644430,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8455087670",
  "text" : "What do I really think of this world? Http:\/\/www.abfabgab.com (my blog)",
  "id" : 8455087670,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8455132448",
  "text" : "Me n hubs enjoy lazy Sunday morn w\/our coffee... Life is good.",
  "id" : 8455132448,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8454937604",
  "geo" : { },
  "id_str" : "8455171466",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus Congrats! : )",
  "id" : 8455171466,
  "in_reply_to_status_id" : 8454937604,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prayer",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "healing",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "prayer",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8455490763",
  "text" : "RT @ahkonlhamo: Request #prayer #healing for Bella with chronic encephelitis and inflamation. The cold worsens it, and we need #prayer.",
  "id" : 8455490763,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8457790661",
  "text" : "RT @CandyTX: Free on Kindle: Deadlock by James Scott Bell  http:\/\/bit.ly\/bpJD8p (Christan legal thriller)",
  "id" : 8457790661,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8457808691",
  "text" : "RT @CandyTX: Free on Kindle: Sins of the Fathers by James Scott Bell (Christian Fiction, but looks pretty good)  http:\/\/bit.ly\/9eK2Dl",
  "id" : 8457808691,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hope",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8457846373",
  "text" : "RT @DHHypno: Your ReTweet could mean the world to someone. Creating new #hope in their life. Be Kind ReTweet the inportant stuff",
  "id" : 8457846373,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8458388971",
  "text" : "@DHHypno Thanks for the RT! : )",
  "id" : 8458388971,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8458427361",
  "text" : "@DHHypno YVW & Thanks for follow. Hope you like my tweets. ; )",
  "id" : 8458427361,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppConnect",
      "screen_name" : "appconn",
      "indices" : [ 3, 11 ],
      "id_str" : "83124469",
      "id" : 83124469
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppConnect",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8458537289",
  "text" : "RT @appconn: Hot New App on #AppConnect - Business Classics (Business) http:\/\/bit.ly\/ai0qQV",
  "id" : 8458537289,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 0, 12 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8458330137",
  "geo" : { },
  "id_str" : "8458575029",
  "in_reply_to_user_id" : 18694547,
  "text" : "@brandonrofl I feel so special! ; ) Thanks",
  "id" : 8458575029,
  "in_reply_to_status_id" : 8458330137,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8459524999",
  "geo" : { },
  "id_str" : "8459674508",
  "in_reply_to_user_id" : 75137401,
  "text" : "@ahkonlhamo poor, sweet thing.. Our Aussie will think she's been bad and hides under couch..",
  "id" : 8459674508,
  "in_reply_to_status_id" : 8459524999,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "JALpalyul",
  "in_reply_to_user_id_str" : "75137401",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Happysoul (\u25D5\u203F\u25D5)",
      "screen_name" : "Happysoul",
      "indices" : [ 3, 13 ],
      "id_str" : "6456162",
      "id" : 6456162
    }, {
      "name" : "PhotoTownship",
      "screen_name" : "phototownship",
      "indices" : [ 72, 86 ],
      "id_str" : "68741115",
      "id" : 68741115
    }, {
      "name" : "Massimo Lombardo",
      "screen_name" : "Mlomb",
      "indices" : [ 90, 96 ],
      "id_str" : "455059002",
      "id" : 455059002
    }, {
      "name" : "Cindy H",
      "screen_name" : "cindyvriend",
      "indices" : [ 97, 109 ],
      "id_str" : "51678226",
      "id" : 51678226
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Amazing",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8459863935",
  "text" : "RT @Happysoul: Nature's conception: Gates of Hell Collection (Pics) via @phototownship RT @mlomb @cindyvriend http:\/\/bit.ly\/ceHbP1 #Amazing",
  "id" : 8459863935,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8459752420",
  "geo" : { },
  "id_str" : "8460086219",
  "in_reply_to_user_id" : 75137401,
  "text" : "@ahkonlhamo I believe animals understand intricate emotions. She is treated the same as our daughter. : )",
  "id" : 8460086219,
  "in_reply_to_status_id" : 8459752420,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "JALpalyul",
  "in_reply_to_user_id_str" : "75137401",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Beau Bockman",
      "screen_name" : "BeauBock",
      "indices" : [ 15, 24 ],
      "id_str" : "431979960",
      "id" : 431979960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8460250347",
  "text" : "RT @BestAt: RT @BeauBock: I've had enough partying for one weekend. My \"check liver\" light just came on.",
  "id" : 8460250347,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coen",
      "screen_name" : "jerrycoen",
      "indices" : [ 3, 13 ],
      "id_str" : "99228713",
      "id" : 99228713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8461872430",
  "text" : "RT @jerrycoen: If you can't get rid of the skeleton in your closet, you'd best teach it to dance. - George Bernard Shaw #quote",
  "id" : 8461872430,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8461895596",
  "text" : "RT @ahkonlhamo: Even if through sickness or death we may lose the beloved, we ourselves are better for it. As (cont) http:\/\/tl.gd\/6a2gr",
  "id" : 8461895596,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freedom Parenting",
      "screen_name" : "FreedomParentng",
      "indices" : [ 3, 19 ],
      "id_str" : "93416715",
      "id" : 93416715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8463022715",
  "text" : "RT @FreedomParentng: \"The opposite of bravery is not cowardice but conformity.\"-Dr. Robert Anthony",
  "id" : 8463022715,
  "created_at" : "2010-01-31 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8413412857",
  "text" : "Getting the kid some new clothes today.. Complaining her current wardrobe is too \"happy\".. Go figure..lol",
  "id" : 8413412857,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trustGod",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8413870636",
  "text" : "RT @SheilaWalsh: With everything you like about yourself and all the dark places you hide, you are absolutely loved by God #trustGod",
  "id" : 8413870636,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anita g. wheeler",
      "screen_name" : "anitagwheeler",
      "indices" : [ 3, 17 ],
      "id_str" : "28475053",
      "id" : 28475053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8413883693",
  "text" : "RT @anitagwheeler: Did you know that the number of people taking anti-depressants has doubled in the last decade?? (cont) http:\/\/tl.gd\/63q2g",
  "id" : 8413883693,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Eric Hegedus",
      "screen_name" : "HegedusEricC",
      "indices" : [ 20, 33 ],
      "id_str" : "1908153631",
      "id" : 1908153631
    }, {
      "name" : "Leslie Blanchard",
      "screen_name" : "1txsage1957",
      "indices" : [ 37, 49 ],
      "id_str" : "19000765",
      "id" : 19000765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8414028430",
  "text" : "RT @brandonrofl: RT @HegedusEricC RT @1txsage1957: \"Heterosexuality isn't normal, it's just common.\" Dor (cont) http:\/\/tl.gd\/63qsj",
  "id" : 8414028430,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Weekly Leader",
      "screen_name" : "WeeklyLeader",
      "indices" : [ 3, 16 ],
      "id_str" : "15941683",
      "id" : 15941683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8424999146",
  "text" : "RT @WeeklyLeader: http:\/\/backupify.com is backing up my tweets. They support Flickr, Basecamp, Google Docs, and more.  Free if you signu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.backupify.com\/\" rel=\"nofollow\"\u003EBackupify\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8424889778",
    "text" : "http:\/\/backupify.com is backing up my tweets. They support Flickr, Basecamp, Google Docs, and more.  Free if you signup by Jan 31st",
    "id" : 8424889778,
    "created_at" : "2010-01-30 21:02:12 +0000",
    "user" : {
      "name" : "Weekly Leader",
      "screen_name" : "WeeklyLeader",
      "protected" : false,
      "id_str" : "15941683",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609762936\/Weekly-Leader-logo-white-fbjfk_normal.jpg",
      "id" : 15941683,
      "verified" : false
    }
  },
  "id" : 8424999146,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coen",
      "screen_name" : "jerrycoen",
      "indices" : [ 3, 13 ],
      "id_str" : "99228713",
      "id" : 99228713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8425069131",
  "text" : "RT @jerrycoen: Frisbeetarianism: The belief that when you die, your soul goes up on the roof and gets stuck. #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 94, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8423496890",
    "text" : "Frisbeetarianism: The belief that when you die, your soul goes up on the roof and gets stuck. #quote",
    "id" : 8423496890,
    "created_at" : "2010-01-30 20:13:28 +0000",
    "user" : {
      "name" : "Jerry Coen",
      "screen_name" : "jerrycoen",
      "protected" : false,
      "id_str" : "99228713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591380032\/461724_my_brother_normal.jpg",
      "id" : 99228713,
      "verified" : false
    }
  },
  "id" : 8425069131,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8425241903",
  "text" : "RT @brandonrofl: \"It doesn't matter where you are at right now, the only thing that matters is where you choose to go from there.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8419493585",
    "text" : "\"It doesn't matter where you are at right now, the only thing that matters is where you choose to go from there.\"",
    "id" : 8419493585,
    "created_at" : "2010-01-30 18:02:42 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8425241903,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Miss Creant",
      "screen_name" : "Trick_or_tweet",
      "indices" : [ 15, 30 ],
      "id_str" : "26061291",
      "id" : 26061291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8425369073",
  "text" : "RT @BestAt: RT @Trick_or_tweet: I'm stuck. Seems I may have picked the wrong day for a little naked, outdoor pole dancing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Miss Creant",
        "screen_name" : "Trick_or_tweet",
        "indices" : [ 3, 18 ],
        "id_str" : "26061291",
        "id" : 26061291
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8417772217",
    "text" : "RT @Trick_or_tweet: I'm stuck. Seems I may have picked the wrong day for a little naked, outdoor pole dancing.",
    "id" : 8417772217,
    "created_at" : "2010-01-30 17:09:13 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 8425369073,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8425415315",
  "text" : "RT @kimduess: Reduce body toxins by cleansing liver. Juice a whole lemon, pour in 8 ounce of water and drink - do every morning - Dr. Mi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8417544816",
    "text" : "Reduce body toxins by cleansing liver. Juice a whole lemon, pour in 8 ounce of water and drink - do every morning - Dr. Michael Galitzer",
    "id" : 8417544816,
    "created_at" : "2010-01-30 17:02:11 +0000",
    "user" : {
      "name" : "You Be Healthy",
      "screen_name" : "you_be_healthy",
      "protected" : false,
      "id_str" : "37557785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459760129\/kim-190-fix-2_3__normal.jpg",
      "id" : 37557785,
      "verified" : false
    }
  },
  "id" : 8425415315,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8426725406",
  "text" : "Our dear Aussie seeks mama's protection when daddy plays blood bowl on xbox... Lol",
  "id" : 8426725406,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bestscents",
      "screen_name" : "MontagCandleCo",
      "indices" : [ 3, 18 ],
      "id_str" : "63568411",
      "id" : 63568411
    }, {
      "name" : "mafercita_26",
      "screen_name" : "OHmommy",
      "indices" : [ 88, 96 ],
      "id_str" : "2561486744",
      "id" : 2561486744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8426821860",
  "text" : "RT @MontagCandleCo: I love twitter.  The DMs. The links. The advice.  Gah... love. \/via @OHmommy &gt; ooh, me too :)",
  "id" : 8426821860,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8426888478",
  "text" : "RT @ahkonlhamo: To save the life of or bring comfort to one sentient being is so much better than to love to hear  (cont) http:\/\/tl.gd\/64sat",
  "id" : 8426888478,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8426902088",
  "text" : "RT @taraburner: \"If you want things to be different, perhaps the answer is to become different yourself.\"-Norman Vincent Peale",
  "id" : 8426902088,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anita g. wheeler",
      "screen_name" : "anitagwheeler",
      "indices" : [ 18, 32 ],
      "id_str" : "28475053",
      "id" : 28475053
    }, {
      "name" : "Burke Walker",
      "screen_name" : "iSalesMax",
      "indices" : [ 37, 47 ],
      "id_str" : "58581687",
      "id" : 58581687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8427840267",
  "text" : "My fave quote! RT @anitagwheeler: RT @iSalesMax: \u201DNo act of kindness, no matter how small, is ever wasted.\u201D Aesop",
  "id" : 8427840267,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8428363651",
  "text" : "Why can't they offer an Internet plan for iPod touch? I take my touch everywhere.. Don't have cell phone.",
  "id" : 8428363651,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8428717626",
  "text" : "RT @brandonrofl: I'm so close to 16,000 followers. Help me out? :D",
  "id" : 8428717626,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa kay",
      "screen_name" : "nymedium",
      "indices" : [ 3, 12 ],
      "id_str" : "32799607",
      "id" : 32799607
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Intuition",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8429034783",
  "text" : "RT @nymedium: The idea that comes to you out of nowhere, is the one that is going somewhere. #Intuition",
  "id" : 8429034783,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8390226483",
  "geo" : { },
  "id_str" : "8390475642",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 which movie? It's hubs night out.. Racing (model cars)",
  "id" : 8390475642,
  "in_reply_to_status_id" : 8390226483,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omgfacts",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8390489879",
  "text" : "RT @OMGFacts: The Yo-Yo originated as a weapon in the Philippine Islands during the sixteenth century. #omgfacts",
  "id" : 8390489879,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8390559441",
  "text" : "This fly in the lampshade is driving me crazy.. Argh!!",
  "id" : 8390559441,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8390546440",
  "geo" : { },
  "id_str" : "8390609909",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 oh sounds good, I like Bruce",
  "id" : 8390609909,
  "in_reply_to_status_id" : 8390546440,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8390632966",
  "text" : "RT @twitingly: All great truths begin as blasphemies. George Bernard Shaw",
  "id" : 8390632966,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8390674525",
  "text" : "Almost time for The Office (missed 3 days!!) then a bath! : )",
  "id" : 8390674525,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8391471652",
  "geo" : { },
  "id_str" : "8391530731",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX LOL",
  "id" : 8391530731,
  "in_reply_to_status_id" : 8391471652,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TonyRush \uF8FF",
      "screen_name" : "TonyRush",
      "indices" : [ 3, 12 ],
      "id_str" : "8906922",
      "id" : 8906922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8393801156",
  "text" : "RT @tonyrush: Worry is the same as praying for what you don't want.",
  "id" : 8393801156,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8393812397",
  "text" : "RT @abandontheherd: Hug a tree!!!!! Take a photo of a tree each day! Here is this month's: http:\/\/gallery.me.com\/isydney#100186",
  "id" : 8393812397,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen at Play",
      "screen_name" : "zenatplay",
      "indices" : [ 3, 13 ],
      "id_str" : "15616966",
      "id" : 15616966
    }, {
      "name" : "Tara",
      "screen_name" : "Aussiewaffler",
      "indices" : [ 15, 29 ],
      "id_str" : "21553277",
      "id" : 21553277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8395885836",
  "text" : "RT @zenatplay: @Aussiewaffler Yes, elephant sexuality is awkward for everyone involved: http:\/\/bit.ly\/cTwUBn",
  "id" : 8395885836,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8396100649",
  "text" : "RT @twitingly: Believe those who are seeking the truth. Doubt those who find it. \u2014Andr\u00E9 Gide",
  "id" : 8396100649,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8396150612",
  "text" : "RT @abandontheherd: Send free food to abused and neglected animals just by clicking the purple box on this website! http:\/\/bit.ly\/EU0p",
  "id" : 8396150612,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8406420142",
  "text" : "Your 6th House of Daily Routine is lit up today from the playf... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8406420142,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coen",
      "screen_name" : "jerrycoen",
      "indices" : [ 3, 13 ],
      "id_str" : "99228713",
      "id" : 99228713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8412264191",
  "text" : "RT @jerrycoen: \"The universe is not only queerer than we suppose, it is queerer than we can suppose.\" - J. B. S. Haldane #quote",
  "id" : 8412264191,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Coen",
      "screen_name" : "jerrycoen",
      "indices" : [ 3, 13 ],
      "id_str" : "99228713",
      "id" : 99228713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8412284270",
  "text" : "RT @jerrycoen: i'm a non-conformist too! -Faisal N. Jawdat #quote",
  "id" : 8412284270,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8412729534",
  "text" : "RT @Ravish30: twitter tip for newbies - Sending DM's with your sales specials, web site links etc to folks who did (cont) http:\/\/tl.gd\/63jdm",
  "id" : 8412729534,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 9, 18 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omgfacts",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8412747282",
  "text" : "Cool! RT @OMGFacts: The energy of a discharge of an electric eel could start 50 cars. #omgfacts",
  "id" : 8412747282,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "Lotay",
      "screen_name" : "Lotay",
      "indices" : [ 18, 24 ],
      "id_str" : "15285305",
      "id" : 15285305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8412791293",
  "text" : "RT @ChrisCade: RT @Lotay My friend thought \"Lol\" meant \"Lots of love\"! :P Lol! &lt;--If only E (cont) http:\/\/tl.gd\/63jo4",
  "id" : 8412791293,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Conway",
      "screen_name" : "andrea_conway",
      "indices" : [ 3, 17 ],
      "id_str" : "16440705",
      "id" : 16440705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8413269925",
  "text" : "RT @andrea_conway: You may be trying way too hard to get the Law of Attraction working for you - new blog post http:\/\/bit.ly\/9NXEvf",
  "id" : 8413269925,
  "created_at" : "2010-01-30 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8376821113",
  "text" : "http:\/\/news.yahoo.com\/s\/space\/20100129\/sc_space\/biggestandbrightestfullmoonof2010tonight",
  "id" : 8376821113,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8378465064",
  "text" : "RT @DeepakChopra: Twitter Family: Please read this article and RT: 13 (Should Be Celebrated Not Sold) http:\/\/bit.ly\/dwX5u7",
  "id" : 8378465064,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetHoneycutt",
      "screen_name" : "GetHoneycutt",
      "indices" : [ 3, 16 ],
      "id_str" : "18959152",
      "id" : 18959152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8378561035",
  "text" : "RT @gethoneycutt: You are the absolutely the best person on the planet to be you!",
  "id" : 8378561035,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 3, 14 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8378697888",
  "text" : "RT @moosebegab: Do you do #followfriday manually? Or use app? I want to be able to click to choose names from list.",
  "id" : 8378697888,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 7, 19 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Friendship Quotes",
      "screen_name" : "FIWQuotes",
      "indices" : [ 24, 34 ],
      "id_str" : "108381735",
      "id" : 108381735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 117, 123 ]
    }, {
      "text" : "quotes",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8380429264",
  "text" : "LOL RT @brandonrofl: RT @FIWQuotes \u201CWhen people are laughing, they\u2019re generally not killing each other.\u201D \u2013 Alan Alda #quote #quotes",
  "id" : 8380429264,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8380571450",
  "text" : "Hi! : ) Thanks for reading my tweets, RTing and replying. You are wicked cool!",
  "id" : 8380571450,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "indices" : [ 3, 17 ],
      "id_str" : "38596022",
      "id" : 38596022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8380977120",
  "text" : "RT @livingthepoem: We needn't understand the exact nature of miracles for them to occur in our lives; we need only invite the possibility.",
  "id" : 8380977120,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhonda Warren \u10E6",
      "screen_name" : "rhondawarren",
      "indices" : [ 3, 16 ],
      "id_str" : "9112422",
      "id" : 9112422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8381551075",
  "text" : "RT @RhondaWarren: Im still offering a special for creating personalized twitter pages for $11! If you havent gotten urs yet email me rho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8381016611",
    "text" : "Im still offering a special for creating personalized twitter pages for $11! If you havent gotten urs yet email me rhonda@rhondawarren.com",
    "id" : 8381016611,
    "created_at" : "2010-01-29 19:40:25 +0000",
    "user" : {
      "name" : "Rhonda Warren \u10E6",
      "screen_name" : "rhondawarren",
      "protected" : false,
      "id_str" : "9112422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770811374725464064\/UOPXZcpj_normal.jpg",
      "id" : 9112422,
      "verified" : false
    }
  },
  "id" : 8381551075,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shabbir",
      "screen_name" : "shabzcohelp",
      "indices" : [ 0, 12 ],
      "id_str" : "19052397",
      "id" : 19052397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8381298383",
  "geo" : { },
  "id_str" : "8381963146",
  "in_reply_to_user_id" : 19052397,
  "text" : "@shabzcohelp Awesome! : )",
  "id" : 8381963146,
  "in_reply_to_status_id" : 8381298383,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "shabzcohelp",
  "in_reply_to_user_id_str" : "19052397",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8382084438",
  "text" : "RT @RichardWiseman: Tomorrow 100s of skeptics overdose on homeopathy. Surely 1 homeopath willing to overdose on dr (cont) http:\/\/tl.gd\/5v8qh",
  "id" : 8382084438,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8382177012",
  "text" : "RT @FreeSpiritKnits: Great link about how schools kill creativity.  http:\/\/www.ted.com\/talks\/ken_robinson_says_schools_kill_creativity.html",
  "id" : 8382177012,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "indices" : [ 14, 26 ],
      "id_str" : "32585384",
      "id" : 32585384
    }, {
      "name" : "Slade Roberson",
      "screen_name" : "SladeRoberson",
      "indices" : [ 27, 41 ],
      "id_str" : "40714123",
      "id" : 40714123
    }, {
      "name" : "GetHoneycutt",
      "screen_name" : "GetHoneycutt",
      "indices" : [ 42, 55 ],
      "id_str" : "18959152",
      "id" : 18959152
    }, {
      "name" : "Pema James",
      "screen_name" : "vacantsolace",
      "indices" : [ 56, 69 ],
      "id_str" : "15159771",
      "id" : 15159771
    }, {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "indices" : [ 70, 84 ],
      "id_str" : "38596022",
      "id" : 38596022
    }, {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "indices" : [ 97, 112 ],
      "id_str" : "48001363",
      "id" : 48001363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8383240480",
  "text" : "#followfriday @intuitivedm @sladeroberson @gethoneycutt @vacantsolace @livingthepoem @SkiptheZip @hippopotatomus",
  "id" : 8383240480,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLB",
      "screen_name" : "MLB37",
      "indices" : [ 19, 25 ],
      "id_str" : "322799281",
      "id" : 322799281
    }, {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 26, 32 ],
      "id_str" : "11006552",
      "id" : 11006552
    }, {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "indices" : [ 47, 61 ],
      "id_str" : "40923520",
      "id" : 40923520
    }, {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "indices" : [ 62, 73 ],
      "id_str" : "14461139",
      "id" : 14461139
    }, {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 74, 89 ],
      "id_str" : "46816086",
      "id" : 46816086
    }, {
      "name" : "Healing Inside",
      "screen_name" : "HealingInside",
      "indices" : [ 90, 104 ],
      "id_str" : "2176573952",
      "id" : 2176573952
    }, {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 105, 114 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 5, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8383445719",
  "text" : "more #followfriday @mlb37 @DrRus @EducateBooks @GiveTreeGifts @coachkaren @SpiritMaterial @HealingInside @OMGFacts",
  "id" : 8383445719,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 7, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8383481227",
  "text" : "I love #followfriday.. picking out special people!! : )",
  "id" : 8383481227,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetHoneycutt",
      "screen_name" : "GetHoneycutt",
      "indices" : [ 0, 13 ],
      "id_str" : "18959152",
      "id" : 18959152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8383899694",
  "geo" : { },
  "id_str" : "8383953738",
  "in_reply_to_user_id" : 18959152,
  "text" : "@gethoneycutt Clever.. : )",
  "id" : 8383953738,
  "in_reply_to_status_id" : 8383899694,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "GetHoneycutt",
  "in_reply_to_user_id_str" : "18959152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetHoneycutt",
      "screen_name" : "GetHoneycutt",
      "indices" : [ 7, 20 ],
      "id_str" : "18959152",
      "id" : 18959152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8384132103",
  "text" : "LOL RT @gethoneycutt: Why don't they make the whole plane out of that \"black box\" stuff?",
  "id" : 8384132103,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8384176679",
  "text" : "RT @DeepakChopra: Being or God is the One Life at the root or ground of all lives",
  "id" : 8384176679,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8384609774",
  "text" : "Becoming increasingly intolerant of news and judge shows... Ack!!!",
  "id" : 8384609774,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetHoneycutt",
      "screen_name" : "GetHoneycutt",
      "indices" : [ 3, 16 ],
      "id_str" : "18959152",
      "id" : 18959152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8384699472",
  "text" : "RT @gethoneycutt: What most people call listening is nothing more than them waiting for a pause, so they can begin talking :)",
  "id" : 8384699472,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8385686219",
  "text" : "RT @Ravish30: Selling all of my NEW Tupperware Stock & willing to wheel & deal! All will be sold for 50% off and more",
  "id" : 8385686219,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "anita g. wheeler",
      "screen_name" : "anitagwheeler",
      "indices" : [ 3, 17 ],
      "id_str" : "28475053",
      "id" : 28475053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8386085233",
  "text" : "RT @anitagwheeler: TGIF..maybe we should change to TGFT (Thank God For TODAY!)  Every day and every moment is precious! http:\/\/bit.ly\/ayhpVv",
  "id" : 8386085233,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8386079921",
  "geo" : { },
  "id_str" : "8386195338",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 me, too! Spring is my fave season : )",
  "id" : 8386195338,
  "in_reply_to_status_id" : 8386079921,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GetHoneycutt",
      "screen_name" : "GetHoneycutt",
      "indices" : [ 0, 13 ],
      "id_str" : "18959152",
      "id" : 18959152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8386064965",
  "geo" : { },
  "id_str" : "8386235429",
  "in_reply_to_user_id" : 18959152,
  "text" : "@gethoneycutt hubs liked that one! Teehee",
  "id" : 8386235429,
  "in_reply_to_status_id" : 8386064965,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "GetHoneycutt",
  "in_reply_to_user_id_str" : "18959152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8386331160",
  "text" : "Mmm.. Sure do love my strawberries!",
  "id" : 8386331160,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8386859791",
  "text" : "My DD just informed me that the black spot in eye is a hole... (health class)",
  "id" : 8386859791,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8387107440",
  "text" : "Dove Promises message:\"Think without limits.\".&lt;&lt; Yes!!",
  "id" : 8387107440,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8387210650",
  "text" : "My DD is picking up choc chips with a clothespin.. Lol",
  "id" : 8387210650,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8387393310",
  "text" : "Now.hubs is making the dog dance",
  "id" : 8387393310,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8389061402",
  "text" : "Love it!! RT @SkiptheZip: Free hugs to a good home. Current owner is so happy, so content, can't contain it anymore. Inquire within.",
  "id" : 8389061402,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8389102291",
  "text" : "RT @ChrisCade: \"I need help!\" is the cry of a true Universal warrior. :) Merely uttering those words ord (cont) http:\/\/tl.gd\/5vr5s",
  "id" : 8389102291,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoachDawn",
      "screen_name" : "CoachDawn",
      "indices" : [ 3, 13 ],
      "id_str" : "15989069",
      "id" : 15989069
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8389186840",
  "text" : "RT @CoachDawn: \u2727A PARENT'S Job is to Encourage Kids to develop a Joy for Life & a great urge to Follow their own D R E A M S ~Pausch #quote",
  "id" : 8389186840,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "indices" : [ 3, 17 ],
      "id_str" : "40923520",
      "id" : 40923520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8348648560",
  "text" : "RT @GiveTreeGifts: \u201CLove is when your puppy licks your face even after you left him alone all day.\u201D Mary Ann, age 4 #quote",
  "id" : 8348648560,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omgfacts",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8348790575",
  "text" : "RT @OMGFacts: Footprints of astronauts who landed on the moon are expected to last at least 10 million years. #omgfacts",
  "id" : 8348790575,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8350266567",
  "text" : "RT @brandonrofl: \u262E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8350180064",
    "text" : "\u262E",
    "id" : 8350180064,
    "created_at" : "2010-01-29 02:41:32 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8350266567,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8346735763",
  "geo" : { },
  "id_str" : "8350305967",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX Thanks for posting these! : )",
  "id" : 8350305967,
  "in_reply_to_status_id" : 8346735763,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8350424641",
  "text" : "@SkiptheZip very interesting.. thanks!",
  "id" : 8350424641,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8351103871",
  "text" : "Look to the good. Look to the good and don't look back. #quotes",
  "id" : 8351103871,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8362208499",
  "text" : "You are more focused than usual, which encourages others to co... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8362208499,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8367908764",
  "text" : "RT @BigBookofYou: I've learned....... That just one person saying to me, 'You've made my day!' makes my day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8367420217",
    "text" : "I've learned....... That just one person saying to me, 'You've made my day!' makes my day.",
    "id" : 8367420217,
    "created_at" : "2010-01-29 13:29:05 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 8367908764,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8368092948",
  "text" : "RT @RichardWiseman: If everyone suggests that people follow me, I will make a large contribution to my local owl and donkey sanctuaries.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8365123628",
    "text" : "If everyone suggests that people follow me, I will make a large contribution to my local owl and donkey sanctuaries.",
    "id" : 8365123628,
    "created_at" : "2010-01-29 12:09:30 +0000",
    "user" : {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "protected" : false,
      "id_str" : "19512493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3225534671\/ef59c3b397d28dacb74034b47d8cd9e2_normal.jpeg",
      "id" : 19512493,
      "verified" : true
    }
  },
  "id" : 8368092948,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "How2Go2Hell",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8368540129",
  "text" : "RT @brandonrofl: #How2Go2Hell You can't, because Hell exists only in our imaginations.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "How2Go2Hell",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8351983021",
    "text" : "#How2Go2Hell You can't, because Hell exists only in our imaginations.",
    "id" : 8351983021,
    "created_at" : "2010-01-29 03:28:42 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8368540129,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 14, 23 ],
      "id_str" : "443493421",
      "id" : 443493421
    }, {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 38, 50 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 51, 66 ],
      "id_str" : "46816086",
      "id" : 46816086
    }, {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 67, 75 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 76, 91 ],
      "id_str" : "43012495",
      "id" : 43012495
    }, {
      "name" : "turuhime",
      "screen_name" : "aloemom",
      "indices" : [ 92, 100 ],
      "id_str" : "283729168",
      "id" : 283729168
    }, {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 101, 112 ],
      "id_str" : "85670618",
      "id" : 85670618
    }, {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "indices" : [ 113, 124 ],
      "id_str" : "30795207",
      "id" : 30795207
    }, {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 125, 131 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8369271446",
  "text" : "#followfriday @ravish30 @bigbookofyou @brandonrofl @spiritmaterial @candytx @abandontheherd @aloemom @tweeterena @alphamares @drrus",
  "id" : 8369271446,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8369758050",
  "text" : "I got Follow Friday Generator app but needs tweaking. Needs to add \"choose contacts\" option...",
  "id" : 8369758050,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followfriday",
      "indices" : [ 10, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8369910442",
  "text" : "Do you do #followfriday manually? Or use app? I want to be able to click to choose names from list.",
  "id" : 8369910442,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8370354150",
  "geo" : { },
  "id_str" : "8370569861",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus their raises",
  "id" : 8370569861,
  "in_reply_to_status_id" : 8370354150,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8370341990",
  "geo" : { },
  "id_str" : "8370668270",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus look forward to your mindbenders each day : )",
  "id" : 8370668270,
  "in_reply_to_status_id" : 8370341990,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8370331480",
  "geo" : { },
  "id_str" : "8370909877",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 Woohoo!! (insert music here!) : )",
  "id" : 8370909877,
  "in_reply_to_status_id" : 8370331480,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 0, 11 ],
      "id_str" : "85670618",
      "id" : 85670618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8370983722",
  "in_reply_to_user_id" : 85670618,
  "text" : "@tweeterena how do I get to saved draft? Can't find it.",
  "id" : 8370983722,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tweeterena",
  "in_reply_to_user_id_str" : "85670618",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8370811281",
  "geo" : { },
  "id_str" : "8371149806",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 I bow to you.. 22 years next Sept. Cruise sounds great! Did one for honeymoon.",
  "id" : 8371149806,
  "in_reply_to_status_id" : 8370811281,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8371165244",
  "text" : "RT @DrRus: Wondering if I will finally break the 2000 follower mark this weekend. I'm SO close! LOL!",
  "id" : 8371165244,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    }, {
      "name" : "MLB",
      "screen_name" : "MLB37",
      "indices" : [ 18, 24 ],
      "id_str" : "322799281",
      "id" : 322799281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetaway",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8371285415",
  "text" : "RT @DrRus: Follow @mlb37 ! He's a great movie guy and has a #tweetaway going too! Win an iPod touch!",
  "id" : 8371285415,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8371216048",
  "geo" : { },
  "id_str" : "8371358558",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus should have known this one.. I remember those days.. Hehe",
  "id" : 8371358558,
  "in_reply_to_status_id" : 8371216048,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8373218649",
  "text" : "RT @DrRus: Saturday is \"Inane Answering Message Day\"! The day to change, shorten, replace or delete your answering machine message.",
  "id" : 8373218649,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8373182113",
  "geo" : { },
  "id_str" : "8373288589",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd cool.. You just made my day : ) Thanks!!",
  "id" : 8373288589,
  "in_reply_to_status_id" : 8373182113,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 9, 24 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8373352092",
  "text" : "Amen! RT @abandontheherd: We are all part of something beautiful.",
  "id" : 8373352092,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8373907645",
  "text" : "Ohh big argument brewing w\/ hubs.. Sigh!! : (",
  "id" : 8373907645,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quot.me iPhone App",
      "screen_name" : "quotme",
      "indices" : [ 3, 10 ],
      "id_str" : "69018756",
      "id" : 69018756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8374131966",
  "text" : "RT @quotme: \"If you want to get laid, go to college. If you want an education, go to the library.\" - Frank Zappa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8170427614",
    "text" : "\"If you want to get laid, go to college. If you want an education, go to the library.\" - Frank Zappa",
    "id" : 8170427614,
    "created_at" : "2010-01-25 00:44:05 +0000",
    "user" : {
      "name" : "Quot.me iPhone App",
      "screen_name" : "quotme",
      "protected" : false,
      "id_str" : "69018756",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/420171926\/quotme-57_normal.png",
      "id" : 69018756,
      "verified" : false
    }
  },
  "id" : 8374131966,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 9, 21 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8375189820",
  "text" : "just for @brandonrofl \"You have enemies? Good. That means you've stood up for something, sometime in your life.\"-Winston Churchill",
  "id" : 8375189820,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vin Miller",
      "screen_name" : "vinmiller",
      "indices" : [ 3, 13 ],
      "id_str" : "17511879",
      "id" : 17511879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8375493324",
  "text" : "RT @vinmiller How to Eliminate Sugar from Your Diet http:\/\/bit.ly\/eDq9c",
  "id" : 8375493324,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8375172781",
  "geo" : { },
  "id_str" : "8375595685",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 oh pretty!",
  "id" : 8375595685,
  "in_reply_to_status_id" : 8375172781,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8375867791",
  "text" : "Laugh if you will, but I learned to stand up for myself, speak my mind, face fear from a Malamute...",
  "id" : 8375867791,
  "created_at" : "2010-01-29 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vickie barnes",
      "screen_name" : "VickieBarnes",
      "indices" : [ 3, 16 ],
      "id_str" : "356600864",
      "id" : 356600864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8325075591",
  "text" : "RT @VickieBarnes: Don\u2019t Conform! \u2013 Abraham-Hicks Quote: The people that are at the top of their game, the peop (cont) http:\/\/tl.gd\/5o2r7",
  "id" : 8325075591,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turuhime",
      "screen_name" : "aloemom",
      "indices" : [ 0, 8 ],
      "id_str" : "283729168",
      "id" : 283729168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8325714971",
  "text" : "@aloemom Cool : )",
  "id" : 8325714971,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turuhime",
      "screen_name" : "aloemom",
      "indices" : [ 32, 40 ],
      "id_str" : "283729168",
      "id" : 283729168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8325804937",
  "text" : "Miracles are alive and well! RT @aloemom: Today I received answer to more than 1 prayer, all in one place! I even  (cont) http:\/\/tl.gd\/5o6v4",
  "id" : 8325804937,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 0, 11 ],
      "id_str" : "85670618",
      "id" : 85670618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8325925409",
  "in_reply_to_user_id" : 85670618,
  "text" : "@tweeterena when I RT w\/ reply.. I keep hitting close button. I put reply in front of RT.",
  "id" : 8325925409,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tweeterena",
  "in_reply_to_user_id_str" : "85670618",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "indices" : [ 3, 14 ],
      "id_str" : "30795207",
      "id" : 30795207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8326504001",
  "text" : "RT @AlphaMares: Don't 'make do' because you feel unworthy to ask for anything more.",
  "id" : 8326504001,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8326974997",
  "text" : "UGH! Hit wrong button and ended game.. Have to start over : (",
  "id" : 8326974997,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8327298048",
  "geo" : { },
  "id_str" : "8327754939",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 Cranberry Almond from HNB? Love it, too. Need hubs to order more!",
  "id" : 8327754939,
  "in_reply_to_status_id" : 8327298048,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8329147039",
  "text" : "Feel free to add me on Facebook: http:\/\/profile.to\/abfabgab",
  "id" : 8329147039,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "indices" : [ 3, 14 ],
      "id_str" : "30795207",
      "id" : 30795207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8330053362",
  "text" : "RT @AlphaMares: If we judge a person by their differences we miss what we are here to share.",
  "id" : 8330053362,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8330162315",
  "text" : "I want bionic eyes! Tired of not being able to see...",
  "id" : 8330162315,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8331504445",
  "text" : "Busy is a swear word...",
  "id" : 8331504445,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8334593225",
  "geo" : { },
  "id_str" : "8334901213",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd \"or inferior\" as a friend added...",
  "id" : 8334901213,
  "in_reply_to_status_id" : 8334593225,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "indices" : [ 3, 17 ],
      "id_str" : "38596022",
      "id" : 38596022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8336379914",
  "text" : "RT @livingthepoem: A thought occurs. We suspect it may be. We grow to believe. We blossom as we live it. Thoughts take form.",
  "id" : 8336379914,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 17, 26 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8337550259",
  "text" : "Good advice!! RT @Ravish30: it always amazes me that some folks don't think before they type & post something that can be hurtful to others",
  "id" : 8337550259,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8338857293",
  "text" : "Homemade chicken wraps for dindin.. I'm so excited!",
  "id" : 8338857293,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8342569934",
  "geo" : { },
  "id_str" : "8343356562",
  "in_reply_to_user_id" : 14563201,
  "text" : "@BigBookofYou oh how awesome is that? : )",
  "id" : 8343356562,
  "in_reply_to_status_id" : 8342569934,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "meetjennmclean",
  "in_reply_to_user_id_str" : "14563201",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 7, 14 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Darin Ross's Ghost",
      "screen_name" : "luckyshirt",
      "indices" : [ 19, 30 ],
      "id_str" : "15060582",
      "id" : 15060582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8343412087",
  "text" : "LOL RT @BestAt: RT @luckyshirt: To make a long story short: the end.",
  "id" : 8343412087,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    }, {
      "name" : "John Hope Bryant",
      "screen_name" : "johnhopebryant",
      "indices" : [ 90, 105 ],
      "id_str" : "16555317",
      "id" : 16555317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8343445736",
  "text" : "RT @paulocoelho: Davos: \"If you want to see God laughing, show Him your plans\" (my friend @johnhopebryant during the dinner)",
  "id" : 8343445736,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "indices" : [ 0, 15 ],
      "id_str" : "48001363",
      "id" : 48001363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8343027329",
  "geo" : { },
  "id_str" : "8343530917",
  "in_reply_to_user_id" : 48001363,
  "text" : "@hippopotatomus LOL",
  "id" : 8343530917,
  "in_reply_to_status_id" : 8343027329,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "hippopotatomus",
  "in_reply_to_user_id_str" : "48001363",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8305711183",
  "text" : "RT @SpiritMaterial: The illusion of separateness leads to belief in absolute right and wrong, allowing us to feel superior to others.",
  "id" : 8305711183,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 0, 12 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8307298468",
  "geo" : { },
  "id_str" : "8307375551",
  "in_reply_to_user_id" : 18694547,
  "text" : "@brandonrofl Is that a bad thing? : )",
  "id" : 8307375551,
  "in_reply_to_status_id" : 8307298468,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8317273158",
  "text" : "You are still attempting to process a lot of information that ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8317273158,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8322169620",
  "text" : "G'Morn my tweeties. Snowy here in NY... Drinking my coffee.",
  "id" : 8322169620,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodimentary",
      "screen_name" : "Foodimentary",
      "indices" : [ 3, 16 ],
      "id_str" : "17242874",
      "id" : 17242874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8323013900",
  "text" : "RT @Foodimentary: Pass the syrup! January 28 is National Blueberry Pancake Day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8322227255",
    "text" : "Pass the syrup! January 28 is National Blueberry Pancake Day.",
    "id" : 8322227255,
    "created_at" : "2010-01-28 13:25:45 +0000",
    "user" : {
      "name" : "Foodimentary",
      "screen_name" : "Foodimentary",
      "protected" : false,
      "id_str" : "17242874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622893150525243392\/oAiOUaCD_normal.jpg",
      "id" : 17242874,
      "verified" : false
    }
  },
  "id" : 8323013900,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "indices" : [ 3, 16 ],
      "id_str" : "22276232",
      "id" : 22276232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 103, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8323016485",
  "text" : "RT @successwalls: \"We can do anything we want to as long as we stick to it long enough.\" \u2013Helen Keller #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 85, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8322435038",
    "text" : "\"We can do anything we want to as long as we stick to it long enough.\" \u2013Helen Keller #quote",
    "id" : 8322435038,
    "created_at" : "2010-01-28 13:32:19 +0000",
    "user" : {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "protected" : false,
      "id_str" : "22276232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840968112\/twitrSWicon2_normal.jpg",
      "id" : 22276232,
      "verified" : false
    }
  },
  "id" : 8323016485,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8323690006",
  "geo" : { },
  "id_str" : "8323792250",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus Sex",
  "id" : 8323792250,
  "in_reply_to_status_id" : 8323690006,
  "created_at" : "2010-01-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8261156520",
  "text" : "RT @RevAnne1: EFT Affirm I find humor in everything! I laugh at myself & I laugh at life itself! I LOVE to lau (cont) http:\/\/tl.gd\/5g17k",
  "id" : 8261156520,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8261339315",
  "text" : "RT @twitingly: Act as if what you do makes a difference. It does.",
  "id" : 8261339315,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8277270795",
  "text" : "You are ready for a day of fun-filled activities, but you won'... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8277270795,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8278630600",
  "text" : "RT @BigBookofYou: I've learned...That everyone you meet deserves to be greeted with a smile. #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 75, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8277732570",
    "text" : "I've learned...That everyone you meet deserves to be greeted with a smile. #quote",
    "id" : 8277732570,
    "created_at" : "2010-01-27 12:53:05 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 8278630600,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8278697714",
  "text" : "RT @Encouraging: Love can be as simple as asking, \u201CHow are you?\u201D and then really listening.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8276175886",
    "text" : "Love can be as simple as asking, \u201CHow are you?\u201D and then really listening.",
    "id" : 8276175886,
    "created_at" : "2010-01-27 11:54:09 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 8278697714,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8278704750",
  "text" : "RT @abandontheherd: May your troubles be less, blessings be more, and nothing but happiness come through your door.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8276094560",
    "text" : "May your troubles be less, blessings be more, and nothing but happiness come through your door.",
    "id" : 8276094560,
    "created_at" : "2010-01-27 11:50:40 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 8278704750,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8279268585",
  "text" : "Who knew The Weather Channel coul be entertaining? : )",
  "id" : 8279268585,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8279918271",
  "text" : "Hubs continues to amaze me (in a most good way.. Lol!) I am very, very blessed.",
  "id" : 8279918271,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8281019227",
  "geo" : { },
  "id_str" : "8281237667",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus our sanity?",
  "id" : 8281237667,
  "in_reply_to_status_id" : 8281019227,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8281717897",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX what do you use for video? Flip? Which one specifically? Where is it positioned (on monitor?) Thx!",
  "id" : 8281717897,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8282702197",
  "text" : "RT @brandonrofl: RT @exmttravel \"Your imagination is your preview of life's coming attractions.\" \u2014 Albert Einstein #quote",
  "id" : 8282702197,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8283215646",
  "text" : "RT @BigBookofYou: \"Too many of us are not living our dreams because we are living our fears.\" -Les Brown #quote",
  "id" : 8283215646,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turuhime",
      "screen_name" : "aloemom",
      "indices" : [ 0, 8 ],
      "id_str" : "283729168",
      "id" : 283729168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8283883660",
  "text" : "@aloemom yes I have.. Follow your intuition : )",
  "id" : 8283883660,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8283488987",
  "geo" : { },
  "id_str" : "8283990649",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX cool, thanks!",
  "id" : 8283990649,
  "in_reply_to_status_id" : 8283488987,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8283488987",
  "geo" : { },
  "id_str" : "8284203174",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX Sorry.. but I did laugh.. ; ) Nice set up!",
  "id" : 8284203174,
  "in_reply_to_status_id" : 8283488987,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8284646779",
  "text" : "RT @brandonrofl: RT @POPNQ \"Sometimes good things fall apart so better things can fall together\" - Marilyn Monroe #quotes",
  "id" : 8284646779,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 19, 34 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8285545608",
  "text" : "Absolutely! Lol RT @abandontheherd: Ever notice when you have a \"good hair day\" everything feels right? ;)",
  "id" : 8285545608,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8283488987",
  "geo" : { },
  "id_str" : "8285707982",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX so you have old model Ultra? any reason to get newer? I'd be casual user.. trying to figure out what I need\/want..",
  "id" : 8285707982,
  "in_reply_to_status_id" : 8283488987,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8285488559",
  "geo" : { },
  "id_str" : "8285850144",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 Hubs makes fun when I watch that channel.. Lol.. I like it too",
  "id" : 8285850144,
  "in_reply_to_status_id" : 8285488559,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8286135725",
  "geo" : { },
  "id_str" : "8287244423",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 not big on romance either.. Mystery or psycho for me.. Lol",
  "id" : 8287244423,
  "in_reply_to_status_id" : 8286135725,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 3, 16 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8290428677",
  "text" : "RT @aplacetobark: Want 2 be part of my dog project? Film 30 sec vid or less abt why u have the greatest dog &  (cont) http:\/\/tl.gd\/5k02p",
  "id" : 8290428677,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8291417117",
  "geo" : { },
  "id_str" : "8291624858",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 Will we get a pic? Sounds cute!",
  "id" : 8291624858,
  "in_reply_to_status_id" : 8291417117,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amazing quotes",
      "screen_name" : "QuotesToSmile",
      "indices" : [ 3, 17 ],
      "id_str" : "488280964",
      "id" : 488280964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8294059120",
  "text" : "RT @QuotesToSmile: Let us be grateful to people who make us happy, they are the charming gardeners who make our so (cont) http:\/\/tl.gd\/5k78a",
  "id" : 8294059120,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 9, 24 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8294104389",
  "text" : "AMEN! RT @SpiritMaterial: \"Healing\" is actually a reconnection with our own power of being. Separation f (cont) http:\/\/tl.gd\/5k7be",
  "id" : 8294104389,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8293454772",
  "geo" : { },
  "id_str" : "8294175355",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 Ohhh, yeahhhh (drool)",
  "id" : 8294175355,
  "in_reply_to_status_id" : 8293454772,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8294196553",
  "text" : "RT @BigBookofYou: I've learned...That when you plan to get even with someone, you are only letting that person continue to hurt you.",
  "id" : 8294196553,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anita DeFrank",
      "screen_name" : "anitadefrank",
      "indices" : [ 3, 16 ],
      "id_str" : "17277821",
      "id" : 17277821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8294461907",
  "text" : "RT @anitadefrank: Do you know anyone who would be interested in reviewing internet marketing reports for me?  http:\/\/tinyurl.com\/yfucatx ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8293721055",
    "text" : "Do you know anyone who would be interested in reviewing internet marketing reports for me?  http:\/\/tinyurl.com\/yfucatx  Please RT",
    "id" : 8293721055,
    "created_at" : "2010-01-27 20:47:51 +0000",
    "user" : {
      "name" : "Anita DeFrank",
      "screen_name" : "anitadefrank",
      "protected" : false,
      "id_str" : "17277821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64010490\/me-in-ny_normal.jpg",
      "id" : 17277821,
      "verified" : false
    }
  },
  "id" : 8294461907,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8298018550",
  "text" : "Off to taekwondo! Cyal8r",
  "id" : 8298018550,
  "created_at" : "2010-01-27 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8241782058",
  "text" : "RT @mercola: Read your food labels & just say 'no' to anything containing this item... Guess what it is before (cont) http:\/\/tl.gd\/5efhm",
  "id" : 8241782058,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8241953297",
  "text" : "\"There's no reason to have a Plan B because it just distracts from Plan A.\" - Will Smith #quotes",
  "id" : 8241953297,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8243878478",
  "text" : "RT @ChrisCade: \"To forgive is to set a prisoner free and discover that the prisoner was you.\" ~ Lewis B. Smedes",
  "id" : 8243878478,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret Stockley",
      "screen_name" : "margaretstock",
      "indices" : [ 3, 17 ],
      "id_str" : "34653137",
      "id" : 34653137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8244147265",
  "text" : "RT @margaretstock: The illusion of the world is powerful and plays easily with the mind. Margaret Stockley",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8215483313",
    "text" : "The illusion of the world is powerful and plays easily with the mind. Margaret Stockley",
    "id" : 8215483313,
    "created_at" : "2010-01-26 01:22:14 +0000",
    "user" : {
      "name" : "Margaret Stockley",
      "screen_name" : "margaretstock",
      "protected" : false,
      "id_str" : "34653137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586171900155428866\/F-7k3zbk_normal.jpg",
      "id" : 34653137,
      "verified" : false
    }
  },
  "id" : 8244147265,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8246226240",
  "text" : "Hubby is excited. Got new game today for Xbox. He'll be playing all day! : )",
  "id" : 8246226240,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 35, 44 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8247081739",
  "text" : "Always cooking something yummy! RT @Ravish30: Just put some sugar cookies into the oven :)",
  "id" : 8247081739,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8247850864",
  "text" : "RT @BigBookofYou: The art of being wise is knowing what to overlook. William James #quote",
  "id" : 8247850864,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8247906127",
  "text" : "RT @BigBookofYou: 10 Simple Ways to Show Kindness Online http:\/\/short.to\/9lih",
  "id" : 8247906127,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 0, 11 ],
      "id_str" : "85670618",
      "id" : 85670618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8248068555",
  "in_reply_to_user_id" : 85670618,
  "text" : "@tweeterena should add \"from tweeterena\" when posts to FB. I checked out diff tweet apps that way. : )",
  "id" : 8248068555,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tweeterena",
  "in_reply_to_user_id_str" : "85670618",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Trudeau",
      "screen_name" : "KevinTrudeau",
      "indices" : [ 3, 16 ],
      "id_str" : "17198504",
      "id" : 17198504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8248172682",
  "text" : "RT @KevinTrudeau: Obama Administration Orders World Bank To Keep Third World In Poverty http:\/\/bit.ly\/bvENmz",
  "id" : 8248172682,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    }, {
      "name" : "The Classy Chics",
      "screen_name" : "TwoClassyChics",
      "indices" : [ 60, 75 ],
      "id_str" : "107879781",
      "id" : 107879781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8249194810",
  "text" : "RT @Ravish30: If you are in Direct Sales, you should follow @twoclassychics for DS information, tips etc",
  "id" : 8249194810,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8250309569",
  "text" : "RT @SpiritMaterial: Chocolate is definitely one of the major food groups.",
  "id" : 8250309569,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Henry Jennings",
      "screen_name" : "HenryJennings",
      "indices" : [ 20, 34 ],
      "id_str" : "17235959",
      "id" : 17235959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "p2",
      "indices" : [ 92, 95 ]
    }, {
      "text" : "quote",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8252498960",
  "text" : "RT @brandonrofl: RT @henryjennings There's never been a good government.-Emma Goldman #tcot #p2 #quote",
  "id" : 8252498960,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8253372112",
  "text" : "The dog is insisting on laying under my feet and chair... don't think she likes Daddy's new game.",
  "id" : 8253372112,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8213186566",
  "text" : "RT @twitingly: Wasting time won't make any difference to eternity.",
  "id" : 8213186566,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8213255672",
  "text" : "Eating pizza and waiting for \"The Office\". Life is good. : )",
  "id" : 8213255672,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8214660996",
  "text" : "So glad I got to see this episode... Proposed in the rain!",
  "id" : 8214660996,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Shaqir Hussyin",
      "screen_name" : "ShaqirHussyin",
      "indices" : [ 20, 34 ],
      "id_str" : "21950915",
      "id" : 21950915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8215642501",
  "text" : "RT @brandonrofl: RT @ShaqirHussyin \"Sometimes the heart sees what is invisible to the eye.\" ~ H. Jackson Brown, Jr. #quote",
  "id" : 8215642501,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8215936789",
  "text" : "RT @tonyrobbins: The most important thing in communication is to hear what isn't being said",
  "id" : 8215936789,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 0, 13 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8216014343",
  "text" : "@deucehartley LOL",
  "id" : 8216014343,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 0, 12 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8219578166",
  "geo" : { },
  "id_str" : "8219840277",
  "in_reply_to_user_id" : 18694547,
  "text" : "@brandonrofl there's emotion and then there's attitude. Pessimism is an attitude.",
  "id" : 8219840277,
  "in_reply_to_status_id" : 8219578166,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "Crystal Silver",
      "screen_name" : "crystalsilver",
      "indices" : [ 18, 32 ],
      "id_str" : "14030452",
      "id" : 14030452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8219922872",
  "text" : "RT @ChrisCade: RT @CrystalSilver Never let someone else design your life for you.",
  "id" : 8219922872,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8220381268",
  "text" : "RT @BigBookofYou: A true friend never gets in your way unless you happen to be going down. Arnold H. Glasow #quote",
  "id" : 8220381268,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8220400495",
  "text" : "RT @SpiritMaterial: Believe in yourself. If you can't do that, you can at least believe that I believe in you.",
  "id" : 8220400495,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "TinyQuote",
      "screen_name" : "tinyquote",
      "indices" : [ 20, 30 ],
      "id_str" : "99803852",
      "id" : 99803852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "music",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "sound",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "singing",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8220780574",
  "text" : "RT @brandonrofl: RT @tinyquote \"Music is the poetry of the air.\" ~ Richter #quote #music #sound #singing (cont) http:\/\/tl.gd\/5b9vg",
  "id" : 8220780574,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 7, 22 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8220946289",
  "text" : "LOL RT @SpiritMaterial: Be careful what you wish for. You might just get it. If you ask for an elephant, you'd better have a big back yard.",
  "id" : 8220946289,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Photography",
      "screen_name" : "AmazingPics",
      "indices" : [ 12, 24 ],
      "id_str" : "1364630323",
      "id" : 1364630323
    }, {
      "name" : "LIFE",
      "screen_name" : "LIFE",
      "indices" : [ 29, 34 ],
      "id_str" : "18665800",
      "id" : 18665800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8221352109",
  "text" : "Awesome! RT @AmazingPics: RT @LIFE: Sit. Stay. Do Not Roll Over. Meet My Pet Buffalo - http:\/\/digg.com\/d31GW8a",
  "id" : 8221352109,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8221599565",
  "text" : "Good night, my tweeties.. Cya in am!",
  "id" : 8221599565,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8233294905",
  "text" : "Your friends have something crucial to tell you and you better... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8233294905,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8234773065",
  "text" : "RT @lisarobbinyoung: Seth Godin slams twitter? Not on my watch! http:\/\/is.gd\/74qlL http:\/\/bit.ly\/8ZQZLQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8231845504",
    "text" : "Seth Godin slams twitter? Not on my watch! http:\/\/is.gd\/74qlL http:\/\/bit.ly\/8ZQZLQ",
    "id" : 8231845504,
    "created_at" : "2010-01-26 11:31:28 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 8234773065,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8234853572",
  "text" : "RT @twitingly: If you will laugh about it later, why not laugh about it now?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8228724281",
    "text" : "If you will laugh about it later, why not laugh about it now?",
    "id" : 8228724281,
    "created_at" : "2010-01-26 08:51:44 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 8234853572,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8234894613",
  "text" : "RT @twitingly: Organize your life around your dreams - and watch them come true.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8228717813",
    "text" : "Organize your life around your dreams - and watch them come true.",
    "id" : 8228717813,
    "created_at" : "2010-01-26 08:51:22 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 8234894613,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EFT",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8234940800",
  "text" : "RT @RevAnne1: #EFT Affirm I see doors of opportunity opening to me everywhere I look & I say \u201CYes!\u201D http:\/\/ThinkitBeitSeeit.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EFT",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8226752938",
    "text" : "#EFT Affirm I see doors of opportunity opening to me everywhere I look & I say \u201CYes!\u201D http:\/\/ThinkitBeitSeeit.com",
    "id" : 8226752938,
    "created_at" : "2010-01-26 07:11:17 +0000",
    "user" : {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "protected" : false,
      "id_str" : "25058557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212762820\/507W6716aDONEa1_normal.jpg",
      "id" : 25058557,
      "verified" : false
    }
  },
  "id" : 8234940800,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8234990787",
  "text" : "RT @SpiritMaterial: One \"secret\" to success is surrounding yourself with the right people. Stay away from negative people who bring you  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8223641773",
    "text" : "One \"secret\" to success is surrounding yourself with the right people. Stay away from negative people who bring you down.",
    "id" : 8223641773,
    "created_at" : "2010-01-26 05:08:46 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 8234990787,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8235181025",
  "text" : "Good morning, my tweeties. Enjoying my coffee, catching up on tweets. Been busy while I was sleepin'.. hehe.",
  "id" : 8235181025,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/intensedebate.com\" rel=\"nofollow\"\u003EIntenseDebate\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8236235482",
  "text" : "Commented on Should I Be Less Pessimistic or Should You Be More Realistic? \/ Brandon Writes The Wrongs http:\/\/tinyurl.com\/ydr73lp",
  "id" : 8236235482,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Winterburn",
      "screen_name" : "5tevenw",
      "indices" : [ 3, 11 ],
      "id_str" : "71806313",
      "id" : 71806313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8237047973",
  "text" : "RT @5tevenw: If the human brain was simple enough for us to understand we'd be so simple we couldn't understand.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8236471223",
    "text" : "If the human brain was simple enough for us to understand we'd be so simple we couldn't understand.",
    "id" : 8236471223,
    "created_at" : "2010-01-26 14:17:47 +0000",
    "user" : {
      "name" : "Steven Winterburn",
      "screen_name" : "5tevenw",
      "protected" : false,
      "id_str" : "71806313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697440590\/twitterProfilePhoto_normal.jpg",
      "id" : 71806313,
      "verified" : false
    }
  },
  "id" : 8237047973,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8237221523",
  "text" : "RT @abandontheherd: Hot off the press! My new blog: http:\/\/livingstressfreeprogram.blogspot.com\/2010\/01\/watching-stream.html",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8236827893",
    "text" : "Hot off the press! My new blog: http:\/\/livingstressfreeprogram.blogspot.com\/2010\/01\/watching-stream.html",
    "id" : 8236827893,
    "created_at" : "2010-01-26 14:28:22 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 8237221523,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8237307387",
  "text" : "perhaps they hear from the other side of veil, hmm.. http:\/\/news.yahoo.com\/s\/nm\/20100125\/hl_nm\/us_children_voices",
  "id" : 8237307387,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8237630589",
  "text" : "Perhaps it's our perception of these kids that is off... Cuz they don't fit in the box! http:\/\/tinyurl.com\/ydmb4rj",
  "id" : 8237630589,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Whole Science",
      "screen_name" : "wholescience",
      "indices" : [ 3, 16 ],
      "id_str" : "14867082",
      "id" : 14867082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8237718525",
  "text" : "RT @wholescience: Jim Carrey discusses his transpersonal experience and subsequent transformation of consciousness: http:\/\/bit.ly\/5yJZuV",
  "id" : 8237718525,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8238161862",
  "text" : "RT @abandontheherd: A repost: We cannot experience true calmness if we're attached to the fruits of our actions.",
  "id" : 8238161862,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8240596679",
  "text" : "RT @EducateBooks: I am not a teacher; only a fellow traveler of whom you asked the way. I pointed ahead\u2013ahead of (cont) http:\/\/tl.gd\/5eakf",
  "id" : 8240596679,
  "created_at" : "2010-01-26 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Simonds",
      "screen_name" : "SaganSchools",
      "indices" : [ 3, 16 ],
      "id_str" : "90255720",
      "id" : 90255720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8172985481",
  "text" : "RT @SaganSchools: Self-education is, I firmly believe, the only kind of education there is.\rIsaac Asimov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8172718000",
    "text" : "Self-education is, I firmly believe, the only kind of education there is.\rIsaac Asimov",
    "id" : 8172718000,
    "created_at" : "2010-01-25 01:46:55 +0000",
    "user" : {
      "name" : "Adam Simonds",
      "screen_name" : "SaganSchools",
      "protected" : false,
      "id_str" : "90255720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533829230\/100_1203_normal.JPG",
      "id" : 90255720,
      "verified" : false
    }
  },
  "id" : 8172985481,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "indices" : [ 3, 14 ],
      "id_str" : "14461139",
      "id" : 14461139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8175324147",
  "text" : "RT @coachkaren: Feeling bad serves to get your attention so that you will change what you are focusing on. http:\/\/bit.ly\/6TtbbA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8175170566",
    "text" : "Feeling bad serves to get your attention so that you will change what you are focusing on. http:\/\/bit.ly\/6TtbbA",
    "id" : 8175170566,
    "created_at" : "2010-01-25 02:47:22 +0000",
    "user" : {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "protected" : false,
      "id_str" : "14461139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1747699492\/KarenWalker_normal.jpg",
      "id" : 14461139,
      "verified" : false
    }
  },
  "id" : 8175324147,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8175328420",
  "text" : "RT @brandonrofl: You guys want to know how to be successful in life? I know a way that works every time. It's called dedication.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8175247372",
    "text" : "You guys want to know how to be successful in life? I know a way that works every time. It's called dedication.",
    "id" : 8175247372,
    "created_at" : "2010-01-25 02:49:09 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8175328420,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8189754199",
  "text" : "You are quite clear about what you want now, but as soon as yo... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8189754199,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    }, {
      "name" : "MLB",
      "screen_name" : "MLB37",
      "indices" : [ 65, 71 ],
      "id_str" : "322799281",
      "id" : 322799281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweetaway",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8200430956",
  "text" : "RT @DrRus: Follow TV\/Film Actor\/Producer\/Retired Baseball player @mlb37 in his #tweetaway - and have a chance to win an iPod touch from him!",
  "id" : 8200430956,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Phelps",
      "screen_name" : "PhelpsKaren",
      "indices" : [ 3, 15 ],
      "id_str" : "24110809",
      "id" : 24110809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8200495614",
  "text" : "RT @PhelpsKaren: Register now for my special Teleseminar with author Raleigh Pinskey's on \"101 Ways to Market (cont) http:\/\/tl.gd\/59ke3",
  "id" : 8200495614,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8200547216",
  "text" : "RT @DeepakChopra: Every second is a door to eternity. The door is opened by perception.",
  "id" : 8200547216,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 0, 11 ],
      "id_str" : "85670618",
      "id" : 85670618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8200885184",
  "in_reply_to_user_id" : 85670618,
  "text" : "@tweeterena Is there option to email a tweet to myself? I was able to do that w\/ another app.. Came in handy to check links..",
  "id" : 8200885184,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tweeterena",
  "in_reply_to_user_id_str" : "85670618",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8200958024",
  "text" : "Do I really want a Flip? If so, which one? Would I really use it? I am a gadget addict...",
  "id" : 8200958024,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8201013560",
  "text" : "RT @ChrisCade: \"In daily life we must see that it is not happiness that makes us grateful, but gratefulness t (cont) http:\/\/tl.gd\/59luv",
  "id" : 8201013560,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8200643496",
  "geo" : { },
  "id_str" : "8201092169",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd rainy, windy here, too. Car rocked while parked at bank..",
  "id" : 8201092169,
  "in_reply_to_status_id" : 8200643496,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8201105971",
  "geo" : { },
  "id_str" : "8201207192",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 I love spending time w\/ hubby.. Don't understand ladies that complain about too much togetherness. Lol",
  "id" : 8201207192,
  "in_reply_to_status_id" : 8201105971,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8201232173",
  "text" : "RT @mspinopromotes: \"To gain that which is worth having, it may be necessary to lose everything else.\"-Burnadette Devlin http:\/\/mspino.com",
  "id" : 8201232173,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8202538662",
  "text" : "RT @EducateBooks: [Education] consists mainly in what we have unlearned. - Mark Twain #quote",
  "id" : 8202538662,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8203036793",
  "text" : "RT @mspinopromotes: Lead me not into temptation; I can find the way myself.  ~Rita Mae Brown Have Fun!!! It is Monday!!! http:\/\/mspino.com",
  "id" : 8203036793,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8203900249",
  "text" : "RT @RevAnne1: EFT Affirm I let go of my need to know what will happen next & I trust Spirit to guide me. http:\/\/ThinkitBeitSeeit.com",
  "id" : 8203900249,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppConnect",
      "screen_name" : "appconn",
      "indices" : [ 0, 8 ],
      "id_str" : "83124469",
      "id" : 83124469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8205367749",
  "in_reply_to_user_id" : 83124469,
  "text" : "@appconn shows up as $1.99",
  "id" : 8205367749,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "appconn",
  "in_reply_to_user_id_str" : "83124469",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8205778427",
  "text" : "I made a game with zombies in it &lt;&lt; hubby playing on xbox.. song is catchy (smashing pumpkins type sound)",
  "id" : 8205778427,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8207312574",
  "text" : "RT @SheilaWalsh: If you are broken I will be your friend, if you are lost I'll be your traveling companion, if you (cont) http:\/\/tl.gd\/5a4ve",
  "id" : 8207312574,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 0, 12 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8208604141",
  "geo" : { },
  "id_str" : "8208942699",
  "in_reply_to_user_id" : 18694547,
  "text" : "@brandonrofl but rats are soo cute! ; )",
  "id" : 8208942699,
  "in_reply_to_status_id" : 8208604141,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "4ores7",
  "in_reply_to_user_id_str" : "18694547",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    }, {
      "name" : "skepticalguy",
      "screen_name" : "skepticalguy",
      "indices" : [ 23, 36 ],
      "id_str" : "14464210",
      "id" : 14464210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8210637091",
  "text" : "RT @RichardWiseman: RT @skepticalguy I've designed a survey to assess the atheist stereotype. Need non-theists. Pl (cont) http:\/\/tl.gd\/5abct",
  "id" : 8210637091,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8168847793",
  "geo" : { },
  "id_str" : "8170133314",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 oh I love mysteries like tha!",
  "id" : 8170133314,
  "in_reply_to_status_id" : 8168847793,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8168469815",
  "geo" : { },
  "id_str" : "8170188832",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 you just love taunting me ; &gt;",
  "id" : 8170188832,
  "in_reply_to_status_id" : 8168469815,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amazing quotes",
      "screen_name" : "QuotesToSmile",
      "indices" : [ 3, 17 ],
      "id_str" : "488280964",
      "id" : 488280964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "QTS",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8170207724",
  "text" : "RT @QuotesToSmile: \u00A8Love me when I least deserve it, because that\u2019s when I really need it.\u00A8 -Swedish Proverb #quotes #QTS",
  "id" : 8170207724,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8171652194",
  "text" : "RT @BigBookofYou: 16 awesome commands and shortcuts for Twitter http:\/\/snipr.com\/lmgxa",
  "id" : 8171652194,
  "created_at" : "2010-01-25 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Tepha&Ana",
      "screen_name" : "CelebritiesHere",
      "indices" : [ 79, 95 ],
      "id_str" : "241350798",
      "id" : 241350798
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 97, 110 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8130761103",
  "text" : "RT @DeepakChopra: Universe is physical body of God (infinite consciousness) RT @CelebritiesHere: @DeepakChopra define Universe versus God?",
  "id" : 8130761103,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amazing quotes",
      "screen_name" : "QuotesToSmile",
      "indices" : [ 3, 17 ],
      "id_str" : "488280964",
      "id" : 488280964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8135171156",
  "text" : "RT @QuotesToSmile: \"The most desired gift of love is not diamonds or roses or chocolate. It is focused attention.\"~Richard Warren #quotes",
  "id" : 8135171156,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8136792454",
  "text" : "RT @RevAnne1: EFT Affirm I am grateful for family, for friends, and for pets. I am grateful for love in all its ex (cont) http:\/\/tl.gd\/50td8",
  "id" : 8136792454,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8147882294",
  "text" : "It's hard to know whether it's smarter today to be as practica... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8147882294,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8151175707",
  "text" : "Nothing like an Aussie \"Good morning!\" greeting... Wiggles, twists, kisses... \"so happy you're alive!\"",
  "id" : 8151175707,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Todd Alberts",
      "screen_name" : "MrAlberts",
      "indices" : [ 26, 36 ],
      "id_str" : "34419840",
      "id" : 34419840
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 38, 51 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8151229496",
  "text" : "RT @DeepakChopra: LOVE RT @MrAlberts: @DeepakChopra  If just one word, what word?",
  "id" : 8151229496,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "MaureenSharib",
      "screen_name" : "TechTrak",
      "indices" : [ 65, 74 ],
      "id_str" : "48347473",
      "id" : 48347473
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 76, 89 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8151276271",
  "text" : "RT @DeepakChopra: Traveling the cosmic highway :) Wanna join? RT @TechTrak: @DeepakChopra You sound like you're trippin'.",
  "id" : 8151276271,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8151330638",
  "text" : "RT @twitingly: \"Some people never go crazy. What truly horrible lives they must lead. \"  \u2014 Charles Bukowski",
  "id" : 8151330638,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Anya Vaney",
      "screen_name" : "Born2BBold",
      "indices" : [ 20, 31 ],
      "id_str" : "3376621245",
      "id" : 3376621245
    }, {
      "name" : "Scott Reis",
      "screen_name" : "scott_re",
      "indices" : [ 35, 44 ],
      "id_str" : "101300166",
      "id" : 101300166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8151384034",
  "text" : "RT @brandonrofl: RT @born2bbold RT @scott_re: Disillusionment is a GOOD thing; to be disillusioned is to be enligh (cont) http:\/\/tl.gd\/53mnm",
  "id" : 8151384034,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8151395156",
  "text" : "RT @paulocoelho: 24\/01 Don\u2019t allow your wounds to turn you into a person you are not",
  "id" : 8151395156,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "swaroop",
      "screen_name" : "swaroopk",
      "indices" : [ 20, 29 ],
      "id_str" : "939510205",
      "id" : 939510205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8151523763",
  "text" : "RT @brandonrofl: RT @swaroopk RT: Do not take the road everyone else takes, for it will only get you stuck in traf (cont) http:\/\/tl.gd\/53nkb",
  "id" : 8151523763,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 0, 6 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8146910790",
  "geo" : { },
  "id_str" : "8152038027",
  "in_reply_to_user_id" : 11006552,
  "text" : "@DrRus trying to do this with my teenager.. lol",
  "id" : 8152038027,
  "in_reply_to_status_id" : 8146910790,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "DrRus",
  "in_reply_to_user_id_str" : "11006552",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "indices" : [ 3, 17 ],
      "id_str" : "40923520",
      "id" : 40923520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8153647280",
  "text" : "RT @GiveTreeGifts: Most of the shadows of this life are caused by our standing in our own sunshine. Ralph Waldo Emerson #quote",
  "id" : 8153647280,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8152793772",
  "geo" : { },
  "id_str" : "8153692863",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 you're such a tease! LOL",
  "id" : 8153692863,
  "in_reply_to_status_id" : 8152793772,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8152634159",
  "geo" : { },
  "id_str" : "8153715811",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 me, too...",
  "id" : 8153715811,
  "in_reply_to_status_id" : 8152634159,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amazing quotes",
      "screen_name" : "QuotesToSmile",
      "indices" : [ 0, 14 ],
      "id_str" : "488280964",
      "id" : 488280964
    }, {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 59, 71 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8153845596",
  "text" : "@QuotesToSmile cool, I was mentioned in group with awesome @brandonrofl : )",
  "id" : 8153845596,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8154425352",
  "text" : "I like my bananas just barely ripe with a bit of green at the top of skin",
  "id" : 8154425352,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "BZTAT",
      "screen_name" : "BZTAT",
      "indices" : [ 72, 78 ],
      "id_str" : "17269275",
      "id" : 17269275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8154914173",
  "text" : "RT @CaplinROUS: Good quote! I am 2.5 yo so I know the truth of this! RT @BZTAT: The years teach much which the day (cont) http:\/\/tl.gd\/54amn",
  "id" : 8154914173,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mrtweet.com\/\" rel=\"nofollow\"\u003EMrTweet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 12, 24 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "MrTweet",
      "screen_name" : "mrtweet",
      "indices" : [ 28, 36 ],
      "id_str" : "2307776510",
      "id" : 2307776510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8156907099",
  "text" : "Recommended @brandonrofl to @MrTweet 'intelligent, funny, wise for years, not afraid to speak truth' http:\/\/bit.ly\/8wAc8t",
  "id" : 8156907099,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mrtweet.com\/\" rel=\"nofollow\"\u003EMrTweet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 12, 21 ],
      "id_str" : "443493421",
      "id" : 443493421
    }, {
      "name" : "MrTweet",
      "screen_name" : "mrtweet",
      "indices" : [ 25, 33 ],
      "id_str" : "2307776510",
      "id" : 2307776510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8157052282",
  "text" : "Recommended @Ravish30 to @MrTweet 'she's funny, opinionated, down to earth, nice, good conversation' http:\/\/bit.ly\/5gF01I",
  "id" : 8157052282,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mrtweet.com\/\" rel=\"nofollow\"\u003EMrTweet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 12, 23 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "MrTweet",
      "screen_name" : "mrtweet",
      "indices" : [ 27, 35 ],
      "id_str" : "2307776510",
      "id" : 2307776510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8157406005",
  "text" : "Recommended @CaplinROUS to @MrTweet 'he's just adorable and makes great videos! Shows us how humans and animals can...' http:\/\/bit.ly\/8YEJXj",
  "id" : 8157406005,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8161984845",
  "text" : "Sometimes I like to just stare at hubby when he's interacting with others &lt;3",
  "id" : 8161984845,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amazing quotes",
      "screen_name" : "QuotesToSmile",
      "indices" : [ 3, 17 ],
      "id_str" : "488280964",
      "id" : 488280964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 121, 128 ]
    }, {
      "text" : "QTS",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8167180725",
  "text" : "RT @QuotesToSmile: The Grand essentials of happiness are: something to do, something to love, and something to hope for. #quotes #QTS",
  "id" : 8167180725,
  "created_at" : "2010-01-24 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 3, 17 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8092171199",
  "text" : "RT @marwilliamson: In a realm beyond what the eyes can see, events are conspiring to bring forth Good. Be a willing conduit through whic ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 132, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8092058934",
    "text" : "In a realm beyond what the eyes can see, events are conspiring to bring forth Good. Be a willing conduit through which it can flow  #fb",
    "id" : 8092058934,
    "created_at" : "2010-01-23 01:03:00 +0000",
    "user" : {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "protected" : false,
      "id_str" : "21522338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507257000367882240\/cWcbBvzD_normal.jpeg",
      "id" : 21522338,
      "verified" : true
    }
  },
  "id" : 8092171199,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8093525719",
  "text" : "You may be tired of the daily grind and now want to retreat in... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8093525719,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8094559467",
  "text" : "RT @twitingly: The goal of science is to build better mousetraps. The goal of nature is to build better mice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8094424146",
    "text" : "The goal of science is to build better mousetraps. The goal of nature is to build better mice.",
    "id" : 8094424146,
    "created_at" : "2010-01-23 02:09:18 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 8094559467,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Browne",
      "screen_name" : "MatthewLiberty",
      "indices" : [ 3, 18 ],
      "id_str" : "20698002",
      "id" : 20698002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8096830585",
  "text" : "RT @MatthewLiberty: It's always hard to say the unpopular thing!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8096385804",
    "text" : "It's always hard to say the unpopular thing!",
    "id" : 8096385804,
    "created_at" : "2010-01-23 03:00:54 +0000",
    "user" : {
      "name" : "Matt Browne",
      "screen_name" : "MatthewLiberty",
      "protected" : false,
      "id_str" : "20698002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726509851233423360\/HqPRqyAx_normal.jpg",
      "id" : 20698002,
      "verified" : false
    }
  },
  "id" : 8096830585,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8109178977",
  "text" : "You are ready to settle in to your weekend routine and you loo... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8109178977,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8111625970",
  "text" : "RT @paulocoelho: 23\/01 To believe in your choice you don't need to prove that other people's choices are wrong.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8108551801",
    "text" : "23\/01 To believe in your choice you don't need to prove that other people's choices are wrong.",
    "id" : 8108551801,
    "created_at" : "2010-01-23 11:56:22 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 8111625970,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Debra McDowell",
      "screen_name" : "Debra_McDowell",
      "indices" : [ 20, 35 ],
      "id_str" : "99680698",
      "id" : 99680698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8111682276",
  "text" : "RT @brandonrofl: RT @Debra_McDowell There's a certain freedom in being totally screwed... -from The Freshman #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Debra McDowell",
        "screen_name" : "Debra_McDowell",
        "indices" : [ 3, 18 ],
        "id_str" : "99680698",
        "id" : 99680698
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8107323544",
    "text" : "RT @Debra_McDowell There's a certain freedom in being totally screwed... -from The Freshman #quote",
    "id" : 8107323544,
    "created_at" : "2010-01-23 10:47:16 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8111682276,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Jean sQuared",
      "screen_name" : "jeansquared",
      "indices" : [ 20, 32 ],
      "id_str" : "27926973",
      "id" : 27926973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8112550443",
  "text" : "RT @brandonrofl: RT @jeansquared You can no more win a war than you can win an earthquake. -Jeannette Rankin #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jean sQuared",
        "screen_name" : "jeansquared",
        "indices" : [ 3, 15 ],
        "id_str" : "27926973",
        "id" : 27926973
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8112499374",
    "text" : "RT @jeansquared You can no more win a war than you can win an earthquake. -Jeannette Rankin #quote",
    "id" : 8112499374,
    "created_at" : "2010-01-23 14:44:50 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8112550443,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8112516858",
  "geo" : { },
  "id_str" : "8112818516",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 plain, blueberry, banana, choc chip? mmmm...",
  "id" : 8112818516,
  "in_reply_to_status_id" : 8112516858,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8112894534",
  "geo" : { },
  "id_str" : "8113008515",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 oh yeah, strawberries.. LOVE strawberries! : )",
  "id" : 8113008515,
  "in_reply_to_status_id" : 8112894534,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 0, 11 ],
      "id_str" : "85670618",
      "id" : 85670618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8110999216",
  "geo" : { },
  "id_str" : "8113426240",
  "in_reply_to_user_id" : 85670618,
  "text" : "@tweeterena wouldn't let me get sale price,kept saying updating, try later..",
  "id" : 8113426240,
  "in_reply_to_status_id" : 8110999216,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tweeterena",
  "in_reply_to_user_id_str" : "85670618",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8114463770",
  "text" : "RT @Rainer_hilft: \"We are like islands in the sea, separate on the surface but connected in the deep.\"-William James",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8113953200",
    "text" : "\"We are like islands in the sea, separate on the surface but connected in the deep.\"-William James",
    "id" : 8113953200,
    "created_at" : "2010-01-23 15:35:27 +0000",
    "user" : {
      "name" : "A\/D\/H Consult",
      "screen_name" : "ADH_Consult",
      "protected" : false,
      "id_str" : "24533117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743024677103239168\/S7ej_ZA0_normal.jpg",
      "id" : 24533117,
      "verified" : false
    }
  },
  "id" : 8114463770,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8115128051",
  "text" : "so I got tweeterena pro.. it uses real names in timeline not twitter names.. I go by twitter names.. hope they update that.. ; )",
  "id" : 8115128051,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8115194957",
  "geo" : { },
  "id_str" : "8115344634",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd im partial to willows so jan 18 weeping in fog.. also one next to it..",
  "id" : 8115344634,
  "in_reply_to_status_id" : 8115194957,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweeterena",
      "screen_name" : "Tweeterena",
      "indices" : [ 0, 11 ],
      "id_str" : "85670618",
      "id" : 85670618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8116080808",
  "geo" : { },
  "id_str" : "8116408001",
  "in_reply_to_user_id" : 85670618,
  "text" : "@tweeterena ok, got it.. much better now! : )",
  "id" : 8116408001,
  "in_reply_to_status_id" : 8116080808,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Tweeterena",
  "in_reply_to_user_id_str" : "85670618",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8116444007",
  "text" : "RT @brandonrofl: RT @superjenie If you woke up breathing, congratulations! You have another chance. ~Andrea Boydston #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 100, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8116205962",
    "text" : "RT @superjenie If you woke up breathing, congratulations! You have another chance. ~Andrea Boydston #quote",
    "id" : 8116205962,
    "created_at" : "2010-01-23 16:49:29 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8116444007,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8116546494",
  "text" : "RT @BeALegacy: Don't let what you cannot do interfere with what you can do. ~ Do all you can and keep learning to  (cont) http:\/\/tl.gd\/4v277",
  "id" : 8116546494,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 0, 10 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8116736997",
  "geo" : { },
  "id_str" : "8116797733",
  "in_reply_to_user_id" : 29787449,
  "text" : "@BeALegacy so true.. when I hear impossible, I think of people never thought we'd fly..",
  "id" : 8116797733,
  "in_reply_to_status_id" : 8116736997,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "BeALegacy",
  "in_reply_to_user_id_str" : "29787449",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8120360931",
  "text" : "Love my iPod touch but want Internet access everywhere.. Don't use cell phone..",
  "id" : 8120360931,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8120640102",
  "text" : "Have to say tweeterena is pretty cool so far...",
  "id" : 8120640102,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8123803237",
  "text" : "RT @brandonrofl: When I hear somebody sigh, \"Life is hard\", I am always tempted to ask, \"Compared to what?\" Sydney J. Harris #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8121181253",
    "text" : "When I hear somebody sigh, \"Life is hard\", I am always tempted to ask, \"Compared to what?\" Sydney J. Harris #quote",
    "id" : 8121181253,
    "created_at" : "2010-01-23 19:33:55 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8123803237,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Amalia (Amy) E Zents",
      "screen_name" : "therealamyzents",
      "indices" : [ 73, 89 ],
      "id_str" : "61343044",
      "id" : 61343044
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 91, 104 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8126273644",
  "text" : "RT @DeepakChopra: Yes but you are just one of infinite ways of peeing RT @therealamyzents: @DeepakChopra so when I pee the universe pees?",
  "id" : 8126273644,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8127327148",
  "text" : "My newest addiction.. Moxie (game app on my Touch)",
  "id" : 8127327148,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "turuhime",
      "screen_name" : "aloemom",
      "indices" : [ 0, 8 ],
      "id_str" : "283729168",
      "id" : 283729168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8090432085",
  "text" : "@aloemom got echofon, tweeterena, tweet only on my ipod touch",
  "id" : 8090432085,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Love",
      "screen_name" : "inspiremedaisy",
      "indices" : [ 3, 18 ],
      "id_str" : "41955131",
      "id" : 41955131
    }, {
      "name" : "Owning Pink",
      "screen_name" : "OwningPink",
      "indices" : [ 36, 47 ],
      "id_str" : "64522624",
      "id" : 64522624
    }, {
      "name" : "Lissa Rankin, MD",
      "screen_name" : "Lissarankin",
      "indices" : [ 51, 63 ],
      "id_str" : "25393674",
      "id" : 25393674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8090627564",
  "text" : "RT @inspiremedaisy: SO Powerful! RT @OwningPink RT @Lissarankin: What if the next generation refused to accept the brokenness? Watch thi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Owning Pink",
        "screen_name" : "OwningPink",
        "indices" : [ 16, 27 ],
        "id_str" : "64522624",
        "id" : 64522624
      }, {
        "name" : "Lissa Rankin, MD",
        "screen_name" : "Lissarankin",
        "indices" : [ 31, 43 ],
        "id_str" : "25393674",
        "id" : 25393674
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8033232547",
    "text" : "SO Powerful! RT @OwningPink RT @Lissarankin: What if the next generation refused to accept the brokenness? Watch this- http:\/\/su.pr\/8sjE00",
    "id" : 8033232547,
    "created_at" : "2010-01-21 16:43:05 +0000",
    "user" : {
      "name" : "Jessica Love",
      "screen_name" : "inspiremedaisy",
      "protected" : false,
      "id_str" : "41955131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1251050046\/SolidarityWisconsin_normal.PNG",
      "id" : 41955131,
      "verified" : false
    }
  },
  "id" : 8090627564,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS News",
      "screen_name" : "CBSNews",
      "indices" : [ 3, 11 ],
      "id_str" : "15012486",
      "id" : 15012486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8092127772",
  "text" : "RT @cbsnews Off-Road Racing Dog Has Need for Speed - CBS News http:\/\/bit.ly\/7oOqbd",
  "id" : 8092127772,
  "created_at" : "2010-01-23 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8051534579",
  "text" : "RT @abandontheherd: Accepting 2010 tree photos from anyone ... http:\/\/www.abandontheherd.com\/AbandonTheHerd\/Blog\/Entries\/2010\/1\/17_DSC_0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8049207301",
    "text" : "Accepting 2010 tree photos from anyone ... http:\/\/www.abandontheherd.com\/AbandonTheHerd\/Blog\/Entries\/2010\/1\/17_DSC_0002_1.html",
    "id" : 8049207301,
    "created_at" : "2010-01-22 00:56:14 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 8051534579,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8051700540",
  "text" : "broke my board on 3rd try at taekwondo tonight using backfist",
  "id" : 8051700540,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Donna",
      "screen_name" : "smittenkat",
      "indices" : [ 20, 31 ],
      "id_str" : "45217457",
      "id" : 45217457
    }, {
      "name" : "Spirit Warrior",
      "screen_name" : "rainbow_phoenix",
      "indices" : [ 35, 51 ],
      "id_str" : "54035267",
      "id" : 54035267
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Quote",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8068606260",
  "text" : "RT @brandonrofl: RT @smittenkat RT @rainbow_phoenix: I may not be there yet, but I'm closer than I was yesterday. ~Author Unknown #Quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donna",
        "screen_name" : "smittenkat",
        "indices" : [ 3, 14 ],
        "id_str" : "45217457",
        "id" : 45217457
      }, {
        "name" : "Spirit Warrior",
        "screen_name" : "rainbow_phoenix",
        "indices" : [ 18, 34 ],
        "id_str" : "54035267",
        "id" : 54035267
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Quote",
        "indices" : [ 113, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8065130333",
    "text" : "RT @smittenkat RT @rainbow_phoenix: I may not be there yet, but I'm closer than I was yesterday. ~Author Unknown #Quote",
    "id" : 8065130333,
    "created_at" : "2010-01-22 10:44:23 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8068606260,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "James Goodwill",
      "screen_name" : "JimGoodwill",
      "indices" : [ 20, 32 ],
      "id_str" : "99241895",
      "id" : 99241895
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8068638014",
  "text" : "RT @brandonrofl: RT @JimGoodwill My definition of a free society is a society where it is safe to be unpopular. -Adlai E. Stevenson #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Goodwill",
        "screen_name" : "JimGoodwill",
        "indices" : [ 3, 15 ],
        "id_str" : "99241895",
        "id" : 99241895
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8062215204",
    "text" : "RT @JimGoodwill My definition of a free society is a society where it is safe to be unpopular. -Adlai E. Stevenson #quote",
    "id" : 8062215204,
    "created_at" : "2010-01-22 08:08:10 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8068638014,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole",
      "screen_name" : "obnoxiousacorns",
      "indices" : [ 0, 16 ],
      "id_str" : "24719145",
      "id" : 24719145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8060276651",
  "geo" : { },
  "id_str" : "8068716762",
  "in_reply_to_user_id" : 24719145,
  "text" : "@obnoxiousacorns wishing you many years of wedded bliss! : )",
  "id" : 8068716762,
  "in_reply_to_status_id" : 8060276651,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "obnoxiousacorns",
  "in_reply_to_user_id_str" : "24719145",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8068769035",
  "text" : "RT @EducateBooks: My reading of history convinces me that most bad government results from too much government. Thomas Jefferson #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8056562587",
    "text" : "My reading of history convinces me that most bad government results from too much government. Thomas Jefferson #quote",
    "id" : 8056562587,
    "created_at" : "2010-01-22 04:15:10 +0000",
    "user" : {
      "name" : "The Dennys",
      "screen_name" : "DoTheMathBooks",
      "protected" : false,
      "id_str" : "69126688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/383388011\/bookworm_normal.gif",
      "id" : 69126688,
      "verified" : false
    }
  },
  "id" : 8068769035,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maura Casey",
      "screen_name" : "Maura_Aura",
      "indices" : [ 3, 14 ],
      "id_str" : "40530952",
      "id" : 40530952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8068842569",
  "text" : "RT @Maura_Aura: Do not wish to be anything but what you are and try to be that perfectly.-St. Francis De Sales",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8057366097",
    "text" : "Do not wish to be anything but what you are and try to be that perfectly.-St. Francis De Sales",
    "id" : 8057366097,
    "created_at" : "2010-01-22 04:40:53 +0000",
    "user" : {
      "name" : "Maura Casey",
      "screen_name" : "Maura_Aura",
      "protected" : false,
      "id_str" : "40530952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438540236318973952\/rMGEdZSm_normal.jpeg",
      "id" : 40530952,
      "verified" : false
    }
  },
  "id" : 8068842569,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8069398851",
  "text" : "RT @BigBookofYou: I've learned....... That just one person saying to me, 'You've made my day!' makes my day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8069067637",
    "text" : "I've learned....... That just one person saying to me, 'You've made my day!' makes my day.",
    "id" : 8069067637,
    "created_at" : "2010-01-22 13:29:05 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 8069398851,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8069670448",
  "text" : "RT @DeepakChopra: No one is wrong. In the eyes of love, all people are doing the best they can from their own levels of consciousness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8041996893",
    "text" : "No one is wrong. In the eyes of love, all people are doing the best they can from their own levels of consciousness.",
    "id" : 8041996893,
    "created_at" : "2010-01-21 21:20:41 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 8069670448,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "indices" : [ 3, 17 ],
      "id_str" : "40923520",
      "id" : 40923520
    }, {
      "name" : "Laurie Hosken, PHR",
      "screen_name" : "LaurieHosken",
      "indices" : [ 22, 35 ],
      "id_str" : "80235953",
      "id" : 80235953
    }, {
      "name" : "Greg Wilson",
      "screen_name" : "GWPStudio",
      "indices" : [ 130, 140 ],
      "id_str" : "19734025",
      "id" : 19734025
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Photography",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8069768199",
  "text" : "RT @GiveTreeGifts: RT @LaurieHosken 10 Geological Wonders you probably didn\u2019t know! Great #Photography -&gt; http:\/\/ow.ly\/UXFd RT @GWPStudio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laurie Hosken, PHR",
        "screen_name" : "LaurieHosken",
        "indices" : [ 3, 16 ],
        "id_str" : "80235953",
        "id" : 80235953
      }, {
        "name" : "Greg Wilson",
        "screen_name" : "GWPStudio",
        "indices" : [ 111, 121 ],
        "id_str" : "19734025",
        "id" : 19734025
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Photography",
        "indices" : [ 71, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8069599621",
    "text" : "RT @LaurieHosken 10 Geological Wonders you probably didn\u2019t know! Great #Photography -&gt; http:\/\/ow.ly\/UXFd RT @GWPStudio",
    "id" : 8069599621,
    "created_at" : "2010-01-22 13:46:52 +0000",
    "user" : {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "protected" : false,
      "id_str" : "40923520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/400026192\/Tree-Angel_jpg_normal.jpg",
      "id" : 40923520,
      "verified" : false
    }
  },
  "id" : 8069768199,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Jordan",
      "screen_name" : "MindfullyChange",
      "indices" : [ 3, 19 ],
      "id_str" : "22987468",
      "id" : 22987468
    }, {
      "name" : "Sandra",
      "screen_name" : "jacoticaba",
      "indices" : [ 21, 32 ],
      "id_str" : "60148697",
      "id" : 60148697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8070026125",
  "text" : "RT @MindfullyChange: @jacoticaba My mission on Twitter involves encouraging people to think, not agree with me. Thanks again Sandra!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandra",
        "screen_name" : "jacoticaba",
        "indices" : [ 0, 11 ],
        "id_str" : "60148697",
        "id" : 60148697
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "8036457992",
    "geo" : { },
    "id_str" : "8036561049",
    "in_reply_to_user_id" : 60148697,
    "text" : "@jacoticaba My mission on Twitter involves encouraging people to think, not agree with me. Thanks again Sandra!",
    "id" : 8036561049,
    "in_reply_to_status_id" : 8036457992,
    "created_at" : "2010-01-21 18:26:24 +0000",
    "in_reply_to_screen_name" : "jacoticaba",
    "in_reply_to_user_id_str" : "60148697",
    "user" : {
      "name" : "Jonathan Jordan",
      "screen_name" : "MindfullyChange",
      "protected" : false,
      "id_str" : "22987468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478242524683718656\/daRMQ1YI_normal.jpeg",
      "id" : 22987468,
      "verified" : false
    }
  },
  "id" : 8070026125,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8070100144",
  "text" : "RT @kimduess: Health Tip: Take responsibility for ur own health. Listen to ur doc but do own research 2. Get 2nd opinions, research on w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8069940284",
    "text" : "Health Tip: Take responsibility for ur own health. Listen to ur doc but do own research 2. Get 2nd opinions, research on web, buy books etc",
    "id" : 8069940284,
    "created_at" : "2010-01-22 13:57:53 +0000",
    "user" : {
      "name" : "You Be Healthy",
      "screen_name" : "you_be_healthy",
      "protected" : false,
      "id_str" : "37557785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459760129\/kim-190-fix-2_3__normal.jpg",
      "id" : 37557785,
      "verified" : false
    }
  },
  "id" : 8070100144,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2B50 Best Tweets Ever \u2B50",
      "screen_name" : "DrJeffersnBoggs",
      "indices" : [ 3, 19 ],
      "id_str" : "15274836",
      "id" : 15274836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8070538038",
  "text" : "RT @DrJeffersnBoggs: Charlie Chaplin once won third prize in a Charlie Chaplin look-alike contest.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8053839712",
    "text" : "Charlie Chaplin once won third prize in a Charlie Chaplin look-alike contest.",
    "id" : 8053839712,
    "created_at" : "2010-01-22 03:01:54 +0000",
    "user" : {
      "name" : "\u2B50 Best Tweets Ever \u2B50",
      "screen_name" : "DrJeffersnBoggs",
      "protected" : false,
      "id_str" : "15274836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549871819751051266\/qHOORH_h_normal.jpeg",
      "id" : 15274836,
      "verified" : false
    }
  },
  "id" : 8070538038,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "indices" : [ 3, 14 ],
      "id_str" : "30795207",
      "id" : 30795207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8070696144",
  "text" : "RT @AlphaMares: http:\/\/twitpic.com\/p5tzh - Just snapped this ...Doc peeking in my office window [it's feeding time]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5632347191",
    "text" : "http:\/\/twitpic.com\/p5tzh - Just snapped this ...Doc peeking in my office window [it's feeding time]",
    "id" : 5632347191,
    "created_at" : "2009-11-11 23:04:43 +0000",
    "user" : {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "protected" : false,
      "id_str" : "30795207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605832622\/bio_frame_normal.jpg",
      "id" : 30795207,
      "verified" : false
    }
  },
  "id" : 8070696144,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "indices" : [ 3, 14 ],
      "id_str" : "30795207",
      "id" : 30795207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8070698477",
  "text" : "RT @AlphaMares: Skip down the hall - sing out loud - hug your dog -draw a picture...remember what it feels like to be 7? TRY IT!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5722091303",
    "text" : "Skip down the hall - sing out loud - hug your dog -draw a picture...remember what it feels like to be 7? TRY IT!",
    "id" : 5722091303,
    "created_at" : "2009-11-14 23:56:04 +0000",
    "user" : {
      "name" : "Debi Blacklidge",
      "screen_name" : "AlphaMares",
      "protected" : false,
      "id_str" : "30795207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605832622\/bio_frame_normal.jpg",
      "id" : 30795207,
      "verified" : false
    }
  },
  "id" : 8070698477,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 14, 25 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 26, 41 ],
      "id_str" : "43012495",
      "id" : 43012495
    }, {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 42, 50 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 51, 63 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "indices" : [ 64, 78 ],
      "id_str" : "40923520",
      "id" : 40923520
    }, {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 79, 88 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "FF",
      "indices" : [ 89, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8071090287",
  "text" : "#FollowFriday @CaplinROUS @abandontheherd @CandyTX @brandonrofl @GiveTreeGifts @Ravish30 #FF",
  "id" : 8071090287,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8070770344",
  "geo" : { },
  "id_str" : "8071139819",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS Thanks Caplin! kisses!",
  "id" : 8071139819,
  "in_reply_to_status_id" : 8070770344,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8071259263",
  "geo" : { },
  "id_str" : "8071476534",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 Aren't you a doll for including me! ; &gt;",
  "id" : 8071476534,
  "in_reply_to_status_id" : 8071259263,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8071515245",
  "text" : "silly cat expects her food freshened every 5 mins!",
  "id" : 8071515245,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 14, 27 ],
      "id_str" : "44163738",
      "id" : 44163738
    }, {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 28, 41 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    }, {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 42, 55 ],
      "id_str" : "14669290",
      "id" : 14669290
    }, {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 56, 69 ],
      "id_str" : "43640071",
      "id" : 43640071
    }, {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 70, 86 ],
      "id_str" : "15615511",
      "id" : 15615511
    }, {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 87, 97 ],
      "id_str" : "29787449",
      "id" : 29787449
    }, {
      "name" : "\u88CF\u57A2\uFF28\uFF2B\uFF34\u30C6\u30E9\u30B9\u30CF\u30A6\u30B9\u6771\u6D0B\u533B\u5B66\u6F22\u65B9\u9662\u3055\u3041",
      "screen_name" : "Lady_GQ",
      "indices" : [ 98, 106 ],
      "id_str" : "772841288907444226",
      "id" : 772841288907444226
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "FF",
      "indices" : [ 107, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8075719739",
  "text" : "#FollowFriday @ralphmacchio @deucehartley @aplacetobark @LaughingBaba @lisarobbinyoung @BeALegacy @Lady_GQ #FF",
  "id" : 8075719739,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8075799753",
  "text" : "sshhh... the cat is playing with hubby's painting tools!",
  "id" : 8075799753,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Zaucha",
      "screen_name" : "czaucha",
      "indices" : [ 3, 11 ],
      "id_str" : "51034077",
      "id" : 51034077
    }, {
      "name" : "Great Minds Quotes",
      "screen_name" : "GreatestQuotes",
      "indices" : [ 16, 31 ],
      "id_str" : "22256645",
      "id" : 22256645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greatminds",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8076881667",
  "text" : "RT @czaucha: RT @GreatestQuotes: \"Never discourage anyone.....who continually makes progress, no matter how slow.\"- Plato #greatminds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Great Minds Quotes",
        "screen_name" : "GreatestQuotes",
        "indices" : [ 3, 18 ],
        "id_str" : "22256645",
        "id" : 22256645
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "greatminds",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8071119688",
    "text" : "RT @GreatestQuotes: \"Never discourage anyone.....who continually makes progress, no matter how slow.\"- Plato #greatminds",
    "id" : 8071119688,
    "created_at" : "2010-01-22 14:33:24 +0000",
    "user" : {
      "name" : "Christopher Zaucha",
      "screen_name" : "czaucha",
      "protected" : false,
      "id_str" : "51034077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521648448412467200\/P26yMHwo_normal.jpeg",
      "id" : 51034077,
      "verified" : false
    }
  },
  "id" : 8076881667,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 0, 13 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8076813639",
  "geo" : { },
  "id_str" : "8078130858",
  "in_reply_to_user_id" : 43640071,
  "text" : "@LaughingBaba Thanks kindly! You are awesome! : )",
  "id" : 8078130858,
  "in_reply_to_status_id" : 8076813639,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "LaughingBaba",
  "in_reply_to_user_id_str" : "43640071",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 0, 16 ],
      "id_str" : "15615511",
      "id" : 15615511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8077760625",
  "geo" : { },
  "id_str" : "8078164804",
  "in_reply_to_user_id" : 15615511,
  "text" : "@lisarobbinyoung YVW.. I think you are very interesting and real. : )",
  "id" : 8078164804,
  "in_reply_to_status_id" : 8077760625,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "lisarobbinyoung",
  "in_reply_to_user_id_str" : "15615511",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8077254896",
  "geo" : { },
  "id_str" : "8078202868",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 sorry to hear that.. I'll send some positive vibes your way.. hugs!",
  "id" : 8078202868,
  "in_reply_to_status_id" : 8077254896,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Aroy",
      "screen_name" : "frankaroy",
      "indices" : [ 3, 13 ],
      "id_str" : "105627686",
      "id" : 105627686
    }, {
      "name" : "Joe Bonsai",
      "screen_name" : "JoeBonsai",
      "indices" : [ 81, 91 ],
      "id_str" : "79249149",
      "id" : 79249149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8079761525",
  "text" : "RT @frankaroy: Fifty beautiful trees. Excellent photos http:\/\/bit.ly\/8CA83D \/via @JoeBonsai\nThese are a \"must see.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Bonsai",
        "screen_name" : "JoeBonsai",
        "indices" : [ 66, 76 ],
        "id_str" : "79249149",
        "id" : 79249149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8079533001",
    "text" : "Fifty beautiful trees. Excellent photos http:\/\/bit.ly\/8CA83D \/via @JoeBonsai\nThese are a \"must see.\"",
    "id" : 8079533001,
    "created_at" : "2010-01-22 18:33:31 +0000",
    "user" : {
      "name" : "Frank Aroy",
      "screen_name" : "frankaroy",
      "protected" : false,
      "id_str" : "105627686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1749796170\/image_normal.jpg",
      "id" : 105627686,
      "verified" : false
    }
  },
  "id" : 8079761525,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8080481560",
  "geo" : { },
  "id_str" : "8080592724",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 ohh, I like him, too! : )",
  "id" : 8080592724,
  "in_reply_to_status_id" : 8080481560,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8081167811",
  "text" : "RT @lisarobbinyoung: In order to leave a wake in the water, one must make at least a few small waves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8080881227",
    "text" : "In order to leave a wake in the water, one must make at least a few small waves.",
    "id" : 8080881227,
    "created_at" : "2010-01-22 19:15:12 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 8081167811,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Silver",
      "screen_name" : "thesilverbar",
      "indices" : [ 20, 33 ],
      "id_str" : "73424318",
      "id" : 73424318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8085759705",
  "text" : "RT @brandonrofl: RT @thesilverbar Anger makes you smaller, while forgiveness forces you to grow beyond what you were. -Cherie Carter-Sco ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Silver",
        "screen_name" : "thesilverbar",
        "indices" : [ 3, 16 ],
        "id_str" : "73424318",
        "id" : 73424318
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 122, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8085485620",
    "text" : "RT @thesilverbar Anger makes you smaller, while forgiveness forces you to grow beyond what you were. -Cherie Carter-Scott #quote",
    "id" : 8085485620,
    "created_at" : "2010-01-22 21:40:45 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8085759705,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    }, {
      "name" : "GeekGyrls",
      "screen_name" : "geekgyrls",
      "indices" : [ 52, 62 ],
      "id_str" : "22953085",
      "id" : 22953085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8087114083",
  "text" : "RT @CandyTX: My latest post on Geek Gyrls --&gt; RT @geekgyrls: New blog post: Flip Ultra vs Mino http:\/\/dqqqw.th8.us",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GeekGyrls",
        "screen_name" : "geekgyrls",
        "indices" : [ 39, 49 ],
        "id_str" : "22953085",
        "id" : 22953085
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8086570680",
    "text" : "My latest post on Geek Gyrls --&gt; RT @geekgyrls: New blog post: Flip Ultra vs Mino http:\/\/dqqqw.th8.us",
    "id" : 8086570680,
    "created_at" : "2010-01-22 22:14:18 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 8087114083,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u88CF\u57A2\uFF28\uFF2B\uFF34\u30C6\u30E9\u30B9\u30CF\u30A6\u30B9\u6771\u6D0B\u533B\u5B66\u6F22\u65B9\u9662\u3055\u3041",
      "screen_name" : "Lady_GQ",
      "indices" : [ 0, 8 ],
      "id_str" : "772841288907444226",
      "id" : 772841288907444226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8087129603",
  "text" : "@Lady_GQ Thanks, your a doll! : )",
  "id" : 8087129603,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rabbi Rami",
      "screen_name" : "rabbirami",
      "indices" : [ 3, 13 ],
      "id_str" : "15019273",
      "id" : 15019273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8088290898",
  "text" : "RT @rabbirami: Focus on the good. Ignore the Neo-Nazis and get yourself a puppy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7916301201",
    "text" : "Focus on the good. Ignore the Neo-Nazis and get yourself a puppy.",
    "id" : 7916301201,
    "created_at" : "2010-01-18 20:02:18 +0000",
    "user" : {
      "name" : "Rabbi Rami",
      "screen_name" : "rabbirami",
      "protected" : false,
      "id_str" : "15019273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/298162683\/Best_Photo_normal.jpg",
      "id" : 15019273,
      "verified" : false
    }
  },
  "id" : 8088290898,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    }, {
      "name" : "ABC News",
      "screen_name" : "abcnews",
      "indices" : [ 50, 58 ],
      "id_str" : "2768501",
      "id" : 2768501
    }, {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 100, 109 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8088784710",
  "text" : "RT @OMGFacts: Find out in a recent interview with @ABCNews on what happened and what will happen to @OMGFacts. http:\/\/bit.ly\/7yeKAw #omg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "abcnews",
        "indices" : [ 36, 44 ],
        "id_str" : "2768501",
        "id" : 2768501
      }, {
        "name" : "OMG Facts",
        "screen_name" : "OMGFacts",
        "indices" : [ 86, 95 ],
        "id_str" : "77888423",
        "id" : 77888423
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "omgfacts",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8088300114",
    "text" : "Find out in a recent interview with @ABCNews on what happened and what will happen to @OMGFacts. http:\/\/bit.ly\/7yeKAw #omgfacts",
    "id" : 8088300114,
    "created_at" : "2010-01-22 23:07:23 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 8088784710,
  "created_at" : "2010-01-22 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "indices" : [ 3, 17 ],
      "id_str" : "40923520",
      "id" : 40923520
    }, {
      "name" : "Sara Roderick",
      "screen_name" : "LgreenA",
      "indices" : [ 57, 65 ],
      "id_str" : "60720204",
      "id" : 60720204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8033335512",
  "text" : "RT @GiveTreeGifts: This is FREE!  Please RT everyone! RT @LgreenA    Click to help Haiti: http:\/\/www.care2.com\/click-to-donate\/haiti\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sara Roderick",
        "screen_name" : "LgreenA",
        "indices" : [ 38, 46 ],
        "id_str" : "60720204",
        "id" : 60720204
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8009513444",
    "text" : "This is FREE!  Please RT everyone! RT @LgreenA    Click to help Haiti: http:\/\/www.care2.com\/click-to-donate\/haiti\/",
    "id" : 8009513444,
    "created_at" : "2010-01-21 01:53:49 +0000",
    "user" : {
      "name" : "Joanne Wotherspoon",
      "screen_name" : "GiveTreeGifts",
      "protected" : false,
      "id_str" : "40923520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/400026192\/Tree-Angel_jpg_normal.jpg",
      "id" : 40923520,
      "verified" : false
    }
  },
  "id" : 8033335512,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8037773431",
  "text" : "RT @Ravish30: If anyone is looking for a chance to win a Sony Book Reader --- http:\/\/bookgiveaways.blogspot.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8036613057",
    "text" : "If anyone is looking for a chance to win a Sony Book Reader --- http:\/\/bookgiveaways.blogspot.com",
    "id" : 8036613057,
    "created_at" : "2010-01-21 18:28:02 +0000",
    "user" : {
      "name" : "\u2665 Shelly - Louise",
      "screen_name" : "ClassyChicShel",
      "protected" : false,
      "id_str" : "23845064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749025439058956288\/2a5boEDx_normal.jpg",
      "id" : 23845064,
      "verified" : false
    }
  },
  "id" : 8037773431,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8036190817",
  "geo" : { },
  "id_str" : "8037817060",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 ya, me, too.. hehe!",
  "id" : 8037817060,
  "in_reply_to_status_id" : 8036190817,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8037854825",
  "text" : "RT @ChrisCade: \"We are all faced with a series of great opportunities brilliantly disguised as impossible situations.\" ~ Charles R. Swindoll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8035297424",
    "text" : "\"We are all faced with a series of great opportunities brilliantly disguised as impossible situations.\" ~ Charles R. Swindoll",
    "id" : 8035297424,
    "created_at" : "2010-01-21 17:46:27 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 8037854825,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Trudeau",
      "screen_name" : "KevinTrudeau",
      "indices" : [ 3, 16 ],
      "id_str" : "17198504",
      "id" : 17198504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8037935376",
  "text" : "RT @KevinTrudeau: Millions in Kickbacks from Johnson & Johnson http:\/\/bit.ly\/4KOYVq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8034639561",
    "text" : "Millions in Kickbacks from Johnson & Johnson http:\/\/bit.ly\/4KOYVq",
    "id" : 8034639561,
    "created_at" : "2010-01-21 17:25:50 +0000",
    "user" : {
      "name" : "Kevin Trudeau",
      "screen_name" : "KevinTrudeau",
      "protected" : false,
      "id_str" : "17198504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/93095715\/Kevin-Trudeau_normal.jpg",
      "id" : 17198504,
      "verified" : false
    }
  },
  "id" : 8037935376,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8038033289",
  "text" : "somehow hubby roped me into his cleaning spree : (",
  "id" : 8038033289,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8042359063",
  "text" : "RT @brandonrofl: Help me get 15,000 followers? Tell your people to follow me, and i'll return the favor :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8042251985",
    "text" : "Help me get 15,000 followers? Tell your people to follow me, and i'll return the favor :)",
    "id" : 8042251985,
    "created_at" : "2010-01-21 21:28:46 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8042359063,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8042675168",
  "text" : "bad cold + clean daughter's room = I'm tired.. and still have taekwondo tonight...",
  "id" : 8042675168,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Fuck Yo Team",
      "screen_name" : "CheddarChad",
      "indices" : [ 20, 32 ],
      "id_str" : "190811927",
      "id" : 190811927
    }, {
      "name" : "Ann Tran",
      "screen_name" : "TrendyDC",
      "indices" : [ 36, 45 ],
      "id_str" : "188573761",
      "id" : 188573761
    }, {
      "name" : "Massimo Lombardo",
      "screen_name" : "Mlomb",
      "indices" : [ 128, 134 ],
      "id_str" : "455059002",
      "id" : 455059002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 117, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8043980531",
  "text" : "RT @brandonrofl: RT @CheddarChad RT @TrendyDC: Where there is anger, there is always pain underneath - Eckhart Tolle #quote via @mlomb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fuck Yo Team",
        "screen_name" : "CheddarChad",
        "indices" : [ 3, 15 ],
        "id_str" : "190811927",
        "id" : 190811927
      }, {
        "name" : "Ann Tran",
        "screen_name" : "TrendyDC",
        "indices" : [ 19, 28 ],
        "id_str" : "188573761",
        "id" : 188573761
      }, {
        "name" : "Massimo Lombardo",
        "screen_name" : "Mlomb",
        "indices" : [ 111, 117 ],
        "id_str" : "455059002",
        "id" : 455059002
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 100, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8043787148",
    "text" : "RT @CheddarChad RT @TrendyDC: Where there is anger, there is always pain underneath - Eckhart Tolle #quote via @mlomb",
    "id" : 8043787148,
    "created_at" : "2010-01-21 22:16:18 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 8043980531,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8045041117",
  "text" : "Can one go insane from inside ear itching??",
  "id" : 8045041117,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 0, 13 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8045232310",
  "text" : "@deucehartley hehe.. got bad cold and it's messing with my ears.. ugh",
  "id" : 8045232310,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8009463731",
  "text" : "RT @BigBookofYou: Always forgive your enemies - nothing annoys them so much. Oscar Wilde #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8007038151",
    "text" : "Always forgive your enemies - nothing annoys them so much. Oscar Wilde #quote",
    "id" : 8007038151,
    "created_at" : "2010-01-21 00:43:11 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 8009463731,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8009522142",
  "text" : "RT @twitingly: Living on Earth may be expensive, but it includes an annual free trip around the Sun.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8004351533",
    "text" : "Living on Earth may be expensive, but it includes an annual free trip around the Sun.",
    "id" : 8004351533,
    "created_at" : "2010-01-20 23:25:05 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 8009522142,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8009544518",
  "text" : "RT @twitingly: Astronomers say the universe is finite, which is a comforting thought for those people who can't remember where they leav ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8004345103",
    "text" : "Astronomers say the universe is finite, which is a comforting thought for those people who can't remember where they leave things.",
    "id" : 8004345103,
    "created_at" : "2010-01-20 23:24:54 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 8009544518,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8009563908",
  "text" : "RT @twitingly: Sometimes insanity is the only alternative.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8004320315",
    "text" : "Sometimes insanity is the only alternative.",
    "id" : 8004320315,
    "created_at" : "2010-01-20 23:24:09 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 8009563908,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8009583973",
  "text" : "RT @twitingly: This life is your gift to yourself...Open it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8004281258",
    "text" : "This life is your gift to yourself...Open it!",
    "id" : 8004281258,
    "created_at" : "2010-01-20 23:23:00 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 8009583973,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8009774632",
  "text" : "RT @taraburner: \u201CThere is only one you for all time. Fearlessly be yourself.\u201D \u2014Anthony Rapp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8009507997",
    "text" : "\u201CThere is only one you for all time. Fearlessly be yourself.\u201D \u2014Anthony Rapp",
    "id" : 8009507997,
    "created_at" : "2010-01-21 01:53:40 +0000",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 8009774632,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8009286632",
  "geo" : { },
  "id_str" : "8009848772",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS I'm partial to aussie sheps but I can see the joy of having a capybara from your videos! : )",
  "id" : 8009848772,
  "in_reply_to_status_id" : 8009286632,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8009873833",
  "text" : "hallelujah.. my brown sock was once lost but now found!!",
  "id" : 8009873833,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8025759940",
  "text" : "You are fired up at work today and could be quite productive o... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 8025759940,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8026237106",
  "text" : "RT @Encouraging: Just for today, enjoy people. Yes, they\u2019re \u201Cfunny\u201D but then again, so are you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8024835333",
    "text" : "Just for today, enjoy people. Yes, they\u2019re \u201Cfunny\u201D but then again, so are you!",
    "id" : 8024835333,
    "created_at" : "2010-01-21 12:12:02 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 8026237106,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8026842243",
  "text" : "RT @BigBookofYou: I saw the angel in the marble and carved until I set him free. Michelangelo #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8026309099",
    "text" : "I saw the angel in the marble and carved until I set him free. Michelangelo #quote",
    "id" : 8026309099,
    "created_at" : "2010-01-21 13:08:06 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 8026842243,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Schumacher",
      "screen_name" : "gelbevideos",
      "indices" : [ 3, 15 ],
      "id_str" : "19483682",
      "id" : 19483682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8026982134",
  "text" : "RT @gelbevideos: Everything you can imagine is real.Pablo Picasso",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8024975327",
    "text" : "Everything you can imagine is real.Pablo Picasso",
    "id" : 8024975327,
    "created_at" : "2010-01-21 12:17:49 +0000",
    "user" : {
      "name" : "Fred Schumacher",
      "screen_name" : "gelbevideos",
      "protected" : false,
      "id_str" : "19483682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459081315703214080\/EyLxWGnV_normal.jpeg",
      "id" : 19483682,
      "verified" : false
    }
  },
  "id" : 8026982134,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8026986176",
  "text" : "RT @BigBookofYou: Success is the sum of small efforts, repeated day in and day out. Robert Collier #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 81, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8024837004",
    "text" : "Success is the sum of small efforts, repeated day in and day out. Robert Collier #quote",
    "id" : 8024837004,
    "created_at" : "2010-01-21 12:12:05 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 8026986176,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Zaucha",
      "screen_name" : "czaucha",
      "indices" : [ 3, 11 ],
      "id_str" : "51034077",
      "id" : 51034077
    }, {
      "name" : "Drie Ferdian",
      "screen_name" : "Ferdianz",
      "indices" : [ 16, 25 ],
      "id_str" : "32591770",
      "id" : 32591770
    }, {
      "name" : "B2BSalesConnections",
      "screen_name" : "SusanEnns",
      "indices" : [ 30, 40 ],
      "id_str" : "85385401",
      "id" : 85385401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8027226099",
  "text" : "RT @czaucha: RT @Ferdianz: RT @SusanEnns: \"You will never leave where you are, until you decide where you'd rather be.\" - Dexter Yager.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Drie Ferdian",
        "screen_name" : "Ferdianz",
        "indices" : [ 3, 12 ],
        "id_str" : "32591770",
        "id" : 32591770
      }, {
        "name" : "B2BSalesConnections",
        "screen_name" : "SusanEnns",
        "indices" : [ 17, 27 ],
        "id_str" : "85385401",
        "id" : 85385401
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quotes",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8026871309",
    "text" : "RT @Ferdianz: RT @SusanEnns: \"You will never leave where you are, until you decide where you'd rather be.\" - Dexter Yager.  #quotes",
    "id" : 8026871309,
    "created_at" : "2010-01-21 13:28:10 +0000",
    "user" : {
      "name" : "Christopher Zaucha",
      "screen_name" : "czaucha",
      "protected" : false,
      "id_str" : "51034077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521648448412467200\/P26yMHwo_normal.jpeg",
      "id" : 51034077,
      "verified" : false
    }
  },
  "id" : 8027226099,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Aroy",
      "screen_name" : "frankaroy",
      "indices" : [ 3, 13 ],
      "id_str" : "105627686",
      "id" : 105627686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8027867134",
  "text" : "RT @frankaroy: @amysaia NO, you are NOT talking to yourself. You're simply talking to lazy people who enjoy your tweets, but don't tweet ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8007135772",
    "text" : "@amysaia NO, you are NOT talking to yourself. You're simply talking to lazy people who enjoy your tweets, but don't tweet back. Sorry!!",
    "id" : 8007135772,
    "created_at" : "2010-01-21 00:46:02 +0000",
    "user" : {
      "name" : "Frank Aroy",
      "screen_name" : "frankaroy",
      "protected" : false,
      "id_str" : "105627686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1749796170\/image_normal.jpg",
      "id" : 105627686,
      "verified" : false
    }
  },
  "id" : 8027867134,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Green Valley Store",
      "screen_name" : "GV_store",
      "indices" : [ 3, 12 ],
      "id_str" : "829220486",
      "id" : 829220486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8027871679",
  "text" : "RT @GV_Store: \"The difference between the hero and the coward is that the hero sticks in there five minutes longer.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8001640566",
    "text" : "\"The difference between the hero and the coward is that the hero sticks in there five minutes longer.\"",
    "id" : 8001640566,
    "created_at" : "2010-01-20 22:04:39 +0000",
    "user" : {
      "name" : "Sunshine",
      "screen_name" : "Raiinbows",
      "protected" : false,
      "id_str" : "105214847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1159321675\/images1_normal.jpg",
      "id" : 105214847,
      "verified" : false
    }
  },
  "id" : 8027871679,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "defythemind",
      "indices" : [ 3, 15 ],
      "id_str" : "279751736",
      "id" : 279751736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8027960318",
  "text" : "RT @DefyTheMind: The only thing that keeps you from having what you want, is the story you tell yourself about why you can't have it.  # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 118, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8027224684",
    "text" : "The only thing that keeps you from having what you want, is the story you tell yourself about why you can't have it.  #quote",
    "id" : 8027224684,
    "created_at" : "2010-01-21 13:40:04 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 8027960318,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8027991313",
  "text" : "hubby just warned me.. \"it's going to be a busy day\".. he's cleaning house.. ACK!",
  "id" : 8027991313,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twilk.com\" rel=\"nofollow\"\u003ETwilk.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8028441757",
  "text" : "Just used http:\/\/twilk.com to put my friends' faces on my Twitter background. Check it out!",
  "id" : 8028441757,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "indices" : [ 3, 14 ],
      "id_str" : "14461139",
      "id" : 14461139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8029208497",
  "text" : "RT @coachkaren: Your desire for success has to be stronger than your fear of failure. http:\/\/bit.ly\/8fPJ2I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8029108957",
    "text" : "Your desire for success has to be stronger than your fear of failure. http:\/\/bit.ly\/8fPJ2I",
    "id" : 8029108957,
    "created_at" : "2010-01-21 14:40:02 +0000",
    "user" : {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "protected" : false,
      "id_str" : "14461139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1747699492\/KarenWalker_normal.jpg",
      "id" : 14461139,
      "verified" : false
    }
  },
  "id" : 8029208497,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Aroy",
      "screen_name" : "frankaroy",
      "indices" : [ 0, 10 ],
      "id_str" : "105627686",
      "id" : 105627686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "8028947371",
  "geo" : { },
  "id_str" : "8029221992",
  "in_reply_to_user_id" : 105627686,
  "text" : "@frankaroy LOL",
  "id" : 8029221992,
  "in_reply_to_status_id" : 8028947371,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "frankaroy",
  "in_reply_to_user_id_str" : "105627686",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8029974532",
  "text" : "And the day came when the risk to remain tight in a bud was more painful than the risk it took to blossom. -- Ana\u00EFs Nin",
  "id" : 8029974532,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8030251997",
  "text" : "hubby is my mirror.. my thoughts are reflected in his words and actions.. way cool!",
  "id" : 8030251997,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8030303663",
  "text" : "Once you wake up, you change what you give attention to.. you see the world in a new way and it's awesome!",
  "id" : 8030303663,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8030786854",
  "text" : "RT @BeALegacy: \"What you leave behind is not what is engraved in stone monuments, but what is woven into the lives of others.\u201D ~ Pericles",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8030440140",
    "text" : "\"What you leave behind is not what is engraved in stone monuments, but what is woven into the lives of others.\u201D ~ Pericles",
    "id" : 8030440140,
    "created_at" : "2010-01-21 15:20:13 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 8030786854,
  "created_at" : "2010-01-21 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7983981740",
  "text" : "Although you might feel persistent resistance from a powerful ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7983981740,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 0, 11 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7984089686",
  "geo" : { },
  "id_str" : "7984407693",
  "in_reply_to_user_id" : 15467920,
  "text" : "@taraburner hope you have a wonderful birthday!",
  "id" : 7984407693,
  "in_reply_to_status_id" : 7984089686,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "taraburner",
  "in_reply_to_user_id_str" : "15467920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7984521688",
  "text" : "36 months ago we brought home a small furry girl who brought cheer to a sad family. Her wiggles continue to give us joy every day!",
  "id" : 7984521688,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7984914109",
  "text" : "RT @BigBookofYou: \"All life is an experiment. The more experiments you make the better.\" - Ralph Waldo Emerson #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 93, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7971340631",
    "text" : "\"All life is an experiment. The more experiments you make the better.\" - Ralph Waldo Emerson #quote",
    "id" : 7971340631,
    "created_at" : "2010-01-20 02:54:10 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 7984914109,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7969881796",
  "geo" : { },
  "id_str" : "7985174794",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS good job Caplin, that's hard work!",
  "id" : 7985174794,
  "in_reply_to_status_id" : 7969881796,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Mead",
      "screen_name" : "jonathanmead",
      "indices" : [ 69, 82 ],
      "id_str" : "14126982",
      "id" : 14126982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7985817000",
  "text" : "The Zero Hour Workweek: http:\/\/budurl.com\/0HWW \u2014 new free ebook from @jonathanmead",
  "id" : 7985817000,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7986695667",
  "text" : "RT @RevAnne1: EFT Affirm I allow my learning to be fun & easy. I choose fun & easy! Learning IS easy & fun! http:\/\/ThinkitBeitSeeit.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7986606517",
    "text" : "EFT Affirm I allow my learning to be fun & easy. I choose fun & easy! Learning IS easy & fun! http:\/\/ThinkitBeitSeeit.com",
    "id" : 7986606517,
    "created_at" : "2010-01-20 14:13:41 +0000",
    "user" : {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "protected" : false,
      "id_str" : "25058557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212762820\/507W6716aDONEa1_normal.jpg",
      "id" : 25058557,
      "verified" : false
    }
  },
  "id" : 7986695667,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "indices" : [ 3, 17 ],
      "id_str" : "69318532",
      "id" : 69318532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7987888271",
  "text" : "RT @MyBizPresence: you found your calling, now learn how to get clients during this FREE call: http:\/\/bit.ly\/8wGXAG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7987672452",
    "text" : "you found your calling, now learn how to get clients during this FREE call: http:\/\/bit.ly\/8wGXAG",
    "id" : 7987672452,
    "created_at" : "2010-01-20 14:45:49 +0000",
    "user" : {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "protected" : false,
      "id_str" : "69318532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748607898406645761\/us3mLEKn_normal.jpg",
      "id" : 69318532,
      "verified" : false
    }
  },
  "id" : 7987888271,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7988183524",
  "text" : "need to find new hiding spot for my chocolate. daughter saw it and keeps asking \"are you going to eat those?\"",
  "id" : 7988183524,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7988411720",
  "text" : "RT @taraburner: To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment-Ralph Wald ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7988339863",
    "text" : "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment-Ralph Waldo Emerson",
    "id" : 7988339863,
    "created_at" : "2010-01-20 15:06:07 +0000",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 7988411720,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7991844538",
  "text" : "RT @ChrisCade: \u201CI have been all things unholy; if God can work through me, he can work through anyone.\u201D ~ St. Francis of Assisi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7991639580",
    "text" : "\u201CI have been all things unholy; if God can work through me, he can work through anyone.\u201D ~ St. Francis of Assisi",
    "id" : 7991639580,
    "created_at" : "2010-01-20 16:45:54 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7991844538,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7991845895",
  "text" : "RT @ChrisCade: \u201CEvery successful, truly happy person that I have encountered has confirmed their knowing that there are simply no accide ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7991692291",
    "text" : "\u201CEvery successful, truly happy person that I have encountered has confirmed their knowing that there are simply no accidents.\u201D ~  Wayne Dyer",
    "id" : 7991692291,
    "created_at" : "2010-01-20 16:47:33 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7991845895,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "indices" : [ 3, 15 ],
      "id_str" : "23273932",
      "id" : 23273932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "8002354956",
  "text" : "RT @CuresCancer: Got pain? Get this. Free. http:\/\/ItReallyHurts.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "8001450528",
    "text" : "Got pain? Get this. Free. http:\/\/ItReallyHurts.com",
    "id" : 8001450528,
    "created_at" : "2010-01-20 21:58:49 +0000",
    "user" : {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "protected" : false,
      "id_str" : "23273932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609239639358988288\/AZfiLu4b_normal.png",
      "id" : 23273932,
      "verified" : false
    }
  },
  "id" : 8002354956,
  "created_at" : "2010-01-20 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7954065688",
  "text" : "RT @ChrisCade: \"Tenderness and kindness are not signs of weakness and despair, but manifestations of strength and resolution.\" ~ Khalil  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7953761135",
    "text" : "\"Tenderness and kindness are not signs of weakness and despair, but manifestations of strength and resolution.\" ~ Khalil Gibran",
    "id" : 7953761135,
    "created_at" : "2010-01-19 17:57:55 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7954065688,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7955596880",
  "text" : "RT @SheilaWalsh: Woman beside me is in a foul mood, I'm watching how it impacts all around her. Everything we do matters",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7955555261",
    "text" : "Woman beside me is in a foul mood, I'm watching how it impacts all around her. Everything we do matters",
    "id" : 7955555261,
    "created_at" : "2010-01-19 18:56:46 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 7955596880,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7957108390",
  "text" : "RT @BigBookofYou: The art of being wise is knowing what to overlook. William James #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7956964886",
    "text" : "The art of being wise is knowing what to overlook. William James #quote",
    "id" : 7956964886,
    "created_at" : "2010-01-19 19:43:08 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 7957108390,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7957763651",
  "text" : "RT @ChrisCade: \"What is love?\" \"The total absence of fear,\" said the Master. \"What is it we fear?\" \"Love,\" said the Master ~ Anthony de  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7957714455",
    "text" : "\"What is love?\" \"The total absence of fear,\" said the Master. \"What is it we fear?\" \"Love,\" said the Master ~ Anthony de Mello",
    "id" : 7957714455,
    "created_at" : "2010-01-19 20:07:50 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7957763651,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7960073213",
  "text" : "RT @BeALegacy: When u boldly declare ur dreams & goals people w\/ similar dreams & goals will create a bond with u so they too can be suc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7959838092",
    "text" : "When u boldly declare ur dreams & goals people w\/ similar dreams & goals will create a bond with u so they too can be successful.",
    "id" : 7959838092,
    "created_at" : "2010-01-19 21:16:03 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 7960073213,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7963480333",
  "text" : "RT @mercola: Why did the FDA implement TANNING TAX? How on earth could this ridiculous law ever get passed? http:\/\/bit.ly\/75yb3U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7963257811",
    "text" : "Why did the FDA implement TANNING TAX? How on earth could this ridiculous law ever get passed? http:\/\/bit.ly\/75yb3U",
    "id" : 7963257811,
    "created_at" : "2010-01-19 23:00:08 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 7963480333,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MB's eBookNewser",
      "screen_name" : "eBookNewser",
      "indices" : [ 3, 15 ],
      "id_str" : "509372493",
      "id" : 509372493
    }, {
      "name" : "Tin House",
      "screen_name" : "Tin_House",
      "indices" : [ 52, 62 ],
      "id_str" : "22190395",
      "id" : 22190395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7963494362",
  "text" : "RT @eBookNewser: The most successful Kindle Book at @Tin_House may surprise you: http:\/\/bit.ly\/8P9zAK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tin House",
        "screen_name" : "Tin_House",
        "indices" : [ 35, 45 ],
        "id_str" : "22190395",
        "id" : 22190395
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7963181686",
    "text" : "The most successful Kindle Book at @Tin_House may surprise you: http:\/\/bit.ly\/8P9zAK",
    "id" : 7963181686,
    "created_at" : "2010-01-19 22:57:51 +0000",
    "user" : {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "protected" : false,
      "id_str" : "90893629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461987151496744960\/7LSAvXUw_normal.png",
      "id" : 90893629,
      "verified" : false
    }
  },
  "id" : 7963494362,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7963668494",
  "text" : "RT @ChrisCade: \"Positive\" and \"Negative\" are not judgments - they are polarities. Choose your directions and alignments consciously.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7963494284",
    "text" : "\"Positive\" and \"Negative\" are not judgments - they are polarities. Choose your directions and alignments consciously.",
    "id" : 7963494284,
    "created_at" : "2010-01-19 23:06:57 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7963668494,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7964570798",
  "text" : "hubby is playing with my christmas camera...",
  "id" : 7964570798,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7925122581",
  "text" : "RT @BigBookofYou: Be faithful in small things because it is in them that your strength lies. Mother Teresa #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 89, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7924578852",
    "text" : "Be faithful in small things because it is in them that your strength lies. Mother Teresa #quote",
    "id" : 7924578852,
    "created_at" : "2010-01-19 00:17:11 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 7925122581,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanley Pinkerton",
      "screen_name" : "Mr_Pinkerton",
      "indices" : [ 3, 16 ],
      "id_str" : "14886197",
      "id" : 14886197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7925136354",
  "text" : "RT @Mr_Pinkerton: More of what people would learn if dogs were their teachers: When you're happy, dance around and wag your entire body.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7923842406",
    "text" : "More of what people would learn if dogs were their teachers: When you're happy, dance around and wag your entire body.",
    "id" : 7923842406,
    "created_at" : "2010-01-18 23:55:05 +0000",
    "user" : {
      "name" : "Stanley Pinkerton",
      "screen_name" : "Mr_Pinkerton",
      "protected" : false,
      "id_str" : "14886197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466695969782763520\/ueFcrOTs_normal.png",
      "id" : 14886197,
      "verified" : false
    }
  },
  "id" : 7925136354,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Kitzmiller",
      "screen_name" : "JimKitzmiller",
      "indices" : [ 3, 17 ],
      "id_str" : "17081275",
      "id" : 17081275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7925178035",
  "text" : "RT @JimKitzmiller: Blessings are everywhere. We just need to see them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7923503317",
    "text" : "Blessings are everywhere. We just need to see them.",
    "id" : 7923503317,
    "created_at" : "2010-01-18 23:44:56 +0000",
    "user" : {
      "name" : "Jim Kitzmiller",
      "screen_name" : "JimKitzmiller",
      "protected" : false,
      "id_str" : "17081275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2784880051\/475564817d2f0df0d68361ce52c296cf_normal.jpeg",
      "id" : 17081275,
      "verified" : false
    }
  },
  "id" : 7925178035,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7925257050",
  "text" : "RT @abandontheherd: It's all about love",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7922470384",
    "text" : "It's all about love",
    "id" : 7922470384,
    "created_at" : "2010-01-18 23:14:09 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7925257050,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7926537018",
  "geo" : { },
  "id_str" : "7927021052",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS yes I did and you are so nice to try to be helpful carrying the pieces to your owner!",
  "id" : 7927021052,
  "in_reply_to_status_id" : 7926537018,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Umstattd",
      "screen_name" : "karenu",
      "indices" : [ 3, 10 ],
      "id_str" : "15877211",
      "id" : 15877211
    }, {
      "name" : "Chris Brady",
      "screen_name" : "RascalTweets",
      "indices" : [ 15, 28 ],
      "id_str" : "18485106",
      "id" : 18485106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7927195803",
  "text" : "RT @karenu: RT @RascalTweets   Worry is the process of trying to fix things that haven't broken yet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.onthecity.org\" rel=\"nofollow\"\u003EThe City\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Brady",
        "screen_name" : "RascalTweets",
        "indices" : [ 3, 16 ],
        "id_str" : "18485106",
        "id" : 18485106
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7926764216",
    "text" : "RT @RascalTweets   Worry is the process of trying to fix things that haven't broken yet.",
    "id" : 7926764216,
    "created_at" : "2010-01-19 01:22:39 +0000",
    "user" : {
      "name" : "Karen Umstattd",
      "screen_name" : "karenu",
      "protected" : false,
      "id_str" : "15877211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728239341479190528\/1QxXuaBV_normal.jpg",
      "id" : 15877211,
      "verified" : false
    }
  },
  "id" : 7927195803,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7927884283",
  "geo" : { },
  "id_str" : "7928715660",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS You're such a good capybara!",
  "id" : 7928715660,
  "in_reply_to_status_id" : 7927884283,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7943790564",
  "text" : "If you don't want everyone to know what you're up to now, you ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7943790564,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Arun Charles",
      "screen_name" : "livetorque",
      "indices" : [ 20, 31 ],
      "id_str" : "29600506",
      "id" : 29600506
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "you",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7945131226",
  "text" : "RT @Encouraging: RT @livetorque Hugs are to squeeze the pain out of #you!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arun Charles",
        "screen_name" : "livetorque",
        "indices" : [ 3, 14 ],
        "id_str" : "29600506",
        "id" : 29600506
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "you",
        "indices" : [ 51, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7943016722",
    "text" : "RT @livetorque Hugs are to squeeze the pain out of #you!!!",
    "id" : 7943016722,
    "created_at" : "2010-01-19 12:07:57 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7945131226,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7945321753",
  "text" : "RT @ChrisCade: \u201CDon't miss all the beautiful colors of the rainbow looking for that pot of gold.\u201D ~unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7935460474",
    "text" : "\u201CDon't miss all the beautiful colors of the rainbow looking for that pot of gold.\u201D ~unknown",
    "id" : 7935460474,
    "created_at" : "2010-01-19 05:53:05 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7945321753,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IlluminativeVisions",
      "screen_name" : "Illumnative_Vis",
      "indices" : [ 3, 19 ],
      "id_str" : "103718492",
      "id" : 103718492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7945392444",
  "text" : "RT @Illumnative_Vis: Treat people as if they were what they ought to be, & you help them become what they are capable of becoming. Van G ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7931668462",
    "text" : "Treat people as if they were what they ought to be, & you help them become what they are capable of becoming. Van Goethe",
    "id" : 7931668462,
    "created_at" : "2010-01-19 03:45:56 +0000",
    "user" : {
      "name" : "IlluminativeVisions",
      "screen_name" : "Illumnative_Vis",
      "protected" : false,
      "id_str" : "103718492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1168008902\/asian_sunrisemodified_normal.png",
      "id" : 103718492,
      "verified" : false
    }
  },
  "id" : 7945392444,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7945455012",
  "text" : "RT @BigBookofYou: A true friend never gets in your way unless you happen to be going down. Arnold H. Glasow #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7931163178",
    "text" : "A true friend never gets in your way unless you happen to be going down. Arnold H. Glasow #quote",
    "id" : 7931163178,
    "created_at" : "2010-01-19 03:31:16 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 7945455012,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7945609535",
  "text" : "ah, real coffee today. hubby is redeemed.. lol",
  "id" : 7945609535,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7948655131",
  "text" : "Do not conform any longer to the pattern of this world, but be transformed by the renewing of your mind. Rom 12:2",
  "id" : 7948655131,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7949647029",
  "geo" : { },
  "id_str" : "7949731945",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd AMEN!!",
  "id" : 7949731945,
  "in_reply_to_status_id" : 7949647029,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 0, 10 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7949101909",
  "geo" : { },
  "id_str" : "7950399028",
  "in_reply_to_user_id" : 29787449,
  "text" : "@BeALegacy Here's a ((hug)) : )",
  "id" : 7950399028,
  "in_reply_to_status_id" : 7949101909,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "BeALegacy",
  "in_reply_to_user_id_str" : "29787449",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7952928747",
  "text" : "our aussie watches as the cat eats out of the dog bowl.. too funny!",
  "id" : 7952928747,
  "created_at" : "2010-01-19 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the piece movement",
      "screen_name" : "piece2dot0",
      "indices" : [ 3, 14 ],
      "id_str" : "19613202",
      "id" : 19613202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7882586770",
  "text" : "RT @piece2dot0: Life is real!  Life is earnest!  And the grave is not its goal; Dust thou art, to dust returnest, was not spoken of the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7869860611",
    "text" : "Life is real!  Life is earnest!  And the grave is not its goal; Dust thou art, to dust returnest, was not spoken of the soul~Longfellow",
    "id" : 7869860611,
    "created_at" : "2010-01-17 17:21:06 +0000",
    "user" : {
      "name" : "the piece movement",
      "screen_name" : "piece2dot0",
      "protected" : false,
      "id_str" : "19613202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518087892\/piece-higher-res_circle_normal.png",
      "id" : 19613202,
      "verified" : false
    }
  },
  "id" : 7882586770,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7885126804",
  "text" : "RT @mercola: \"Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.\" ~ Martin L ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7884224263",
    "text" : "\"Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.\" ~ Martin Luther King, Jr.",
    "id" : 7884224263,
    "created_at" : "2010-01-18 01:00:05 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 7885126804,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paula Ashley",
      "screen_name" : "paulaashley",
      "indices" : [ 3, 15 ],
      "id_str" : "23364787",
      "id" : 23364787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Who",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7885661422",
  "text" : "RT @paulaashley: #Who knew?: In 2006, 6 public schools were each awarded $25k by David Lynch Foundation to establish transcendental medi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Who",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7812815470",
    "text" : "#Who knew?: In 2006, 6 public schools were each awarded $25k by David Lynch Foundation to establish transcendental meditation programs.",
    "id" : 7812815470,
    "created_at" : "2010-01-16 03:04:01 +0000",
    "user" : {
      "name" : "Paula Ashley",
      "screen_name" : "paulaashley",
      "protected" : false,
      "id_str" : "23364787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/90755768\/PaflameSQ_normal.jpg",
      "id" : 23364787,
      "verified" : false
    }
  },
  "id" : 7885661422,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7887814207",
  "geo" : { },
  "id_str" : "7888533847",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 Can't wait to see what you gals are up to! ; )",
  "id" : 7888533847,
  "in_reply_to_status_id" : 7887814207,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John C Maxwell",
      "screen_name" : "JohnCMaxwell",
      "indices" : [ 3, 16 ],
      "id_str" : "19154824",
      "id" : 19154824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7888699031",
  "text" : "RT @johncmaxwell: It's never too late to be what you might have been. -George Eliot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7746798266",
    "text" : "It's never too late to be what you might have been. -George Eliot",
    "id" : 7746798266,
    "created_at" : "2010-01-14 13:01:26 +0000",
    "user" : {
      "name" : "John C Maxwell",
      "screen_name" : "JohnCMaxwell",
      "protected" : false,
      "id_str" : "19154824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/897322882\/maxwell_089rcloseup_normal.jpg",
      "id" : 19154824,
      "verified" : true
    }
  },
  "id" : 7888699031,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7888946456",
  "text" : "RT @tonyrobbins: Check out my free new video on how to make your new year\/goals\/dreams a reality http:\/\/bit.ly\/8gkVgZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7888833130",
    "text" : "Check out my free new video on how to make your new year\/goals\/dreams a reality http:\/\/bit.ly\/8gkVgZ",
    "id" : 7888833130,
    "created_at" : "2010-01-18 03:09:43 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 7888946456,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7902348589",
  "text" : "The Moon's return to your empathetic sign today offsets your d... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7902348589,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7907774215",
  "text" : "2nd day drinking \"tea bag\" coffee.. a step up from instant. Where's my REAL coffee???",
  "id" : 7907774215,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "indices" : [ 3, 16 ],
      "id_str" : "22276232",
      "id" : 22276232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7907982973",
  "text" : "RT @successwalls: \"If I have the belief that I can do it, I shall surely acquire the capacity to do it even if I may not have it at the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7903658321",
    "text" : "\"If I have the belief that I can do it, I shall surely acquire the capacity to do it even if I may not have it at the beginning.\" -Gandhi",
    "id" : 7903658321,
    "created_at" : "2010-01-18 13:23:49 +0000",
    "user" : {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "protected" : false,
      "id_str" : "22276232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840968112\/twitrSWicon2_normal.jpg",
      "id" : 22276232,
      "verified" : false
    }
  },
  "id" : 7907982973,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7908011721",
  "text" : "RT @abandontheherd: \"he who knows, knows not. He who knows not, knows\" - gurugita",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7901044312",
    "text" : "\"he who knows, knows not. He who knows not, knows\" - gurugita",
    "id" : 7901044312,
    "created_at" : "2010-01-18 11:34:03 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7908011721,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "Julian Cavallo",
      "screen_name" : "julzcav",
      "indices" : [ 18, 26 ],
      "id_str" : "3067273620",
      "id" : 3067273620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7908075704",
  "text" : "RT @ChrisCade: RT @julzcav \"Always stand up for what you believe in\u2026even if it means standing alone.\" ~ Kim Hanks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julian Cavallo",
        "screen_name" : "julzcav",
        "indices" : [ 3, 11 ],
        "id_str" : "3067273620",
        "id" : 3067273620
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7896241606",
    "text" : "RT @julzcav \"Always stand up for what you believe in\u2026even if it means standing alone.\" ~ Kim Hanks",
    "id" : 7896241606,
    "created_at" : "2010-01-18 07:30:50 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7908075704,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7908102695",
  "text" : "RT @ChrisCade: The purpose of 4th Grade? \"To be happy.\" If only American education would learn from this example... http:\/\/sn.im\/u469b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7894639440",
    "text" : "The purpose of 4th Grade? \"To be happy.\" If only American education would learn from this example... http:\/\/sn.im\/u469b",
    "id" : 7894639440,
    "created_at" : "2010-01-18 06:19:24 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7908102695,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily success quotes",
      "screen_name" : "dailysquotes",
      "indices" : [ 3, 16 ],
      "id_str" : "79265076",
      "id" : 79265076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7908216145",
  "text" : "RT @dailysquotes: \"If you focus on results, you will never change. If you focus on change, you will get results.\" Jack Dixon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7205125619",
    "text" : "\"If you focus on results, you will never change. If you focus on change, you will get results.\" Jack Dixon",
    "id" : 7205125619,
    "created_at" : "2009-12-30 19:00:08 +0000",
    "user" : {
      "name" : "Daily success quotes",
      "screen_name" : "dailysquotes",
      "protected" : false,
      "id_str" : "79265076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458175390\/index.icon_normal.gif",
      "id" : 79265076,
      "verified" : false
    }
  },
  "id" : 7908216145,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7908558633",
  "text" : "RT @_NealeDWalsch: All of the changes occurring right now on this planet are leading to a better life for all.  The movement here is...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7908093070",
    "text" : "All of the changes occurring right now on this planet are leading to a better life for all.  The movement here is... http:\/\/bit.ly\/8FyM37",
    "id" : 7908093070,
    "created_at" : "2010-01-18 15:50:06 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 7908558633,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7908385043",
  "geo" : { },
  "id_str" : "7908617010",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 I might have to move in with you.. you're always cooking up yummies! lol",
  "id" : 7908617010,
  "in_reply_to_status_id" : 7908385043,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7909691858",
  "geo" : { },
  "id_str" : "7910075929",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 at least it smells good ; )",
  "id" : 7910075929,
  "in_reply_to_status_id" : 7909691858,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7910094496",
  "geo" : { },
  "id_str" : "7910171709",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 occasionally I like to make fudge or cookies but not on a regular basis.. lol",
  "id" : 7910171709,
  "in_reply_to_status_id" : 7910094496,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7912497660",
  "text" : "\"I may not agree with what you say, but I will fight to the death \nfor your right to say it\" -Voltaire",
  "id" : 7912497660,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "indices" : [ 3, 17 ],
      "id_str" : "19160554",
      "id" : 19160554
    }, {
      "name" : "Just Chillin",
      "screen_name" : "wepromote",
      "indices" : [ 22, 32 ],
      "id_str" : "2274249235",
      "id" : 2274249235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7914521961",
  "text" : "RT @TatianaTheDog: RT @WEPromote I have become my own version of an optimist. If I can't make it through one door, I'll make a door. ~Ta ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Just Chillin",
        "screen_name" : "wepromote",
        "indices" : [ 3, 13 ],
        "id_str" : "2274249235",
        "id" : 2274249235
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7914100177",
    "text" : "RT @WEPromote I have become my own version of an optimist. If I can't make it through one door, I'll make a door. ~Tagore &lt;&lt; Yes!  Woof!",
    "id" : 7914100177,
    "created_at" : "2010-01-18 18:54:43 +0000",
    "user" : {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "protected" : false,
      "id_str" : "19160554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736817395\/c22eadc111e9af2f8a8bea5c17c83a82_normal.png",
      "id" : 19160554,
      "verified" : false
    }
  },
  "id" : 7914521961,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "indices" : [ 3, 14 ],
      "id_str" : "14461139",
      "id" : 14461139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7914681380",
  "text" : "RT @coachkaren: If you want one year of prosperity, grow seeds. If you want ten years of prosperity,grow trees. If you want a... http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7913153028",
    "text" : "If you want one year of prosperity, grow seeds. If you want ten years of prosperity,grow trees. If you want a... http:\/\/bit.ly\/8l917y",
    "id" : 7913153028,
    "created_at" : "2010-01-18 18:25:24 +0000",
    "user" : {
      "name" : "Karen Walker",
      "screen_name" : "coachkaren",
      "protected" : false,
      "id_str" : "14461139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1747699492\/KarenWalker_normal.jpg",
      "id" : 14461139,
      "verified" : false
    }
  },
  "id" : 7914681380,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7915374870",
  "text" : "I am not sick, I am not sick, I am not sick.. but I will eat that soup!",
  "id" : 7915374870,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7915943119",
  "geo" : { },
  "id_str" : "7916124533",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 get a gmail account : )",
  "id" : 7916124533,
  "in_reply_to_status_id" : 7915943119,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7916913251",
  "text" : "Let's play Words With Friends on the iPhone! My username is 'AbFabGab'. http:\/\/bit.ly\/2qbpQ",
  "id" : 7916913251,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7917156275",
  "geo" : { },
  "id_str" : "7917609712",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 mmmm..",
  "id" : 7917609712,
  "in_reply_to_status_id" : 7917156275,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Kitzmiller",
      "screen_name" : "JimKitzmiller",
      "indices" : [ 3, 17 ],
      "id_str" : "17081275",
      "id" : 17081275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7917624329",
  "text" : "RT @JimKitzmiller: Kindness is contagious. Start an epidemic.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7917541676",
    "text" : "Kindness is contagious. Start an epidemic.",
    "id" : 7917541676,
    "created_at" : "2010-01-18 20:41:15 +0000",
    "user" : {
      "name" : "Jim Kitzmiller",
      "screen_name" : "JimKitzmiller",
      "protected" : false,
      "id_str" : "17081275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2784880051\/475564817d2f0df0d68361ce52c296cf_normal.jpeg",
      "id" : 17081275,
      "verified" : false
    }
  },
  "id" : 7917624329,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Stacy",
      "screen_name" : "lindastacy",
      "indices" : [ 0, 11 ],
      "id_str" : "14333861",
      "id" : 14333861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7918118098",
  "geo" : { },
  "id_str" : "7918244388",
  "in_reply_to_user_id" : 14333861,
  "text" : "@lindastacy try nameboy.com.. or thesaurus..",
  "id" : 7918244388,
  "in_reply_to_status_id" : 7918118098,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "lindastacy",
  "in_reply_to_user_id_str" : "14333861",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 0, 11 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7919821366",
  "geo" : { },
  "id_str" : "7920145104",
  "in_reply_to_user_id" : 15467920,
  "text" : "@taraburner that's when I'm happiest...",
  "id" : 7920145104,
  "in_reply_to_status_id" : 7919821366,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "taraburner",
  "in_reply_to_user_id_str" : "15467920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7920157854",
  "text" : "RT @twitingly: \"He who sings frightens away his ills.\" \n-- Cervantes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7919770807",
    "text" : "\"He who sings frightens away his ills.\" \n-- Cervantes",
    "id" : 7919770807,
    "created_at" : "2010-01-18 21:51:17 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 7920157854,
  "created_at" : "2010-01-18 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7870356631",
  "geo" : { },
  "id_str" : "7870429868",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS our aussie plays every day with her daddy!",
  "id" : 7870429868,
  "in_reply_to_status_id" : 7870356631,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7880559169",
  "text" : "I gave in and upgraded my Whirly Word app.. so addicting!",
  "id" : 7880559169,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail Lynne Goodwin",
      "screen_name" : "inspiremetoday",
      "indices" : [ 3, 18 ],
      "id_str" : "14080704",
      "id" : 14080704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7846091857",
  "text" : "RT @inspiremetoday: Life is like riding a bicycle. To keep your balance you must keep moving.- Albert Einstein",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7845287186",
    "text" : "Life is like riding a bicycle. To keep your balance you must keep moving.- Albert Einstein",
    "id" : 7845287186,
    "created_at" : "2010-01-17 00:39:16 +0000",
    "user" : {
      "name" : "Gail Lynne Goodwin",
      "screen_name" : "inspiremetoday",
      "protected" : false,
      "id_str" : "14080704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/599047322\/Gail_Goodwin_5_normal.jpg",
      "id" : 14080704,
      "verified" : false
    }
  },
  "id" : 7846091857,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 0, 13 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7849735027",
  "text" : "@deucehartley yup",
  "id" : 7849735027,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7851530683",
  "text" : "RT @SpiritMaterial: Never use past experience to make judgements in the present, or the future will look just like the past. Start over  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7850280432",
    "text" : "Never use past experience to make judgements in the present, or the future will look just like the past. Start over every minute.",
    "id" : 7850280432,
    "created_at" : "2010-01-17 03:21:47 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 7851530683,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7862463181",
  "text" : "You are standing at the threshold of a new adventure as auspic... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7862463181,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodimentary",
      "screen_name" : "Foodimentary",
      "indices" : [ 3, 16 ],
      "id_str" : "17242874",
      "id" : 17242874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7865248879",
  "text" : "RT @Foodimentary: This will keep you warm! January 17 is National Hot Buttered Rum Day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7863928989",
    "text" : "This will keep you warm! January 17 is National Hot Buttered Rum Day.",
    "id" : 7863928989,
    "created_at" : "2010-01-17 13:35:42 +0000",
    "user" : {
      "name" : "Foodimentary",
      "screen_name" : "Foodimentary",
      "protected" : false,
      "id_str" : "17242874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622893150525243392\/oAiOUaCD_normal.jpg",
      "id" : 17242874,
      "verified" : false
    }
  },
  "id" : 7865248879,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u88CF\u57A2\uFF28\uFF2B\uFF34\u30C6\u30E9\u30B9\u30CF\u30A6\u30B9\u6771\u6D0B\u533B\u5B66\u6F22\u65B9\u9662\u3055\u3041",
      "screen_name" : "Lady_GQ",
      "indices" : [ 0, 8 ],
      "id_str" : "772841288907444226",
      "id" : 772841288907444226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7865324176",
  "text" : "@Lady_GQ No but I do believe there is a major shift in conciousness.",
  "id" : 7865324176,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7869610346",
  "text" : "trying to find right email app for my ipod touch.. just want to see new mail, not download all folders",
  "id" : 7869610346,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 3, 17 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7870047077",
  "text" : "RT @marwilliamson: The best way to improve the world is to improve your thinking about the world. An attack thought towards anyone is an ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7869732168",
    "text" : "The best way to improve the world is to improve your thinking about the world. An attack thought towards anyone is an attack on love's plan",
    "id" : 7869732168,
    "created_at" : "2010-01-17 17:16:32 +0000",
    "user" : {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "protected" : false,
      "id_str" : "21522338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507257000367882240\/cWcbBvzD_normal.jpeg",
      "id" : 21522338,
      "verified" : true
    }
  },
  "id" : 7870047077,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7870149173",
  "text" : "RT @BeALegacy: Whenever man comes up with a better mousetrap, nature immediately comes up with a better mouse. ~ James Carswell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7869970738",
    "text" : "Whenever man comes up with a better mousetrap, nature immediately comes up with a better mouse. ~ James Carswell",
    "id" : 7869970738,
    "created_at" : "2010-01-17 17:25:05 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 7870149173,
  "created_at" : "2010-01-17 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 0, 11 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7808243415",
  "geo" : { },
  "id_str" : "7808422704",
  "in_reply_to_user_id" : 15467920,
  "text" : "@taraburner glad you're feeling better : )",
  "id" : 7808422704,
  "in_reply_to_status_id" : 7808243415,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "taraburner",
  "in_reply_to_user_id_str" : "15467920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7808869989",
  "geo" : { },
  "id_str" : "7809112856",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 yummy!",
  "id" : 7809112856,
  "in_reply_to_status_id" : 7808869989,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7809302780",
  "geo" : { },
  "id_str" : "7809409532",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 .. and I'm older than both of you.. 44 in March. ; &gt;",
  "id" : 7809409532,
  "in_reply_to_status_id" : 7809302780,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7811217711",
  "geo" : { },
  "id_str" : "7811444423",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 well, that sucks! hope the next few days go quickly for you!",
  "id" : 7811444423,
  "in_reply_to_status_id" : 7811217711,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7824873725",
  "text" : "You may think that you are the epitome of common sense today, ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7824873725,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 3, 17 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7825215010",
  "text" : "RT @marwilliamson: The same Air Force planes that are sent to drop bombs, also deliver food and supplies to disaster victims. Consider t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 127, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7822330936",
    "text" : "The same Air Force planes that are sent to drop bombs, also deliver food and supplies to disaster victims. Consider the irony. #fb",
    "id" : 7822330936,
    "created_at" : "2010-01-16 09:57:45 +0000",
    "user" : {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "protected" : false,
      "id_str" : "21522338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507257000367882240\/cWcbBvzD_normal.jpeg",
      "id" : 21522338,
      "verified" : true
    }
  },
  "id" : 7825215010,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LoriMoreno",
      "screen_name" : "LoriMoreno",
      "indices" : [ 3, 14 ],
      "id_str" : "15039436",
      "id" : 15039436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7826976131",
  "text" : "RT @LoriMoreno: How am I going to live today in order to create the tomorrow I'm committed to?. ~Tony Robbins #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 94, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7825292684",
    "text" : "How am I going to live today in order to create the tomorrow I'm committed to?. ~Tony Robbins #quote",
    "id" : 7825292684,
    "created_at" : "2010-01-16 12:45:35 +0000",
    "user" : {
      "name" : "LoriMoreno",
      "screen_name" : "LoriMoreno",
      "protected" : false,
      "id_str" : "15039436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651143247499100160\/Qfg95x_L_normal.jpg",
      "id" : 15039436,
      "verified" : false
    }
  },
  "id" : 7826976131,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Corcoran",
      "screen_name" : "DancesWithBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "103138475",
      "id" : 103138475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7826983207",
  "text" : "RT @DancesWithBooks: pencils on tables \/\/ words captured within their lead \/\/ either shout or die #haiku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 77, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7825567065",
    "text" : "pencils on tables \/\/ words captured within their lead \/\/ either shout or die #haiku",
    "id" : 7825567065,
    "created_at" : "2010-01-16 12:59:21 +0000",
    "user" : {
      "name" : "Kitty Corcoran",
      "screen_name" : "DancesWithBooks",
      "protected" : false,
      "id_str" : "103138475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619165110\/KittysProfilePic_normal.jpg",
      "id" : 103138475,
      "verified" : false
    }
  },
  "id" : 7826983207,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7827023865",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 How are you this morning?",
  "id" : 7827023865,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7827068975",
  "geo" : { },
  "id_str" : "7827173393",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 wish I could sew... : )",
  "id" : 7827173393,
  "in_reply_to_status_id" : 7827068975,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7827405755",
  "text" : "3 cute kittys cuddling in wicker chair and no camera : (",
  "id" : 7827405755,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Monica Diaz",
      "screen_name" : "monedays",
      "indices" : [ 20, 29 ],
      "id_str" : "30928974",
      "id" : 30928974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OtherEsteem",
      "indices" : [ 30, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7829568685",
  "text" : "RT @Encouraging: RT @monedays #OtherEsteem Tip of the Day: Focus on what you have in COMMON with those other people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica Diaz",
        "screen_name" : "monedays",
        "indices" : [ 3, 12 ],
        "id_str" : "30928974",
        "id" : 30928974
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OtherEsteem",
        "indices" : [ 13, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7829512856",
    "text" : "RT @monedays #OtherEsteem Tip of the Day: Focus on what you have in COMMON with those other people.",
    "id" : 7829512856,
    "created_at" : "2010-01-16 15:36:38 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7829568685,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Monica Diaz",
      "screen_name" : "monedays",
      "indices" : [ 98, 107 ],
      "id_str" : "30928974",
      "id" : 30928974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OtherEsteem",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7829650119",
  "text" : "RT @Encouraging: How am I JUST LIKE that person or group of people who bother me? &gt;Inspired by @monedays #OtherEsteem Tip of The Day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monica Diaz",
        "screen_name" : "monedays",
        "indices" : [ 81, 90 ],
        "id_str" : "30928974",
        "id" : 30928974
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OtherEsteem",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7829544428",
    "text" : "How am I JUST LIKE that person or group of people who bother me? &gt;Inspired by @monedays #OtherEsteem Tip of The Day.",
    "id" : 7829544428,
    "created_at" : "2010-01-16 15:37:45 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7829650119,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7829710173",
  "text" : "Sinuses acting up... Yuk!",
  "id" : 7829710173,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7830621091",
  "geo" : { },
  "id_str" : "7836784539",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 you just had to put those 3 things together now... drool...",
  "id" : 7836784539,
  "in_reply_to_status_id" : 7830621091,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7836821602",
  "text" : "I &lt;3 RTing great stuff! : )",
  "id" : 7836821602,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7836920942",
  "text" : "I have my own life to live but feel like someone's taking over. I want to do the right thing but have my own life I want to live my way",
  "id" : 7836920942,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7838909437",
  "text" : "hubby isn't home to entertain me.. I'm bored!!",
  "id" : 7838909437,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7838942857",
  "geo" : { },
  "id_str" : "7839096797",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 you are sooo cruel! ; &gt; good thing I have my fave ice cream",
  "id" : 7839096797,
  "in_reply_to_status_id" : 7838942857,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7839623763",
  "geo" : { },
  "id_str" : "7839719919",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 what's a head sling? Is it for your headache?",
  "id" : 7839719919,
  "in_reply_to_status_id" : 7839623763,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7840182662",
  "geo" : { },
  "id_str" : "7840403941",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 ahh, I see. Could garner a quick look but not a stare! ; &gt;",
  "id" : 7840403941,
  "in_reply_to_status_id" : 7840182662,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7842028419",
  "text" : "RT @BigBookofYou: The only journey is the journey within. Rainer Maria Rilke #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 59, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7841361330",
    "text" : "The only journey is the journey within. Rainer Maria Rilke #quote",
    "id" : 7841361330,
    "created_at" : "2010-01-16 22:23:09 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 7842028419,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 0, 13 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7842094108",
  "in_reply_to_user_id" : 14669290,
  "text" : "@aplacetobark http:\/\/twitpic.com\/ye72w - He is very, very beautiful!",
  "id" : 7842094108,
  "created_at" : "2010-01-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "aplacetobark",
  "in_reply_to_user_id_str" : "14669290",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7772901195",
  "text" : "\"I'm glad you choose to see me the way you do\" Walter on Fringe",
  "id" : 7772901195,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7785220486",
  "text" : "RT @abandontheherd: Let your love shine http:\/\/yfrog.com\/4aubxmj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7784596264",
    "text" : "Let your love shine http:\/\/yfrog.com\/4aubxmj",
    "id" : 7784596264,
    "created_at" : "2010-01-15 11:37:25 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7785220486,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 0, 15 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7784673497",
  "geo" : { },
  "id_str" : "7785235262",
  "in_reply_to_user_id" : 43012495,
  "text" : "@abandontheherd you two are so cute! thanks for sharing! : )",
  "id" : 7785235262,
  "in_reply_to_status_id" : 7784673497,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "abandontheherd",
  "in_reply_to_user_id_str" : "43012495",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "Guy Finley",
      "screen_name" : "guy_finley",
      "indices" : [ 18, 29 ],
      "id_str" : "68468837",
      "id" : 68468837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7785373518",
  "text" : "RT @ChrisCade: RT @Guy_Finley Some of God\u2019s greatest gifts to us often appear, at first, as though He is taking something away from us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Guy Finley",
        "screen_name" : "guy_finley",
        "indices" : [ 3, 14 ],
        "id_str" : "68468837",
        "id" : 68468837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7777024885",
    "text" : "RT @Guy_Finley Some of God\u2019s greatest gifts to us often appear, at first, as though He is taking something away from us.",
    "id" : 7777024885,
    "created_at" : "2010-01-15 05:17:21 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7785373518,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7785404422",
  "text" : "RT @SpiritMaterial: The most important thing in communication is hearing what isn't said. ~Peter Drucker",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7774361242",
    "text" : "The most important thing in communication is hearing what isn't said. ~Peter Drucker",
    "id" : 7774361242,
    "created_at" : "2010-01-15 03:46:15 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 7785404422,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7785625837",
  "text" : "Your world now might feel like a science fiction movie because... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7785625837,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7786679245",
  "geo" : { },
  "id_str" : "7787893840",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX Date night!! : ) Have fun!",
  "id" : 7787893840,
  "in_reply_to_status_id" : 7786679245,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Herrick",
      "screen_name" : "Coolbear77",
      "indices" : [ 0, 11 ],
      "id_str" : "19577191",
      "id" : 19577191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7794655806",
  "geo" : { },
  "id_str" : "7794700156",
  "in_reply_to_user_id" : 19577191,
  "text" : "@Coolbear77 hubby says he can use that one on me! lol",
  "id" : 7794700156,
  "in_reply_to_status_id" : 7794655806,
  "created_at" : "2010-01-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "Coolbear77",
  "in_reply_to_user_id_str" : "19577191",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richa Mehrotra",
      "screen_name" : "Smilelotus",
      "indices" : [ 3, 14 ],
      "id_str" : "56967244",
      "id" : 56967244
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7747250095",
  "text" : "RT @Smilelotus: Life is really simple, but we insist on making it complicated.  ~Confucius",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7746163874",
    "text" : "Life is really simple, but we insist on making it complicated.  ~Confucius",
    "id" : 7746163874,
    "created_at" : "2010-01-14 12:36:06 +0000",
    "user" : {
      "name" : "Richa Mehrotra",
      "screen_name" : "Smilelotus",
      "protected" : false,
      "id_str" : "56967244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705565766\/DSC00668_normal.JPG",
      "id" : 56967244,
      "verified" : false
    }
  },
  "id" : 7747250095,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7747288217",
  "text" : "RT @paulocoelho: 14\/1: Save your energies: bitter people hate to be reminded that joy exists.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7746165232",
    "text" : "14\/1: Save your energies: bitter people hate to be reminded that joy exists.",
    "id" : 7746165232,
    "created_at" : "2010-01-14 12:36:09 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 7747288217,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7747320545",
  "text" : "I'm still just a baby in this big world",
  "id" : 7747320545,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7758494527",
  "text" : "RT @mercola: You may be able to fool your taste buds with artificial sweeteners, but your brain isn\u2019t buying it. http:\/\/bit.ly\/6G9vaZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7758264964",
    "text" : "You may be able to fool your taste buds with artificial sweeteners, but your brain isn\u2019t buying it. http:\/\/bit.ly\/6G9vaZ",
    "id" : 7758264964,
    "created_at" : "2010-01-14 19:20:12 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 7758494527,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7758546041",
  "text" : "what a crazy day today.. poor nephew had to get shot and a blood test.. and I was the one with him.. my poor li'l man!",
  "id" : 7758546041,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 51, 64 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7758687395",
  "text" : "RT @ChrisCade: \"When in doubt, doubt the doubt!\" ~ @DeepakChopra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 36, 49 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7758248113",
    "text" : "\"When in doubt, doubt the doubt!\" ~ @DeepakChopra",
    "id" : 7758248113,
    "created_at" : "2010-01-14 19:19:40 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7758687395,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7731521746",
  "text" : "Of course your feelings make total sense to you, but the troub... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7731521746,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7745877588",
  "text" : "You may need to take a stand against the pressure you feel fro... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7745877588,
  "created_at" : "2010-01-14 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7691209762",
  "geo" : { },
  "id_str" : "7691766739",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 agreed!",
  "id" : 7691766739,
  "in_reply_to_status_id" : 7691209762,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7691659174",
  "geo" : { },
  "id_str" : "7691831941",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS hubby tries that with me sometimes.. don't like it! : )",
  "id" : 7691831941,
  "in_reply_to_status_id" : 7691659174,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7692090076",
  "text" : "hubby did not get me my chocolate ice cream.. i'm so sad : (",
  "id" : 7692090076,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7692102693",
  "geo" : { },
  "id_str" : "7692516912",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS true, true!",
  "id" : 7692516912,
  "in_reply_to_status_id" : 7692102693,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7692401430",
  "geo" : { },
  "id_str" : "7692558946",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 which is why I can't stand to watch it.. but hubby has it on.. sigh.",
  "id" : 7692558946,
  "in_reply_to_status_id" : 7692401430,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7693781363",
  "text" : "our aussie has a ferocious bark and sometimes scares people coming into the yard.. heehee. I love hearing about her adventures from Daddy.",
  "id" : 7693781363,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Jen\u00E1 Adams",
      "screen_name" : "101Relationship",
      "indices" : [ 20, 36 ],
      "id_str" : "92677317",
      "id" : 92677317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ivelearned",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7706634067",
  "text" : "RT @Encouraging: RT @101Relationship #Ivelearned .... That being kind is more important than being right.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jen\u00E1 Adams",
        "screen_name" : "101Relationship",
        "indices" : [ 3, 19 ],
        "id_str" : "92677317",
        "id" : 92677317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ivelearned",
        "indices" : [ 20, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7703442909",
    "text" : "RT @101Relationship #Ivelearned .... That being kind is more important than being right.",
    "id" : 7703442909,
    "created_at" : "2010-01-13 10:05:06 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7706634067,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7706870315",
  "text" : "getting up early is for the birds.. how do people do this every day? lol",
  "id" : 7706870315,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7709173197",
  "text" : "RT @ChrisCade: \"What if... we just acted like everything was easy?\" ~ Mary Anne Radmacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7695486495",
    "text" : "\"What if... we just acted like everything was easy?\" ~ Mary Anne Radmacher",
    "id" : 7695486495,
    "created_at" : "2010-01-13 03:28:19 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7709173197,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "indices" : [ 3, 17 ],
      "id_str" : "69318532",
      "id" : 69318532
    }, {
      "name" : "Kelby",
      "screen_name" : "typeamom",
      "indices" : [ 22, 31 ],
      "id_str" : "19736240",
      "id" : 19736240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7709195915",
  "text" : "RT @MyBizPresence: RT @typeamom: Help people first on these social networks. Offer advice, RT, share, comment. Kharma comes back tenfold ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kelby",
        "screen_name" : "typeamom",
        "indices" : [ 3, 12 ],
        "id_str" : "19736240",
        "id" : 19736240
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gno",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7695888405",
    "text" : "RT @typeamom: Help people first on these social networks. Offer advice, RT, share, comment. Kharma comes back tenfold+ #gno",
    "id" : 7695888405,
    "created_at" : "2010-01-13 03:43:18 +0000",
    "user" : {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "protected" : false,
      "id_str" : "69318532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748607898406645761\/us3mLEKn_normal.jpg",
      "id" : 69318532,
      "verified" : false
    }
  },
  "id" : 7709195915,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "indices" : [ 3, 17 ],
      "id_str" : "69318532",
      "id" : 69318532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7709206826",
  "text" : "RT @MyBizPresence: I personally think Blogger should make it much more obvious that it is NOT to be used for business purposes, too many ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gno",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7696356989",
    "text" : "I personally think Blogger should make it much more obvious that it is NOT to be used for business purposes, too many find out too late #gno",
    "id" : 7696356989,
    "created_at" : "2010-01-13 04:00:32 +0000",
    "user" : {
      "name" : "Karen Clark",
      "screen_name" : "MyBizPresence",
      "protected" : false,
      "id_str" : "69318532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748607898406645761\/us3mLEKn_normal.jpg",
      "id" : 69318532,
      "verified" : false
    }
  },
  "id" : 7709206826,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7709262920",
  "text" : "RT @abandontheherd: If a toxic substance was in front of you, walking away from it would be wise. Why not treat toxic thoughts and toxic ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7705623515",
    "text" : "If a toxic substance was in front of you, walking away from it would be wise. Why not treat toxic thoughts and toxic people the same?",
    "id" : 7705623515,
    "created_at" : "2010-01-13 11:58:27 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7709262920,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7709756040",
  "text" : "Love my iPod touch.. One of my better spending choices! Thanks, Dad!",
  "id" : 7709756040,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Tammy Doci",
      "screen_name" : "TammyDoci",
      "indices" : [ 20, 30 ],
      "id_str" : "58588093",
      "id" : 58588093
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7709841120",
  "text" : "RT @Encouraging: RT @TammyDoci Every time a door closes behind us, the rest of the world opens up in front of us....",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tammy Doci",
        "screen_name" : "TammyDoci",
        "indices" : [ 3, 13 ],
        "id_str" : "58588093",
        "id" : 58588093
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7709747749",
    "text" : "RT @TammyDoci Every time a door closes behind us, the rest of the world opens up in front of us....",
    "id" : 7709747749,
    "created_at" : "2010-01-13 14:32:36 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7709841120,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7709821197",
  "geo" : { },
  "id_str" : "7709872122",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 agree.. It's awesome feeling!",
  "id" : 7709872122,
  "in_reply_to_status_id" : 7709821197,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7709952663",
  "text" : "Hubby said to me he's spending too much time online. I scoffed.. LOL.. No such thing.. Hehe",
  "id" : 7709952663,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7711736296",
  "text" : "Did not like cartoons as a kid.. Still don't thrill me",
  "id" : 7711736296,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7711750852",
  "geo" : { },
  "id_str" : "7711935145",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS I'd like to see a pic of you and puzzle, too!",
  "id" : 7711935145,
  "in_reply_to_status_id" : 7711750852,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7715183010",
  "geo" : { },
  "id_str" : "7715853216",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 advil works wonders for me.. Benadryl if sinuses..",
  "id" : 7715853216,
  "in_reply_to_status_id" : 7715183010,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7715241535",
  "geo" : { },
  "id_str" : "7715940268",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 me, too. Don't like popups and stuff. Or those \"wait don't leave, let's chat\" things..",
  "id" : 7715940268,
  "in_reply_to_status_id" : 7715241535,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7717309374",
  "text" : "RT @kimduess: Health Tip: Eat more quinoa: A high-protein, low-carb \"grain\" (a seed!) that can replace rice or couscous. http:\/\/su.pr\/1k ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7716851587",
    "text" : "Health Tip: Eat more quinoa: A high-protein, low-carb \"grain\" (a seed!) that can replace rice or couscous. http:\/\/su.pr\/1kx6cV Yum!",
    "id" : 7716851587,
    "created_at" : "2010-01-13 18:16:15 +0000",
    "user" : {
      "name" : "You Be Healthy",
      "screen_name" : "you_be_healthy",
      "protected" : false,
      "id_str" : "37557785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459760129\/kim-190-fix-2_3__normal.jpg",
      "id" : 37557785,
      "verified" : false
    }
  },
  "id" : 7717309374,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Abe",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "LoA",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7719241756",
  "text" : "RT @abe_quotes: The more joyful you are, the more you thrive. It is just that simple. \n\n#Abe #LoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Abe",
        "indices" : [ 72, 76 ]
      }, {
        "text" : "LoA",
        "indices" : [ 77, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7717777872",
    "text" : "The more joyful you are, the more you thrive. It is just that simple. \n\n#Abe #LoA",
    "id" : 7717777872,
    "created_at" : "2010-01-13 18:47:18 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 7719241756,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7719574375",
  "text" : "RT @paulocoelho: Wed: Accept joy even if you're afraid it might end one day",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7719375986",
    "text" : "Wed: Accept joy even if you're afraid it might end one day",
    "id" : 7719375986,
    "created_at" : "2010-01-13 19:40:45 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 7719574375,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7725057540",
  "text" : "getting ready to leave for taekwondo. leadership tonight. I'm tired and don't want to leave the house.. waah",
  "id" : 7725057540,
  "created_at" : "2010-01-13 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7667083198",
  "text" : "You can be quite headstrong today about your career objectives... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7667083198,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7668108044",
  "text" : "RT @RevAnne1: EFT Affirm I know that I am loved & cared for by Spirit. I am provided for in all ways, always. http:\/\/ThinkitBeitSeeit.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7664182015",
    "text" : "EFT Affirm I know that I am loved & cared for by Spirit. I am provided for in all ways, always. http:\/\/ThinkitBeitSeeit.com",
    "id" : 7664182015,
    "created_at" : "2010-01-12 09:57:03 +0000",
    "user" : {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "protected" : false,
      "id_str" : "25058557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212762820\/507W6716aDONEa1_normal.jpg",
      "id" : 25058557,
      "verified" : false
    }
  },
  "id" : 7668108044,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7668172954",
  "text" : "RT @ChrisCade: \"Remember, the entrance door to the sanctuary is inside you.\" ~ Rumi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7658754274",
    "text" : "\"Remember, the entrance door to the sanctuary is inside you.\" ~ Rumi",
    "id" : 7658754274,
    "created_at" : "2010-01-12 05:16:41 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7668172954,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7672375062",
  "text" : "Babysitting sick nephew today",
  "id" : 7672375062,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7672581853",
  "text" : "RT @tonyrobbins: faith is knowing 1 of 2 things shall happen: either U will be given something solid 2 stand on, or  Uwill be taught how ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7666942834",
    "text" : "faith is knowing 1 of 2 things shall happen: either U will be given something solid 2 stand on, or  Uwill be taught how to fly -Teller",
    "id" : 7666942834,
    "created_at" : "2010-01-12 12:20:31 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 7672581853,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7669206510",
  "geo" : { },
  "id_str" : "7672737847",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 have you told them you prefer not to receive those type of emails?",
  "id" : 7672737847,
  "in_reply_to_status_id" : 7669206510,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7669258044",
  "geo" : { },
  "id_str" : "7672832595",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 me, too.. B4 9am is early to me : )",
  "id" : 7672832595,
  "in_reply_to_status_id" : 7669258044,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7672867684",
  "text" : "RT @Ravish30: I have tried some new things with my biz...they are working well. I am now offering door to door service to seniors in our ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7669356848",
    "text" : "I have tried some new things with my biz...they are working well. I am now offering door to door service to seniors in our community",
    "id" : 7669356848,
    "created_at" : "2010-01-12 13:54:38 +0000",
    "user" : {
      "name" : "\u2665 Shelly - Louise",
      "screen_name" : "ClassyChicShel",
      "protected" : false,
      "id_str" : "23845064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749025439058956288\/2a5boEDx_normal.jpg",
      "id" : 23845064,
      "verified" : false
    }
  },
  "id" : 7672867684,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7673360112",
  "text" : "RT @BeALegacy: \"Yesterday is a canceled check; tomorrow is a promissory note; today is the only cash you have - so spend it wisely\u201D ~ Ka ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7672442500",
    "text" : "\"Yesterday is a canceled check; tomorrow is a promissory note; today is the only cash you have - so spend it wisely\u201D ~ Kay Lyons",
    "id" : 7672442500,
    "created_at" : "2010-01-12 15:34:11 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 7673360112,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7674898413",
  "text" : "RT @Ravish30: One of the best things I learnt in 2009 was the fact that I can't be about business all the time :) I am now exper. a lot  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7674787937",
    "text" : "One of the best things I learnt in 2009 was the fact that I can't be about business all the time :) I am now exper. a lot less stress",
    "id" : 7674787937,
    "created_at" : "2010-01-12 16:47:39 +0000",
    "user" : {
      "name" : "\u2665 Shelly - Louise",
      "screen_name" : "ClassyChicShel",
      "protected" : false,
      "id_str" : "23845064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749025439058956288\/2a5boEDx_normal.jpg",
      "id" : 23845064,
      "verified" : false
    }
  },
  "id" : 7674898413,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7678120778",
  "text" : "Babysitting is not my thing..does not mean I don't like kids, tho",
  "id" : 7678120778,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7679010602",
  "text" : "Advil is king! Lol.. It's what works for me",
  "id" : 7679010602,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7679020078",
  "text" : "RT @LaughingBaba: In a supermarket thinking: if we really want health we have to start eating food and stop eating inventions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7678482116",
    "text" : "In a supermarket thinking: if we really want health we have to start eating food and stop eating inventions.",
    "id" : 7678482116,
    "created_at" : "2010-01-12 18:49:49 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 7679020078,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7679047545",
  "text" : "RT @kimduess: If you eat organic food there will be less toxins delivered to liver and it will have an easier job keeping you alive!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7678878790",
    "text" : "If you eat organic food there will be less toxins delivered to liver and it will have an easier job keeping you alive!",
    "id" : 7678878790,
    "created_at" : "2010-01-12 19:02:57 +0000",
    "user" : {
      "name" : "You Be Healthy",
      "screen_name" : "you_be_healthy",
      "protected" : false,
      "id_str" : "37557785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459760129\/kim-190-fix-2_3__normal.jpg",
      "id" : 37557785,
      "verified" : false
    }
  },
  "id" : 7679047545,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7685432999",
  "text" : "RT @paulocoelho: After closing the doors that lead you nowhere, throw away the key! Because our tendency is to look back and regret",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7682801770",
    "text" : "After closing the doors that lead you nowhere, throw away the key! Because our tendency is to look back and regret",
    "id" : 7682801770,
    "created_at" : "2010-01-12 21:11:59 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 7685432999,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7685660390",
  "text" : "relaxing at home, had nice bath, waiting for hubby to cook dinner",
  "id" : 7685660390,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7687555262",
  "text" : "RT @twitingly: Given a choice between two theories, take the one which is funnier.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7687354348",
    "text" : "Given a choice between two theories, take the one which is funnier.",
    "id" : 7687354348,
    "created_at" : "2010-01-12 23:28:39 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 7687555262,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7651964047",
  "text" : "Let's play Words With Friends on the iPhone! My username is 'AbFabGab'. http:\/\/bit.ly\/2qbpQ",
  "id" : 7651964047,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7652259948",
  "text" : "RT @LaughingBaba: The smallest act of kindness or even a simple act of politeness has the power to turn someone's day completely around  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7648122579",
    "text" : "The smallest act of kindness or even a simple act of politeness has the power to turn someone's day completely around for the good.",
    "id" : 7648122579,
    "created_at" : "2010-01-11 23:50:18 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 7652259948,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7646993880",
  "geo" : { },
  "id_str" : "7652421776",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 the dog has all three, she's basically a furry sister to our daughter..hehe..",
  "id" : 7652421776,
  "in_reply_to_status_id" : 7646993880,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7655058250",
  "geo" : { },
  "id_str" : "7655273893",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS You look quite charming with those blue balls bobbling on your head, Caplin! : )",
  "id" : 7655273893,
  "in_reply_to_status_id" : 7655058250,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7657867278",
  "text" : "It's easy to lose track of your own goals today because you ar... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7657867278,
  "created_at" : "2010-01-12 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vishara",
      "screen_name" : "vishara",
      "indices" : [ 3, 11 ],
      "id_str" : "17613276",
      "id" : 17613276
    }, {
      "name" : "CtheMZOR",
      "screen_name" : "TigerMystic",
      "indices" : [ 13, 25 ],
      "id_str" : "26145431",
      "id" : 26145431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7611903778",
  "text" : "RT @vishara: @TigerMystic Your mind would have you think that thinking is the gateway to Freedom. But Freedom is found in BE-ing...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CtheMZOR",
        "screen_name" : "TigerMystic",
        "indices" : [ 0, 12 ],
        "id_str" : "26145431",
        "id" : 26145431
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "7610148055",
    "geo" : { },
    "id_str" : "7610570636",
    "in_reply_to_user_id" : 26145431,
    "text" : "@TigerMystic Your mind would have you think that thinking is the gateway to Freedom. But Freedom is found in BE-ing...",
    "id" : 7610570636,
    "in_reply_to_status_id" : 7610148055,
    "created_at" : "2010-01-11 00:29:49 +0000",
    "in_reply_to_screen_name" : "TigerMystic",
    "in_reply_to_user_id_str" : "26145431",
    "user" : {
      "name" : "Awake to Oneness",
      "screen_name" : "Awake2oneness",
      "protected" : false,
      "id_str" : "15874378",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2299512745\/d7smkzpeoox7uchpd68c_normal.gif",
      "id" : 15874378,
      "verified" : false
    }
  },
  "id" : 7611903778,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Moose",
      "screen_name" : "PeteMoose",
      "indices" : [ 3, 13 ],
      "id_str" : "63542215",
      "id" : 63542215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7611932992",
  "text" : "RT @PeteMoose: I'm on my last moose leg here - Vermont is going to KILL ME!  http:\/\/twurl.nl\/a88tmr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7609922146",
    "text" : "I'm on my last moose leg here - Vermont is going to KILL ME!  http:\/\/twurl.nl\/a88tmr",
    "id" : 7609922146,
    "created_at" : "2010-01-11 00:08:16 +0000",
    "user" : {
      "name" : "Pete Moose",
      "screen_name" : "PeteMoose",
      "protected" : false,
      "id_str" : "63542215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643603789\/moose_normal.gif",
      "id" : 63542215,
      "verified" : false
    }
  },
  "id" : 7611932992,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 3, 17 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7627890725",
  "text" : "RT @marwilliamson: \"The rest you seek you will not find from sleeping but from waking.\" -- A COURSE IN MIRACLES #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 93, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7621840036",
    "text" : "\"The rest you seek you will not find from sleeping but from waking.\" -- A COURSE IN MIRACLES #fb",
    "id" : 7621840036,
    "created_at" : "2010-01-11 06:59:38 +0000",
    "user" : {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "protected" : false,
      "id_str" : "21522338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507257000367882240\/cWcbBvzD_normal.jpeg",
      "id" : 21522338,
      "verified" : true
    }
  },
  "id" : 7627890725,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7628785368",
  "text" : "watched \"district 9\" last night.. really enjoyed it. was a bit different than expected..",
  "id" : 7628785368,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7628910928",
  "text" : "Let's play Words With Friends on the iPhone! My username is 'AbFabGab'. http:\/\/bit.ly\/2qbpQ",
  "id" : 7628910928,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7630339545",
  "geo" : { },
  "id_str" : "7630634777",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 an owl fan, eh? wise choice..LOL.. moose fan here.",
  "id" : 7630634777,
  "in_reply_to_status_id" : 7630339545,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7630655031",
  "geo" : { },
  "id_str" : "7630768150",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 have a fav type of owl? they are all beautiful, though.",
  "id" : 7630768150,
  "in_reply_to_status_id" : 7630655031,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7631225321",
  "geo" : { },
  "id_str" : "7631714182",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 sounds like my kind of flavor.. love caramel!",
  "id" : 7631714182,
  "in_reply_to_status_id" : 7631225321,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7630801366",
  "geo" : { },
  "id_str" : "7631836019",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 hmm. prob 15 years. I just love their funny noses.. want to rub one.. lol.",
  "id" : 7631836019,
  "in_reply_to_status_id" : 7630801366,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7634779383",
  "geo" : { },
  "id_str" : "7635046738",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 correct I think? &gt;&gt; http:\/\/www.google.com\/support\/blogger\/bin\/answer.py?hl=en&answer=106241",
  "id" : 7635046738,
  "in_reply_to_status_id" : 7634779383,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "indices" : [ 3, 17 ],
      "id_str" : "19160554",
      "id" : 19160554
    }, {
      "name" : "Harry Shade",
      "screen_name" : "harryshade",
      "indices" : [ 22, 33 ],
      "id_str" : "15374586",
      "id" : 15374586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7635248775",
  "text" : "RT @TatianaTheDog: RT @harryshade This is 2 cute & w\/ a lesson 2 boot! I luv Tatiana the dog: http:\/\/bit.ly\/5DJHeG &lt;&lt; Thanks Harry!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harry Shade",
        "screen_name" : "harryshade",
        "indices" : [ 3, 14 ],
        "id_str" : "15374586",
        "id" : 15374586
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7634993799",
    "text" : "RT @harryshade This is 2 cute & w\/ a lesson 2 boot! I luv Tatiana the dog: http:\/\/bit.ly\/5DJHeG &lt;&lt; Thanks Harry!!",
    "id" : 7634993799,
    "created_at" : "2010-01-11 16:40:24 +0000",
    "user" : {
      "name" : "Tatiana The Dog \u2122",
      "screen_name" : "TatianaTheDog",
      "protected" : false,
      "id_str" : "19160554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000736817395\/c22eadc111e9af2f8a8bea5c17c83a82_normal.png",
      "id" : 19160554,
      "verified" : false
    }
  },
  "id" : 7635248775,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katieshugs.com",
      "screen_name" : "katieshugs",
      "indices" : [ 3, 14 ],
      "id_str" : "19918075",
      "id" : 19918075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7635341625",
  "text" : "RT @katieshugs: Free Recipe Box with index cards http:\/\/bit.ly\/6XOIDs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7634158305",
    "text" : "Free Recipe Box with index cards http:\/\/bit.ly\/6XOIDs",
    "id" : 7634158305,
    "created_at" : "2010-01-11 16:13:12 +0000",
    "user" : {
      "name" : "Katieshugs.com",
      "screen_name" : "katieshugs",
      "protected" : false,
      "id_str" : "19918075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74795347\/katieshugsbutton1__Small__normal.jpg",
      "id" : 19918075,
      "verified" : false
    }
  },
  "id" : 7635341625,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7635335330",
  "geo" : { },
  "id_str" : "7635439788",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 check out candy beauchamp.. web, twitter, fb. she runs a va group as well as doing va.",
  "id" : 7635439788,
  "in_reply_to_status_id" : 7635335330,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 82, 90 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7636528166",
  "text" : "Ava Anderson Non-Toxic - Ava\u2019s Truly Non-Toxic Products: http:\/\/bit.ly\/5JpabK via @addthis",
  "id" : 7636528166,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7637068365",
  "text" : "I like tomato soup but tomato based soups taste pukey to me...",
  "id" : 7637068365,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7637180534",
  "geo" : { },
  "id_str" : "7637324436",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 hope you get meds straightend out.. good luck! : )",
  "id" : 7637324436,
  "in_reply_to_status_id" : 7637180534,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healing Inside",
      "screen_name" : "HealingInside",
      "indices" : [ 0, 14 ],
      "id_str" : "2176573952",
      "id" : 2176573952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7637359995",
  "text" : "@HealingInside more people waking up daily to govt nonsense : )",
  "id" : 7637359995,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deucehartley",
      "screen_name" : "deucehartley",
      "indices" : [ 0, 13 ],
      "id_str" : "2493195518",
      "id" : 2493195518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7638776848",
  "text" : "@deucehartley I saw it on FB before twitter and I was checking twitter.. maybe twit is glitchy today?",
  "id" : 7638776848,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7639046083",
  "text" : "I guess it was my sinuses.. took sudafed and head feeling better...",
  "id" : 7639046083,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    }, {
      "name" : "Sarah \u2740\u24C1\u24DE\u24E5\u24D4\u2740 \u262E",
      "screen_name" : "zbleumoon",
      "indices" : [ 85, 95 ],
      "id_str" : "36032320",
      "id" : 36032320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7639305566",
  "text" : "RT @abandontheherd: \u25C8 The greatest strength is gentleness. ~ Iroquois Indians \u25C8 (via @zbleumoon)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah \u2740\u24C1\u24DE\u24E5\u24D4\u2740 \u262E",
        "screen_name" : "zbleumoon",
        "indices" : [ 65, 75 ],
        "id_str" : "36032320",
        "id" : 36032320
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7638110277",
    "text" : "\u25C8 The greatest strength is gentleness. ~ Iroquois Indians \u25C8 (via @zbleumoon)",
    "id" : 7638110277,
    "created_at" : "2010-01-11 18:23:49 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7639305566,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 18, 31 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7639722847",
  "text" : "RT @ChrisCade: RT @DeepakChopra You belong & are important in the scheme of the universe. There are no spare parts in the universe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 3, 16 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7639683168",
    "text" : "RT @DeepakChopra You belong & are important in the scheme of the universe. There are no spare parts in the universe",
    "id" : 7639683168,
    "created_at" : "2010-01-11 19:17:19 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7639722847,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "LoriMoreno",
      "screen_name" : "LoriMoreno",
      "indices" : [ 18, 29 ],
      "id_str" : "15039436",
      "id" : 15039436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7639725479",
  "text" : "RT @ChrisCade: RT @LoriMoreno In the practice of tolerance, one's enemy is the best teacher. ~ Dalai Lama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LoriMoreno",
        "screen_name" : "LoriMoreno",
        "indices" : [ 3, 14 ],
        "id_str" : "15039436",
        "id" : 15039436
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7639640851",
    "text" : "RT @LoriMoreno In the practice of tolerance, one's enemy is the best teacher. ~ Dalai Lama",
    "id" : 7639640851,
    "created_at" : "2010-01-11 19:15:53 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7639725479,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7641440744",
  "text" : "RT @ChrisCade: There's no word in Tibetan for 'guilty.' The closest thing is 'intelligent regret that decides to do things differently'~ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7641368731",
    "text" : "There's no word in Tibetan for 'guilty.' The closest thing is 'intelligent regret that decides to do things differently'~Geshe Michael Roach",
    "id" : 7641368731,
    "created_at" : "2010-01-11 20:15:11 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7641440744,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7646261491",
  "text" : "getting ready to leave for taekwondo class tonight",
  "id" : 7646261491,
  "created_at" : "2010-01-11 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7575700716",
  "text" : "finally returned christmas clothes,exchanged one, cash back other,ran out of steam. got new game for my ds:womens murder club",
  "id" : 7575700716,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omgfacts",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7575719956",
  "text" : "RT @OMGFacts: The average human body contains enough fat to make seven bars of soap. #omgfacts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "omgfacts",
        "indices" : [ 71, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7575069494",
    "text" : "The average human body contains enough fat to make seven bars of soap. #omgfacts",
    "id" : 7575069494,
    "created_at" : "2010-01-10 00:40:53 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 7575719956,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7575725327",
  "text" : "RT @SpiritMaterial: Chocolate should be classified as one of the principal food groups!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7574480164",
    "text" : "Chocolate should be classified as one of the principal food groups!",
    "id" : 7574480164,
    "created_at" : "2010-01-10 00:20:37 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 7575725327,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7572736094",
  "geo" : { },
  "id_str" : "7575826727",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 (((hugs)))",
  "id" : 7575826727,
  "in_reply_to_status_id" : 7572736094,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fields",
      "screen_name" : "jonathanfields",
      "indices" : [ 3, 18 ],
      "id_str" : "11752272",
      "id" : 11752272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7575997403",
  "text" : "RT @jonathanfields: Nothing is impossible for a person who refuses to listen to reason. -Gary Halbert",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7569277932",
    "text" : "Nothing is impossible for a person who refuses to listen to reason. -Gary Halbert",
    "id" : 7569277932,
    "created_at" : "2010-01-09 21:14:16 +0000",
    "user" : {
      "name" : "Jonathan Fields",
      "screen_name" : "jonathanfields",
      "protected" : false,
      "id_str" : "11752272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441600266878451714\/1FVwvwjd_normal.jpeg",
      "id" : 11752272,
      "verified" : false
    }
  },
  "id" : 7575997403,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7594337455",
  "text" : "Let's play Words With Friends on the iPhone! My username is 'AbFabGab'. http:\/\/bit.ly\/2qbpQ",
  "id" : 7594337455,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7594936799",
  "text" : "hubby brought me coffee and breakfast at my pc.. am I spoiled? ; &gt;",
  "id" : 7594936799,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Corcoran",
      "screen_name" : "DancesWithBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "103138475",
      "id" : 103138475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7594945906",
  "text" : "RT @DancesWithBooks: Each element (stitch) in a crochet piece is supported & held in place by those around it, like atoms in a universe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7594526786",
    "text" : "Each element (stitch) in a crochet piece is supported & held in place by those around it, like atoms in a universe.",
    "id" : 7594526786,
    "created_at" : "2010-01-10 14:55:39 +0000",
    "user" : {
      "name" : "Kitty Corcoran",
      "screen_name" : "DancesWithBooks",
      "protected" : false,
      "id_str" : "103138475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619165110\/KittysProfilePic_normal.jpg",
      "id" : 103138475,
      "verified" : false
    }
  },
  "id" : 7594945906,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7595394980",
  "text" : "woke up hubby,dog,myself with a shout in middle of night.. weird.",
  "id" : 7595394980,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7596594274",
  "text" : "RT @BeALegacy: None of the ideas will matter unless I take action on them.  Decisions are meaningess without action! What are you taking ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7595878661",
    "text" : "None of the ideas will matter unless I take action on them.  Decisions are meaningess without action! What are you taking action on today?",
    "id" : 7595878661,
    "created_at" : "2010-01-10 15:48:04 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 7596594274,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omgfacts",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7597093698",
  "text" : "RT @OMGFacts: Each day, more than $40 Trillion Dollars changes hands worldwide. #omgfacts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.Tweet-U-Later.com\" rel=\"nofollow\"\u003ETweet-U-Later\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "omgfacts",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7596620357",
    "text" : "Each day, more than $40 Trillion Dollars changes hands worldwide. #omgfacts",
    "id" : 7596620357,
    "created_at" : "2010-01-10 16:17:02 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 7597093698,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omgfacts",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7607243765",
  "text" : "RT @OMGFacts: It takes 492 seconds for sunlight to reach the Earth. #omgfacts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.Tweet-U-Later.com\" rel=\"nofollow\"\u003ETweet-U-Later\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "omgfacts",
        "indices" : [ 54, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7605091705",
    "text" : "It takes 492 seconds for sunlight to reach the Earth. #omgfacts",
    "id" : 7605091705,
    "created_at" : "2010-01-10 21:22:03 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 7607243765,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7607457005",
  "text" : "spent day w\/ hubby returning top, browsing stores, opening sams club acct again.",
  "id" : 7607457005,
  "created_at" : "2010-01-10 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "indices" : [ 3, 15 ],
      "id_str" : "23273932",
      "id" : 23273932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7560292438",
  "text" : "RT @CuresCancer: I refuse to answer that question on the grounds that I don't know the answer.~Douglas Adams",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7560173791",
    "text" : "I refuse to answer that question on the grounds that I don't know the answer.~Douglas Adams",
    "id" : 7560173791,
    "created_at" : "2010-01-09 15:46:19 +0000",
    "user" : {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "protected" : false,
      "id_str" : "23273932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609239639358988288\/AZfiLu4b_normal.png",
      "id" : 23273932,
      "verified" : false
    }
  },
  "id" : 7560292438,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Miller",
      "screen_name" : "lindamiller",
      "indices" : [ 0, 12 ],
      "id_str" : "14825460",
      "id" : 14825460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7561189888",
  "geo" : { },
  "id_str" : "7561285478",
  "in_reply_to_user_id" : 14825460,
  "text" : "@lindamiller ooh nice, anything in particular?",
  "id" : 7561285478,
  "in_reply_to_status_id" : 7561189888,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "lindamiller",
  "in_reply_to_user_id_str" : "14825460",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ty Bennett",
      "screen_name" : "TyBennett",
      "indices" : [ 20, 30 ],
      "id_str" : "19639088",
      "id" : 19639088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7562384693",
  "text" : "genshai &gt;&gt; RT @tybennett A Powerful Word http:\/\/bit.ly\/11v38M",
  "id" : 7562384693,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "indices" : [ 3, 15 ],
      "id_str" : "23273932",
      "id" : 23273932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7563319889",
  "text" : "RT @CuresCancer: The easiest job in the world has to be coroner.... If everything went wrong, maybe you'd get a pulse~Dennis Miller",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7563217334",
    "text" : "The easiest job in the world has to be coroner.... If everything went wrong, maybe you'd get a pulse~Dennis Miller",
    "id" : 7563217334,
    "created_at" : "2010-01-09 17:34:04 +0000",
    "user" : {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "protected" : false,
      "id_str" : "23273932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609239639358988288\/AZfiLu4b_normal.png",
      "id" : 23273932,
      "verified" : false
    }
  },
  "id" : 7563319889,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "indices" : [ 3, 15 ],
      "id_str" : "23273932",
      "id" : 23273932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7563322024",
  "text" : "RT @CuresCancer: I like work: it fascinates me. I can sit and look at it for hours~Jerome K Jerome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7563146573",
    "text" : "I like work: it fascinates me. I can sit and look at it for hours~Jerome K Jerome",
    "id" : 7563146573,
    "created_at" : "2010-01-09 17:31:36 +0000",
    "user" : {
      "name" : "Kelley Eidem",
      "screen_name" : "CuresCancer",
      "protected" : false,
      "id_str" : "23273932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609239639358988288\/AZfiLu4b_normal.png",
      "id" : 23273932,
      "verified" : false
    }
  },
  "id" : 7563322024,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7563378568",
  "text" : "supposed to be going to mall but apparently skunk problem on property",
  "id" : 7563378568,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "comedybot",
      "screen_name" : "comedybot",
      "indices" : [ 3, 13 ],
      "id_str" : "38397232",
      "id" : 38397232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7539508870",
  "text" : "RT @comedybot: I intend to live forever - so far, so good. -Steven Wright \u263A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7450765616",
    "text" : "I intend to live forever - so far, so good. -Steven Wright \u263A",
    "id" : 7450765616,
    "created_at" : "2010-01-06 19:23:44 +0000",
    "user" : {
      "name" : "comedybot",
      "screen_name" : "comedybot",
      "protected" : false,
      "id_str" : "38397232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200231684\/140art-mascot-robot_normal.png",
      "id" : 38397232,
      "verified" : false
    }
  },
  "id" : 7539508870,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "indices" : [ 3, 18 ],
      "id_str" : "46816086",
      "id" : 46816086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7539515765",
  "text" : "RT @SpiritMaterial: If there is one thing I can't tolerate, it is intolerant people!  ;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7455034974",
    "text" : "If there is one thing I can't tolerate, it is intolerant people!  ;-)",
    "id" : 7455034974,
    "created_at" : "2010-01-06 21:52:32 +0000",
    "user" : {
      "name" : "Tom Stein",
      "screen_name" : "SpiritMaterial",
      "protected" : false,
      "id_str" : "46816086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614156520\/_MG_3263-WEB02_normal.jpg",
      "id" : 46816086,
      "verified" : false
    }
  },
  "id" : 7539515765,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7542187528",
  "text" : "I poured spot remover on my dog. Now he's gone. ; &gt;",
  "id" : 7542187528,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7555280523",
  "text" : "It's surprising how quickly you can swing from having unattain... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7555280523,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7557941766",
  "text" : "RT @abandontheherd: You have control over action alone never over it's fruits (Maharishi)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7556931070",
    "text" : "You have control over action alone never over it's fruits (Maharishi)",
    "id" : 7556931070,
    "created_at" : "2010-01-09 13:36:38 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7557941766,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    }, {
      "name" : "Lacy Kantra",
      "screen_name" : "dailyrandom",
      "indices" : [ 103, 115 ],
      "id_str" : "50500193",
      "id" : 50500193
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 91, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7557954321",
  "text" : "RT @abandontheherd: \"You don't drown by falling in the water. You drown by staying there.\" #quote (via @dailyrandom)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lacy Kantra",
        "screen_name" : "dailyrandom",
        "indices" : [ 83, 95 ],
        "id_str" : "50500193",
        "id" : 50500193
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7556849165",
    "text" : "\"You don't drown by falling in the water. You drown by staying there.\" #quote (via @dailyrandom)",
    "id" : 7556849165,
    "created_at" : "2010-01-09 13:32:52 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7557954321,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 3, 17 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 64, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7557987035",
  "text" : "RT @marwilliamson: The biggest antidote to chaos is stillness.  #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 45, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7554265829",
    "text" : "The biggest antidote to chaos is stillness.  #fb",
    "id" : 7554265829,
    "created_at" : "2010-01-09 11:15:11 +0000",
    "user" : {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "protected" : false,
      "id_str" : "21522338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507257000367882240\/cWcbBvzD_normal.jpeg",
      "id" : 21522338,
      "verified" : true
    }
  },
  "id" : 7557987035,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Miller",
      "screen_name" : "thedogcounselor",
      "indices" : [ 3, 19 ],
      "id_str" : "90096817",
      "id" : 90096817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7558064384",
  "text" : "RT @thedogcounselor: Please!!! Take extra care of your animals in this freezing weather!  Give some extra thought to how hard it must be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7548837274",
    "text" : "Please!!! Take extra care of your animals in this freezing weather!  Give some extra thought to how hard it must be on them.  Thanks!",
    "id" : 7548837274,
    "created_at" : "2010-01-09 06:18:19 +0000",
    "user" : {
      "name" : "Dean Miller",
      "screen_name" : "thedogcounselor",
      "protected" : false,
      "id_str" : "90096817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2637193188\/c3e4e4f053cca1ccda95f31d0b0627b0_normal.jpeg",
      "id" : 90096817,
      "verified" : false
    }
  },
  "id" : 7558064384,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "defythemind",
      "indices" : [ 3, 15 ],
      "id_str" : "279751736",
      "id" : 279751736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7558087558",
  "text" : "RT @DefyTheMind: Thoughts have been proven to DRASTICALLY affect Water. You, are 80% Water, Your Brain, 75%. So what are your thoughts d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 125, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7546656526",
    "text" : "Thoughts have been proven to DRASTICALLY affect Water. You, are 80% Water, Your Brain, 75%. So what are your thoughts doing? #quote",
    "id" : 7546656526,
    "created_at" : "2010-01-09 04:55:46 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 7558087558,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7558255546",
  "text" : "GM tweeties. I'm up. Don't ask for more. lol",
  "id" : 7558255546,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    }, {
      "name" : "Rowan.",
      "screen_name" : "RowanNs",
      "indices" : [ 73, 81 ],
      "id_str" : "222886265",
      "id" : 222886265
    }, {
      "name" : "Roger Highfield",
      "screen_name" : "RogerHighfield",
      "indices" : [ 86, 101 ],
      "id_str" : "46959037",
      "id" : 46959037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7558270070",
  "text" : "RT @RichardWiseman: Logos with hidden messages http:\/\/bit.ly\/75KOTE (via @rowanNS and @rogerhighfield)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rowan.",
        "screen_name" : "RowanNs",
        "indices" : [ 53, 61 ],
        "id_str" : "222886265",
        "id" : 222886265
      }, {
        "name" : "Roger Highfield",
        "screen_name" : "RogerHighfield",
        "indices" : [ 66, 81 ],
        "id_str" : "46959037",
        "id" : 46959037
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7553768479",
    "text" : "Logos with hidden messages http:\/\/bit.ly\/75KOTE (via @rowanNS and @rogerhighfield)",
    "id" : 7553768479,
    "created_at" : "2010-01-09 10:45:00 +0000",
    "user" : {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "protected" : false,
      "id_str" : "19512493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3225534671\/ef59c3b397d28dacb74034b47d8cd9e2_normal.jpeg",
      "id" : 19512493,
      "verified" : true
    }
  },
  "id" : 7558270070,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7558447707",
  "text" : "The Prosperity Prayer Affirmation http:\/\/5xrzq.th8.us",
  "id" : 7558447707,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7558723056",
  "text" : "Every time I close the door on reality, it comes in through the windows. -Jennifer Unlimited",
  "id" : 7558723056,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LoriMoreno",
      "screen_name" : "LoriMoreno",
      "indices" : [ 3, 14 ],
      "id_str" : "15039436",
      "id" : 15039436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7560230694",
  "text" : "RT @LoriMoreno: Trust yourself. You know more than you think you do.~Benjamin Spock",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7558950804",
    "text" : "Trust yourself. You know more than you think you do.~Benjamin Spock",
    "id" : 7558950804,
    "created_at" : "2010-01-09 15:01:18 +0000",
    "user" : {
      "name" : "LoriMoreno",
      "screen_name" : "LoriMoreno",
      "protected" : false,
      "id_str" : "15039436",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651143247499100160\/Qfg95x_L_normal.jpg",
      "id" : 15039436,
      "verified" : false
    }
  },
  "id" : 7560230694,
  "created_at" : "2010-01-09 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7516758465",
  "text" : "Your imagination can place a strain on your life today because... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7516758465,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7519856353",
  "text" : "RT @ChrisCade: Accept the good stuff, and move on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7507965852",
    "text" : "Accept the good stuff, and move on.",
    "id" : 7507965852,
    "created_at" : "2010-01-08 05:18:57 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7519856353,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "indices" : [ 3, 13 ],
      "id_str" : "15655376",
      "id" : 15655376
    }, {
      "name" : "Vincent Ang",
      "screen_name" : "Vincent_Ang",
      "indices" : [ 18, 30 ],
      "id_str" : "25204536",
      "id" : 25204536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7519859510",
  "text" : "RT @ChrisCade: RT @Vincent_Ang \"It's kind of fun to do the impossible.\" ~ Walt Disney #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vincent Ang",
        "screen_name" : "Vincent_Ang",
        "indices" : [ 3, 15 ],
        "id_str" : "25204536",
        "id" : 25204536
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7507954105",
    "text" : "RT @Vincent_Ang \"It's kind of fun to do the impossible.\" ~ Walt Disney #quote",
    "id" : 7507954105,
    "created_at" : "2010-01-08 05:18:32 +0000",
    "user" : {
      "name" : "Chris Cade",
      "screen_name" : "ChrisCade",
      "protected" : false,
      "id_str" : "15655376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000563652118\/15c28c7c24c1bfce2a7db48a46163b68_normal.jpeg",
      "id" : 15655376,
      "verified" : false
    }
  },
  "id" : 7519859510,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7519893891",
  "text" : "RT @BeALegacy: Mother Nature is providential. She gives us twelve years 2 develop a love 4 our children before turning them into teenage ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7507035792",
    "text" : "Mother Nature is providential. She gives us twelve years 2 develop a love 4 our children before turning them into teenagers. ~William Galvin",
    "id" : 7507035792,
    "created_at" : "2010-01-08 04:49:17 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 7519893891,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7520030154",
  "text" : "finally, at camo belt I'm remembering form ezier but still slower than other students",
  "id" : 7520030154,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7520141441",
  "text" : "and I still have to return too small xmas clothes.. haven't had time.. hopefully tomorrow!",
  "id" : 7520141441,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7520209547",
  "geo" : { },
  "id_str" : "7522096885",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 the boxes get thrown out.. hence labelling products..",
  "id" : 7522096885,
  "in_reply_to_status_id" : 7520209547,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7520045787",
  "geo" : { },
  "id_str" : "7522138649",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 true! should use AR and ask them to subscribe!",
  "id" : 7522138649,
  "in_reply_to_status_id" : 7520045787,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7521812004",
  "geo" : { },
  "id_str" : "7522178188",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 aww. mine works at home so I see him alot. I like it!",
  "id" : 7522178188,
  "in_reply_to_status_id" : 7521812004,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7522188587",
  "text" : "RT @mercola: DAILYTIP: The active ingredient in most antibacterial products TRICLOSAN not only kills bacteria it also has been shown to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7521127732",
    "text" : "DAILYTIP: The active ingredient in most antibacterial products TRICLOSAN not only kills bacteria it also has been shown to kill human cells.",
    "id" : 7521127732,
    "created_at" : "2010-01-08 15:03:29 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 7522188587,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7522194052",
  "geo" : { },
  "id_str" : "7522316224",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 hey, mine, too. he's a caretaker. He also has 2nd property up road (same owner) so not always yelling distance..hehe.",
  "id" : 7522316224,
  "in_reply_to_status_id" : 7522194052,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "indices" : [ 3, 12 ],
      "id_str" : "25058557",
      "id" : 25058557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7522323441",
  "text" : "RT @RevAnne1: EFT Affirm I choose Fabulousness! I AM Fabulous! http:\/\/ThinkitBeitSeeit.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7522291846",
    "text" : "EFT Affirm I choose Fabulousness! I AM Fabulous! http:\/\/ThinkitBeitSeeit.com",
    "id" : 7522291846,
    "created_at" : "2010-01-08 15:38:58 +0000",
    "user" : {
      "name" : "Rev. Anne Presuel",
      "screen_name" : "RevAnne1",
      "protected" : false,
      "id_str" : "25058557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2212762820\/507W6716aDONEa1_normal.jpg",
      "id" : 25058557,
      "verified" : false
    }
  },
  "id" : 7522323441,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7522509520",
  "geo" : { },
  "id_str" : "7522669885",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 individual here. weekend property. lives in city.",
  "id" : 7522669885,
  "in_reply_to_status_id" : 7522509520,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 3, 17 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7522793656",
  "text" : "RT @marwilliamson: We can't just fight all the darkness on the planet. We have to TURN ON MORE LIGHTS. Then darkness will be no more....#fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 117, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7506466089",
    "text" : "We can't just fight all the darkness on the planet. We have to TURN ON MORE LIGHTS. Then darkness will be no more....#fb",
    "id" : 7506466089,
    "created_at" : "2010-01-08 04:31:40 +0000",
    "user" : {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "protected" : false,
      "id_str" : "21522338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507257000367882240\/cWcbBvzD_normal.jpeg",
      "id" : 21522338,
      "verified" : true
    }
  },
  "id" : 7522793656,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Stacy",
      "screen_name" : "lindastacy",
      "indices" : [ 0, 11 ],
      "id_str" : "14333861",
      "id" : 14333861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7523172931",
  "geo" : { },
  "id_str" : "7523824532",
  "in_reply_to_user_id" : 14333861,
  "text" : "@lindastacy neutral for me",
  "id" : 7523824532,
  "in_reply_to_status_id" : 7523172931,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "lindastacy",
  "in_reply_to_user_id_str" : "14333861",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7536583808",
  "text" : "\u201CI couldn\u2019t wait for success, so I went ahead without it.\u201D -Jonathan Winters",
  "id" : 7536583808,
  "created_at" : "2010-01-08 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7462331292",
  "text" : "RT @abandontheherd: http:\/\/www.abandontheherd.com\/AbandonTheHerd\/Blog\/Entries\/2010\/1\/5_2010_Tree_A_Day_Photo_Challenge.html SEND ME A TR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7460839455",
    "text" : "http:\/\/www.abandontheherd.com\/AbandonTheHerd\/Blog\/Entries\/2010\/1\/5_2010_Tree_A_Day_Photo_Challenge.html SEND ME A TREE PHOTO!!",
    "id" : 7460839455,
    "created_at" : "2010-01-07 01:00:43 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7462331292,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7476903701",
  "text" : "good morning my tweeties! : )",
  "id" : 7476903701,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7477273210",
  "text" : "RT @twitingly: Kind words can be short and easy to speak, but their echoes are truly endless. - Mother Teresa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7464065267",
    "text" : "Kind words can be short and easy to speak, but their echoes are truly endless. - Mother Teresa",
    "id" : 7464065267,
    "created_at" : "2010-01-07 02:52:07 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 7477273210,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7477302992",
  "text" : "You might have a very intuitive take on your life, as if you a... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7477302992,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7478152122",
  "text" : "\u2665 You can't wrap love in a box ~ but you can wrap a person in a hug \u2665 Sending big hugs out to anyone who needs one \u2665",
  "id" : 7478152122,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7479175766",
  "text" : "Did i get sprinkled with faery dust cuz I feel giddy (or is that horse dust?) : )",
  "id" : 7479175766,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7478880822",
  "geo" : { },
  "id_str" : "7479229699",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 u need 2 move somewhere warmer..lol",
  "id" : 7479229699,
  "in_reply_to_status_id" : 7478880822,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7479571971",
  "text" : "Energizer Bunny arrested, charged with battery.",
  "id" : 7479571971,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7479612615",
  "text" : "hey, I just found my twitter replies area.. lol",
  "id" : 7479612615,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 0, 13 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7479593964",
  "geo" : { },
  "id_str" : "7479764946",
  "in_reply_to_user_id" : 14669290,
  "text" : "@aplacetobark that's precious..love the collar!",
  "id" : 7479764946,
  "in_reply_to_status_id" : 7479593964,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "aplacetobark",
  "in_reply_to_user_id_str" : "14669290",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 0, 13 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7479787306",
  "geo" : { },
  "id_str" : "7479972126",
  "in_reply_to_user_id" : 44163738,
  "text" : "@ralphmacchio here's to all the nice guys.. cheers!!-includes mine : )",
  "id" : 7479972126,
  "in_reply_to_status_id" : 7479787306,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ralphmacchio",
  "in_reply_to_user_id_str" : "44163738",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7480493952",
  "geo" : { },
  "id_str" : "7481154838",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 cream cheese sounds good, not sure about cranberries..hmm",
  "id" : 7481154838,
  "in_reply_to_status_id" : 7480493952,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7481482174",
  "geo" : { },
  "id_str" : "7481990533",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 now that is one cool idea!",
  "id" : 7481990533,
  "in_reply_to_status_id" : 7481482174,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7481291300",
  "geo" : { },
  "id_str" : "7482063500",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 have phone#? call her 2 go over, maybe you get bigger sale!",
  "id" : 7482063500,
  "in_reply_to_status_id" : 7481291300,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7482208014",
  "text" : "RT @Ravish30: Put all of my crochet hooks into the spaghetti storer and they fit perfectly. Now they are organized & protected :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7481482174",
    "text" : "Put all of my crochet hooks into the spaghetti storer and they fit perfectly. Now they are organized & protected :)",
    "id" : 7481482174,
    "created_at" : "2010-01-07 15:12:29 +0000",
    "user" : {
      "name" : "\u2665 Shelly - Louise",
      "screen_name" : "ClassyChicShel",
      "protected" : false,
      "id_str" : "23845064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749025439058956288\/2a5boEDx_normal.jpg",
      "id" : 23845064,
      "verified" : false
    }
  },
  "id" : 7482208014,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Mary Knebel",
      "screen_name" : "SelfHelpGoddess",
      "indices" : [ 20, 36 ],
      "id_str" : "20785170",
      "id" : 20785170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 98, 103 ]
    }, {
      "text" : "forgiveness",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7484005722",
  "text" : "RT @Encouraging: RT @SelfHelpGoddess You know that person who *really* hurt u? Yeah, they need ur #love & #forgiveness the most! It's true:)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary Knebel",
        "screen_name" : "SelfHelpGoddess",
        "indices" : [ 3, 19 ],
        "id_str" : "20785170",
        "id" : 20785170
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 81, 86 ]
      }, {
        "text" : "forgiveness",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7483814226",
    "text" : "RT @SelfHelpGoddess You know that person who *really* hurt u? Yeah, they need ur #love & #forgiveness the most! It's true:)",
    "id" : 7483814226,
    "created_at" : "2010-01-07 16:28:39 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7484005722,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7486343378",
  "text" : "RT @mercola: Major conflict of interest uncovered when WHO Vaccine advisor fails to disclose over $9M from vaccine manufacturer http:\/\/b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7485629239",
    "text" : "Major conflict of interest uncovered when WHO Vaccine advisor fails to disclose over $9M from vaccine manufacturer http:\/\/bit.ly\/777XDR",
    "id" : 7485629239,
    "created_at" : "2010-01-07 17:28:12 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 7486343378,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Robert G. Allen",
      "screen_name" : "BestSellerBob",
      "indices" : [ 20, 34 ],
      "id_str" : "18906805",
      "id" : 18906805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7486375853",
  "text" : "RT @Encouraging: RT @BestSellerBob When fear shows up, ask faith to step in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert G. Allen",
        "screen_name" : "BestSellerBob",
        "indices" : [ 3, 17 ],
        "id_str" : "18906805",
        "id" : 18906805
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7484834548",
    "text" : "RT @BestSellerBob When fear shows up, ask faith to step in.",
    "id" : 7484834548,
    "created_at" : "2010-01-07 17:01:56 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7486375853,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7490560323",
  "text" : "RT @abe_quotes: Never mind what the subject is. Concentrate on how you feel, and make a decision, \"Nothing is more important than that I ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7489753109",
    "text" : "Never mind what the subject is. Concentrate on how you feel, and make a decision, \"Nothing is more important than that I feel good.\"",
    "id" : 7489753109,
    "created_at" : "2010-01-07 19:45:29 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 7490560323,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 0, 11 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7459360105",
  "geo" : { },
  "id_str" : "7459879951",
  "in_reply_to_user_id" : 18840386,
  "text" : "@CaplinROUS some good quality capy time! ; )",
  "id" : 7459879951,
  "in_reply_to_status_id" : 7459360105,
  "created_at" : "2010-01-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "CaplinROUS",
  "in_reply_to_user_id_str" : "18840386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TonyRush \uF8FF",
      "screen_name" : "TonyRush",
      "indices" : [ 3, 12 ],
      "id_str" : "8906922",
      "id" : 8906922
    }, {
      "name" : "Joe Johnson",
      "screen_name" : "MarineRecon",
      "indices" : [ 14, 26 ],
      "id_str" : "13922782",
      "id" : 13922782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7421795765",
  "text" : "RT @TonyRush: @MarineRecon Oh, it's simple.  It just requires one to stop believing their beliefs are the only right beliefs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Johnson",
        "screen_name" : "MarineRecon",
        "indices" : [ 0, 12 ],
        "id_str" : "13922782",
        "id" : 13922782
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "7250643767",
    "geo" : { },
    "id_str" : "7253823193",
    "in_reply_to_user_id" : 13922782,
    "text" : "@MarineRecon Oh, it's simple.  It just requires one to stop believing their beliefs are the only right beliefs.",
    "id" : 7253823193,
    "in_reply_to_status_id" : 7250643767,
    "created_at" : "2010-01-01 01:02:03 +0000",
    "in_reply_to_screen_name" : "MarineRecon",
    "in_reply_to_user_id_str" : "13922782",
    "user" : {
      "name" : "TonyRush \uF8FF",
      "screen_name" : "TonyRush",
      "protected" : false,
      "id_str" : "8906922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590290053416538112\/4F8M4fHI_normal.jpg",
      "id" : 8906922,
      "verified" : false
    }
  },
  "id" : 7421795765,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7422376235",
  "text" : "hubby is so good to me.. braved to the cold to get me dessert!",
  "id" : 7422376235,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7439267129",
  "text" : "You may be the wild card in the group today, but aren't yet aw... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7439267129,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7443476969",
  "text" : "RT @BeALegacy: If you want to learn to love better, you should start with a friend who you don't like to play with.  ~Unkown Child",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7439086661",
    "text" : "If you want to learn to love better, you should start with a friend who you don't like to play with.  ~Unkown Child",
    "id" : 7439086661,
    "created_at" : "2010-01-06 12:28:10 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 7443476969,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7443518629",
  "text" : "RT @abandontheherd: Take a tree photo today and contribute! Details: http:\/\/www.abandontheherd.com\/AbandonTheHerd\/Blog\/Blog.html",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7438678735",
    "text" : "Take a tree photo today and contribute! Details: http:\/\/www.abandontheherd.com\/AbandonTheHerd\/Blog\/Blog.html",
    "id" : 7438678735,
    "created_at" : "2010-01-06 12:09:16 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7443518629,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "indices" : [ 3, 13 ],
      "id_str" : "29787449",
      "id" : 29787449
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7443524904",
  "text" : "RT @BeALegacy: While we try to teach our children all about life, Our children teach us what life is all about.  ~Angela Schwindt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7438635637",
    "text" : "While we try to teach our children all about life, Our children teach us what life is all about.  ~Angela Schwindt",
    "id" : 7438635637,
    "created_at" : "2010-01-06 12:07:07 +0000",
    "user" : {
      "name" : "Be A Legacy",
      "screen_name" : "BeALegacy",
      "protected" : false,
      "id_str" : "29787449",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629397432439209984\/UWGdbcia_normal.jpg",
      "id" : 29787449,
      "verified" : false
    }
  },
  "id" : 7443524904,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CHRIS VOSS",
      "screen_name" : "CHRISVOSS",
      "indices" : [ 3, 13 ],
      "id_str" : "23172966",
      "id" : 23172966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7443688473",
  "text" : "RT @CHRISVOSS: You never know how far reaching something you may say, think or do today may affect the lives of millions tomorrow. Palmer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7430237035",
    "text" : "You never know how far reaching something you may say, think or do today may affect the lives of millions tomorrow. Palmer",
    "id" : 7430237035,
    "created_at" : "2010-01-06 04:59:09 +0000",
    "user" : {
      "name" : "CHRIS VOSS",
      "screen_name" : "CHRISVOSS",
      "protected" : false,
      "id_str" : "23172966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765461483526299648\/ngMOcyPP_normal.jpg",
      "id" : 23172966,
      "verified" : false
    }
  },
  "id" : 7443688473,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave",
      "screen_name" : "HaywoodStubble",
      "indices" : [ 3, 18 ],
      "id_str" : "15887107",
      "id" : 15887107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7443698844",
  "text" : "RT @HaywoodStubble: God must be very great to have created a world that leaves a mystery as to whether he created it. -Richard Wurmbrand",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7429875610",
    "text" : "God must be very great to have created a world that leaves a mystery as to whether he created it. -Richard Wurmbrand",
    "id" : 7429875610,
    "created_at" : "2010-01-06 04:46:05 +0000",
    "user" : {
      "name" : "Dave",
      "screen_name" : "HaywoodStubble",
      "protected" : false,
      "id_str" : "15887107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/284939831\/ScreenHunter_195_normal.jpg",
      "id" : 15887107,
      "verified" : false
    }
  },
  "id" : 7443698844,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "defythemind",
      "indices" : [ 3, 15 ],
      "id_str" : "279751736",
      "id" : 279751736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7443705030",
  "text" : "RT @DefyTheMind: The way some people find fault, you'd think there was some kind of reward.  #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7429337204",
    "text" : "The way some people find fault, you'd think there was some kind of reward.  #quote",
    "id" : 7429337204,
    "created_at" : "2010-01-06 04:27:28 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 7443705030,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "defythemind",
      "indices" : [ 3, 15 ],
      "id_str" : "279751736",
      "id" : 279751736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7443731072",
  "text" : "RT @DefyTheMind: All that we need to make us happy is something to be enthusiastic about.  -Einstein  #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 85, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7428380698",
    "text" : "All that we need to make us happy is something to be enthusiastic about.  -Einstein  #quote",
    "id" : 7428380698,
    "created_at" : "2010-01-06 03:56:48 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 7443731072,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7444068565",
  "text" : "my best thoughts are at night falling asleep but can't remember them next day.. ack!",
  "id" : 7444068565,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7444073036",
  "geo" : { },
  "id_str" : "7447377183",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 wowza.. nice! : )",
  "id" : 7447377183,
  "in_reply_to_status_id" : 7444073036,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7447456293",
  "text" : "RT @CandyTX: Kindle Freebie: Happiness: A Guide by Matthieu Ricard http:\/\/www.amazon.com\/gp\/product\/B000SEUSXW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7447383597",
    "text" : "Kindle Freebie: Happiness: A Guide by Matthieu Ricard http:\/\/www.amazon.com\/gp\/product\/B000SEUSXW",
    "id" : 7447383597,
    "created_at" : "2010-01-06 17:25:57 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 7447456293,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7447639758",
  "text" : "by nature not a real chatty person.. but I'll try to post my thoughts more often",
  "id" : 7447639758,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7449402295",
  "text" : "my 14yo still complains about going to nursery school & preK years ago..",
  "id" : 7449402295,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fields",
      "screen_name" : "jonathanfields",
      "indices" : [ 3, 18 ],
      "id_str" : "11752272",
      "id" : 11752272
    }, {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "indices" : [ 42, 58 ],
      "id_str" : "10373972",
      "id" : 10373972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7452707078",
  "text" : "RT @jonathanfields: And your dreams... RT @chrisguillebeau Every time someone tells u 2 'b realistic' they r asking u 2 compromise ur ideals",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Guillebeau",
        "screen_name" : "chrisguillebeau",
        "indices" : [ 22, 38 ],
        "id_str" : "10373972",
        "id" : 10373972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7450435644",
    "text" : "And your dreams... RT @chrisguillebeau Every time someone tells u 2 'b realistic' they r asking u 2 compromise ur ideals",
    "id" : 7450435644,
    "created_at" : "2010-01-06 19:12:14 +0000",
    "user" : {
      "name" : "Jonathan Fields",
      "screen_name" : "jonathanfields",
      "protected" : false,
      "id_str" : "11752272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441600266878451714\/1FVwvwjd_normal.jpeg",
      "id" : 11752272,
      "verified" : false
    }
  },
  "id" : 7452707078,
  "created_at" : "2010-01-06 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7388003871",
  "text" : "RT @twitingly: Why do we teach kids that violence is not the answer and then have them read about wars in school that solved America's p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7382704070",
    "text" : "Why do we teach kids that violence is not the answer and then have them read about wars in school that solved America's problems?",
    "id" : 7382704070,
    "created_at" : "2010-01-04 23:18:50 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 7388003871,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Morrow",
      "screen_name" : "jonmorrow",
      "indices" : [ 3, 13 ],
      "id_str" : "2183837993",
      "id" : 2183837993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7388178753",
  "text" : "RT @JonMorrow: Brain device allows blind man to play tic-tac-toe with his daughter: http:\/\/bit.ly\/8XSsvf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7380993844",
    "text" : "Brain device allows blind man to play tic-tac-toe with his daughter: http:\/\/bit.ly\/8XSsvf",
    "id" : 7380993844,
    "created_at" : "2010-01-04 22:20:26 +0000",
    "user" : {
      "name" : "Smart Blogger",
      "screen_name" : "smartbloggerhq",
      "protected" : false,
      "id_str" : "10621792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755799323129020416\/CHdKrRpD_normal.jpg",
      "id" : 10621792,
      "verified" : false
    }
  },
  "id" : 7388178753,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7402643443",
  "text" : "Your faith in your friends can be a true gift to them, but tod... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7402643443,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "indices" : [ 3, 16 ],
      "id_str" : "22276232",
      "id" : 22276232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7404845085",
  "text" : "RT @successwalls: Don't compare your life to others. You have no idea what their journey is all about.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7403019368",
    "text" : "Don't compare your life to others. You have no idea what their journey is all about.",
    "id" : 7403019368,
    "created_at" : "2010-01-05 13:24:05 +0000",
    "user" : {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "protected" : false,
      "id_str" : "22276232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840968112\/twitrSWicon2_normal.jpg",
      "id" : 22276232,
      "verified" : false
    }
  },
  "id" : 7404845085,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7405067474",
  "text" : "RT @LaughingBaba: My Newest Post on the subject of karma in our lives: Body of Light Blog http:\/\/bodyoflightblog.blogspot.com\/?spref=tw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7400417307",
    "text" : "My Newest Post on the subject of karma in our lives: Body of Light Blog http:\/\/bodyoflightblog.blogspot.com\/?spref=tw",
    "id" : 7400417307,
    "created_at" : "2010-01-05 11:14:24 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 7405067474,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7405072364",
  "text" : "RT @BigBookofYou: Love is the answer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7397681648",
    "text" : "Love is the answer.",
    "id" : 7397681648,
    "created_at" : "2010-01-05 08:26:27 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 7405072364,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7405387960",
  "text" : "RT @twitingly: Is a castrated pig disgruntled?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7393271944",
    "text" : "Is a castrated pig disgruntled?",
    "id" : 7393271944,
    "created_at" : "2010-01-05 04:58:31 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 7405387960,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7405491953",
  "text" : "RT @BigBookofYou: The more you think you need physical force to control life, the less you control life~frm Ceasar Milan Dog Whisperer S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7392678845",
    "text" : "The more you think you need physical force to control life, the less you control life~frm Ceasar Milan Dog Whisperer Show I'm watching",
    "id" : 7392678845,
    "created_at" : "2010-01-05 04:37:29 +0000",
    "user" : {
      "name" : "Jennifer McLean",
      "screen_name" : "meetjennmclean",
      "protected" : false,
      "id_str" : "14563201",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701981425361260544\/JZuInE43_normal.jpg",
      "id" : 14563201,
      "verified" : false
    }
  },
  "id" : 7405491953,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 0, 9 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7406578019",
  "geo" : { },
  "id_str" : "7407117197",
  "in_reply_to_user_id" : 23845064,
  "text" : "@Ravish30 care to elaborate? I'm always curious : ) anyway good4u to make decision!",
  "id" : 7407117197,
  "in_reply_to_status_id" : 7406578019,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "ClassyChicShel",
  "in_reply_to_user_id_str" : "23845064",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ravish",
      "screen_name" : "ravish30",
      "indices" : [ 3, 12 ],
      "id_str" : "443493421",
      "id" : 443493421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7407171813",
  "text" : "RT @Ravish30: I hate when people u don't know, call you but don't leave their name or why they are calling. What is the point of that?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7405214786",
    "text" : "I hate when people u don't know, call you but don't leave their name or why they are calling. What is the point of that?",
    "id" : 7405214786,
    "created_at" : "2010-01-05 14:53:06 +0000",
    "user" : {
      "name" : "\u2665 Shelly - Louise",
      "screen_name" : "ClassyChicShel",
      "protected" : false,
      "id_str" : "23845064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749025439058956288\/2a5boEDx_normal.jpg",
      "id" : 23845064,
      "verified" : false
    }
  },
  "id" : 7407171813,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7407224467",
  "text" : "I am officially addicted to whirlyword app on my touch.. lol",
  "id" : 7407224467,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7408215158",
  "text" : "RT @abe_quotes: Fear only exists when you do not understand that you have the power to project thought and that the Universe will respon ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Abraham",
        "indices" : [ 124, 132 ]
      }, {
        "text" : "Hicks",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7407543620",
    "text" : "Fear only exists when you do not understand that you have the power to project thought and that the Universe will respond.\n\n#Abraham #Hicks",
    "id" : 7407543620,
    "created_at" : "2010-01-05 16:19:56 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 7408215158,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7408215925",
  "text" : "RT @abe_quotes: Parents can\u2019t choose the mates of their children ...You actually can\u2019t choose anything for your children w\/o disempoweri ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Abe",
        "indices" : [ 130, 134 ]
      }, {
        "text" : "LoA",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7407514737",
    "text" : "Parents can\u2019t choose the mates of their children ...You actually can\u2019t choose anything for your children w\/o disempowering them.\n\n#Abe #LoA",
    "id" : 7407514737,
    "created_at" : "2010-01-05 16:18:50 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 7408215925,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7408794261",
  "text" : "May the forces of evil become confused on the way to your house.~ George Carlin",
  "id" : 7408794261,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7410231672",
  "text" : "As an American, I refuse to buy mandatory health insurance that supports corrupt conventional medicine http:\/\/bit.ly\/4QvEMu",
  "id" : 7410231672,
  "created_at" : "2010-01-05 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7365823277",
  "text" : "This is not a time for you to undertake a project by yourself.... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7365823277,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "indices" : [ 3, 16 ],
      "id_str" : "22276232",
      "id" : 22276232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7368945555",
  "text" : "RT @successwalls: \"No horse gets anywhere until he is harnessed. No life ever grows great until it is focused, dedicated, and discipline ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7366041310",
    "text" : "\"No horse gets anywhere until he is harnessed. No life ever grows great until it is focused, dedicated, and disciplined.\" -Harry Fosdick",
    "id" : 7366041310,
    "created_at" : "2010-01-04 12:57:59 +0000",
    "user" : {
      "name" : "Success Wallpapers",
      "screen_name" : "successwalls",
      "protected" : false,
      "id_str" : "22276232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/840968112\/twitrSWicon2_normal.jpg",
      "id" : 22276232,
      "verified" : false
    }
  },
  "id" : 7368945555,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "indices" : [ 3, 15 ],
      "id_str" : "20882372",
      "id" : 20882372
    }, {
      "name" : "Mary Knebel",
      "screen_name" : "SelfHelpGoddess",
      "indices" : [ 20, 36 ],
      "id_str" : "20785170",
      "id" : 20785170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7368956206",
  "text" : "RT @Encouraging: RT @SelfHelpGoddess Instead of fearing the worst, why not start expecting the best!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary Knebel",
        "screen_name" : "SelfHelpGoddess",
        "indices" : [ 3, 19 ],
        "id_str" : "20785170",
        "id" : 20785170
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7365223619",
    "text" : "RT @SelfHelpGoddess Instead of fearing the worst, why not start expecting the best!",
    "id" : 7365223619,
    "created_at" : "2010-01-04 12:20:29 +0000",
    "user" : {
      "name" : "Thomas Waterhouse",
      "screen_name" : "Encouraging",
      "protected" : false,
      "id_str" : "20882372",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458865632293826561\/mQs3BsLZ_normal.png",
      "id" : 20882372,
      "verified" : false
    }
  },
  "id" : 7368956206,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Riggs",
      "screen_name" : "defythemind",
      "indices" : [ 3, 15 ],
      "id_str" : "279751736",
      "id" : 279751736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loa",
      "indices" : [ 60, 64 ]
    }, {
      "text" : "Success",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7369126399",
  "text" : "RT @DefyTheMind: Someone said I was BrainWashed by all this #loa #Success stuff.  Know what?  I needed my Brain Washed..  :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loa",
        "indices" : [ 43, 47 ]
      }, {
        "text" : "Success",
        "indices" : [ 48, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7354420067",
    "text" : "Someone said I was BrainWashed by all this #loa #Success stuff.  Know what?  I needed my Brain Washed..  :-)",
    "id" : 7354420067,
    "created_at" : "2010-01-04 03:37:51 +0000",
    "user" : {
      "name" : "Joe Riggs",
      "screen_name" : "WorldOfJoeRiggs",
      "protected" : false,
      "id_str" : "29251361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661352842654031872\/4pUC16jl_normal.jpg",
      "id" : 29251361,
      "verified" : false
    }
  },
  "id" : 7369126399,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "empower",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7370980920",
  "text" : "Free download - the Self Empowerment Guidebook:  http:\/\/snipr.com\/tygpt #empower",
  "id" : 7370980920,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7371565575",
  "text" : "Email Marketing with TrafficWave.net: Your 24\/7 Sales Force!  Free Trial http:\/\/www.trafficwave.net\/members\/prowealth\/features.html",
  "id" : 7371565575,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7374521187",
  "text" : "RT @desireinaction: Never confuse a single defeat with a final defeat. ~F. Scott Fitzgerald",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6721963160",
    "text" : "Never confuse a single defeat with a final defeat. ~F. Scott Fitzgerald",
    "id" : 6721963160,
    "created_at" : "2009-12-16 05:50:29 +0000",
    "user" : {
      "name" : "BBMClub",
      "screen_name" : "BBMClub",
      "protected" : false,
      "id_str" : "47318227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1005871765\/me_2_normal.jpg",
      "id" : 47318227,
      "verified" : false
    }
  },
  "id" : 7374521187,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Stacy",
      "screen_name" : "lindastacy",
      "indices" : [ 3, 14 ],
      "id_str" : "14333861",
      "id" : 14333861
    }, {
      "name" : "Melissa Ingold",
      "screen_name" : "imsweetie",
      "indices" : [ 19, 29 ],
      "id_str" : "335588122",
      "id" : 335588122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7375871580",
  "text" : "RT @lindastacy: RT @imsweetie: Free planning sheets, checklist, and more for your 2010 business planning binder =&gt; http:\/\/su.pr\/2zQ8XK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melissa Ingold",
        "screen_name" : "imsweetie",
        "indices" : [ 3, 13 ],
        "id_str" : "335588122",
        "id" : 335588122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7372193057",
    "text" : "RT @imsweetie: Free planning sheets, checklist, and more for your 2010 business planning binder =&gt; http:\/\/su.pr\/2zQ8XK",
    "id" : 7372193057,
    "created_at" : "2010-01-04 16:52:41 +0000",
    "user" : {
      "name" : "Linda Stacy",
      "screen_name" : "lindastacy",
      "protected" : false,
      "id_str" : "14333861",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/52562805\/eyes_normal.jpg",
      "id" : 14333861,
      "verified" : false
    }
  },
  "id" : 7375871580,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Abraham",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "Hicks",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "LoA",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7375964476",
  "text" : "RT @abe_quotes: You have all of the power. You're either allowing alignment or not...It really is that simple.\n\n#Abraham #Hicks #LoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Abraham",
        "indices" : [ 96, 104 ]
      }, {
        "text" : "Hicks",
        "indices" : [ 105, 111 ]
      }, {
        "text" : "LoA",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7374481643",
    "text" : "You have all of the power. You're either allowing alignment or not...It really is that simple.\n\n#Abraham #Hicks #LoA",
    "id" : 7374481643,
    "created_at" : "2010-01-04 18:17:55 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 7375964476,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "indices" : [ 3, 15 ],
      "id_str" : "5520952",
      "id" : 5520952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7376051143",
  "text" : "RT @paulocoelho: 20 SEC READING: The Path http:\/\/bit.ly\/6DbSyw Espanol http:\/\/bit.ly\/79QZjs Portugues http:\/\/bit.ly\/6aU5t7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7373937147",
    "text" : "20 SEC READING: The Path http:\/\/bit.ly\/6DbSyw Espanol http:\/\/bit.ly\/79QZjs Portugues http:\/\/bit.ly\/6aU5t7",
    "id" : 7373937147,
    "created_at" : "2010-01-04 17:57:44 +0000",
    "user" : {
      "name" : "Paulo Coelho",
      "screen_name" : "paulocoelho",
      "protected" : false,
      "id_str" : "5520952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791423363797377024\/svEXr6X8_normal.jpg",
      "id" : 5520952,
      "verified" : true
    }
  },
  "id" : 7376051143,
  "created_at" : "2010-01-04 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BILLY COX",
      "screen_name" : "Billy_Cox",
      "indices" : [ 3, 13 ],
      "id_str" : "23249204",
      "id" : 23249204
    }, {
      "name" : "Steve B",
      "screen_name" : "steveb2u",
      "indices" : [ 117, 126 ],
      "id_str" : "35615167",
      "id" : 35615167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DecadeOfHope",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7338234052",
  "text" : "RT @Billy_Cox: This country cannot afford to be materially rich and spiritually poor.   John Fitzgerald Kennedy (via @steveb2u)#DecadeOfHope",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve B",
        "screen_name" : "steveb2u",
        "indices" : [ 102, 111 ],
        "id_str" : "35615167",
        "id" : 35615167
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DecadeOfHope",
        "indices" : [ 112, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7335461134",
    "text" : "This country cannot afford to be materially rich and spiritually poor.   John Fitzgerald Kennedy (via @steveb2u)#DecadeOfHope",
    "id" : 7335461134,
    "created_at" : "2010-01-03 16:09:46 +0000",
    "user" : {
      "name" : "BILLY COX",
      "screen_name" : "Billy_Cox",
      "protected" : false,
      "id_str" : "23249204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429502767686619137\/jcAjBiF0_normal.jpeg",
      "id" : 23249204,
      "verified" : false
    }
  },
  "id" : 7338234052,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7338247698",
  "text" : "RT @CaplinROUS: They are animals! RT @Inthehillsfish: RT @Silixell: \"The best things in life aren't things.\"   ~ Art Buchwald",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "silixell",
        "screen_name" : "silixell",
        "indices" : [ 41, 50 ],
        "id_str" : "2492259379",
        "id" : 2492259379
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7335172145",
    "text" : "They are animals! RT @Inthehillsfish: RT @Silixell: \"The best things in life aren't things.\"   ~ Art Buchwald",
    "id" : 7335172145,
    "created_at" : "2010-01-03 15:57:24 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 7338247698,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7338917668",
  "text" : "Updated my Free Website List. Need a free, easy to use website? I'm collecting them into a list http:\/\/budurl.com\/freewebsitelist",
  "id" : 7338917668,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louise Hay",
      "screen_name" : "LouiseHay",
      "indices" : [ 3, 13 ],
      "id_str" : "21135496",
      "id" : 21135496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7339673469",
  "text" : "RT @LouiseHay: stop all criticism",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7338079685",
    "text" : "stop all criticism",
    "id" : 7338079685,
    "created_at" : "2010-01-03 18:00:56 +0000",
    "user" : {
      "name" : "Louise Hay",
      "screen_name" : "LouiseHay",
      "protected" : false,
      "id_str" : "21135496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/79423478\/ScreenHunter_06_Feb._17_14.45_normal.jpg",
      "id" : 21135496,
      "verified" : false
    }
  },
  "id" : 7339673469,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7339707409",
  "text" : "reading messages from your angels by doreen virtue",
  "id" : 7339707409,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wally Conger",
      "screen_name" : "wconger",
      "indices" : [ 3, 11 ],
      "id_str" : "22069193",
      "id" : 22069193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7342201582",
  "text" : "RT @wconger: A tree in our front yard is filled with Monarch butterflies this afternoon. So freakin' cool.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7341675452",
    "text" : "A tree in our front yard is filled with Monarch butterflies this afternoon. So freakin' cool.",
    "id" : 7341675452,
    "created_at" : "2010-01-03 20:19:02 +0000",
    "user" : {
      "name" : "Wally Conger",
      "screen_name" : "wconger",
      "protected" : false,
      "id_str" : "22069193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/178894867\/Wally3_normal.jpg",
      "id" : 22069193,
      "verified" : false
    }
  },
  "id" : 7342201582,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wally Conger",
      "screen_name" : "wconger",
      "indices" : [ 0, 8 ],
      "id_str" : "22069193",
      "id" : 22069193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7342220708",
  "in_reply_to_user_id" : 22069193,
  "text" : "@wconger hope you get some pics and share! : )",
  "id" : 7342220708,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "wconger",
  "in_reply_to_user_id_str" : "22069193",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7316060235",
  "text" : "I don't know if I can bear to watch Dr. Who tonight : (",
  "id" : 7316060235,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7331237103",
  "text" : "You may be set in your ways now and have a specific strategy a... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7331237103,
  "created_at" : "2010-01-03 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twittascope.com\" rel=\"nofollow\"\u003ETwittascope\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7298313859",
  "text" : "Your mind may wander off course today and you could even lose ... More for Pisces http:\/\/twittascope.com\/twittascope\/?sign=12",
  "id" : 7298313859,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7302945673",
  "text" : "taking girls out today to get owl, panda at buildabear..I want the buffalo.. waah!",
  "id" : 7302945673,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7302988709",
  "text" : "RT @abandontheherd: Don't forget: Leave the baggage behind with 2009",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7302214146",
    "text" : "Don't forget: Leave the baggage behind with 2009",
    "id" : 7302214146,
    "created_at" : "2010-01-02 15:47:34 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 7302988709,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7303027348",
  "text" : "RT @twitingly: If ignorance is bliss, why aren't there more happy people?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7301119589",
    "text" : "If ignorance is bliss, why aren't there more happy people?",
    "id" : 7301119589,
    "created_at" : "2010-01-02 14:56:49 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 7303027348,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Tweets",
      "screen_name" : "twitingly",
      "indices" : [ 3, 13 ],
      "id_str" : "1335469837",
      "id" : 1335469837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7303034763",
  "text" : "RT @twitingly: If the human brain were so simple we could understand it, we would be so simple we couldn't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7301113238",
    "text" : "If the human brain were so simple we could understand it, we would be so simple we couldn't.",
    "id" : 7301113238,
    "created_at" : "2010-01-02 14:56:31 +0000",
    "user" : {
      "name" : "Alex Telman \u1D34\u1D31\u1D2C\u1D38\u1D31\u1D3F",
      "screen_name" : "AlexTelman",
      "protected" : false,
      "id_str" : "95304055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2483441939\/i7cv06u20w0ady9npqn6_normal.jpeg",
      "id" : 95304055,
      "verified" : false
    }
  },
  "id" : 7303034763,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Joe Schmitt",
      "screen_name" : "joeschmitt",
      "indices" : [ 15, 26 ],
      "id_str" : "15665583",
      "id" : 15665583
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7303312448",
  "text" : "RT @BestAt: RT @joeschmitt: So I take it we're NOT counting down every night?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Schmitt",
        "screen_name" : "joeschmitt",
        "indices" : [ 3, 14 ],
        "id_str" : "15665583",
        "id" : 15665583
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7294013742",
    "text" : "RT @joeschmitt: So I take it we're NOT counting down every night?",
    "id" : 7294013742,
    "created_at" : "2010-01-02 07:38:55 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 7303312448,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean Miller",
      "screen_name" : "thedogcounselor",
      "indices" : [ 3, 19 ],
      "id_str" : "90096817",
      "id" : 90096817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7313689721",
  "text" : "RT @thedogcounselor: About their new pup, 2 little girls told me they \"Prayed for the dog that needed them most.\" How beautiful is that??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7279419491",
    "text" : "About their new pup, 2 little girls told me they \"Prayed for the dog that needed them most.\" How beautiful is that??",
    "id" : 7279419491,
    "created_at" : "2010-01-01 21:26:53 +0000",
    "user" : {
      "name" : "Dean Miller",
      "screen_name" : "thedogcounselor",
      "protected" : false,
      "id_str" : "90096817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2637193188\/c3e4e4f053cca1ccda95f31d0b0627b0_normal.jpeg",
      "id" : 90096817,
      "verified" : false
    }
  },
  "id" : 7313689721,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7313745162",
  "text" : "no buildabear.. anime store instead. I got 2 books from BN.. doreen virtue and sonia choquette.",
  "id" : 7313745162,
  "created_at" : "2010-01-02 00:00:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]