Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737812079248322560",
  "text" : "RT @pankhearst: For Books' Sake: \u2018Most women still have a terror of fat, even if they are allies\u2019: why feminists still can\u2019t ha... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/f7dPySCeUq",
        "expanded_url" : "http:\/\/ow.ly\/fFff500SZxd",
        "display_url" : "ow.ly\/fFff500SZxd"
      } ]
    },
    "geo" : { },
    "id_str" : "737807064492322816",
    "text" : "For Books' Sake: \u2018Most women still have a terror of fat, even if they are allies\u2019: why feminists still can\u2019t ha... https:\/\/t.co\/f7dPySCeUq",
    "id" : 737807064492322816,
    "created_at" : "2016-06-01 00:44:46 +0000",
    "user" : {
      "name" : "Furious",
      "screen_name" : "candryll",
      "protected" : false,
      "id_str" : "400348333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796374771940212736\/FdZPtyp2_normal.jpg",
      "id" : 400348333,
      "verified" : false
    }
  },
  "id" : 737812079248322560,
  "created_at" : "2016-06-01 01:04:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YorkshireShepherdess",
      "screen_name" : "AmandaOwen8",
      "indices" : [ 3, 15 ],
      "id_str" : "497353176",
      "id" : 497353176
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 105, 111 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737805493629034497",
  "text" : "RT @AmandaOwen8: When you sit quiet and take a closer look amongst the greenery the place becomes alive.\n#birds #wildlife https:\/\/t.co\/1O5i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmandaOwen8\/status\/737747861039927296\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/1O5ik0snN9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj0Bn0AUoAA8ZaT.jpg",
        "id_str" : "737747697445150720",
        "id" : 737747697445150720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj0Bn0AUoAA8ZaT.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1O5ik0snN9"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AmandaOwen8\/status\/737747861039927296\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/1O5ik0snN9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj0Bn5zUkAEG2Rd.jpg",
        "id_str" : "737747699001233409",
        "id" : 737747699001233409,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj0Bn5zUkAEG2Rd.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1O5ik0snN9"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AmandaOwen8\/status\/737747861039927296\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/1O5ik0snN9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj0Bn5zUUAAb1EH.jpg",
        "id_str" : "737747699001217024",
        "id" : 737747699001217024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj0Bn5zUUAAb1EH.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1O5ik0snN9"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AmandaOwen8\/status\/737747861039927296\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/1O5ik0snN9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj0Bn58VEAEI14_.jpg",
        "id_str" : "737747699039014913",
        "id" : 737747699039014913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj0Bn58VEAEI14_.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1O5ik0snN9"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 88, 94 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737747861039927296",
    "text" : "When you sit quiet and take a closer look amongst the greenery the place becomes alive.\n#birds #wildlife https:\/\/t.co\/1O5ik0snN9",
    "id" : 737747861039927296,
    "created_at" : "2016-05-31 20:49:31 +0000",
    "user" : {
      "name" : "YorkshireShepherdess",
      "screen_name" : "AmandaOwen8",
      "protected" : false,
      "id_str" : "497353176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537020732405211136\/lcQtvBOf_normal.jpeg",
      "id" : 497353176,
      "verified" : false
    }
  },
  "id" : 737805493629034497,
  "created_at" : "2016-06-01 00:38:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737802694677671936",
  "text" : "RT @BrianRathbone: Retweets are like pollen being spread by friendly honey bees. Fly pollen! Be free!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737801068088807425",
    "text" : "Retweets are like pollen being spread by friendly honey bees. Fly pollen! Be free!",
    "id" : 737801068088807425,
    "created_at" : "2016-06-01 00:20:56 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 737802694677671936,
  "created_at" : "2016-06-01 00:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalFarmersUnion",
      "screen_name" : "NFUtweets",
      "indices" : [ 3, 13 ],
      "id_str" : "61736345",
      "id" : 61736345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NFUtweets\/status\/737722551535800320\/video\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/YQSB3ZNeuG",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/737722515716333568\/pu\/img\/nee5v-NvSAxluiC4.jpg",
      "id_str" : "737722515716333568",
      "id" : 737722515716333568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/737722515716333568\/pu\/img\/nee5v-NvSAxluiC4.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YQSB3ZNeuG"
    } ],
    "hashtags" : [ {
      "text" : "happycows",
      "indices" : [ 79, 89 ]
    }, {
      "text" : "WorldMilkDay",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737792075542958080",
  "text" : "RT @NFUtweets: Using soft brushes are just one way that British farmers ensure #happycows on #WorldMilkDay https:\/\/t.co\/YQSB3ZNeuG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NFUtweets\/status\/737722551535800320\/video\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/YQSB3ZNeuG",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/737722515716333568\/pu\/img\/nee5v-NvSAxluiC4.jpg",
        "id_str" : "737722515716333568",
        "id" : 737722515716333568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/737722515716333568\/pu\/img\/nee5v-NvSAxluiC4.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YQSB3ZNeuG"
      } ],
      "hashtags" : [ {
        "text" : "happycows",
        "indices" : [ 64, 74 ]
      }, {
        "text" : "WorldMilkDay",
        "indices" : [ 78, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737722551535800320",
    "text" : "Using soft brushes are just one way that British farmers ensure #happycows on #WorldMilkDay https:\/\/t.co\/YQSB3ZNeuG",
    "id" : 737722551535800320,
    "created_at" : "2016-05-31 19:08:57 +0000",
    "user" : {
      "name" : "NationalFarmersUnion",
      "screen_name" : "NFUtweets",
      "protected" : false,
      "id_str" : "61736345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440456755001044993\/No50a-yO_normal.jpeg",
      "id" : 61736345,
      "verified" : false
    }
  },
  "id" : 737792075542958080,
  "created_at" : "2016-05-31 23:45:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/19yVqvX4vI",
      "expanded_url" : "https:\/\/vine.co\/v\/iVUXBjEieFV",
      "display_url" : "vine.co\/v\/iVUXBjEieFV"
    } ]
  },
  "geo" : { },
  "id_str" : "737758589230649344",
  "text" : "RT @1CatShepherd: Cat naps are written into the supervisor's contract as supervision of humans is exhausting  https:\/\/t.co\/19yVqvX4vI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/19yVqvX4vI",
        "expanded_url" : "https:\/\/vine.co\/v\/iVUXBjEieFV",
        "display_url" : "vine.co\/v\/iVUXBjEieFV"
      } ]
    },
    "geo" : { },
    "id_str" : "737756254358114304",
    "text" : "Cat naps are written into the supervisor's contract as supervision of humans is exhausting  https:\/\/t.co\/19yVqvX4vI",
    "id" : 737756254358114304,
    "created_at" : "2016-05-31 21:22:52 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 737758589230649344,
  "created_at" : "2016-05-31 21:32:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/737703862010818560\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/fm8cPMJ7w9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjzZvy1VEAAmEBc.jpg",
      "id_str" : "737703854104449024",
      "id" : 737703854104449024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjzZvy1VEAAmEBc.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 1041
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fm8cPMJ7w9"
    } ],
    "hashtags" : [ {
      "text" : "springwatch",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737749108497219584",
  "text" : "RT @Swanwhisperer: #springwatch ive never been attacked by a swan :) they call me the swan whisperer https:\/\/t.co\/fm8cPMJ7w9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/737703862010818560\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/fm8cPMJ7w9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjzZvy1VEAAmEBc.jpg",
        "id_str" : "737703854104449024",
        "id" : 737703854104449024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjzZvy1VEAAmEBc.jpg",
        "sizes" : [ {
          "h" : 623,
          "resize" : "fit",
          "w" : 1041
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fm8cPMJ7w9"
      } ],
      "hashtags" : [ {
        "text" : "springwatch",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737703862010818560",
    "text" : "#springwatch ive never been attacked by a swan :) they call me the swan whisperer https:\/\/t.co\/fm8cPMJ7w9",
    "id" : 737703862010818560,
    "created_at" : "2016-05-31 17:54:41 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 737749108497219584,
  "created_at" : "2016-05-31 20:54:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/nc7SymIMNV",
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/737702094963134465",
      "display_url" : "twitter.com\/Swanwhisperer\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737748417452072960",
  "text" : "amazing they let you get so close! : ) https:\/\/t.co\/nc7SymIMNV",
  "id" : 737748417452072960,
  "created_at" : "2016-05-31 20:51:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 0, 9 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737631370210611200",
  "geo" : { },
  "id_str" : "737674685991751680",
  "in_reply_to_user_id" : 13046992,
  "text" : "@mhawksey i had to use IE to authorize. Chrome wouldnt show authorize link. Ad blocker turned off. (in case others have same issue)",
  "id" : 737674685991751680,
  "in_reply_to_status_id" : 737631370210611200,
  "created_at" : "2016-05-31 15:58:45 +0000",
  "in_reply_to_screen_name" : "mhawksey",
  "in_reply_to_user_id_str" : "13046992",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737673838717239296",
  "text" : "RT @mhawksey: In case you missed it archiving tweets into Google Sheets (TAGS) got a little easier (no developer signup required)  https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9Zvjag4V8d",
        "expanded_url" : "https:\/\/mashe.hawksey.info\/2016\/05\/twitter-archive-google-sheets-tags-just-got-a-bit-easier-with-an-easy-setup\/",
        "display_url" : "mashe.hawksey.info\/2016\/05\/twitte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737631370210611200",
    "text" : "In case you missed it archiving tweets into Google Sheets (TAGS) got a little easier (no developer signup required)  https:\/\/t.co\/9Zvjag4V8d",
    "id" : 737631370210611200,
    "created_at" : "2016-05-31 13:06:37 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 737673838717239296,
  "created_at" : "2016-05-31 15:55:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Lidder",
      "screen_name" : "CollieColleen",
      "indices" : [ 3, 17 ],
      "id_str" : "396075623",
      "id" : 396075623
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/733598690829438977\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/yOATKAhXeB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci5EH0WVAAI7Nhe.jpg",
      "id_str" : "733598690410037250",
      "id" : 733598690410037250,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci5EH0WVAAI7Nhe.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yOATKAhXeB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737672474314342404",
  "text" : "RT @CollieColleen: Mutual observation over a late breakfast. https:\/\/t.co\/yOATKAhXeB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/733598690829438977\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/yOATKAhXeB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci5EH0WVAAI7Nhe.jpg",
        "id_str" : "733598690410037250",
        "id" : 733598690410037250,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci5EH0WVAAI7Nhe.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yOATKAhXeB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733598690829438977",
    "text" : "Mutual observation over a late breakfast. https:\/\/t.co\/yOATKAhXeB",
    "id" : 733598690829438977,
    "created_at" : "2016-05-20 10:02:12 +0000",
    "user" : {
      "name" : "Angela Lidder",
      "screen_name" : "CollieColleen",
      "protected" : false,
      "id_str" : "396075623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249749495\/20120306_79_normal.jpg",
      "id" : 396075623,
      "verified" : false
    }
  },
  "id" : 737672474314342404,
  "created_at" : "2016-05-31 15:49:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737671984067293184",
  "text" : "yay.. i fixed my twitter archive. had to use IE cuz chrome wasnt showing the authenticate msgs.",
  "id" : 737671984067293184,
  "created_at" : "2016-05-31 15:48:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Enns",
      "screen_name" : "peteenns",
      "indices" : [ 3, 12 ],
      "id_str" : "130267418",
      "id" : 130267418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737465091193475074",
  "text" : "RT @peteenns: I would say that living a dis-integrated, unreflective, false self, cost me 14 years of awareness. There is no... https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/nExAxeHaRU",
        "expanded_url" : "http:\/\/fb.me\/7qXvCt9dd",
        "display_url" : "fb.me\/7qXvCt9dd"
      } ]
    },
    "geo" : { },
    "id_str" : "737460306084007936",
    "text" : "I would say that living a dis-integrated, unreflective, false self, cost me 14 years of awareness. There is no... https:\/\/t.co\/nExAxeHaRU",
    "id" : 737460306084007936,
    "created_at" : "2016-05-31 01:46:52 +0000",
    "user" : {
      "name" : "Peter Enns",
      "screen_name" : "peteenns",
      "protected" : false,
      "id_str" : "130267418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742055830057553920\/CSedeoZ3_normal.jpg",
      "id" : 130267418,
      "verified" : false
    }
  },
  "id" : 737465091193475074,
  "created_at" : "2016-05-31 02:05:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737463599145291776",
  "text" : "just spent 15 minutes hiding from the bat..lol",
  "id" : 737463599145291776,
  "created_at" : "2016-05-31 01:59:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jamie",
      "screen_name" : "gnuman1979",
      "indices" : [ 3, 14 ],
      "id_str" : "257715213",
      "id" : 257715213
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gnuman1979\/status\/737451551447359488\/photo\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/ow66IedW6D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjv0RozUkAESq9I.jpg",
      "id_str" : "737451547852836865",
      "id" : 737451547852836865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjv0RozUkAESq9I.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ow66IedW6D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737453474426806272",
  "text" : "RT @gnuman1979: Canadian dog fight. https:\/\/t.co\/ow66IedW6D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gnuman1979\/status\/737451551447359488\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/ow66IedW6D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjv0RozUkAESq9I.jpg",
        "id_str" : "737451547852836865",
        "id" : 737451547852836865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjv0RozUkAESq9I.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ow66IedW6D"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737451551447359488",
    "text" : "Canadian dog fight. https:\/\/t.co\/ow66IedW6D",
    "id" : 737451551447359488,
    "created_at" : "2016-05-31 01:12:05 +0000",
    "user" : {
      "name" : "jamie",
      "screen_name" : "gnuman1979",
      "protected" : false,
      "id_str" : "257715213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780073557132914693\/JpcA0EwC_normal.jpg",
      "id" : 257715213,
      "verified" : false
    }
  },
  "id" : 737453474426806272,
  "created_at" : "2016-05-31 01:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "indices" : [ 3, 14 ],
      "id_str" : "2815401127",
      "id" : 2815401127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/737398199946743809\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/cHXmnnZaKs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjvDwUgUgAAk8ZJ.jpg",
      "id_str" : "737398198910615552",
      "id" : 737398198910615552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjvDwUgUgAAk8ZJ.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1020
      } ],
      "display_url" : "pic.twitter.com\/cHXmnnZaKs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737442210396962816",
  "text" : "RT @gertvanden: Duo grasmaaiers https:\/\/t.co\/cHXmnnZaKs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/737398199946743809\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/cHXmnnZaKs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjvDwUgUgAAk8ZJ.jpg",
        "id_str" : "737398198910615552",
        "id" : 737398198910615552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjvDwUgUgAAk8ZJ.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1020
        } ],
        "display_url" : "pic.twitter.com\/cHXmnnZaKs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737398199946743809",
    "text" : "Duo grasmaaiers https:\/\/t.co\/cHXmnnZaKs",
    "id" : 737398199946743809,
    "created_at" : "2016-05-30 21:40:05 +0000",
    "user" : {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "protected" : false,
      "id_str" : "2815401127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635003322211147776\/tdmuR7zK_normal.jpg",
      "id" : 2815401127,
      "verified" : false
    }
  },
  "id" : 737442210396962816,
  "created_at" : "2016-05-31 00:34:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Periscope",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/UcIZsj3Iw2",
      "expanded_url" : "https:\/\/www.periscope.tv\/w\/ahtsAzFWR1F2R1lXVk9LT2t8MUJSSmpscm5tZWVLd4So8jk2nSoQBfedGyQqaI455K5CKVv1t-aIOaELkMJB",
      "display_url" : "periscope.tv\/w\/ahtsAzFWR1F2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737425408770113536",
  "text" : "RT @fairlyspiritual: LIVE on #Periscope https:\/\/t.co\/UcIZsj3Iw2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/periscope.tv\" rel=\"nofollow\"\u003EPeriscope\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Periscope",
        "indices" : [ 8, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/UcIZsj3Iw2",
        "expanded_url" : "https:\/\/www.periscope.tv\/w\/ahtsAzFWR1F2R1lXVk9LT2t8MUJSSmpscm5tZWVLd4So8jk2nSoQBfedGyQqaI455K5CKVv1t-aIOaELkMJB",
        "display_url" : "periscope.tv\/w\/ahtsAzFWR1F2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737418392114593792",
    "text" : "LIVE on #Periscope https:\/\/t.co\/UcIZsj3Iw2",
    "id" : 737418392114593792,
    "created_at" : "2016-05-30 23:00:19 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 737425408770113536,
  "created_at" : "2016-05-30 23:28:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat Girl Posing",
      "screen_name" : "FatGirlPosing",
      "indices" : [ 3, 17 ],
      "id_str" : "238195090",
      "id" : 238195090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737408676009508864",
  "text" : "RT @FatGirlPosing: It's almost bikini season. Meaning you're going to see a lot of fat shaming from people and a lot of me in a bikini not\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733734672002342913",
    "text" : "It's almost bikini season. Meaning you're going to see a lot of fat shaming from people and a lot of me in a bikini not giving a fuck.",
    "id" : 733734672002342913,
    "created_at" : "2016-05-20 19:02:32 +0000",
    "user" : {
      "name" : "Fat Girl Posing",
      "screen_name" : "FatGirlPosing",
      "protected" : false,
      "id_str" : "238195090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672067815164129280\/xi5FQKqO_normal.jpg",
      "id" : 238195090,
      "verified" : false
    }
  },
  "id" : 737408676009508864,
  "created_at" : "2016-05-30 22:21:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iamfat",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "fatacceptance",
      "indices" : [ 40, 54 ]
    }, {
      "text" : "bodypositive",
      "indices" : [ 55, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/NAMDQnQjYa",
      "expanded_url" : "https:\/\/twitter.com\/AdviceChicken\/status\/737354390541979648",
      "display_url" : "twitter.com\/AdviceChicken\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737394136962203649",
  "text" : "yes and i struggle with this... #iamfat #fatacceptance #bodypositive https:\/\/t.co\/NAMDQnQjYa",
  "id" : 737394136962203649,
  "created_at" : "2016-05-30 21:23:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debz",
      "screen_name" : "Debzjs",
      "indices" : [ 3, 10 ],
      "id_str" : "18578156",
      "id" : 18578156
    }, {
      "name" : "Mean Fat Girl",
      "screen_name" : "Artists_Ali",
      "indices" : [ 12, 24 ],
      "id_str" : "31624328",
      "id" : 31624328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737392778326487040",
  "text" : "RT @Debzjs: @Artists_Ali I still believe in fat bodies being amazing. My choice to lose weight did not change and will not change how I fee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mean Fat Girl",
        "screen_name" : "Artists_Ali",
        "indices" : [ 0, 12 ],
        "id_str" : "31624328",
        "id" : 31624328
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "737334934805831680",
    "geo" : { },
    "id_str" : "737336441043361792",
    "in_reply_to_user_id" : 31624328,
    "text" : "@Artists_Ali I still believe in fat bodies being amazing. My choice to lose weight did not change and will not change how I feel about",
    "id" : 737336441043361792,
    "in_reply_to_status_id" : 737334934805831680,
    "created_at" : "2016-05-30 17:34:41 +0000",
    "in_reply_to_screen_name" : "Artists_Ali",
    "in_reply_to_user_id_str" : "31624328",
    "user" : {
      "name" : "Debz",
      "screen_name" : "Debzjs",
      "protected" : false,
      "id_str" : "18578156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518104943803133952\/KGKGcaL-_normal.jpeg",
      "id" : 18578156,
      "verified" : false
    }
  },
  "id" : 737392778326487040,
  "created_at" : "2016-05-30 21:18:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "feedly",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/dSSjwxAAFW",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/05\/the-sounds-of-fundamentalism-church-knock-teeth-out-maury-davis\/",
      "display_url" : "brucegerencser.net\/2016\/05\/the-so\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737370243224461312",
  "text" : "He Wouldn\u2019t Come to Church so I Knocked His Teeth Out by Maury Davis https:\/\/t.co\/dSSjwxAAFW #religion #feedly",
  "id" : 737370243224461312,
  "created_at" : "2016-05-30 19:49:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Walz",
      "screen_name" : "bigthunder5",
      "indices" : [ 3, 15 ],
      "id_str" : "208665050",
      "id" : 208665050
    }, {
      "name" : "OverDrive Libraries",
      "screen_name" : "OverDriveLibs",
      "indices" : [ 44, 58 ],
      "id_str" : "100572292",
      "id" : 100572292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737364531433902080",
  "text" : "RT @bigthunder5: Now that I've found the ap @OverDriveLibs (Overdrive Libraries), and I can manage audio book checkouts from the library, m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OverDrive Libraries",
        "screen_name" : "OverDriveLibs",
        "indices" : [ 27, 41 ],
        "id_str" : "100572292",
        "id" : 100572292
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737351432878231553",
    "text" : "Now that I've found the ap @OverDriveLibs (Overdrive Libraries), and I can manage audio book checkouts from the library, my mind is blown.",
    "id" : 737351432878231553,
    "created_at" : "2016-05-30 18:34:15 +0000",
    "user" : {
      "name" : "Josh Walz",
      "screen_name" : "bigthunder5",
      "protected" : false,
      "id_str" : "208665050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614237819414777856\/nMNoAPgI_normal.jpg",
      "id" : 208665050,
      "verified" : false
    }
  },
  "id" : 737364531433902080,
  "created_at" : "2016-05-30 19:26:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/737363711682187264\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/j8qPxBW3YE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjukY0TW0AEyAxr.jpg",
      "id_str" : "737363710268854273",
      "id" : 737363710268854273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjukY0TW0AEyAxr.jpg",
      "sizes" : [ {
        "h" : 1847,
        "resize" : "fit",
        "w" : 3319
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/j8qPxBW3YE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737364110355124225",
  "text" : "RT @ChippyCMunk: More of the fish https:\/\/t.co\/j8qPxBW3YE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/737363711682187264\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/j8qPxBW3YE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjukY0TW0AEyAxr.jpg",
        "id_str" : "737363710268854273",
        "id" : 737363710268854273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjukY0TW0AEyAxr.jpg",
        "sizes" : [ {
          "h" : 1847,
          "resize" : "fit",
          "w" : 3319
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/j8qPxBW3YE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737363711682187264",
    "text" : "More of the fish https:\/\/t.co\/j8qPxBW3YE",
    "id" : 737363711682187264,
    "created_at" : "2016-05-30 19:23:03 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 737364110355124225,
  "created_at" : "2016-05-30 19:24:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "indices" : [ 3, 18 ],
      "id_str" : "4906259687",
      "id" : 4906259687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/737346475047411712\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/E50aChbtYd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjuUpJsXIAAiD0H.jpg",
      "id_str" : "737346398702739456",
      "id" : 737346398702739456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjuUpJsXIAAiD0H.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/E50aChbtYd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/737346475047411712\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/E50aChbtYd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjuUrvcW0AAldLk.jpg",
      "id_str" : "737346443195895808",
      "id" : 737346443195895808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjuUrvcW0AAldLk.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/E50aChbtYd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737349763771846657",
  "text" : "RT @Nigelstewart76: Going in and coming out Blue tit https:\/\/t.co\/E50aChbtYd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/737346475047411712\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/E50aChbtYd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjuUpJsXIAAiD0H.jpg",
        "id_str" : "737346398702739456",
        "id" : 737346398702739456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjuUpJsXIAAiD0H.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/E50aChbtYd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Nigelstewart76\/status\/737346475047411712\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/E50aChbtYd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjuUrvcW0AAldLk.jpg",
        "id_str" : "737346443195895808",
        "id" : 737346443195895808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjuUrvcW0AAldLk.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/E50aChbtYd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737346475047411712",
    "text" : "Going in and coming out Blue tit https:\/\/t.co\/E50aChbtYd",
    "id" : 737346475047411712,
    "created_at" : "2016-05-30 18:14:33 +0000",
    "user" : {
      "name" : "Nigel Stewart\/NIGS",
      "screen_name" : "Nigelstewart76",
      "protected" : false,
      "id_str" : "4906259687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800413501911089152\/enhbiZD4_normal.jpg",
      "id" : 4906259687,
      "verified" : false
    }
  },
  "id" : 737349763771846657,
  "created_at" : "2016-05-30 18:27:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/22wXhOS2Rz",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx27CGuBI",
      "display_url" : "tmblr.co\/Zp3-jx27CGuBI"
    } ]
  },
  "geo" : { },
  "id_str" : "737330828175413248",
  "text" : "gem-under-the-mountain: Hey guys, guess what, trees are pornographic now.\u00A0 Pinterest deleted this picture:... https:\/\/t.co\/22wXhOS2Rz",
  "id" : 737330828175413248,
  "created_at" : "2016-05-30 17:12:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/dGSpKfLfgz",
      "expanded_url" : "https:\/\/tmblr.co\/Z1swSx26xrzTi",
      "display_url" : "tmblr.co\/Z1swSx26xrzTi"
    } ]
  },
  "geo" : { },
  "id_str" : "737330563900661760",
  "text" : "Trees can get email in Australia. https:\/\/t.co\/dGSpKfLfgz",
  "id" : 737330563900661760,
  "created_at" : "2016-05-30 17:11:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/QHc2yoZtN3",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx27CGWPa",
      "display_url" : "tmblr.co\/Zp3-jx27CGWPa"
    } ]
  },
  "geo" : { },
  "id_str" : "737330268164489216",
  "text" : "\uD83D\uDCF7 did-you-kno: Trees can get\u00A0email in Australia. In 2013, trees were assigned email addresses by\u00A0the... https:\/\/t.co\/QHc2yoZtN3",
  "id" : 737330268164489216,
  "created_at" : "2016-05-30 17:10:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/xpB0JSQHVG",
      "expanded_url" : "https:\/\/tmblr.co\/Zp3-jx27CFe96",
      "display_url" : "tmblr.co\/Zp3-jx27CFe96"
    } ]
  },
  "geo" : { },
  "id_str" : "737328941258641408",
  "text" : "100-lbs-of-salt: yungmethuselah: Don\u2019t talk shit about people\u2019s teeth. Seriously. Speaking as a major... https:\/\/t.co\/xpB0JSQHVG",
  "id" : 737328941258641408,
  "created_at" : "2016-05-30 17:04:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Dare",
      "screen_name" : "moonandserpent",
      "indices" : [ 3, 18 ],
      "id_str" : "9022742",
      "id" : 9022742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/XNyzqbYh7N",
      "expanded_url" : "https:\/\/twitter.com\/datachick\/status\/737058683524423680",
      "display_url" : "twitter.com\/datachick\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737089590331363328",
  "text" : "RT @moonandserpent: Finally, a Dark Extropian candidate. https:\/\/t.co\/XNyzqbYh7N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/XNyzqbYh7N",
        "expanded_url" : "https:\/\/twitter.com\/datachick\/status\/737058683524423680",
        "display_url" : "twitter.com\/datachick\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737061929630326785",
    "text" : "Finally, a Dark Extropian candidate. https:\/\/t.co\/XNyzqbYh7N",
    "id" : 737061929630326785,
    "created_at" : "2016-05-29 23:23:52 +0000",
    "user" : {
      "name" : "Emily Dare",
      "screen_name" : "moonandserpent",
      "protected" : false,
      "id_str" : "9022742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799354510720143360\/E1zW9xf__normal.jpg",
      "id" : 9022742,
      "verified" : false
    }
  },
  "id" : 737089590331363328,
  "created_at" : "2016-05-30 01:13:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/JYdkb96Bkf",
      "expanded_url" : "https:\/\/www.overdrive.com\/search?q=Life+As+We+Knew+It",
      "display_url" : "overdrive.com\/search?q=Life+\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "737066810789527552",
  "text" : "Finished \"Life As We Knew It\" #audiobook by Susan Beth Pfeffer from my library. https:\/\/t.co\/JYdkb96Bkf.",
  "id" : 737066810789527552,
  "created_at" : "2016-05-29 23:43:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "indices" : [ 3, 18 ],
      "id_str" : "582993732",
      "id" : 582993732
    }, {
      "name" : "Desiring God",
      "screen_name" : "desiringGod",
      "indices" : [ 37, 49 ],
      "id_str" : "15890094",
      "id" : 15890094
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DefendTheSheep\/status\/737003553106055168\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/4IqNn8U0AL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjpc03ZWEAAlf4c.jpg",
      "id_str" : "737003552321703936",
      "id" : 737003552321703936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjpc03ZWEAAlf4c.jpg",
      "sizes" : [ {
        "h" : 120,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 497
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 497
      } ],
      "display_url" : "pic.twitter.com\/4IqNn8U0AL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737016788161036288",
  "text" : "RT @DefendTheSheep: 52 people on the @desiringGod Facebook page liked this comment on why women should not preach: https:\/\/t.co\/4IqNn8U0AL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Desiring God",
        "screen_name" : "desiringGod",
        "indices" : [ 17, 29 ],
        "id_str" : "15890094",
        "id" : 15890094
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DefendTheSheep\/status\/737003553106055168\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/4IqNn8U0AL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjpc03ZWEAAlf4c.jpg",
        "id_str" : "737003552321703936",
        "id" : 737003552321703936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjpc03ZWEAAlf4c.jpg",
        "sizes" : [ {
          "h" : 120,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 497
        } ],
        "display_url" : "pic.twitter.com\/4IqNn8U0AL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737003553106055168",
    "text" : "52 people on the @desiringGod Facebook page liked this comment on why women should not preach: https:\/\/t.co\/4IqNn8U0AL",
    "id" : 737003553106055168,
    "created_at" : "2016-05-29 19:31:54 +0000",
    "user" : {
      "name" : "Julie Anne",
      "screen_name" : "DefendTheSheep",
      "protected" : false,
      "id_str" : "582993732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719282831931781120\/BB0VrKyw_normal.jpg",
      "id" : 582993732,
      "verified" : false
    }
  },
  "id" : 737016788161036288,
  "created_at" : "2016-05-29 20:24:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "indices" : [ 3, 14 ],
      "id_str" : "2815401127",
      "id" : 2815401127
    }, {
      "name" : "The Milk Story",
      "screen_name" : "KoeOpAvontuur",
      "indices" : [ 21, 35 ],
      "id_str" : "391567080",
      "id" : 391567080
    }, {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 36, 48 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    }, {
      "name" : "Charlie Sutcliffe",
      "screen_name" : "ChasSutcliffe",
      "indices" : [ 49, 63 ],
      "id_str" : "51045839",
      "id" : 51045839
    }, {
      "name" : "Victoria hopkinson",
      "screen_name" : "Topfarmerswife",
      "indices" : [ 64, 79 ],
      "id_str" : "374708270",
      "id" : 374708270
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/736969716389056512\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/fg9poN5JuO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjo-DSnWgAAdwrK.jpg",
      "id_str" : "736969715285917696",
      "id" : 736969715285917696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjo-DSnWgAAdwrK.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1020
      } ],
      "display_url" : "pic.twitter.com\/fg9poN5JuO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737016247607525376",
  "text" : "RT @gertvanden: Nose\n@KoeOpAvontuur @newlandfarm @ChasSutcliffe @Topfarmerswife https:\/\/t.co\/fg9poN5JuO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Milk Story",
        "screen_name" : "KoeOpAvontuur",
        "indices" : [ 5, 19 ],
        "id_str" : "391567080",
        "id" : 391567080
      }, {
        "name" : "Newland Farm",
        "screen_name" : "newlandfarm",
        "indices" : [ 20, 32 ],
        "id_str" : "2259182801",
        "id" : 2259182801
      }, {
        "name" : "Charlie Sutcliffe",
        "screen_name" : "ChasSutcliffe",
        "indices" : [ 33, 47 ],
        "id_str" : "51045839",
        "id" : 51045839
      }, {
        "name" : "Victoria hopkinson",
        "screen_name" : "Topfarmerswife",
        "indices" : [ 48, 63 ],
        "id_str" : "374708270",
        "id" : 374708270
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gertvanden\/status\/736969716389056512\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/fg9poN5JuO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjo-DSnWgAAdwrK.jpg",
        "id_str" : "736969715285917696",
        "id" : 736969715285917696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjo-DSnWgAAdwrK.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1020
        } ],
        "display_url" : "pic.twitter.com\/fg9poN5JuO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736969716389056512",
    "text" : "Nose\n@KoeOpAvontuur @newlandfarm @ChasSutcliffe @Topfarmerswife https:\/\/t.co\/fg9poN5JuO",
    "id" : 736969716389056512,
    "created_at" : "2016-05-29 17:17:27 +0000",
    "user" : {
      "name" : "Gert van den Bosch",
      "screen_name" : "gertvanden",
      "protected" : false,
      "id_str" : "2815401127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635003322211147776\/tdmuR7zK_normal.jpg",
      "id" : 2815401127,
      "verified" : false
    }
  },
  "id" : 737016247607525376,
  "created_at" : "2016-05-29 20:22:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736982169957044228",
  "text" : "im very sad i have no twitter archive since jan 27 and i cant figure out why not working.",
  "id" : 736982169957044228,
  "created_at" : "2016-05-29 18:06:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/VpvkLbw5DC",
      "expanded_url" : "https:\/\/twitter.com\/greg_boyd\/status\/736966528843812865",
      "display_url" : "twitter.com\/greg_boyd\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736971355313340416",
  "text" : "reach for the better feeling. keep reaching... https:\/\/t.co\/VpvkLbw5DC",
  "id" : 736971355313340416,
  "created_at" : "2016-05-29 17:23:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736964060902756353",
  "text" : "RT @TheGoldenMirror: What others do is by you interpreted according to your state of mind. Don't point the finger at them. Recognize your o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736958080949334016",
    "text" : "What others do is by you interpreted according to your state of mind. Don't point the finger at them. Recognize your own reflection.",
    "id" : 736958080949334016,
    "created_at" : "2016-05-29 16:31:13 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 736964060902756353,
  "created_at" : "2016-05-29 16:54:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "swanwatchswanselfie",
      "indices" : [ 53, 73 ]
    }, {
      "text" : "swanwatch",
      "indices" : [ 113, 123 ]
    }, {
      "text" : "cygnets",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736923724490903552",
  "text" : "RT @Swanwhisperer: People are starting to send there #swanwatchswanselfie across the uk you can get some photo u #swanwatch #cygnets https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/736839365943537664\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/aosjJRXjTK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjnHZU6WUAAlifx.jpg",
        "id_str" : "736839251975884800",
        "id" : 736839251975884800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjnHZU6WUAAlifx.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aosjJRXjTK"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/736839365943537664\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/aosjJRXjTK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjnHZWRW0AAl8vw.jpg",
        "id_str" : "736839252340822016",
        "id" : 736839252340822016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjnHZWRW0AAl8vw.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/aosjJRXjTK"
      } ],
      "hashtags" : [ {
        "text" : "swanwatchswanselfie",
        "indices" : [ 34, 54 ]
      }, {
        "text" : "swanwatch",
        "indices" : [ 94, 104 ]
      }, {
        "text" : "cygnets",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736839365943537664",
    "text" : "People are starting to send there #swanwatchswanselfie across the uk you can get some photo u #swanwatch #cygnets https:\/\/t.co\/aosjJRXjTK",
    "id" : 736839365943537664,
    "created_at" : "2016-05-29 08:39:29 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 736923724490903552,
  "created_at" : "2016-05-29 14:14:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736923609361469440",
  "text" : "RT @johnpavlovitz: You are the only one who knows your truth. Never let those who know less about you, define you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736731143874174976",
    "text" : "You are the only one who knows your truth. Never let those who know less about you, define you.",
    "id" : 736731143874174976,
    "created_at" : "2016-05-29 01:29:27 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 736923609361469440,
  "created_at" : "2016-05-29 14:14:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736651132672544769",
  "text" : "my twitter archive is brokenJan 27. : ( \"Twitter access has not been authenticated\"",
  "id" : 736651132672544769,
  "created_at" : "2016-05-28 20:11:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/736637997861347328\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/bBaqUje0iO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjkQU_tUkAAuia2.jpg",
      "id_str" : "736637966936739840",
      "id" : 736637966936739840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjkQU_tUkAAuia2.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1534,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bBaqUje0iO"
    } ],
    "hashtags" : [ {
      "text" : "Nebraska",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736642106702352384",
  "text" : "RT @rm123077: Eastern Bluebird at Chadron State Park. #Nebraska https:\/\/t.co\/bBaqUje0iO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/736637997861347328\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/bBaqUje0iO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjkQU_tUkAAuia2.jpg",
        "id_str" : "736637966936739840",
        "id" : 736637966936739840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjkQU_tUkAAuia2.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1534,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bBaqUje0iO"
      } ],
      "hashtags" : [ {
        "text" : "Nebraska",
        "indices" : [ 40, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736637997861347328",
    "text" : "Eastern Bluebird at Chadron State Park. #Nebraska https:\/\/t.co\/bBaqUje0iO",
    "id" : 736637997861347328,
    "created_at" : "2016-05-28 19:19:19 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 736642106702352384,
  "created_at" : "2016-05-28 19:35:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736642005271482369",
  "text" : "RT @fairlyspiritual: I'll invite you to my pity party, but you must break it up.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736637927157948416",
    "text" : "I'll invite you to my pity party, but you must break it up.",
    "id" : 736637927157948416,
    "created_at" : "2016-05-28 19:19:02 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 736642005271482369,
  "created_at" : "2016-05-28 19:35:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/5RwclHWW1w",
      "expanded_url" : "https:\/\/vine.co\/v\/iVz6E7AjIQY",
      "display_url" : "vine.co\/v\/iVz6E7AjIQY"
    } ]
  },
  "geo" : { },
  "id_str" : "736641777667563520",
  "text" : "RT @1CatShepherd: Ovenmitt is trying to be such a dude https:\/\/t.co\/5RwclHWW1w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/5RwclHWW1w",
        "expanded_url" : "https:\/\/vine.co\/v\/iVz6E7AjIQY",
        "display_url" : "vine.co\/v\/iVz6E7AjIQY"
      } ]
    },
    "geo" : { },
    "id_str" : "736641183045300224",
    "text" : "Ovenmitt is trying to be such a dude https:\/\/t.co\/5RwclHWW1w",
    "id" : 736641183045300224,
    "created_at" : "2016-05-28 19:31:58 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 736641777667563520,
  "created_at" : "2016-05-28 19:34:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736633538586529793",
  "text" : "family party went well today. grandma cried when each grandkid presented her with flower.",
  "id" : 736633538586529793,
  "created_at" : "2016-05-28 19:01:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Rawlinson",
      "screen_name" : "lesleysworld",
      "indices" : [ 3, 16 ],
      "id_str" : "745938667",
      "id" : 745938667
    }, {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 18, 32 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lesleysworld\/status\/736620550945116160\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/PQe81Wml8U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjkAbUpXIAEGQnt.jpg",
      "id_str" : "736620483450445825",
      "id" : 736620483450445825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjkAbUpXIAEGQnt.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PQe81Wml8U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736632865195208706",
  "text" : "RT @lesleysworld: @Swanwhisperer I'm pleased to report a happy event on our local pond. Not sure how many yet. https:\/\/t.co\/PQe81Wml8U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlifeloverforever",
        "screen_name" : "Swanwhisperer",
        "indices" : [ 0, 14 ],
        "id_str" : "272369448",
        "id" : 272369448
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lesleysworld\/status\/736620550945116160\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/PQe81Wml8U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjkAbUpXIAEGQnt.jpg",
        "id_str" : "736620483450445825",
        "id" : 736620483450445825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjkAbUpXIAEGQnt.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PQe81Wml8U"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736620550945116160",
    "in_reply_to_user_id" : 272369448,
    "text" : "@Swanwhisperer I'm pleased to report a happy event on our local pond. Not sure how many yet. https:\/\/t.co\/PQe81Wml8U",
    "id" : 736620550945116160,
    "created_at" : "2016-05-28 18:09:59 +0000",
    "in_reply_to_screen_name" : "Swanwhisperer",
    "in_reply_to_user_id_str" : "272369448",
    "user" : {
      "name" : "Lesley Rawlinson",
      "screen_name" : "lesleysworld",
      "protected" : false,
      "id_str" : "745938667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/612266113838260224\/6S7Zli7N_normal.jpg",
      "id" : 745938667,
      "verified" : false
    }
  },
  "id" : 736632865195208706,
  "created_at" : "2016-05-28 18:58:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "indices" : [ 3, 19 ],
      "id_str" : "364856414",
      "id" : 364856414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Caturday",
      "indices" : [ 87, 96 ]
    }, {
      "text" : "CatsOClock",
      "indices" : [ 98, 109 ]
    }, {
      "text" : "CatsOfTwitter",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736632713613041664",
  "text" : "RT @ThomMoorePhotos: My new DIY and painting apprentice just turned up for work. Happy #Caturday! #CatsOClock #CatsOfTwitter https:\/\/t.co\/9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/736572731962097665\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/9Yy9iL3937",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjjU_tsUkAAdgef.jpg",
        "id_str" : "736572730137415680",
        "id" : 736572730137415680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjjU_tsUkAAdgef.jpg",
        "sizes" : [ {
          "h" : 2914,
          "resize" : "fit",
          "w" : 3960
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 754,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9Yy9iL3937"
      } ],
      "hashtags" : [ {
        "text" : "Caturday",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "CatsOClock",
        "indices" : [ 77, 88 ]
      }, {
        "text" : "CatsOfTwitter",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736572731962097665",
    "text" : "My new DIY and painting apprentice just turned up for work. Happy #Caturday! #CatsOClock #CatsOfTwitter https:\/\/t.co\/9Yy9iL3937",
    "id" : 736572731962097665,
    "created_at" : "2016-05-28 14:59:58 +0000",
    "user" : {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "protected" : false,
      "id_str" : "364856414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770204744543563776\/cS24tsF9_normal.jpg",
      "id" : 364856414,
      "verified" : false
    }
  },
  "id" : 736632713613041664,
  "created_at" : "2016-05-28 18:58:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736564972227006464",
  "text" : "RT @BrianRathbone: Life is a hallucination.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736564271564328960",
    "text" : "Life is a hallucination.",
    "id" : 736564271564328960,
    "created_at" : "2016-05-28 14:26:21 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 736564972227006464,
  "created_at" : "2016-05-28 14:29:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/736528304279330816\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/0qUaujt5pA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjisk2FWUAAiUer.jpg",
      "id_str" : "736528288068292608",
      "id" : 736528288068292608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjisk2FWUAAiUer.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0qUaujt5pA"
    } ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736548487697960960",
  "text" : "RT @CatskillCritter: Sun breaking through mist over Lazy Hawk Ridge this morning. #Catskills https:\/\/t.co\/0qUaujt5pA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/736528304279330816\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/0qUaujt5pA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjisk2FWUAAiUer.jpg",
        "id_str" : "736528288068292608",
        "id" : 736528288068292608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjisk2FWUAAiUer.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0qUaujt5pA"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 61, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736528304279330816",
    "text" : "Sun breaking through mist over Lazy Hawk Ridge this morning. #Catskills https:\/\/t.co\/0qUaujt5pA",
    "id" : 736528304279330816,
    "created_at" : "2016-05-28 12:03:26 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 736548487697960960,
  "created_at" : "2016-05-28 13:23:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Chan",
      "screen_name" : "xyztal",
      "indices" : [ 3, 10 ],
      "id_str" : "2200411375",
      "id" : 2200411375
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/xyztal\/status\/735656464128217088\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/XGXARfXqpn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjWToALUgAAbEdA.jpg",
      "id_str" : "735656429596475392",
      "id" : 735656429596475392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjWToALUgAAbEdA.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XGXARfXqpn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/xyztal\/status\/735656464128217088\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/XGXARfXqpn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjWToAEUgAATTha.jpg",
      "id_str" : "735656429567115264",
      "id" : 735656429567115264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjWToAEUgAATTha.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XGXARfXqpn"
    } ],
    "hashtags" : [ {
      "text" : "sheep365",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "sheepfarmer",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736368700081733633",
  "text" : "RT @xyztal: Poor guy got sunburnt on his neck so we upgraded his gear #sheep365 #sheepfarmer https:\/\/t.co\/XGXARfXqpn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/xyztal\/status\/735656464128217088\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/XGXARfXqpn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjWToALUgAAbEdA.jpg",
        "id_str" : "735656429596475392",
        "id" : 735656429596475392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjWToALUgAAbEdA.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XGXARfXqpn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/xyztal\/status\/735656464128217088\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/XGXARfXqpn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjWToAEUgAATTha.jpg",
        "id_str" : "735656429567115264",
        "id" : 735656429567115264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjWToAEUgAATTha.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XGXARfXqpn"
      } ],
      "hashtags" : [ {
        "text" : "sheep365",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "sheepfarmer",
        "indices" : [ 68, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735656464128217088",
    "text" : "Poor guy got sunburnt on his neck so we upgraded his gear #sheep365 #sheepfarmer https:\/\/t.co\/XGXARfXqpn",
    "id" : 735656464128217088,
    "created_at" : "2016-05-26 02:19:03 +0000",
    "user" : {
      "name" : "Crystal Chan",
      "screen_name" : "xyztal",
      "protected" : false,
      "id_str" : "2200411375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654095772061798400\/W6VJP3aj_normal.jpg",
      "id" : 2200411375,
      "verified" : false
    }
  },
  "id" : 736368700081733633,
  "created_at" : "2016-05-28 01:29:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736348335909572611",
  "geo" : { },
  "id_str" : "736351176044761088",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 family visiting, family party tomorrow has got DD's anxiety high alert.",
  "id" : 736351176044761088,
  "in_reply_to_status_id" : 736348335909572611,
  "created_at" : "2016-05-28 00:19:35 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Collins",
      "screen_name" : "stan_sdcollins",
      "indices" : [ 0, 15 ],
      "id_str" : "858549320",
      "id" : 858549320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736336017871900672",
  "geo" : { },
  "id_str" : "736344622029537280",
  "in_reply_to_user_id" : 858549320,
  "text" : "@stan_sdcollins Northern Pintail Duck (I googled..lol)",
  "id" : 736344622029537280,
  "in_reply_to_status_id" : 736336017871900672,
  "created_at" : "2016-05-27 23:53:33 +0000",
  "in_reply_to_screen_name" : "stan_sdcollins",
  "in_reply_to_user_id_str" : "858549320",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anxiety",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736325815638593536",
  "text" : "made the mistake of leaving DD alone today. DH had to drive me back home. my poor cupcake... #anxiety #hashimotos",
  "id" : 736325815638593536,
  "created_at" : "2016-05-27 22:38:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hachette Audio",
      "screen_name" : "HachetteAudio",
      "indices" : [ 61, 75 ],
      "id_str" : "300912850",
      "id" : 300912850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveAudiobooks",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/v1vGf3c4QV",
      "expanded_url" : "https:\/\/www.rafflecopter.com\/rafl\/display\/9230c9594\/",
      "display_url" : "rafflecopter.com\/rafl\/display\/9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736241749018939393",
  "text" : "I entered to win the thriller audiobook giveaway bundle from @hachetteaudio #LoveAudiobooks https:\/\/t.co\/v1vGf3c4QV",
  "id" : 736241749018939393,
  "created_at" : "2016-05-27 17:04:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/736233121746669568\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/kiw7ODzsJR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjegH5OW0AAgjm7.jpg",
      "id_str" : "736233121578930176",
      "id" : 736233121578930176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjegH5OW0AAgjm7.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 202
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 202
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 202
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 202
      } ],
      "display_url" : "pic.twitter.com\/kiw7ODzsJR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/gH709LmuPf",
      "expanded_url" : "http:\/\/bit.ly\/1U3WJLi",
      "display_url" : "bit.ly\/1U3WJLi"
    } ]
  },
  "geo" : { },
  "id_str" : "736238429328027649",
  "text" : "RT @jonlieffmd: Infants know much more than they are able to say or gesture. https:\/\/t.co\/gH709LmuPf https:\/\/t.co\/kiw7ODzsJR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/736233121746669568\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/kiw7ODzsJR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjegH5OW0AAgjm7.jpg",
        "id_str" : "736233121578930176",
        "id" : 736233121578930176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjegH5OW0AAgjm7.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 202
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 202
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 202
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 202
        } ],
        "display_url" : "pic.twitter.com\/kiw7ODzsJR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/gH709LmuPf",
        "expanded_url" : "http:\/\/bit.ly\/1U3WJLi",
        "display_url" : "bit.ly\/1U3WJLi"
      } ]
    },
    "geo" : { },
    "id_str" : "736233121746669568",
    "text" : "Infants know much more than they are able to say or gesture. https:\/\/t.co\/gH709LmuPf https:\/\/t.co\/kiw7ODzsJR",
    "id" : 736233121746669568,
    "created_at" : "2016-05-27 16:30:29 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 736238429328027649,
  "created_at" : "2016-05-27 16:51:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736238279377489920",
  "text" : "RT @existentialcoms: Student: \"but what's the point of learning math?\"\nTeacher: \"There is none. Life in general is pointless and after deat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736225774483562496",
    "text" : "Student: \"but what's the point of learning math?\"\nTeacher: \"There is none. Life in general is pointless and after death there is only void.\"",
    "id" : 736225774483562496,
    "created_at" : "2016-05-27 16:01:17 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 736238279377489920,
  "created_at" : "2016-05-27 16:50:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "indices" : [ 0, 9 ],
      "id_str" : "12642282",
      "id" : 12642282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "736209679261409280",
  "geo" : { },
  "id_str" : "736238146329935872",
  "in_reply_to_user_id" : 12642282,
  "text" : "@dasparky sweet fuzzy puppy fur! ((smooches))",
  "id" : 736238146329935872,
  "in_reply_to_status_id" : 736209679261409280,
  "created_at" : "2016-05-27 16:50:27 +0000",
  "in_reply_to_screen_name" : "dasparky",
  "in_reply_to_user_id_str" : "12642282",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735969941732655104",
  "text" : "RT @SangyeH: Hey fellow Dems,\n\nCriticizing Trump for making fun of people's appearances while making fun of *his* appearance is really hypo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735968597705560065",
    "text" : "Hey fellow Dems,\n\nCriticizing Trump for making fun of people's appearances while making fun of *his* appearance is really hypocritical.",
    "id" : 735968597705560065,
    "created_at" : "2016-05-26 22:59:21 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 735969941732655104,
  "created_at" : "2016-05-26 23:04:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raw Story",
      "screen_name" : "RawStory",
      "indices" : [ 3, 12 ],
      "id_str" : "16041234",
      "id" : 16041234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/DN22i3SXUr",
      "expanded_url" : "http:\/\/ow.ly\/bQog300AmQp",
      "display_url" : "ow.ly\/bQog300AmQp"
    } ]
  },
  "geo" : { },
  "id_str" : "735582149944979456",
  "text" : "RT @RawStory: Texas 8th grader sent home for wearing pro-LGBT t-shirt telling haters to \u2018Get Over It\u2019 https:\/\/t.co\/DN22i3SXUr https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RawStory\/status\/735559014239592448\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/a82FyRW3Fs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjU7BpDWUAErWpw.jpg",
        "id_str" : "735559013530750977",
        "id" : 735559013530750977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjU7BpDWUAErWpw.jpg",
        "sizes" : [ {
          "h" : 183,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 430,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/a82FyRW3Fs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/DN22i3SXUr",
        "expanded_url" : "http:\/\/ow.ly\/bQog300AmQp",
        "display_url" : "ow.ly\/bQog300AmQp"
      } ]
    },
    "geo" : { },
    "id_str" : "735559014239592448",
    "text" : "Texas 8th grader sent home for wearing pro-LGBT t-shirt telling haters to \u2018Get Over It\u2019 https:\/\/t.co\/DN22i3SXUr https:\/\/t.co\/a82FyRW3Fs",
    "id" : 735559014239592448,
    "created_at" : "2016-05-25 19:51:49 +0000",
    "user" : {
      "name" : "Raw Story",
      "screen_name" : "RawStory",
      "protected" : false,
      "id_str" : "16041234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511012709270183936\/wEVYV7Lf_normal.png",
      "id" : 16041234,
      "verified" : true
    }
  },
  "id" : 735582149944979456,
  "created_at" : "2016-05-25 21:23:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Optimism Toad, KSC",
      "screen_name" : "sainttoad",
      "indices" : [ 3, 13 ],
      "id_str" : "85117657",
      "id" : 85117657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735564491765735424",
  "text" : "RT @sainttoad: gay lifestyle I've seen is exactly like my hetero one. Get job, pay bills, fall in love, eat dinner. Sex is private  https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xcZpg1k25w",
        "expanded_url" : "https:\/\/twitter.com\/adressrehearsal\/status\/735539057745383425",
        "display_url" : "twitter.com\/adressrehearsa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735539697456316416",
    "text" : "gay lifestyle I've seen is exactly like my hetero one. Get job, pay bills, fall in love, eat dinner. Sex is private  https:\/\/t.co\/xcZpg1k25w",
    "id" : 735539697456316416,
    "created_at" : "2016-05-25 18:35:04 +0000",
    "user" : {
      "name" : "Optimism Toad, KSC",
      "screen_name" : "sainttoad",
      "protected" : false,
      "id_str" : "85117657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782253579545382914\/rdWFzmz-_normal.jpg",
      "id" : 85117657,
      "verified" : false
    }
  },
  "id" : 735564491765735424,
  "created_at" : "2016-05-25 20:13:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R.C. Bray",
      "screen_name" : "audbks",
      "indices" : [ 3, 10 ],
      "id_str" : "2293107631",
      "id" : 2293107631
    }, {
      "name" : "Nicholas S. Smith",
      "screen_name" : "greatwaveink",
      "indices" : [ 50, 63 ],
      "id_str" : "735512832",
      "id" : 735512832
    }, {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "indices" : [ 110, 126 ],
      "id_str" : "111095506",
      "id" : 111095506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/oUJ8NmPoTe",
      "expanded_url" : "http:\/\/nicholassansbury.com\/helldivers.php",
      "display_url" : "nicholassansbury.com\/helldivers.php"
    } ]
  },
  "geo" : { },
  "id_str" : "735516408671522817",
  "text" : "RT @audbks: Halfway done narrating HELL DIVERS by @greatwaveink.  It's perfect.  7\/19\nhttps:\/\/t.co\/oUJ8NmPoTe @BlackstoneAudio https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas S. Smith",
        "screen_name" : "greatwaveink",
        "indices" : [ 38, 51 ],
        "id_str" : "735512832",
        "id" : 735512832
      }, {
        "name" : "Blackstone",
        "screen_name" : "BlackstoneAudio",
        "indices" : [ 98, 114 ],
        "id_str" : "111095506",
        "id" : 111095506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/audbks\/status\/735513059301699585\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/QhrWCTdID8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjUROsgVEAAa8Pp.jpg",
        "id_str" : "735513058307543040",
        "id" : 735513058307543040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjUROsgVEAAa8Pp.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1606,
          "resize" : "fit",
          "w" : 1606
        } ],
        "display_url" : "pic.twitter.com\/QhrWCTdID8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/oUJ8NmPoTe",
        "expanded_url" : "http:\/\/nicholassansbury.com\/helldivers.php",
        "display_url" : "nicholassansbury.com\/helldivers.php"
      } ]
    },
    "geo" : { },
    "id_str" : "735513059301699585",
    "text" : "Halfway done narrating HELL DIVERS by @greatwaveink.  It's perfect.  7\/19\nhttps:\/\/t.co\/oUJ8NmPoTe @BlackstoneAudio https:\/\/t.co\/QhrWCTdID8",
    "id" : 735513059301699585,
    "created_at" : "2016-05-25 16:49:13 +0000",
    "user" : {
      "name" : "R.C. Bray",
      "screen_name" : "audbks",
      "protected" : false,
      "id_str" : "2293107631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789471882844205056\/jypAzaNl_normal.jpg",
      "id" : 2293107631,
      "verified" : false
    }
  },
  "id" : 735516408671522817,
  "created_at" : "2016-05-25 17:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake Ross",
      "screen_name" : "blakeross",
      "indices" : [ 3, 13 ],
      "id_str" : "15228003",
      "id" : 15228003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735497964970516480",
  "text" : "RT @blakeross: I'm 30 and I just realized that people can actually \"picture\" things in their mind. I can't. It's called Aphantasia: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/5OfyZWtbvv",
        "expanded_url" : "https:\/\/www.facebook.com\/notes\/blake-ross\/aphantasia-how-it-feels-to-be-blind-in-your-mind\/10156834777480504",
        "display_url" : "facebook.com\/notes\/blake-ro\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "724321050985517056",
    "text" : "I'm 30 and I just realized that people can actually \"picture\" things in their mind. I can't. It's called Aphantasia: https:\/\/t.co\/5OfyZWtbvv",
    "id" : 724321050985517056,
    "created_at" : "2016-04-24 19:36:10 +0000",
    "user" : {
      "name" : "Blake Ross",
      "screen_name" : "blakeross",
      "protected" : false,
      "id_str" : "15228003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658700721596948480\/9rjK0vCF_normal.jpg",
      "id" : 15228003,
      "verified" : true
    }
  },
  "id" : 735497964970516480,
  "created_at" : "2016-05-25 15:49:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flurries Unlimited",
      "screen_name" : "flurriesofwords",
      "indices" : [ 3, 19 ],
      "id_str" : "465041073",
      "id" : 465041073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1YOMq76fWk",
      "expanded_url" : "http:\/\/sco.lt\/800nbd",
      "display_url" : "sco.lt\/800nbd"
    } ]
  },
  "geo" : { },
  "id_str" : "735494482053976064",
  "text" : "RT @flurriesofwords: Imagine a dog. Got it? I don\u2019t. Here\u2019s what it\u2019s like to be unable to visualize anything. https:\/\/t.co\/1YOMq76fWk http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.scoop.it\" rel=\"nofollow\"\u003EScoop.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/flurriesofwords\/status\/735487701189681153\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/9XqNUePSmi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjT6KkBVEAEtTZM.jpg",
        "id_str" : "735487698543120385",
        "id" : 735487698543120385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjT6KkBVEAEtTZM.jpg",
        "sizes" : [ {
          "h" : 632,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/9XqNUePSmi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/1YOMq76fWk",
        "expanded_url" : "http:\/\/sco.lt\/800nbd",
        "display_url" : "sco.lt\/800nbd"
      } ]
    },
    "geo" : { },
    "id_str" : "735487701189681153",
    "text" : "Imagine a dog. Got it? I don\u2019t. Here\u2019s what it\u2019s like to be unable to visualize anything. https:\/\/t.co\/1YOMq76fWk https:\/\/t.co\/9XqNUePSmi",
    "id" : 735487701189681153,
    "created_at" : "2016-05-25 15:08:27 +0000",
    "user" : {
      "name" : "Flurries Unlimited",
      "screen_name" : "flurriesofwords",
      "protected" : false,
      "id_str" : "465041073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681661227311837184\/8MLHVL09_normal.jpg",
      "id" : 465041073,
      "verified" : false
    }
  },
  "id" : 735494482053976064,
  "created_at" : "2016-05-25 15:35:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "indices" : [ 3, 14 ],
      "id_str" : "511243584",
      "id" : 511243584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/NVNOII5gFC",
      "expanded_url" : "http:\/\/wpo.st\/9izb1",
      "display_url" : "wpo.st\/9izb1"
    } ]
  },
  "geo" : { },
  "id_str" : "735492492683059200",
  "text" : "RT @becwaddell: Sparking fears of a zombie apocalypse: Controversial study aims to 'reanimate' the brain dead https:\/\/t.co\/NVNOII5gFC #Jahi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JahiMcMath",
        "indices" : [ 118, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/NVNOII5gFC",
        "expanded_url" : "http:\/\/wpo.st\/9izb1",
        "display_url" : "wpo.st\/9izb1"
      } ]
    },
    "geo" : { },
    "id_str" : "735486943052468224",
    "text" : "Sparking fears of a zombie apocalypse: Controversial study aims to 'reanimate' the brain dead https:\/\/t.co\/NVNOII5gFC #JahiMcMath",
    "id" : 735486943052468224,
    "created_at" : "2016-05-25 15:05:26 +0000",
    "user" : {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "protected" : false,
      "id_str" : "511243584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604077917094596608\/YsEVFvZs_normal.jpg",
      "id" : 511243584,
      "verified" : false
    }
  },
  "id" : 735492492683059200,
  "created_at" : "2016-05-25 15:27:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "indices" : [ 3, 16 ],
      "id_str" : "217626610",
      "id" : 217626610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735492002838646784",
  "text" : "RT @jameslsutter: People who tweet about books you like: Thank you. You not only encourage the authors, you help the books succeed. Word of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735490147832070145",
    "text" : "People who tweet about books you like: Thank you. You not only encourage the authors, you help the books succeed. Word of mouth is key.",
    "id" : 735490147832070145,
    "created_at" : "2016-05-25 15:18:10 +0000",
    "user" : {
      "name" : "James L. Sutter",
      "screen_name" : "jameslsutter",
      "protected" : false,
      "id_str" : "217626610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739849533346054144\/6CIwOnsG_normal.jpg",
      "id" : 217626610,
      "verified" : false
    }
  },
  "id" : 735492002838646784,
  "created_at" : "2016-05-25 15:25:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735480278026715136",
  "text" : "finished \"Admission\" by Jean Hanff Korelitz. really enjoyed it.",
  "id" : 735480278026715136,
  "created_at" : "2016-05-25 14:38:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elnigma",
      "screen_name" : "galaxiou",
      "indices" : [ 3, 12 ],
      "id_str" : "455972590",
      "id" : 455972590
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/galaxiou\/status\/735279526649966593\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Zgu682Fe5U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQ81UYWkAAIbZ5.jpg",
      "id_str" : "735279525869817856",
      "id" : 735279525869817856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQ81UYWkAAIbZ5.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 822
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 822
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Zgu682Fe5U"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/galaxiou\/status\/735279526649966593\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Zgu682Fe5U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQ81VFXEAQs9r0.jpg",
      "id_str" : "735279526058594308",
      "id" : 735279526058594308,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQ81VFXEAQs9r0.jpg",
      "sizes" : [ {
        "h" : 502,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 837,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 837,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Zgu682Fe5U"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/galaxiou\/status\/735279526649966593\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Zgu682Fe5U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQ81UyWUAQQPt4.jpg",
      "id_str" : "735279525978853380",
      "id" : 735279525978853380,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQ81UyWUAQQPt4.jpg",
      "sizes" : [ {
        "h" : 756,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 756,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Zgu682Fe5U"
    } ],
    "hashtags" : [ {
      "text" : "Bellydance",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "bunny",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735281079570071552",
  "text" : "RT @galaxiou: really good #Bellydance class. Saw a #bunny's butt outside earlier https:\/\/t.co\/Zgu682Fe5U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/galaxiou\/status\/735279526649966593\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Zgu682Fe5U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQ81UYWkAAIbZ5.jpg",
        "id_str" : "735279525869817856",
        "id" : 735279525869817856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQ81UYWkAAIbZ5.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 822
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 822
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Zgu682Fe5U"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/galaxiou\/status\/735279526649966593\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Zgu682Fe5U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQ81VFXEAQs9r0.jpg",
        "id_str" : "735279526058594308",
        "id" : 735279526058594308,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQ81VFXEAQs9r0.jpg",
        "sizes" : [ {
          "h" : 502,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 837,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 837,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Zgu682Fe5U"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/galaxiou\/status\/735279526649966593\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Zgu682Fe5U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjQ81UyWUAQQPt4.jpg",
        "id_str" : "735279525978853380",
        "id" : 735279525978853380,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjQ81UyWUAQQPt4.jpg",
        "sizes" : [ {
          "h" : 756,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 756,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Zgu682Fe5U"
      } ],
      "hashtags" : [ {
        "text" : "Bellydance",
        "indices" : [ 12, 23 ]
      }, {
        "text" : "bunny",
        "indices" : [ 37, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735279526649966593",
    "text" : "really good #Bellydance class. Saw a #bunny's butt outside earlier https:\/\/t.co\/Zgu682Fe5U",
    "id" : 735279526649966593,
    "created_at" : "2016-05-25 01:21:14 +0000",
    "user" : {
      "name" : "Elnigma",
      "screen_name" : "galaxiou",
      "protected" : false,
      "id_str" : "455972590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1736502695\/categg_edited-1_normal.jpg",
      "id" : 455972590,
      "verified" : false
    }
  },
  "id" : 735281079570071552,
  "created_at" : "2016-05-25 01:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e vagae campestribus",
      "screen_name" : "_bwomp",
      "indices" : [ 3, 10 ],
      "id_str" : "14323654",
      "id" : 14323654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735241758087483394",
  "text" : "RT @_bwomp: Choices come from outside of you; they can only be taken when they're offered. Decisions come from inside; they are made on you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "735213796260618240",
    "geo" : { },
    "id_str" : "735234513622597633",
    "in_reply_to_user_id" : 14323654,
    "text" : "Choices come from outside of you; they can only be taken when they're offered. Decisions come from inside; they are made on your terms.",
    "id" : 735234513622597633,
    "in_reply_to_status_id" : 735213796260618240,
    "created_at" : "2016-05-24 22:22:22 +0000",
    "in_reply_to_screen_name" : "_bwomp",
    "in_reply_to_user_id_str" : "14323654",
    "user" : {
      "name" : "e vagae campestribus",
      "screen_name" : "_bwomp",
      "protected" : false,
      "id_str" : "14323654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790061747608522752\/mFxzBgD0_normal.jpg",
      "id" : 14323654,
      "verified" : false
    }
  },
  "id" : 735241758087483394,
  "created_at" : "2016-05-24 22:51:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e vagae campestribus",
      "screen_name" : "_bwomp",
      "indices" : [ 3, 10 ],
      "id_str" : "14323654",
      "id" : 14323654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735241735593459712",
  "text" : "RT @_bwomp: Here's really the ultimate lie of Individualist Capitalism, exposed for us: You don't \"make decisions\". You are \"given choices\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "735211960304730113",
    "geo" : { },
    "id_str" : "735213796260618240",
    "in_reply_to_user_id" : 14323654,
    "text" : "Here's really the ultimate lie of Individualist Capitalism, exposed for us: You don't \"make decisions\". You are \"given choices\".",
    "id" : 735213796260618240,
    "in_reply_to_status_id" : 735211960304730113,
    "created_at" : "2016-05-24 21:00:03 +0000",
    "in_reply_to_screen_name" : "_bwomp",
    "in_reply_to_user_id_str" : "14323654",
    "user" : {
      "name" : "e vagae campestribus",
      "screen_name" : "_bwomp",
      "protected" : false,
      "id_str" : "14323654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790061747608522752\/mFxzBgD0_normal.jpg",
      "id" : 14323654,
      "verified" : false
    }
  },
  "id" : 735241735593459712,
  "created_at" : "2016-05-24 22:51:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735211360859082752",
  "text" : "I miss seeing \"Today's Audiobook News &amp; Reviews\" by @Listen2Books .. wonder if it will start up again? #audiobooks",
  "id" : 735211360859082752,
  "created_at" : "2016-05-24 20:50:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734857620830355461",
  "text" : "im thinking conservatives have point regarding liberals re: tolerance, pol correctness. becoming like religion \"think this way or be damned\"",
  "id" : 734857620830355461,
  "created_at" : "2016-05-23 21:24:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 11, 18 ],
      "id_str" : "20793816",
      "id" : 20793816
    }, {
      "name" : "Mark Kelso",
      "screen_name" : "audible",
      "indices" : [ 48, 56 ],
      "id_str" : "1579651",
      "id" : 1579651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firephone",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734781573472657408",
  "text" : "#firephone @amazon should redo it as #audiobook @audible reader. perfect size, android apps, kindle apps, whispersync.",
  "id" : 734781573472657408,
  "created_at" : "2016-05-23 16:22:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Chan",
      "screen_name" : "xyztal",
      "indices" : [ 3, 10 ],
      "id_str" : "2200411375",
      "id" : 2200411375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lamb",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "sheep365",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734751451398955010",
  "text" : "RT @xyztal: Anyone seen this before in a young #lamb?He seems healthy &amp; not itchy other than losing his wool.... #sheep365 https:\/\/t.co\/wZ6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/xyztal\/status\/734491702170378240\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/wZ6EHzIQ9j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjFwS1ZVEAACJY9.jpg",
        "id_str" : "734491683111374848",
        "id" : 734491683111374848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjFwS1ZVEAACJY9.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wZ6EHzIQ9j"
      } ],
      "hashtags" : [ {
        "text" : "lamb",
        "indices" : [ 35, 40 ]
      }, {
        "text" : "sheep365",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734491702170378240",
    "text" : "Anyone seen this before in a young #lamb?He seems healthy &amp; not itchy other than losing his wool.... #sheep365 https:\/\/t.co\/wZ6EHzIQ9j",
    "id" : 734491702170378240,
    "created_at" : "2016-05-22 21:10:42 +0000",
    "user" : {
      "name" : "Crystal Chan",
      "screen_name" : "xyztal",
      "protected" : false,
      "id_str" : "2200411375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654095772061798400\/W6VJP3aj_normal.jpg",
      "id" : 2200411375,
      "verified" : false
    }
  },
  "id" : 734751451398955010,
  "created_at" : "2016-05-23 14:22:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 0, 7 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734557749909065729",
  "geo" : { },
  "id_str" : "734750481344520193",
  "in_reply_to_user_id" : 6872302,
  "text" : "@Mahala ((hugs)) id be in the hospital by now! my biggest fear in life is running out. #effexor",
  "id" : 734750481344520193,
  "in_reply_to_status_id" : 734557749909065729,
  "created_at" : "2016-05-23 14:19:00 +0000",
  "in_reply_to_screen_name" : "Mahala",
  "in_reply_to_user_id_str" : "6872302",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734747529678606341",
  "text" : "RT @TheGoldenMirror: Don't help others without their permission. Sometimes we want to fix thing about them that they don't consider to be b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734624944714305537",
    "text" : "Don't help others without their permission. Sometimes we want to fix thing about them that they don't consider to be broken.",
    "id" : 734624944714305537,
    "created_at" : "2016-05-23 06:00:10 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 734747529678606341,
  "created_at" : "2016-05-23 14:07:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734467240297304066",
  "geo" : { },
  "id_str" : "734550037817110530",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind what if there was a reason not to remember?",
  "id" : 734550037817110530,
  "in_reply_to_status_id" : 734467240297304066,
  "created_at" : "2016-05-23 01:02:30 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "indices" : [ 3, 19 ],
      "id_str" : "364856414",
      "id" : 364856414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734547728617906179",
  "text" : "RT @ThomMoorePhotos: It's me who's been up a ladder all day painting walls, but it's the cat who is now fast asleep on the drop cloth. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/734526360648097792\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/eEwWJlVOll",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjGP1MkXIAAo0ZB.jpg",
        "id_str" : "734526358307676160",
        "id" : 734526358307676160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjGP1MkXIAAo0ZB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3916,
          "resize" : "fit",
          "w" : 5865
        } ],
        "display_url" : "pic.twitter.com\/eEwWJlVOll"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734526360648097792",
    "text" : "It's me who's been up a ladder all day painting walls, but it's the cat who is now fast asleep on the drop cloth. https:\/\/t.co\/eEwWJlVOll",
    "id" : 734526360648097792,
    "created_at" : "2016-05-22 23:28:25 +0000",
    "user" : {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "protected" : false,
      "id_str" : "364856414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770204744543563776\/cS24tsF9_normal.jpg",
      "id" : 364856414,
      "verified" : false
    }
  },
  "id" : 734547728617906179,
  "created_at" : "2016-05-23 00:53:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "feedly",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/6EAcMLciJz",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/05\/why-i-never-used-the-word-religious-when-i-was-a-christian\/",
      "display_url" : "brucegerencser.net\/2016\/05\/why-i-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734490596128264194",
  "text" : "Why I Never Used the Word \u201CReligious\u201D\u00A0When I Was a Christian https:\/\/t.co\/6EAcMLciJz #religion #feedly",
  "id" : 734490596128264194,
  "created_at" : "2016-05-22 21:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/P09C4m5Cdn",
      "expanded_url" : "https:\/\/twitter.com\/aliceinthewater\/status\/734338840605908992",
      "display_url" : "twitter.com\/aliceinthewate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734430882870755328",
  "text" : "gonna get a bikini for beach vacation in august becuz less wet suit on body.. im 200+ lbs. https:\/\/t.co\/P09C4m5Cdn",
  "id" : 734430882870755328,
  "created_at" : "2016-05-22 17:09:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neurotic",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "mentalillness",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734429275236012033",
  "text" : "making decisions creates great anxiety within me. #neurotic #mentalillness",
  "id" : 734429275236012033,
  "created_at" : "2016-05-22 17:02:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neurotic",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "ocd",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "mentalillness",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/vaD69ek4AD",
      "expanded_url" : "https:\/\/twitter.com\/iSmashFizzle\/status\/734168318127509504",
      "display_url" : "twitter.com\/iSmashFizzle\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734428675802845184",
  "text" : "as a teen, felt my life was imperfect, ugly so shouldnt exist at all. #neurotic #ocd #mentalillness  https:\/\/t.co\/vaD69ek4AD",
  "id" : 734428675802845184,
  "created_at" : "2016-05-22 17:00:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/734403871523635200\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/BkDSPJd7dD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjEgZaHWkAA_tg5.jpg",
      "id_str" : "734403835117080576",
      "id" : 734403835117080576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjEgZaHWkAA_tg5.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BkDSPJd7dD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734421592558710786",
  "text" : "RT @Salmonae1: Young Starlings waiting for me to change the coconut feeder.On the other Feeder stand. https:\/\/t.co\/BkDSPJd7dD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/734403871523635200\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/BkDSPJd7dD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjEgZaHWkAA_tg5.jpg",
        "id_str" : "734403835117080576",
        "id" : 734403835117080576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjEgZaHWkAA_tg5.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BkDSPJd7dD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734403871523635200",
    "text" : "Young Starlings waiting for me to change the coconut feeder.On the other Feeder stand. https:\/\/t.co\/BkDSPJd7dD",
    "id" : 734403871523635200,
    "created_at" : "2016-05-22 15:21:42 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 734421592558710786,
  "created_at" : "2016-05-22 16:32:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/734403894944620545\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/x7q1OLKic8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjEgZaTXIAElwcn.jpg",
      "id_str" : "734403835167449089",
      "id" : 734403835167449089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjEgZaTXIAElwcn.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x7q1OLKic8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734421518558605313",
  "text" : "RT @Salmonae1: This mornings 'welcome to Cliffs Starling Party'. https:\/\/t.co\/x7q1OLKic8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/734403894944620545\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/x7q1OLKic8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjEgZaTXIAElwcn.jpg",
        "id_str" : "734403835167449089",
        "id" : 734403835167449089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjEgZaTXIAElwcn.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/x7q1OLKic8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734403894944620545",
    "text" : "This mornings 'welcome to Cliffs Starling Party'. https:\/\/t.co\/x7q1OLKic8",
    "id" : 734403894944620545,
    "created_at" : "2016-05-22 15:21:47 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 734421518558605313,
  "created_at" : "2016-05-22 16:31:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danger noodle",
      "screen_name" : "dasparky",
      "indices" : [ 0, 9 ],
      "id_str" : "12642282",
      "id" : 12642282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734180432946692096",
  "geo" : { },
  "id_str" : "734203831521816577",
  "in_reply_to_user_id" : 12642282,
  "text" : "@dasparky well, it lets me sort follows by time so I'm happy. Thanks! : )",
  "id" : 734203831521816577,
  "in_reply_to_status_id" : 734180432946692096,
  "created_at" : "2016-05-22 02:06:48 +0000",
  "in_reply_to_screen_name" : "dasparky",
  "in_reply_to_user_id_str" : "12642282",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 0, 11 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734178680994435072",
  "geo" : { },
  "id_str" : "734179015339180032",
  "in_reply_to_user_id" : 93747129,
  "text" : "@moosebegab not a \"who's not following\" app, tho. I follow ppl by shared interests.",
  "id" : 734179015339180032,
  "in_reply_to_status_id" : 734178680994435072,
  "created_at" : "2016-05-22 00:28:12 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734178680994435072",
  "text" : "any idea how to go thru my follow list easier? i want to clean up who im following.. maybe an app?",
  "id" : 734178680994435072,
  "created_at" : "2016-05-22 00:26:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ieeVwVTlZK",
      "expanded_url" : "http:\/\/espn.go.com\/horse-racing\/story\/_\/id\/15645111",
      "display_url" : "espn.go.com\/horse-racing\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734100967206064128",
  "text" : "RT @dwaynereaves: Two horses die after racing ahead of Preakness https:\/\/t.co\/ieeVwVTlZK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/ieeVwVTlZK",
        "expanded_url" : "http:\/\/espn.go.com\/horse-racing\/story\/_\/id\/15645111",
        "display_url" : "espn.go.com\/horse-racing\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734084270327758848",
    "text" : "Two horses die after racing ahead of Preakness https:\/\/t.co\/ieeVwVTlZK",
    "id" : 734084270327758848,
    "created_at" : "2016-05-21 18:11:43 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 734100967206064128,
  "created_at" : "2016-05-21 19:18:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ColorOfChange.org",
      "screen_name" : "ColorOfChange",
      "indices" : [ 3, 17 ],
      "id_str" : "27793335",
      "id" : 27793335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734072579259006976",
  "text" : "RT @ColorOfChange: It's not a joke. Dog the Bounty Hunter &amp; his wife are really using their celebrity to block criminal justice reform. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/gQqFioEqgV",
        "expanded_url" : "http:\/\/bit.ly\/1q2DHdS",
        "display_url" : "bit.ly\/1q2DHdS"
      } ]
    },
    "geo" : { },
    "id_str" : "734070003985588226",
    "text" : "It's not a joke. Dog the Bounty Hunter &amp; his wife are really using their celebrity to block criminal justice reform. https:\/\/t.co\/gQqFioEqgV",
    "id" : 734070003985588226,
    "created_at" : "2016-05-21 17:15:01 +0000",
    "user" : {
      "name" : "ColorOfChange.org",
      "screen_name" : "ColorOfChange",
      "protected" : false,
      "id_str" : "27793335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758364049235148800\/BPo4un0O_normal.jpg",
      "id" : 27793335,
      "verified" : false
    }
  },
  "id" : 734072579259006976,
  "created_at" : "2016-05-21 17:25:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Monday",
      "screen_name" : "KaBrent",
      "indices" : [ 3, 11 ],
      "id_str" : "95348464",
      "id" : 95348464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734071728842936320",
  "text" : "RT @KaBrent: Ex 22:18 \u201CThou shalt not suffer a witch to live,\u201D Christians killed 60,000+ accused witches in European witch hunts https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KaBrent\/status\/733981808346419201\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/b98nbXph2r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci-gkKcWsAANGSU.jpg",
        "id_str" : "733981807423696896",
        "id" : 733981807423696896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci-gkKcWsAANGSU.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 366
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 366
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 366
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/b98nbXph2r"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733981808346419201",
    "text" : "Ex 22:18 \u201CThou shalt not suffer a witch to live,\u201D Christians killed 60,000+ accused witches in European witch hunts https:\/\/t.co\/b98nbXph2r",
    "id" : 733981808346419201,
    "created_at" : "2016-05-21 11:24:34 +0000",
    "user" : {
      "name" : "Brent Monday",
      "screen_name" : "KaBrent",
      "protected" : false,
      "id_str" : "95348464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697820966827773953\/l9OppszQ_normal.jpg",
      "id" : 95348464,
      "verified" : false
    }
  },
  "id" : 734071728842936320,
  "created_at" : "2016-05-21 17:21:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "734022726491340800",
  "geo" : { },
  "id_str" : "734039739477688320",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre i used 2B good w tech. now, DD had 2 help me scan onto DH pc so I could upload then fax. ugh...",
  "id" : 734039739477688320,
  "in_reply_to_status_id" : 734022726491340800,
  "created_at" : "2016-05-21 15:14:46 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/GVJ6mNa2xf",
      "expanded_url" : "https:\/\/youtu.be\/J0ppS0UlYY0",
      "display_url" : "youtu.be\/J0ppS0UlYY0"
    } ]
  },
  "geo" : { },
  "id_str" : "734023564182048769",
  "text" : "we all play a role &gt; 2016 Psychic Presidential Prediction - You may be shocked! https:\/\/t.co\/GVJ6mNa2xf #woo",
  "id" : 734023564182048769,
  "created_at" : "2016-05-21 14:10:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733833317427122176",
  "text" : "RT @SpiritualNurse: Sometimes questions are more important than answers. ~Nancy Willard",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733831429868687360",
    "text" : "Sometimes questions are more important than answers. ~Nancy Willard",
    "id" : 733831429868687360,
    "created_at" : "2016-05-21 01:27:01 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 733833317427122176,
  "created_at" : "2016-05-21 01:34:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733833281775542272",
  "text" : "RT @parkstepp: \u201CBe like a tree, let the dead leaves drop.\u201D\nRumi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733831474588291072",
    "text" : "\u201CBe like a tree, let the dead leaves drop.\u201D\nRumi",
    "id" : 733831474588291072,
    "created_at" : "2016-05-21 01:27:12 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 733833281775542272,
  "created_at" : "2016-05-21 01:34:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Koi Fresco",
      "screen_name" : "koifresco",
      "indices" : [ 3, 13 ],
      "id_str" : "1857947658",
      "id" : 1857947658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733720411129647104",
  "text" : "RT @koifresco: it's impressive how different each human stimuli can be. some people love music, some hate it. some love movies, some don't.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733717913681584129",
    "text" : "it's impressive how different each human stimuli can be. some people love music, some hate it. some love movies, some don't. weird but cool.",
    "id" : 733717913681584129,
    "created_at" : "2016-05-20 17:55:57 +0000",
    "user" : {
      "name" : "Koi Fresco",
      "screen_name" : "koifresco",
      "protected" : false,
      "id_str" : "1857947658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800859325132480512\/7nsejbdH_normal.jpg",
      "id" : 1857947658,
      "verified" : false
    }
  },
  "id" : 733720411129647104,
  "created_at" : "2016-05-20 18:05:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BADCHRISTIAN",
      "screen_name" : "xbadchristianx",
      "indices" : [ 3, 18 ],
      "id_str" : "330399024",
      "id" : 330399024
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowYouKnow",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733701021701156864",
  "text" : "RT @xbadchristianx: To anyone who likes us, and was under the silly impression that they were a Christian, sorry!! #NowYouKnow  https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowYouKnow",
        "indices" : [ 95, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/Xc0oKorpik",
        "expanded_url" : "https:\/\/twitter.com\/SaikoWoods\/status\/733513832602034178",
        "display_url" : "twitter.com\/SaikoWoods\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733696082870296577",
    "text" : "To anyone who likes us, and was under the silly impression that they were a Christian, sorry!! #NowYouKnow  https:\/\/t.co\/Xc0oKorpik",
    "id" : 733696082870296577,
    "created_at" : "2016-05-20 16:29:12 +0000",
    "user" : {
      "name" : "BADCHRISTIAN",
      "screen_name" : "xbadchristianx",
      "protected" : false,
      "id_str" : "330399024",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472061926571134976\/5CNxzM8L_normal.jpeg",
      "id" : 330399024,
      "verified" : false
    }
  },
  "id" : 733701021701156864,
  "created_at" : "2016-05-20 16:48:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/4SIIVOt2Uk",
      "expanded_url" : "https:\/\/twitter.com\/existentialcoms\/status\/733681971453300737",
      "display_url" : "twitter.com\/existentialcom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733698097545662464",
  "text" : "me. https:\/\/t.co\/4SIIVOt2Uk",
  "id" : 733698097545662464,
  "created_at" : "2016-05-20 16:37:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 0, 14 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733691119985430528",
  "geo" : { },
  "id_str" : "733697856658345985",
  "in_reply_to_user_id" : 272369448,
  "text" : "@Swanwhisperer ((hugs)) my condolences",
  "id" : 733697856658345985,
  "in_reply_to_status_id" : 733691119985430528,
  "created_at" : "2016-05-20 16:36:15 +0000",
  "in_reply_to_screen_name" : "Swanwhisperer",
  "in_reply_to_user_id_str" : "272369448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/733694783760302081\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/DEfYeNngl5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6bhLSWUAA3Br6.jpg",
      "id_str" : "733694783575707648",
      "id" : 733694783575707648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6bhLSWUAA3Br6.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 462,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/DEfYeNngl5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733697124118999040",
  "text" : "RT @SciencePorn: https:\/\/t.co\/DEfYeNngl5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/733694783760302081\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/DEfYeNngl5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6bhLSWUAA3Br6.jpg",
        "id_str" : "733694783575707648",
        "id" : 733694783575707648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6bhLSWUAA3Br6.jpg",
        "sizes" : [ {
          "h" : 679,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 462,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/DEfYeNngl5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733694783760302081",
    "text" : "https:\/\/t.co\/DEfYeNngl5",
    "id" : 733694783760302081,
    "created_at" : "2016-05-20 16:24:02 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 733697124118999040,
  "created_at" : "2016-05-20 16:33:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FayObserver.com",
      "screen_name" : "fayobserver",
      "indices" : [ 3, 15 ],
      "id_str" : "13210422",
      "id" : 13210422
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fayobserver\/status\/733643707254071296\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EQQ0wEcLgu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci5qHq3XEAAqajf.jpg",
      "id_str" : "733640469306085376",
      "id" : 733640469306085376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci5qHq3XEAAqajf.jpg",
      "sizes" : [ {
        "h" : 486,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/EQQ0wEcLgu"
    } ],
    "hashtags" : [ {
      "text" : "ICYMI",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/NzFVIQlfEH",
      "expanded_url" : "http:\/\/bit.ly\/255sqZY",
      "display_url" : "bit.ly\/255sqZY"
    } ]
  },
  "geo" : { },
  "id_str" : "733659770612264960",
  "text" : "RT @fayobserver: #ICYMI He was pardoned after 27 yrs in prison for crimes he did not commit: https:\/\/t.co\/NzFVIQlfEH https:\/\/t.co\/EQQ0wEcLgu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fayobserver\/status\/733643707254071296\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/EQQ0wEcLgu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci5qHq3XEAAqajf.jpg",
        "id_str" : "733640469306085376",
        "id" : 733640469306085376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci5qHq3XEAAqajf.jpg",
        "sizes" : [ {
          "h" : 486,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/EQQ0wEcLgu"
      } ],
      "hashtags" : [ {
        "text" : "ICYMI",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/NzFVIQlfEH",
        "expanded_url" : "http:\/\/bit.ly\/255sqZY",
        "display_url" : "bit.ly\/255sqZY"
      } ]
    },
    "geo" : { },
    "id_str" : "733643707254071296",
    "text" : "#ICYMI He was pardoned after 27 yrs in prison for crimes he did not commit: https:\/\/t.co\/NzFVIQlfEH https:\/\/t.co\/EQQ0wEcLgu",
    "id" : 733643707254071296,
    "created_at" : "2016-05-20 13:01:04 +0000",
    "user" : {
      "name" : "FayObserver.com",
      "screen_name" : "fayobserver",
      "protected" : false,
      "id_str" : "13210422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735234152761561088\/t2_dzvDQ_normal.jpg",
      "id" : 13210422,
      "verified" : false
    }
  },
  "id" : 733659770612264960,
  "created_at" : "2016-05-20 14:04:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/e5vXGGbjz2",
      "expanded_url" : "https:\/\/youtu.be\/bKYE4xtJ09A",
      "display_url" : "youtu.be\/bKYE4xtJ09A"
    } ]
  },
  "geo" : { },
  "id_str" : "733435101565095936",
  "text" : "Liberal Redneck - Belief Don't Matter None https:\/\/t.co\/e5vXGGbjz2",
  "id" : 733435101565095936,
  "created_at" : "2016-05-19 23:12:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wisdom",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "circleoflife",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733381602667945984",
  "geo" : { },
  "id_str" : "733389475028537345",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind huh.. there you go being buddhisty again..lol #wisdom #circleoflife",
  "id" : 733389475028537345,
  "in_reply_to_status_id" : 733381602667945984,
  "created_at" : "2016-05-19 20:10:51 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733381913579257857",
  "geo" : { },
  "id_str" : "733389169658068992",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind well, the individual starts at conception. as to life force, soul, conciousness.. that's another ball of wax.",
  "id" : 733389169658068992,
  "in_reply_to_status_id" : 733381913579257857,
  "created_at" : "2016-05-19 20:09:38 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Home",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "Canada",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "photography",
      "indices" : [ 83, 95 ]
    }, {
      "text" : "architecture",
      "indices" : [ 96, 109 ]
    }, {
      "text" : "house",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "wood",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733384035301478400",
  "text" : "RT @ToadHollowPhoto: Character #Home - Vancouver Island, British Columbia, #Canada #photography #architecture #house #wood https:\/\/t.co\/poX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ToadHollowPhoto\/status\/733347850617163777\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/poX0sVY93K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci1f-5MW0AAfMjP.jpg",
        "id_str" : "733347848440434688",
        "id" : 733347848440434688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci1f-5MW0AAfMjP.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/poX0sVY93K"
      } ],
      "hashtags" : [ {
        "text" : "Home",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "Canada",
        "indices" : [ 54, 61 ]
      }, {
        "text" : "photography",
        "indices" : [ 62, 74 ]
      }, {
        "text" : "architecture",
        "indices" : [ 75, 88 ]
      }, {
        "text" : "house",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "wood",
        "indices" : [ 96, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733347850617163777",
    "text" : "Character #Home - Vancouver Island, British Columbia, #Canada #photography #architecture #house #wood https:\/\/t.co\/poX0sVY93K",
    "id" : 733347850617163777,
    "created_at" : "2016-05-19 17:25:27 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 733384035301478400,
  "created_at" : "2016-05-19 19:49:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "One by One The Movie",
      "screen_name" : "OneByOne_movie",
      "indices" : [ 3, 18 ],
      "id_str" : "245237033",
      "id" : 245237033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733364620472287232",
  "text" : "RT @OneByOne_movie: So this is it! The final master version of One by One that I've just triple checked... It's now off for a little... htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/kRX9r8I5Lz",
        "expanded_url" : "http:\/\/fb.me\/3zBlBTv2U",
        "display_url" : "fb.me\/3zBlBTv2U"
      } ]
    },
    "geo" : { },
    "id_str" : "731406010552848384",
    "text" : "So this is it! The final master version of One by One that I've just triple checked... It's now off for a little... https:\/\/t.co\/kRX9r8I5Lz",
    "id" : 731406010552848384,
    "created_at" : "2016-05-14 08:49:16 +0000",
    "user" : {
      "name" : "One by One The Movie",
      "screen_name" : "OneByOne_movie",
      "protected" : false,
      "id_str" : "245237033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1930765689\/one_by_one04_normal.jpg",
      "id" : 245237033,
      "verified" : false
    }
  },
  "id" : 733364620472287232,
  "created_at" : "2016-05-19 18:32:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/J1xrnTgOu4",
      "expanded_url" : "https:\/\/youtu.be\/KI2koOGpR5Q",
      "display_url" : "youtu.be\/KI2koOGpR5Q"
    } ]
  },
  "geo" : { },
  "id_str" : "733362683689480192",
  "text" : "rik mayall clip \"one by one\" https:\/\/t.co\/J1xrnTgOu4 #9-11",
  "id" : 733362683689480192,
  "created_at" : "2016-05-19 18:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MaryCT",
      "screen_name" : "CTcrazyGF",
      "indices" : [ 3, 13 ],
      "id_str" : "22132753",
      "id" : 22132753
    }, {
      "name" : "MaryCT",
      "screen_name" : "CTcrazyGF",
      "indices" : [ 15, 25 ],
      "id_str" : "22132753",
      "id" : 22132753
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CTcrazyGF\/status\/733265118096687104\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/RokRY3N7Bf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci0Uu_KXIAA4kFt.jpg",
      "id_str" : "733265111792689152",
      "id" : 733265111792689152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci0Uu_KXIAA4kFt.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RokRY3N7Bf"
    } ],
    "hashtags" : [ {
      "text" : "PrayerShawl",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733321848654561280",
  "text" : "RT @CTcrazyGF: @CTcrazyGF will make a great #PrayerShawl https:\/\/t.co\/RokRY3N7Bf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MaryCT",
        "screen_name" : "CTcrazyGF",
        "indices" : [ 0, 10 ],
        "id_str" : "22132753",
        "id" : 22132753
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CTcrazyGF\/status\/733265118096687104\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/RokRY3N7Bf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci0Uu_KXIAA4kFt.jpg",
        "id_str" : "733265111792689152",
        "id" : 733265111792689152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci0Uu_KXIAA4kFt.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RokRY3N7Bf"
      } ],
      "hashtags" : [ {
        "text" : "PrayerShawl",
        "indices" : [ 29, 41 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "733264613651972096",
    "geo" : { },
    "id_str" : "733265118096687104",
    "in_reply_to_user_id" : 22132753,
    "text" : "@CTcrazyGF will make a great #PrayerShawl https:\/\/t.co\/RokRY3N7Bf",
    "id" : 733265118096687104,
    "in_reply_to_status_id" : 733264613651972096,
    "created_at" : "2016-05-19 11:56:42 +0000",
    "in_reply_to_screen_name" : "CTcrazyGF",
    "in_reply_to_user_id_str" : "22132753",
    "user" : {
      "name" : "MaryCT",
      "screen_name" : "CTcrazyGF",
      "protected" : false,
      "id_str" : "22132753",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784184104719937536\/1MRq6UQo_normal.jpg",
      "id" : 22132753,
      "verified" : false
    }
  },
  "id" : 733321848654561280,
  "created_at" : "2016-05-19 15:42:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 3, 13 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733315761691844610",
  "text" : "RT @ShaunKing: \"The police attack you. Hit you upside your head. Then charge you with assault.\"\n\n-Malcolm X.\n\n55 years ago\nhttps:\/\/t.co\/MDN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/MDNwmS9PNd",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/94e713f8-3170-4a31-811c-47785000d179",
        "display_url" : "amp.twimg.com\/v\/94e713f8-317\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733305117651279872",
    "text" : "\"The police attack you. Hit you upside your head. Then charge you with assault.\"\n\n-Malcolm X.\n\n55 years ago\nhttps:\/\/t.co\/MDNwmS9PNd",
    "id" : 733305117651279872,
    "created_at" : "2016-05-19 14:35:38 +0000",
    "user" : {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "protected" : false,
      "id_str" : "755113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690138574050705408\/HkB9XCu4_normal.jpg",
      "id" : 755113,
      "verified" : true
    }
  },
  "id" : 733315761691844610,
  "created_at" : "2016-05-19 15:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733304909311905792",
  "geo" : { },
  "id_str" : "733315079756754944",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides maybe use a caller id\/ block app (even temporary?) mr number, truecaller..",
  "id" : 733315079756754944,
  "in_reply_to_status_id" : 733304909311905792,
  "created_at" : "2016-05-19 15:15:14 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "733304909311905792",
  "geo" : { },
  "id_str" : "733314757487427584",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides its not me, i swear.. well.. i dont think its me. (ive accidentally called back callers playing w phone..lol)",
  "id" : 733314757487427584,
  "in_reply_to_status_id" : 733304909311905792,
  "created_at" : "2016-05-19 15:13:57 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "indices" : [ 3, 12 ],
      "id_str" : "552094863",
      "id" : 552094863
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/733306444167008257\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ojLbHLDed4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci06Uv4UkAAeCn5.jpg",
      "id_str" : "733306442455748608",
      "id" : 733306442455748608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci06Uv4UkAAeCn5.jpg",
      "sizes" : [ {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1512
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ojLbHLDed4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/733306444167008257\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ojLbHLDed4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci06UyiUgAESrfl.jpg",
      "id_str" : "733306443168776193",
      "id" : 733306443168776193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci06UyiUgAESrfl.jpg",
      "sizes" : [ {
        "h" : 429,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1512
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ojLbHLDed4"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "Arizona",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733313596093042688",
  "text" : "RT @AWrobley: Cormorants being lovey dovey...then off to build a nest! #birds #Arizona https:\/\/t.co\/ojLbHLDed4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/733306444167008257\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/ojLbHLDed4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci06Uv4UkAAeCn5.jpg",
        "id_str" : "733306442455748608",
        "id" : 733306442455748608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci06Uv4UkAAeCn5.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1512
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ojLbHLDed4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AWrobley\/status\/733306444167008257\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/ojLbHLDed4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci06UyiUgAESrfl.jpg",
        "id_str" : "733306443168776193",
        "id" : 733306443168776193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci06UyiUgAESrfl.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1512
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ojLbHLDed4"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 57, 63 ]
      }, {
        "text" : "Arizona",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733306444167008257",
    "text" : "Cormorants being lovey dovey...then off to build a nest! #birds #Arizona https:\/\/t.co\/ojLbHLDed4",
    "id" : 733306444167008257,
    "created_at" : "2016-05-19 14:40:55 +0000",
    "user" : {
      "name" : "A.Wrobley",
      "screen_name" : "AWrobley",
      "protected" : false,
      "id_str" : "552094863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762087287538581504\/AtMoZmT1_normal.jpg",
      "id" : 552094863,
      "verified" : false
    }
  },
  "id" : 733313596093042688,
  "created_at" : "2016-05-19 15:09:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/704947111448715264\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/SJi6eGVYnE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cch5qYlWEAEvThe.jpg",
      "id_str" : "704947110744035329",
      "id" : 704947110744035329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cch5qYlWEAEvThe.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 880
      } ],
      "display_url" : "pic.twitter.com\/SJi6eGVYnE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733313160611016706",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/SJi6eGVYnE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/704947111448715264\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/SJi6eGVYnE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cch5qYlWEAEvThe.jpg",
        "id_str" : "704947110744035329",
        "id" : 704947110744035329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cch5qYlWEAEvThe.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 587,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/SJi6eGVYnE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733311716147236864",
    "text" : "https:\/\/t.co\/SJi6eGVYnE",
    "id" : 733311716147236864,
    "created_at" : "2016-05-19 15:01:52 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 733313160611016706,
  "created_at" : "2016-05-19 15:07:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/tRvbtTjBwW",
      "expanded_url" : "http:\/\/on.wsj.com\/1gLD7rF",
      "display_url" : "on.wsj.com\/1gLD7rF"
    } ]
  },
  "geo" : { },
  "id_str" : "733293433289355264",
  "text" : "He or she? The brain will tell, says Robert M. Sapolsky.  https:\/\/t.co\/tRvbtTjBwW",
  "id" : 733293433289355264,
  "created_at" : "2016-05-19 13:49:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/733069963620155393\/photo\/1",
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/2vFae7KDOL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CixjP26WUAAOsVK.jpg",
      "id_str" : "733069963443982336",
      "id" : 733069963443982336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CixjP26WUAAOsVK.jpg",
      "sizes" : [ {
        "h" : 634,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 634,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2vFae7KDOL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733071523582513152",
  "text" : "RT @SciencePorn: Meteor shower https:\/\/t.co\/2vFae7KDOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/733069963620155393\/photo\/1",
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/2vFae7KDOL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CixjP26WUAAOsVK.jpg",
        "id_str" : "733069963443982336",
        "id" : 733069963443982336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CixjP26WUAAOsVK.jpg",
        "sizes" : [ {
          "h" : 634,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2vFae7KDOL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733069963620155393",
    "text" : "Meteor shower https:\/\/t.co\/2vFae7KDOL",
    "id" : 733069963620155393,
    "created_at" : "2016-05-18 23:01:13 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 733071523582513152,
  "created_at" : "2016-05-18 23:07:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733055093008945152",
  "text" : "if i dont drink enough water during the day.. i feel ill. bah.",
  "id" : 733055093008945152,
  "created_at" : "2016-05-18 22:02:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/733023176439910402\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/45BvcKTBD2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ciw4rBMUkAEigtj.jpg",
      "id_str" : "733023151060193281",
      "id" : 733023151060193281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ciw4rBMUkAEigtj.jpg",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/45BvcKTBD2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733025133527437313",
  "text" : "RT @5thdimdreamz: https:\/\/t.co\/45BvcKTBD2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5thdimdreamz\/status\/733023176439910402\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/45BvcKTBD2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ciw4rBMUkAEigtj.jpg",
        "id_str" : "733023151060193281",
        "id" : 733023151060193281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ciw4rBMUkAEigtj.jpg",
        "sizes" : [ {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/45BvcKTBD2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733023176439910402",
    "text" : "https:\/\/t.co\/45BvcKTBD2",
    "id" : 733023176439910402,
    "created_at" : "2016-05-18 19:55:18 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 733025133527437313,
  "created_at" : "2016-05-18 20:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732999252641775617",
  "text" : "apparently I should not have a cell phone.. and now I need to change my phone number. gah.",
  "id" : 732999252641775617,
  "created_at" : "2016-05-18 18:20:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/732982499874312192\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/UKZeTyXY6e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiwTpZ4WsAICbBJ.jpg",
      "id_str" : "732982441397366786",
      "id" : 732982441397366786,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiwTpZ4WsAICbBJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1498
      }, {
        "h" : 1400,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UKZeTyXY6e"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/732982499874312192\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/UKZeTyXY6e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiwTpaxW0AE5Yzb.jpg",
      "id_str" : "732982441636450305",
      "id" : 732982441636450305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiwTpaxW0AE5Yzb.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UKZeTyXY6e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732999052992892929",
  "text" : "RT @1CatShepherd: Caught red handed responding to my Twitter followers https:\/\/t.co\/UKZeTyXY6e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/732982499874312192\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/UKZeTyXY6e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiwTpZ4WsAICbBJ.jpg",
        "id_str" : "732982441397366786",
        "id" : 732982441397366786,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiwTpZ4WsAICbBJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1498
        }, {
          "h" : 1400,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UKZeTyXY6e"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/732982499874312192\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/UKZeTyXY6e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiwTpaxW0AE5Yzb.jpg",
        "id_str" : "732982441636450305",
        "id" : 732982441636450305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiwTpaxW0AE5Yzb.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UKZeTyXY6e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732982499874312192",
    "text" : "Caught red handed responding to my Twitter followers https:\/\/t.co\/UKZeTyXY6e",
    "id" : 732982499874312192,
    "created_at" : "2016-05-18 17:13:40 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 732999052992892929,
  "created_at" : "2016-05-18 18:19:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/732964220309012481\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/D4M67HjpAb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiwDExzWsAII2gw.jpg",
      "id_str" : "732964219977641986",
      "id" : 732964219977641986,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiwDExzWsAII2gw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/D4M67HjpAb"
    } ],
    "hashtags" : [ {
      "text" : "Probiotics",
      "indices" : [ 70, 81 ]
    }, {
      "text" : "gut",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "health",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732972075355361280",
  "text" : "RT @mercola: Your intestinal bacteria are part of your immune system. #Probiotics #gut #health https:\/\/t.co\/D4M67HjpAb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mercola\/status\/732964220309012481\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/D4M67HjpAb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiwDExzWsAII2gw.jpg",
        "id_str" : "732964219977641986",
        "id" : 732964219977641986,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiwDExzWsAII2gw.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/D4M67HjpAb"
      } ],
      "hashtags" : [ {
        "text" : "Probiotics",
        "indices" : [ 57, 68 ]
      }, {
        "text" : "gut",
        "indices" : [ 69, 73 ]
      }, {
        "text" : "health",
        "indices" : [ 74, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732964220309012481",
    "text" : "Your intestinal bacteria are part of your immune system. #Probiotics #gut #health https:\/\/t.co\/D4M67HjpAb",
    "id" : 732964220309012481,
    "created_at" : "2016-05-18 16:01:02 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 732972075355361280,
  "created_at" : "2016-05-18 16:32:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "feedly",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Rwu6cierVy",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/8a2b6beca43362\/63084?app_id=339",
      "display_url" : "producthunt.com\/r\/8a2b6beca433\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732946226358976512",
  "text" : "Intently \u2014 Adblocker meets Pinterest to replace ads with inspiration https:\/\/t.co\/Rwu6cierVy #tech #feedly",
  "id" : 732946226358976512,
  "created_at" : "2016-05-18 14:49:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NaturalFibre Company",
      "screen_name" : "NatFibreCo",
      "indices" : [ 3, 14 ],
      "id_str" : "1257599581",
      "id" : 1257599581
    }, {
      "name" : "Blacker Yarns",
      "screen_name" : "blackeryarns",
      "indices" : [ 64, 77 ],
      "id_str" : "130115333",
      "id" : 130115333
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NatFibreCo\/status\/732892014186913792\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/8gVCa0MQeP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChxPX1kWMAEXxbD.jpg",
      "id_str" : "728544510662291457",
      "id" : 728544510662291457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChxPX1kWMAEXxbD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/8gVCa0MQeP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732931485481734144",
  "text" : "RT @NatFibreCo: This wonderful blanket has been crocheted using @blackeryarns Swan range. https:\/\/t.co\/8gVCa0MQeP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blacker Yarns",
        "screen_name" : "blackeryarns",
        "indices" : [ 48, 61 ],
        "id_str" : "130115333",
        "id" : 130115333
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatFibreCo\/status\/732892014186913792\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/8gVCa0MQeP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChxPX1kWMAEXxbD.jpg",
        "id_str" : "728544510662291457",
        "id" : 728544510662291457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChxPX1kWMAEXxbD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/8gVCa0MQeP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732892014186913792",
    "text" : "This wonderful blanket has been crocheted using @blackeryarns Swan range. https:\/\/t.co\/8gVCa0MQeP",
    "id" : 732892014186913792,
    "created_at" : "2016-05-18 11:14:07 +0000",
    "user" : {
      "name" : "NaturalFibre Company",
      "screen_name" : "NatFibreCo",
      "protected" : false,
      "id_str" : "1257599581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000548203766\/fe287d18e0f3a1e2ea1cded38658564e_normal.jpeg",
      "id" : 1257599581,
      "verified" : false
    }
  },
  "id" : 732931485481734144,
  "created_at" : "2016-05-18 13:50:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weather",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "ncwx",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732931395996291072",
  "text" : "RT @dwaynereaves: This is what sunshine looks like! All my North Carolina friends have probably forgotten!  #weather #ncwx https:\/\/t.co\/eGY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/732908443745570817\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/eGYfvjPDow",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CivQV_XUYAEtN-v.jpg",
        "id_str" : "732908440582905857",
        "id" : 732908440582905857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CivQV_XUYAEtN-v.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eGYfvjPDow"
      } ],
      "hashtags" : [ {
        "text" : "weather",
        "indices" : [ 90, 98 ]
      }, {
        "text" : "ncwx",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732908443745570817",
    "text" : "This is what sunshine looks like! All my North Carolina friends have probably forgotten!  #weather #ncwx https:\/\/t.co\/eGYfvjPDow",
    "id" : 732908443745570817,
    "created_at" : "2016-05-18 12:19:24 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 732931395996291072,
  "created_at" : "2016-05-18 13:50:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "RockyNPS",
      "screen_name" : "RockyNPS",
      "indices" : [ 32, 41 ],
      "id_str" : "96783382",
      "id" : 96783382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/732710787450568704\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/hevoV9YxVk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CisckjbXIAEo9iA.jpg",
      "id_str" : "732710778688708609",
      "id" : 732710778688708609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CisckjbXIAEo9iA.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hevoV9YxVk"
    } ],
    "hashtags" : [ {
      "text" : "Colorado",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "nature",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732740391196319744",
  "text" : "RT @Interior: Moose in the mist @RockyNPS by Aaron Rockefeller #Colorado #nature https:\/\/t.co\/hevoV9YxVk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RockyNPS",
        "screen_name" : "RockyNPS",
        "indices" : [ 18, 27 ],
        "id_str" : "96783382",
        "id" : 96783382
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/732710787450568704\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/hevoV9YxVk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CisckjbXIAEo9iA.jpg",
        "id_str" : "732710778688708609",
        "id" : 732710778688708609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CisckjbXIAEo9iA.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hevoV9YxVk"
      } ],
      "hashtags" : [ {
        "text" : "Colorado",
        "indices" : [ 49, 58 ]
      }, {
        "text" : "nature",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732710787450568704",
    "text" : "Moose in the mist @RockyNPS by Aaron Rockefeller #Colorado #nature https:\/\/t.co\/hevoV9YxVk",
    "id" : 732710787450568704,
    "created_at" : "2016-05-17 23:13:59 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 732740391196319744,
  "created_at" : "2016-05-18 01:11:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deep Stuff",
      "screen_name" : "DeepStuff",
      "indices" : [ 3, 13 ],
      "id_str" : "18721583",
      "id" : 18721583
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeepStuff\/status\/732542518928138241\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/KijYG3eRxb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiqDiYSUUAArYjh.jpg",
      "id_str" : "732542516059197440",
      "id" : 732542516059197440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiqDiYSUUAArYjh.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/KijYG3eRxb"
    } ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/2qQ0obzuNw",
      "expanded_url" : "http:\/\/flip.it\/SOpao",
      "display_url" : "flip.it\/SOpao"
    } ]
  },
  "geo" : { },
  "id_str" : "732723306428825600",
  "text" : "RT @DeepStuff: Physicists Discover a New Form of Light https:\/\/t.co\/2qQ0obzuNw #science https:\/\/t.co\/KijYG3eRxb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeepStuff\/status\/732542518928138241\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/KijYG3eRxb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiqDiYSUUAArYjh.jpg",
        "id_str" : "732542516059197440",
        "id" : 732542516059197440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiqDiYSUUAArYjh.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/KijYG3eRxb"
      } ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/2qQ0obzuNw",
        "expanded_url" : "http:\/\/flip.it\/SOpao",
        "display_url" : "flip.it\/SOpao"
      } ]
    },
    "geo" : { },
    "id_str" : "732542518928138241",
    "text" : "Physicists Discover a New Form of Light https:\/\/t.co\/2qQ0obzuNw #science https:\/\/t.co\/KijYG3eRxb",
    "id" : 732542518928138241,
    "created_at" : "2016-05-17 12:05:21 +0000",
    "user" : {
      "name" : "Deep Stuff",
      "screen_name" : "DeepStuff",
      "protected" : false,
      "id_str" : "18721583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560993459205832704\/BrXDhjHu_normal.jpeg",
      "id" : 18721583,
      "verified" : false
    }
  },
  "id" : 732723306428825600,
  "created_at" : "2016-05-18 00:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "indices" : [ 0, 11 ],
      "id_str" : "548388698",
      "id" : 548388698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732719057246531584",
  "geo" : { },
  "id_str" : "732720508739936257",
  "in_reply_to_user_id" : 548388698,
  "text" : "@JohnUmland i just dont get the no medical care thing... sigh.",
  "id" : 732720508739936257,
  "in_reply_to_status_id" : 732719057246531584,
  "created_at" : "2016-05-17 23:52:37 +0000",
  "in_reply_to_screen_name" : "JohnUmland",
  "in_reply_to_user_id_str" : "548388698",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/n7rzenB32V",
      "expanded_url" : "https:\/\/youtu.be\/W_7c0I8ODKw",
      "display_url" : "youtu.be\/W_7c0I8ODKw"
    } ]
  },
  "geo" : { },
  "id_str" : "732712387120357376",
  "text" : "found this interesting. last 45 sec sums up. &gt; What happened at the Nevada Convention https:\/\/t.co\/n7rzenB32V",
  "id" : 732712387120357376,
  "created_at" : "2016-05-17 23:20:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/gu2rJAWP0F",
      "expanded_url" : "https:\/\/twitter.com\/matty_lawrence\/status\/732637073019162624",
      "display_url" : "twitter.com\/matty_lawrence\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732674280631197696",
  "text" : "huh.. never heard Hell inside Earth theory before. https:\/\/t.co\/gu2rJAWP0F",
  "id" : 732674280631197696,
  "created_at" : "2016-05-17 20:48:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732650270983880705",
  "text" : "dunno why but drinking water is helping headache today.",
  "id" : 732650270983880705,
  "created_at" : "2016-05-17 19:13:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Lidder",
      "screen_name" : "CollieColleen",
      "indices" : [ 3, 17 ],
      "id_str" : "396075623",
      "id" : 396075623
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/732626332006416384\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/sgsYClm8xj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CirPwhAWgAAwz2d.jpg",
      "id_str" : "732626321801641984",
      "id" : 732626321801641984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CirPwhAWgAAwz2d.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sgsYClm8xj"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/732626332006416384\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/sgsYClm8xj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CirPwjBW0AAnmSE.jpg",
      "id_str" : "732626322342727680",
      "id" : 732626322342727680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CirPwjBW0AAnmSE.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/sgsYClm8xj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732635094675030018",
  "text" : "RT @CollieColleen: Unusual road traffic! https:\/\/t.co\/sgsYClm8xj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/732626332006416384\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/sgsYClm8xj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CirPwhAWgAAwz2d.jpg",
        "id_str" : "732626321801641984",
        "id" : 732626321801641984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CirPwhAWgAAwz2d.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/sgsYClm8xj"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/732626332006416384\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/sgsYClm8xj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CirPwjBW0AAnmSE.jpg",
        "id_str" : "732626322342727680",
        "id" : 732626322342727680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CirPwjBW0AAnmSE.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/sgsYClm8xj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732626332006416384",
    "text" : "Unusual road traffic! https:\/\/t.co\/sgsYClm8xj",
    "id" : 732626332006416384,
    "created_at" : "2016-05-17 17:38:23 +0000",
    "user" : {
      "name" : "Angela Lidder",
      "screen_name" : "CollieColleen",
      "protected" : false,
      "id_str" : "396075623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249749495\/20120306_79_normal.jpg",
      "id" : 396075623,
      "verified" : false
    }
  },
  "id" : 732635094675030018,
  "created_at" : "2016-05-17 18:13:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 3, 13 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SymoneMarshall",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Aaiin4f807",
      "expanded_url" : "http:\/\/www.nydailynews.com\/news\/national\/beautiful-22-year-old-mom-symone-marshall-dies-police-custody-article-1.2639562",
      "display_url" : "nydailynews.com\/news\/national\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732604071505461248",
  "text" : "RT @ShaunKing: #SymoneMarshall \n\nBeautiful, beloved 22 y\/o mother of a 3 y\/o. Died in police custody in TX\n\nhttps:\/\/t.co\/Aaiin4f807 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/732566099653328896\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DO4zuMYwpD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiqY_FLWkAAnTp3.jpg",
        "id_str" : "732566098890100736",
        "id" : 732566098890100736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiqY_FLWkAAnTp3.jpg",
        "sizes" : [ {
          "h" : 582,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DO4zuMYwpD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/732566099653328896\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DO4zuMYwpD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiqY-9WXIAEyyW8.jpg",
        "id_str" : "732566096788791297",
        "id" : 732566096788791297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiqY-9WXIAEyyW8.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DO4zuMYwpD"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/732566099653328896\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DO4zuMYwpD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiqY2YZWkAEi-bz.jpg",
        "id_str" : "732565949430272001",
        "id" : 732565949430272001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiqY2YZWkAEi-bz.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DO4zuMYwpD"
      } ],
      "hashtags" : [ {
        "text" : "SymoneMarshall",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/Aaiin4f807",
        "expanded_url" : "http:\/\/www.nydailynews.com\/news\/national\/beautiful-22-year-old-mom-symone-marshall-dies-police-custody-article-1.2639562",
        "display_url" : "nydailynews.com\/news\/national\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732566099653328896",
    "text" : "#SymoneMarshall \n\nBeautiful, beloved 22 y\/o mother of a 3 y\/o. Died in police custody in TX\n\nhttps:\/\/t.co\/Aaiin4f807 https:\/\/t.co\/DO4zuMYwpD",
    "id" : 732566099653328896,
    "created_at" : "2016-05-17 13:39:03 +0000",
    "user" : {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "protected" : false,
      "id_str" : "755113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690138574050705408\/HkB9XCu4_normal.jpg",
      "id" : 755113,
      "verified" : true
    }
  },
  "id" : 732604071505461248,
  "created_at" : "2016-05-17 16:09:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KERV",
      "screen_name" : "KervSoReal",
      "indices" : [ 3, 14 ],
      "id_str" : "378573275",
      "id" : 378573275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732603932267151360",
  "text" : "RT @KervSoReal: I live in Huntsville, and had no idea this happened, yet they publish  irrelevant articles  in the newspaper daily https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ywAHUJqxRf",
        "expanded_url" : "https:\/\/twitter.com\/shaunking\/status\/732566099653328896",
        "display_url" : "twitter.com\/shaunking\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732584985639550978",
    "text" : "I live in Huntsville, and had no idea this happened, yet they publish  irrelevant articles  in the newspaper daily https:\/\/t.co\/ywAHUJqxRf",
    "id" : 732584985639550978,
    "created_at" : "2016-05-17 14:54:06 +0000",
    "user" : {
      "name" : "KERV",
      "screen_name" : "KervSoReal",
      "protected" : false,
      "id_str" : "378573275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796397753836376064\/-7zRCsbR_normal.jpg",
      "id" : 378573275,
      "verified" : false
    }
  },
  "id" : 732603932267151360,
  "created_at" : "2016-05-17 16:09:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/4eij9TK9t0",
      "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/731803132682993664",
      "display_url" : "twitter.com\/aigkenham\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732382573276635137",
  "text" : "really?? you think this proves a point? https:\/\/t.co\/4eij9TK9t0",
  "id" : 732382573276635137,
  "created_at" : "2016-05-17 01:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "indices" : [ 3, 13 ],
      "id_str" : "574554751",
      "id" : 574554751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YellowstoneBisonCalf",
      "indices" : [ 106, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/NB4PCcjDS3",
      "expanded_url" : "http:\/\/www.keyt.com\/news\/housebroken-bison-sold-on-craigslist-finds-new-home\/39559424",
      "display_url" : "keyt.com\/news\/housebrok\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732380556957224960",
  "text" : "RT @CosmoTyme: Housebroken bison sold on Craigslist, finds new home | News - KEYT https:\/\/t.co\/NB4PCcjDS3 #YellowstoneBisonCalf deserved a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YellowstoneBisonCalf",
        "indices" : [ 91, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/NB4PCcjDS3",
        "expanded_url" : "http:\/\/www.keyt.com\/news\/housebroken-bison-sold-on-craigslist-finds-new-home\/39559424",
        "display_url" : "keyt.com\/news\/housebrok\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732379606712360960",
    "text" : "Housebroken bison sold on Craigslist, finds new home | News - KEYT https:\/\/t.co\/NB4PCcjDS3 #YellowstoneBisonCalf deserved a chance to live!",
    "id" : 732379606712360960,
    "created_at" : "2016-05-17 01:17:59 +0000",
    "user" : {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "protected" : false,
      "id_str" : "574554751",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500723456317456385\/vX0Jdg1A_normal.jpeg",
      "id" : 574554751,
      "verified" : false
    }
  },
  "id" : 732380556957224960,
  "created_at" : "2016-05-17 01:21:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Collins",
      "screen_name" : "stan_sdcollins",
      "indices" : [ 0, 15 ],
      "id_str" : "858549320",
      "id" : 858549320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732336818843205632",
  "geo" : { },
  "id_str" : "732338266742067200",
  "in_reply_to_user_id" : 858549320,
  "text" : "@stan_sdcollins nice room!",
  "id" : 732338266742067200,
  "in_reply_to_status_id" : 732336818843205632,
  "created_at" : "2016-05-16 22:33:43 +0000",
  "in_reply_to_screen_name" : "stan_sdcollins",
  "in_reply_to_user_id_str" : "858549320",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/k3Fix8hcgP",
      "expanded_url" : "https:\/\/youtu.be\/4cr4KtlTrTA",
      "display_url" : "youtu.be\/4cr4KtlTrTA"
    } ]
  },
  "geo" : { },
  "id_str" : "732336144667529216",
  "text" : "obey, you lowly woman!! &lt; Pastor Anderson on Icelandic Radio https:\/\/t.co\/k3Fix8hcgP",
  "id" : 732336144667529216,
  "created_at" : "2016-05-16 22:25:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732327690380906496",
  "text" : "I'm 84% through Mr. Mann (Unabridged) by John Byron, narrated by Todd McLaren on my Audible app.",
  "id" : 732327690380906496,
  "created_at" : "2016-05-16 21:51:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/fTXfPzo4HT",
      "expanded_url" : "http:\/\/amzn.com\/k\/x1c9XiG0QSOOtd91hkoDzA",
      "display_url" : "amzn.com\/k\/x1c9XiG0QSOO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732323045558390786",
  "text" : "just started. good so far. https:\/\/t.co\/fTXfPzo4HT",
  "id" : 732323045558390786,
  "created_at" : "2016-05-16 21:33:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732319305140948996",
  "geo" : { },
  "id_str" : "732322445093408768",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley it was in our local lost pets group on FB. interesting some of the animals that come up.",
  "id" : 732322445093408768,
  "in_reply_to_status_id" : 732319305140948996,
  "created_at" : "2016-05-16 21:30:51 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732286954977542144",
  "geo" : { },
  "id_str" : "732318767078899713",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley bad day for animals.. grrr.. lost zebra was found deceased after a few days looking (catskill, ny) : (",
  "id" : 732318767078899713,
  "in_reply_to_status_id" : 732286954977542144,
  "created_at" : "2016-05-16 21:16:14 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/4GQ7xLH4tl",
      "expanded_url" : "https:\/\/twitter.com\/yellowstonenps\/status\/732254568143302661",
      "display_url" : "twitter.com\/yellowstonenps\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732318469711089664",
  "text" : "RT @ErinEFarley: Damn. The bison calf had to be euthanized. Stupid people. \uD83D\uDE20 https:\/\/t.co\/4GQ7xLH4tl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/4GQ7xLH4tl",
        "expanded_url" : "https:\/\/twitter.com\/yellowstonenps\/status\/732254568143302661",
        "display_url" : "twitter.com\/yellowstonenps\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732286954977542144",
    "text" : "Damn. The bison calf had to be euthanized. Stupid people. \uD83D\uDE20 https:\/\/t.co\/4GQ7xLH4tl",
    "id" : 732286954977542144,
    "created_at" : "2016-05-16 19:09:49 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 732318469711089664,
  "created_at" : "2016-05-16 21:15:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kings Cross",
      "screen_name" : "kingscrossuk",
      "indices" : [ 3, 16 ],
      "id_str" : "143951089",
      "id" : 143951089
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kingscrossuk\/status\/732257076832047104\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/7KDKUmh2Oq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil_7h_WgAEuz8-.jpg",
      "id_str" : "732257075137511425",
      "id" : 732257075137511425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil_7h_WgAEuz8-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/7KDKUmh2Oq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kRo07ROiPC",
      "expanded_url" : "https:\/\/www.facebook.com\/kingscrosslondon\/posts\/1085109441549139",
      "display_url" : "facebook.com\/kingscrosslond\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732279972069556224",
  "text" : "RT @kingscrossuk: Battlebridge Basin and 2 cygnets hatched, mum sitting on more eggs. Pics: https:\/\/t.co\/kRo07ROiPC https:\/\/t.co\/7KDKUmh2Oq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kingscrossuk\/status\/732257076832047104\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/7KDKUmh2Oq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cil_7h_WgAEuz8-.jpg",
        "id_str" : "732257075137511425",
        "id" : 732257075137511425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cil_7h_WgAEuz8-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/7KDKUmh2Oq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/kRo07ROiPC",
        "expanded_url" : "https:\/\/www.facebook.com\/kingscrosslondon\/posts\/1085109441549139",
        "display_url" : "facebook.com\/kingscrosslond\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732257076832047104",
    "text" : "Battlebridge Basin and 2 cygnets hatched, mum sitting on more eggs. Pics: https:\/\/t.co\/kRo07ROiPC https:\/\/t.co\/7KDKUmh2Oq",
    "id" : 732257076832047104,
    "created_at" : "2016-05-16 17:11:06 +0000",
    "user" : {
      "name" : "Kings Cross",
      "screen_name" : "kingscrossuk",
      "protected" : false,
      "id_str" : "143951089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3364254626\/39ba1c6d7dac5046f3130d22110a90ce_normal.jpeg",
      "id" : 143951089,
      "verified" : false
    }
  },
  "id" : 732279972069556224,
  "created_at" : "2016-05-16 18:42:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "indices" : [ 3, 18 ],
      "id_str" : "392880595",
      "id" : 392880595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732221795361820673",
  "text" : "RT @ThirdEyeShawty: You can only deliver the message to those who are a vibrational match to the message so don't stress yourself with thos\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702897704201031681",
    "text" : "You can only deliver the message to those who are a vibrational match to the message so don't stress yourself with those who can't hear you.",
    "id" : 702897704201031681,
    "created_at" : "2016-02-25 16:47:26 +0000",
    "user" : {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "protected" : false,
      "id_str" : "392880595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712827324723544064\/H6BO9VjX_normal.jpg",
      "id" : 392880595,
      "verified" : false
    }
  },
  "id" : 732221795361820673,
  "created_at" : "2016-05-16 14:50:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "indices" : [ 3, 18 ],
      "id_str" : "392880595",
      "id" : 392880595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732221725413380097",
  "text" : "RT @ThirdEyeShawty: We give too many people the power to lower our vibrations. Stand true to your own frequency.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703711554215223297",
    "text" : "We give too many people the power to lower our vibrations. Stand true to your own frequency.",
    "id" : 703711554215223297,
    "created_at" : "2016-02-27 22:41:23 +0000",
    "user" : {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "protected" : false,
      "id_str" : "392880595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712827324723544064\/H6BO9VjX_normal.jpg",
      "id" : 392880595,
      "verified" : false
    }
  },
  "id" : 732221725413380097,
  "created_at" : "2016-05-16 14:50:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "indices" : [ 3, 18 ],
      "id_str" : "392880595",
      "id" : 392880595
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThirdEyeShawty\/status\/716998430720188417\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/EZy5wGyUUZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfNKRb-WsAAmeQ1.jpg",
      "id_str" : "716998429109563392",
      "id" : 716998429109563392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfNKRb-WsAAmeQ1.jpg",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 307
      } ],
      "display_url" : "pic.twitter.com\/EZy5wGyUUZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732220598655590400",
  "text" : "RT @ThirdEyeShawty: Your focus affects your vibration. Where attention goes, energy flows. https:\/\/t.co\/EZy5wGyUUZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThirdEyeShawty\/status\/716998430720188417\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/EZy5wGyUUZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfNKRb-WsAAmeQ1.jpg",
        "id_str" : "716998429109563392",
        "id" : 716998429109563392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfNKRb-WsAAmeQ1.jpg",
        "sizes" : [ {
          "h" : 256,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 307
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 307
        } ],
        "display_url" : "pic.twitter.com\/EZy5wGyUUZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "716998430720188417",
    "text" : "Your focus affects your vibration. Where attention goes, energy flows. https:\/\/t.co\/EZy5wGyUUZ",
    "id" : 716998430720188417,
    "created_at" : "2016-04-04 14:38:41 +0000",
    "user" : {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "protected" : false,
      "id_str" : "392880595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712827324723544064\/H6BO9VjX_normal.jpg",
      "id" : 392880595,
      "verified" : false
    }
  },
  "id" : 732220598655590400,
  "created_at" : "2016-05-16 14:46:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "indices" : [ 3, 18 ],
      "id_str" : "392880595",
      "id" : 392880595
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThirdEyeShawty\/status\/728197466626109440\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/vvbJ0OW859",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChsTvFpXEAAQv7g.jpg",
      "id_str" : "728197464440901632",
      "id" : 728197464440901632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChsTvFpXEAAQv7g.jpg",
      "sizes" : [ {
        "h" : 521,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vvbJ0OW859"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732219813523795968",
  "text" : "RT @ThirdEyeShawty: I'm not atheist. We just don't share the same concept of God. https:\/\/t.co\/vvbJ0OW859",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThirdEyeShawty\/status\/728197466626109440\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/vvbJ0OW859",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChsTvFpXEAAQv7g.jpg",
        "id_str" : "728197464440901632",
        "id" : 728197464440901632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChsTvFpXEAAQv7g.jpg",
        "sizes" : [ {
          "h" : 521,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 277,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vvbJ0OW859"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728197466626109440",
    "text" : "I'm not atheist. We just don't share the same concept of God. https:\/\/t.co\/vvbJ0OW859",
    "id" : 728197466626109440,
    "created_at" : "2016-05-05 12:19:39 +0000",
    "user" : {
      "name" : "\u25B2 B47ANCE \u25B3",
      "screen_name" : "ThirdEyeShawty",
      "protected" : false,
      "id_str" : "392880595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712827324723544064\/H6BO9VjX_normal.jpg",
      "id" : 392880595,
      "verified" : false
    }
  },
  "id" : 732219813523795968,
  "created_at" : "2016-05-16 14:43:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/WBsgbW0HJa",
      "expanded_url" : "http:\/\/dose.ly\/24Q72ru",
      "display_url" : "dose.ly\/24Q72ru"
    } ]
  },
  "geo" : { },
  "id_str" : "732008303958626308",
  "text" : "RT @OMGFacts: No One Can Explain This Unknown Object That Has Been Orbiting Earth For The Last 60 Years https:\/\/t.co\/WBsgbW0HJa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/WBsgbW0HJa",
        "expanded_url" : "http:\/\/dose.ly\/24Q72ru",
        "display_url" : "dose.ly\/24Q72ru"
      } ]
    },
    "geo" : { },
    "id_str" : "732006499493552128",
    "text" : "No One Can Explain This Unknown Object That Has Been Orbiting Earth For The Last 60 Years https:\/\/t.co\/WBsgbW0HJa",
    "id" : 732006499493552128,
    "created_at" : "2016-05-16 00:35:24 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 732008303958626308,
  "created_at" : "2016-05-16 00:42:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i love biscuits",
      "screen_name" : "sayitwhirly",
      "indices" : [ 3, 15 ],
      "id_str" : "104351562",
      "id" : 104351562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/xmkf3nCcoD",
      "expanded_url" : "https:\/\/twitter.com\/goldietaylor\/status\/731586169083924481",
      "display_url" : "twitter.com\/goldietaylor\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731975193250435073",
  "text" : "RT @sayitwhirly: Read: https:\/\/t.co\/xmkf3nCcoD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/xmkf3nCcoD",
        "expanded_url" : "https:\/\/twitter.com\/goldietaylor\/status\/731586169083924481",
        "display_url" : "twitter.com\/goldietaylor\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731909857582960640",
    "text" : "Read: https:\/\/t.co\/xmkf3nCcoD",
    "id" : 731909857582960640,
    "created_at" : "2016-05-15 18:11:22 +0000",
    "user" : {
      "name" : "i love biscuits",
      "screen_name" : "sayitwhirly",
      "protected" : false,
      "id_str" : "104351562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787693418352893956\/KMwcq1qK_normal.jpg",
      "id" : 104351562,
      "verified" : false
    }
  },
  "id" : 731975193250435073,
  "created_at" : "2016-05-15 22:31:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/MwsBDTQDJV",
      "expanded_url" : "http:\/\/vclouds.deviantart.com\/art\/VClouds-Weather-2-179058977",
      "display_url" : "vclouds.deviantart.com\/art\/VClouds-We\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731869928702283776",
  "text" : "love this on my desktop. works well. &gt; \"VClouds Weather 2\" by VClouds https:\/\/t.co\/MwsBDTQDJV",
  "id" : 731869928702283776,
  "created_at" : "2016-05-15 15:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Good News Network",
      "screen_name" : "goodnewsnetwork",
      "indices" : [ 102, 118 ],
      "id_str" : "22025046",
      "id" : 22025046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/A3Vgimhllj",
      "expanded_url" : "http:\/\/www.goodnewsnetwork.org\/bridesmaid-dives-in-to-save-gosling-being-bullied-by-swan\/#.VziKdisW-Pg.twitter",
      "display_url" : "goodnewsnetwork.org\/bridesmaid-div\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731856936644280320",
  "text" : "Bridesmaid Marches into the Water to Save Gosling Being Drowned By a Swan https:\/\/t.co\/A3Vgimhllj via @GoodNewsNetwork",
  "id" : 731856936644280320,
  "created_at" : "2016-05-15 14:41:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/731649813851209728\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/zyR4Ba7jqJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CidXoQkU4AEPhNJ.png",
      "id_str" : "731649813624709121",
      "id" : 731649813624709121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CidXoQkU4AEPhNJ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zyR4Ba7jqJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731657687893676033",
  "text" : "RT @SciencePorn: https:\/\/t.co\/zyR4Ba7jqJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/731649813851209728\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/zyR4Ba7jqJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CidXoQkU4AEPhNJ.png",
        "id_str" : "731649813624709121",
        "id" : 731649813624709121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CidXoQkU4AEPhNJ.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 219,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 149,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zyR4Ba7jqJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731649813851209728",
    "text" : "https:\/\/t.co\/zyR4Ba7jqJ",
    "id" : 731649813851209728,
    "created_at" : "2016-05-15 00:58:03 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 731657687893676033,
  "created_at" : "2016-05-15 01:29:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mad In America",
      "screen_name" : "Mad_In_America",
      "indices" : [ 22, 37 ],
      "id_str" : "458674855",
      "id" : 458674855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/bbbsCODlf6",
      "expanded_url" : "http:\/\/go.shr.lc\/1VWJCiA",
      "display_url" : "go.shr.lc\/1VWJCiA"
    } ]
  },
  "geo" : { },
  "id_str" : "731652838112284672",
  "text" : "interesting &gt; From @Mad_In_America Consciousness Revealed - Revolutionary Implications for Psychiatry - https:\/\/t.co\/bbbsCODlf6",
  "id" : 731652838112284672,
  "created_at" : "2016-05-15 01:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul The Book Guy",
      "screen_name" : "PaulTheBookGuy",
      "indices" : [ 3, 18 ],
      "id_str" : "18302779",
      "id" : 18302779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/G6ipxIwUuv",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/bookguys",
      "display_url" : "reddit.com\/r\/bookguys"
    } ]
  },
  "geo" : { },
  "id_str" : "731631777224228865",
  "text" : "RT @PaulTheBookGuy: Join us at https:\/\/t.co\/G6ipxIwUuv (SUBSCRIBE!) and get in on our reboot contest as we get ready to bring back #BookGuy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BookGuysShow",
        "indices" : [ 111, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/G6ipxIwUuv",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/bookguys",
        "display_url" : "reddit.com\/r\/bookguys"
      } ]
    },
    "geo" : { },
    "id_str" : "730546406046339072",
    "text" : "Join us at https:\/\/t.co\/G6ipxIwUuv (SUBSCRIBE!) and get in on our reboot contest as we get ready to bring back #BookGuysShow",
    "id" : 730546406046339072,
    "created_at" : "2016-05-11 23:53:30 +0000",
    "user" : {
      "name" : "Paul The Book Guy",
      "screen_name" : "PaulTheBookGuy",
      "protected" : false,
      "id_str" : "18302779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764379424875810817\/cb59s5P9_normal.jpg",
      "id" : 18302779,
      "verified" : false
    }
  },
  "id" : 731631777224228865,
  "created_at" : "2016-05-14 23:46:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bcmystery\/status\/731627717032968192\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/8xQ8SyeSbf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CidDhz3UUAACmKG.jpg",
      "id_str" : "731627712607965184",
      "id" : 731627712607965184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CidDhz3UUAACmKG.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8xQ8SyeSbf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731628569894506496",
  "text" : "RT @bcmystery: Spoiler alert: I lived to tweet the tale. https:\/\/t.co\/8xQ8SyeSbf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bcmystery\/status\/731627717032968192\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/8xQ8SyeSbf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CidDhz3UUAACmKG.jpg",
        "id_str" : "731627712607965184",
        "id" : 731627712607965184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CidDhz3UUAACmKG.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8xQ8SyeSbf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731627717032968192",
    "text" : "Spoiler alert: I lived to tweet the tale. https:\/\/t.co\/8xQ8SyeSbf",
    "id" : 731627717032968192,
    "created_at" : "2016-05-14 23:30:15 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 731628569894506496,
  "created_at" : "2016-05-14 23:33:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731516292797239296",
  "geo" : { },
  "id_str" : "731518952820625408",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ((whines)) ((drools)) &lt;3",
  "id" : 731518952820625408,
  "in_reply_to_status_id" : 731516292797239296,
  "created_at" : "2016-05-14 16:18:03 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Levinthal",
      "screen_name" : "davelevinthal",
      "indices" : [ 3, 17 ],
      "id_str" : "222554961",
      "id" : 222554961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/8jDD6Mgmt6",
      "expanded_url" : "http:\/\/usat.ly\/1TeDej5",
      "display_url" : "usat.ly\/1TeDej5"
    } ]
  },
  "geo" : { },
  "id_str" : "731338538327912448",
  "text" : "RT @davelevinthal: There is one person left who was born during the 1800s.\n\nOne.\n\nhttps:\/\/t.co\/8jDD6Mgmt6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/8jDD6Mgmt6",
        "expanded_url" : "http:\/\/usat.ly\/1TeDej5",
        "display_url" : "usat.ly\/1TeDej5"
      } ]
    },
    "geo" : { },
    "id_str" : "731252588730064897",
    "text" : "There is one person left who was born during the 1800s.\n\nOne.\n\nhttps:\/\/t.co\/8jDD6Mgmt6",
    "id" : 731252588730064897,
    "created_at" : "2016-05-13 22:39:37 +0000",
    "user" : {
      "name" : "Dave Levinthal",
      "screen_name" : "davelevinthal",
      "protected" : false,
      "id_str" : "222554961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510081173330997249\/kCiJts9O_normal.png",
      "id" : 222554961,
      "verified" : true
    }
  },
  "id" : 731338538327912448,
  "created_at" : "2016-05-14 04:21:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adileni Whitfield",
      "screen_name" : "AdileniWhitfie",
      "indices" : [ 3, 18 ],
      "id_str" : "1964256980",
      "id" : 1964256980
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AdileniWhitfie\/status\/731138399483105280\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/JSnNyxQloD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWGgBzXIAAFCJv.jpg",
      "id_str" : "731138399315369984",
      "id" : 731138399315369984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWGgBzXIAAFCJv.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JSnNyxQloD"
    } ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 38, 46 ]
    }, {
      "text" : "image",
      "indices" : [ 47, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731312161411223552",
  "text" : "RT @AdileniWhitfie: Staithes, England #awesome #image https:\/\/t.co\/JSnNyxQloD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AdileniWhitfie\/status\/731138399483105280\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/JSnNyxQloD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWGgBzXIAAFCJv.jpg",
        "id_str" : "731138399315369984",
        "id" : 731138399315369984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWGgBzXIAAFCJv.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JSnNyxQloD"
      } ],
      "hashtags" : [ {
        "text" : "awesome",
        "indices" : [ 18, 26 ]
      }, {
        "text" : "image",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731138399483105280",
    "text" : "Staithes, England #awesome #image https:\/\/t.co\/JSnNyxQloD",
    "id" : 731138399483105280,
    "created_at" : "2016-05-13 15:05:52 +0000",
    "user" : {
      "name" : "Adileni Whitfield",
      "screen_name" : "AdileniWhitfie",
      "protected" : false,
      "id_str" : "1964256980",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531208287174148096\/dljbGGym_normal.png",
      "id" : 1964256980,
      "verified" : false
    }
  },
  "id" : 731312161411223552,
  "created_at" : "2016-05-14 02:36:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/731279497983594504\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/6NAgjePFjW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiYG05aWUAEJH4h.jpg",
      "id_str" : "731279495328583681",
      "id" : 731279495328583681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiYG05aWUAEJH4h.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/6NAgjePFjW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/4D2o9NJBQ1",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=021zbOjAXZ0&_ts=1463185591",
      "display_url" : "youtube.com\/watch?v=021zbO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731279497983594504",
  "text" : "\"Everyone Goes To Heaven\" ~ Dr. Phil Kidd https:\/\/t.co\/4D2o9NJBQ1 https:\/\/t.co\/6NAgjePFjW",
  "id" : 731279497983594504,
  "created_at" : "2016-05-14 00:26:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 7, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/XG3s9lMEGR",
      "expanded_url" : "https:\/\/twitter.com\/fairlyspiritual\/status\/731270763097939968",
      "display_url" : "twitter.com\/fairlyspiritua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731274399387635713",
  "text" : "heehee #INFP https:\/\/t.co\/XG3s9lMEGR",
  "id" : 731274399387635713,
  "created_at" : "2016-05-14 00:06:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "indices" : [ 3, 15 ],
      "id_str" : "321774180",
      "id" : 321774180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731260068017127424",
  "text" : "RT @ChrisJZullo: I'd like to meet the John Miller that works in the Trump Organization. While we're at it see his long form birth certifica\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731252124298977280",
    "text" : "I'd like to meet the John Miller that works in the Trump Organization. While we're at it see his long form birth certificate and tax return",
    "id" : 731252124298977280,
    "created_at" : "2016-05-13 22:37:47 +0000",
    "user" : {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "protected" : false,
      "id_str" : "321774180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614520488266727424\/MJBPfrGG_normal.jpg",
      "id" : 321774180,
      "verified" : false
    }
  },
  "id" : 731260068017127424,
  "created_at" : "2016-05-13 23:09:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/731254652721876992\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/FISvhCajvl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiXwOxcW0AAud6s.jpg",
      "id_str" : "731254651098681344",
      "id" : 731254651098681344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiXwOxcW0AAud6s.jpg",
      "sizes" : [ {
        "h" : 1397,
        "resize" : "fit",
        "w" : 1119
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1278,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FISvhCajvl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731259150496333824",
  "text" : "RT @ChippyCMunk: A top view of it https:\/\/t.co\/FISvhCajvl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/731254652721876992\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/FISvhCajvl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiXwOxcW0AAud6s.jpg",
        "id_str" : "731254651098681344",
        "id" : 731254651098681344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiXwOxcW0AAud6s.jpg",
        "sizes" : [ {
          "h" : 1397,
          "resize" : "fit",
          "w" : 1119
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1278,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FISvhCajvl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731254652721876992",
    "text" : "A top view of it https:\/\/t.co\/FISvhCajvl",
    "id" : 731254652721876992,
    "created_at" : "2016-05-13 22:47:49 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 731259150496333824,
  "created_at" : "2016-05-13 23:05:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 0, 16 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "731257387953197056",
  "geo" : { },
  "id_str" : "731259028731510784",
  "in_reply_to_user_id" : 24233147,
  "text" : "@fairlyspiritual doesn't look too scary..",
  "id" : 731259028731510784,
  "in_reply_to_status_id" : 731257387953197056,
  "created_at" : "2016-05-13 23:05:13 +0000",
  "in_reply_to_screen_name" : "fairlyspiritual",
  "in_reply_to_user_id_str" : "24233147",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SciencePorn\/status\/731258059192971264\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/lGc5SnI5b4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiXzVIpWEAA0L2e.jpg",
      "id_str" : "731258058941272064",
      "id" : 731258058941272064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiXzVIpWEAA0L2e.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 877,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 877,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lGc5SnI5b4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731258786418180096",
  "text" : "RT @SciencePorn: This is what rain looks like from an airplane. https:\/\/t.co\/lGc5SnI5b4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SciencePorn\/status\/731258059192971264\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/lGc5SnI5b4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiXzVIpWEAA0L2e.jpg",
        "id_str" : "731258058941272064",
        "id" : 731258058941272064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiXzVIpWEAA0L2e.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 877,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 877,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lGc5SnI5b4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731258059192971264",
    "text" : "This is what rain looks like from an airplane. https:\/\/t.co\/lGc5SnI5b4",
    "id" : 731258059192971264,
    "created_at" : "2016-05-13 23:01:22 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 731258786418180096,
  "created_at" : "2016-05-13 23:04:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731245119391797248",
  "text" : "just discovered my phone has a timer on it.",
  "id" : 731245119391797248,
  "created_at" : "2016-05-13 22:09:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mer",
      "screen_name" : "Theremina",
      "indices" : [ 3, 13 ],
      "id_str" : "7804612",
      "id" : 7804612
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Theremina\/status\/731171988236947456\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/xVkbhf7UCf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWlCuTU4AEz-Gc.jpg",
      "id_str" : "731171980724985857",
      "id" : 731171980724985857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWlCuTU4AEz-Gc.jpg",
      "sizes" : [ {
        "h" : 458,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 980
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 980
      } ],
      "display_url" : "pic.twitter.com\/xVkbhf7UCf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/dXl2jaCD0X",
      "expanded_url" : "http:\/\/molgh.tumblr.com",
      "display_url" : "molgh.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "731239707959562240",
  "text" : "RT @Theremina: https:\/\/t.co\/dXl2jaCD0X https:\/\/t.co\/xVkbhf7UCf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Theremina\/status\/731171988236947456\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/xVkbhf7UCf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWlCuTU4AEz-Gc.jpg",
        "id_str" : "731171980724985857",
        "id" : 731171980724985857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWlCuTU4AEz-Gc.jpg",
        "sizes" : [ {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 980
        } ],
        "display_url" : "pic.twitter.com\/xVkbhf7UCf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/dXl2jaCD0X",
        "expanded_url" : "http:\/\/molgh.tumblr.com",
        "display_url" : "molgh.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "731171988236947456",
    "text" : "https:\/\/t.co\/dXl2jaCD0X https:\/\/t.co\/xVkbhf7UCf",
    "id" : 731171988236947456,
    "created_at" : "2016-05-13 17:19:21 +0000",
    "user" : {
      "name" : "mer",
      "screen_name" : "Theremina",
      "protected" : false,
      "id_str" : "7804612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799402931120242688\/Kpnpxqzx_normal.jpg",
      "id" : 7804612,
      "verified" : false
    }
  },
  "id" : 731239707959562240,
  "created_at" : "2016-05-13 21:48:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/731185932301271041\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/tSO9UyWaBU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWxcmjUYAEsEnj.jpg",
      "id_str" : "731185619460710401",
      "id" : 731185619460710401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWxcmjUYAEsEnj.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/tSO9UyWaBU"
    } ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731196388286078977",
  "text" : "RT @CatskillCritter: Misty, rainy May day in the slowly greening Great Western #Catskills. https:\/\/t.co\/tSO9UyWaBU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/731185932301271041\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/tSO9UyWaBU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWxcmjUYAEsEnj.jpg",
        "id_str" : "731185619460710401",
        "id" : 731185619460710401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWxcmjUYAEsEnj.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/tSO9UyWaBU"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 58, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731185932301271041",
    "text" : "Misty, rainy May day in the slowly greening Great Western #Catskills. https:\/\/t.co\/tSO9UyWaBU",
    "id" : 731185932301271041,
    "created_at" : "2016-05-13 18:14:45 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 731196388286078977,
  "created_at" : "2016-05-13 18:56:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "indices" : [ 3, 14 ],
      "id_str" : "220895419",
      "id" : 220895419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/mEmkXXYFqm",
      "expanded_url" : "http:\/\/www.wellplated.com\/healthy-banana-bread-recipe\/",
      "display_url" : "wellplated.com\/healthy-banana\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731176604530057216",
  "text" : "RT @WellPlated: Need some healthy comfort food? Try this Healthy Banana Bread with Chocolate Chips \uD83C\uDF4C\uD83C\uDF6B!  https:\/\/t.co\/mEmkXXYFqm https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WellPlated\/status\/731164126387568640\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/DMXpLmqUor",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWd5gnWkAEaZWN.jpg",
        "id_str" : "731164125850669057",
        "id" : 731164125850669057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWd5gnWkAEaZWN.jpg",
        "sizes" : [ {
          "h" : 1534,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1798,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 899,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DMXpLmqUor"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/mEmkXXYFqm",
        "expanded_url" : "http:\/\/www.wellplated.com\/healthy-banana-bread-recipe\/",
        "display_url" : "wellplated.com\/healthy-banana\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731164126387568640",
    "text" : "Need some healthy comfort food? Try this Healthy Banana Bread with Chocolate Chips \uD83C\uDF4C\uD83C\uDF6B!  https:\/\/t.co\/mEmkXXYFqm https:\/\/t.co\/DMXpLmqUor",
    "id" : 731164126387568640,
    "created_at" : "2016-05-13 16:48:06 +0000",
    "user" : {
      "name" : "Erin Clarke",
      "screen_name" : "WellPlated",
      "protected" : false,
      "id_str" : "220895419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621711174824914944\/lOVoCMeS_normal.jpg",
      "id" : 220895419,
      "verified" : false
    }
  },
  "id" : 731176604530057216,
  "created_at" : "2016-05-13 17:37:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gocart mozart",
      "screen_name" : "gocartmozart1",
      "indices" : [ 3, 17 ],
      "id_str" : "919968950",
      "id" : 919968950
    }, {
      "name" : "Rod Dreher",
      "screen_name" : "roddreher",
      "indices" : [ 19, 29 ],
      "id_str" : "257145200",
      "id" : 257145200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731151726338838528",
  "text" : "RT @gocartmozart1: @roddreher curious,how many hours a day do you obsess over other people's genitals? Don't you have any hobbies or is tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rod Dreher",
        "screen_name" : "roddreher",
        "indices" : [ 0, 10 ],
        "id_str" : "257145200",
        "id" : 257145200
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "730860293744525313",
    "geo" : { },
    "id_str" : "730946702463647744",
    "in_reply_to_user_id" : 257145200,
    "text" : "@roddreher curious,how many hours a day do you obsess over other people's genitals? Don't you have any hobbies or is that it.",
    "id" : 730946702463647744,
    "in_reply_to_status_id" : 730860293744525313,
    "created_at" : "2016-05-13 02:24:08 +0000",
    "in_reply_to_screen_name" : "roddreher",
    "in_reply_to_user_id_str" : "257145200",
    "user" : {
      "name" : "gocart mozart",
      "screen_name" : "gocartmozart1",
      "protected" : false,
      "id_str" : "919968950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788857461943988224\/QS0jHvVx_normal.jpg",
      "id" : 919968950,
      "verified" : false
    }
  },
  "id" : 731151726338838528,
  "created_at" : "2016-05-13 15:58:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kenji kuramitsu (\u65E5\u7CFB)",
      "screen_name" : "afreshmind",
      "indices" : [ 3, 14 ],
      "id_str" : "226460394",
      "id" : 226460394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731151386344357889",
  "text" : "RT @afreshmind: this is the breaking point\/wake up call for them.\n\nBathrooms.\n\nNot lynchings, wars, poverty, corruption.\n\nBathrooms. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/7Bo6kjykZL",
        "expanded_url" : "https:\/\/twitter.com\/roddreher\/status\/730944520615907328",
        "display_url" : "twitter.com\/roddreher\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "731135121017868289",
    "text" : "this is the breaking point\/wake up call for them.\n\nBathrooms.\n\nNot lynchings, wars, poverty, corruption.\n\nBathrooms. https:\/\/t.co\/7Bo6kjykZL",
    "id" : 731135121017868289,
    "created_at" : "2016-05-13 14:52:51 +0000",
    "user" : {
      "name" : "kenji kuramitsu (\u65E5\u7CFB)",
      "screen_name" : "afreshmind",
      "protected" : false,
      "id_str" : "226460394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789730081589506048\/fXq9mps6_normal.jpg",
      "id" : 226460394,
      "verified" : false
    }
  },
  "id" : 731151386344357889,
  "created_at" : "2016-05-13 15:57:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "feedly",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/FYHRutrl8Y",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/fritjofsson\/rewind-iconic-headphones-inspired-by-the-80s",
      "display_url" : "kickstarter.com\/projects\/fritj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731144533254242304",
  "text" : "Rewind retro headphones \u2014 Iconic headphones inspired by the 80's. https:\/\/t.co\/FYHRutrl8Y #tech #feedly",
  "id" : 731144533254242304,
  "created_at" : "2016-05-13 15:30:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/cOShsBaMSl",
      "expanded_url" : "https:\/\/twitter.com\/AmitayusX\/status\/730957222298058753",
      "display_url" : "twitter.com\/AmitayusX\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "731118572794183682",
  "text" : "ponders... https:\/\/t.co\/cOShsBaMSl",
  "id" : 731118572794183682,
  "created_at" : "2016-05-13 13:47:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 3, 16 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/731032546390228992\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/vW3U4cWJWN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiUmMhbW0AA0KjM.jpg",
      "id_str" : "731032511090970624",
      "id" : 731032511090970624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiUmMhbW0AA0KjM.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vW3U4cWJWN"
    } ],
    "hashtags" : [ {
      "text" : "toweroflondon",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731118128952975361",
  "text" : "RT @ravenmaster1: A pair of visiting Egyptian Geese this morning. #toweroflondon https:\/\/t.co\/vW3U4cWJWN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/731032546390228992\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/vW3U4cWJWN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiUmMhbW0AA0KjM.jpg",
        "id_str" : "731032511090970624",
        "id" : 731032511090970624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiUmMhbW0AA0KjM.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vW3U4cWJWN"
      } ],
      "hashtags" : [ {
        "text" : "toweroflondon",
        "indices" : [ 48, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731032546390228992",
    "text" : "A pair of visiting Egyptian Geese this morning. #toweroflondon https:\/\/t.co\/vW3U4cWJWN",
    "id" : 731032546390228992,
    "created_at" : "2016-05-13 08:05:15 +0000",
    "user" : {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "protected" : false,
      "id_str" : "357816281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797910066217291776\/TIbczQ3f_normal.jpg",
      "id" : 357816281,
      "verified" : false
    }
  },
  "id" : 731118128952975361,
  "created_at" : "2016-05-13 13:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INFP Thoughts",
      "screen_name" : "INFP_Thoughts",
      "indices" : [ 3, 17 ],
      "id_str" : "1031965927",
      "id" : 1031965927
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/INFP_Thoughts\/status\/730920124534919168\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/myDDKXEHuF",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiS_uSLWsAER1D0.jpg",
      "id_str" : "730919841415213057",
      "id" : 730919841415213057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiS_uSLWsAER1D0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 244
      } ],
      "display_url" : "pic.twitter.com\/myDDKXEHuF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730936784323006464",
  "text" : "RT @INFP_Thoughts: \"Introverts are boring, what do they even do for fun?\" https:\/\/t.co\/myDDKXEHuF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/INFP_Thoughts\/status\/730920124534919168\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/myDDKXEHuF",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiS_uSLWsAER1D0.jpg",
        "id_str" : "730919841415213057",
        "id" : 730919841415213057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiS_uSLWsAER1D0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 244
        } ],
        "display_url" : "pic.twitter.com\/myDDKXEHuF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730920124534919168",
    "text" : "\"Introverts are boring, what do they even do for fun?\" https:\/\/t.co\/myDDKXEHuF",
    "id" : 730920124534919168,
    "created_at" : "2016-05-13 00:38:32 +0000",
    "user" : {
      "name" : "INFP Thoughts",
      "screen_name" : "INFP_Thoughts",
      "protected" : false,
      "id_str" : "1031965927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738894852654551041\/RkehZdVk_normal.jpg",
      "id" : 1031965927,
      "verified" : false
    }
  },
  "id" : 730936784323006464,
  "created_at" : "2016-05-13 01:44:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730923558315102208",
  "text" : "RT @existentialcoms: I hope they figure out how the brain causes consciousness soon. Then maybe they can finally find a cure.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730920300263538688",
    "text" : "I hope they figure out how the brain causes consciousness soon. Then maybe they can finally find a cure.",
    "id" : 730920300263538688,
    "created_at" : "2016-05-13 00:39:14 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 730923558315102208,
  "created_at" : "2016-05-13 00:52:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "feedly",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/tFIXMDXYJh",
      "expanded_url" : "http:\/\/scripting.com\/2016\/05\/12\/1255.html",
      "display_url" : "scripting.com\/2016\/05\/12\/125\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730893170012102657",
  "text" : "Newsriver howto for publishers https:\/\/t.co\/tFIXMDXYJh #tech #feedly",
  "id" : 730893170012102657,
  "created_at" : "2016-05-12 22:51:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730891168146317313",
  "text" : "RT @_NealeDWalsch: You will not change the world by trying first to change the world. You will change the world by first changing yourself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730880412445229056",
    "text" : "You will not change the world by trying first to change the world. You will change the world by first changing yourself.",
    "id" : 730880412445229056,
    "created_at" : "2016-05-12 22:00:44 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 730891168146317313,
  "created_at" : "2016-05-12 22:43:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "indices" : [ 3, 16 ],
      "id_str" : "2343966982",
      "id" : 2343966982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/mKdLFGdr4G",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/sign-up-to-pose-nude-at-the-republican-national-convention_us_5734bb67e4b08f96c1826b18",
      "display_url" : "huffingtonpost.com\/entry\/sign-up-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730890949925048320",
  "text" : "RT @5thdimdreamz: Sign Up To Pose Nude At The Republican National Convention  https:\/\/t.co\/mKdLFGdr4G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/mKdLFGdr4G",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/sign-up-to-pose-nude-at-the-republican-national-convention_us_5734bb67e4b08f96c1826b18",
        "display_url" : "huffingtonpost.com\/entry\/sign-up-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730887728146071552",
    "text" : "Sign Up To Pose Nude At The Republican National Convention  https:\/\/t.co\/mKdLFGdr4G",
    "id" : 730887728146071552,
    "created_at" : "2016-05-12 22:29:48 +0000",
    "user" : {
      "name" : "\u0AD0\u0D6C\u04BD\u056A\u0268\u0188\u0268\u057C\u025B \u0E2C\u0DA7\u2113\u0493",
      "screen_name" : "5thdimdreamz",
      "protected" : false,
      "id_str" : "2343966982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636369951490711552\/4F0pGlww_normal.jpg",
      "id" : 2343966982,
      "verified" : false
    }
  },
  "id" : 730890949925048320,
  "created_at" : "2016-05-12 22:42:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "730877897486024704",
  "geo" : { },
  "id_str" : "730890473364033536",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 both me and DD #INFP ((fistbump)) we feel ya...",
  "id" : 730890473364033536,
  "in_reply_to_status_id" : 730877897486024704,
  "created_at" : "2016-05-12 22:40:42 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Case",
      "screen_name" : "jessecase",
      "indices" : [ 3, 13 ],
      "id_str" : "24664313",
      "id" : 24664313
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jessecase\/status\/730867421284843520\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/pNahS9Q9iZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiSQB1JXEAEn1Bl.jpg",
      "id_str" : "730867400661471233",
      "id" : 730867400661471233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiSQB1JXEAEn1Bl.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pNahS9Q9iZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730870019941371904",
  "text" : "RT @jessecase: Dude I suck at picking lap dogs. https:\/\/t.co\/pNahS9Q9iZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jessecase\/status\/730867421284843520\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/pNahS9Q9iZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiSQB1JXEAEn1Bl.jpg",
        "id_str" : "730867400661471233",
        "id" : 730867400661471233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiSQB1JXEAEn1Bl.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pNahS9Q9iZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730867421284843520",
    "text" : "Dude I suck at picking lap dogs. https:\/\/t.co\/pNahS9Q9iZ",
    "id" : 730867421284843520,
    "created_at" : "2016-05-12 21:09:06 +0000",
    "user" : {
      "name" : "Jesse Case",
      "screen_name" : "jessecase",
      "protected" : false,
      "id_str" : "24664313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486957095892160513\/b_ho7daM_normal.png",
      "id" : 24664313,
      "verified" : false
    }
  },
  "id" : 730870019941371904,
  "created_at" : "2016-05-12 21:19:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chas",
      "screen_name" : "WobblyCollie",
      "indices" : [ 3, 16 ],
      "id_str" : "1151633636",
      "id" : 1151633636
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WobblyCollie\/status\/730862793591816192\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/8dCIPWIhPD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiSL0xeWsAMksJA.jpg",
      "id_str" : "730862778290974723",
      "id" : 730862778290974723,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiSL0xeWsAMksJA.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8dCIPWIhPD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730869766987120640",
  "text" : "RT @WobblyCollie: Not blinking. Spider on floor....Halp ! https:\/\/t.co\/8dCIPWIhPD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WobblyCollie\/status\/730862793591816192\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/8dCIPWIhPD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiSL0xeWsAMksJA.jpg",
        "id_str" : "730862778290974723",
        "id" : 730862778290974723,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiSL0xeWsAMksJA.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1161,
          "resize" : "fit",
          "w" : 2064
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8dCIPWIhPD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730862793591816192",
    "text" : "Not blinking. Spider on floor....Halp ! https:\/\/t.co\/8dCIPWIhPD",
    "id" : 730862793591816192,
    "created_at" : "2016-05-12 20:50:43 +0000",
    "user" : {
      "name" : "Chas",
      "screen_name" : "WobblyCollie",
      "protected" : false,
      "id_str" : "1151633636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734068929258225664\/7RMqih_j_normal.jpg",
      "id" : 1151633636,
      "verified" : false
    }
  },
  "id" : 730869766987120640,
  "created_at" : "2016-05-12 21:18:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "feedly",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/frQxbj0dlA",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/05\/please-stop-the-war-on-chronic-pain-sufferers\/",
      "display_url" : "brucegerencser.net\/2016\/05\/please\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730537149309849601",
  "text" : "I agree!! &gt; Please Stop the War on Chronic Pain Sufferers https:\/\/t.co\/frQxbj0dlA #religion #feedly #chronicillness",
  "id" : 730537149309849601,
  "created_at" : "2016-05-11 23:16:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/vImmF3YCDB",
      "expanded_url" : "http:\/\/via.fox8.com\/1yHJR",
      "display_url" : "via.fox8.com\/1yHJR"
    } ]
  },
  "geo" : { },
  "id_str" : "730443801307787264",
  "text" : "Mama goose 'hails' police officer to free trapped gosling https:\/\/t.co\/vImmF3YCDB",
  "id" : 730443801307787264,
  "created_at" : "2016-05-11 17:05:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/730046612043665408\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/cuNNVItgOJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiGlhcoWUAAIjtx.jpg",
      "id_str" : "730046608650424320",
      "id" : 730046608650424320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiGlhcoWUAAIjtx.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/cuNNVItgOJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/LO0McwD65c",
      "expanded_url" : "http:\/\/johnpavlovitz.com\/2016\/05\/10\/things-im-doing-before-going-to-hell\/?utm_campaign=coschedule&utm_source=twitter&utm_medium=johnpavlovitz&utm_content=Things+I'm+Doing+Before+Going+to+Hell&_ts=1462891644",
      "display_url" : "johnpavlovitz.com\/2016\/05\/10\/thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730046612043665408",
  "text" : "Things I\u2019m Doing Before Going to Hell https:\/\/t.co\/LO0McwD65c https:\/\/t.co\/cuNNVItgOJ",
  "id" : 730046612043665408,
  "created_at" : "2016-05-10 14:47:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729836968302006273",
  "text" : "RT @petersonguides: WANT TO WIN a copy of any Peterson Field Guide? Check out our photo contest, running now through May 24th!... https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/2UgJLAok9x",
        "expanded_url" : "http:\/\/fb.me\/4KEYplZkj",
        "display_url" : "fb.me\/4KEYplZkj"
      } ]
    },
    "geo" : { },
    "id_str" : "729393686723833857",
    "text" : "WANT TO WIN a copy of any Peterson Field Guide? Check out our photo contest, running now through May 24th!... https:\/\/t.co\/2UgJLAok9x",
    "id" : 729393686723833857,
    "created_at" : "2016-05-08 19:33:01 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 729836968302006273,
  "created_at" : "2016-05-10 00:54:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "indices" : [ 3, 18 ],
      "id_str" : "24254537",
      "id" : 24254537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729830372901564418",
  "text" : "RT @GrumpyTheology: The personal is theological. When we want a Caesar-like God, and simultaneously want to be godly, we end up power-hungry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729826164869505025",
    "text" : "The personal is theological. When we want a Caesar-like God, and simultaneously want to be godly, we end up power-hungry",
    "id" : 729826164869505025,
    "created_at" : "2016-05-10 00:11:31 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 729830372901564418,
  "created_at" : "2016-05-10 00:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "feedly",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/0sMf9dIGb8",
      "expanded_url" : "http:\/\/micahredding.com\/blog\/the-dark-side-of-knowledge",
      "display_url" : "micahredding.com\/blog\/the-dark-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729790510185984000",
  "text" : "interesting &gt; The Dark Side of Knowledge https:\/\/t.co\/0sMf9dIGb8 #religion #feedly",
  "id" : 729790510185984000,
  "created_at" : "2016-05-09 21:49:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/onealexharms\/status\/729726730718609408\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/87LD5zLYRN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCCksBUkAA0g_C.jpg",
      "id_str" : "729726706437623808",
      "id" : 729726706437623808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCCksBUkAA0g_C.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1494,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2261,
        "resize" : "fit",
        "w" : 1550
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/87LD5zLYRN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729788012838662145",
  "text" : "RT @onealexharms: Just a backyard squirrel enjoying his nuts. https:\/\/t.co\/87LD5zLYRN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/onealexharms\/status\/729726730718609408\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/87LD5zLYRN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCCksBUkAA0g_C.jpg",
        "id_str" : "729726706437623808",
        "id" : 729726706437623808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCCksBUkAA0g_C.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 875,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1494,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2261,
          "resize" : "fit",
          "w" : 1550
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/87LD5zLYRN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729726730718609408",
    "text" : "Just a backyard squirrel enjoying his nuts. https:\/\/t.co\/87LD5zLYRN",
    "id" : 729726730718609408,
    "created_at" : "2016-05-09 17:36:24 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 729788012838662145,
  "created_at" : "2016-05-09 21:39:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/729745346906087424\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/c4efZe3v5X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
      "id_str" : "729745345786224640",
      "id" : 729745345786224640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/c4efZe3v5X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/TFWPdFbeBM",
      "expanded_url" : "http:\/\/on.doi.gov\/1Oc7VXg",
      "display_url" : "on.doi.gov\/1Oc7VXg"
    } ]
  },
  "geo" : { },
  "id_str" : "729786349306433536",
  "text" : "RT @Interior: Say hello to our new national mammal: The American bison https:\/\/t.co\/TFWPdFbeBM\nPic by Rich Keen https:\/\/t.co\/c4efZe3v5X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/729745346906087424\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/c4efZe3v5X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
        "id_str" : "729745345786224640",
        "id" : 729745345786224640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/c4efZe3v5X"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/TFWPdFbeBM",
        "expanded_url" : "http:\/\/on.doi.gov\/1Oc7VXg",
        "display_url" : "on.doi.gov\/1Oc7VXg"
      } ]
    },
    "geo" : { },
    "id_str" : "729745346906087424",
    "text" : "Say hello to our new national mammal: The American bison https:\/\/t.co\/TFWPdFbeBM\nPic by Rich Keen https:\/\/t.co\/c4efZe3v5X",
    "id" : 729745346906087424,
    "created_at" : "2016-05-09 18:50:23 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 729786349306433536,
  "created_at" : "2016-05-09 21:33:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aniya Wolf",
      "screen_name" : "AniyaWolf",
      "indices" : [ 3, 13 ],
      "id_str" : "4167125901",
      "id" : 4167125901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/2lBBMs9k7V",
      "expanded_url" : "https:\/\/twitter.com\/i\/moments\/729458405803474944",
      "display_url" : "twitter.com\/i\/moments\/7294\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729684363579957248",
  "text" : "RT @AniyaWolf: \u26A1\uFE0F \u201CStudent dismissed from prom for wearing a suit\u201D\n\nhttps:\/\/t.co\/2lBBMs9k7V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/2lBBMs9k7V",
        "expanded_url" : "https:\/\/twitter.com\/i\/moments\/729458405803474944",
        "display_url" : "twitter.com\/i\/moments\/7294\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729472575370317825",
    "text" : "\u26A1\uFE0F \u201CStudent dismissed from prom for wearing a suit\u201D\n\nhttps:\/\/t.co\/2lBBMs9k7V",
    "id" : 729472575370317825,
    "created_at" : "2016-05-09 00:46:29 +0000",
    "user" : {
      "name" : "Aniya Wolf",
      "screen_name" : "AniyaWolf",
      "protected" : false,
      "id_str" : "4167125901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799478796093194240\/rL9bjzgs_normal.jpg",
      "id" : 4167125901,
      "verified" : true
    }
  },
  "id" : 729684363579957248,
  "created_at" : "2016-05-09 14:48:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "True Nature Fnd",
      "screen_name" : "truenaturefound",
      "indices" : [ 3, 19 ],
      "id_str" : "2362349730",
      "id" : 2362349730
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/truenaturefound\/status\/726129258784034817\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/qsM1ENc2nv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChO6b40XEAQGkFf.jpg",
      "id_str" : "726128953208016900",
      "id" : 726128953208016900,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChO6b40XEAQGkFf.jpg",
      "sizes" : [ {
        "h" : 795,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qsM1ENc2nv"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/truenaturefound\/status\/726129258784034817\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/qsM1ENc2nv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChO6d_zWUAEz3eA.jpg",
      "id_str" : "726128989442560001",
      "id" : 726128989442560001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChO6d_zWUAEz3eA.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qsM1ENc2nv"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/truenaturefound\/status\/726129258784034817\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/qsM1ENc2nv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChO6e5HWgAQc09A.jpg",
      "id_str" : "726129004827279364",
      "id" : 726129004827279364,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChO6e5HWgAQc09A.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/qsM1ENc2nv"
    } ],
    "hashtags" : [ {
      "text" : "Bison",
      "indices" : [ 29, 35 ]
    }, {
      "text" : "reintroduction",
      "indices" : [ 36, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/Dq7WnRh3L4",
      "expanded_url" : "http:\/\/www.truenaturefoundation.org\/latest-news\/largest-bison-reintroduction-ever-in-western-europe",
      "display_url" : "truenaturefoundation.org\/latest-news\/la\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729682204180271105",
  "text" : "RT @truenaturefound: Largest #Bison #reintroduction ever in Western Europe https:\/\/t.co\/Dq7WnRh3L4 https:\/\/t.co\/qsM1ENc2nv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/truenaturefound\/status\/726129258784034817\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/qsM1ENc2nv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChO6b40XEAQGkFf.jpg",
        "id_str" : "726128953208016900",
        "id" : 726128953208016900,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChO6b40XEAQGkFf.jpg",
        "sizes" : [ {
          "h" : 795,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qsM1ENc2nv"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/truenaturefound\/status\/726129258784034817\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/qsM1ENc2nv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChO6d_zWUAEz3eA.jpg",
        "id_str" : "726128989442560001",
        "id" : 726128989442560001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChO6d_zWUAEz3eA.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qsM1ENc2nv"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/truenaturefound\/status\/726129258784034817\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/qsM1ENc2nv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChO6e5HWgAQc09A.jpg",
        "id_str" : "726129004827279364",
        "id" : 726129004827279364,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChO6e5HWgAQc09A.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 795,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/qsM1ENc2nv"
      } ],
      "hashtags" : [ {
        "text" : "Bison",
        "indices" : [ 8, 14 ]
      }, {
        "text" : "reintroduction",
        "indices" : [ 15, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/Dq7WnRh3L4",
        "expanded_url" : "http:\/\/www.truenaturefoundation.org\/latest-news\/largest-bison-reintroduction-ever-in-western-europe",
        "display_url" : "truenaturefoundation.org\/latest-news\/la\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "726129258784034817",
    "text" : "Largest #Bison #reintroduction ever in Western Europe https:\/\/t.co\/Dq7WnRh3L4 https:\/\/t.co\/qsM1ENc2nv",
    "id" : 726129258784034817,
    "created_at" : "2016-04-29 19:21:20 +0000",
    "user" : {
      "name" : "True Nature Fnd",
      "screen_name" : "truenaturefound",
      "protected" : false,
      "id_str" : "2362349730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/438590356699893760\/o568eEeN_normal.jpeg",
      "id" : 2362349730,
      "verified" : false
    }
  },
  "id" : 729682204180271105,
  "created_at" : "2016-05-09 14:39:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rowdy Girl Sanctuary",
      "screen_name" : "RowdyGirlRanch",
      "indices" : [ 3, 18 ],
      "id_str" : "3158431765",
      "id" : 3158431765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/aa5BiKjTzl",
      "expanded_url" : "http:\/\/www.cbsnews.com\/news\/cattle-ranchers-vegan-wife-turns-ranch-into-animal-sanctuary\/",
      "display_url" : "cbsnews.com\/news\/cattle-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729676721226665985",
  "text" : "RT @RowdyGirlRanch: https:\/\/t.co\/aa5BiKjTzl - SOME PEOPLE have still not seem this! Watch!  First beef cattle ranch in the country to conve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/aa5BiKjTzl",
        "expanded_url" : "http:\/\/www.cbsnews.com\/news\/cattle-ranchers-vegan-wife-turns-ranch-into-animal-sanctuary\/",
        "display_url" : "cbsnews.com\/news\/cattle-ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727538876940607488",
    "text" : "https:\/\/t.co\/aa5BiKjTzl - SOME PEOPLE have still not seem this! Watch!  First beef cattle ranch in the country to convert to vegan sanctuary",
    "id" : 727538876940607488,
    "created_at" : "2016-05-03 16:42:39 +0000",
    "user" : {
      "name" : "Rowdy Girl Sanctuary",
      "screen_name" : "RowdyGirlRanch",
      "protected" : false,
      "id_str" : "3158431765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588551764506316800\/lC45sHF__normal.jpg",
      "id" : 3158431765,
      "verified" : false
    }
  },
  "id" : 729676721226665985,
  "created_at" : "2016-05-09 14:17:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523107211950981120\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/zZjzNxErEk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0JzPNEIUAA4QjL.jpg",
      "id_str" : "523107211770613760",
      "id" : 523107211770613760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0JzPNEIUAA4QjL.jpg",
      "sizes" : [ {
        "h" : 482,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/zZjzNxErEk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729483855275692037",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/zZjzNxErEk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523107211950981120\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/zZjzNxErEk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0JzPNEIUAA4QjL.jpg",
        "id_str" : "523107211770613760",
        "id" : 523107211770613760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0JzPNEIUAA4QjL.jpg",
        "sizes" : [ {
          "h" : 482,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/zZjzNxErEk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729465924777037825",
    "text" : "https:\/\/t.co\/zZjzNxErEk",
    "id" : 729465924777037825,
    "created_at" : "2016-05-09 00:20:03 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 729483855275692037,
  "created_at" : "2016-05-09 01:31:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/729475497466433537\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/El8gp0fY25",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch-eGZCWsAApXTZ.jpg",
      "id_str" : "729475497294475264",
      "id" : 729475497294475264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch-eGZCWsAApXTZ.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/El8gp0fY25"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729483575515557888",
  "text" : "RT @SciencePorn: German photographer Birk M\u00F6bius captured a photo of lightning striking a plane inside a rainbow. https:\/\/t.co\/El8gp0fY25",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/729475497466433537\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/El8gp0fY25",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch-eGZCWsAApXTZ.jpg",
        "id_str" : "729475497294475264",
        "id" : 729475497294475264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch-eGZCWsAApXTZ.jpg",
        "sizes" : [ {
          "h" : 381,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/El8gp0fY25"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729475497466433537",
    "text" : "German photographer Birk M\u00F6bius captured a photo of lightning striking a plane inside a rainbow. https:\/\/t.co\/El8gp0fY25",
    "id" : 729475497466433537,
    "created_at" : "2016-05-09 00:58:06 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 729483575515557888,
  "created_at" : "2016-05-09 01:30:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/Z1VDl4lqeN",
      "expanded_url" : "https:\/\/twitter.com\/AtheistEngineer\/status\/728688718744268800",
      "display_url" : "twitter.com\/AtheistEnginee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729454850505846784",
  "text" : "ohh.. very cool. https:\/\/t.co\/Z1VDl4lqeN",
  "id" : 729454850505846784,
  "created_at" : "2016-05-08 23:36:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 3, 16 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729315661361643520",
  "text" : "RT @AudioBookRev: Putting together this Tuesday's #audiobook new release post. There is still time to get yours featured",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "audiobook",
        "indices" : [ 32, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729145544803672065",
    "text" : "Putting together this Tuesday's #audiobook new release post. There is still time to get yours featured",
    "id" : 729145544803672065,
    "created_at" : "2016-05-08 03:06:59 +0000",
    "user" : {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "protected" : false,
      "id_str" : "457997266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740455024\/avatar_normal.png",
      "id" : 457997266,
      "verified" : false
    }
  },
  "id" : 729315661361643520,
  "created_at" : "2016-05-08 14:22:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "indices" : [ 3, 14 ],
      "id_str" : "548388698",
      "id" : 548388698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/njgyuWd83q",
      "expanded_url" : "http:\/\/nzzl.us\/jIOxm4s",
      "display_url" : "nzzl.us\/jIOxm4s"
    } ]
  },
  "geo" : { },
  "id_str" : "729315381085622272",
  "text" : "RT @JohnUmland: Ivy League economist ethnically profiled, interrogated for doing math on American Airlines flight https:\/\/t.co\/njgyuWd83q v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/nuzzel.com\/\" rel=\"nofollow\"\u003ENuzzel\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nuzzel",
        "screen_name" : "nuzzel",
        "indices" : [ 126, 133 ],
        "id_str" : "106041193",
        "id" : 106041193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/njgyuWd83q",
        "expanded_url" : "http:\/\/nzzl.us\/jIOxm4s",
        "display_url" : "nzzl.us\/jIOxm4s"
      } ]
    },
    "geo" : { },
    "id_str" : "729288681324990464",
    "text" : "Ivy League economist ethnically profiled, interrogated for doing math on American Airlines flight https:\/\/t.co\/njgyuWd83q via @nuzzel",
    "id" : 729288681324990464,
    "created_at" : "2016-05-08 12:35:45 +0000",
    "user" : {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "protected" : false,
      "id_str" : "548388698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797536354452340736\/6SfqJlHp_normal.jpg",
      "id" : 548388698,
      "verified" : false
    }
  },
  "id" : 729315381085622272,
  "created_at" : "2016-05-08 14:21:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/729293491008897024\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/n5eF3DpLHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch74kKuU4AElHHW.jpg",
      "id_str" : "729293489918238721",
      "id" : 729293489918238721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch74kKuU4AElHHW.jpg",
      "sizes" : [ {
        "h" : 2284,
        "resize" : "fit",
        "w" : 2033
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n5eF3DpLHb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729315191704391681",
  "text" : "RT @ChippyCMunk: and a little contemplation before the next snack https:\/\/t.co\/n5eF3DpLHb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/729293491008897024\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/n5eF3DpLHb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch74kKuU4AElHHW.jpg",
        "id_str" : "729293489918238721",
        "id" : 729293489918238721,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch74kKuU4AElHHW.jpg",
        "sizes" : [ {
          "h" : 2284,
          "resize" : "fit",
          "w" : 2033
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1150,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/n5eF3DpLHb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729293491008897024",
    "text" : "and a little contemplation before the next snack https:\/\/t.co\/n5eF3DpLHb",
    "id" : 729293491008897024,
    "created_at" : "2016-05-08 12:54:52 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 729315191704391681,
  "created_at" : "2016-05-08 14:21:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dragons",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729315076835020801",
  "text" : "RT @BrianRathbone: Animal Control? You're gonna need a bigger truck. #dragons",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dragons",
        "indices" : [ 50, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729314537632104453",
    "text" : "Animal Control? You're gonna need a bigger truck. #dragons",
    "id" : 729314537632104453,
    "created_at" : "2016-05-08 14:18:30 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 729315076835020801,
  "created_at" : "2016-05-08 14:20:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/t7psvuebjS",
      "expanded_url" : "https:\/\/www.overdrive.com\/search?q=The+Last+Theorem",
      "display_url" : "overdrive.com\/search?q=The+L\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729151301150507008",
  "text" : "I finished \"The Last Theorem\" by Arthur C. Clarke. Find this &amp; more at https:\/\/t.co\/t7psvuebjS. #audiobook",
  "id" : 729151301150507008,
  "created_at" : "2016-05-08 03:29:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729111637089779713",
  "text" : "me: (frustrated) \" I give up.\" DD: That's ok, Mom. Give up today. Stand back up tomorrow.\"",
  "id" : 729111637089779713,
  "created_at" : "2016-05-08 00:52:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/lFd8CKwXvN",
      "expanded_url" : "https:\/\/twitter.com\/WellPlated\/status\/729055746869108739",
      "display_url" : "twitter.com\/WellPlated\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729056338920275969",
  "text" : "((drools)) these look very yum! https:\/\/t.co\/lFd8CKwXvN",
  "id" : 729056338920275969,
  "created_at" : "2016-05-07 21:12:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Burton",
      "screen_name" : "AmitayusX",
      "indices" : [ 3, 13 ],
      "id_str" : "3283778658",
      "id" : 3283778658
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AmitayusX\/status\/729049967336116224\/photo\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/cAhTi7uN3h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4bE8zVEAAqqB9.jpg",
      "id_str" : "729049961535442944",
      "id" : 729049961535442944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4bE8zVEAAqqB9.jpg",
      "sizes" : [ {
        "h" : 496,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cAhTi7uN3h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729051610261950464",
  "text" : "RT @AmitayusX: https:\/\/t.co\/cAhTi7uN3h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmitayusX\/status\/729049967336116224\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/cAhTi7uN3h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4bE8zVEAAqqB9.jpg",
        "id_str" : "729049961535442944",
        "id" : 729049961535442944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4bE8zVEAAqqB9.jpg",
        "sizes" : [ {
          "h" : 496,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cAhTi7uN3h"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729049967336116224",
    "text" : "https:\/\/t.co\/cAhTi7uN3h",
    "id" : 729049967336116224,
    "created_at" : "2016-05-07 20:47:11 +0000",
    "user" : {
      "name" : "Phil Burton",
      "screen_name" : "AmitayusX",
      "protected" : false,
      "id_str" : "3283778658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793404694114689024\/aRQWvLhF_normal.jpg",
      "id" : 3283778658,
      "verified" : false
    }
  },
  "id" : 729051610261950464,
  "created_at" : "2016-05-07 20:53:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/729039215552516097\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/7YwCn6NuD8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4RSHvWEAAQxh8.jpg",
      "id_str" : "729039192693542912",
      "id" : 729039192693542912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4RSHvWEAAQxh8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 645
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 443,
        "resize" : "fit",
        "w" : 645
      } ],
      "display_url" : "pic.twitter.com\/7YwCn6NuD8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/729039215552516097\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/7YwCn6NuD8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4RTXPWkAAvbMZ.jpg",
      "id_str" : "729039214034194432",
      "id" : 729039214034194432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4RTXPWkAAvbMZ.jpg",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 653
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7YwCn6NuD8"
    } ],
    "hashtags" : [ {
      "text" : "CDWG",
      "indices" : [ 37, 42 ]
    }, {
      "text" : "Hedgehogs",
      "indices" : [ 64, 74 ]
    }, {
      "text" : "Livecams",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "CheshiresWildlife",
      "indices" : [ 85, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729051478883766281",
  "text" : "RT @CamoDave_: Mr Big feeding in the #CDWG early hours 7\/5\/2016 #Hedgehogs #Livecams #CheshiresWildlife https:\/\/t.co\/7YwCn6NuD8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/729039215552516097\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/7YwCn6NuD8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4RSHvWEAAQxh8.jpg",
        "id_str" : "729039192693542912",
        "id" : 729039192693542912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4RSHvWEAAQxh8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 645
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 443,
          "resize" : "fit",
          "w" : 645
        } ],
        "display_url" : "pic.twitter.com\/7YwCn6NuD8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/729039215552516097\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/7YwCn6NuD8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4RTXPWkAAvbMZ.jpg",
        "id_str" : "729039214034194432",
        "id" : 729039214034194432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4RTXPWkAAvbMZ.jpg",
        "sizes" : [ {
          "h" : 459,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 653
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7YwCn6NuD8"
      } ],
      "hashtags" : [ {
        "text" : "CDWG",
        "indices" : [ 22, 27 ]
      }, {
        "text" : "Hedgehogs",
        "indices" : [ 49, 59 ]
      }, {
        "text" : "Livecams",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "CheshiresWildlife",
        "indices" : [ 70, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729039215552516097",
    "text" : "Mr Big feeding in the #CDWG early hours 7\/5\/2016 #Hedgehogs #Livecams #CheshiresWildlife https:\/\/t.co\/7YwCn6NuD8",
    "id" : 729039215552516097,
    "created_at" : "2016-05-07 20:04:28 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 729051478883766281,
  "created_at" : "2016-05-07 20:53:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 3, 12 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/729044038054236160\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/PvEdBaB22e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4VsFTXAAEhUrG.jpg",
      "id_str" : "729044036762402817",
      "id" : 729044036762402817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4VsFTXAAEhUrG.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 861,
        "resize" : "fit",
        "w" : 1296
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PvEdBaB22e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729051248977166336",
  "text" : "RT @BobTarte: A squirrel climbing a tree suddenly turns into the tree. So sad. https:\/\/t.co\/PvEdBaB22e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/729044038054236160\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/PvEdBaB22e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4VsFTXAAEhUrG.jpg",
        "id_str" : "729044036762402817",
        "id" : 729044036762402817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4VsFTXAAEhUrG.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 861,
          "resize" : "fit",
          "w" : 1296
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PvEdBaB22e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729044038054236160",
    "text" : "A squirrel climbing a tree suddenly turns into the tree. So sad. https:\/\/t.co\/PvEdBaB22e",
    "id" : 729044038054236160,
    "created_at" : "2016-05-07 20:23:38 +0000",
    "user" : {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "protected" : false,
      "id_str" : "490591746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570578729\/6y9pn9ap800am8pkqsku_normal.jpeg",
      "id" : 490591746,
      "verified" : false
    }
  },
  "id" : 729051248977166336,
  "created_at" : "2016-05-07 20:52:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thyroid & Hashimotos",
      "screen_name" : "OutsmartDisease",
      "indices" : [ 3, 19 ],
      "id_str" : "254768478",
      "id" : 254768478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hormones",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "hypothyroidism",
      "indices" : [ 105, 120 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729050850111438850",
  "text" : "RT @OutsmartDisease: Imbalances of adrenals and sex #hormones can produce symptoms identical to those of #hypothyroidism and #hashimotos #t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hormones",
        "indices" : [ 31, 40 ]
      }, {
        "text" : "hypothyroidism",
        "indices" : [ 84, 99 ]
      }, {
        "text" : "hashimotos",
        "indices" : [ 104, 115 ]
      }, {
        "text" : "thyroid",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "autoimmune",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729046963455463426",
    "text" : "Imbalances of adrenals and sex #hormones can produce symptoms identical to those of #hypothyroidism and #hashimotos #thyroid #autoimmune",
    "id" : 729046963455463426,
    "created_at" : "2016-05-07 20:35:15 +0000",
    "user" : {
      "name" : "Thyroid & Hashimotos",
      "screen_name" : "OutsmartDisease",
      "protected" : false,
      "id_str" : "254768478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611733876688314368\/Sg41xZSU_normal.jpg",
      "id" : 254768478,
      "verified" : false
    }
  },
  "id" : 729050850111438850,
  "created_at" : "2016-05-07 20:50:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferritin",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729040771135983618",
  "text" : "#ferritin : 28 (10-154ng\/ml) on july 7 then.. 21 (10-291ng\/ml) on sept 30 .. does wider range mean drop is not as significant?",
  "id" : 729040771135983618,
  "created_at" : "2016-05-07 20:10:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Fish and Wildlife",
      "screen_name" : "USFWS",
      "indices" : [ 3, 9 ],
      "id_str" : "57625403",
      "id" : 57625403
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USFWS\/status\/729031037112586241\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/yHIeiMwxj0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4J3YaUgAAtdta.jpg",
      "id_str" : "729031036730900480",
      "id" : 729031036730900480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4J3YaUgAAtdta.jpg",
      "sizes" : [ {
        "h" : 769,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1537,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yHIeiMwxj0"
    } ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729039328807165952",
  "text" : "RT @USFWS: We're getting ready to fawn over moms tomorrow. #MothersDay https:\/\/t.co\/yHIeiMwxj0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USFWS\/status\/729031037112586241\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/yHIeiMwxj0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch4J3YaUgAAtdta.jpg",
        "id_str" : "729031036730900480",
        "id" : 729031036730900480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch4J3YaUgAAtdta.jpg",
        "sizes" : [ {
          "h" : 769,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1537,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yHIeiMwxj0"
      } ],
      "hashtags" : [ {
        "text" : "MothersDay",
        "indices" : [ 48, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729031037112586241",
    "text" : "We're getting ready to fawn over moms tomorrow. #MothersDay https:\/\/t.co\/yHIeiMwxj0",
    "id" : 729031037112586241,
    "created_at" : "2016-05-07 19:31:58 +0000",
    "user" : {
      "name" : "US Fish and Wildlife",
      "screen_name" : "USFWS",
      "protected" : false,
      "id_str" : "57625403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476357561268969473\/sFkAJc7o_normal.jpeg",
      "id" : 57625403,
      "verified" : true
    }
  },
  "id" : 729039328807165952,
  "created_at" : "2016-05-07 20:04:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doesntworkwell",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729013007288832000",
  "text" : "RT @fairlyspiritual: \"Let me tell you how to view things.\" #doesntworkwell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "doesntworkwell",
        "indices" : [ 38, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729011561562431488",
    "text" : "\"Let me tell you how to view things.\" #doesntworkwell",
    "id" : 729011561562431488,
    "created_at" : "2016-05-07 18:14:35 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 729013007288832000,
  "created_at" : "2016-05-07 18:20:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doesntworkwell",
      "indices" : [ 52, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729012900677980161",
  "text" : "RT @fairlyspiritual: \"Let me tell you how to feel.\" #doesntworkwell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "doesntworkwell",
        "indices" : [ 31, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "729011756492709888",
    "text" : "\"Let me tell you how to feel.\" #doesntworkwell",
    "id" : 729011756492709888,
    "created_at" : "2016-05-07 18:15:21 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 729012900677980161,
  "created_at" : "2016-05-07 18:19:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728985861115793409",
  "geo" : { },
  "id_str" : "728992030962126848",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe im always telling dh he must have been very, very bad in a past life to get stuck w me. ( hm, doesnt quite relate but..)",
  "id" : 728992030962126848,
  "in_reply_to_status_id" : 728985861115793409,
  "created_at" : "2016-05-07 16:56:58 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "indices" : [ 3, 14 ],
      "id_str" : "2236808551",
      "id" : 2236808551
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JenLRPhoto\/status\/727605343019249664\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/PCwR3PoxEI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chj5Lz2WMAAmsBq.jpg",
      "id_str" : "727605321112367104",
      "id" : 727605321112367104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chj5Lz2WMAAmsBq.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      } ],
      "display_url" : "pic.twitter.com\/PCwR3PoxEI"
    } ],
    "hashtags" : [ {
      "text" : "woodpecker",
      "indices" : [ 22, 33 ]
    }, {
      "text" : "photography",
      "indices" : [ 47, 59 ]
    }, {
      "text" : "birds",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "birding",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "nature",
      "indices" : [ 76, 83 ]
    }, {
      "text" : "canon",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728991367922364417",
  "text" : "RT @JenLRPhoto: Downy #woodpecker in my tree \uD83D\uDE0A #photography #birds #birding #nature #canon \uD83D\uDCF7 https:\/\/t.co\/PCwR3PoxEI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JenLRPhoto\/status\/727605343019249664\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/PCwR3PoxEI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Chj5Lz2WMAAmsBq.jpg",
        "id_str" : "727605321112367104",
        "id" : 727605321112367104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chj5Lz2WMAAmsBq.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/PCwR3PoxEI"
      } ],
      "hashtags" : [ {
        "text" : "woodpecker",
        "indices" : [ 6, 17 ]
      }, {
        "text" : "photography",
        "indices" : [ 31, 43 ]
      }, {
        "text" : "birds",
        "indices" : [ 44, 50 ]
      }, {
        "text" : "birding",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "nature",
        "indices" : [ 60, 67 ]
      }, {
        "text" : "canon",
        "indices" : [ 68, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727605343019249664",
    "text" : "Downy #woodpecker in my tree \uD83D\uDE0A #photography #birds #birding #nature #canon \uD83D\uDCF7 https:\/\/t.co\/PCwR3PoxEI",
    "id" : 727605343019249664,
    "created_at" : "2016-05-03 21:06:46 +0000",
    "user" : {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "protected" : false,
      "id_str" : "2236808551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916989995909120\/ZPqHp6yp_normal.jpg",
      "id" : 2236808551,
      "verified" : false
    }
  },
  "id" : 728991367922364417,
  "created_at" : "2016-05-07 16:54:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.producthunt.com\" rel=\"nofollow\"\u003EProduct Hunt\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Newman",
      "screen_name" : "mjnewman",
      "indices" : [ 95, 104 ],
      "id_str" : "5544362",
      "id" : 5544362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/728987478372274176\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/UVyhAlwW0O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3iP75WwAECWUA.jpg",
      "id_str" : "728987478108061697",
      "id" : 728987478108061697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3iP75WwAECWUA.jpg",
      "sizes" : [ {
        "h" : 493,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/UVyhAlwW0O"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/WcQmXO5jql",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/list-bot",
      "display_url" : "producthunt.com\/tech\/list-bot"
    } ]
  },
  "geo" : { },
  "id_str" : "728987478372274176",
  "text" : "ok this is cool. try it. &gt; List Bot: An SMS bot for to-do lists https:\/\/t.co\/WcQmXO5jql via @mjnewman https:\/\/t.co\/UVyhAlwW0O",
  "id" : 728987478372274176,
  "created_at" : "2016-05-07 16:38:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728945495062806528",
  "geo" : { },
  "id_str" : "728976392566747136",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 : ((",
  "id" : 728976392566747136,
  "in_reply_to_status_id" : 728945495062806528,
  "created_at" : "2016-05-07 15:54:50 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kentuckyderby",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728974496787529728",
  "text" : "RT @dwaynereaves: The two Tennessee Walkers will not be running for the Roses, but they need attention also, right? #kentuckyderby https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/728926925972967424\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/xMhBedJHjp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch2q9WuWEAE4cno.jpg",
        "id_str" : "728926685752594433",
        "id" : 728926685752594433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch2q9WuWEAE4cno.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/xMhBedJHjp"
      } ],
      "hashtags" : [ {
        "text" : "kentuckyderby",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728926925972967424",
    "text" : "The two Tennessee Walkers will not be running for the Roses, but they need attention also, right? #kentuckyderby https:\/\/t.co\/xMhBedJHjp",
    "id" : 728926925972967424,
    "created_at" : "2016-05-07 12:38:16 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 728974496787529728,
  "created_at" : "2016-05-07 15:47:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/zZ5WWtX1f2",
      "expanded_url" : "https:\/\/twitter.com\/milesjreed\/status\/728929561862393856",
      "display_url" : "twitter.com\/milesjreed\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728973731566063616",
  "text" : "TRUTHTRUTHTRUTH https:\/\/t.co\/zZ5WWtX1f2",
  "id" : 728973731566063616,
  "created_at" : "2016-05-07 15:44:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728963856207224832",
  "geo" : { },
  "id_str" : "728972806969528320",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ((claps)) ((confetti))",
  "id" : 728972806969528320,
  "in_reply_to_status_id" : 728963856207224832,
  "created_at" : "2016-05-07 15:40:35 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "indices" : [ 3, 17 ],
      "id_str" : "555307309",
      "id" : 555307309
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TA",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728971864433958912",
  "text" : "RT @takecareofUUU: If U want to be Happy spread Positivity Everyday. Positive Words &amp; Actions change people's lives including yours.#TA htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/takecareofUUU\/status\/728950772881358848\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/2SWnQB9fOl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3A3V8WsAAIo6U.jpg",
        "id_str" : "728950771719516160",
        "id" : 728950771719516160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3A3V8WsAAIo6U.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2SWnQB9fOl"
      } ],
      "hashtags" : [ {
        "text" : "TA",
        "indices" : [ 117, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728950772881358848",
    "text" : "If U want to be Happy spread Positivity Everyday. Positive Words &amp; Actions change people's lives including yours.#TA https:\/\/t.co\/2SWnQB9fOl",
    "id" : 728950772881358848,
    "created_at" : "2016-05-07 14:13:02 +0000",
    "user" : {
      "name" : "Terry Alex",
      "screen_name" : "takecareofUUU",
      "protected" : false,
      "id_str" : "555307309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537254454949445634\/7uw1omdM_normal.jpeg",
      "id" : 555307309,
      "verified" : false
    }
  },
  "id" : 728971864433958912,
  "created_at" : "2016-05-07 15:36:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Incredible Pics",
      "screen_name" : "incredibleviews",
      "indices" : [ 3, 19 ],
      "id_str" : "126990459",
      "id" : 126990459
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/incredibleviews\/status\/728965131988807681\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/ggweY4ZT5S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3N7BkXIAAhEsF.jpg",
      "id_str" : "728965128620810240",
      "id" : 728965128620810240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3N7BkXIAAhEsF.jpg",
      "sizes" : [ {
        "h" : 741,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 790,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 790,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ggweY4ZT5S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728971593683210242",
  "text" : "RT @incredibleviews: This must be what the entrance to heaven looks like https:\/\/t.co\/ggweY4ZT5S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/incredibleviews\/status\/728965131988807681\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/ggweY4ZT5S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3N7BkXIAAhEsF.jpg",
        "id_str" : "728965128620810240",
        "id" : 728965128620810240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3N7BkXIAAhEsF.jpg",
        "sizes" : [ {
          "h" : 741,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ggweY4ZT5S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728965131988807681",
    "text" : "This must be what the entrance to heaven looks like https:\/\/t.co\/ggweY4ZT5S",
    "id" : 728965131988807681,
    "created_at" : "2016-05-07 15:10:05 +0000",
    "user" : {
      "name" : "Incredible Pics",
      "screen_name" : "incredibleviews",
      "protected" : false,
      "id_str" : "126990459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717222241616965633\/Xao0l2X-_normal.jpg",
      "id" : 126990459,
      "verified" : false
    }
  },
  "id" : 728971593683210242,
  "created_at" : "2016-05-07 15:35:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/tAINFsaCUO",
      "expanded_url" : "https:\/\/twitter.com\/TheGoldenMirror\/status\/728791263630245889",
      "display_url" : "twitter.com\/TheGoldenMirro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728946226020888576",
  "text" : "hmm.. ponders this as it relates to me. https:\/\/t.co\/tAINFsaCUO",
  "id" : 728946226020888576,
  "created_at" : "2016-05-07 13:54:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Fine Art America",
      "screen_name" : "FineArtAmerica",
      "indices" : [ 81, 96 ],
      "id_str" : "16828262",
      "id" : 16828262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/728746142897340416\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/qWeJb5Qkqv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch0GwV4VEAAA87b.jpg",
      "id_str" : "728746142280781824",
      "id" : 728746142280781824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch0GwV4VEAAA87b.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qWeJb5Qkqv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/zxGRGohnYc",
      "expanded_url" : "http:\/\/fineartamerica.com\/featured\/may-sunset-dwayne-reaves.html",
      "display_url" : "fineartamerica.com\/featured\/may-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728746533043179521",
  "text" : "RT @dwaynereaves: New artwork for sale! - \"May Sunset\" - https:\/\/t.co\/zxGRGohnYc @fineartamerica https:\/\/t.co\/qWeJb5Qkqv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/fineartamerica.com\" rel=\"nofollow\"\u003EFine Art America\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fine Art America",
        "screen_name" : "FineArtAmerica",
        "indices" : [ 63, 78 ],
        "id_str" : "16828262",
        "id" : 16828262
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/728746142897340416\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/qWeJb5Qkqv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch0GwV4VEAAA87b.jpg",
        "id_str" : "728746142280781824",
        "id" : 728746142280781824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch0GwV4VEAAA87b.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qWeJb5Qkqv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/zxGRGohnYc",
        "expanded_url" : "http:\/\/fineartamerica.com\/featured\/may-sunset-dwayne-reaves.html",
        "display_url" : "fineartamerica.com\/featured\/may-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728746142897340416",
    "text" : "New artwork for sale! - \"May Sunset\" - https:\/\/t.co\/zxGRGohnYc @fineartamerica https:\/\/t.co\/qWeJb5Qkqv",
    "id" : 728746142897340416,
    "created_at" : "2016-05-07 00:39:54 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 728746533043179521,
  "created_at" : "2016-05-07 00:41:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "feedly",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/6jqXzYyc6w",
      "expanded_url" : "http:\/\/samanthapfield.com\/2016\/05\/06\/feminism-american-exceptionalism\/",
      "display_url" : "samanthapfield.com\/2016\/05\/06\/fem\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728744057124626432",
  "text" : "feminism and American exceptionalism https:\/\/t.co\/6jqXzYyc6w #religion #feedly",
  "id" : 728744057124626432,
  "created_at" : "2016-05-07 00:31:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728737381239693313",
  "text" : "DD: \"its like sharing with a sibling.. who's ocd.. and neurotic.\" re: sharing a room w me.",
  "id" : 728737381239693313,
  "created_at" : "2016-05-07 00:05:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728734209561526272",
  "geo" : { },
  "id_str" : "728736810470412289",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 (((hugs)))",
  "id" : 728736810470412289,
  "in_reply_to_status_id" : 728734209561526272,
  "created_at" : "2016-05-07 00:02:49 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/HboKt73eVl",
      "expanded_url" : "http:\/\/www.rawstory.com\/2016\/05\/prince-did-not-die-from-pain-pills-he-died-from-chronic-pain\/",
      "display_url" : "rawstory.com\/2016\/05\/prince\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728687690187714561",
  "text" : "Prince did not die from pain pills \u2014 he died from chronic pain https:\/\/t.co\/HboKt73eVl",
  "id" : 728687690187714561,
  "created_at" : "2016-05-06 20:47:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/G7b5s83132",
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/728554634004963330",
      "display_url" : "twitter.com\/ErinEFarley\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728582900325752833",
  "text" : "wisdom &gt; \"meet them where they are\" &lt; regarding science, religion, politics.. anything. https:\/\/t.co\/G7b5s83132",
  "id" : 728582900325752833,
  "created_at" : "2016-05-06 13:51:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728579496148897793",
  "text" : "RT @TheGoldenMirror: A mind is not free as long as it's restricted by the convictions it keeps. Learn to look beyond your interpretations o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728576627752448000",
    "text" : "A mind is not free as long as it's restricted by the convictions it keeps. Learn to look beyond your interpretations of reality.",
    "id" : 728576627752448000,
    "created_at" : "2016-05-06 13:26:19 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 728579496148897793,
  "created_at" : "2016-05-06 13:37:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 112, 121 ]
    }, {
      "text" : "feedly",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/WmtKkv5KtI",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/nolongerquivering\/2016\/05\/duggar-cult-founder-plans-kansas-retreat-to-set-up-arranged-marriages-for-teen-girls\/",
      "display_url" : "patheos.com\/blogs\/nolonger\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728224155448037384",
  "text" : "makes me want to puke &gt; Kansas \u2018Retreat\u2019 to Set Up Arranged Marriages For Teen Girls https:\/\/t.co\/WmtKkv5KtI #religion #feedly",
  "id" : 728224155448037384,
  "created_at" : "2016-05-05 14:05:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "software",
      "indices" : [ 7, 16 ]
    }, {
      "text" : "medical",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728014689649733632",
  "text" : "i NEED #software that i can track #medical visits and lab values. i have spreadsheets but they dont work so well for me.",
  "id" : 728014689649733632,
  "created_at" : "2016-05-05 00:13:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beauty",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "spring",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "trees",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "awe",
      "indices" : [ 111, 115 ]
    }, {
      "text" : "gratitude",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728013781763272704",
  "text" : "RT @wildwitchyju: Greeting the trees as they dance with delight in the spring sunshine. #beauty #spring #trees #awe #gratitude https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/728003647876038658\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/f7Yd4TwAHd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChpjdWSWUAAjYT9.jpg",
        "id_str" : "728003645623652352",
        "id" : 728003645623652352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChpjdWSWUAAjYT9.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2592,
          "resize" : "fit",
          "w" : 3456
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/f7Yd4TwAHd"
      } ],
      "hashtags" : [ {
        "text" : "beauty",
        "indices" : [ 70, 77 ]
      }, {
        "text" : "spring",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "trees",
        "indices" : [ 86, 92 ]
      }, {
        "text" : "awe",
        "indices" : [ 93, 97 ]
      }, {
        "text" : "gratitude",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728003647876038658",
    "text" : "Greeting the trees as they dance with delight in the spring sunshine. #beauty #spring #trees #awe #gratitude https:\/\/t.co\/f7Yd4TwAHd",
    "id" : 728003647876038658,
    "created_at" : "2016-05-04 23:29:29 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 728013781763272704,
  "created_at" : "2016-05-05 00:09:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AP South U.S. Region",
      "screen_name" : "APSouthRegion",
      "indices" : [ 3, 17 ],
      "id_str" : "4114441180",
      "id" : 4114441180
    }, {
      "name" : "The News & Observer",
      "screen_name" : "newsobserver",
      "indices" : [ 74, 87 ],
      "id_str" : "8942262",
      "id" : 8942262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727990789557657600",
  "text" : "RT @APSouthRegion: North Carolina jail surveillance footage, uncovered by @newsobserver, shows shackled inmate's death by Taser. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The News & Observer",
        "screen_name" : "newsobserver",
        "indices" : [ 55, 68 ],
        "id_str" : "8942262",
        "id" : 8942262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/MSyN99CLzT",
        "expanded_url" : "http:\/\/www.newsobserver.com\/news\/local\/crime\/article75138592.html",
        "display_url" : "newsobserver.com\/news\/local\/cri\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727511350860206080",
    "text" : "North Carolina jail surveillance footage, uncovered by @newsobserver, shows shackled inmate's death by Taser. https:\/\/t.co\/MSyN99CLzT",
    "id" : 727511350860206080,
    "created_at" : "2016-05-03 14:53:17 +0000",
    "user" : {
      "name" : "AP South U.S. Region",
      "screen_name" : "APSouthRegion",
      "protected" : false,
      "id_str" : "4114441180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661999897588072448\/2xFhakP-_normal.png",
      "id" : 4114441180,
      "verified" : true
    }
  },
  "id" : 727990789557657600,
  "created_at" : "2016-05-04 22:38:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Wes Hohenstein",
      "screen_name" : "WeatherWes",
      "indices" : [ 74, 85 ],
      "id_str" : "19739695",
      "id" : 19739695
    }, {
      "name" : "Alyssa Corfont",
      "screen_name" : "weatherAC",
      "indices" : [ 86, 96 ],
      "id_str" : "105675677",
      "id" : 105675677
    }, {
      "name" : "WNCN",
      "screen_name" : "WNCN",
      "indices" : [ 97, 102 ],
      "id_str" : "2861771",
      "id" : 2861771
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/727661583615307777\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/UHY1IbNI5j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChksWo2W0AI7wlr.jpg",
      "id_str" : "727661582231195650",
      "id" : 727661582231195650,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChksWo2W0AI7wlr.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UHY1IbNI5j"
    } ],
    "hashtags" : [ {
      "text" : "ncwx",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "weather",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727666585524121601",
  "text" : "RT @dwaynereaves: The sunset tonight here in Person County #ncwx #weather @WeatherWes @weatherAC @WNCN https:\/\/t.co\/UHY1IbNI5j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wes Hohenstein",
        "screen_name" : "WeatherWes",
        "indices" : [ 56, 67 ],
        "id_str" : "19739695",
        "id" : 19739695
      }, {
        "name" : "Alyssa Corfont",
        "screen_name" : "weatherAC",
        "indices" : [ 68, 78 ],
        "id_str" : "105675677",
        "id" : 105675677
      }, {
        "name" : "WNCN",
        "screen_name" : "WNCN",
        "indices" : [ 79, 84 ],
        "id_str" : "2861771",
        "id" : 2861771
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/727661583615307777\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/UHY1IbNI5j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChksWo2W0AI7wlr.jpg",
        "id_str" : "727661582231195650",
        "id" : 727661582231195650,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChksWo2W0AI7wlr.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/UHY1IbNI5j"
      } ],
      "hashtags" : [ {
        "text" : "ncwx",
        "indices" : [ 41, 46 ]
      }, {
        "text" : "weather",
        "indices" : [ 47, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727661583615307777",
    "text" : "The sunset tonight here in Person County #ncwx #weather @WeatherWes @weatherAC @WNCN https:\/\/t.co\/UHY1IbNI5j",
    "id" : 727661583615307777,
    "created_at" : "2016-05-04 00:50:15 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 727666585524121601,
  "created_at" : "2016-05-04 01:10:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "indices" : [ 0, 11 ],
      "id_str" : "548388698",
      "id" : 548388698
    }, {
      "name" : "Nuzzel",
      "screen_name" : "nuzzel",
      "indices" : [ 12, 19 ],
      "id_str" : "106041193",
      "id" : 106041193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727658533244833792",
  "geo" : { },
  "id_str" : "727661765513904128",
  "in_reply_to_user_id" : 548388698,
  "text" : "@JohnUmland @nuzzel you can almost see the righteousness smoking up the room. gah.",
  "id" : 727661765513904128,
  "in_reply_to_status_id" : 727658533244833792,
  "created_at" : "2016-05-04 00:50:58 +0000",
  "in_reply_to_screen_name" : "JohnUmland",
  "in_reply_to_user_id_str" : "548388698",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikey Franklin",
      "screen_name" : "mikeyfranklin",
      "indices" : [ 3, 17 ],
      "id_str" : "102036068",
      "id" : 102036068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727660471919226880",
  "text" : "RT @mikeyfranklin: What a time to be alive.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727659475394560000",
    "text" : "What a time to be alive.",
    "id" : 727659475394560000,
    "created_at" : "2016-05-04 00:41:52 +0000",
    "user" : {
      "name" : "Mikey Franklin",
      "screen_name" : "mikeyfranklin",
      "protected" : false,
      "id_str" : "102036068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674270676270891008\/0hVYztyO_normal.jpg",
      "id" : 102036068,
      "verified" : false
    }
  },
  "id" : 727660471919226880,
  "created_at" : "2016-05-04 00:45:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "hypothyroid",
      "indices" : [ 87, 99 ]
    }, {
      "text" : "lowferritin",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727650532089856000",
  "text" : "DD needs a general supplement and iron supplement. small pills. any ideas? #hashimotos #hypothyroid #lowferritin",
  "id" : 727650532089856000,
  "created_at" : "2016-05-04 00:06:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/rm06c4PcCY",
      "expanded_url" : "http:\/\/hiddenmahala.blogspot.com",
      "display_url" : "hiddenmahala.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "727630160615383040",
  "text" : "RT @Mahala: I need to redo my blog header at https:\/\/t.co\/rm06c4PcCY What do ya'll think it should contain?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/rm06c4PcCY",
        "expanded_url" : "http:\/\/hiddenmahala.blogspot.com",
        "display_url" : "hiddenmahala.blogspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "727623907285544961",
    "text" : "I need to redo my blog header at https:\/\/t.co\/rm06c4PcCY What do ya'll think it should contain?",
    "id" : 727623907285544961,
    "created_at" : "2016-05-03 22:20:32 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 727630160615383040,
  "created_at" : "2016-05-03 22:45:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 64, 75 ]
    }, {
      "text" : "hypothyroid",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727621460043403264",
  "geo" : { },
  "id_str" : "727628869445005312",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 neuro said not drinking enough but i know she does. DD has #hashimotos #hypothyroid . thx 4 thoughts : )",
  "id" : 727628869445005312,
  "in_reply_to_status_id" : 727621460043403264,
  "created_at" : "2016-05-03 22:40:15 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/igmpeFMBfy",
      "expanded_url" : "http:\/\/www.thenewcivilrightsmovement.com\/davidbadash\/watch_parents_sing_jesus_loves_me_to_silence_lone_transgender_supporter_at_school_board_meeting",
      "display_url" : "thenewcivilrightsmovement.com\/davidbadash\/wa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727627013327097856",
  "text" : "Watch: Parents Sing 'Jesus Loves Me' to Silence Lone Transgender Supporter at School Board Meeting https:\/\/t.co\/igmpeFMBfy",
  "id" : 727627013327097856,
  "created_at" : "2016-05-03 22:32:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/iTKi1JqboA",
      "expanded_url" : "https:\/\/vine.co\/v\/ixr2djdj2hz",
      "display_url" : "vine.co\/v\/ixr2djdj2hz"
    } ]
  },
  "geo" : { },
  "id_str" : "727607719641919490",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDE3A\uD83C\uDF88\uD83D\uDC2F\uD83C\uDF52\uD83C\uDF1E\uD83D\uDC3E Grey goose giving traffic education lessons ... our best wishes are with them ... https:\/\/t.co\/iTKi1JqboA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/iTKi1JqboA",
        "expanded_url" : "https:\/\/vine.co\/v\/ixr2djdj2hz",
        "display_url" : "vine.co\/v\/ixr2djdj2hz"
      } ]
    },
    "geo" : { },
    "id_str" : "727595777179189249",
    "text" : "\uD83D\uDC3E\uD83D\uDE3A\uD83C\uDF88\uD83D\uDC2F\uD83C\uDF52\uD83C\uDF1E\uD83D\uDC3E Grey goose giving traffic education lessons ... our best wishes are with them ... https:\/\/t.co\/iTKi1JqboA",
    "id" : 727595777179189249,
    "created_at" : "2016-05-03 20:28:46 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 727607719641919490,
  "created_at" : "2016-05-03 21:16:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727589384724332548",
  "text" : "dry skin, dry scalp.. doesnt drink enough water. she drinks enough so that tells me.. thyroid! even tho numbers are in range.",
  "id" : 727589384724332548,
  "created_at" : "2016-05-03 20:03:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727588814009581568",
  "text" : "so neuro did order EMU that psych asked for. waiting on appt for that.",
  "id" : 727588814009581568,
  "created_at" : "2016-05-03 20:01:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727586100827574272",
  "text" : "another neuro eval. she thinks symptoms are psychiatric or personality based. wibblywobbly perception from flat feet.",
  "id" : 727586100827574272,
  "created_at" : "2016-05-03 19:50:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/RzIRnce8f8",
      "expanded_url" : "http:\/\/bookriot.com\/2016\/05\/01\/giveaway-win-year-long-membership-audible\/",
      "display_url" : "bookriot.com\/2016\/05\/01\/giv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727514761139724288",
  "text" : "Giveaway: Win a Year-Long Membership to Audible - https:\/\/t.co\/RzIRnce8f8",
  "id" : 727514761139724288,
  "created_at" : "2016-05-03 15:06:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "indices" : [ 3, 15 ],
      "id_str" : "954590804",
      "id" : 954590804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Rj5KJEkcdH",
      "expanded_url" : "http:\/\/themindcircle.com\/a-real-underground-kingdom\/",
      "display_url" : "themindcircle.com\/a-real-undergr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727312169994469376",
  "text" : "RT @planetepics: It\u2019s been there for millions of years, and we never even noticed it.\uD83D\uDE33 https:\/\/t.co\/Rj5KJEkcdH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/Rj5KJEkcdH",
        "expanded_url" : "http:\/\/themindcircle.com\/a-real-underground-kingdom\/",
        "display_url" : "themindcircle.com\/a-real-undergr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727273716590231553",
    "text" : "It\u2019s been there for millions of years, and we never even noticed it.\uD83D\uDE33 https:\/\/t.co\/Rj5KJEkcdH",
    "id" : 727273716590231553,
    "created_at" : "2016-05-02 23:09:00 +0000",
    "user" : {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "protected" : false,
      "id_str" : "954590804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463495027600015360\/_Jyj6WD6_normal.jpeg",
      "id" : 954590804,
      "verified" : false
    }
  },
  "id" : 727312169994469376,
  "created_at" : "2016-05-03 01:41:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727300285455056896",
  "text" : "RT @AWorldOutOfMind: sane atheists, non-libertarian, non-Trump followers\npeople interested in reality and the mind\nscience people\nI want to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727287300565131266",
    "text" : "sane atheists, non-libertarian, non-Trump followers\npeople interested in reality and the mind\nscience people\nI want to follow you\nRT please",
    "id" : 727287300565131266,
    "created_at" : "2016-05-03 00:02:59 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 727300285455056896,
  "created_at" : "2016-05-03 00:54:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727299769857613824",
  "text" : "RT @johnpavlovitz: To all those out there working for equality and compassion in the world: keep your head up, keep going, &amp; keep bringing\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727298410785677313",
    "text" : "To all those out there working for equality and compassion in the world: keep your head up, keep going, &amp; keep bringing light to dark places",
    "id" : 727298410785677313,
    "created_at" : "2016-05-03 00:47:08 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 727299769857613824,
  "created_at" : "2016-05-03 00:52:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727245578502066176",
  "text" : "im just so fed up w technology. I want to print agenda date range. why is that such a effin problem!!!",
  "id" : 727245578502066176,
  "created_at" : "2016-05-02 21:17:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727156726810681344",
  "text" : "ive got a win 7 computer and since win 10 on DHs pc can no longer print pdf, html. only from notepad. i print via wifi thru DHs pc.",
  "id" : 727156726810681344,
  "created_at" : "2016-05-02 15:24:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 64, 75 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/wDhzjQtQty",
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/727121994014150658",
      "display_url" : "twitter.com\/marseelee\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727126957603885056",
  "text" : "but thyroid labs improved, in normal range, R3 fine.. now what? #hashimotos #chronicillness https:\/\/t.co\/wDhzjQtQty",
  "id" : 727126957603885056,
  "created_at" : "2016-05-02 13:25:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/726999067302191105\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ITmu9YN7Eh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChbRyV4U4AAwJ6a.jpg",
      "id_str" : "726999052663971840",
      "id" : 726999052663971840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChbRyV4U4AAwJ6a.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ITmu9YN7Eh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/726999067302191105\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ITmu9YN7Eh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChbRyWEU8AAo4Yy.jpg",
      "id_str" : "726999052714307584",
      "id" : 726999052714307584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChbRyWEU8AAo4Yy.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ITmu9YN7Eh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727122758757408768",
  "text" : "RT @ErinEFarley: Made some black sheep and what's supposed to be a Jacob. It's a bit scary looking. https:\/\/t.co\/ITmu9YN7Eh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/726999067302191105\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/ITmu9YN7Eh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChbRyV4U4AAwJ6a.jpg",
        "id_str" : "726999052663971840",
        "id" : 726999052663971840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChbRyV4U4AAwJ6a.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ITmu9YN7Eh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/726999067302191105\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/ITmu9YN7Eh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChbRyWEU8AAo4Yy.jpg",
        "id_str" : "726999052714307584",
        "id" : 726999052714307584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChbRyWEU8AAo4Yy.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ITmu9YN7Eh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726999067302191105",
    "text" : "Made some black sheep and what's supposed to be a Jacob. It's a bit scary looking. https:\/\/t.co\/ITmu9YN7Eh",
    "id" : 726999067302191105,
    "created_at" : "2016-05-02 04:57:39 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 727122758757408768,
  "created_at" : "2016-05-02 13:09:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 79, 91 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "California",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726940995225542656",
  "text" : "RT @Interior: Our most popular pic last week: Tower trees &amp; Yosemite Falls @YosemiteNPS by Tiffany Nguyen #California \uD83C\uDF32 https:\/\/t.co\/m6ggcX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yosemite National Pk",
        "screen_name" : "YosemiteNPS",
        "indices" : [ 65, 77 ],
        "id_str" : "18726942",
        "id" : 18726942
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/726929717039906817\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/m6ggcXKzDv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChaStA8W0AAGDe4.jpg",
        "id_str" : "726929691911835648",
        "id" : 726929691911835648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChaStA8W0AAGDe4.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1640
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1279,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/m6ggcXKzDv"
      } ],
      "hashtags" : [ {
        "text" : "California",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726929717039906817",
    "text" : "Our most popular pic last week: Tower trees &amp; Yosemite Falls @YosemiteNPS by Tiffany Nguyen #California \uD83C\uDF32 https:\/\/t.co\/m6ggcXKzDv",
    "id" : 726929717039906817,
    "created_at" : "2016-05-02 00:22:04 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 726940995225542656,
  "created_at" : "2016-05-02 01:06:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726818837073661955",
  "text" : "fitbit one can be worn with clip OR band. fitbit flex is band only? (because no altimeter?)",
  "id" : 726818837073661955,
  "created_at" : "2016-05-01 17:01:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726818542352519169",
  "text" : "fitbit flex has no altimeter but better 3rd party band selection and can get a cheaper deal. ponders..",
  "id" : 726818542352519169,
  "created_at" : "2016-05-01 17:00:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726772725256216576",
  "text" : "RT @jorymicah: Complementarianism disempowers wives, then tells husbands to protect wives. Why not simply empower women in the first place?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "726760043274723328",
    "text" : "Complementarianism disempowers wives, then tells husbands to protect wives. Why not simply empower women in the first place? Control maybe?!",
    "id" : 726760043274723328,
    "created_at" : "2016-05-01 13:07:51 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 726772725256216576,
  "created_at" : "2016-05-01 13:58:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]