Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 36, 47 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 48, 55 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97468779449167872",
  "text" : "thanks for the love, peeps ((hugs)) @mimismutts @ssmdad",
  "id" : 97468779449167872,
  "created_at" : "2011-07-31 00:49:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GELASKINS",
      "screen_name" : "GelaSkins",
      "indices" : [ 3, 13 ],
      "id_str" : "1662544884",
      "id" : 1662544884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95866650020155392",
  "text" : "RT @GelaSkins: WOAH! Only 21 more followers to add until we giveaway TEN $75 Gift Certificates - Follow us and re-tweet this message to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95866284742414336",
    "text" : "WOAH! Only 21 more followers to add until we giveaway TEN $75 Gift Certificates - Follow us and re-tweet this message to enter :)",
    "id" : 95866284742414336,
    "created_at" : "2011-07-26 14:41:18 +0000",
    "user" : {
      "name" : "Nuvango",
      "screen_name" : "Nuvango",
      "protected" : false,
      "id_str" : "16751855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615889924382785536\/Y6fknMy4_normal.png",
      "id" : 16751855,
      "verified" : false
    }
  },
  "id" : 95866650020155392,
  "created_at" : "2011-07-26 14:42:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95282028211208193",
  "text" : "and the world carries on.",
  "id" : 95282028211208193,
  "created_at" : "2011-07-24 23:59:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/6oRQOgm",
      "expanded_url" : "https:\/\/plus.google.com\/107049300595210794285\/posts\/RtWCJGs2QMr",
      "display_url" : "plus.google.com\/10704930059521\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94035533386350592",
  "text" : "GOOGLE+ GUIDES & TIPS FOR NEWBIES (especially writers & illustrators) http:\/\/t.co\/6oRQOgm",
  "id" : 94035533386350592,
  "created_at" : "2011-07-21 13:26:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/GjkXdJS",
      "expanded_url" : "https:\/\/plus.google.com\/117541072957720579032\/posts\/FmFvw5sVd9d",
      "display_url" : "plus.google.com\/11754107295772\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "93856068450516992",
  "text" : "I have discovered the answer to life is not 42 but TKD! http:\/\/t.co\/GjkXdJS",
  "id" : 93856068450516992,
  "created_at" : "2011-07-21 01:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 104, 120 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/VA8tpGh",
      "expanded_url" : "http:\/\/bit.ly\/oOGV6a",
      "display_url" : "bit.ly\/oOGV6a"
    } ]
  },
  "geo" : { },
  "id_str" : "93775882245775361",
  "text" : "ATAPok.org hosting Free Bully Prevention Seminar Aug 6 or Aug 20 at 1pm. Register - http:\/\/t.co\/VA8tpGh @TheHudsonValley",
  "id" : 93775882245775361,
  "created_at" : "2011-07-20 20:14:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 0, 14 ],
      "id_str" : "112762057",
      "id" : 112762057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93722711624400896",
  "in_reply_to_user_id" : 112762057,
  "text" : "@loveofreading cant dm you.. can you email me: my twitter username at gmail.com? or tell me where to email you? thx!",
  "id" : 93722711624400896,
  "created_at" : "2011-07-20 16:43:30 +0000",
  "in_reply_to_screen_name" : "loveofreading",
  "in_reply_to_user_id_str" : "112762057",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93131320573706240",
  "text" : "mama raccoon came w\/out her babies. im concerned. hope babies are ok.",
  "id" : 93131320573706240,
  "created_at" : "2011-07-19 01:33:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92952652371083264",
  "geo" : { },
  "id_str" : "92977964664373248",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell one baby kept sitting on his butt. Mama kept eye on us but babies didnt care. told hubby we'll need bigger bag of catfood..lol",
  "id" : 92977964664373248,
  "in_reply_to_status_id" : 92952652371083264,
  "created_at" : "2011-07-18 15:24:08 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92951266656919552",
  "text" : "so now we have a mama raccoon and 3 babies taking advantage of our dine out special!",
  "id" : 92951266656919552,
  "created_at" : "2011-07-18 13:38:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/P0lql6P",
      "expanded_url" : "https:\/\/plus.google.com\/106452827609451720482\/posts\/K64bkgi3jvf",
      "display_url" : "plus.google.com\/10645282760945\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "92619865281667072",
  "text" : "A somber, dull morning which quickly turned dramatic as the the rising sun was given room to peek through the heavy ... http:\/\/t.co\/P0lql6P",
  "id" : 92619865281667072,
  "created_at" : "2011-07-17 15:41:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92417726487855104",
  "geo" : { },
  "id_str" : "92422342365560833",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps I'm a sucker for any new technology..lol",
  "id" : 92422342365560833,
  "in_reply_to_status_id" : 92417726487855104,
  "created_at" : "2011-07-17 02:36:18 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92417726487855104",
  "geo" : { },
  "id_str" : "92422214363787264",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps I'll have to see how it goes. I love my Twitter. I've been busy so haven't been tweeting much.",
  "id" : 92422214363787264,
  "in_reply_to_status_id" : 92417726487855104,
  "created_at" : "2011-07-17 02:35:47 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92281559167676416",
  "geo" : { },
  "id_str" : "92292156294828032",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps hard to say. I dont FB nearly as much as I tweet. Diff. audience. I like G+. It's slowly getting more active for me.",
  "id" : 92292156294828032,
  "in_reply_to_status_id" : 92281559167676416,
  "created_at" : "2011-07-16 17:58:59 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty Rayburn",
      "screen_name" : "topshelfebooks",
      "indices" : [ 3, 18 ],
      "id_str" : "231431785",
      "id" : 231431785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hellfirepub",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92266416031531008",
  "text" : "RT @topshelfebooks: Partay on twitter with hellfire publishing! just use #hellfirepub to join in the fun.  Win free books!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twhirl.org\" rel=\"nofollow\"\u003ESeesmic twhirl\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hellfirepub",
        "indices" : [ 53, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "92264341151301633",
    "text" : "Partay on twitter with hellfire publishing! just use #hellfirepub to join in the fun.  Win free books!",
    "id" : 92264341151301633,
    "created_at" : "2011-07-16 16:08:27 +0000",
    "user" : {
      "name" : "Misty Rayburn",
      "screen_name" : "topshelfebooks",
      "protected" : false,
      "id_str" : "231431785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704834759629938688\/o3bRCVgp_normal.jpg",
      "id" : 231431785,
      "verified" : false
    }
  },
  "id" : 92266416031531008,
  "created_at" : "2011-07-16 16:16:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gardeners",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92240281382043649",
  "text" : "RT @petersonguides: Reminder for all you #gardeners out there. Peterson Feeder Birds app is free and has 160 backyard birds, calls & mor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gardeners",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/AIqCzno",
        "expanded_url" : "http:\/\/bit.ly\/PFBofNA",
        "display_url" : "bit.ly\/PFBofNA"
      } ]
    },
    "geo" : { },
    "id_str" : "92239796113649664",
    "text" : "Reminder for all you #gardeners out there. Peterson Feeder Birds app is free and has 160 backyard birds, calls & more http:\/\/t.co\/AIqCzno",
    "id" : 92239796113649664,
    "created_at" : "2011-07-16 14:30:55 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 92240281382043649,
  "created_at" : "2011-07-16 14:32:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92236888500482048",
  "text" : "I do love my tweety friends \u2665",
  "id" : 92236888500482048,
  "created_at" : "2011-07-16 14:19:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92207741787045888",
  "geo" : { },
  "id_str" : "92236770149806082",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps no prob. just wanted to let you know. : )",
  "id" : 92236770149806082,
  "in_reply_to_status_id" : 92207741787045888,
  "created_at" : "2011-07-16 14:18:54 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92231243701301248",
  "text" : "I am here. I am there. I am everywhere.",
  "id" : 92231243701301248,
  "created_at" : "2011-07-16 13:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hope Dworaczyk",
      "screen_name" : "HopeDworaczyk",
      "indices" : [ 3, 17 ],
      "id_str" : "22997662",
      "id" : 22997662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92044451849056256",
  "text" : "RT @HopeDworaczyk: Puppy love is real to puppies.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "79029307267223553",
    "text" : "Puppy love is real to puppies.",
    "id" : 79029307267223553,
    "created_at" : "2011-06-10 03:37:09 +0000",
    "user" : {
      "name" : "Hope Dworaczyk",
      "screen_name" : "HopeDworaczyk",
      "protected" : false,
      "id_str" : "22997662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3673238817\/bb5a3f0f1f68274c2429f2e1726815ec_normal.jpeg",
      "id" : 22997662,
      "verified" : true
    }
  },
  "id" : 92044451849056256,
  "created_at" : "2011-07-16 01:34:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92016357129977856",
  "geo" : { },
  "id_str" : "92019741740367872",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl now I have to look that up..lol",
  "id" : 92019741740367872,
  "in_reply_to_status_id" : 92016357129977856,
  "created_at" : "2011-07-15 23:56:30 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kari",
      "screen_name" : "WiltingSoul",
      "indices" : [ 0, 12 ],
      "id_str" : "24330014",
      "id" : 24330014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 32 ],
      "url" : "http:\/\/t.co\/uH1LDQ6",
      "expanded_url" : "http:\/\/gplus.to\/abfabgab",
      "display_url" : "gplus.to\/abfabgab"
    } ]
  },
  "in_reply_to_status_id_str" : "92016811066933250",
  "geo" : { },
  "id_str" : "92019567387348992",
  "in_reply_to_user_id" : 24330014,
  "text" : "@WiltingSoul http:\/\/t.co\/uH1LDQ6 if you'd like",
  "id" : 92019567387348992,
  "in_reply_to_status_id" : 92016811066933250,
  "created_at" : "2011-07-15 23:55:49 +0000",
  "in_reply_to_screen_name" : "WiltingSoul",
  "in_reply_to_user_id_str" : "24330014",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 0, 13 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/stW6k7E",
      "expanded_url" : "http:\/\/bit.ly\/q5dmgq",
      "display_url" : "bit.ly\/q5dmgq"
    } ]
  },
  "geo" : { },
  "id_str" : "92018869153185793",
  "in_reply_to_user_id" : 93072985,
  "text" : "@MyNatureApps Nature Lovers and Birders share their Google+ with folks of similar interest http:\/\/t.co\/stW6k7E (if you're on G+)",
  "id" : 92018869153185793,
  "created_at" : "2011-07-15 23:53:02 +0000",
  "in_reply_to_screen_name" : "MyNatureApps",
  "in_reply_to_user_id_str" : "93072985",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/EvSTrlK",
      "expanded_url" : "http:\/\/bit.ly\/oezTAz",
      "display_url" : "bit.ly\/oezTAz"
    } ]
  },
  "geo" : { },
  "id_str" : "92014585388867584",
  "text" : "The Bible Says It. Does That Settle It? ~ Crystal St. Marie Lewis: http:\/\/t.co\/EvSTrlK",
  "id" : 92014585388867584,
  "created_at" : "2011-07-15 23:36:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91933137898180608",
  "geo" : { },
  "id_str" : "91958889796472833",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms omg'ness 3 years? wow...",
  "id" : 91958889796472833,
  "in_reply_to_status_id" : 91933137898180608,
  "created_at" : "2011-07-15 19:54:42 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91925359750152192",
  "text" : "effexor & me http:\/\/bit.ly\/qBtCDh",
  "id" : 91925359750152192,
  "created_at" : "2011-07-15 17:41:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91878643189547009",
  "geo" : { },
  "id_str" : "91880681663246337",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench what about \"Fondly\"?",
  "id" : 91880681663246337,
  "in_reply_to_status_id" : 91878643189547009,
  "created_at" : "2011-07-15 14:43:56 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Honey Badger",
      "screen_name" : "BronxZooHBadger",
      "indices" : [ 3, 19 ],
      "id_str" : "273624512",
      "id" : 273624512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamHoneyBadger",
      "indices" : [ 105, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/jm1g5iZ",
      "expanded_url" : "http:\/\/klout.com\/hbdc",
      "display_url" : "klout.com\/hbdc"
    } ]
  },
  "geo" : { },
  "id_str" : "91685598657642496",
  "text" : "RT @BronxZooHBadger: My Klout score is HONEY BADGER DON'T GIVE A SHIT. What's yours? http:\/\/t.co\/jm1g5iZ #TeamHoneyBadger",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamHoneyBadger",
        "indices" : [ 84, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 83 ],
        "url" : "http:\/\/t.co\/jm1g5iZ",
        "expanded_url" : "http:\/\/klout.com\/hbdc",
        "display_url" : "klout.com\/hbdc"
      } ]
    },
    "geo" : { },
    "id_str" : "91684340383227904",
    "text" : "My Klout score is HONEY BADGER DON'T GIVE A SHIT. What's yours? http:\/\/t.co\/jm1g5iZ #TeamHoneyBadger",
    "id" : 91684340383227904,
    "created_at" : "2011-07-15 01:43:44 +0000",
    "user" : {
      "name" : "The Honey Badger",
      "screen_name" : "BronxZooHBadger",
      "protected" : false,
      "id_str" : "273624512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598524575\/honey_badger_normal.jpg",
      "id" : 273624512,
      "verified" : false
    }
  },
  "id" : 91685598657642496,
  "created_at" : "2011-07-15 01:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RobG",
      "screen_name" : "RobertGirandola",
      "indices" : [ 3, 19 ],
      "id_str" : "17259640",
      "id" : 17259640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91685466583216129",
  "text" : "RT @RobertGirandola: If the universe is infinite in every direction then mathematically speaking, you are at the center...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91684674203697153",
    "text" : "If the universe is infinite in every direction then mathematically speaking, you are at the center...",
    "id" : 91684674203697153,
    "created_at" : "2011-07-15 01:45:04 +0000",
    "user" : {
      "name" : "RobG",
      "screen_name" : "RobertGirandola",
      "protected" : false,
      "id_str" : "17259640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000492875892\/b5fcd4405334ac08804a80d8c4ae0fbd_normal.jpeg",
      "id" : 17259640,
      "verified" : false
    }
  },
  "id" : 91685466583216129,
  "created_at" : "2011-07-15 01:48:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91671256881037313",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 omg'ness just read over what happened! big squeezy ((hugs))",
  "id" : 91671256881037313,
  "created_at" : "2011-07-15 00:51:45 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91528584786751488",
  "geo" : { },
  "id_str" : "91536110945185794",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell LOLOL",
  "id" : 91536110945185794,
  "in_reply_to_status_id" : 91528584786751488,
  "created_at" : "2011-07-14 15:54:44 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Honest Tea",
      "screen_name" : "HonestTea",
      "indices" : [ 3, 13 ],
      "id_str" : "16149114",
      "id" : 16149114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91526404713357312",
  "text" : "RT @HonestTea: \"Only a person who risks is free.\" -- Anonymous  #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 49, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91501922829336577",
    "text" : "\"Only a person who risks is free.\" -- Anonymous  #quote",
    "id" : 91501922829336577,
    "created_at" : "2011-07-14 13:38:53 +0000",
    "user" : {
      "name" : "Honest Tea",
      "screen_name" : "HonestTea",
      "protected" : false,
      "id_str" : "16149114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/564895345662910464\/rl47nbNF_normal.jpeg",
      "id" : 16149114,
      "verified" : true
    }
  },
  "id" : 91526404713357312,
  "created_at" : "2011-07-14 15:16:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91524003763720194",
  "geo" : { },
  "id_str" : "91525710858027008",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I'm wondering that myself...",
  "id" : 91525710858027008,
  "in_reply_to_status_id" : 91524003763720194,
  "created_at" : "2011-07-14 15:13:24 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91362549701939200",
  "geo" : { },
  "id_str" : "91525496344543232",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad btw, if you get on G+, let me know & I'll add you. : )",
  "id" : 91525496344543232,
  "in_reply_to_status_id" : 91362549701939200,
  "created_at" : "2011-07-14 15:12:33 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91362549701939200",
  "geo" : { },
  "id_str" : "91525241385390081",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad Thanks for the WW mention. You are so kind! Hope your knee is good today.",
  "id" : 91525241385390081,
  "in_reply_to_status_id" : 91362549701939200,
  "created_at" : "2011-07-14 15:11:32 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91123986842398721",
  "geo" : { },
  "id_str" : "91126473364226048",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench I just read about that this am. I hope they listen to the many ppl who are protesting that.",
  "id" : 91126473364226048,
  "in_reply_to_status_id" : 91123986842398721,
  "created_at" : "2011-07-13 12:46:58 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91123446762844160",
  "text" : "blah. just blah.",
  "id" : 91123446762844160,
  "created_at" : "2011-07-13 12:34:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91123001717833729",
  "text" : "I got up early this am. Dog had to go out. So I stayed up.",
  "id" : 91123001717833729,
  "created_at" : "2011-07-13 12:33:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91120775536443392",
  "text" : "good morning peeps. I am sleepy.",
  "id" : 91120775536443392,
  "created_at" : "2011-07-13 12:24:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 3, 19 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/zFJ3d9z",
      "expanded_url" : "http:\/\/Facebook.com\/HudsonRiverValley",
      "display_url" : "Facebook.com\/HudsonRiverVal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90963932029788160",
  "text" : "RT @TheHudsonValley: Our Facebook page has over 4,000 fans, as of tonight! Haven't joined us yet? Feel Free! :o) http:\/\/t.co\/zFJ3d9z #hu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hudsonvalley",
        "indices" : [ 112, 125 ]
      }, {
        "text" : "local",
        "indices" : [ 126, 132 ]
      }, {
        "text" : "ny",
        "indices" : [ 133, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 111 ],
        "url" : "http:\/\/t.co\/zFJ3d9z",
        "expanded_url" : "http:\/\/Facebook.com\/HudsonRiverValley",
        "display_url" : "Facebook.com\/HudsonRiverVal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "90961878708273152",
    "text" : "Our Facebook page has over 4,000 fans, as of tonight! Haven't joined us yet? Feel Free! :o) http:\/\/t.co\/zFJ3d9z #hudsonvalley #local #ny",
    "id" : 90961878708273152,
    "created_at" : "2011-07-13 01:52:56 +0000",
    "user" : {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "protected" : false,
      "id_str" : "102313523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567810424549044227\/C6iux0NV_normal.png",
      "id" : 102313523,
      "verified" : false
    }
  },
  "id" : 90963932029788160,
  "created_at" : "2011-07-13 02:01:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/gH99JLu",
      "expanded_url" : "http:\/\/gplus.to",
      "display_url" : "gplus.to"
    } ]
  },
  "in_reply_to_status_id_str" : "90958583101005824",
  "geo" : { },
  "id_str" : "90962766495617024",
  "in_reply_to_user_id" : 40585382,
  "text" : "@Reverend_Sue you can get a short url for g+ at http:\/\/t.co\/gH99JLu",
  "id" : 90962766495617024,
  "in_reply_to_status_id" : 90958583101005824,
  "created_at" : "2011-07-13 01:56:28 +0000",
  "in_reply_to_screen_name" : "ReverendSue",
  "in_reply_to_user_id_str" : "40585382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90961083531145216",
  "geo" : { },
  "id_str" : "90962008685543425",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad have a good sleep : )",
  "id" : 90962008685543425,
  "in_reply_to_status_id" : 90961083531145216,
  "created_at" : "2011-07-13 01:53:27 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90954595655892992",
  "text" : "RT @Buddhaworld: trust in your own judgement only, but let it come from your heart. Buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90950429290143744",
    "text" : "trust in your own judgement only, but let it come from your heart. Buddha volko.",
    "id" : 90950429290143744,
    "created_at" : "2011-07-13 01:07:26 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 90954595655892992,
  "created_at" : "2011-07-13 01:24:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "thriller",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/mGligYs",
      "expanded_url" : "http:\/\/thefrugalereader.com\/2011\/07\/12\/qa-and-giveaway-with-david-carnoy\/#.ThztW8jGgX0.tweet",
      "display_url" : "thefrugalereader.com\/2011\/07\/12\/qa-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "90948447678627840",
  "text" : "Q&A and Giveaway with David Carnoy: http:\/\/t.co\/mGligYs Knife Music #kindle #thriller",
  "id" : 90948447678627840,
  "created_at" : "2011-07-13 00:59:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90876685578285056",
  "text" : "@bookhound78 ((highfive))",
  "id" : 90876685578285056,
  "created_at" : "2011-07-12 20:14:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90796113778573312",
  "text" : "@Tideliar LOL..Coolio!",
  "id" : 90796113778573312,
  "created_at" : "2011-07-12 14:54:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90594202873892864",
  "text" : "RT @hvspca: Critical Crossroad http:\/\/wp.me\/pLcDB-ea\"\" PLS retweet\", share to ur facebook, pls help us convey to all this very important ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90592982797000704",
    "text" : "Critical Crossroad http:\/\/wp.me\/pLcDB-ea\"\" PLS retweet\", share to ur facebook, pls help us convey to all this very important message\"\"\"\"\"",
    "id" : 90592982797000704,
    "created_at" : "2011-07-12 01:27:04 +0000",
    "user" : {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "protected" : false,
      "id_str" : "99531497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638069419164454913\/KeccRrpI_normal.jpg",
      "id" : 99531497,
      "verified" : false
    }
  },
  "id" : 90594202873892864,
  "created_at" : "2011-07-12 01:31:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 0, 15 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90593023557238785",
  "geo" : { },
  "id_str" : "90593691324006400",
  "in_reply_to_user_id" : 104029814,
  "text" : "@stream_enterer to me, its like Twitter & FB mix. It's all about the circles. Circles are groups of ppl.",
  "id" : 90593691324006400,
  "in_reply_to_status_id" : 90593023557238785,
  "created_at" : "2011-07-12 01:29:53 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90590266083381248",
  "geo" : { },
  "id_str" : "90590971011678208",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees ouch! sorry to hear that. ((hugs))",
  "id" : 90590971011678208,
  "in_reply_to_status_id" : 90590266083381248,
  "created_at" : "2011-07-12 01:19:05 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 7, 16 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90590168242864128",
  "text" : "I want @Tideliar to join G+ so I can have a circle entitled \"abundant use of F word\"..lol",
  "id" : 90590168242864128,
  "created_at" : "2011-07-12 01:15:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 0, 15 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90588774056198145",
  "geo" : { },
  "id_str" : "90589286918922242",
  "in_reply_to_user_id" : 104029814,
  "text" : "@stream_enterer absolutely! send me your email, here, dm or at gplus.to\/abfabgab (send mail)",
  "id" : 90589286918922242,
  "in_reply_to_status_id" : 90588774056198145,
  "created_at" : "2011-07-12 01:12:23 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 3, 17 ],
      "id_str" : "112762057",
      "id" : 112762057
    }, {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 68, 78 ],
      "id_str" : "14428947",
      "id" : 14428947
    }, {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "indices" : [ 90, 104 ],
      "id_str" : "112762057",
      "id" : 112762057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Freebie",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90505768566136832",
  "text" : "RT @loveofreading: FSB #Freebie! US\/CANADA entrants: County Line by @bcmystery! RT\/Follow @LoveOfReading by 7\/18. http:\/\/ow.ly\/5ddr4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Cameron",
        "screen_name" : "bcmystery",
        "indices" : [ 49, 59 ],
        "id_str" : "14428947",
        "id" : 14428947
      }, {
        "name" : "Love of Reading",
        "screen_name" : "loveofreading",
        "indices" : [ 71, 85 ],
        "id_str" : "112762057",
        "id" : 112762057
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Freebie",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90498184622780416",
    "text" : "FSB #Freebie! US\/CANADA entrants: County Line by @bcmystery! RT\/Follow @LoveOfReading by 7\/18. http:\/\/ow.ly\/5ddr4",
    "id" : 90498184622780416,
    "created_at" : "2011-07-11 19:10:23 +0000",
    "user" : {
      "name" : "Love of Reading",
      "screen_name" : "loveofreading",
      "protected" : false,
      "id_str" : "112762057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/807514027\/loricon2_normal.jpg",
      "id" : 112762057,
      "verified" : false
    }
  },
  "id" : 90505768566136832,
  "created_at" : "2011-07-11 19:40:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90500435332448256",
  "text" : "RT @DuttonBooks: THE KEEPER OF LOST CAUSES by Jussi Adler-Olsen is the next red hot Scandinavian thriller.  RT to enter to #win an ARC.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 106, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90499357329195008",
    "text" : "THE KEEPER OF LOST CAUSES by Jussi Adler-Olsen is the next red hot Scandinavian thriller.  RT to enter to #win an ARC.  (US only)",
    "id" : 90499357329195008,
    "created_at" : "2011-07-11 19:15:02 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 90500435332448256,
  "created_at" : "2011-07-11 19:19:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CosmicConsciousness",
      "indices" : [ 18, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90221564888485888",
  "text" : "RT @DeepakChopra: #CosmicConsciousness Instead of thinking outside the box, get rid of the box.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CosmicConsciousness",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90218523359592448",
    "text" : "#CosmicConsciousness Instead of thinking outside the box, get rid of the box.",
    "id" : 90218523359592448,
    "created_at" : "2011-07-11 00:39:06 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 90221564888485888,
  "created_at" : "2011-07-11 00:51:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http:\/\/t.co\/uH1LDQ6",
      "expanded_url" : "http:\/\/gplus.to\/abfabgab",
      "display_url" : "gplus.to\/abfabgab"
    } ]
  },
  "geo" : { },
  "id_str" : "90059393202274304",
  "text" : "If you need an invite, send request by clicking link on my G+ profile to send me a message. http:\/\/t.co\/uH1LDQ6",
  "id" : 90059393202274304,
  "created_at" : "2011-07-10 14:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90056998732832768",
  "text" : "You're a Gamer.. create a Circle, put your gaming friends in it. Now you can post game talk without boring your non-gaming friends..LOL",
  "id" : 90056998732832768,
  "created_at" : "2011-07-10 13:57:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90056565951954945",
  "text" : "Let's say you like to share risque type jokes.. create a Jokes Circle and include your friends who like those jokes.",
  "id" : 90056565951954945,
  "created_at" : "2011-07-10 13:55:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90056239312154624",
  "text" : "People can choose to \"follow\" you but unless they are in one of your circles, they will only see what you post under \"Public.\"",
  "id" : 90056239312154624,
  "created_at" : "2011-07-10 13:54:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90055959069736960",
  "text" : "It's like Twitter and Facebook combined. There is a learning curve but I can see the benefits of this system.",
  "id" : 90055959069736960,
  "created_at" : "2011-07-10 13:53:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90055508903477248",
  "text" : "Google+ is based on Circles which you create, name, choose privacy. They can overlap. No one knows which Circle they're in.",
  "id" : 90055508903477248,
  "created_at" : "2011-07-10 13:51:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90055164056182784",
  "text" : "Google+ invites still available. You don't need to add me to a Circle.",
  "id" : 90055164056182784,
  "created_at" : "2011-07-10 13:49:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89890695808155648",
  "text" : "now I know who loves me and who doesn't...",
  "id" : 89890695808155648,
  "created_at" : "2011-07-10 02:56:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89864808408678401",
  "geo" : { },
  "id_str" : "89866809410453505",
  "in_reply_to_user_id" : 17165443,
  "text" : "@kindlevixen still showing up in my sidebar",
  "id" : 89866809410453505,
  "in_reply_to_status_id" : 89864808408678401,
  "created_at" : "2011-07-10 01:21:31 +0000",
  "in_reply_to_screen_name" : "moxie_hart",
  "in_reply_to_user_id_str" : "17165443",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89842785787723778",
  "text" : "anyone want a google plus invite? (I need your email address to send it)",
  "id" : 89842785787723778,
  "created_at" : "2011-07-09 23:46:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89767713416806400",
  "text" : "@Tideliar good to see you're still in fine form! : )",
  "id" : 89767713416806400,
  "created_at" : "2011-07-09 18:47:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Beth Nelson",
      "screen_name" : "northernmagic",
      "indices" : [ 0, 14 ],
      "id_str" : "2556861443",
      "id" : 2556861443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89757311777779712",
  "text" : "@NorthernMagic LOLOL",
  "id" : 89757311777779712,
  "created_at" : "2011-07-09 18:06:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89711292763475969",
  "geo" : { },
  "id_str" : "89743218186518530",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell if you can see the posts in my Bookmarked Circle.. ive been adding G+ tips there. : )",
  "id" : 89743218186518530,
  "in_reply_to_status_id" : 89711292763475969,
  "created_at" : "2011-07-09 17:10:25 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89717253414723584",
  "geo" : { },
  "id_str" : "89742760822849536",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell gplus.to\/abfabgab",
  "id" : 89742760822849536,
  "in_reply_to_status_id" : 89717253414723584,
  "created_at" : "2011-07-09 17:08:36 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jackass",
      "screen_name" : "Adults_jokes",
      "indices" : [ 3, 16 ],
      "id_str" : "241617450",
      "id" : 241617450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89702283381706752",
  "text" : "RT @Adults_jokes: There was a beautiful young woman knocking at my hotel room door all night. I finally had to let her out",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89622965712457728",
    "text" : "There was a beautiful young woman knocking at my hotel room door all night. I finally had to let her out",
    "id" : 89622965712457728,
    "created_at" : "2011-07-09 09:12:34 +0000",
    "user" : {
      "name" : "jackass",
      "screen_name" : "Adults_jokes",
      "protected" : false,
      "id_str" : "241617450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1313945626\/284833582_normal.jpg",
      "id" : 241617450,
      "verified" : false
    }
  },
  "id" : 89702283381706752,
  "created_at" : "2011-07-09 14:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89690823217782785",
  "geo" : { },
  "id_str" : "89700989040459779",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell its like a mix of Twitter & FB. Ppl can B put in 1+ circles. You can have private, public or semi-private circles.",
  "id" : 89700989040459779,
  "in_reply_to_status_id" : 89690823217782785,
  "created_at" : "2011-07-09 14:22:37 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89690823217782785",
  "geo" : { },
  "id_str" : "89700493298896896",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell its taking some getting used to but I think it will be good once I get gist of it.",
  "id" : 89700493298896896,
  "in_reply_to_status_id" : 89690823217782785,
  "created_at" : "2011-07-09 14:20:38 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89690058097033216",
  "text" : "Busy with websites. Discovering Google+.",
  "id" : 89690058097033216,
  "created_at" : "2011-07-09 13:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87940271295315968",
  "text" : "dont worry, my dears.. im still alive! : D",
  "id" : 87940271295315968,
  "created_at" : "2011-07-04 17:46:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/3j8YA5y",
      "expanded_url" : "http:\/\/www.thepostgame.com\/features\/201107\/daredevil-squirrel-performs-ultimate-lambo-leap",
      "display_url" : "thepostgame.com\/features\/20110\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "87636208821354496",
  "text" : "Daredevil California Squirrel Somehow Outfoxes Speeding Lamborghini http:\/\/t.co\/3j8YA5y",
  "id" : 87636208821354496,
  "created_at" : "2011-07-03 21:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 112, 125 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87174192604254208",
  "text" : "HUGE 70% off - every app we have on nature reduced to $2.99 for July 4th weekend only! http:\/\/bit.ly\/ix6khT via @MyNatureApps",
  "id" : 87174192604254208,
  "created_at" : "2011-07-02 15:02:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]