Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/K0Gt1X8LNn",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=142908889230649&set=a.140280772826794.1073741827.139911216197083&type=1&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329413516522037248",
  "text" : "RT @DwayneReaves: Bunny Rabbit Photo https:\/\/t.co\/K0Gt1X8LNn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/K0Gt1X8LNn",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=142908889230649&set=a.140280772826794.1073741827.139911216197083&type=1&theater",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "329413030477692929",
    "text" : "Bunny Rabbit Photo https:\/\/t.co\/K0Gt1X8LNn",
    "id" : 329413030477692929,
    "created_at" : "2013-05-01 01:52:41 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 329413516522037248,
  "created_at" : "2013-05-01 01:54:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lola Haag",
      "screen_name" : "ojailola",
      "indices" : [ 3, 12 ],
      "id_str" : "269441846",
      "id" : 269441846
    }, {
      "name" : "Say No To GOP",
      "screen_name" : "SayNoToGOP",
      "indices" : [ 22, 33 ],
      "id_str" : "849169945",
      "id" : 849169945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/hl85tkJRY3",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/04\/30\/1205885\/-Gov-Brewer-signs-law-to-force-Arizona-gun-buy-back-programs-to-resell-the-guns-they-collect",
      "display_url" : "dailykos.com\/story\/2013\/04\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329398460262514690",
  "text" : "RT @ojailola: Wacko! \u201C@SayNoToGOP: Brewer signs law to force AZ gun buy-back programs to resell guns they collect http:\/\/t.co\/hl85tkJRY3 vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Say No To GOP",
        "screen_name" : "SayNoToGOP",
        "indices" : [ 8, 19 ],
        "id_str" : "849169945",
        "id" : 849169945
      }, {
        "name" : "Daily Kos",
        "screen_name" : "dailykos",
        "indices" : [ 127, 136 ],
        "id_str" : "20818801",
        "id" : 20818801
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/hl85tkJRY3",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/04\/30\/1205885\/-Gov-Brewer-signs-law-to-force-Arizona-gun-buy-back-programs-to-resell-the-guns-they-collect",
        "display_url" : "dailykos.com\/story\/2013\/04\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "329366877174370304",
    "geo" : { },
    "id_str" : "329394282538618880",
    "in_reply_to_user_id" : 849169945,
    "text" : "Wacko! \u201C@SayNoToGOP: Brewer signs law to force AZ gun buy-back programs to resell guns they collect http:\/\/t.co\/hl85tkJRY3 via @dailykos\u201D",
    "id" : 329394282538618880,
    "in_reply_to_status_id" : 329366877174370304,
    "created_at" : "2013-05-01 00:38:11 +0000",
    "in_reply_to_screen_name" : "SayNoToGOP",
    "in_reply_to_user_id_str" : "849169945",
    "user" : {
      "name" : "Lola Haag",
      "screen_name" : "ojailola",
      "protected" : false,
      "id_str" : "269441846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529336207902126080\/JXpLInOC_normal.jpeg",
      "id" : 269441846,
      "verified" : false
    }
  },
  "id" : 329398460262514690,
  "created_at" : "2013-05-01 00:54:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birdinfeeder",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329379135615033344",
  "text" : "i was afraid the poor thing was going to have a heart attack before getting out... #birdinfeeder",
  "id" : 329379135615033344,
  "created_at" : "2013-04-30 23:38:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329378597074788352",
  "text" : "DH just had to save a bird from the birdfeeder. somehow he got inside of it. poor dear was hopping about..lol",
  "id" : 329378597074788352,
  "created_at" : "2013-04-30 23:35:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329377807346044928",
  "text" : "RT @ducksandclucks: \"We'd like to sit NEAR you, but we don't want to TALK to you. And don't look at us.\" - chicken rules http:\/\/t.co\/Qgv3sN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/Qgv3sNltuj",
        "expanded_url" : "http:\/\/instagram.com\/p\/Yv0gz2hH71\/",
        "display_url" : "instagram.com\/p\/Yv0gz2hH71\/"
      } ]
    },
    "geo" : { },
    "id_str" : "329375692049506305",
    "text" : "\"We'd like to sit NEAR you, but we don't want to TALK to you. And don't look at us.\" - chicken rules http:\/\/t.co\/Qgv3sNltuj",
    "id" : 329375692049506305,
    "created_at" : "2013-04-30 23:24:19 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 329377807346044928,
  "created_at" : "2013-04-30 23:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329331004718333952",
  "geo" : { },
  "id_str" : "329338130173919234",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH agreed.. as long is there is no blood involved..lol",
  "id" : 329338130173919234,
  "in_reply_to_status_id" : 329331004718333952,
  "created_at" : "2013-04-30 20:55:03 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329316556746133507",
  "geo" : { },
  "id_str" : "329321958581878785",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid i love this.. just sooo cool : )",
  "id" : 329321958581878785,
  "in_reply_to_status_id" : 329316556746133507,
  "created_at" : "2013-04-30 19:50:48 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Ballou",
      "screen_name" : "Catballou",
      "indices" : [ 0, 10 ],
      "id_str" : "19308529",
      "id" : 19308529
    }, {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 11, 24 ],
      "id_str" : "946353775",
      "id" : 946353775
    }, {
      "name" : "\u2728Cheron\u2728",
      "screen_name" : "CosmoTyme",
      "indices" : [ 25, 35 ],
      "id_str" : "574554751",
      "id" : 574554751
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329282793886597122",
  "geo" : { },
  "id_str" : "329295393399664640",
  "in_reply_to_user_id" : 19308529,
  "text" : "@Catballou @MimiMadeira1 @CosmoTyme blue sky and nice 69 here in NY",
  "id" : 329295393399664640,
  "in_reply_to_status_id" : 329282793886597122,
  "created_at" : "2013-04-30 18:05:14 +0000",
  "in_reply_to_screen_name" : "Catballou",
  "in_reply_to_user_id_str" : "19308529",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329290900360527872",
  "text" : "RT @BrianRathbone: REMINDER: Have you backed up your website lately? Databases? Relying on hosts' backups is not wise.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329288879456800768",
    "text" : "REMINDER: Have you backed up your website lately? Databases? Relying on hosts' backups is not wise.",
    "id" : 329288879456800768,
    "created_at" : "2013-04-30 17:39:21 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 329290900360527872,
  "created_at" : "2013-04-30 17:47:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329281428456083457",
  "text" : "RT @TimGreaton: Did you know? For over 150 years, scientists have known that fires can be extinguished with sound waves, but they still don\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329281110569799680",
    "text" : "Did you know? For over 150 years, scientists have known that fires can be extinguished with sound waves, but they still don't know how.",
    "id" : 329281110569799680,
    "created_at" : "2013-04-30 17:08:29 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 329281428456083457,
  "created_at" : "2013-04-30 17:09:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    }, {
      "name" : "Cat Ballou",
      "screen_name" : "Catballou",
      "indices" : [ 14, 24 ],
      "id_str" : "19308529",
      "id" : 19308529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329272371456380928",
  "geo" : { },
  "id_str" : "329280409655451648",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 @Catballou not me..lol. im very.. um.. anal..lol. very picky about food..",
  "id" : 329280409655451648,
  "in_reply_to_status_id" : 329272371456380928,
  "created_at" : "2013-04-30 17:05:42 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    }, {
      "name" : "Cat Ballou",
      "screen_name" : "Catballou",
      "indices" : [ 14, 24 ],
      "id_str" : "19308529",
      "id" : 19308529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329265133182386178",
  "geo" : { },
  "id_str" : "329279786016993280",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 @Catballou my \"weird\" hot flashes seemed to have stopped. it was more an intolerance to heat. my DR said she had that.",
  "id" : 329279786016993280,
  "in_reply_to_status_id" : 329265133182386178,
  "created_at" : "2013-04-30 17:03:13 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    }, {
      "name" : "Cat Ballou",
      "screen_name" : "Catballou",
      "indices" : [ 14, 24 ],
      "id_str" : "19308529",
      "id" : 19308529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329265133182386178",
  "geo" : { },
  "id_str" : "329279491341963266",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 @Catballou i read recently that nausea can be a symptom of menopause (which makes sense..crazy hormones)",
  "id" : 329279491341963266,
  "in_reply_to_status_id" : 329265133182386178,
  "created_at" : "2013-04-30 17:02:03 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329278171834875904",
  "text" : "bible study... always interesting..hehe. love my MIL.. if her dog's not going (to heaven) then neither is she! : ) Go, Mommy!",
  "id" : 329278171834875904,
  "created_at" : "2013-04-30 16:56:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329220188069306370",
  "geo" : { },
  "id_str" : "329222347737419777",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides what a cutie!",
  "id" : 329222347737419777,
  "in_reply_to_status_id" : 329220188069306370,
  "created_at" : "2013-04-30 13:14:59 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wilderness Training",
      "screen_name" : "MarybethHaydon",
      "indices" : [ 3, 18 ],
      "id_str" : "950531623",
      "id" : 950531623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deer",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "trail",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "snow",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "sighting",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/zKZ24IgKTz",
      "expanded_url" : "http:\/\/ow.ly\/i\/1ZwCE",
      "display_url" : "ow.ly\/i\/1ZwCE"
    } ]
  },
  "geo" : { },
  "id_str" : "329037662516281347",
  "text" : "RT @MarybethHaydon: Now, THIS is a deer sighting! W-O-W! http:\/\/t.co\/zKZ24IgKTz  #deer #trail #snow #wildlife #sighting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "deer",
        "indices" : [ 61, 66 ]
      }, {
        "text" : "trail",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "snow",
        "indices" : [ 74, 79 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 80, 89 ]
      }, {
        "text" : "sighting",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/zKZ24IgKTz",
        "expanded_url" : "http:\/\/ow.ly\/i\/1ZwCE",
        "display_url" : "ow.ly\/i\/1ZwCE"
      } ]
    },
    "geo" : { },
    "id_str" : "328671265726529536",
    "text" : "Now, THIS is a deer sighting! W-O-W! http:\/\/t.co\/zKZ24IgKTz  #deer #trail #snow #wildlife #sighting",
    "id" : 328671265726529536,
    "created_at" : "2013-04-29 00:45:10 +0000",
    "user" : {
      "name" : "Wilderness Training",
      "screen_name" : "MarybethHaydon",
      "protected" : false,
      "id_str" : "950531623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3380652093\/0e94a44f3f95a92aa06e092db4c0e9b2_normal.jpeg",
      "id" : 950531623,
      "verified" : false
    }
  },
  "id" : 329037662516281347,
  "created_at" : "2013-04-30 01:01:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WoolyBumblebee \u2718",
      "screen_name" : "WoolyBumblebee",
      "indices" : [ 3, 18 ],
      "id_str" : "97282602",
      "id" : 97282602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/lWYfGucxTj",
      "expanded_url" : "http:\/\/wp.me\/p1Ku6V-9GL",
      "display_url" : "wp.me\/p1Ku6V-9GL"
    } ]
  },
  "geo" : { },
  "id_str" : "329034068224245762",
  "text" : "RT @WoolyBumblebee: Mary Elizabeth Williams killed Earl Silverman http:\/\/t.co\/lWYfGucxTj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/lWYfGucxTj",
        "expanded_url" : "http:\/\/wp.me\/p1Ku6V-9GL",
        "display_url" : "wp.me\/p1Ku6V-9GL"
      } ]
    },
    "geo" : { },
    "id_str" : "329031907520167938",
    "text" : "Mary Elizabeth Williams killed Earl Silverman http:\/\/t.co\/lWYfGucxTj",
    "id" : 329031907520167938,
    "created_at" : "2013-04-30 00:38:14 +0000",
    "user" : {
      "name" : "WoolyBumblebee \u2718",
      "screen_name" : "WoolyBumblebee",
      "protected" : false,
      "id_str" : "97282602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799845160670461952\/IXV4TeTi_normal.jpg",
      "id" : 97282602,
      "verified" : false
    }
  },
  "id" : 329034068224245762,
  "created_at" : "2013-04-30 00:46:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "indices" : [ 3, 18 ],
      "id_str" : "615318971",
      "id" : 615318971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329005819838464002",
  "text" : "RT @CuestionMarque: An abundance of food production does not end scarcity nor starvation b\/c of corrupted distribution channels manipulated\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329000894068838402",
    "text" : "An abundance of food production does not end scarcity nor starvation b\/c of corrupted distribution channels manipulated to maximize profits.",
    "id" : 329000894068838402,
    "created_at" : "2013-04-29 22:35:00 +0000",
    "user" : {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "protected" : false,
      "id_str" : "615318971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2347711009\/5slm7j57n6tf4g5d98ia_normal.jpeg",
      "id" : 615318971,
      "verified" : false
    }
  },
  "id" : 329005819838464002,
  "created_at" : "2013-04-29 22:54:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    }, {
      "name" : "James Marsh",
      "screen_name" : "marshjs90",
      "indices" : [ 15, 25 ],
      "id_str" : "1306702638",
      "id" : 1306702638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328982035672752129",
  "geo" : { },
  "id_str" : "328985929027043328",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid @marshjs90 lots of things can be dangerous if used wrongly or bad intent.",
  "id" : 328985929027043328,
  "in_reply_to_status_id" : 328982035672752129,
  "created_at" : "2013-04-29 21:35:32 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328966028862296064",
  "geo" : { },
  "id_str" : "328968577094934528",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH ((hugs)) dear ani la. hope you feel better tomorrow.",
  "id" : 328968577094934528,
  "in_reply_to_status_id" : 328966028862296064,
  "created_at" : "2013-04-29 20:26:35 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RhinebeckTweets",
      "screen_name" : "RhinebeckTweets",
      "indices" : [ 3, 19 ],
      "id_str" : "85490306",
      "id" : 85490306
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "artsarestillalive",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/EqwxhgSla1",
      "expanded_url" : "http:\/\/ow.ly\/kxEAc",
      "display_url" : "ow.ly\/kxEAc"
    } ]
  },
  "geo" : { },
  "id_str" : "328967278697783296",
  "text" : "RT @RhinebeckTweets: wow! $1Million given to Center for Perform Arts at Rhinebeck anonymously. #artsarestillalive! http:\/\/t.co\/EqwxhgSla1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "artsarestillalive",
        "indices" : [ 74, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/EqwxhgSla1",
        "expanded_url" : "http:\/\/ow.ly\/kxEAc",
        "display_url" : "ow.ly\/kxEAc"
      } ]
    },
    "geo" : { },
    "id_str" : "328962026984570882",
    "text" : "wow! $1Million given to Center for Perform Arts at Rhinebeck anonymously. #artsarestillalive! http:\/\/t.co\/EqwxhgSla1",
    "id" : 328962026984570882,
    "created_at" : "2013-04-29 20:00:33 +0000",
    "user" : {
      "name" : "RhinebeckTweets",
      "screen_name" : "RhinebeckTweets",
      "protected" : false,
      "id_str" : "85490306",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801025222765907968\/R2lqG0je_normal.jpg",
      "id" : 85490306,
      "verified" : false
    }
  },
  "id" : 328967278697783296,
  "created_at" : "2013-04-29 20:21:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/oVXNJheV7U",
      "expanded_url" : "http:\/\/bit.ly\/12Jesx7",
      "display_url" : "bit.ly\/12Jesx7"
    } ]
  },
  "geo" : { },
  "id_str" : "328909520522846208",
  "text" : "RT @CandyTX: Candy's Raves: Book Giveaway: The Wrath of Angels: A Charlie Parker Thriller by John Connolly http:\/\/t.co\/oVXNJheV7U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/oVXNJheV7U",
        "expanded_url" : "http:\/\/bit.ly\/12Jesx7",
        "display_url" : "bit.ly\/12Jesx7"
      } ]
    },
    "geo" : { },
    "id_str" : "328891606969241601",
    "text" : "Candy's Raves: Book Giveaway: The Wrath of Angels: A Charlie Parker Thriller by John Connolly http:\/\/t.co\/oVXNJheV7U",
    "id" : 328891606969241601,
    "created_at" : "2013-04-29 15:20:44 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 328909520522846208,
  "created_at" : "2013-04-29 16:31:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328900453939159040",
  "text" : "RT @petsalive: NEVER allow them 2 take your dog, even to \"hold\". NEVER sign any papers relinquishing ur ownership. NEVER. U HAVE RIGHTS. Do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328896559410462722",
    "text" : "NEVER allow them 2 take your dog, even to \"hold\". NEVER sign any papers relinquishing ur ownership. NEVER. U HAVE RIGHTS. Don't give them up",
    "id" : 328896559410462722,
    "created_at" : "2013-04-29 15:40:25 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 328900453939159040,
  "created_at" : "2013-04-29 15:55:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328900429377306627",
  "text" : "RT @petsalive: NO ONE CAN TAKE YOUR DOG EVEN AFTER A BITE without you having an opportunity to go through the legal system and fight it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328896286143164416",
    "text" : "NO ONE CAN TAKE YOUR DOG EVEN AFTER A BITE without you having an opportunity to go through the legal system and fight it.",
    "id" : 328896286143164416,
    "created_at" : "2013-04-29 15:39:19 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 328900429377306627,
  "created_at" : "2013-04-29 15:55:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328900313111212032",
  "text" : "RT @petsalive: In order for ANY official to TAKE your dog it would have to be ordered by a SITTING JUDGE &amp; YOU WOULD legally have your \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328895950791778304",
    "text" : "In order for ANY official to TAKE your dog it would have to be ordered by a SITTING JUDGE &amp; YOU WOULD legally have your day in court",
    "id" : 328895950791778304,
    "created_at" : "2013-04-29 15:37:59 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 328900313111212032,
  "created_at" : "2013-04-29 15:55:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328900293859348481",
  "text" : "RT @petsalive: I would also like to remind everyone that no matter WHAT YOUR DOG DOES - DO NOT EVER SURRENDER HIM. No one can TAKE your dog\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328895778674335744",
    "text" : "I would also like to remind everyone that no matter WHAT YOUR DOG DOES - DO NOT EVER SURRENDER HIM. No one can TAKE your dog from you.",
    "id" : 328895778674335744,
    "created_at" : "2013-04-29 15:37:18 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 328900293859348481,
  "created_at" : "2013-04-29 15:55:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Morger",
      "screen_name" : "linkytools",
      "indices" : [ 3, 14 ],
      "id_str" : "1625925218",
      "id" : 1625925218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328890425475727361",
  "text" : "RT @LinkyTools: You only need a tiny sliver of the customer market at $1\/month to make a nice income.  What service or product could you of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328890164585824257",
    "text" : "You only need a tiny sliver of the customer market at $1\/month to make a nice income.  What service or product could you offer at $1\/month?",
    "id" : 328890164585824257,
    "created_at" : "2013-04-29 15:15:00 +0000",
    "user" : {
      "name" : "Brent Riggs - Linky",
      "screen_name" : "LinkyBlog",
      "protected" : false,
      "id_str" : "333649438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000189810515\/0a1b9624a3f8dd86d2c419829c357e7b_normal.png",
      "id" : 333649438,
      "verified" : false
    }
  },
  "id" : 328890425475727361,
  "created_at" : "2013-04-29 15:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328873594333560832",
  "text" : "nothing is fair...",
  "id" : 328873594333560832,
  "created_at" : "2013-04-29 14:09:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin-Health Nut News",
      "screen_name" : "unhealthytruth",
      "indices" : [ 3, 18 ],
      "id_str" : "18093097",
      "id" : 18093097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328871199713136640",
  "text" : "RT @unhealthytruth: Europe stares down chemical industry to enforce world's first continent-wide ban on widely used insecticides linked to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328870240584884227",
    "text" : "Europe stares down chemical industry to enforce world's first continent-wide ban on widely used insecticides linked to serious harm in bees",
    "id" : 328870240584884227,
    "created_at" : "2013-04-29 13:55:50 +0000",
    "user" : {
      "name" : "Robyn O'Brien",
      "screen_name" : "foodawakenings",
      "protected" : false,
      "id_str" : "25056239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684904916184256512\/Zr_EBvr0_normal.jpg",
      "id" : 25056239,
      "verified" : false
    }
  },
  "id" : 328871199713136640,
  "created_at" : "2013-04-29 13:59:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/aMnxMHXTgF",
      "expanded_url" : "http:\/\/su.pr\/9R7DQa",
      "display_url" : "su.pr\/9R7DQa"
    } ]
  },
  "geo" : { },
  "id_str" : "328641251291312130",
  "text" : "RT @holycutenesss: Baby bat wants milk http:\/\/t.co\/aMnxMHXTgF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/aMnxMHXTgF",
        "expanded_url" : "http:\/\/su.pr\/9R7DQa",
        "display_url" : "su.pr\/9R7DQa"
      } ]
    },
    "geo" : { },
    "id_str" : "328640649375129600",
    "text" : "Baby bat wants milk http:\/\/t.co\/aMnxMHXTgF",
    "id" : 328640649375129600,
    "created_at" : "2013-04-28 22:43:31 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 328641251291312130,
  "created_at" : "2013-04-28 22:45:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Pastor Mark Driscoll",
      "screen_name" : "PastorMark",
      "indices" : [ 93, 104 ],
      "id_str" : "4276531",
      "id" : 4276531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328638302997581825",
  "text" : "RT @micahjmurray: \u201CYou can always tell a rebel\u00ADlious evangel\u00ADi\u00ADcal. They do word studies.\u201D - @PastorMark",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pastor Mark Driscoll",
        "screen_name" : "PastorMark",
        "indices" : [ 75, 86 ],
        "id_str" : "4276531",
        "id" : 4276531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328637340941680640",
    "text" : "\u201CYou can always tell a rebel\u00ADlious evangel\u00ADi\u00ADcal. They do word studies.\u201D - @PastorMark",
    "id" : 328637340941680640,
    "created_at" : "2013-04-28 22:30:22 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 328638302997581825,
  "created_at" : "2013-04-28 22:34:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Jones",
      "screen_name" : "jonestony",
      "indices" : [ 3, 13 ],
      "id_str" : "4334981",
      "id" : 4334981
    }, {
      "name" : "Dan Wilkinson",
      "screen_name" : "CoolingTwilight",
      "indices" : [ 16, 32 ],
      "id_str" : "906684116",
      "id" : 906684116
    }, {
      "name" : "Pastor Mark Driscoll",
      "screen_name" : "PastorMark",
      "indices" : [ 121, 132 ],
      "id_str" : "4276531",
      "id" : 4276531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/JDWAiFb2aS",
      "expanded_url" : "http:\/\/wp.me\/p2LYEl-AL",
      "display_url" : "wp.me\/p2LYEl-AL"
    } ]
  },
  "geo" : { },
  "id_str" : "328638007466921984",
  "text" : "RT @jonestony: \u201C@CoolingTwilight: New post: Mark Driscoll doesn't want you to study the Bible http:\/\/t.co\/JDWAiFb2aS\u201D \/\/ @pastormark",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dan Wilkinson",
        "screen_name" : "CoolingTwilight",
        "indices" : [ 1, 17 ],
        "id_str" : "906684116",
        "id" : 906684116
      }, {
        "name" : "Pastor Mark Driscoll",
        "screen_name" : "PastorMark",
        "indices" : [ 106, 117 ],
        "id_str" : "4276531",
        "id" : 4276531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/JDWAiFb2aS",
        "expanded_url" : "http:\/\/wp.me\/p2LYEl-AL",
        "display_url" : "wp.me\/p2LYEl-AL"
      } ]
    },
    "in_reply_to_status_id_str" : "328624769262039040",
    "geo" : { },
    "id_str" : "328636189512970243",
    "in_reply_to_user_id" : 906684116,
    "text" : "\u201C@CoolingTwilight: New post: Mark Driscoll doesn't want you to study the Bible http:\/\/t.co\/JDWAiFb2aS\u201D \/\/ @pastormark",
    "id" : 328636189512970243,
    "in_reply_to_status_id" : 328624769262039040,
    "created_at" : "2013-04-28 22:25:48 +0000",
    "in_reply_to_screen_name" : "CoolingTwilight",
    "in_reply_to_user_id_str" : "906684116",
    "user" : {
      "name" : "Tony Jones",
      "screen_name" : "jonestony",
      "protected" : false,
      "id_str" : "4334981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433699121224876032\/A3RqA0sa_normal.jpeg",
      "id" : 4334981,
      "verified" : false
    }
  },
  "id" : 328638007466921984,
  "created_at" : "2013-04-28 22:33:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Marsh",
      "screen_name" : "marshjs90",
      "indices" : [ 0, 10 ],
      "id_str" : "1306702638",
      "id" : 1306702638
    }, {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 35, 49 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328615365959643137",
  "geo" : { },
  "id_str" : "328625665412829184",
  "in_reply_to_user_id" : 1306702638,
  "text" : "@marshjs90 yes.. thats me, too : ) @CosmicHominid",
  "id" : 328625665412829184,
  "in_reply_to_status_id" : 328615365959643137,
  "created_at" : "2013-04-28 21:43:58 +0000",
  "in_reply_to_screen_name" : "marshjs90",
  "in_reply_to_user_id_str" : "1306702638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    }, {
      "name" : "James Marsh",
      "screen_name" : "marshjs90",
      "indices" : [ 15, 25 ],
      "id_str" : "1306702638",
      "id" : 1306702638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328618507585609729",
  "geo" : { },
  "id_str" : "328625494012592128",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid @marshjs90 when you're back, i'd love to hear why you disagree w following our intuition.",
  "id" : 328625494012592128,
  "in_reply_to_status_id" : 328618507585609729,
  "created_at" : "2013-04-28 21:43:17 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328613540355268608",
  "geo" : { },
  "id_str" : "328614888010309634",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid hence my eternal existential crisis..lol. dont be sorry. my life is good. im blessed w good ppl in it. : )",
  "id" : 328614888010309634,
  "in_reply_to_status_id" : 328613540355268608,
  "created_at" : "2013-04-28 21:01:09 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328609516914618368",
  "geo" : { },
  "id_str" : "328612033081769986",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid im 47 and still trying to figure out \"what to do with my life\" o-O",
  "id" : 328612033081769986,
  "in_reply_to_status_id" : 328609516914618368,
  "created_at" : "2013-04-28 20:49:48 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328609516914618368",
  "geo" : { },
  "id_str" : "328611784044998657",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid no, im not living FOR the afterlife.. just something i think about. and no, i dont live this life. im just waiting to die.",
  "id" : 328611784044998657,
  "in_reply_to_status_id" : 328609516914618368,
  "created_at" : "2013-04-28 20:48:49 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/jUdxj7iP0o",
      "expanded_url" : "http:\/\/via.me\/-bpevy36",
      "display_url" : "via.me\/-bpevy36"
    } ]
  },
  "geo" : { },
  "id_str" : "328610697170792449",
  "text" : "We are a Zombie family! http:\/\/t.co\/jUdxj7iP0o",
  "id" : 328610697170792449,
  "created_at" : "2013-04-28 20:44:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328607184302768128",
  "geo" : { },
  "id_str" : "328607879709999104",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid yeah, something like that...",
  "id" : 328607879709999104,
  "in_reply_to_status_id" : 328607184302768128,
  "created_at" : "2013-04-28 20:33:18 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/I8AhxSxnxu",
      "expanded_url" : "http:\/\/via.me\/-bpeo008",
      "display_url" : "via.me\/-bpeo008"
    } ]
  },
  "geo" : { },
  "id_str" : "328606372293926914",
  "text" : "I just posted a photo on Via.Me http:\/\/t.co\/I8AhxSxnxu",
  "id" : 328606372293926914,
  "created_at" : "2013-04-28 20:27:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 3, 19 ],
      "id_str" : "344209049",
      "id" : 344209049
    }, {
      "name" : "Red Ice Radio",
      "screen_name" : "rediceradio",
      "indices" : [ 116, 128 ],
      "id_str" : "800600344291983360",
      "id" : 800600344291983360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/OZSstA0g6C",
      "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/everything-is-rigged-the-biggest-financial-scandal-yet-20130425",
      "display_url" : "rollingstone.com\/politics\/news\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "328598816452378624",
  "text" : "RT @AlterEgoTrip_Se: http:\/\/t.co\/OZSstA0g6C \"Everything Is Rigged: The Biggest Price-Fixing Scandal Ever\" found via @rediceradio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Red Ice Radio",
        "screen_name" : "rediceradio",
        "indices" : [ 95, 107 ],
        "id_str" : "800600344291983360",
        "id" : 800600344291983360
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/OZSstA0g6C",
        "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/everything-is-rigged-the-biggest-financial-scandal-yet-20130425",
        "display_url" : "rollingstone.com\/politics\/news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "328598518539362304",
    "text" : "http:\/\/t.co\/OZSstA0g6C \"Everything Is Rigged: The Biggest Price-Fixing Scandal Ever\" found via @rediceradio",
    "id" : 328598518539362304,
    "created_at" : "2013-04-28 19:56:06 +0000",
    "user" : {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "protected" : false,
      "id_str" : "344209049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779194958410579968\/qUDtmyLs_normal.jpg",
      "id" : 344209049,
      "verified" : false
    }
  },
  "id" : 328598816452378624,
  "created_at" : "2013-04-28 19:57:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328597122700169216",
  "geo" : { },
  "id_str" : "328598287835873280",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid its not about judgement...",
  "id" : 328598287835873280,
  "in_reply_to_status_id" : 328597122700169216,
  "created_at" : "2013-04-28 19:55:11 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328597122700169216",
  "geo" : { },
  "id_str" : "328598152133357568",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid noo.. more like school.. the better you do, the more choices you have. we're here to learn, experience.",
  "id" : 328598152133357568,
  "in_reply_to_status_id" : 328597122700169216,
  "created_at" : "2013-04-28 19:54:39 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2021",
      "screen_name" : "salwahafiz",
      "indices" : [ 3, 14 ],
      "id_str" : "26468789",
      "id" : 26468789
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/salwahafiz\/status\/314075801047953408\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/hRH9zrZ6I7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFvSRuqCcAARjLX.jpg",
      "id_str" : "314075801056342016",
      "id" : 314075801056342016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFvSRuqCcAARjLX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 975
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 975
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hRH9zrZ6I7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328597023693619200",
  "text" : "RT @salwahafiz: The interesting thing about twitter is that I'm here in ways I can't be out there: http:\/\/t.co\/hRH9zrZ6I7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/salwahafiz\/status\/314075801047953408\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/hRH9zrZ6I7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFvSRuqCcAARjLX.jpg",
        "id_str" : "314075801056342016",
        "id" : 314075801056342016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFvSRuqCcAARjLX.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 975
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 975
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hRH9zrZ6I7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314075801047953408",
    "text" : "The interesting thing about twitter is that I'm here in ways I can't be out there: http:\/\/t.co\/hRH9zrZ6I7",
    "id" : 314075801047953408,
    "created_at" : "2013-03-19 18:08:01 +0000",
    "user" : {
      "name" : "\u2021",
      "screen_name" : "salwahafiz",
      "protected" : false,
      "id_str" : "26468789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743458288575123456\/eNNlPHhX_normal.jpg",
      "id" : 26468789,
      "verified" : false
    }
  },
  "id" : 328597023693619200,
  "created_at" : "2013-04-28 19:50:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Funny animals",
      "screen_name" : "koralmagic",
      "indices" : [ 17, 28 ],
      "id_str" : "928453831",
      "id" : 928453831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/koralmagic\/status\/328312708837548033\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/LRRCmIvU0P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BI5mq1HCIAAedyg.jpg",
      "id_str" : "328312708841742336",
      "id" : 328312708841742336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BI5mq1HCIAAedyg.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/LRRCmIvU0P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328594621397610496",
  "text" : "RT @gemswinc: RT @koralmagic: White crows http:\/\/t.co\/LRRCmIvU0P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Funny animals",
        "screen_name" : "koralmagic",
        "indices" : [ 3, 14 ],
        "id_str" : "928453831",
        "id" : 928453831
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/koralmagic\/status\/328312708837548033\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/LRRCmIvU0P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BI5mq1HCIAAedyg.jpg",
        "id_str" : "328312708841742336",
        "id" : 328312708841742336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BI5mq1HCIAAedyg.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/LRRCmIvU0P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328593077809840129",
    "text" : "RT @koralmagic: White crows http:\/\/t.co\/LRRCmIvU0P",
    "id" : 328593077809840129,
    "created_at" : "2013-04-28 19:34:29 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 328594621397610496,
  "created_at" : "2013-04-28 19:40:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328594447652749313",
  "text" : "\"Sing it for the world, sing it for the world\nYeah, you got to be what tomorrow needs\" (my chemical romance)",
  "id" : 328594447652749313,
  "created_at" : "2013-04-28 19:39:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328565146777694208",
  "geo" : { },
  "id_str" : "328593326985080832",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid believing in afterlife means more effort.. means what i do creates karmic effect.",
  "id" : 328593326985080832,
  "in_reply_to_status_id" : 328565146777694208,
  "created_at" : "2013-04-28 19:35:28 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328560629558431744",
  "geo" : { },
  "id_str" : "328562258928091137",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid hmm.. yes.. and no. i mean, its work. im lazy. i dont want to put effort into anything.",
  "id" : 328562258928091137,
  "in_reply_to_status_id" : 328560629558431744,
  "created_at" : "2013-04-28 17:32:01 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328558784270172160",
  "geo" : { },
  "id_str" : "328560069392363523",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid well, i like chocolate.. and strawberries.. and sitting in the sun on a fine spring day.. and feeding the birds..",
  "id" : 328560069392363523,
  "in_reply_to_status_id" : 328558784270172160,
  "created_at" : "2013-04-28 17:23:19 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 3, 15 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tommysalami\/status\/328558833175785473\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/fOmj53Z7A0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BI9GhJuCcAAOxlt.jpg",
      "id_str" : "328558833179979776",
      "id" : 328558833179979776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BI9GhJuCcAAOxlt.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fOmj53Z7A0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328559192547926016",
  "text" : "RT @tommysalami: CatLoaf wants to help edit. http:\/\/t.co\/fOmj53Z7A0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tommysalami\/status\/328558833175785473\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/fOmj53Z7A0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BI9GhJuCcAAOxlt.jpg",
        "id_str" : "328558833179979776",
        "id" : 328558833179979776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BI9GhJuCcAAOxlt.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/fOmj53Z7A0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328558833175785473",
    "text" : "CatLoaf wants to help edit. http:\/\/t.co\/fOmj53Z7A0",
    "id" : 328558833175785473,
    "created_at" : "2013-04-28 17:18:25 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 328559192547926016,
  "created_at" : "2013-04-28 17:19:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328555148576186369",
  "geo" : { },
  "id_str" : "328557176396337152",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid i could be totally wrong..absolutely! but it is my conclusion from my totality of experience.",
  "id" : 328557176396337152,
  "in_reply_to_status_id" : 328555148576186369,
  "created_at" : "2013-04-28 17:11:49 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328555148576186369",
  "geo" : { },
  "id_str" : "328556904332795904",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid i believe there is a reason and purpose for our lives.. that we continue on after death.",
  "id" : 328556904332795904,
  "in_reply_to_status_id" : 328555148576186369,
  "created_at" : "2013-04-28 17:10:44 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328555148576186369",
  "geo" : { },
  "id_str" : "328556573632917504",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid i honestly think i would have killed myself long ago if i didnt think there was more to this world than what my senses show",
  "id" : 328556573632917504,
  "in_reply_to_status_id" : 328555148576186369,
  "created_at" : "2013-04-28 17:09:26 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brain",
      "indices" : [ 85, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328554266094604290",
  "text" : "RT @jonlieffmd: Do we see what is outside of us or do we create our own perceptions? #brain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brain",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328551951635738625",
    "text" : "Do we see what is outside of us or do we create our own perceptions? #brain",
    "id" : 328551951635738625,
    "created_at" : "2013-04-28 16:51:04 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 328554266094604290,
  "created_at" : "2013-04-28 17:00:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328545026844000256",
  "geo" : { },
  "id_str" : "328547580969631744",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind you're sending me into insanity..LOL",
  "id" : 328547580969631744,
  "in_reply_to_status_id" : 328545026844000256,
  "created_at" : "2013-04-28 16:33:42 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 0, 14 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328543901914906624",
  "geo" : { },
  "id_str" : "328546690971873280",
  "in_reply_to_user_id" : 1193933845,
  "text" : "@CosmicHominid its useless dealing w physical world.. but helpful for our inner world (for us who are eternally in existential crisis..lol)",
  "id" : 328546690971873280,
  "in_reply_to_status_id" : 328543901914906624,
  "created_at" : "2013-04-28 16:30:09 +0000",
  "in_reply_to_screen_name" : "CosmicHominid",
  "in_reply_to_user_id_str" : "1193933845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328544559569182720",
  "text" : "RT @ZachsMind: It's perception that dicks with us every time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "328543667172306944",
    "text" : "It's perception that dicks with us every time.",
    "id" : 328543667172306944,
    "created_at" : "2013-04-28 16:18:08 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 328544559569182720,
  "created_at" : "2013-04-28 16:21:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328537165170630656",
  "geo" : { },
  "id_str" : "328544262817992705",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind @PtiteMeve ahh.. that line is how i was defining. its still confusing cuz i have to change how im looking at it..lol",
  "id" : 328544262817992705,
  "in_reply_to_status_id" : 328537165170630656,
  "created_at" : "2013-04-28 16:20:30 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328537970510536704",
  "geo" : { },
  "id_str" : "328543144612356096",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind see, to me, they've always been mutually exclusive.. so my perception has to adjust to understand.",
  "id" : 328543144612356096,
  "in_reply_to_status_id" : 328537970510536704,
  "created_at" : "2013-04-28 16:16:04 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328538443644817408",
  "geo" : { },
  "id_str" : "328542595116584960",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind DH and I were watching a show about physical vision.. i was like \"how can we trust anything we see?\" ..was interesting.",
  "id" : 328542595116584960,
  "in_reply_to_status_id" : 328538443644817408,
  "created_at" : "2013-04-28 16:13:53 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "328515949412110337",
  "geo" : { },
  "id_str" : "328528745923215361",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind @PtiteMeve im STILL confused over atheism \/ agnosticism distinctions.. LOL",
  "id" : 328528745923215361,
  "in_reply_to_status_id" : 328515949412110337,
  "created_at" : "2013-04-28 15:18:51 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LSHarter",
      "screen_name" : "L_SHarter",
      "indices" : [ 3, 13 ],
      "id_str" : "1252607532",
      "id" : 1252607532
    }, {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 15, 29 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 30, 43 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328526983250182147",
  "text" : "RT @L_SHarter: @CosmicHominid @DeepakChopra Intense! Next time I will have coffee before I follow your feed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cosmic Hominid",
        "screen_name" : "CosmicHominid",
        "indices" : [ 0, 14 ],
        "id_str" : "1193933845",
        "id" : 1193933845
      }, {
        "name" : "Deepak Chopra",
        "screen_name" : "DeepakChopra",
        "indices" : [ 15, 28 ],
        "id_str" : "15588657",
        "id" : 15588657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "328499744139796480",
    "geo" : { },
    "id_str" : "328501287152930816",
    "in_reply_to_user_id" : 1193933845,
    "text" : "@CosmicHominid @DeepakChopra Intense! Next time I will have coffee before I follow your feed.",
    "id" : 328501287152930816,
    "in_reply_to_status_id" : 328499744139796480,
    "created_at" : "2013-04-28 13:29:44 +0000",
    "in_reply_to_screen_name" : "CosmicHominid",
    "in_reply_to_user_id_str" : "1193933845",
    "user" : {
      "name" : "LSHarter",
      "screen_name" : "L_SHarter",
      "protected" : false,
      "id_str" : "1252607532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3625610316\/95f81fda6bf51555d00b5bf67b10cfea_normal.jpeg",
      "id" : 1252607532,
      "verified" : false
    }
  },
  "id" : 328526983250182147,
  "created_at" : "2013-04-28 15:11:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Agbara Kelechi",
      "screen_name" : "dr_spex",
      "indices" : [ 87, 95 ],
      "id_str" : "186984478",
      "id" : 186984478
    }, {
      "name" : "Cosmic Hominid",
      "screen_name" : "CosmicHominid",
      "indices" : [ 96, 110 ],
      "id_str" : "1193933845",
      "id" : 1193933845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328525791761674241",
  "text" : "RT @DeepakChopra: The universe itself is a living organism known thru living organisms @dr_spex @CosmicHominid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Agbara Kelechi",
        "screen_name" : "dr_spex",
        "indices" : [ 69, 77 ],
        "id_str" : "186984478",
        "id" : 186984478
      }, {
        "name" : "Cosmic Hominid",
        "screen_name" : "CosmicHominid",
        "indices" : [ 78, 92 ],
        "id_str" : "1193933845",
        "id" : 1193933845
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "328518761747460097",
    "geo" : { },
    "id_str" : "328518993046560769",
    "in_reply_to_user_id" : 186984478,
    "text" : "The universe itself is a living organism known thru living organisms @dr_spex @CosmicHominid",
    "id" : 328518993046560769,
    "in_reply_to_status_id" : 328518761747460097,
    "created_at" : "2013-04-28 14:40:06 +0000",
    "in_reply_to_screen_name" : "dr_spex",
    "in_reply_to_user_id_str" : "186984478",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 328525791761674241,
  "created_at" : "2013-04-28 15:07:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 84, 94 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/u1IkEp7lyQ",
      "expanded_url" : "http:\/\/shar.es\/lmhnl",
      "display_url" : "shar.es\/lmhnl"
    } ]
  },
  "geo" : { },
  "id_str" : "328209927325745152",
  "text" : "CPS Takes Baby After Parents Seek Second Medical Opinion http:\/\/t.co\/u1IkEp7lyQ via @sharethis",
  "id" : 328209927325745152,
  "created_at" : "2013-04-27 18:11:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 27, 41 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/LHK8E1oZNY",
      "expanded_url" : "http:\/\/huff.to\/1623WVy",
      "display_url" : "huff.to\/1623WVy"
    } ]
  },
  "in_reply_to_status_id_str" : "328154186556506112",
  "geo" : { },
  "id_str" : "328155834448244736",
  "in_reply_to_user_id" : 125567504,
  "text" : "crap.. now im sobbing.. RT @HuffPostWeird Dog mourns death of beaver friend http:\/\/t.co\/LHK8E1oZNY",
  "id" : 328155834448244736,
  "in_reply_to_status_id" : 328154186556506112,
  "created_at" : "2013-04-27 14:37:02 +0000",
  "in_reply_to_screen_name" : "HuffPostWeird",
  "in_reply_to_user_id_str" : "125567504",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Care 4 All CO",
      "screen_name" : "HCAC",
      "indices" : [ 3, 8 ],
      "id_str" : "33272036",
      "id" : 33272036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327929140739190785",
  "text" : "RT @HCAC: Dr. Diljeet Singh: Having for-profit payers creates paradox -- health care system that avoids the sick.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325800799575891968",
    "text" : "Dr. Diljeet Singh: Having for-profit payers creates paradox -- health care system that avoids the sick.",
    "id" : 325800799575891968,
    "created_at" : "2013-04-21 02:38:58 +0000",
    "user" : {
      "name" : "Health Care 4 All CO",
      "screen_name" : "HCAC",
      "protected" : false,
      "id_str" : "33272036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2648902514\/1a0ec5dd835f7e278fd5621163fe51eb_normal.jpeg",
      "id" : 33272036,
      "verified" : false
    }
  },
  "id" : 327929140739190785,
  "created_at" : "2013-04-26 23:36:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Pedicini",
      "screen_name" : "ArthurA_P",
      "indices" : [ 3, 13 ],
      "id_str" : "93419194",
      "id" : 93419194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327923010306703360",
  "text" : "RT @ArthurA_P: INDOCTRINATION: Mississippi School Forces Students To Listen To Christian Lecture, Teachers Block Exits http:\/\/t.co\/vnPt7YPg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UniteBlue",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/vnPt7YPgY4",
        "expanded_url" : "http:\/\/p.ost.im\/p\/dXHWDg",
        "display_url" : "p.ost.im\/p\/dXHWDg"
      } ]
    },
    "geo" : { },
    "id_str" : "327921368735813636",
    "text" : "INDOCTRINATION: Mississippi School Forces Students To Listen To Christian Lecture, Teachers Block Exits http:\/\/t.co\/vnPt7YPgY4 #UniteBlue",
    "id" : 327921368735813636,
    "created_at" : "2013-04-26 23:05:21 +0000",
    "user" : {
      "name" : "Arthur Pedicini",
      "screen_name" : "ArthurA_P",
      "protected" : false,
      "id_str" : "93419194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3199302852\/95be66eeace17ffb1acd5f6e6fe74bfb_normal.png",
      "id" : 93419194,
      "verified" : false
    }
  },
  "id" : 327923010306703360,
  "created_at" : "2013-04-26 23:11:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327922644609540096",
  "text" : "my inside of my nose is on fire...",
  "id" : 327922644609540096,
  "created_at" : "2013-04-26 23:10:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Music",
      "screen_name" : "amazonmp3",
      "indices" : [ 3, 13 ],
      "id_str" : "26426173",
      "id" : 26426173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327915848205471744",
  "text" : "RT @amazonmp3: Time for a new Kindle case, charger or stylus? Get a $2 MP3 credit when you buy select Kindle accessories: http:\/\/t.co\/JEZSa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/JEZSaPewuO",
        "expanded_url" : "http:\/\/amzn.to\/Yaeuj4",
        "display_url" : "amzn.to\/Yaeuj4"
      } ]
    },
    "geo" : { },
    "id_str" : "327903459733037056",
    "text" : "Time for a new Kindle case, charger or stylus? Get a $2 MP3 credit when you buy select Kindle accessories: http:\/\/t.co\/JEZSaPewuO",
    "id" : 327903459733037056,
    "created_at" : "2013-04-26 21:54:11 +0000",
    "user" : {
      "name" : "Amazon Music",
      "screen_name" : "amazonmusic",
      "protected" : false,
      "id_str" : "14740219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786102643877900288\/EFFYay70_normal.jpg",
      "id" : 14740219,
      "verified" : true
    }
  },
  "id" : 327915848205471744,
  "created_at" : "2013-04-26 22:43:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/7SkkKuAci2",
      "expanded_url" : "http:\/\/money.cnn.com\/2013\/04\/26\/news\/economy\/health-care-cost\/index.html",
      "display_url" : "money.cnn.com\/2013\/04\/26\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327914832185663488",
  "text" : "RT @AllOnMedicare: Last year, 53 MILLION Americans couldn't visit a physician due to inability to pay. http:\/\/t.co\/7SkkKuAci2 #SinglePayer \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 107, 119 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 120, 135 ]
      }, {
        "text" : "p2",
        "indices" : [ 136, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/7SkkKuAci2",
        "expanded_url" : "http:\/\/money.cnn.com\/2013\/04\/26\/news\/economy\/health-care-cost\/index.html",
        "display_url" : "money.cnn.com\/2013\/04\/26\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327909153756573697",
    "text" : "Last year, 53 MILLION Americans couldn't visit a physician due to inability to pay. http:\/\/t.co\/7SkkKuAci2 #SinglePayer #MedicareForAll #p2",
    "id" : 327909153756573697,
    "created_at" : "2013-04-26 22:16:49 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 327914832185663488,
  "created_at" : "2013-04-26 22:39:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7SkkKuAci2",
      "expanded_url" : "http:\/\/money.cnn.com\/2013\/04\/26\/news\/economy\/health-care-cost\/index.html",
      "display_url" : "money.cnn.com\/2013\/04\/26\/new\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327914740892438528",
  "text" : "RT @AllOnMedicare: Last year, 50 MILLION Americans couldn't fill a prescription due to inability to pay http:\/\/t.co\/7SkkKuAci2 #SinglePayer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 108, 120 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 121, 136 ]
      }, {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/7SkkKuAci2",
        "expanded_url" : "http:\/\/money.cnn.com\/2013\/04\/26\/news\/economy\/health-care-cost\/index.html",
        "display_url" : "money.cnn.com\/2013\/04\/26\/new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327909413023256577",
    "text" : "Last year, 50 MILLION Americans couldn't fill a prescription due to inability to pay http:\/\/t.co\/7SkkKuAci2 #SinglePayer #MedicareForAll #p2",
    "id" : 327909413023256577,
    "created_at" : "2013-04-26 22:17:50 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 327914740892438528,
  "created_at" : "2013-04-26 22:39:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AHIP",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "Aetna",
      "indices" : [ 117, 123 ]
    }, {
      "text" : "Cigna",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327914586244263936",
  "text" : "RT @AllOnMedicare: This year, almost 50,000 Americans will DIE due to lack of health insurance. Shame on you: #AHIP, #Aetna, #Cigna, #WellP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AHIP",
        "indices" : [ 91, 96 ]
      }, {
        "text" : "Aetna",
        "indices" : [ 98, 104 ]
      }, {
        "text" : "Cigna",
        "indices" : [ 106, 112 ]
      }, {
        "text" : "WellPoint",
        "indices" : [ 114, 124 ]
      }, {
        "text" : "Humana",
        "indices" : [ 126, 133 ]
      }, {
        "text" : "p2",
        "indices" : [ 134, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327909737817571328",
    "text" : "This year, almost 50,000 Americans will DIE due to lack of health insurance. Shame on you: #AHIP, #Aetna, #Cigna, #WellPoint, #Humana #p2",
    "id" : 327909737817571328,
    "created_at" : "2013-04-26 22:19:08 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 327914586244263936,
  "created_at" : "2013-04-26 22:38:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/e1OQ5TnxW9",
      "expanded_url" : "http:\/\/su.pr\/5w60db",
      "display_url" : "su.pr\/5w60db"
    } ]
  },
  "geo" : { },
  "id_str" : "327886196367818752",
  "text" : "RT @holycutenesss: Wild otter jumps into car http:\/\/t.co\/e1OQ5TnxW9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/e1OQ5TnxW9",
        "expanded_url" : "http:\/\/su.pr\/5w60db",
        "display_url" : "su.pr\/5w60db"
      } ]
    },
    "geo" : { },
    "id_str" : "327884393299460097",
    "text" : "Wild otter jumps into car http:\/\/t.co\/e1OQ5TnxW9",
    "id" : 327884393299460097,
    "created_at" : "2013-04-26 20:38:25 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 327886196367818752,
  "created_at" : "2013-04-26 20:45:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Paul Turner",
      "screen_name" : "JesusNeedsNewPR",
      "indices" : [ 3, 19 ],
      "id_str" : "727580030084251648",
      "id" : 727580030084251648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4AbFvG4iW2",
      "expanded_url" : "http:\/\/www.matthewpaulturner.com\/blog\/2013\/4\/26\/mark-driscolls-compares-nagging-wives",
      "display_url" : "matthewpaulturner.com\/blog\/2013\/4\/26\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327884473217724416",
  "text" : "RT @JesusNeedsNewPR: Mark Driscoll says a \"nagging wife\" is like Chinese water torture, life sentence in jail... http:\/\/t.co\/4AbFvG4iW2 #My\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyThoughts",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/4AbFvG4iW2",
        "expanded_url" : "http:\/\/www.matthewpaulturner.com\/blog\/2013\/4\/26\/mark-driscolls-compares-nagging-wives",
        "display_url" : "matthewpaulturner.com\/blog\/2013\/4\/26\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327878348221079552",
    "text" : "Mark Driscoll says a \"nagging wife\" is like Chinese water torture, life sentence in jail... http:\/\/t.co\/4AbFvG4iW2 #MyThoughts",
    "id" : 327878348221079552,
    "created_at" : "2013-04-26 20:14:24 +0000",
    "user" : {
      "name" : "Matthew Paul Turner",
      "screen_name" : "HeyMPT",
      "protected" : false,
      "id_str" : "10206812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749619882552098816\/HgjwUHtr_normal.jpg",
      "id" : 10206812,
      "verified" : false
    }
  },
  "id" : 327884473217724416,
  "created_at" : "2013-04-26 20:38:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "norwind",
      "screen_name" : "norwind",
      "indices" : [ 3, 11 ],
      "id_str" : "17545469",
      "id" : 17545469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327882978028036096",
  "text" : "RT @norwind: .But we have no money for Social Security? WTF | Syrian Rebels To Receive $123 Million More In Aid From United States http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2w3h47Gq4Q",
        "expanded_url" : "http:\/\/southweb.org\/blog\/syrian-rebels-to-receive-123-mi",
        "display_url" : "southweb.org\/blog\/syrian-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327879351767027713",
    "text" : ".But we have no money for Social Security? WTF | Syrian Rebels To Receive $123 Million More In Aid From United States http:\/\/t.co\/2w3h47Gq4Q",
    "id" : 327879351767027713,
    "created_at" : "2013-04-26 20:18:23 +0000",
    "user" : {
      "name" : "norwind",
      "screen_name" : "norwind",
      "protected" : false,
      "id_str" : "17545469",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423696712947884032\/16gB03Hk_normal.jpeg",
      "id" : 17545469,
      "verified" : false
    }
  },
  "id" : 327882978028036096,
  "created_at" : "2013-04-26 20:32:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "les cooper",
      "screen_name" : "flywildflyfree",
      "indices" : [ 3, 18 ],
      "id_str" : "23470034",
      "id" : 23470034
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/327851016886292481\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/XJnB5BRImC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIzCw0kCEAIH2Jq.jpg",
      "id_str" : "327851016890486786",
      "id" : 327851016890486786,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIzCw0kCEAIH2Jq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1495,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XJnB5BRImC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327854668468334592",
  "text" : "RT @flywildflyfree: all alone http:\/\/t.co\/XJnB5BRImC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/327851016886292481\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/XJnB5BRImC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BIzCw0kCEAIH2Jq.jpg",
        "id_str" : "327851016890486786",
        "id" : 327851016890486786,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIzCw0kCEAIH2Jq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1495,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 748,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XJnB5BRImC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327851016886292481",
    "text" : "all alone http:\/\/t.co\/XJnB5BRImC",
    "id" : 327851016886292481,
    "created_at" : "2013-04-26 18:25:48 +0000",
    "user" : {
      "name" : "les cooper",
      "screen_name" : "flywildflyfree",
      "protected" : false,
      "id_str" : "23470034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000033775910\/154418c4011969db884eff317a450dd3_normal.jpeg",
      "id" : 23470034,
      "verified" : false
    }
  },
  "id" : 327854668468334592,
  "created_at" : "2013-04-26 18:40:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/hTIJVDDjtX",
      "expanded_url" : "http:\/\/huff.to\/182iBMU",
      "display_url" : "huff.to\/182iBMU"
    } ]
  },
  "geo" : { },
  "id_str" : "327850499879608320",
  "text" : "RT @HuffPostWeird: LOOK: Sex-ed book for first graders may be NSFW http:\/\/t.co\/hTIJVDDjtX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/hTIJVDDjtX",
        "expanded_url" : "http:\/\/huff.to\/182iBMU",
        "display_url" : "huff.to\/182iBMU"
      } ]
    },
    "geo" : { },
    "id_str" : "327848342774222849",
    "text" : "LOOK: Sex-ed book for first graders may be NSFW http:\/\/t.co\/hTIJVDDjtX",
    "id" : 327848342774222849,
    "created_at" : "2013-04-26 18:15:10 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 327850499879608320,
  "created_at" : "2013-04-26 18:23:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/ergJlyV1UR",
      "expanded_url" : "http:\/\/www.moosebegab.com",
      "display_url" : "moosebegab.com"
    } ]
  },
  "geo" : { },
  "id_str" : "327833517759295488",
  "text" : "btw... my website is back up : ) &gt;&gt; http:\/\/t.co\/ergJlyV1UR",
  "id" : 327833517759295488,
  "created_at" : "2013-04-26 17:16:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Physicians Committee",
      "screen_name" : "PCRM",
      "indices" : [ 44, 49 ],
      "id_str" : "38048560",
      "id" : 38048560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327824261945360384",
  "text" : "RT @SangyeH: Folks, beware of a petition by @PCRM called \"SNAP Transparency Act.\" It's a bill that BANS foodstamps recipients from buying m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Physicians Committee",
        "screen_name" : "PCRM",
        "indices" : [ 31, 36 ],
        "id_str" : "38048560",
        "id" : 38048560
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327807382988140544",
    "text" : "Folks, beware of a petition by @PCRM called \"SNAP Transparency Act.\" It's a bill that BANS foodstamps recipients from buying meat.",
    "id" : 327807382988140544,
    "created_at" : "2013-04-26 15:32:25 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 327824261945360384,
  "created_at" : "2013-04-26 16:39:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 104, 113 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jonstewart",
      "indices" : [ 8, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/W5bmVM6OvM",
      "expanded_url" : "http:\/\/www.upworthy.com\/its-official-fox-news-just-hit-rock-bottom-hard-and-repeatedly-3?g=2&c=cp1",
      "display_url" : "upworthy.com\/its-official-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327821946857345024",
  "text" : "i &lt;3 #jonstewart &gt;&gt; Is some comedic genius making Fox News a living parody of itself now? (via @Upworthy) http:\/\/t.co\/W5bmVM6OvM",
  "id" : 327821946857345024,
  "created_at" : "2013-04-26 16:30:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327563322968903680",
  "text" : "RT @AllOnMedicare: How do health insurance executives sleep at night when they profit from denying care? Yes, they profit when they don't p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 133, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327561478708285440",
    "text" : "How do health insurance executives sleep at night when they profit from denying care? Yes, they profit when they don't provide care. #p2",
    "id" : 327561478708285440,
    "created_at" : "2013-04-25 23:15:16 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 327563322968903680,
  "created_at" : "2013-04-25 23:22:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327560182383120384",
  "text" : "RT @CoyoteSings: \"At the bottom of the well, the frog thinks the sky is as big as the top of the well.\" -unknown (and paraphrased)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327556410953043968",
    "text" : "\"At the bottom of the well, the frog thinks the sky is as big as the top of the well.\" -unknown (and paraphrased)",
    "id" : 327556410953043968,
    "created_at" : "2013-04-25 22:55:08 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 327560182383120384,
  "created_at" : "2013-04-25 23:10:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FreedomFighterReport",
      "screen_name" : "FFRNewsNet1",
      "indices" : [ 3, 15 ],
      "id_str" : "428081159",
      "id" : 428081159
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WAKINGUP",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "LEFT",
      "indices" : [ 72, 77 ]
    }, {
      "text" : "RIGHT",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "DESTROY",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "FREEDOM",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327411414962679808",
  "text" : "RT @FFRNewsNet1: #WAKINGUP IT HAS NEVER EVER BEEN MORE OBVIOUS THAT THE #LEFT &amp; #RIGHT ARE WORKING TOGETHER TO #DESTROY #FREEDOM http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WAKINGUP",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "LEFT",
        "indices" : [ 55, 60 ]
      }, {
        "text" : "RIGHT",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "DESTROY",
        "indices" : [ 98, 106 ]
      }, {
        "text" : "FREEDOM",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/kn5eKrs07d",
        "expanded_url" : "http:\/\/youtu.be\/jAdu0N1-tvU?t=18s",
        "display_url" : "youtu.be\/jAdu0N1-tvU?t=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "327376516705026048",
    "text" : "#WAKINGUP IT HAS NEVER EVER BEEN MORE OBVIOUS THAT THE #LEFT &amp; #RIGHT ARE WORKING TOGETHER TO #DESTROY #FREEDOM http:\/\/t.co\/kn5eKrs07d",
    "id" : 327376516705026048,
    "created_at" : "2013-04-25 11:00:18 +0000",
    "user" : {
      "name" : "FreedomFighterReport",
      "screen_name" : "FFRNewsNet1",
      "protected" : false,
      "id_str" : "428081159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1673061660\/landofthefree_normal.jpg",
      "id" : 428081159,
      "verified" : false
    }
  },
  "id" : 327411414962679808,
  "created_at" : "2013-04-25 13:18:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327215660226711552",
  "geo" : { },
  "id_str" : "327410623191334913",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind haha.. ((pinchesyourcheeks))",
  "id" : 327410623191334913,
  "in_reply_to_status_id" : 327215660226711552,
  "created_at" : "2013-04-25 13:15:50 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/tF9pSklagE",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2013\/04\/texas-judge-says-animal-snuff-films-are-constitutional\/",
      "display_url" : "lifewithdogs.tv\/2013\/04\/texas-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327214791091433473",
  "text" : "Texas Judge Says Animal Snuff Films Are Constitutional http:\/\/t.co\/tF9pSklagE",
  "id" : 327214791091433473,
  "created_at" : "2013-04-25 00:17:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327213866289344513",
  "text" : "having tea w my honey...",
  "id" : 327213866289344513,
  "created_at" : "2013-04-25 00:13:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327207409833627648",
  "geo" : { },
  "id_str" : "327211705102913536",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind what did i say now.... o-O",
  "id" : 327211705102913536,
  "in_reply_to_status_id" : 327207409833627648,
  "created_at" : "2013-04-25 00:05:24 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327138577165197313",
  "text" : "RT @Buddhaworld: Paradise is within. The outside world is only decoration. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327131685265219585",
    "text" : "Paradise is within. The outside world is only decoration. Buddha volko",
    "id" : 327131685265219585,
    "created_at" : "2013-04-24 18:47:26 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 327138577165197313,
  "created_at" : "2013-04-24 19:14:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "indices" : [ 3, 18 ],
      "id_str" : "18725718",
      "id" : 18725718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/W3Z0ALTpux",
      "expanded_url" : "http:\/\/shar.es\/JRxBD",
      "display_url" : "shar.es\/JRxBD"
    } ]
  },
  "geo" : { },
  "id_str" : "327103957770055680",
  "text" : "RT @christianpiatt: A Bible Study for Heretics: A Q&amp;A with Christian Piatt http:\/\/t.co\/W3Z0ALTpux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/W3Z0ALTpux",
        "expanded_url" : "http:\/\/shar.es\/JRxBD",
        "display_url" : "shar.es\/JRxBD"
      } ]
    },
    "geo" : { },
    "id_str" : "327101515175170048",
    "text" : "A Bible Study for Heretics: A Q&amp;A with Christian Piatt http:\/\/t.co\/W3Z0ALTpux",
    "id" : 327101515175170048,
    "created_at" : "2013-04-24 16:47:33 +0000",
    "user" : {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "protected" : false,
      "id_str" : "18725718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765072572337704960\/hMj5pUf0_normal.jpg",
      "id" : 18725718,
      "verified" : false
    }
  },
  "id" : 327103957770055680,
  "created_at" : "2013-04-24 16:57:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327094783694745600",
  "geo" : { },
  "id_str" : "327100260507848704",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves oh my lord.. would you pick a name and stick w it?! LOLOL",
  "id" : 327100260507848704,
  "in_reply_to_status_id" : 327094783694745600,
  "created_at" : "2013-04-24 16:42:33 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgia Herring",
      "screen_name" : "LaGrangeHistory",
      "indices" : [ 3, 19 ],
      "id_str" : "1135628857",
      "id" : 1135628857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327099043178221568",
  "text" : "RT @LaGrangeHistory: Millbrook Moose is on the Loose!  Yesterday he was spotted near my neighborhood - at the Arlington High School parking\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "327095674363596801",
    "text" : "Millbrook Moose is on the Loose!  Yesterday he was spotted near my neighborhood - at the Arlington High School parking lot in LaGrange!",
    "id" : 327095674363596801,
    "created_at" : "2013-04-24 16:24:20 +0000",
    "user" : {
      "name" : "Georgia Herring",
      "screen_name" : "LaGrangeHistory",
      "protected" : false,
      "id_str" : "1135628857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472414152925786112\/DBRWfFvS_normal.jpeg",
      "id" : 1135628857,
      "verified" : false
    }
  },
  "id" : 327099043178221568,
  "created_at" : "2013-04-24 16:37:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amreading",
      "indices" : [ 118, 128 ]
    }, {
      "text" : "romance",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/aXUygeN8hj",
      "expanded_url" : "http:\/\/ow.ly\/ki9dk",
      "display_url" : "ow.ly\/ki9dk"
    } ]
  },
  "geo" : { },
  "id_str" : "327082739021000705",
  "text" : "RT @JAScribbles: I loved this book so much I'm gifting one copy to a lucky winner. Enter here: http:\/\/t.co\/aXUygeN8hj #amreading #romance #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amreading",
        "indices" : [ 101, 111 ]
      }, {
        "text" : "romance",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "giveaway",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/aXUygeN8hj",
        "expanded_url" : "http:\/\/ow.ly\/ki9dk",
        "display_url" : "ow.ly\/ki9dk"
      } ]
    },
    "geo" : { },
    "id_str" : "327079671755849728",
    "text" : "I loved this book so much I'm gifting one copy to a lucky winner. Enter here: http:\/\/t.co\/aXUygeN8hj #amreading #romance #giveaway",
    "id" : 327079671755849728,
    "created_at" : "2013-04-24 15:20:45 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 327082739021000705,
  "created_at" : "2013-04-24 15:32:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 13, 25 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Buddhaworld\/status\/327081550850162689\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/IeTx3c0Geb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BIoG8ANCAAAjJyI.jpg",
      "id_str" : "327081550854356992",
      "id" : 327081550854356992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BIoG8ANCAAAjJyI.jpg",
      "sizes" : [ {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 920
      } ],
      "display_url" : "pic.twitter.com\/IeTx3c0Geb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "327081550850162689",
  "geo" : { },
  "id_str" : "327082428172734464",
  "in_reply_to_user_id" : 40560386,
  "text" : "beautiful RT @Buddhaworld http:\/\/t.co\/IeTx3c0Geb",
  "id" : 327082428172734464,
  "in_reply_to_status_id" : 327081550850162689,
  "created_at" : "2013-04-24 15:31:42 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/sSfQPzQYwD",
      "expanded_url" : "http:\/\/amzn.to\/WMae7q",
      "display_url" : "amzn.to\/WMae7q"
    } ]
  },
  "geo" : { },
  "id_str" : "326874509221167104",
  "text" : "finished Locked Away (Book #2 in the Love and Madness series) by Gabriella Murray http:\/\/t.co\/sSfQPzQYwD",
  "id" : 326874509221167104,
  "created_at" : "2013-04-24 01:45:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326864385001783297",
  "text" : "RT @ChickenJen: home tired but happy after testifying in support of ME's Right to Know GMO labeling bill. I spoke as a beekeeper trying to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326862926537445376",
    "text" : "home tired but happy after testifying in support of ME's Right to Know GMO labeling bill. I spoke as a beekeeper trying to save our bees.",
    "id" : 326862926537445376,
    "created_at" : "2013-04-24 00:59:29 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 326864385001783297,
  "created_at" : "2013-04-24 01:05:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 3, 16 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 19, 24 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CISPA",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326495297066901504",
  "text" : "RT @SisterSadist: \u201C@wilw: This #CISPA infographic explains why it's so incredibly evil and wrong and must be stopped. http:\/\/t.co\/JBTqz9ziu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wil Wheaton",
        "screen_name" : "wilw",
        "indices" : [ 1, 6 ],
        "id_str" : "1183041",
        "id" : 1183041
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CISPA",
        "indices" : [ 13, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/JBTqz9ziuT",
        "expanded_url" : "http:\/\/is.gd\/0vzkIb",
        "display_url" : "is.gd\/0vzkIb"
      } ]
    },
    "in_reply_to_status_id_str" : "326491841795072000",
    "geo" : { },
    "id_str" : "326494173672914944",
    "in_reply_to_user_id" : 1183041,
    "text" : "\u201C@wilw: This #CISPA infographic explains why it's so incredibly evil and wrong and must be stopped. http:\/\/t.co\/JBTqz9ziuT\u201D",
    "id" : 326494173672914944,
    "in_reply_to_status_id" : 326491841795072000,
    "created_at" : "2013-04-23 00:34:11 +0000",
    "in_reply_to_screen_name" : "wilw",
    "in_reply_to_user_id_str" : "1183041",
    "user" : {
      "name" : "Cam",
      "screen_name" : "WrathOfCam",
      "protected" : false,
      "id_str" : "20987411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769322135336652801\/9R_a4UjJ_normal.jpg",
      "id" : 20987411,
      "verified" : false
    }
  },
  "id" : 326495297066901504,
  "created_at" : "2013-04-23 00:38:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin",
      "screen_name" : "caulkthewagon",
      "indices" : [ 3, 17 ],
      "id_str" : "14404725",
      "id" : 14404725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326476373017374720",
  "text" : "RT @caulkthewagon: If you take rights away from some, even the worst of the worst, the rights you stand upon every day are eroding beneath \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326465961970524160",
    "text" : "If you take rights away from some, even the worst of the worst, the rights you stand upon every day are eroding beneath your own feet.",
    "id" : 326465961970524160,
    "created_at" : "2013-04-22 22:42:05 +0000",
    "user" : {
      "name" : "Robin",
      "screen_name" : "caulkthewagon",
      "protected" : false,
      "id_str" : "14404725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745314870271287296\/ZKDv59iP_normal.jpg",
      "id" : 14404725,
      "verified" : false
    }
  },
  "id" : 326476373017374720,
  "created_at" : "2013-04-22 23:23:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica",
      "screen_name" : "JessicaGoldstei",
      "indices" : [ 3, 19 ],
      "id_str" : "53490475",
      "id" : 53490475
    }, {
      "name" : "NAACP",
      "screen_name" : "NAACP",
      "indices" : [ 25, 31 ],
      "id_str" : "44988185",
      "id" : 44988185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WarOnDrugs",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326475198054408192",
  "text" : "RT @JessicaGoldstei: via @naacp: \n1 in 9 black kids have incarcerated parents compared to 1 in 57 white kids. end #WarOnDrugs &amp; #ForPro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NAACP",
        "screen_name" : "NAACP",
        "indices" : [ 4, 10 ],
        "id_str" : "44988185",
        "id" : 44988185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WarOnDrugs",
        "indices" : [ 93, 104 ]
      }, {
        "text" : "ForProfitPrisons",
        "indices" : [ 111, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "326473610472603649",
    "text" : "via @naacp: \n1 in 9 black kids have incarcerated parents compared to 1 in 57 white kids. end #WarOnDrugs &amp; #ForProfitPrisons for our kids.",
    "id" : 326473610472603649,
    "created_at" : "2013-04-22 23:12:28 +0000",
    "user" : {
      "name" : "Jessica",
      "screen_name" : "JessicaGoldstei",
      "protected" : false,
      "id_str" : "53490475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721415478539902977\/7cyd8BVE_normal.jpg",
      "id" : 53490475,
      "verified" : false
    }
  },
  "id" : 326475198054408192,
  "created_at" : "2013-04-22 23:18:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326355136681230336",
  "geo" : { },
  "id_str" : "326475069410914304",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad aww, thanks : ) .. still a bit off but much better than this am!",
  "id" : 326475069410914304,
  "in_reply_to_status_id" : 326355136681230336,
  "created_at" : "2013-04-22 23:18:16 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "indices" : [ 3, 17 ],
      "id_str" : "169354425",
      "id" : 169354425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ynBdsYugMj",
      "expanded_url" : "http:\/\/bit.ly\/11ERK6f",
      "display_url" : "bit.ly\/11ERK6f"
    } ]
  },
  "geo" : { },
  "id_str" : "326396909352787968",
  "text" : "RT @MontyMcSquill: File This Under \"Awful News\": Swarm of Bees Kills a Rottweiler in Florida http:\/\/t.co\/ynBdsYugMj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/ynBdsYugMj",
        "expanded_url" : "http:\/\/bit.ly\/11ERK6f",
        "display_url" : "bit.ly\/11ERK6f"
      } ]
    },
    "geo" : { },
    "id_str" : "326388693407510529",
    "text" : "File This Under \"Awful News\": Swarm of Bees Kills a Rottweiler in Florida http:\/\/t.co\/ynBdsYugMj",
    "id" : 326388693407510529,
    "created_at" : "2013-04-22 17:35:03 +0000",
    "user" : {
      "name" : "Monty",
      "screen_name" : "MontyMcSquill",
      "protected" : false,
      "id_str" : "169354425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083700728\/McSquill_normal.jpg",
      "id" : 169354425,
      "verified" : false
    }
  },
  "id" : 326396909352787968,
  "created_at" : "2013-04-22 18:07:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Mary DeMuth",
      "screen_name" : "MaryDeMuth",
      "indices" : [ 100, 111 ],
      "id_str" : "16613700",
      "id" : 16613700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ch1zI0wx6h",
      "expanded_url" : "http:\/\/bit.ly\/ZFNsKq",
      "display_url" : "bit.ly\/ZFNsKq"
    } ]
  },
  "geo" : { },
  "id_str" : "326395980662571008",
  "text" : "RT @micahjmurray: \"I'm sick of hearing about your smokin' hot wife... \" http:\/\/t.co\/ch1zI0wx6h (via @MaryDeMuth)\u00A0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary DeMuth",
        "screen_name" : "MaryDeMuth",
        "indices" : [ 82, 93 ],
        "id_str" : "16613700",
        "id" : 16613700
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/ch1zI0wx6h",
        "expanded_url" : "http:\/\/bit.ly\/ZFNsKq",
        "display_url" : "bit.ly\/ZFNsKq"
      } ]
    },
    "geo" : { },
    "id_str" : "326389972154335235",
    "text" : "\"I'm sick of hearing about your smokin' hot wife... \" http:\/\/t.co\/ch1zI0wx6h (via @MaryDeMuth)\u00A0",
    "id" : 326389972154335235,
    "created_at" : "2013-04-22 17:40:08 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 326395980662571008,
  "created_at" : "2013-04-22 18:04:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Donkey",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/4rIDlHQhiR",
      "expanded_url" : "http:\/\/youtu.be\/9pRh4MAZu10",
      "display_url" : "youtu.be\/9pRh4MAZu10"
    } ]
  },
  "geo" : { },
  "id_str" : "326370409954029568",
  "text" : "#Donkey Rescue in Israel - http:\/\/t.co\/4rIDlHQhiR",
  "id" : 326370409954029568,
  "created_at" : "2013-04-22 16:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326332512886484992",
  "text" : "bleh.. woke up feeling ill today. please go away, sickness.",
  "id" : 326332512886484992,
  "created_at" : "2013-04-22 13:51:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "indices" : [ 3, 16 ],
      "id_str" : "78155553",
      "id" : 78155553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325781004855947266",
  "text" : "RT @angelmagicjp: Love is the flashlight that helps you see through the darkness of fear.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325771500793769984",
    "text" : "Love is the flashlight that helps you see through the darkness of fear.",
    "id" : 325771500793769984,
    "created_at" : "2013-04-21 00:42:32 +0000",
    "user" : {
      "name" : "John and Pam",
      "screen_name" : "angelmagicjp",
      "protected" : false,
      "id_str" : "78155553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1497479357\/Hand_Heart_Sun_2_normal.jpg",
      "id" : 78155553,
      "verified" : false
    }
  },
  "id" : 325781004855947266,
  "created_at" : "2013-04-21 01:20:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 3, 19 ],
      "id_str" : "41377983",
      "id" : 41377983
    }, {
      "name" : "Chris Deerin",
      "screen_name" : "chrisdeerin",
      "indices" : [ 24, 36 ],
      "id_str" : "130835710",
      "id" : 130835710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325642307544154114",
  "text" : "RT @emperorsclothes: RT @chrisdeerin: A one night stand. You wake up the next morning to find the city in lockdown. Awkward. http:\/\/t.co\/0k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Deerin",
        "screen_name" : "chrisdeerin",
        "indices" : [ 3, 15 ],
        "id_str" : "130835710",
        "id" : 130835710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/0kmDzMxMyA",
        "expanded_url" : "http:\/\/www.esquire.com\/blogs\/culture\/lust-during-wartime?src=soc_twtr",
        "display_url" : "esquire.com\/blogs\/culture\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "325637535814520833",
    "text" : "RT @chrisdeerin: A one night stand. You wake up the next morning to find the city in lockdown. Awkward. http:\/\/t.co\/0kmDzMxMyA Sweet!",
    "id" : 325637535814520833,
    "created_at" : "2013-04-20 15:50:13 +0000",
    "user" : {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "protected" : false,
      "id_str" : "41377983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451424284636745728\/EOavGMYP_normal.jpeg",
      "id" : 41377983,
      "verified" : true
    }
  },
  "id" : 325642307544154114,
  "created_at" : "2013-04-20 16:09:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325640954260357120",
  "text" : "RT @TimGreaton: This was a surprise? In 1879, the Belgium mail service attempted &amp; failed to  train 37 cats to carry bundles of letters\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325634747663544320",
    "text" : "This was a surprise? In 1879, the Belgium mail service attempted &amp; failed to  train 37 cats to carry bundles of letters to nearby villages.",
    "id" : 325634747663544320,
    "created_at" : "2013-04-20 15:39:08 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 325640954260357120,
  "created_at" : "2013-04-20 16:03:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325410661834297344",
  "text" : "hmm.. i am seeing something on twitter.. it's a light..",
  "id" : 325410661834297344,
  "created_at" : "2013-04-20 00:48:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325399300974723072",
  "text" : "@IronAtheist LOL :D",
  "id" : 325399300974723072,
  "created_at" : "2013-04-20 00:03:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "indices" : [ 3, 18 ],
      "id_str" : "24165761",
      "id" : 24165761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325395136974557184",
  "text" : "RT @MichaelSkolnik: \"Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.\" Martin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325394546093600768",
    "text" : "\"Darkness cannot drive out darkness; only light can do that. Hate cannot drive out hate; only love can do that.\" Martin Luther King, Jr.",
    "id" : 325394546093600768,
    "created_at" : "2013-04-19 23:44:39 +0000",
    "user" : {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "protected" : false,
      "id_str" : "24165761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738364600220045313\/L-103cVr_normal.jpg",
      "id" : 24165761,
      "verified" : true
    }
  },
  "id" : 325395136974557184,
  "created_at" : "2013-04-19 23:47:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325343154914095104",
  "text" : "how long has my website been down?? UGH",
  "id" : 325343154914095104,
  "created_at" : "2013-04-19 20:20:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 19, 31 ]
    }, {
      "text" : "Medicare",
      "indices" : [ 34, 43 ]
    }, {
      "text" : "p2",
      "indices" : [ 73, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325342982943416320",
  "text" : "RT @AllOnMedicare: #SinglePayer = #Medicare. It's really, really simple. #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "Medicare",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "p2",
        "indices" : [ 54, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "325340377441787904",
    "text" : "#SinglePayer = #Medicare. It's really, really simple. #p2",
    "id" : 325340377441787904,
    "created_at" : "2013-04-19 20:09:25 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 325342982943416320,
  "created_at" : "2013-04-19 20:19:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "325326325588054016",
  "text" : "@IronAtheist duh dundun duh dundun duh dundun duh dundun ...",
  "id" : 325326325588054016,
  "created_at" : "2013-04-19 19:13:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Queer Voices",
      "screen_name" : "huffpostgay",
      "indices" : [ 121, 133 ],
      "id_str" : "4343856743",
      "id" : 4343856743
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ppPDmW9o21",
      "expanded_url" : "http:\/\/huff.to\/15jxmOC",
      "display_url" : "huff.to\/15jxmOC"
    } ]
  },
  "geo" : { },
  "id_str" : "325268586354577411",
  "text" : "so cute! &gt;&gt; Marriage Proposal Video: Man Proposes To Boyfriend With Sweet Signs (VIDEO) http:\/\/t.co\/ppPDmW9o21 via @HuffPostGay",
  "id" : 325268586354577411,
  "created_at" : "2013-04-19 15:24:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 19, 31 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 32, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324979081022144512",
  "text" : "RT @AllOnMedicare: #SinglePayer #MedicareForAll just means that someone other than a pain-in-the-ass insurance company (i.e. Aetna) pays ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 13, 28 ]
      }, {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324974557842776064",
    "text" : "#SinglePayer #MedicareForAll just means that someone other than a pain-in-the-ass insurance company (i.e. Aetna) pays your doctor's bill #p2",
    "id" : 324974557842776064,
    "created_at" : "2013-04-18 19:55:46 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 324979081022144512,
  "created_at" : "2013-04-18 20:13:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tampa Bay Lightning",
      "screen_name" : "TBLightning",
      "indices" : [ 3, 15 ],
      "id_str" : "28173550",
      "id" : 28173550
    }, {
      "name" : "Tyrellosaurus Rex",
      "screen_name" : "tyrellosaurus",
      "indices" : [ 44, 58 ],
      "id_str" : "553728901",
      "id" : 553728901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324979035497189376",
  "text" : "RT @TBLightning: Update: she said \"yes!\" RT @Tyrellosaurus asked @lovelecavalier  to prom with the @TBLightning logo and hockey cards ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyrellosaurus Rex",
        "screen_name" : "tyrellosaurus",
        "indices" : [ 27, 41 ],
        "id_str" : "553728901",
        "id" : 553728901
      }, {
        "name" : "Tampa Bay Lightning",
        "screen_name" : "TBLightning",
        "indices" : [ 82, 94 ],
        "id_str" : "28173550",
        "id" : 28173550
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FsiMc6c3Q5",
        "expanded_url" : "https:\/\/twitter.com\/Tyrellosaurus\/status\/324684248525185024\/photo\/1",
        "display_url" : "pic.twitter.com\/FsiMc6c3Q5"
      } ]
    },
    "geo" : { },
    "id_str" : "324958335432531968",
    "text" : "Update: she said \"yes!\" RT @Tyrellosaurus asked @lovelecavalier  to prom with the @TBLightning logo and hockey cards http:\/\/t.co\/FsiMc6c3Q5\u201D",
    "id" : 324958335432531968,
    "created_at" : "2013-04-18 18:51:19 +0000",
    "user" : {
      "name" : "Tampa Bay Lightning",
      "screen_name" : "TBLightning",
      "protected" : false,
      "id_str" : "28173550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797808763843596292\/wg_mU2DJ_normal.jpg",
      "id" : 28173550,
      "verified" : true
    }
  },
  "id" : 324979035497189376,
  "created_at" : "2013-04-18 20:13:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324934543775768576",
  "geo" : { },
  "id_str" : "324935674031661056",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves aww.. bless her. what a kind heart &lt;3",
  "id" : 324935674031661056,
  "in_reply_to_status_id" : 324934543775768576,
  "created_at" : "2013-04-18 17:21:16 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "doubledose",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324935353364533249",
  "text" : "feeling better but still a few days til normal i think.. #effexor #doubledose",
  "id" : 324935353364533249,
  "created_at" : "2013-04-18 17:19:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goose",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/j97VEcKtpr",
      "expanded_url" : "https:\/\/www.facebook.com\/cwrescue\/posts\/10152721073425063",
      "display_url" : "facebook.com\/cwrescue\/posts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "324934872454025217",
  "text" : "rip dear wilma #goose https:\/\/t.co\/j97VEcKtpr",
  "id" : 324934872454025217,
  "created_at" : "2013-04-18 17:18:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 110, 122 ]
    }, {
      "text" : "photos",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/ZnnGb0Ec5d",
      "expanded_url" : "https:\/\/www.facebook.com\/thedeafphotographer",
      "display_url" : "facebook.com\/thedeafphotogr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "324933367361568768",
  "geo" : { },
  "id_str" : "324934280167968768",
  "in_reply_to_user_id" : 73908822,
  "text" : "RT @DwayneReaves Created a Facebook page, need visits, need likes! As always, thanks! https:\/\/t.co\/ZnnGb0Ec5d #photography #photos",
  "id" : 324934280167968768,
  "in_reply_to_status_id" : 324933367361568768,
  "created_at" : "2013-04-18 17:15:44 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324615873912520704",
  "text" : "mon: pill at 10 and 3. felt weird from 4 on. tue: pill at 12. sick from 2 on. wed: pill at 3. hopefully will be ok. #effexor",
  "id" : 324615873912520704,
  "created_at" : "2013-04-17 20:10:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TexasEx94",
      "screen_name" : "TexasEx94",
      "indices" : [ 3, 13 ],
      "id_str" : "34171975",
      "id" : 34171975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324573424162856961",
  "text" : "RT @TexasEx94: DeMarte cannot be shaken!  This woman rocks!  #jodiarias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "324572934347821057",
    "text" : "DeMarte cannot be shaken!  This woman rocks!  #jodiarias",
    "id" : 324572934347821057,
    "created_at" : "2013-04-17 17:19:52 +0000",
    "user" : {
      "name" : "TexasEx94",
      "screen_name" : "TexasEx94",
      "protected" : false,
      "id_str" : "34171975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541394864106008576\/4qg2m4EJ_normal.jpeg",
      "id" : 34171975,
      "verified" : false
    }
  },
  "id" : 324573424162856961,
  "created_at" : "2013-04-17 17:21:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "indices" : [ 3, 15 ],
      "id_str" : "23034673",
      "id" : 23034673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324561260039503872",
  "text" : "RT @hemantmehta: High School Student Fights Back Against Abstinence Speaker at Assembly, so the Principal Threatens to Warn Her... http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/UpXbJ8QD4W",
        "expanded_url" : "http:\/\/bit.ly\/11uTUYs",
        "display_url" : "bit.ly\/11uTUYs"
      } ]
    },
    "geo" : { },
    "id_str" : "324545762807648258",
    "text" : "High School Student Fights Back Against Abstinence Speaker at Assembly, so the Principal Threatens to Warn Her... http:\/\/t.co\/UpXbJ8QD4W",
    "id" : 324545762807648258,
    "created_at" : "2013-04-17 15:31:54 +0000",
    "user" : {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "protected" : false,
      "id_str" : "23034673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3393754882\/07184fa9526af00257538d818b6f72f7_normal.jpeg",
      "id" : 23034673,
      "verified" : true
    }
  },
  "id" : 324561260039503872,
  "created_at" : "2013-04-17 16:33:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324551314279366658",
  "text" : "still recovering from accidental double dose of #effexor on monday .. blah",
  "id" : 324551314279366658,
  "created_at" : "2013-04-17 15:53:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323928845537398784",
  "geo" : { },
  "id_str" : "323930548617748480",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides always good to see you im my TL : )",
  "id" : 323930548617748480,
  "in_reply_to_status_id" : 323928845537398784,
  "created_at" : "2013-04-15 22:47:15 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323920872631058433",
  "text" : "ive got the bathroom ready for later.. if the weirdness turns to nausea. missing my chair cushion, tho.",
  "id" : 323920872631058433,
  "created_at" : "2013-04-15 22:08:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323920397328330753",
  "text" : "RT @CoyoteSings: Some people actually believe that if we're all armed to the teeth, the violence will stop. A constant state of fear is  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FAIL",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323914530533031936",
    "text" : "Some people actually believe that if we're all armed to the teeth, the violence will stop. A constant state of fear is no way to live. #FAIL",
    "id" : 323914530533031936,
    "created_at" : "2013-04-15 21:43:36 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 323920397328330753,
  "created_at" : "2013-04-15 22:06:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "APenAndADream",
      "screen_name" : "APenAndADream",
      "indices" : [ 31, 45 ],
      "id_str" : "740926623759863808",
      "id" : 740926623759863808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323915577901056002",
  "geo" : { },
  "id_str" : "323920188758175744",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous aww.. bless you : ) @APenAndADream",
  "id" : 323920188758175744,
  "in_reply_to_status_id" : 323915577901056002,
  "created_at" : "2013-04-15 22:06:05 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323919671579512832",
  "text" : "RT @TyrusBooks: Love. Not fear. Always.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323917178808201217",
    "text" : "Love. Not fear. Always.",
    "id" : 323917178808201217,
    "created_at" : "2013-04-15 21:54:08 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 323919671579512832,
  "created_at" : "2013-04-15 22:04:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323901356626808832",
  "text" : "i still feel weird.. maybe weirder.. what happens if you take an extra #effexor pill?",
  "id" : 323901356626808832,
  "created_at" : "2013-04-15 20:51:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323875148279197696",
  "text" : "feeling strange.. cannot remember if i took my pill this am.. so popped 1 just now. ugh. #effexor",
  "id" : 323875148279197696,
  "created_at" : "2013-04-15 19:07:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/bnGY7PvJG1",
      "expanded_url" : "http:\/\/amzn.to\/13W9ezk",
      "display_url" : "amzn.to\/13W9ezk"
    } ]
  },
  "geo" : { },
  "id_str" : "323625285457154051",
  "text" : "finished Unintended Consequences by Marti Green http:\/\/t.co\/bnGY7PvJG1",
  "id" : 323625285457154051,
  "created_at" : "2013-04-15 02:34:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323471881002946561",
  "text" : "RT @ZachsMind: Tired of watching humanity try to control reality. There's no control. We're like children building a dam against the oce ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323469207859785728",
    "text" : "Tired of watching humanity try to control reality. There's no control. We're like children building a dam against the ocean w\/sand.",
    "id" : 323469207859785728,
    "created_at" : "2013-04-14 16:14:03 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 323471881002946561,
  "created_at" : "2013-04-14 16:24:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323469513632915456",
  "geo" : { },
  "id_str" : "323471782105468928",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind thats sounds very buddhist to me..lol : )",
  "id" : 323471782105468928,
  "in_reply_to_status_id" : 323469513632915456,
  "created_at" : "2013-04-14 16:24:17 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323471619924316161",
  "text" : "RT @ZachsMind: instead of trying to control the waves, we need to learn how to surf.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323469513632915456",
    "text" : "instead of trying to control the waves, we need to learn how to surf.",
    "id" : 323469513632915456,
    "created_at" : "2013-04-14 16:15:16 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 323471619924316161,
  "created_at" : "2013-04-14 16:23:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedicareForAll",
      "indices" : [ 34, 49 ]
    }, {
      "text" : "Cigna",
      "indices" : [ 101, 107 ]
    }, {
      "text" : "Aetna",
      "indices" : [ 108, 114 ]
    }, {
      "text" : "AHIP",
      "indices" : [ 115, 120 ]
    }, {
      "text" : "WellPoint",
      "indices" : [ 121, 131 ]
    }, {
      "text" : "p2",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323455937530707968",
  "text" : "RT @AllOnMedicare: We want to see #MedicareForAll trending today on Twitter. You're on notice -- CC: #Cigna #Aetna #AHIP #WellPoint. #p2 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedicareForAll",
        "indices" : [ 15, 30 ]
      }, {
        "text" : "Cigna",
        "indices" : [ 82, 88 ]
      }, {
        "text" : "Aetna",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "AHIP",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "WellPoint",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "p2",
        "indices" : [ 114, 117 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 118, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323455719754059778",
    "text" : "We want to see #MedicareForAll trending today on Twitter. You're on notice -- CC: #Cigna #Aetna #AHIP #WellPoint. #p2 #SinglePayer",
    "id" : 323455719754059778,
    "created_at" : "2013-04-14 15:20:27 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 323455937530707968,
  "created_at" : "2013-04-14 15:21:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "indices" : [ 3, 18 ],
      "id_str" : "18725718",
      "id" : 18725718
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hell",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "Love",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "God",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "OregonState",
      "indices" : [ 62, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Fg041H8BCg",
      "expanded_url" : "http:\/\/shar.es\/J0xww",
      "display_url" : "shar.es\/J0xww"
    } ]
  },
  "geo" : { },
  "id_str" : "323175010489483264",
  "text" : "RT @christianpiatt: My talk on #Hell and the #Love of #God at #OregonState (Pt. 1 of 2) http:\/\/t.co\/Fg041H8BCg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hell",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "Love",
        "indices" : [ 25, 30 ]
      }, {
        "text" : "God",
        "indices" : [ 34, 38 ]
      }, {
        "text" : "OregonState",
        "indices" : [ 42, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/Fg041H8BCg",
        "expanded_url" : "http:\/\/shar.es\/J0xww",
        "display_url" : "shar.es\/J0xww"
      } ]
    },
    "geo" : { },
    "id_str" : "322452466543243264",
    "text" : "My talk on #Hell and the #Love of #God at #OregonState (Pt. 1 of 2) http:\/\/t.co\/Fg041H8BCg",
    "id" : 322452466543243264,
    "created_at" : "2013-04-11 20:53:53 +0000",
    "user" : {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "protected" : false,
      "id_str" : "18725718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765072572337704960\/hMj5pUf0_normal.jpg",
      "id" : 18725718,
      "verified" : false
    }
  },
  "id" : 323175010489483264,
  "created_at" : "2013-04-13 20:45:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "howcanyouhavelessthanzero",
      "indices" : [ 77, 103 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323120535330488320",
  "geo" : { },
  "id_str" : "323121243018625024",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible ..and i STILL dont get the whole negative numbers thing..lol #howcanyouhavelessthanzero?",
  "id" : 323121243018625024,
  "in_reply_to_status_id" : 323120535330488320,
  "created_at" : "2013-04-13 17:11:22 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc",
      "screen_name" : "SP4RT4N360",
      "indices" : [ 0, 11 ],
      "id_str" : "44840269",
      "id" : 44840269
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 100, 115 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323115942596997121",
  "geo" : { },
  "id_str" : "323119994961547264",
  "in_reply_to_user_id" : 44840269,
  "text" : "@SP4RT4N360 i did say \"some\" ... you really cant lump all atheists together or all theists together @AnnotatedBible",
  "id" : 323119994961547264,
  "in_reply_to_status_id" : 323115942596997121,
  "created_at" : "2013-04-13 17:06:24 +0000",
  "in_reply_to_screen_name" : "SP4RT4N360",
  "in_reply_to_user_id_str" : "44840269",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323119663808651264",
  "text" : "@Prestonbram i guess some ppl believe that.. never made sense to me.",
  "id" : 323119663808651264,
  "created_at" : "2013-04-13 17:05:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323107752627023873",
  "geo" : { },
  "id_str" : "323116725782601728",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible we all have our reasons for belief or non-belief. its personal to each person. so many variables come into play.",
  "id" : 323116725782601728,
  "in_reply_to_status_id" : 323107752627023873,
  "created_at" : "2013-04-13 16:53:25 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323107752627023873",
  "geo" : { },
  "id_str" : "323116525164822528",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible i disagree.. its like when atheists claim believers have been brainwashed or looking for an out, etc.",
  "id" : 323116525164822528,
  "in_reply_to_status_id" : 323107752627023873,
  "created_at" : "2013-04-13 16:52:37 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323110468837318656",
  "geo" : { },
  "id_str" : "323115616099782656",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep hoping it's something minor and will resolve itself",
  "id" : 323115616099782656,
  "in_reply_to_status_id" : 323110468837318656,
  "created_at" : "2013-04-13 16:49:00 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "323112462868172801",
  "geo" : { },
  "id_str" : "323115029677346816",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible some atheists have backgrounds where christianity was strictly forced upon them as children so i can understand anger...",
  "id" : 323115029677346816,
  "in_reply_to_status_id" : 323112462868172801,
  "created_at" : "2013-04-13 16:46:40 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323097288035680256",
  "text" : "i have serious self esteem issues.. ive just learned to ignore them..",
  "id" : 323097288035680256,
  "created_at" : "2013-04-13 15:36:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323096969969020930",
  "text" : "RT @aliceinthewater: Dr. Kermit Gosnell's clinic is what happens when abortions are so restricted that women have no where else to go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323096559170494465",
    "text" : "Dr. Kermit Gosnell's clinic is what happens when abortions are so restricted that women have no where else to go.",
    "id" : 323096559170494465,
    "created_at" : "2013-04-13 15:33:17 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 323096969969020930,
  "created_at" : "2013-04-13 15:34:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    }, {
      "name" : "\u3086\u3046\u304D\u3083\u3093",
      "screen_name" : "juliannq",
      "indices" : [ 21, 30 ],
      "id_str" : "785133358628077568",
      "id" : 785133358628077568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323096670042726400",
  "text" : "RT @ChrisCapparell: \u201C@juliannq: We tend to think consciousness is a product of the physical. But what if consciousness comes first?\u201D\n#Th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u3086\u3046\u304D\u3083\u3093",
        "screen_name" : "juliannq",
        "indices" : [ 1, 10 ],
        "id_str" : "785133358628077568",
        "id" : 785133358628077568
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheProblemOfSupervenience",
        "indices" : [ 113, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "323089067564756993",
    "text" : "\u201C@juliannq: We tend to think consciousness is a product of the physical. But what if consciousness comes first?\u201D\n#TheProblemOfSupervenience.",
    "id" : 323089067564756993,
    "created_at" : "2013-04-13 15:03:31 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 323096670042726400,
  "created_at" : "2013-04-13 15:33:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "323095787116580864",
  "text" : "just deleted an account..",
  "id" : 323095787116580864,
  "created_at" : "2013-04-13 15:30:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/s3oRcD408Y",
      "expanded_url" : "http:\/\/amzn.to\/w44ohS",
      "display_url" : "amzn.to\/w44ohS"
    } ]
  },
  "geo" : { },
  "id_str" : "322894358716235778",
  "text" : "finished Nick of Time (A Bug Man Novel) by Tim Downs http:\/\/t.co\/s3oRcD408Y",
  "id" : 322894358716235778,
  "created_at" : "2013-04-13 02:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322860456668692480",
  "text" : "i think im morphing again.. oy!",
  "id" : 322860456668692480,
  "created_at" : "2013-04-12 23:55:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322826264350175232",
  "geo" : { },
  "id_str" : "322830131628474371",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 i cant believe she can get away with this...",
  "id" : 322830131628474371,
  "in_reply_to_status_id" : 322826264350175232,
  "created_at" : "2013-04-12 21:54:35 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/k5D1tzucwx",
      "expanded_url" : "http:\/\/jezebel.com\/terrifying-public-high-school-speaker-if-you-take-birt-472610594",
      "display_url" : "jezebel.com\/terrifying-pub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322829506719145985",
  "text" : "RT @atheistlady76: http:\/\/t.co\/k5D1tzucwx &lt;&lt;&lt;ugh. Just wrong",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/k5D1tzucwx",
        "expanded_url" : "http:\/\/jezebel.com\/terrifying-public-high-school-speaker-if-you-take-birt-472610594",
        "display_url" : "jezebel.com\/terrifying-pub\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "322826264350175232",
    "text" : "http:\/\/t.co\/k5D1tzucwx &lt;&lt;&lt;ugh. Just wrong",
    "id" : 322826264350175232,
    "created_at" : "2013-04-12 21:39:13 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 322829506719145985,
  "created_at" : "2013-04-12 21:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "indices" : [ 0, 11 ],
      "id_str" : "511243584",
      "id" : 511243584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322754736078086144",
  "geo" : { },
  "id_str" : "322756300700258304",
  "in_reply_to_user_id" : 511243584,
  "text" : "@becwaddell these jury questions certainly indicate that!",
  "id" : 322756300700258304,
  "in_reply_to_status_id" : 322754736078086144,
  "created_at" : "2013-04-12 17:01:13 +0000",
  "in_reply_to_screen_name" : "becwaddell",
  "in_reply_to_user_id_str" : "511243584",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The OED",
      "screen_name" : "OED",
      "indices" : [ 3, 7 ],
      "id_str" : "126002546",
      "id" : 126002546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322694948443004928",
  "text" : "RT @OED: 'Exosculate' is a now obsolete verb meaning 'to kiss heartily' (from Latin 'osculum', a kiss).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322691977579732992",
    "text" : "'Exosculate' is a now obsolete verb meaning 'to kiss heartily' (from Latin 'osculum', a kiss).",
    "id" : 322691977579732992,
    "created_at" : "2013-04-12 12:45:37 +0000",
    "user" : {
      "name" : "The OED",
      "screen_name" : "OED",
      "protected" : false,
      "id_str" : "126002546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/845695415\/OED_logo_normal.jpg",
      "id" : 126002546,
      "verified" : true
    }
  },
  "id" : 322694948443004928,
  "created_at" : "2013-04-12 12:57:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322512261379944448",
  "text" : "RT @CoyoteSings: If I wanted to know how to kill something, I'd ask Ted Nugent. I'm trying to figure out how *not* to kill things. Ted N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322511236489170944",
    "text" : "If I wanted to know how to kill something, I'd ask Ted Nugent. I'm trying to figure out how *not* to kill things. Ted Nugent can't help me.",
    "id" : 322511236489170944,
    "created_at" : "2013-04-12 00:47:25 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 322512261379944448,
  "created_at" : "2013-04-12 00:51:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322507965200470016",
  "geo" : { },
  "id_str" : "322508789783855104",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 lol.. i was listening to the questions and shouting at hubby \"they know, they know\"",
  "id" : 322508789783855104,
  "in_reply_to_status_id" : 322507965200470016,
  "created_at" : "2013-04-12 00:37:42 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322505699420680192",
  "text" : "From the jury's questions.. i'd say #jodiarias is DONE. They see through all the crap.",
  "id" : 322505699420680192,
  "created_at" : "2013-04-12 00:25:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "chrisbr40",
      "indices" : [ 0, 10 ],
      "id_str" : "540023255",
      "id" : 540023255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322472811354546176",
  "geo" : { },
  "id_str" : "322473709703159808",
  "in_reply_to_user_id" : 540023255,
  "text" : "@chrisbr40 i heard that, too.. im thinking maybe the research was on hetero couples, not gay?",
  "id" : 322473709703159808,
  "in_reply_to_status_id" : 322472811354546176,
  "created_at" : "2013-04-11 22:18:18 +0000",
  "in_reply_to_screen_name" : "chrisbr40",
  "in_reply_to_user_id_str" : "540023255",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322472118233206784",
  "text" : "\"Is it possible for the survivor to be the perpetrator?\" Yessss.. the jury gets it!! #jodiarias",
  "id" : 322472118233206784,
  "created_at" : "2013-04-11 22:11:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/JzbwffWI9u",
      "expanded_url" : "http:\/\/HLNtv.com",
      "display_url" : "HLNtv.com"
    }, {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/CjFO2O54q4",
      "expanded_url" : "http:\/\/www.hlntv.com\/article\/2013\/04\/11\/jodi-arias-murder-trial-hln-lies-domestic-abuse-violence",
      "display_url" : "hlntv.com\/article\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "322428077638549504",
  "text" : "Doc: Jodi's abuse claim is an 'impossibility' | http:\/\/t.co\/JzbwffWI9u http:\/\/t.co\/CjFO2O54q4 #jodiarias",
  "id" : 322428077638549504,
  "created_at" : "2013-04-11 19:16:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322424665584832512",
  "geo" : { },
  "id_str" : "322425336811900928",
  "in_reply_to_user_id" : 323552584,
  "text" : "@JacqMJackson me, too...",
  "id" : 322425336811900928,
  "in_reply_to_status_id" : 322424665584832512,
  "created_at" : "2013-04-11 19:06:05 +0000",
  "in_reply_to_screen_name" : "Jacinallhonesty",
  "in_reply_to_user_id_str" : "323552584",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIP",
      "indices" : [ 76, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322423958706196480",
  "in_reply_to_user_id" : 323552584,
  "text" : "@JacqMJackson your avi.. is that your cat? : ) ..looks like my baby, Ghosty #RIP",
  "id" : 322423958706196480,
  "created_at" : "2013-04-11 19:00:36 +0000",
  "in_reply_to_screen_name" : "Jacinallhonesty",
  "in_reply_to_user_id_str" : "323552584",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322417936222527488",
  "text" : "i think i need serios drugs to keep listening to this crap - ugh! #jodiarias",
  "id" : 322417936222527488,
  "created_at" : "2013-04-11 18:36:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KathieLee65",
      "screen_name" : "kathielee65",
      "indices" : [ 3, 15 ],
      "id_str" : "67637852",
      "id" : 67637852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bullying",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "jodiarias",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322397541293490176",
  "text" : "RT @kathielee65: #Bullying is wrong no matter how you dress it up. ALV is being bullied on a grand scale. Don't help #jodiarias destroy  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bullying",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "jodiarias",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322396178933227521",
    "text" : "#Bullying is wrong no matter how you dress it up. ALV is being bullied on a grand scale. Don't help #jodiarias destroy another life.",
    "id" : 322396178933227521,
    "created_at" : "2013-04-11 17:10:13 +0000",
    "user" : {
      "name" : "KathieLee65",
      "screen_name" : "kathielee65",
      "protected" : false,
      "id_str" : "67637852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2518225245\/e67ahhg1h0vggrvegnn1_normal.jpeg",
      "id" : 67637852,
      "verified" : false
    }
  },
  "id" : 322397541293490176,
  "created_at" : "2013-04-11 17:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "r",
      "screen_name" : "westtexasbec",
      "indices" : [ 3, 16 ],
      "id_str" : "621116463",
      "id" : 621116463
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322397500122218496",
  "text" : "RT @westtexasbec: I think #jodiarias is disgusting and really don't care for laViolette. That being said I don't think the harassment of ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 8, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322396133747998720",
    "text" : "I think #jodiarias is disgusting and really don't care for laViolette. That being said I don't think the harassment of her office is right",
    "id" : 322396133747998720,
    "created_at" : "2013-04-11 17:10:02 +0000",
    "user" : {
      "name" : "r",
      "screen_name" : "westtexasbec",
      "protected" : false,
      "id_str" : "621116463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2349227989\/image_normal.jpg",
      "id" : 621116463,
      "verified" : false
    }
  },
  "id" : 322397500122218496,
  "created_at" : "2013-04-11 17:15:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322386264533893123",
  "text" : "weird dream.. fat self (nice) and skinny self (mean) trying to go up some stairs...",
  "id" : 322386264533893123,
  "created_at" : "2013-04-11 16:30:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 106, 114 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Ygenwllhrj",
      "expanded_url" : "http:\/\/youtu.be\/IlMI_KQm8m8?a",
      "display_url" : "youtu.be\/IlMI_KQm8m8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "322385252326707200",
  "text" : "RT @JodiAriasNews: #JodiArias Trial: \"Still beat you...BRAT!\" *EHANCED AUDIO*: http:\/\/t.co\/Ygenwllhrj via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 87, 95 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/Ygenwllhrj",
        "expanded_url" : "http:\/\/youtu.be\/IlMI_KQm8m8?a",
        "display_url" : "youtu.be\/IlMI_KQm8m8?a"
      } ]
    },
    "geo" : { },
    "id_str" : "322384179125948416",
    "text" : "#JodiArias Trial: \"Still beat you...BRAT!\" *EHANCED AUDIO*: http:\/\/t.co\/Ygenwllhrj via @YouTube",
    "id" : 322384179125948416,
    "created_at" : "2013-04-11 16:22:32 +0000",
    "user" : {
      "name" : "Mrs R",
      "screen_name" : "Misses_Razberry",
      "protected" : false,
      "id_str" : "1260641948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595448467935371264\/-aFDRH18_normal.jpg",
      "id" : 1260641948,
      "verified" : false
    }
  },
  "id" : 322385252326707200,
  "created_at" : "2013-04-11 16:26:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322090098034348035",
  "text" : "DH: Is it being televised? Me: it's redirect, wilma's back up. DH: Yes or No, Mrs. Campbell.. Is it being televised? #jodiarias LOL",
  "id" : 322090098034348035,
  "created_at" : "2013-04-10 20:53:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 3, 17 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322043905573015552",
  "text" : "RT @TheTweetOfGod: I wish Twitter would verify Me, but that would involve proving I exist, and that's never been My strong suit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322042814789718016",
    "text" : "I wish Twitter would verify Me, but that would involve proving I exist, and that's never been My strong suit.",
    "id" : 322042814789718016,
    "created_at" : "2013-04-10 17:46:04 +0000",
    "user" : {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "protected" : false,
      "id_str" : "204832963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577952058680070144\/6hlNZ0_Y_normal.jpeg",
      "id" : 204832963,
      "verified" : false
    }
  },
  "id" : 322043905573015552,
  "created_at" : "2013-04-10 17:50:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lovelymsdenise",
      "screen_name" : "lovelymsdenise",
      "indices" : [ 0, 15 ],
      "id_str" : "148955112",
      "id" : 148955112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322041534189015041",
  "geo" : { },
  "id_str" : "322041960057667586",
  "in_reply_to_user_id" : 148955112,
  "text" : "@lovelymsdenise LOL ; )",
  "id" : 322041960057667586,
  "in_reply_to_status_id" : 322041534189015041,
  "created_at" : "2013-04-10 17:42:41 +0000",
  "in_reply_to_screen_name" : "lovelymsdenise",
  "in_reply_to_user_id_str" : "148955112",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322039366480437248",
  "text" : "@Llimoner_ lol.. watching #jodiarias trial livestream. Def expert witness refuses to answer Yes or No questions re: her continuum sheet.",
  "id" : 322039366480437248,
  "created_at" : "2013-04-10 17:32:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ROH",
      "screen_name" : "RealOldHouswife",
      "indices" : [ 3, 19 ],
      "id_str" : "126358979",
      "id" : 126358979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/FsdS27GUfY",
      "expanded_url" : "http:\/\/iseeoldpeople.blogspot.com\/",
      "display_url" : "iseeoldpeople.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "322038710071861248",
  "text" : "RT @RealOldHouswife: Guilty As Charged...\nhttp:\/\/t.co\/FsdS27GUfY #jodiarias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 44, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/FsdS27GUfY",
        "expanded_url" : "http:\/\/iseeoldpeople.blogspot.com\/",
        "display_url" : "iseeoldpeople.blogspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "322037583666364416",
    "text" : "Guilty As Charged...\nhttp:\/\/t.co\/FsdS27GUfY #jodiarias",
    "id" : 322037583666364416,
    "created_at" : "2013-04-10 17:25:17 +0000",
    "user" : {
      "name" : "ROH",
      "screen_name" : "RealOldHouswife",
      "protected" : false,
      "id_str" : "126358979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797156834134134784\/hAOop_gw_normal.jpg",
      "id" : 126358979,
      "verified" : false
    }
  },
  "id" : 322038710071861248,
  "created_at" : "2013-04-10 17:29:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hostilewitness",
      "indices" : [ 85, 100 ]
    }, {
      "text" : "jodiarias",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322036522041884672",
  "text" : "Yes, it IS a Yes or No question, Alyce!! \"stalking\" IS listed under terrorism! O.M.G #hostilewitness #jodiarias",
  "id" : 322036522041884672,
  "created_at" : "2013-04-10 17:21:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "juanmartinez",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322035843642572801",
  "text" : "more trial watching today.. love watching #juanmartinez in action!",
  "id" : 322035843642572801,
  "created_at" : "2013-04-10 17:18:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Jauregui",
      "screen_name" : "dutchvowels",
      "indices" : [ 3, 15 ],
      "id_str" : "17493933",
      "id" : 17493933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/wbEMhyzloy",
      "expanded_url" : "http:\/\/huff.to\/14Veh5c",
      "display_url" : "huff.to\/14Veh5c"
    } ]
  },
  "geo" : { },
  "id_str" : "321745417001902080",
  "text" : "RT @dutchvowels: Bad: Sex ideas from animal porn. Worse: Involving eels. Worst: With a taste for rectal flesh http:\/\/t.co\/wbEMhyzloy  @H ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Weird News",
        "screen_name" : "HuffPostWeird",
        "indices" : [ 117, 131 ],
        "id_str" : "125567504",
        "id" : 125567504
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/wbEMhyzloy",
        "expanded_url" : "http:\/\/huff.to\/14Veh5c",
        "display_url" : "huff.to\/14Veh5c"
      } ]
    },
    "geo" : { },
    "id_str" : "321741403271081984",
    "text" : "Bad: Sex ideas from animal porn. Worse: Involving eels. Worst: With a taste for rectal flesh http:\/\/t.co\/wbEMhyzloy  @HuffPostWeird",
    "id" : 321741403271081984,
    "created_at" : "2013-04-09 21:48:22 +0000",
    "user" : {
      "name" : "Andres Jauregui",
      "screen_name" : "dutchvowels",
      "protected" : false,
      "id_str" : "17493933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576069691690479616\/KI35xHLM_normal.jpeg",
      "id" : 17493933,
      "verified" : true
    }
  },
  "id" : 321745417001902080,
  "created_at" : "2013-04-09 22:04:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321743374241632256",
  "geo" : { },
  "id_str" : "321744356082073602",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses you're going for fun.. so be comfy so you can focus on fun!",
  "id" : 321744356082073602,
  "in_reply_to_status_id" : 321743374241632256,
  "created_at" : "2013-04-09 22:00:06 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321741712353529856",
  "text" : "had an AHA! moment this am.. i need to love my body.",
  "id" : 321741712353529856,
  "created_at" : "2013-04-09 21:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321739764443254786",
  "text" : "live stream of event available for viewing.. cool!",
  "id" : 321739764443254786,
  "created_at" : "2013-04-09 21:41:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "indices" : [ 3, 18 ],
      "id_str" : "18725718",
      "id" : 18725718
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OSU",
      "indices" : [ 77, 81 ]
    }, {
      "text" : "Hell",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "God",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321739709690806273",
  "text" : "RT @christianpiatt: Ok folks, here are the deets about my debate tomorrow at #OSU called \"#Hell and the Love of #God.\" http:\/\/t.co\/Brtmp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OSU",
        "indices" : [ 57, 61 ]
      }, {
        "text" : "Hell",
        "indices" : [ 70, 75 ]
      }, {
        "text" : "God",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/BrtmpsQ6aq",
        "expanded_url" : "http:\/\/bit.ly\/ZC0vUa",
        "display_url" : "bit.ly\/ZC0vUa"
      } ]
    },
    "geo" : { },
    "id_str" : "321738221325266944",
    "text" : "Ok folks, here are the deets about my debate tomorrow at #OSU called \"#Hell and the Love of #God.\" http:\/\/t.co\/BrtmpsQ6aq",
    "id" : 321738221325266944,
    "created_at" : "2013-04-09 21:35:44 +0000",
    "user" : {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "protected" : false,
      "id_str" : "18725718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765072572337704960\/hMj5pUf0_normal.jpg",
      "id" : 18725718,
      "verified" : false
    }
  },
  "id" : 321739709690806273,
  "created_at" : "2013-04-09 21:41:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321729122579652608",
  "geo" : { },
  "id_str" : "321734960341999616",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses : )",
  "id" : 321734960341999616,
  "in_reply_to_status_id" : 321729122579652608,
  "created_at" : "2013-04-09 21:22:46 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 3, 13 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/jLz41iOcge",
      "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "321734639062503424",
  "text" : "RT @Dwayne802: Facebook Page https:\/\/t.co\/jLz41iOcge",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/jLz41iOcge",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "321732552702431234",
    "text" : "Facebook Page https:\/\/t.co\/jLz41iOcge",
    "id" : 321732552702431234,
    "created_at" : "2013-04-09 21:13:12 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 321734639062503424,
  "created_at" : "2013-04-09 21:21:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Roller",
      "screen_name" : "rolldiggity",
      "indices" : [ 3, 15 ],
      "id_str" : "157526840",
      "id" : 157526840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321734467041521664",
  "text" : "RT @rolldiggity: New Parent Idea:\n1. Take pictures of you pulling baby out of spacecraft in forest.\n2. Hide pictures in attic for kid to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321671142601543680",
    "text" : "New Parent Idea:\n1. Take pictures of you pulling baby out of spacecraft in forest.\n2. Hide pictures in attic for kid to find when he's 10.",
    "id" : 321671142601543680,
    "created_at" : "2013-04-09 17:09:11 +0000",
    "user" : {
      "name" : "Matt Roller",
      "screen_name" : "rolldiggity",
      "protected" : false,
      "id_str" : "157526840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1590038887\/IMG_0423_normal.JPG",
      "id" : 157526840,
      "verified" : false
    }
  },
  "id" : 321734467041521664,
  "created_at" : "2013-04-09 21:20:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 5, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321734252771278848",
  "text" : "i am #INFP .. im usually not oriented towards \"justice\" .. im really confusing myself..",
  "id" : 321734252771278848,
  "created_at" : "2013-04-09 21:19:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321734019282776065",
  "text" : "child abusers who've killed.. only 20-30 years in jail? W.T.F?? (reading up on killers\/sentences due to watching #jodiarias trial)",
  "id" : 321734019282776065,
  "created_at" : "2013-04-09 21:19:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "indices" : [ 3, 18 ],
      "id_str" : "18725718",
      "id" : 18725718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321715859322191872",
  "text" : "RT @christianpiatt: For anyone in or near Corvallis OR, I will be debating the doctrine of hell at Oregon State tomorrow night from 7 to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321710069366530048",
    "text" : "For anyone in or near Corvallis OR, I will be debating the doctrine of hell at Oregon State tomorrow night from 7 to 9. details coming\u2026",
    "id" : 321710069366530048,
    "created_at" : "2013-04-09 19:43:52 +0000",
    "user" : {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "protected" : false,
      "id_str" : "18725718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765072572337704960\/hMj5pUf0_normal.jpg",
      "id" : 18725718,
      "verified" : false
    }
  },
  "id" : 321715859322191872,
  "created_at" : "2013-04-09 20:06:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321715178947366912",
  "text" : "RT @alanhdawe: There can be no place where there is something that is not God-Consciousness. This also implies He is immaterial in His e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321712385075318784",
    "text" : "There can be no place where there is something that is not God-Consciousness. This also implies He is immaterial in His essence. #TGFBook",
    "id" : 321712385075318784,
    "created_at" : "2013-04-09 19:53:04 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 321715178947366912,
  "created_at" : "2013-04-09 20:04:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321708709061488640",
  "text" : "@BeaEdyson i def agree w that!",
  "id" : 321708709061488640,
  "created_at" : "2013-04-09 19:38:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321701312767082496",
  "geo" : { },
  "id_str" : "321702559645589504",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible i agree.",
  "id" : 321702559645589504,
  "in_reply_to_status_id" : 321701312767082496,
  "created_at" : "2013-04-09 19:14:01 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "les cooper",
      "screen_name" : "flywildflyfree",
      "indices" : [ 3, 18 ],
      "id_str" : "23470034",
      "id" : 23470034
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/321701511258324992\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/fgopbCS5LD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BHbp0e6CQAAAAGZ.jpg",
      "id_str" : "321701511262519296",
      "id" : 321701511262519296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHbp0e6CQAAAAGZ.jpg",
      "sizes" : [ {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1420,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fgopbCS5LD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321701947910524929",
  "text" : "RT @flywildflyfree: why are you not talking to me http:\/\/t.co\/fgopbCS5LD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/321701511258324992\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/fgopbCS5LD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BHbp0e6CQAAAAGZ.jpg",
        "id_str" : "321701511262519296",
        "id" : 321701511262519296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BHbp0e6CQAAAAGZ.jpg",
        "sizes" : [ {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1420,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 416,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/fgopbCS5LD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321701511258324992",
    "text" : "why are you not talking to me http:\/\/t.co\/fgopbCS5LD",
    "id" : 321701511258324992,
    "created_at" : "2013-04-09 19:09:52 +0000",
    "user" : {
      "name" : "les cooper",
      "screen_name" : "flywildflyfree",
      "protected" : false,
      "id_str" : "23470034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000033775910\/154418c4011969db884eff317a450dd3_normal.jpeg",
      "id" : 23470034,
      "verified" : false
    }
  },
  "id" : 321701947910524929,
  "created_at" : "2013-04-09 19:11:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321698259053735936",
  "text" : "@shiniestmarble just be you.. the others will deal w it. ((hugs))",
  "id" : 321698259053735936,
  "created_at" : "2013-04-09 18:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321681761660715008",
  "geo" : { },
  "id_str" : "321684389291491329",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal sorry i missed your tweets about going in.. pancreatitis, huh.. ouch. glad you're getting better! ((hugs))",
  "id" : 321684389291491329,
  "in_reply_to_status_id" : 321681761660715008,
  "created_at" : "2013-04-09 18:01:49 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Chief Elk",
      "screen_name" : "ChiefElk",
      "indices" : [ 3, 12 ],
      "id_str" : "287254852",
      "id" : 287254852
    }, {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "indices" : [ 35, 43 ],
      "id_str" : "8192222",
      "id" : 8192222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/VCqybPs8d8",
      "expanded_url" : "http:\/\/bit.ly\/ZLoDg2",
      "display_url" : "bit.ly\/ZLoDg2"
    } ]
  },
  "geo" : { },
  "id_str" : "321674978841985025",
  "text" : "RT @ChiefElk: For chrissakes...RT \"@Jezebel: Middle school bans tight pants because they \"distract the boys\" http:\/\/t.co\/VCqybPs8d8\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jezebel",
        "screen_name" : "Jezebel",
        "indices" : [ 21, 29 ],
        "id_str" : "8192222",
        "id" : 8192222
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/VCqybPs8d8",
        "expanded_url" : "http:\/\/bit.ly\/ZLoDg2",
        "display_url" : "bit.ly\/ZLoDg2"
      } ]
    },
    "geo" : { },
    "id_str" : "321673013663789056",
    "text" : "For chrissakes...RT \"@Jezebel: Middle school bans tight pants because they \"distract the boys\" http:\/\/t.co\/VCqybPs8d8\"",
    "id" : 321673013663789056,
    "created_at" : "2013-04-09 17:16:37 +0000",
    "user" : {
      "name" : "Lauren Chief Elk",
      "screen_name" : "ChiefElk",
      "protected" : false,
      "id_str" : "287254852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787689994861240320\/r4QRoVP4_normal.jpg",
      "id" : 287254852,
      "verified" : false
    }
  },
  "id" : 321674978841985025,
  "created_at" : "2013-04-09 17:24:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "nature",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "photo",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/gP1CxBO34n",
      "expanded_url" : "http:\/\/ow.ly\/jQpTk",
      "display_url" : "ow.ly\/jQpTk"
    } ]
  },
  "geo" : { },
  "id_str" : "321674164903755776",
  "text" : "RT @KerriFar: 3 Geese a landing ;) ~ http:\/\/t.co\/gP1CxBO34n  ~ #birds #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 49, 55 ]
      }, {
        "text" : "nature",
        "indices" : [ 56, 63 ]
      }, {
        "text" : "photo",
        "indices" : [ 64, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/gP1CxBO34n",
        "expanded_url" : "http:\/\/ow.ly\/jQpTk",
        "display_url" : "ow.ly\/jQpTk"
      } ]
    },
    "geo" : { },
    "id_str" : "321672751561723904",
    "text" : "3 Geese a landing ;) ~ http:\/\/t.co\/gP1CxBO34n  ~ #birds #nature #photo",
    "id" : 321672751561723904,
    "created_at" : "2013-04-09 17:15:35 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 321674164903755776,
  "created_at" : "2013-04-09 17:21:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321673959013765120",
  "text" : "\"i read for hours and hours\" ALV - but what sources, Alyce?? Biased one side sources!! #jodiarias ((headtodesk))",
  "id" : 321673959013765120,
  "created_at" : "2013-04-09 17:20:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Reeves",
      "screen_name" : "concop100",
      "indices" : [ 0, 10 ],
      "id_str" : "37292353",
      "id" : 37292353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321672828942442496",
  "geo" : { },
  "id_str" : "321673369424654337",
  "in_reply_to_user_id" : 37292353,
  "text" : "@concop100 LOL.. exactly!",
  "id" : 321673369424654337,
  "in_reply_to_status_id" : 321672828942442496,
  "created_at" : "2013-04-09 17:18:02 +0000",
  "in_reply_to_screen_name" : "concop100",
  "in_reply_to_user_id_str" : "37292353",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Reeves",
      "screen_name" : "concop100",
      "indices" : [ 3, 13 ],
      "id_str" : "37292353",
      "id" : 37292353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321673285354016768",
  "text" : "RT @concop100: \"ma'am is your first name Alyce?\". \"Mr Martinez if you assess my birth records, coupled with my drivers license you are c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321672828942442496",
    "text" : "\"ma'am is your first name Alyce?\". \"Mr Martinez if you assess my birth records, coupled with my drivers license you are correct\"  #JodiArias",
    "id" : 321672828942442496,
    "created_at" : "2013-04-09 17:15:53 +0000",
    "user" : {
      "name" : "Mark Reeves",
      "screen_name" : "concop100",
      "protected" : false,
      "id_str" : "37292353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3430525585\/b8bfbb350fb271d827a0d54752145fde_normal.jpeg",
      "id" : 37292353,
      "verified" : false
    }
  },
  "id" : 321673285354016768,
  "created_at" : "2013-04-09 17:17:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beautifulday",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321668710358196224",
  "text" : "Spring has sprung! : ) #beautifulday",
  "id" : 321668710358196224,
  "created_at" : "2013-04-09 16:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321610387810312192",
  "geo" : { },
  "id_str" : "321613554182651904",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible maybe some.. but most just dont want religion forced down their throat is all..",
  "id" : 321613554182651904,
  "in_reply_to_status_id" : 321610387810312192,
  "created_at" : "2013-04-09 13:20:21 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321611095854960641",
  "geo" : { },
  "id_str" : "321612958264340480",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench big (((hugs))) .. one moment at a time.. breathe.",
  "id" : 321612958264340480,
  "in_reply_to_status_id" : 321611095854960641,
  "created_at" : "2013-04-09 13:17:59 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321611870551302146",
  "text" : "@BeaEdyson that makes me feel special : )",
  "id" : 321611870551302146,
  "created_at" : "2013-04-09 13:13:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/it0mSWNjEt",
      "expanded_url" : "http:\/\/amzn.to\/T4rD5G",
      "display_url" : "amzn.to\/T4rD5G"
    } ]
  },
  "geo" : { },
  "id_str" : "321445667937599488",
  "text" : "finished Don't Fear The Reaper by Garry Kay http:\/\/t.co\/it0mSWNjEt",
  "id" : 321445667937599488,
  "created_at" : "2013-04-09 02:13:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321409910946533376",
  "geo" : { },
  "id_str" : "321415514477973504",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides Hopefully. I like the sound of that. : )",
  "id" : 321415514477973504,
  "in_reply_to_status_id" : 321409910946533376,
  "created_at" : "2013-04-09 00:13:24 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321378359986774017",
  "text" : "TA &amp; JA dated 5 months. after that JA pursued TA.. making herself available. TA's only crime.. being too nice to #jodiarias",
  "id" : 321378359986774017,
  "created_at" : "2013-04-08 21:45:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherry \u24CB",
      "screen_name" : "BTLover2",
      "indices" : [ 3, 12 ],
      "id_str" : "38173250",
      "id" : 38173250
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 61, 71 ]
    }, {
      "text" : "gojuan",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321376848804204545",
  "text" : "RT @BTLover2: What this shows us is that ALV never looked at #jodiarias as the potential abuser!! #gojuan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 47, 57 ]
      }, {
        "text" : "gojuan",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321374993395118081",
    "text" : "What this shows us is that ALV never looked at #jodiarias as the potential abuser!! #gojuan",
    "id" : 321374993395118081,
    "created_at" : "2013-04-08 21:32:23 +0000",
    "user" : {
      "name" : "Sherry \u24CB",
      "screen_name" : "BTLover2",
      "protected" : false,
      "id_str" : "38173250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000363789626\/1eb9be08414633881751b00f4a2fba04_normal.jpeg",
      "id" : 38173250,
      "verified" : false
    }
  },
  "id" : 321376848804204545,
  "created_at" : "2013-04-08 21:39:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanie Aumann",
      "screen_name" : "bobcatrules",
      "indices" : [ 69, 81 ],
      "id_str" : "317122386",
      "id" : 317122386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321338826717007872",
  "geo" : { },
  "id_str" : "321339572673990656",
  "in_reply_to_user_id" : 279024097,
  "text" : "@SuzinNEOhio exactly.. and not a peck on the cheek kiss, either..lol @bobcatrules",
  "id" : 321339572673990656,
  "in_reply_to_status_id" : 321338826717007872,
  "created_at" : "2013-04-08 19:11:38 +0000",
  "in_reply_to_screen_name" : "CatsGuardian2",
  "in_reply_to_user_id_str" : "279024097",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321266530115526656",
  "text" : "Juan is going to blow the Defense out of the water #jodiarias",
  "id" : 321266530115526656,
  "created_at" : "2013-04-08 14:21:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321265102902919168",
  "text" : "will be watching Juan Martinez continue cross examine LaViolette later today #jodiarias",
  "id" : 321265102902919168,
  "created_at" : "2013-04-08 14:15:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321258634254372864",
  "text" : "RT @CoryBooker: May we help more than we hurt, may we seek to understand more than be understood, and may we love more than we judge.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321026250820960262",
    "text" : "May we help more than we hurt, may we seek to understand more than be understood, and may we love more than we judge.",
    "id" : 321026250820960262,
    "created_at" : "2013-04-07 22:26:37 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 321258634254372864,
  "created_at" : "2013-04-08 13:50:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321248130668560384",
  "geo" : { },
  "id_str" : "321257908321001474",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft also i am #INFP personality. i depend more upon intuition, feelings than logic.",
  "id" : 321257908321001474,
  "in_reply_to_status_id" : 321248130668560384,
  "created_at" : "2013-04-08 13:47:08 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321248130668560384",
  "geo" : { },
  "id_str" : "321257593517522946",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft nature, animals, reading, feeling. knowing more to world than what we see and pondering, questioning.",
  "id" : 321257593517522946,
  "in_reply_to_status_id" : 321248130668560384,
  "created_at" : "2013-04-08 13:45:53 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321243625042345984",
  "geo" : { },
  "id_str" : "321256458220105728",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time she's actually talking about (maybe even excited?) community college in Fall 2014. she was very anti-college for long time! : )",
  "id" : 321256458220105728,
  "in_reply_to_status_id" : 321243625042345984,
  "created_at" : "2013-04-08 13:41:22 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321242243379900417",
  "geo" : { },
  "id_str" : "321243816776568832",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft since a child, ive been a seeker and was encouraged to find my own beliefs.",
  "id" : 321243816776568832,
  "in_reply_to_status_id" : 321242243379900417,
  "created_at" : "2013-04-08 12:51:09 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321242243379900417",
  "geo" : { },
  "id_str" : "321243547632291840",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft i think there are more non-dogmatic christians than you think. every christian ive met believes slightly diff than others.",
  "id" : 321243547632291840,
  "in_reply_to_status_id" : 321242243379900417,
  "created_at" : "2013-04-08 12:50:04 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321242226908876801",
  "text" : "DD had awesome time at con. met up w new friend from last con.",
  "id" : 321242226908876801,
  "created_at" : "2013-04-08 12:44:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321083719668617216",
  "geo" : { },
  "id_str" : "321241367961563136",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft did i say I was? lol.. i consider myself a christian mutt (somewhat christian as base then a sprinkle of this, tad of that)",
  "id" : 321241367961563136,
  "in_reply_to_status_id" : 321083719668617216,
  "created_at" : "2013-04-08 12:41:25 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "indices" : [ 3, 13 ],
      "id_str" : "529048622",
      "id" : 529048622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321068054484234240",
  "text" : "RT @alanhdawe: The Prime Cause in the universe is God-Consciousness. As everything hs a cause there can be no time when a Prime Cause di ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TGFBook",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321067171721650176",
    "text" : "The Prime Cause in the universe is God-Consciousness. As everything hs a cause there can be no time when a Prime Cause didn't exist #TGFBook",
    "id" : 321067171721650176,
    "created_at" : "2013-04-08 01:09:13 +0000",
    "user" : {
      "name" : "Alan H Dawe",
      "screen_name" : "alanhdawe",
      "protected" : false,
      "id_str" : "529048622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2989409556\/af6adf9842aeda837a1009e58b9926c2_normal.png",
      "id" : 529048622,
      "verified" : false
    }
  },
  "id" : 321068054484234240,
  "created_at" : "2013-04-08 01:12:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "LSF",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321058734996598784",
  "text" : "RT @LSFProgram: No one saves us but ourselves. No one can and no one may. We ourselves must walk the path. - Buddha #quote #LSF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 100, 106 ]
      }, {
        "text" : "LSF",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321058068735610880",
    "text" : "No one saves us but ourselves. No one can and no one may. We ourselves must walk the path. - Buddha #quote #LSF",
    "id" : 321058068735610880,
    "created_at" : "2013-04-08 00:33:03 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 321058734996598784,
  "created_at" : "2013-04-08 00:35:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321046157579145217",
  "geo" : { },
  "id_str" : "321058375909638144",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft nobody needs salvation thru Christ. Jesus is just 1 path of many 2 God. Finding God is just finding ourselves.",
  "id" : 321058375909638144,
  "in_reply_to_status_id" : 321046157579145217,
  "created_at" : "2013-04-08 00:34:16 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rock\u26A1\uFE0FGod",
      "screen_name" : "redpawn3",
      "indices" : [ 3, 12 ],
      "id_str" : "191213471",
      "id" : 191213471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321054340263579649",
  "text" : "RT @redpawn3: After getting a karate chop to the leg.\n\n6: Dad, you know the best way to defeat your enemy?\nM: Tell me.\n6: Make them your ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "321052727692124160",
    "text" : "After getting a karate chop to the leg.\n\n6: Dad, you know the best way to defeat your enemy?\nM: Tell me.\n6: Make them your friend.",
    "id" : 321052727692124160,
    "created_at" : "2013-04-08 00:11:49 +0000",
    "user" : {
      "name" : "Rock\u26A1\uFE0FGod",
      "screen_name" : "redpawn3",
      "protected" : false,
      "id_str" : "191213471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776411699515691024\/WrI1PM6l_normal.jpg",
      "id" : 191213471,
      "verified" : false
    }
  },
  "id" : 321054340263579649,
  "created_at" : "2013-04-08 00:18:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "APenAndADream",
      "screen_name" : "APenAndADream",
      "indices" : [ 61, 75 ],
      "id_str" : "740926623759863808",
      "id" : 740926623759863808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319512955878268928",
  "geo" : { },
  "id_str" : "321053430716186624",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous how the hell did i miss this? wow!! : ) congrats! @APenAndADream",
  "id" : 321053430716186624,
  "in_reply_to_status_id" : 319512955878268928,
  "created_at" : "2013-04-08 00:14:37 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321044117914279937",
  "geo" : { },
  "id_str" : "321052129919913985",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell certainly NOT diamonds.. (gal at TKD used to tell me \"hubby'll get you diamonds if you kick that board..lol)",
  "id" : 321052129919913985,
  "in_reply_to_status_id" : 321044117914279937,
  "created_at" : "2013-04-08 00:09:27 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321033165709918208",
  "geo" : { },
  "id_str" : "321043626794819584",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft sorry, im not following?",
  "id" : 321043626794819584,
  "in_reply_to_status_id" : 321033165709918208,
  "created_at" : "2013-04-07 23:35:39 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sew Witchy",
      "screen_name" : "SisterSorcha",
      "indices" : [ 0, 13 ],
      "id_str" : "36200541",
      "id" : 36200541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321027010606534658",
  "geo" : { },
  "id_str" : "321034104948785152",
  "in_reply_to_user_id" : 36200541,
  "text" : "@SisterSorcha ohh.. its a parody site...",
  "id" : 321034104948785152,
  "in_reply_to_status_id" : 321027010606534658,
  "created_at" : "2013-04-07 22:57:49 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sew Witchy",
      "screen_name" : "SisterSorcha",
      "indices" : [ 0, 13 ],
      "id_str" : "36200541",
      "id" : 36200541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321027010606534658",
  "geo" : { },
  "id_str" : "321032089891917824",
  "in_reply_to_user_id" : 36200541,
  "text" : "@SisterSorcha umm.. wow.",
  "id" : 321032089891917824,
  "in_reply_to_status_id" : 321027010606534658,
  "created_at" : "2013-04-07 22:49:49 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "321004908847435777",
  "geo" : { },
  "id_str" : "321031031086002178",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft im still sorting out how i feel about it. i dont believe in original sin or hell.",
  "id" : 321031031086002178,
  "in_reply_to_status_id" : 321004908847435777,
  "created_at" : "2013-04-07 22:45:36 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320937084137398272",
  "geo" : { },
  "id_str" : "320938757622730752",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible LOL : )",
  "id" : 320938757622730752,
  "in_reply_to_status_id" : 320937084137398272,
  "created_at" : "2013-04-07 16:38:57 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen ebooks",
      "screen_name" : "Zen_ebooks",
      "indices" : [ 3, 14 ],
      "id_str" : "580248703",
      "id" : 580248703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320936281620238336",
  "text" : "RT @Zen_ebooks: I don't even know who this \"me\" is, and the \"I\" that doesn't know it is itself unknown to me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317099306303762433",
    "text" : "I don't even know who this \"me\" is, and the \"I\" that doesn't know it is itself unknown to me.",
    "id" : 317099306303762433,
    "created_at" : "2013-03-28 02:22:20 +0000",
    "user" : {
      "name" : "Zen ebooks",
      "screen_name" : "Zen_ebooks",
      "protected" : false,
      "id_str" : "580248703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2218852837\/zenhorse_normal.jpg",
      "id" : 580248703,
      "verified" : false
    }
  },
  "id" : 320936281620238336,
  "created_at" : "2013-04-07 16:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/AOHeKfoQdN",
      "expanded_url" : "http:\/\/babelbooth.com\/2013\/03\/23\/the-double-bind-of-remorse-and-of-redemption\/#comment-229",
      "display_url" : "babelbooth.com\/2013\/03\/23\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320934059968692224",
  "text" : "\"Until people start realizing that crime is in great part a result of society\u2019s...\" http:\/\/t.co\/AOHeKfoQdN",
  "id" : 320934059968692224,
  "created_at" : "2013-04-07 16:20:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320933343199895553",
  "text" : "my brain, my brain... are psychopaths born that way? can they change? do we have free will? does anything truly matter?",
  "id" : 320933343199895553,
  "created_at" : "2013-04-07 16:17:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin O'Mallow",
      "screen_name" : "polerin",
      "indices" : [ 3, 11 ],
      "id_str" : "57115792",
      "id" : 57115792
    }, {
      "name" : "Amadi",
      "screen_name" : "amaditalks",
      "indices" : [ 13, 24 ],
      "id_str" : "23004495",
      "id" : 23004495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320928978657480704",
  "text" : "RT @polerin: @amaditalks not to mention the fact that treating schools like a business also means kids are commodities which is creepy a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amadi",
        "screen_name" : "amaditalks",
        "indices" : [ 0, 11 ],
        "id_str" : "23004495",
        "id" : 23004495
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "320919707664396291",
    "geo" : { },
    "id_str" : "320919981900591104",
    "in_reply_to_user_id" : 23004495,
    "text" : "@amaditalks not to mention the fact that treating schools like a business also means kids are commodities which is creepy as FUCK.",
    "id" : 320919981900591104,
    "in_reply_to_status_id" : 320919707664396291,
    "created_at" : "2013-04-07 15:24:20 +0000",
    "in_reply_to_screen_name" : "amaditalks",
    "in_reply_to_user_id_str" : "23004495",
    "user" : {
      "name" : "Erin O'Mallow",
      "screen_name" : "polerin",
      "protected" : false,
      "id_str" : "57115792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795770169914060801\/IWITrKjL_normal.jpg",
      "id" : 57115792,
      "verified" : false
    }
  },
  "id" : 320928978657480704,
  "created_at" : "2013-04-07 16:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 66, 81 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320892736238649347",
  "geo" : { },
  "id_str" : "320928425315553280",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft um.. no? one can be a christian w\/o being dogmatic @AnnotatedBible",
  "id" : 320928425315553280,
  "in_reply_to_status_id" : 320892736238649347,
  "created_at" : "2013-04-07 15:57:53 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "0x1A4",
      "screen_name" : "RadicalSkeptic",
      "indices" : [ 0, 15 ],
      "id_str" : "539520569",
      "id" : 539520569
    }, {
      "name" : "Courtney Hammett\u2764",
      "screen_name" : "CourtneyHammett",
      "indices" : [ 16, 32 ],
      "id_str" : "35111933",
      "id" : 35111933
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 33, 48 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320916359477338112",
  "geo" : { },
  "id_str" : "320921733207040000",
  "in_reply_to_user_id" : 539520569,
  "text" : "@RadicalSkeptic @CourtneyHammett @AnnotatedBible not sure if that helped or not.. made my head spin round.. ack! lol",
  "id" : 320921733207040000,
  "in_reply_to_status_id" : 320916359477338112,
  "created_at" : "2013-04-07 15:31:18 +0000",
  "in_reply_to_screen_name" : "RadicalSkeptic",
  "in_reply_to_user_id_str" : "539520569",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320919911645999105",
  "geo" : { },
  "id_str" : "320920570378207232",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible to me, there is a diff. agnostic is unsure while atheist is definite.",
  "id" : 320920570378207232,
  "in_reply_to_status_id" : 320919911645999105,
  "created_at" : "2013-04-07 15:26:41 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hines",
      "screen_name" : "CherishSin",
      "indices" : [ 0, 11 ],
      "id_str" : "493953972",
      "id" : 493953972
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 102, 117 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320912459852546048",
  "geo" : { },
  "id_str" : "320915135218716674",
  "in_reply_to_user_id" : 493953972,
  "text" : "@CherishSin i certainly dont want to be governed by church law either even tho i believe there is God @AnnotatedBible",
  "id" : 320915135218716674,
  "in_reply_to_status_id" : 320912459852546048,
  "created_at" : "2013-04-07 15:05:05 +0000",
  "in_reply_to_screen_name" : "CherishSin",
  "in_reply_to_user_id_str" : "493953972",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320910588198916097",
  "geo" : { },
  "id_str" : "320914564273283074",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible i dont agree w that. you'd have to say same for \"christians\" then, no?",
  "id" : 320914564273283074,
  "in_reply_to_status_id" : 320910588198916097,
  "created_at" : "2013-04-07 15:02:49 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Hammett\u2764",
      "screen_name" : "CourtneyHammett",
      "indices" : [ 0, 16 ],
      "id_str" : "35111933",
      "id" : 35111933
    }, {
      "name" : "0x1A4",
      "screen_name" : "RadicalSkeptic",
      "indices" : [ 17, 32 ],
      "id_str" : "539520569",
      "id" : 539520569
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 33, 48 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320903205200486402",
  "geo" : { },
  "id_str" : "320913463876648960",
  "in_reply_to_user_id" : 35111933,
  "text" : "@CourtneyHammett @RadicalSkeptic @AnnotatedBible meaning you can be both? dont understand that... one is \"no god\", one is \"maybe god\"",
  "id" : 320913463876648960,
  "in_reply_to_status_id" : 320903205200486402,
  "created_at" : "2013-04-07 14:58:26 +0000",
  "in_reply_to_screen_name" : "CourtneyHammett",
  "in_reply_to_user_id_str" : "35111933",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/B5rLbhUvgO",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/04\/03\/opinion\/ackers-holmes-death-penalty\/index.html",
      "display_url" : "cnn.com\/2013\/04\/03\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320911763837165568",
  "text" : "Why death penalty for Holmes wouldn't bring justice http:\/\/t.co\/B5rLbhUvgO",
  "id" : 320911763837165568,
  "created_at" : "2013-04-07 14:51:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320908786250444800",
  "text" : "RT @damienechols: \"A gentle tongue brings healing.\"\n- Proverbs-\n\nIt's amazing what a few kind words can do.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "320906127518887937",
    "text" : "\"A gentle tongue brings healing.\"\n- Proverbs-\n\nIt's amazing what a few kind words can do.",
    "id" : 320906127518887937,
    "created_at" : "2013-04-07 14:29:17 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 320908786250444800,
  "created_at" : "2013-04-07 14:39:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/48cdTbZx7f",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/04\/07\/opinion\/lessig-washington-corruption\/index.html",
      "display_url" : "cnn.com\/2013\/04\/07\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320907979379589121",
  "text" : "interesting, makes sense &gt;&gt; Why Washington is corrupt http:\/\/t.co\/48cdTbZx7f",
  "id" : 320907979379589121,
  "created_at" : "2013-04-07 14:36:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 2, 17 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320588899426648064",
  "geo" : { },
  "id_str" : "320589954336059393",
  "in_reply_to_user_id" : 242204735,
  "text" : ". @AnnotatedBible the intent behind the words is what gives them power... same for thoughts...",
  "id" : 320589954336059393,
  "in_reply_to_status_id" : 320588899426648064,
  "created_at" : "2013-04-06 17:32:56 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320589460767113216",
  "text" : "hubby's burning incense while he cleans.. and it's making me ill...",
  "id" : 320589460767113216,
  "created_at" : "2013-04-06 17:30:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/2xAkl3z22S",
      "expanded_url" : "http:\/\/amzn.to\/XZDnNq",
      "display_url" : "amzn.to\/XZDnNq"
    } ]
  },
  "geo" : { },
  "id_str" : "320367241445130241",
  "text" : "finished The God Franchise: A Theory of Everything by Alan H. Dawe http:\/\/t.co\/2xAkl3z22S",
  "id" : 320367241445130241,
  "created_at" : "2013-04-06 02:47:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "chrisbr40",
      "indices" : [ 0, 10 ],
      "id_str" : "540023255",
      "id" : 540023255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320330551531823105",
  "in_reply_to_user_id" : 540023255,
  "text" : "@chrisbr40 the one witness (lady in blue) said her opinion of him changed. i wanted to hear why but they didnt get into that.",
  "id" : 320330551531823105,
  "created_at" : "2013-04-06 00:22:09 +0000",
  "in_reply_to_screen_name" : "chrisbr40",
  "in_reply_to_user_id_str" : "540023255",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "laws",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320319961102970880",
  "text" : "oh for petes sake.. lets just make it illegal to walk out front door w\/o having weekly activity form approved, signed in triplicate!! #laws",
  "id" : 320319961102970880,
  "created_at" : "2013-04-05 23:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320318305355317248",
  "text" : "@shiniestmarble ((hugs))",
  "id" : 320318305355317248,
  "created_at" : "2013-04-05 23:33:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schaffhausen",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320259224095580160",
  "text" : "@ThatFunkyPunky and I believe he said he'd let #schaffhausen watch his kids? wth?",
  "id" : 320259224095580160,
  "created_at" : "2013-04-05 19:38:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "chrisbr40",
      "indices" : [ 0, 10 ],
      "id_str" : "540023255",
      "id" : 540023255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320257544750772224",
  "geo" : { },
  "id_str" : "320258788026380288",
  "in_reply_to_user_id" : 540023255,
  "text" : "@chrisbr40 its like pulling teeth with him",
  "id" : 320258788026380288,
  "in_reply_to_status_id" : 320257544750772224,
  "created_at" : "2013-04-05 19:36:59 +0000",
  "in_reply_to_screen_name" : "chrisbr40",
  "in_reply_to_user_id_str" : "540023255",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "schaffhausen",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320257109059072002",
  "text" : "@ThatFunkyPunky i just dont get this guy wanting to protect #schaffhausen",
  "id" : 320257109059072002,
  "created_at" : "2013-04-05 19:30:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Burnt Orange Report",
      "screen_name" : "BOR",
      "indices" : [ 3, 7 ],
      "id_str" : "28945635",
      "id" : 28945635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/yShRx9v436",
      "expanded_url" : "http:\/\/bit.ly\/16xZcD0",
      "display_url" : "bit.ly\/16xZcD0"
    } ]
  },
  "geo" : { },
  "id_str" : "320254295704489984",
  "text" : "RT @BOR: Gov. Perry Makes Disgusting Comment About Murder of Texas DA http:\/\/t.co\/yShRx9v436",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/yShRx9v436",
        "expanded_url" : "http:\/\/bit.ly\/16xZcD0",
        "display_url" : "bit.ly\/16xZcD0"
      } ]
    },
    "geo" : { },
    "id_str" : "320250698811973632",
    "text" : "Gov. Perry Makes Disgusting Comment About Murder of Texas DA http:\/\/t.co\/yShRx9v436",
    "id" : 320250698811973632,
    "created_at" : "2013-04-05 19:04:51 +0000",
    "user" : {
      "name" : "Burnt Orange Report",
      "screen_name" : "BOR",
      "protected" : false,
      "id_str" : "28945635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510990385426886656\/7WQyOpf__normal.jpeg",
      "id" : 28945635,
      "verified" : false
    }
  },
  "id" : 320254295704489984,
  "created_at" : "2013-04-05 19:19:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    }, {
      "name" : "TamiShields",
      "screen_name" : "TamiShields",
      "indices" : [ 14, 26 ],
      "id_str" : "18398793",
      "id" : 18398793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320243831805210624",
  "geo" : { },
  "id_str" : "320246978619506690",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields @TamiShields lucky you! have fun! : )",
  "id" : 320246978619506690,
  "in_reply_to_status_id" : 320243831805210624,
  "created_at" : "2013-04-05 18:50:04 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319952338024529920",
  "text" : "Juan is the man.. and he's got a plan! Go, Juan, go! #jodiarias",
  "id" : 319952338024529920,
  "created_at" : "2013-04-04 23:19:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose",
      "screen_name" : "Luv_4Dogs",
      "indices" : [ 3, 13 ],
      "id_str" : "1268420155",
      "id" : 1268420155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319948355990081536",
  "text" : "RT @Luv_4Dogs: #jodiarias cheering for JM. omg! I yelled so loud i scared my dog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319947797078081536",
    "text" : "#jodiarias cheering for JM. omg! I yelled so loud i scared my dog",
    "id" : 319947797078081536,
    "created_at" : "2013-04-04 23:01:13 +0000",
    "user" : {
      "name" : "Rose",
      "screen_name" : "Luv_4Dogs",
      "protected" : false,
      "id_str" : "1268420155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460201937984421889\/nyCqlyVZ_normal.png",
      "id" : 1268420155,
      "verified" : false
    }
  },
  "id" : 319948355990081536,
  "created_at" : "2013-04-04 23:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319940923326865409",
  "geo" : { },
  "id_str" : "319941696517455872",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 omg.. yes!",
  "id" : 319941696517455872,
  "in_reply_to_status_id" : 319940923326865409,
  "created_at" : "2013-04-04 22:36:59 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319927883940372482",
  "geo" : { },
  "id_str" : "319929079308640256",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 he seems like he was just a nice kid who was nice to everyone.",
  "id" : 319929079308640256,
  "in_reply_to_status_id" : 319927883940372482,
  "created_at" : "2013-04-04 21:46:51 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "juror5",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "jodiarias",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319925415785406464",
  "text" : "#juror5 who cares if she's in gallery? she doesnt know any more than the rest of us (even less actually) re: #jodiarias trial",
  "id" : 319925415785406464,
  "created_at" : "2013-04-04 21:32:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wild About Trial",
      "screen_name" : "WildAboutTrial",
      "indices" : [ 0, 15 ],
      "id_str" : "465781550",
      "id" : 465781550
    }, {
      "name" : "IG: ProphetofRise",
      "screen_name" : "Alizzo",
      "indices" : [ 56, 63 ],
      "id_str" : "17914106",
      "id" : 17914106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319922453604352001",
  "geo" : { },
  "id_str" : "319924076779028480",
  "in_reply_to_user_id" : 465781550,
  "text" : "@WildAboutTrial everybody chant now \"Juan! Juan! Juan!\" @Alizzo",
  "id" : 319924076779028480,
  "in_reply_to_status_id" : 319922453604352001,
  "created_at" : "2013-04-04 21:26:58 +0000",
  "in_reply_to_screen_name" : "WildAboutTrial",
  "in_reply_to_user_id_str" : "465781550",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shannon",
      "screen_name" : "groove2theblues",
      "indices" : [ 3, 19 ],
      "id_str" : "203804565",
      "id" : 203804565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319920584492457986",
  "text" : "RT @groove2theblues: I think what the defense is doing to TA right now is character assassination #jodiarias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 77, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319920128064110592",
    "text" : "I think what the defense is doing to TA right now is character assassination #jodiarias",
    "id" : 319920128064110592,
    "created_at" : "2013-04-04 21:11:17 +0000",
    "user" : {
      "name" : "shannon",
      "screen_name" : "groove2theblues",
      "protected" : false,
      "id_str" : "203804565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554826631052025856\/CO_hyOvD_normal.jpeg",
      "id" : 203804565,
      "verified" : false
    }
  },
  "id" : 319920584492457986,
  "created_at" : "2013-04-04 21:13:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose",
      "screen_name" : "Luv_4Dogs",
      "indices" : [ 3, 13 ],
      "id_str" : "1268420155",
      "id" : 1268420155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319917090058412032",
  "text" : "RT @Luv_4Dogs: #jodiarias omg! i am sceaming at the computer!! she IS a sociopath",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319916041205596161",
    "text" : "#jodiarias omg! i am sceaming at the computer!! she IS a sociopath",
    "id" : 319916041205596161,
    "created_at" : "2013-04-04 20:55:02 +0000",
    "user" : {
      "name" : "Rose",
      "screen_name" : "Luv_4Dogs",
      "protected" : false,
      "id_str" : "1268420155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460201937984421889\/nyCqlyVZ_normal.png",
      "id" : 1268420155,
      "verified" : false
    }
  },
  "id" : 319917090058412032,
  "created_at" : "2013-04-04 20:59:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319916491560587264",
  "text" : "JW is really gonna drag this out, isnt she? (((whine))) im waiting for Juan to set things straight! #jodiarias",
  "id" : 319916491560587264,
  "created_at" : "2013-04-04 20:56:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319915971353657344",
  "text" : "my wireless mouse is acting crazy.. and i cannot find my wired mouse.. ack!!",
  "id" : 319915971353657344,
  "created_at" : "2013-04-04 20:54:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nilsa",
      "screen_name" : "NilsaNY",
      "indices" : [ 0, 8 ],
      "id_str" : "328654885",
      "id" : 328654885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319905728968130560",
  "geo" : { },
  "id_str" : "319907352834879489",
  "in_reply_to_user_id" : 328654885,
  "text" : "@NilsaNY No. I don't think he did anything outside reasonable behavior.",
  "id" : 319907352834879489,
  "in_reply_to_status_id" : 319905728968130560,
  "created_at" : "2013-04-04 20:20:31 +0000",
  "in_reply_to_screen_name" : "NilsaNY",
  "in_reply_to_user_id_str" : "328654885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "clarke",
      "screen_name" : "radicalhearts",
      "indices" : [ 3, 17 ],
      "id_str" : "22101273",
      "id" : 22101273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319893602350268417",
  "text" : "RT @radicalhearts: 3. Children (nor adults) should never have to \"earn\" the right to eat and have shelter.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319081540518813697",
    "text" : "3. Children (nor adults) should never have to \"earn\" the right to eat and have shelter.",
    "id" : 319081540518813697,
    "created_at" : "2013-04-02 13:39:02 +0000",
    "user" : {
      "name" : "clarke",
      "screen_name" : "radicalhearts",
      "protected" : false,
      "id_str" : "22101273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2750834173\/c5103104e6baabbb70566ae117c5461b_normal.png",
      "id" : 22101273,
      "verified" : false
    }
  },
  "id" : 319893602350268417,
  "created_at" : "2013-04-04 19:25:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319887687551172608",
  "text" : "so glad so many feel as I do re: #jodiarias - frustration w the lies. means im not crazy? lol",
  "id" : 319887687551172608,
  "created_at" : "2013-04-04 19:02:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319877689018286080",
  "text" : "Will all the calls from JA to TA June 3,4 come up? (when she was travelling)  #jodiarias",
  "id" : 319877689018286080,
  "created_at" : "2013-04-04 18:22:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/Fl38MiZUX5",
      "expanded_url" : "http:\/\/www.azcentral.com\/community\/mesa\/articles\/20130110community-mesa-articles-jodi-arias-murder-trial-mesa-arizona-live-video.html",
      "display_url" : "azcentral.com\/community\/mesa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319866155630227457",
  "text" : "@iheartinsession http:\/\/t.co\/Fl38MiZUX5",
  "id" : 319866155630227457,
  "created_at" : "2013-04-04 17:36:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby King",
      "screen_name" : "JaxBobbyKing",
      "indices" : [ 3, 16 ],
      "id_str" : "600363045",
      "id" : 600363045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319614974425182208",
  "text" : "RT @JaxBobbyKing: Crap on cracker - Aetna CEO pockets 10.2 mil in Salary",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316301141782704128",
    "text" : "Crap on cracker - Aetna CEO pockets 10.2 mil in Salary",
    "id" : 316301141782704128,
    "created_at" : "2013-03-25 21:30:43 +0000",
    "user" : {
      "name" : "Bobby King",
      "screen_name" : "JaxBobbyKing",
      "protected" : false,
      "id_str" : "600363045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459386645599371264\/qp_bRRBF_normal.jpeg",
      "id" : 600363045,
      "verified" : false
    }
  },
  "id" : 319614974425182208,
  "created_at" : "2013-04-04 00:58:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319608317058105344",
  "text" : "I loved The Most Important Thing Happening by Mark Steele - brilliant! metaphorical, philosophical",
  "id" : 319608317058105344,
  "created_at" : "2013-04-04 00:32:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 3, 15 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319607490046226432",
  "text" : "RT @tommysalami: So yeah, a Virginia lawmaker wants to ban oral and anal sex, and North Carolina wants to make a state religion. Really.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319604329344548866",
    "text" : "So yeah, a Virginia lawmaker wants to ban oral and anal sex, and North Carolina wants to make a state religion. Really.",
    "id" : 319604329344548866,
    "created_at" : "2013-04-04 00:16:24 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 319607490046226432,
  "created_at" : "2013-04-04 00:28:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Reddin",
      "screen_name" : "HomelessHeretic",
      "indices" : [ 0, 16 ],
      "id_str" : "22151795",
      "id" : 22151795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319585635419705344",
  "geo" : { },
  "id_str" : "319594662065229824",
  "in_reply_to_user_id" : 22151795,
  "text" : "@HomelessHeretic locate a local wildlife rehab and ask them?",
  "id" : 319594662065229824,
  "in_reply_to_status_id" : 319585635419705344,
  "created_at" : "2013-04-03 23:37:59 +0000",
  "in_reply_to_screen_name" : "HomelessHeretic",
  "in_reply_to_user_id_str" : "22151795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/p11NWYSEEs",
      "expanded_url" : "http:\/\/amzn.to\/YwxztW",
      "display_url" : "amzn.to\/YwxztW"
    } ]
  },
  "geo" : { },
  "id_str" : "319576384001421312",
  "text" : "finished Afterlife Teaching From Stephen the Martyr by Michael Cocks http:\/\/t.co\/p11NWYSEEs",
  "id" : 319576384001421312,
  "created_at" : "2013-04-03 22:25:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/b8TxcBt78I",
      "expanded_url" : "http:\/\/amzn.to\/WXLgl2",
      "display_url" : "amzn.to\/WXLgl2"
    } ]
  },
  "geo" : { },
  "id_str" : "319574148827475968",
  "text" : "finished The Most Important Thing Happening: A Novel in Stories by Mark Steele http:\/\/t.co\/b8TxcBt78I",
  "id" : 319574148827475968,
  "created_at" : "2013-04-03 22:16:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 93, 105 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/3Ka4bGT3Ff",
      "expanded_url" : "http:\/\/huff.to\/16lMEhU",
      "display_url" : "huff.to\/16lMEhU"
    } ]
  },
  "geo" : { },
  "id_str" : "319555536964161536",
  "text" : "North Carolina May Declare Official State Religion Under New Bill http:\/\/t.co\/3Ka4bGT3Ff via @HuffPostPol",
  "id" : 319555536964161536,
  "created_at" : "2013-04-03 21:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/f0pwHQHQw3",
      "expanded_url" : "http:\/\/www.facebook.com\/Justice4Travis\/posts\/349831905128697",
      "display_url" : "facebook.com\/Justice4Travis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319547356016168960",
  "text" : "creepy &gt;&gt; \"Still beat you... brat!\" http:\/\/t.co\/f0pwHQHQw3 #jodiarias",
  "id" : 319547356016168960,
  "created_at" : "2013-04-03 20:30:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319529486628552706",
  "geo" : { },
  "id_str" : "319530856341446656",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 ALV giving her impressions of relationship using each entry in diary. up to march 08. recess 4 day, ALV ill.",
  "id" : 319530856341446656,
  "in_reply_to_status_id" : 319529486628552706,
  "created_at" : "2013-04-03 19:24:27 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lys",
      "screen_name" : "lyssmakessense",
      "indices" : [ 0, 15 ],
      "id_str" : "922341847",
      "id" : 922341847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319508522016579584",
  "geo" : { },
  "id_str" : "319509703573004288",
  "in_reply_to_user_id" : 922341847,
  "text" : "@lyssmakessense curious.. can you clarify?",
  "id" : 319509703573004288,
  "in_reply_to_status_id" : 319508522016579584,
  "created_at" : "2013-04-03 18:00:24 +0000",
  "in_reply_to_screen_name" : "lyssmakessense",
  "in_reply_to_user_id_str" : "922341847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ILoveMeSomeTaco",
      "screen_name" : "deararl",
      "indices" : [ 0, 8 ],
      "id_str" : "78172568",
      "id" : 78172568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319506527989952512",
  "geo" : { },
  "id_str" : "319507482768732160",
  "in_reply_to_user_id" : 78172568,
  "text" : "@deararl Bingo! : )",
  "id" : 319507482768732160,
  "in_reply_to_status_id" : 319506527989952512,
  "created_at" : "2013-04-03 17:51:34 +0000",
  "in_reply_to_screen_name" : "deararl",
  "in_reply_to_user_id_str" : "78172568",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CraftyFoxy",
      "screen_name" : "TheWholeTruth13",
      "indices" : [ 0, 16 ],
      "id_str" : "3351788403",
      "id" : 3351788403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319504398185283585",
  "geo" : { },
  "id_str" : "319505320856653827",
  "in_reply_to_user_id" : 1266253332,
  "text" : "@TheWholeTruth13 Amen!!",
  "id" : 319505320856653827,
  "in_reply_to_status_id" : 319504398185283585,
  "created_at" : "2013-04-03 17:42:59 +0000",
  "in_reply_to_screen_name" : "BlueLovesMax",
  "in_reply_to_user_id_str" : "1266253332",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CraftyFoxy",
      "screen_name" : "TheWholeTruth13",
      "indices" : [ 3, 19 ],
      "id_str" : "3351788403",
      "id" : 3351788403
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319505071547236352",
  "text" : "RT @TheWholeTruth13: The only abuse I'm buying here is the abuse of Travis Alexander, by his murderer #jodiarias. Proved by \"hard copy p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319504398185283585",
    "text" : "The only abuse I'm buying here is the abuse of Travis Alexander, by his murderer #jodiarias. Proved by \"hard copy photos.\" Period.",
    "id" : 319504398185283585,
    "created_at" : "2013-04-03 17:39:19 +0000",
    "user" : {
      "name" : "Blue",
      "screen_name" : "BlueLovesMax",
      "protected" : false,
      "id_str" : "1266253332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772999433713618945\/myfBCNX-_normal.jpg",
      "id" : 1266253332,
      "verified" : false
    }
  },
  "id" : 319505071547236352,
  "created_at" : "2013-04-03 17:41:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Martinez",
      "screen_name" : "AskJuanMartinez",
      "indices" : [ 3, 19 ],
      "id_str" : "1230635809",
      "id" : 1230635809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319492904013934592",
  "text" : "RT @AskJuanMartinez: God Help Us. It's still fucking October, 2007. We'll need much more than 99 Beers On The Wall. #JodiArias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 95, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319492333110435840",
    "text" : "God Help Us. It's still fucking October, 2007. We'll need much more than 99 Beers On The Wall. #JodiArias",
    "id" : 319492333110435840,
    "created_at" : "2013-04-03 16:51:22 +0000",
    "user" : {
      "name" : "Juan Martinez",
      "screen_name" : "AskJuanMartinez",
      "protected" : false,
      "id_str" : "1230635809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447970355\/3fb3c6edcf3df0bf133c1ea79d58c9b5_normal.png",
      "id" : 1230635809,
      "verified" : false
    }
  },
  "id" : 319492904013934592,
  "created_at" : "2013-04-03 16:53:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2728WiTcHyWizdom\u2728\u2122",
      "screen_name" : "WitchyTweets",
      "indices" : [ 0, 13 ],
      "id_str" : "911788459",
      "id" : 911788459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319468911512928257",
  "geo" : { },
  "id_str" : "319472360992415746",
  "in_reply_to_user_id" : 911788459,
  "text" : "@WitchyTweets in an email to Abe dated Feb 18 (?) 2007 she said not BF\/GF .. just gets more confusing daily..",
  "id" : 319472360992415746,
  "in_reply_to_status_id" : 319468911512928257,
  "created_at" : "2013-04-03 15:32:01 +0000",
  "in_reply_to_screen_name" : "WitchyTweets",
  "in_reply_to_user_id_str" : "911788459",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/27TA7QeHfd",
      "expanded_url" : "http:\/\/www.hlntv.com\/video\/2013\/04\/02\/jodi-arias-mother-interrogation-room",
      "display_url" : "hlntv.com\/video\/2013\/04\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "319462969199165440",
  "text" : "RT @SuzinNEOhio: #jodiarias Mom's tape: http:\/\/t.co\/27TA7QeHfd  re mental issues",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/27TA7QeHfd",
        "expanded_url" : "http:\/\/www.hlntv.com\/video\/2013\/04\/02\/jodi-arias-mother-interrogation-room",
        "display_url" : "hlntv.com\/video\/2013\/04\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "319427762815393793",
    "text" : "#jodiarias Mom's tape: http:\/\/t.co\/27TA7QeHfd  re mental issues",
    "id" : 319427762815393793,
    "created_at" : "2013-04-03 12:34:47 +0000",
    "user" : {
      "name" : "Approach The Bench",
      "screen_name" : "CatsGuardian2",
      "protected" : false,
      "id_str" : "279024097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605119537642676225\/kK8CG0Yq_normal.jpg",
      "id" : 279024097,
      "verified" : false
    }
  },
  "id" : 319462969199165440,
  "created_at" : "2013-04-03 14:54:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LadyJustice",
      "screen_name" : "ladyjustice323",
      "indices" : [ 15, 30 ],
      "id_str" : "1088725386",
      "id" : 1088725386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319229190232760321",
  "geo" : { },
  "id_str" : "319230067999916033",
  "in_reply_to_user_id" : 1015479589,
  "text" : "@AndreaAukrust @ladyjustice323 i need valium to get through this trial!",
  "id" : 319230067999916033,
  "in_reply_to_status_id" : 319229190232760321,
  "created_at" : "2013-04-02 23:29:13 +0000",
  "in_reply_to_screen_name" : "AndreasOpinions",
  "in_reply_to_user_id_str" : "1015479589",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LadyJustice",
      "screen_name" : "ladyjustice323",
      "indices" : [ 0, 15 ],
      "id_str" : "1088725386",
      "id" : 1088725386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319224507946655744",
  "geo" : { },
  "id_str" : "319226020387508224",
  "in_reply_to_user_id" : 1088725386,
  "text" : "@ladyjustice323 oh so very upset!",
  "id" : 319226020387508224,
  "in_reply_to_status_id" : 319224507946655744,
  "created_at" : "2013-04-02 23:13:08 +0000",
  "in_reply_to_screen_name" : "ladyjustice323",
  "in_reply_to_user_id_str" : "1088725386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Crowley",
      "screen_name" : "seanpcrowley",
      "indices" : [ 0, 13 ],
      "id_str" : "222533327",
      "id" : 222533327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319224832174735360",
  "geo" : { },
  "id_str" : "319225197699928064",
  "in_reply_to_user_id" : 222533327,
  "text" : "@seanpcrowley i saw that...",
  "id" : 319225197699928064,
  "in_reply_to_status_id" : 319224832174735360,
  "created_at" : "2013-04-02 23:09:52 +0000",
  "in_reply_to_screen_name" : "seanpcrowley",
  "in_reply_to_user_id_str" : "222533327",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD83Cara\uD83C\uDF7D",
      "screen_name" : "mamapojo",
      "indices" : [ 0, 9 ],
      "id_str" : "762834786",
      "id" : 762834786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319219806932983808",
  "geo" : { },
  "id_str" : "319222346563072001",
  "in_reply_to_user_id" : 762834786,
  "text" : "@mamapojo LOL.. it IS a rather convoluted trial anyway..",
  "id" : 319222346563072001,
  "in_reply_to_status_id" : 319219806932983808,
  "created_at" : "2013-04-02 22:58:32 +0000",
  "in_reply_to_screen_name" : "mamapojo",
  "in_reply_to_user_id_str" : "762834786",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Shelton",
      "screen_name" : "cqqleyes",
      "indices" : [ 3, 12 ],
      "id_str" : "148771553",
      "id" : 148771553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319219555362803713",
  "text" : "RT @cqqleyes: I'm going to need a therapist after this trial. Following this trial makes me feel Like I'm in an \"Alternative Reality!\" C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319217857324015616",
    "text" : "I'm going to need a therapist after this trial. Following this trial makes me feel Like I'm in an \"Alternative Reality!\" CRAZY #jodiarias",
    "id" : 319217857324015616,
    "created_at" : "2013-04-02 22:40:42 +0000",
    "user" : {
      "name" : "Debbie Shelton",
      "screen_name" : "cqqleyes",
      "protected" : false,
      "id_str" : "148771553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474232951094648832\/EPrW-Wex_normal.jpeg",
      "id" : 148771553,
      "verified" : false
    }
  },
  "id" : 319219555362803713,
  "created_at" : "2013-04-02 22:47:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD83Cara\uD83C\uDF7D",
      "screen_name" : "mamapojo",
      "indices" : [ 0, 9 ],
      "id_str" : "762834786",
      "id" : 762834786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319217778500456448",
  "geo" : { },
  "id_str" : "319218321234993152",
  "in_reply_to_user_id" : 762834786,
  "text" : "@mamapojo i believe ALV was referring to Lisa wanting to be a teacher (not Jodi)",
  "id" : 319218321234993152,
  "in_reply_to_status_id" : 319217778500456448,
  "created_at" : "2013-04-02 22:42:33 +0000",
  "in_reply_to_screen_name" : "mamapojo",
  "in_reply_to_user_id_str" : "762834786",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TN Jed",
      "screen_name" : "TNJed3",
      "indices" : [ 0, 7 ],
      "id_str" : "885672606",
      "id" : 885672606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319216027479207936",
  "geo" : { },
  "id_str" : "319216830558392321",
  "in_reply_to_user_id" : 885672606,
  "text" : "@TNJed3 Amen!!",
  "id" : 319216830558392321,
  "in_reply_to_status_id" : 319216027479207936,
  "created_at" : "2013-04-02 22:36:37 +0000",
  "in_reply_to_screen_name" : "TNJed3",
  "in_reply_to_user_id_str" : "885672606",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MS Kelly",
      "screen_name" : "deserteptx",
      "indices" : [ 3, 14 ],
      "id_str" : "803184973",
      "id" : 803184973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319214717178609665",
  "text" : "RT @deserteptx: #JodiArias God Please grant me the strength to not throw my computer out the window.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319213234701877248",
    "text" : "#JodiArias God Please grant me the strength to not throw my computer out the window.",
    "id" : 319213234701877248,
    "created_at" : "2013-04-02 22:22:20 +0000",
    "user" : {
      "name" : "MS Kelly",
      "screen_name" : "deserteptx",
      "protected" : false,
      "id_str" : "803184973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610311393737183234\/jp34O6_q_normal.jpg",
      "id" : 803184973,
      "verified" : false
    }
  },
  "id" : 319214717178609665,
  "created_at" : "2013-04-02 22:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319213384908275712",
  "text" : "they were not married, or BF\/GF .. there can be no cheating or infidelity!! #jodiarias ((headtodesk))",
  "id" : 319213384908275712,
  "created_at" : "2013-04-02 22:22:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319198308730015744",
  "text" : "sooo.. it was all TA's fault for his execution #jodiarias basically thats what im hearing from DEF.. UGH!!",
  "id" : 319198308730015744,
  "created_at" : "2013-04-02 21:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brigitte",
      "screen_name" : "kewlwench13",
      "indices" : [ 0, 12 ],
      "id_str" : "50567379",
      "id" : 50567379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319193912512221185",
  "geo" : { },
  "id_str" : "319197534629285888",
  "in_reply_to_user_id" : 50567379,
  "text" : "@kewlwench13 exactly",
  "id" : 319197534629285888,
  "in_reply_to_status_id" : 319193912512221185,
  "created_at" : "2013-04-02 21:19:57 +0000",
  "in_reply_to_screen_name" : "kewlwench13",
  "in_reply_to_user_id_str" : "50567379",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Lane",
      "screen_name" : "LaneFriends",
      "indices" : [ 3, 15 ],
      "id_str" : "109684115",
      "id" : 109684115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319195586341523456",
  "text" : "RT @LaneFriends: I still don't get how this expert can testify 2 anything about TA since she never met him &amp; all was told 2 her by a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 131, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319194679394590721",
    "text" : "I still don't get how this expert can testify 2 anything about TA since she never met him &amp; all was told 2 her by a known liar #JodiArias",
    "id" : 319194679394590721,
    "created_at" : "2013-04-02 21:08:36 +0000",
    "user" : {
      "name" : "Laura Lane",
      "screen_name" : "LaneFriends",
      "protected" : false,
      "id_str" : "109684115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/906445322\/Tiger_Lane_normal.jpg",
      "id" : 109684115,
      "verified" : false
    }
  },
  "id" : 319195586341523456,
  "created_at" : "2013-04-02 21:12:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Cain",
      "screen_name" : "cainforpresiden",
      "indices" : [ 3, 19 ],
      "id_str" : "475490131",
      "id" : 475490131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319195429617152000",
  "text" : "RT @cainforpresiden: just saying this trial would already be over if an objection of \"and how does this mean she killed Travis in self-d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "319194710138839040",
    "text" : "just saying this trial would already be over if an objection of \"and how does this mean she killed Travis in self-defense?\" #JodiArias",
    "id" : 319194710138839040,
    "created_at" : "2013-04-02 21:08:43 +0000",
    "user" : {
      "name" : "Andy Cain",
      "screen_name" : "cainforpresiden",
      "protected" : false,
      "id_str" : "475490131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529798561220001792\/0OA1XrlW_normal.jpeg",
      "id" : 475490131,
      "verified" : false
    }
  },
  "id" : 319195429617152000,
  "created_at" : "2013-04-02 21:11:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "jodiarias",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319193725769228288",
  "geo" : { },
  "id_str" : "319194264816996353",
  "in_reply_to_user_id" : 1098959714,
  "text" : "RT @AdrenaLynne1 So if #jodiarias doesn't trust TA then WHY does she keep forcing herself back into his life ALYCE!!!!! #jodiarias",
  "id" : 319194264816996353,
  "in_reply_to_status_id" : 319193725769228288,
  "created_at" : "2013-04-02 21:06:57 +0000",
  "in_reply_to_screen_name" : "RavenLilyGirl",
  "in_reply_to_user_id_str" : "1098959714",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inkedrebel",
      "screen_name" : "theinkedrebel",
      "indices" : [ 0, 14 ],
      "id_str" : "771080855695392768",
      "id" : 771080855695392768
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319174430951616512",
  "text" : "@TheInkedRebel ???",
  "id" : 319174430951616512,
  "created_at" : "2013-04-02 19:48:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319157206731857920",
  "geo" : { },
  "id_str" : "319159816826269696",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 HUSH you!! dont even think it!!",
  "id" : 319159816826269696,
  "in_reply_to_status_id" : 319157206731857920,
  "created_at" : "2013-04-02 18:50:04 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319159174456045570",
  "text" : "OMG... im a very easygoing person but this #jodiarias trial is making me sooo angry!",
  "id" : 319159174456045570,
  "created_at" : "2013-04-02 18:47:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Phillips",
      "screen_name" : "findthebrad",
      "indices" : [ 0, 12 ],
      "id_str" : "575266864",
      "id" : 575266864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319154631898968064",
  "geo" : { },
  "id_str" : "319155137782378497",
  "in_reply_to_user_id" : 575266864,
  "text" : "@findthebrad yeah.. me, too",
  "id" : 319155137782378497,
  "in_reply_to_status_id" : 319154631898968064,
  "created_at" : "2013-04-02 18:31:29 +0000",
  "in_reply_to_screen_name" : "findthebrad",
  "in_reply_to_user_id_str" : "575266864",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319154908655919104",
  "text" : "why are they talking about these emails? #jodiarias they don't sound right...",
  "id" : 319154908655919104,
  "created_at" : "2013-04-02 18:30:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319154604141076480",
  "text" : "\"Can we talk about...?\" JW #jodiarias Can someone please shout \"No, we may not!\"",
  "id" : 319154604141076480,
  "created_at" : "2013-04-02 18:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318862378928328704",
  "geo" : { },
  "id_str" : "318865327838601216",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields aww.. congrats!",
  "id" : 318865327838601216,
  "in_reply_to_status_id" : 318862378928328704,
  "created_at" : "2013-04-01 23:19:53 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318848683858866176",
  "text" : "RT @TheOracle13: An eye for an eye will never be justice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318847669718102017",
    "text" : "An eye for an eye will never be justice.",
    "id" : 318847669718102017,
    "created_at" : "2013-04-01 22:09:43 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 318848683858866176,
  "created_at" : "2013-04-01 22:13:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318846406565711872",
  "text" : "dog absolutely has to lick DH's toes! lol",
  "id" : 318846406565711872,
  "created_at" : "2013-04-01 22:04:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lajonda mack",
      "screen_name" : "LJMack2",
      "indices" : [ 0, 8 ],
      "id_str" : "2699812652",
      "id" : 2699812652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318813569967861761",
  "text" : "@LJMack2 PREMED .. Bingo!",
  "id" : 318813569967861761,
  "created_at" : "2013-04-01 19:54:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318723886449577985",
  "geo" : { },
  "id_str" : "318725460173410304",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 say what?? ((facepalm))",
  "id" : 318725460173410304,
  "in_reply_to_status_id" : 318723886449577985,
  "created_at" : "2013-04-01 14:04:05 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hesakeeper",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318724197545308161",
  "text" : "wow. i knocked coffee can to floor. hubby did not blink an eye, just calmly vacuumed it up. #hesakeeper",
  "id" : 318724197545308161,
  "created_at" : "2013-04-01 13:59:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]