Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xe Sands",
      "screen_name" : "xesands",
      "indices" : [ 3, 11 ],
      "id_str" : "149641215",
      "id" : 149641215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/I6B2Xwd316",
      "expanded_url" : "https:\/\/twitter.com\/DerekMarshJr\/status\/682357594480967680",
      "display_url" : "twitter.com\/DerekMarshJr\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682616284031225856",
  "text" : "RT @xesands: Thanks so much for spreading the word! https:\/\/t.co\/I6B2Xwd316",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/I6B2Xwd316",
        "expanded_url" : "https:\/\/twitter.com\/DerekMarshJr\/status\/682357594480967680",
        "display_url" : "twitter.com\/DerekMarshJr\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "682413936008892416",
    "text" : "Thanks so much for spreading the word! https:\/\/t.co\/I6B2Xwd316",
    "id" : 682413936008892416,
    "created_at" : "2015-12-31 04:12:15 +0000",
    "user" : {
      "name" : "Xe Sands",
      "screen_name" : "xesands",
      "protected" : false,
      "id_str" : "149641215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691760723442208768\/8vszP9vz_normal.png",
      "id" : 149641215,
      "verified" : false
    }
  },
  "id" : 682616284031225856,
  "created_at" : "2015-12-31 17:36:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arthur Breur",
      "screen_name" : "arthurbreur",
      "indices" : [ 3, 15 ],
      "id_str" : "16788376",
      "id" : 16788376
    }, {
      "name" : "The Great Courses",
      "screen_name" : "TheGreatCourses",
      "indices" : [ 78, 94 ],
      "id_str" : "20479873",
      "id" : 20479873
    }, {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 98, 110 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grateful",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "books",
      "indices" : [ 111, 117 ]
    }, {
      "text" : "education",
      "indices" : [ 118, 128 ]
    }, {
      "text" : "learning",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682615966618923008",
  "text" : "RT @arthurbreur: Things &amp; people I'm #grateful for from 2015: discovering @TheGreatCourses on @audible_com #books #education #learning #sel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Great Courses",
        "screen_name" : "TheGreatCourses",
        "indices" : [ 61, 77 ],
        "id_str" : "20479873",
        "id" : 20479873
      }, {
        "name" : "Audible",
        "screen_name" : "audible_com",
        "indices" : [ 81, 93 ],
        "id_str" : "21001534",
        "id" : 21001534
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grateful",
        "indices" : [ 24, 33 ]
      }, {
        "text" : "books",
        "indices" : [ 94, 100 ]
      }, {
        "text" : "education",
        "indices" : [ 101, 111 ]
      }, {
        "text" : "learning",
        "indices" : [ 112, 121 ]
      }, {
        "text" : "selfimprovement",
        "indices" : [ 122, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682607321684418560",
    "text" : "Things &amp; people I'm #grateful for from 2015: discovering @TheGreatCourses on @audible_com #books #education #learning #selfimprovement",
    "id" : 682607321684418560,
    "created_at" : "2015-12-31 17:00:42 +0000",
    "user" : {
      "name" : "Arthur Breur",
      "screen_name" : "arthurbreur",
      "protected" : false,
      "id_str" : "16788376",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792835526734643201\/5XP04eSC_normal.jpg",
      "id" : 16788376,
      "verified" : false
    }
  },
  "id" : 682615966618923008,
  "created_at" : "2015-12-31 17:35:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The AudioBookaneers",
      "screen_name" : "AudioBookaneers",
      "indices" : [ 3, 19 ],
      "id_str" : "425921159",
      "id" : 425921159
    }, {
      "name" : "Margaret E. Atwood",
      "screen_name" : "MargaretAtwood",
      "indices" : [ 73, 88 ],
      "id_str" : "54730258",
      "id" : 54730258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhispersyncDeal",
      "indices" : [ 32, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682615778168864768",
  "text" : "RT @AudioBookaneers: Thursday's #WhispersyncDeal is Claire Danes reading @MargaretAtwood's The Handmaid's Tale for $2.99+$3.99 \"The... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Margaret E. Atwood",
        "screen_name" : "MargaretAtwood",
        "indices" : [ 52, 67 ],
        "id_str" : "54730258",
        "id" : 54730258
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhispersyncDeal",
        "indices" : [ 11, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Pb5rJqw5zM",
        "expanded_url" : "http:\/\/fb.me\/52pmbc1Kq",
        "display_url" : "fb.me\/52pmbc1Kq"
      } ]
    },
    "geo" : { },
    "id_str" : "682608214005780480",
    "text" : "Thursday's #WhispersyncDeal is Claire Danes reading @MargaretAtwood's The Handmaid's Tale for $2.99+$3.99 \"The... https:\/\/t.co\/Pb5rJqw5zM",
    "id" : 682608214005780480,
    "created_at" : "2015-12-31 17:04:15 +0000",
    "user" : {
      "name" : "The AudioBookaneers",
      "screen_name" : "AudioBookaneers",
      "protected" : false,
      "id_str" : "425921159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541980081493536768\/5jrzFUpv_normal.jpeg",
      "id" : 425921159,
      "verified" : false
    }
  },
  "id" : 682615778168864768,
  "created_at" : "2015-12-31 17:34:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "indices" : [ 3, 16 ],
      "id_str" : "59801057",
      "id" : 59801057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "earphonesaward",
      "indices" : [ 128, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Z7kCwZrgaV",
      "expanded_url" : "http:\/\/www.audiofilemagazine.com\/reviews\/Read\/102317",
      "display_url" : "audiofilemagazine.com\/reviews\/Read\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682615684543721472",
  "text" : "RT @AudioFileMag: Diverse voices help us develop both understanding &amp; empathy A STEP TOWARD FALLING https:\/\/t.co\/Z7kCwZrgaV #earphonesaward",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "earphonesaward",
        "indices" : [ 110, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/Z7kCwZrgaV",
        "expanded_url" : "http:\/\/www.audiofilemagazine.com\/reviews\/Read\/102317",
        "display_url" : "audiofilemagazine.com\/reviews\/Read\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "682602475879317504",
    "text" : "Diverse voices help us develop both understanding &amp; empathy A STEP TOWARD FALLING https:\/\/t.co\/Z7kCwZrgaV #earphonesaward",
    "id" : 682602475879317504,
    "created_at" : "2015-12-31 16:41:27 +0000",
    "user" : {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "protected" : false,
      "id_str" : "59801057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525009056\/ArrowsforFacebook_normal.jpg",
      "id" : 59801057,
      "verified" : false
    }
  },
  "id" : 682615684543721472,
  "created_at" : "2015-12-31 17:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682392784028987393",
  "geo" : { },
  "id_str" : "682615281093496833",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre im good. taking care of DD w her weird hormone issues but we have ins. so im grateful. : )",
  "id" : 682615281093496833,
  "in_reply_to_status_id" : 682392784028987393,
  "created_at" : "2015-12-31 17:32:20 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682604458543570944",
  "text" : "feel like im descending into madness.. going backwards in my personal evolution. liking myself less and less. wth is going on??",
  "id" : 682604458543570944,
  "created_at" : "2015-12-31 16:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spider Gwendolyn",
      "screen_name" : "dolyn",
      "indices" : [ 3, 9 ],
      "id_str" : "14423341",
      "id" : 14423341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dolyn\/status\/682411667167182848\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/in3o7EZGIj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXhpytEUMAAixom.jpg",
      "id_str" : "682411663358701568",
      "id" : 682411663358701568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXhpytEUMAAixom.jpg",
      "sizes" : [ {
        "h" : 514,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/in3o7EZGIj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682603327473991681",
  "text" : "RT @dolyn: So true https:\/\/t.co\/in3o7EZGIj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dolyn\/status\/682411667167182848\/photo\/1",
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/in3o7EZGIj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXhpytEUMAAixom.jpg",
        "id_str" : "682411663358701568",
        "id" : 682411663358701568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXhpytEUMAAixom.jpg",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/in3o7EZGIj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682411667167182848",
    "text" : "So true https:\/\/t.co\/in3o7EZGIj",
    "id" : 682411667167182848,
    "created_at" : "2015-12-31 04:03:14 +0000",
    "user" : {
      "name" : "Spider Gwendolyn",
      "screen_name" : "dolyn",
      "protected" : false,
      "id_str" : "14423341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798053734425227264\/tnJ5c85V_normal.jpg",
      "id" : 14423341,
      "verified" : false
    }
  },
  "id" : 682603327473991681,
  "created_at" : "2015-12-31 16:44:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Prine",
      "screen_name" : "randyprine",
      "indices" : [ 3, 14 ],
      "id_str" : "37990581",
      "id" : 37990581
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/randyprine\/status\/682417426651332609\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/AZHcBu1ehG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXhvAuoUQAARQ9C.jpg",
      "id_str" : "682417401854443520",
      "id" : 682417401854443520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXhvAuoUQAARQ9C.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/AZHcBu1ehG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682603194430668801",
  "text" : "RT @randyprine: Gosh I'm gonna miss him. https:\/\/t.co\/AZHcBu1ehG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/randyprine\/status\/682417426651332609\/photo\/1",
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/AZHcBu1ehG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXhvAuoUQAARQ9C.jpg",
        "id_str" : "682417401854443520",
        "id" : 682417401854443520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXhvAuoUQAARQ9C.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/AZHcBu1ehG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682417426651332609",
    "text" : "Gosh I'm gonna miss him. https:\/\/t.co\/AZHcBu1ehG",
    "id" : 682417426651332609,
    "created_at" : "2015-12-31 04:26:07 +0000",
    "user" : {
      "name" : "Randy Prine",
      "screen_name" : "randyprine",
      "protected" : false,
      "id_str" : "37990581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797162319386120192\/uFycjy-b_normal.jpg",
      "id" : 37990581,
      "verified" : false
    }
  },
  "id" : 682603194430668801,
  "created_at" : "2015-12-31 16:44:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682445740761845761",
  "geo" : { },
  "id_str" : "682602978101051392",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley mad skills, woman. : )",
  "id" : 682602978101051392,
  "in_reply_to_status_id" : 682445740761845761,
  "created_at" : "2015-12-31 16:43:26 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "FTW",
      "indices" : [ 54, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682453208673988609",
  "geo" : { },
  "id_str" : "682602648168742912",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides i didnt know that. cool beans. #physics #FTW",
  "id" : 682602648168742912,
  "in_reply_to_status_id" : 682453208673988609,
  "created_at" : "2015-12-31 16:42:08 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freespeech",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682556859782422528",
  "geo" : { },
  "id_str" : "682602337475674114",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell i do agree that there is way too much of \"you cant say that\" going around. #freespeech",
  "id" : 682602337475674114,
  "in_reply_to_status_id" : 682556859782422528,
  "created_at" : "2015-12-31 16:40:54 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/rpCjb9aZbl",
      "expanded_url" : "https:\/\/twitter.com\/PsyPost\/status\/682381974728773633",
      "display_url" : "twitter.com\/PsyPost\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682601522627219457",
  "text" : "how about 4x more likely to NOT order dessert when server is thin due to fear of being judged? https:\/\/t.co\/rpCjb9aZbl",
  "id" : 682601522627219457,
  "created_at" : "2015-12-31 16:37:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belle",
      "screen_name" : "_Thinker_Bell__",
      "indices" : [ 3, 19 ],
      "id_str" : "3317000782",
      "id" : 3317000782
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/_Thinker_Bell__\/status\/682567519274663936\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/AQgQo8ThTM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXj3ilrWwAANqiV.jpg",
      "id_str" : "682567517148200960",
      "id" : 682567517148200960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXj3ilrWwAANqiV.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/AQgQo8ThTM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682599903449772032",
  "text" : "RT @_Thinker_Bell__: Not interested in piousness. It's fake. https:\/\/t.co\/AQgQo8ThTM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/_Thinker_Bell__\/status\/682567519274663936\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/AQgQo8ThTM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXj3ilrWwAANqiV.jpg",
        "id_str" : "682567517148200960",
        "id" : 682567517148200960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXj3ilrWwAANqiV.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/AQgQo8ThTM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682567519274663936",
    "text" : "Not interested in piousness. It's fake. https:\/\/t.co\/AQgQo8ThTM",
    "id" : 682567519274663936,
    "created_at" : "2015-12-31 14:22:32 +0000",
    "user" : {
      "name" : "Belle",
      "screen_name" : "_Thinker_Bell__",
      "protected" : false,
      "id_str" : "3317000782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800972858063200256\/qYZcH3Y0_normal.jpg",
      "id" : 3317000782,
      "verified" : false
    }
  },
  "id" : 682599903449772032,
  "created_at" : "2015-12-31 16:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682386405096554500",
  "geo" : { },
  "id_str" : "682392586359836674",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre glad you're home and ok. : )",
  "id" : 682392586359836674,
  "in_reply_to_status_id" : 682386405096554500,
  "created_at" : "2015-12-31 02:47:25 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/dhSASwLV2X",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2015\/12\/30\/1464846\/-NFL-wide-receiver-will-not-apologize-for-wearing-Justice-for-Tamir-Rice-and-John-Crawford-T-shirt",
      "display_url" : "dailykos.com\/story\/2015\/12\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682383972584808448",
  "text" : "NFL wide receiver will not apologize for wearing 'Justice for Tamir Rice and John Crawford' T-shirt https:\/\/t.co\/dhSASwLV2X",
  "id" : 682383972584808448,
  "created_at" : "2015-12-31 02:13:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john osalvo",
      "screen_name" : "jojokejohn",
      "indices" : [ 3, 14 ],
      "id_str" : "90804267",
      "id" : 90804267
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jojokejohn\/status\/682253789085093888\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/H1JyhVSRGd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfaNKcUwAEXHiX.jpg",
      "id_str" : "682253788246228993",
      "id" : 682253788246228993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfaNKcUwAEXHiX.jpg",
      "sizes" : [ {
        "h" : 295,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/H1JyhVSRGd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682277366731771904",
  "text" : "RT @jojokejohn: HELLO https:\/\/t.co\/H1JyhVSRGd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jojokejohn\/status\/682253789085093888\/photo\/1",
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/H1JyhVSRGd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfaNKcUwAEXHiX.jpg",
        "id_str" : "682253788246228993",
        "id" : 682253788246228993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfaNKcUwAEXHiX.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/H1JyhVSRGd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682253789085093888",
    "text" : "HELLO https:\/\/t.co\/H1JyhVSRGd",
    "id" : 682253789085093888,
    "created_at" : "2015-12-30 17:35:53 +0000",
    "user" : {
      "name" : "john osalvo",
      "screen_name" : "jojokejohn",
      "protected" : false,
      "id_str" : "90804267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737499981007851520\/TMz8Cw39_normal.jpg",
      "id" : 90804267,
      "verified" : false
    }
  },
  "id" : 682277366731771904,
  "created_at" : "2015-12-30 19:09:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "accomplished",
      "indices" : [ 25, 38 ]
    }, {
      "text" : "brainfog",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "dislikephonecalls",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682243149234843648",
  "text" : "made 2 appts today! wow! #accomplished #brainfog #dislikephonecalls",
  "id" : 682243149234843648,
  "created_at" : "2015-12-30 16:53:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Farmer",
      "screen_name" : "emfrmr",
      "indices" : [ 3, 10 ],
      "id_str" : "5540682",
      "id" : 5540682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682229183062343680",
  "text" : "RT @emfrmr: I just dropped my phone on the floor and the narrator in the audiobook I was listening to immediately yelled, \"OW! What was tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682050651124305920",
    "text" : "I just dropped my phone on the floor and the narrator in the audiobook I was listening to immediately yelled, \"OW! What was that for?!\" \uD83D\uDE35",
    "id" : 682050651124305920,
    "created_at" : "2015-12-30 04:08:41 +0000",
    "user" : {
      "name" : "Emily Farmer",
      "screen_name" : "emfrmr",
      "protected" : false,
      "id_str" : "5540682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772206159772123138\/6-ntFGnW_normal.jpg",
      "id" : 5540682,
      "verified" : false
    }
  },
  "id" : 682229183062343680,
  "created_at" : "2015-12-30 15:58:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    }, {
      "name" : "Marcelo Gleiser",
      "screen_name" : "MGleiser",
      "indices" : [ 27, 36 ],
      "id_str" : "123664603",
      "id" : 123664603
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DailyDeal",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VHTqelrbXH",
      "expanded_url" : "http:\/\/adbl.co\/LimitsofScience",
      "display_url" : "adbl.co\/LimitsofScience"
    } ]
  },
  "geo" : { },
  "id_str" : "682228815494541312",
  "text" : "RT @audible_com: Physicist @MGleiser searches for answers to the most fundamental questions of existence #DailyDeal https:\/\/t.co\/VHTqelrbXH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcelo Gleiser",
        "screen_name" : "MGleiser",
        "indices" : [ 10, 19 ],
        "id_str" : "123664603",
        "id" : 123664603
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DailyDeal",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/VHTqelrbXH",
        "expanded_url" : "http:\/\/adbl.co\/LimitsofScience",
        "display_url" : "adbl.co\/LimitsofScience"
      } ]
    },
    "geo" : { },
    "id_str" : "682181843345608705",
    "text" : "Physicist @MGleiser searches for answers to the most fundamental questions of existence #DailyDeal https:\/\/t.co\/VHTqelrbXH",
    "id" : 682181843345608705,
    "created_at" : "2015-12-30 12:50:00 +0000",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 682228815494541312,
  "created_at" : "2015-12-30 15:56:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AbbVie",
      "screen_name" : "abbvie",
      "indices" : [ 3, 10 ],
      "id_str" : "531892451",
      "id" : 531892451
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/gUXdee3jjX",
      "expanded_url" : "http:\/\/ow.ly\/UAiKJ",
      "display_url" : "ow.ly\/UAiKJ"
    } ]
  },
  "geo" : { },
  "id_str" : "682226308173139968",
  "text" : "RT @abbvie: Know how to check your #thyroid? Discover how w\/ resources\nfrom Good Morning Hypothyroidism: https:\/\/t.co\/gUXdee3jjX https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abbvie\/status\/681565995840974848\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/uKL0UBP3OI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVoqWLUEAAx_ds.jpg",
        "id_str" : "681565995333324800",
        "id" : 681565995333324800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVoqWLUEAAx_ds.jpg",
        "sizes" : [ {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/uKL0UBP3OI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/abbvie\/status\/681565995840974848\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/uKL0UBP3OI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVoqWvUwAEooYk.jpg",
        "id_str" : "681565995484364801",
        "id" : 681565995484364801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVoqWvUwAEooYk.jpg",
        "sizes" : [ {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/uKL0UBP3OI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/abbvie\/status\/681565995840974848\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/uKL0UBP3OI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVoqSEUQAIOmhf.jpg",
        "id_str" : "681565994230235138",
        "id" : 681565994230235138,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVoqSEUQAIOmhf.jpg",
        "sizes" : [ {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/uKL0UBP3OI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/abbvie\/status\/681565995840974848\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/uKL0UBP3OI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVoqPQUoAQfjly.jpg",
        "id_str" : "681565993475284996",
        "id" : 681565993475284996,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVoqPQUoAQfjly.jpg",
        "sizes" : [ {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/uKL0UBP3OI"
      } ],
      "hashtags" : [ {
        "text" : "thyroid",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/gUXdee3jjX",
        "expanded_url" : "http:\/\/ow.ly\/UAiKJ",
        "display_url" : "ow.ly\/UAiKJ"
      } ]
    },
    "geo" : { },
    "id_str" : "681565995840974848",
    "text" : "Know how to check your #thyroid? Discover how w\/ resources\nfrom Good Morning Hypothyroidism: https:\/\/t.co\/gUXdee3jjX https:\/\/t.co\/uKL0UBP3OI",
    "id" : 681565995840974848,
    "created_at" : "2015-12-28 20:02:50 +0000",
    "user" : {
      "name" : "AbbVie",
      "screen_name" : "abbvie",
      "protected" : false,
      "id_str" : "531892451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471852251946835968\/Ss0a7v26_normal.jpeg",
      "id" : 531892451,
      "verified" : true
    }
  },
  "id" : 682226308173139968,
  "created_at" : "2015-12-30 15:46:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galaxy Diagnostics",
      "screen_name" : "Bartonella",
      "indices" : [ 3, 14 ],
      "id_str" : "146188728",
      "id" : 146188728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anxiety",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "panicattacks",
      "indices" : [ 49, 62 ]
    }, {
      "text" : "lymedisease",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/mpG5XHOrkT",
      "expanded_url" : "http:\/\/ow.ly\/WmeLj",
      "display_url" : "ow.ly\/WmeLj"
    } ]
  },
  "geo" : { },
  "id_str" : "682224052581314560",
  "text" : "RT @Bartonella: Man develops social #anxiety and #panicattacks before being treated for #lymedisease. https:\/\/t.co\/mpG5XHOrkT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "anxiety",
        "indices" : [ 20, 28 ]
      }, {
        "text" : "panicattacks",
        "indices" : [ 33, 46 ]
      }, {
        "text" : "lymedisease",
        "indices" : [ 72, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/mpG5XHOrkT",
        "expanded_url" : "http:\/\/ow.ly\/WmeLj",
        "display_url" : "ow.ly\/WmeLj"
      } ]
    },
    "geo" : { },
    "id_str" : "682146862367924224",
    "text" : "Man develops social #anxiety and #panicattacks before being treated for #lymedisease. https:\/\/t.co\/mpG5XHOrkT",
    "id" : 682146862367924224,
    "created_at" : "2015-12-30 10:31:00 +0000",
    "user" : {
      "name" : "Galaxy Diagnostics",
      "screen_name" : "Bartonella",
      "protected" : false,
      "id_str" : "146188728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2709308221\/e7b27fbcba3d88aa2a011edb5a959316_normal.jpeg",
      "id" : 146188728,
      "verified" : false
    }
  },
  "id" : 682224052581314560,
  "created_at" : "2015-12-30 15:37:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bridget Mellor",
      "screen_name" : "bidamellor",
      "indices" : [ 3, 14 ],
      "id_str" : "1101111733",
      "id" : 1101111733
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bidamellor\/status\/681874592756006912\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Q5w9iE8Lff",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXaBVErWMAAQuyQ.jpg",
      "id_str" : "681874592625995776",
      "id" : 681874592625995776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXaBVErWMAAQuyQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/Q5w9iE8Lff"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682036667394449408",
  "text" : "RT @bidamellor: Taken inside a house in York today \nHow weird is that https:\/\/t.co\/Q5w9iE8Lff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bidamellor\/status\/681874592756006912\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/Q5w9iE8Lff",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXaBVErWMAAQuyQ.jpg",
        "id_str" : "681874592625995776",
        "id" : 681874592625995776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXaBVErWMAAQuyQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/Q5w9iE8Lff"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681874592756006912",
    "text" : "Taken inside a house in York today \nHow weird is that https:\/\/t.co\/Q5w9iE8Lff",
    "id" : 681874592756006912,
    "created_at" : "2015-12-29 16:29:06 +0000",
    "user" : {
      "name" : "Bridget Mellor",
      "screen_name" : "bidamellor",
      "protected" : false,
      "id_str" : "1101111733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749737384284225536\/sVfK4S-6_normal.jpg",
      "id" : 1101111733,
      "verified" : false
    }
  },
  "id" : 682036667394449408,
  "created_at" : "2015-12-30 03:13:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/L445o8rZeU",
      "expanded_url" : "https:\/\/twitter.com\/RebeccaInDevon\/status\/681955514260025344",
      "display_url" : "twitter.com\/RebeccaInDevon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682001196970708992",
  "text" : "my cat does this to me..lol https:\/\/t.co\/L445o8rZeU",
  "id" : 682001196970708992,
  "created_at" : "2015-12-30 00:52:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681924838026514432",
  "text" : "RT @jorymicah: If anyone out there is interested in crushing patriarchy in the Christian Church, \"like\" my ministry page on FB: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/Myv4cMgxWI",
        "expanded_url" : "https:\/\/www.facebook.com\/Jory-Micah-Ministries-780402312021299\/?fref=ts",
        "display_url" : "facebook.com\/Jory-Micah-Min\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681924254800023552",
    "text" : "If anyone out there is interested in crushing patriarchy in the Christian Church, \"like\" my ministry page on FB: https:\/\/t.co\/Myv4cMgxWI",
    "id" : 681924254800023552,
    "created_at" : "2015-12-29 19:46:26 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 681924838026514432,
  "created_at" : "2015-12-29 19:48:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hypothyroid Mom",
      "screen_name" : "HypothyroidMom",
      "indices" : [ 3, 18 ],
      "id_str" : "842279588",
      "id" : 842279588
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HypothyroidMom\/status\/681872309158854656\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/28WYWu7Dvo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXZ_QFyUEAApIEy.jpg",
      "id_str" : "681872308001050624",
      "id" : 681872308001050624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXZ_QFyUEAApIEy.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2346,
        "resize" : "fit",
        "w" : 2346
      } ],
      "display_url" : "pic.twitter.com\/28WYWu7Dvo"
    } ],
    "hashtags" : [ {
      "text" : "hypothyroidism",
      "indices" : [ 20, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681875649666093056",
  "text" : "RT @HypothyroidMom: #hypothyroidism symptoms...how many do you have? https:\/\/t.co\/28WYWu7Dvo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HypothyroidMom\/status\/681872309158854656\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/28WYWu7Dvo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXZ_QFyUEAApIEy.jpg",
        "id_str" : "681872308001050624",
        "id" : 681872308001050624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXZ_QFyUEAApIEy.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2346,
          "resize" : "fit",
          "w" : 2346
        } ],
        "display_url" : "pic.twitter.com\/28WYWu7Dvo"
      } ],
      "hashtags" : [ {
        "text" : "hypothyroidism",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681872309158854656",
    "text" : "#hypothyroidism symptoms...how many do you have? https:\/\/t.co\/28WYWu7Dvo",
    "id" : 681872309158854656,
    "created_at" : "2015-12-29 16:20:01 +0000",
    "user" : {
      "name" : "Hypothyroid Mom",
      "screen_name" : "HypothyroidMom",
      "protected" : false,
      "id_str" : "842279588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541722388522479618\/RzaTcO_g_normal.jpeg",
      "id" : 842279588,
      "verified" : false
    }
  },
  "id" : 681875649666093056,
  "created_at" : "2015-12-29 16:33:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/p0Lh7J8mmL",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2965",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681853489962561537",
  "text" : "I can hear DD now.. \"Sticky fingers, Mom? .. Let it go.\" (from https:\/\/t.co\/p0Lh7J8mmL)",
  "id" : 681853489962561537,
  "created_at" : "2015-12-29 15:05:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/BZ3fuy2KSp",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2964",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681853302124892161",
  "text" : "getting blocked is like being slapped across the face when its someone you followed, liked, conversed with... (from https:\/\/t.co\/BZ3fuy2KSp)",
  "id" : 681853302124892161,
  "created_at" : "2015-12-29 15:04:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/514899626256633856\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/8Jig0AjaDm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByVKe11CIAAXAqF.jpg",
      "id_str" : "514899626109837312",
      "id" : 514899626109837312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByVKe11CIAAXAqF.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 427
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 427
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 427
      } ],
      "display_url" : "pic.twitter.com\/8Jig0AjaDm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681852562564366337",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/8Jig0AjaDm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/514899626256633856\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/8Jig0AjaDm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByVKe11CIAAXAqF.jpg",
        "id_str" : "514899626109837312",
        "id" : 514899626109837312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByVKe11CIAAXAqF.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        } ],
        "display_url" : "pic.twitter.com\/8Jig0AjaDm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681852422776578048",
    "text" : "https:\/\/t.co\/8Jig0AjaDm",
    "id" : 681852422776578048,
    "created_at" : "2015-12-29 15:01:00 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 681852562564366337,
  "created_at" : "2015-12-29 15:01:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Social Neuroscience",
      "screen_name" : "neuroinfluence",
      "indices" : [ 3, 18 ],
      "id_str" : "1285620068",
      "id" : 1285620068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialneuro",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/JijAg8JsYy",
      "expanded_url" : "http:\/\/ow.ly\/tuGes",
      "display_url" : "ow.ly\/tuGes"
    } ]
  },
  "geo" : { },
  "id_str" : "681845949216460800",
  "text" : "RT @neuroinfluence: Brains of Social Anxiety Sufferers Have Faulty \u2018Brakes,\u2019 Can\u2019t Control Fear - https:\/\/t.co\/JijAg8JsYy  #socialneuro",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialneuro",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/JijAg8JsYy",
        "expanded_url" : "http:\/\/ow.ly\/tuGes",
        "display_url" : "ow.ly\/tuGes"
      } ]
    },
    "geo" : { },
    "id_str" : "681829980775538688",
    "text" : "Brains of Social Anxiety Sufferers Have Faulty \u2018Brakes,\u2019 Can\u2019t Control Fear - https:\/\/t.co\/JijAg8JsYy  #socialneuro",
    "id" : 681829980775538688,
    "created_at" : "2015-12-29 13:31:49 +0000",
    "user" : {
      "name" : "Social Neuroscience",
      "screen_name" : "neuroinfluence",
      "protected" : false,
      "id_str" : "1285620068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3408907571\/87b214516df94f089c113a43dfc8b8a8_normal.jpeg",
      "id" : 1285620068,
      "verified" : false
    }
  },
  "id" : 681845949216460800,
  "created_at" : "2015-12-29 14:35:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dory",
      "screen_name" : "Dory",
      "indices" : [ 3, 8 ],
      "id_str" : "1187647735",
      "id" : 1187647735
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/talimariee\/status\/630072037671768064\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/UJi2WBTq28",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL53K-pUMAAGMOF.jpg",
      "id_str" : "630072028377133056",
      "id" : 630072028377133056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL53K-pUMAAGMOF.jpg",
      "sizes" : [ {
        "h" : 608,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UJi2WBTq28"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/talimariee\/status\/630072037671768064\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/UJi2WBTq28",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL53K-wUYAA6-a1.jpg",
      "id_str" : "630072028406505472",
      "id" : 630072028406505472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL53K-wUYAA6-a1.jpg",
      "sizes" : [ {
        "h" : 692,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UJi2WBTq28"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/talimariee\/status\/630072037671768064\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/UJi2WBTq28",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL53K-vVAAAyi4M.jpg",
      "id_str" : "630072028402352128",
      "id" : 630072028402352128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL53K-vVAAAyi4M.jpg",
      "sizes" : [ {
        "h" : 761,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/UJi2WBTq28"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681845339234648064",
  "text" : "RT @Dory: Say it louder for the people in the back https:\/\/t.co\/UJi2WBTq28",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/talimariee\/status\/630072037671768064\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/UJi2WBTq28",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL53K-pUMAAGMOF.jpg",
        "id_str" : "630072028377133056",
        "id" : 630072028377133056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL53K-pUMAAGMOF.jpg",
        "sizes" : [ {
          "h" : 608,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 323,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 570,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/UJi2WBTq28"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/talimariee\/status\/630072037671768064\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/UJi2WBTq28",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL53K-wUYAA6-a1.jpg",
        "id_str" : "630072028406505472",
        "id" : 630072028406505472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL53K-wUYAA6-a1.jpg",
        "sizes" : [ {
          "h" : 692,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 649,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UJi2WBTq28"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/talimariee\/status\/630072037671768064\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/UJi2WBTq28",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL53K-vVAAAyi4M.jpg",
        "id_str" : "630072028402352128",
        "id" : 630072028402352128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL53K-vVAAAyi4M.jpg",
        "sizes" : [ {
          "h" : 761,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 713,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 761,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/UJi2WBTq28"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681285738000809984",
    "text" : "Say it louder for the people in the back https:\/\/t.co\/UJi2WBTq28",
    "id" : 681285738000809984,
    "created_at" : "2015-12-28 01:29:12 +0000",
    "user" : {
      "name" : "Dory",
      "screen_name" : "Dory",
      "protected" : false,
      "id_str" : "1187647735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681579053338394624\/8UZsho0J_normal.jpg",
      "id" : 1187647735,
      "verified" : false
    }
  },
  "id" : 681845339234648064,
  "created_at" : "2015-12-29 14:32:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "indices" : [ 3, 18 ],
      "id_str" : "46822887",
      "id" : 46822887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/KOGB15SBx8",
      "expanded_url" : "https:\/\/twitter.com\/robdaemon\/status\/681615257702248449",
      "display_url" : "twitter.com\/robdaemon\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681631231713390593",
  "text" : "RT @AngryBlackLady: Be white. https:\/\/t.co\/KOGB15SBx8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 33 ],
        "url" : "https:\/\/t.co\/KOGB15SBx8",
        "expanded_url" : "https:\/\/twitter.com\/robdaemon\/status\/681615257702248449",
        "display_url" : "twitter.com\/robdaemon\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681629167398469633",
    "text" : "Be white. https:\/\/t.co\/KOGB15SBx8",
    "id" : 681629167398469633,
    "created_at" : "2015-12-29 00:13:52 +0000",
    "user" : {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "protected" : false,
      "id_str" : "46822887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790644001330171904\/E3uUevS__normal.jpg",
      "id" : 46822887,
      "verified" : true
    }
  },
  "id" : 681631231713390593,
  "created_at" : "2015-12-29 00:22:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/eW6Tpv5g41",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2958",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681625133455249408",
  "text" : "I wonder how many blocked me that I dont know about? weird thinking about it. (from https:\/\/t.co\/eW6Tpv5g41)",
  "id" : 681625133455249408,
  "created_at" : "2015-12-28 23:57:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 0, 8 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/rUXCrQWR7L",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2957",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681624614527602690",
  "in_reply_to_user_id" : 783214,
  "text" : "@twitter I want list of who has blocked me and who I unfollowed. also ezr list of followeds. (from https:\/\/t.co\/rUXCrQWR7L)",
  "id" : 681624614527602690,
  "created_at" : "2015-12-28 23:55:46 +0000",
  "in_reply_to_screen_name" : "twitter",
  "in_reply_to_user_id_str" : "783214",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/0Mtd6OGeHP",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2956",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681623659367145472",
  "text" : "blocked?? i dont get it. wth did I say that was so bad? gahhhh. (from https:\/\/t.co\/0Mtd6OGeHP)",
  "id" : 681623659367145472,
  "created_at" : "2015-12-28 23:51:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "indices" : [ 3, 12 ],
      "id_str" : "2375492109",
      "id" : 2375492109
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/681597749117194240\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/uTi0ZVfJb4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXWFipQWsAABEjB.jpg",
      "id_str" : "681597748852994048",
      "id" : 681597748852994048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXWFipQWsAABEjB.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/uTi0ZVfJb4"
    } ],
    "hashtags" : [ {
      "text" : "LakeDisctrict",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681598792932679680",
  "text" : "RT @cw_mills: Not a bad place for a swim, if your a swan :-))\n#LakeDisctrict https:\/\/t.co\/uTi0ZVfJb4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/681597749117194240\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/uTi0ZVfJb4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXWFipQWsAABEjB.jpg",
        "id_str" : "681597748852994048",
        "id" : 681597748852994048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXWFipQWsAABEjB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/uTi0ZVfJb4"
      } ],
      "hashtags" : [ {
        "text" : "LakeDisctrict",
        "indices" : [ 48, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681597749117194240",
    "text" : "Not a bad place for a swim, if your a swan :-))\n#LakeDisctrict https:\/\/t.co\/uTi0ZVfJb4",
    "id" : 681597749117194240,
    "created_at" : "2015-12-28 22:09:01 +0000",
    "user" : {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "protected" : false,
      "id_str" : "2375492109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648076476613533696\/1aq5VLpS_normal.jpg",
      "id" : 2375492109,
      "verified" : false
    }
  },
  "id" : 681598792932679680,
  "created_at" : "2015-12-28 22:13:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 3, 18 ],
      "id_str" : "18655567",
      "id" : 18655567
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stevesilberman\/status\/681564141912379392\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/aXb4K3WvmR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVm-aMUEAAAAwV.jpg",
      "id_str" : "681564140985389056",
      "id" : 681564140985389056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVm-aMUEAAAAwV.jpg",
      "sizes" : [ {
        "h" : 301,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aXb4K3WvmR"
    } ],
    "hashtags" : [ {
      "text" : "TamirRice",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681598393106444288",
  "text" : "RT @stevesilberman: What's wrong with America, in a single chilling tweet. #TamirRice https:\/\/t.co\/aXb4K3WvmR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stevesilberman\/status\/681564141912379392\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/aXb4K3WvmR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVm-aMUEAAAAwV.jpg",
        "id_str" : "681564140985389056",
        "id" : 681564140985389056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVm-aMUEAAAAwV.jpg",
        "sizes" : [ {
          "h" : 301,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 100,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aXb4K3WvmR"
      } ],
      "hashtags" : [ {
        "text" : "TamirRice",
        "indices" : [ 55, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681564141912379392",
    "text" : "What's wrong with America, in a single chilling tweet. #TamirRice https:\/\/t.co\/aXb4K3WvmR",
    "id" : 681564141912379392,
    "created_at" : "2015-12-28 19:55:28 +0000",
    "user" : {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "protected" : false,
      "id_str" : "18655567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759556547336818689\/atgxGu8g_normal.jpg",
      "id" : 18655567,
      "verified" : false
    }
  },
  "id" : 681598393106444288,
  "created_at" : "2015-12-28 22:11:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ari Melber",
      "screen_name" : "AriMelber",
      "indices" : [ 3, 13 ],
      "id_str" : "15441965",
      "id" : 15441965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681583641047265280",
  "text" : "RT @AriMelber: Prosecutor Matt Meyer now defending officers for not personally administering medical aid to Rice on scene after shooting hi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681563996097351680",
    "text" : "Prosecutor Matt Meyer now defending officers for not personally administering medical aid to Rice on scene after shooting him.",
    "id" : 681563996097351680,
    "created_at" : "2015-12-28 19:54:54 +0000",
    "user" : {
      "name" : "Ari Melber",
      "screen_name" : "AriMelber",
      "protected" : false,
      "id_str" : "15441965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789478953157296128\/rOfEK32y_normal.jpg",
      "id" : 15441965,
      "verified" : true
    }
  },
  "id" : 681583641047265280,
  "created_at" : "2015-12-28 21:12:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prairie Rose Clayton",
      "screen_name" : "hoover_dam",
      "indices" : [ 3, 14 ],
      "id_str" : "35197742",
      "id" : 35197742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/x6lXeZX9Md",
      "expanded_url" : "https:\/\/twitter.com\/KateAronoff\/status\/681554262439104512",
      "display_url" : "twitter.com\/KateAronoff\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681583218533994498",
  "text" : "RT @hoover_dam: are you fucking shitting me https:\/\/t.co\/x6lXeZX9Md",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/x6lXeZX9Md",
        "expanded_url" : "https:\/\/twitter.com\/KateAronoff\/status\/681554262439104512",
        "display_url" : "twitter.com\/KateAronoff\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681556339173273600",
    "text" : "are you fucking shitting me https:\/\/t.co\/x6lXeZX9Md",
    "id" : 681556339173273600,
    "created_at" : "2015-12-28 19:24:28 +0000",
    "user" : {
      "name" : "Prairie Rose Clayton",
      "screen_name" : "hoover_dam",
      "protected" : false,
      "id_str" : "35197742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1728680267\/rimeticon_normal.jpg",
      "id" : 35197742,
      "verified" : false
    }
  },
  "id" : 681583218533994498,
  "created_at" : "2015-12-28 21:11:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catholic Democrats",
      "screen_name" : "CatholicDems",
      "indices" : [ 3, 16 ],
      "id_str" : "21221064",
      "id" : 21221064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681570040827740160",
  "text" : "RT @CatholicDems: A 12 year old child was doing was 12 year old children do - playing in the park. And he ended up dead for it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681555028411310080",
    "text" : "A 12 year old child was doing was 12 year old children do - playing in the park. And he ended up dead for it.",
    "id" : 681555028411310080,
    "created_at" : "2015-12-28 19:19:16 +0000",
    "user" : {
      "name" : "Catholic Democrats",
      "screen_name" : "CatholicDems",
      "protected" : false,
      "id_str" : "21221064",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/79754812\/CathDems_logo3_normal.jpg",
      "id" : 21221064,
      "verified" : false
    }
  },
  "id" : 681570040827740160,
  "created_at" : "2015-12-28 20:18:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joseeee",
      "screen_name" : "BroseCuervo21",
      "indices" : [ 3, 17 ],
      "id_str" : "85269149",
      "id" : 85269149
    }, {
      "name" : "Sav\uD81A\uDCBE",
      "screen_name" : "savannah_cessna",
      "indices" : [ 19, 35 ],
      "id_str" : "1639089162",
      "id" : 1639089162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681541644223643648",
  "text" : "RT @BroseCuervo21: @savannah_cessna when did you choose to be straight?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sav\uD81A\uDCBE",
        "screen_name" : "savannah_cessna",
        "indices" : [ 0, 16 ],
        "id_str" : "1639089162",
        "id" : 1639089162
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "681369338096431104",
    "geo" : { },
    "id_str" : "681538773889331200",
    "in_reply_to_user_id" : 1639089162,
    "text" : "@savannah_cessna when did you choose to be straight?",
    "id" : 681538773889331200,
    "in_reply_to_status_id" : 681369338096431104,
    "created_at" : "2015-12-28 18:14:40 +0000",
    "in_reply_to_screen_name" : "savannah_cessna",
    "in_reply_to_user_id_str" : "1639089162",
    "user" : {
      "name" : "joseeee",
      "screen_name" : "BroseCuervo21",
      "protected" : false,
      "id_str" : "85269149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800800466212884480\/6l65R4i4_normal.jpg",
      "id" : 85269149,
      "verified" : false
    }
  },
  "id" : 681541644223643648,
  "created_at" : "2015-12-28 18:26:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sav\uD81A\uDCBE",
      "screen_name" : "savannah_cessna",
      "indices" : [ 20, 36 ],
      "id_str" : "1639089162",
      "id" : 1639089162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681541595309707264",
  "text" : "RT @TheDivineMrM89: @savannah_cessna Yeah, because gay people choose to be kicked out of their homes, have the shit beat out of them, and b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sav\uD81A\uDCBE",
        "screen_name" : "savannah_cessna",
        "indices" : [ 0, 16 ],
        "id_str" : "1639089162",
        "id" : 1639089162
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "byefelicia",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "681369338096431104",
    "geo" : { },
    "id_str" : "681540297789181952",
    "in_reply_to_user_id" : 1639089162,
    "text" : "@savannah_cessna Yeah, because gay people choose to be kicked out of their homes, have the shit beat out of them, and be abused. #byefelicia",
    "id" : 681540297789181952,
    "in_reply_to_status_id" : 681369338096431104,
    "created_at" : "2015-12-28 18:20:44 +0000",
    "in_reply_to_screen_name" : "savannah_cessna",
    "in_reply_to_user_id_str" : "1639089162",
    "user" : {
      "name" : "Preston Mackey Carlo",
      "screen_name" : "PMCarlo1989",
      "protected" : false,
      "id_str" : "126866719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700176812270317568\/SWGsDe2s_normal.jpg",
      "id" : 126866719,
      "verified" : false
    }
  },
  "id" : 681541595309707264,
  "created_at" : "2015-12-28 18:25:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Bak",
      "screen_name" : "intindra",
      "indices" : [ 3, 12 ],
      "id_str" : "3314454503",
      "id" : 3314454503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/an3wIgiS0G",
      "expanded_url" : "https:\/\/gum.co\/ueSW",
      "display_url" : "gum.co\/ueSW"
    } ]
  },
  "geo" : { },
  "id_str" : "681513306583117824",
  "text" : "RT @intindra: Hey all, my 2015 sketchbook is available for free download as thanks for all the support! https:\/\/t.co\/an3wIgiS0G https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/intindra\/status\/681222678792003584\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/4Oo4CBXx9f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXQwaqWWMAE1S95.jpg",
        "id_str" : "681222678242537473",
        "id" : 681222678242537473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXQwaqWWMAE1S95.jpg",
        "sizes" : [ {
          "h" : 563,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 904,
          "resize" : "fit",
          "w" : 1645
        } ],
        "display_url" : "pic.twitter.com\/4Oo4CBXx9f"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/an3wIgiS0G",
        "expanded_url" : "https:\/\/gum.co\/ueSW",
        "display_url" : "gum.co\/ueSW"
      } ]
    },
    "geo" : { },
    "id_str" : "681222678792003584",
    "text" : "Hey all, my 2015 sketchbook is available for free download as thanks for all the support! https:\/\/t.co\/an3wIgiS0G https:\/\/t.co\/4Oo4CBXx9f",
    "id" : 681222678792003584,
    "created_at" : "2015-12-27 21:18:37 +0000",
    "user" : {
      "name" : "Jane Bak",
      "screen_name" : "intindra",
      "protected" : false,
      "id_str" : "3314454503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781282434214137856\/kVKo6QnR_normal.jpg",
      "id" : 3314454503,
      "verified" : false
    }
  },
  "id" : 681513306583117824,
  "created_at" : "2015-12-28 16:33:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neurosis",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/x76SirwZrD",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2953",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681500812690862080",
  "text" : "i have some #neurosis about xmas. when its over, relief like a festering wound opening and draining. (from https:\/\/t.co\/x76SirwZrD)",
  "id" : 681500812690862080,
  "created_at" : "2015-12-28 15:43:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681496452061872128",
  "text" : "DD: Let it go, Mom. Me: I can't. DD: Is it glued to your fingers?",
  "id" : 681496452061872128,
  "created_at" : "2015-12-28 15:26:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "memoryissues",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/PueUVkNq7S",
      "expanded_url" : "https:\/\/m.reddit.com\/r\/AskWomen\/comments\/1gjnka\/when_looking_back_does_anyone_else_have\/",
      "display_url" : "m.reddit.com\/r\/AskWomen\/com\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681491225145421824",
  "text" : "DD found a thread about similar #memoryissues https:\/\/t.co\/PueUVkNq7S",
  "id" : 681491225145421824,
  "created_at" : "2015-12-28 15:05:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "indices" : [ 3, 11 ],
      "id_str" : "20479813",
      "id" : 20479813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/3R8exIlkw1",
      "expanded_url" : "http:\/\/www.msnbc.com\/rachel-maddow\/watch\/toxic-water-tragedy-points-directly-to-snyder-588635715518",
      "display_url" : "msnbc.com\/rachel-maddow\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681240265202515973",
  "text" : "RT @MMFlint: Now Confirmed: For the past 2yrs, all of the children in my hometown of Flint MI have been poisoned https:\/\/t.co\/3R8exIlkw1 #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArrestGovSnyder",
        "indices" : [ 124, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/3R8exIlkw1",
        "expanded_url" : "http:\/\/www.msnbc.com\/rachel-maddow\/watch\/toxic-water-tragedy-points-directly-to-snyder-588635715518",
        "display_url" : "msnbc.com\/rachel-maddow\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "678236101610356736",
    "text" : "Now Confirmed: For the past 2yrs, all of the children in my hometown of Flint MI have been poisoned https:\/\/t.co\/3R8exIlkw1 #ArrestGovSnyder",
    "id" : 678236101610356736,
    "created_at" : "2015-12-19 15:31:02 +0000",
    "user" : {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "protected" : false,
      "id_str" : "20479813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440557378027520000\/DTvD2bbr_normal.jpeg",
      "id" : 20479813,
      "verified" : true
    }
  },
  "id" : 681240265202515973,
  "created_at" : "2015-12-27 22:28:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophielinksu",
      "screen_name" : "sophielinksu",
      "indices" : [ 3, 16 ],
      "id_str" : "235862712",
      "id" : 235862712
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sophielinksu\/status\/676298538372870144\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/gQoLcXavSF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWKx7rcUYAAnH-w.jpg",
      "id_str" : "676298532890894336",
      "id" : 676298532890894336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWKx7rcUYAAnH-w.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gQoLcXavSF"
    } ],
    "hashtags" : [ {
      "text" : "SueMeSaudi",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "WomanVoteSaudiJoke",
      "indices" : [ 30, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681240072952360960",
  "text" : "RT @sophielinksu: #SueMeSaudi #WomanVoteSaudiJoke https:\/\/t.co\/gQoLcXavSF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sophielinksu\/status\/676298538372870144\/photo\/1",
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/gQoLcXavSF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWKx7rcUYAAnH-w.jpg",
        "id_str" : "676298532890894336",
        "id" : 676298532890894336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWKx7rcUYAAnH-w.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gQoLcXavSF"
      } ],
      "hashtags" : [ {
        "text" : "SueMeSaudi",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "WomanVoteSaudiJoke",
        "indices" : [ 12, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676298538372870144",
    "text" : "#SueMeSaudi #WomanVoteSaudiJoke https:\/\/t.co\/gQoLcXavSF",
    "id" : 676298538372870144,
    "created_at" : "2015-12-14 07:11:51 +0000",
    "user" : {
      "name" : "Sophielinksu",
      "screen_name" : "sophielinksu",
      "protected" : false,
      "id_str" : "235862712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678102985503670272\/9rXgcqvy_normal.jpg",
      "id" : 235862712,
      "verified" : false
    }
  },
  "id" : 681240072952360960,
  "created_at" : "2015-12-27 22:27:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681145064026992641",
  "text" : "RT @McGunnersite: Exist on your own terms. That is all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681072613658095616",
    "text" : "Exist on your own terms. That is all.",
    "id" : 681072613658095616,
    "created_at" : "2015-12-27 11:22:19 +0000",
    "user" : {
      "name" : "Navarro McGunner",
      "screen_name" : "TheMcGunner",
      "protected" : false,
      "id_str" : "1021951981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772936971777896448\/t7h4e29u_normal.jpg",
      "id" : 1021951981,
      "verified" : false
    }
  },
  "id" : 681145064026992641,
  "created_at" : "2015-12-27 16:10:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 3, 11 ],
      "id_str" : "61363491",
      "id" : 61363491
    }, {
      "name" : "9GAG",
      "screen_name" : "9GAG",
      "indices" : [ 74, 79 ],
      "id_str" : "16548023",
      "id" : 16548023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/MFK2W5lu3d",
      "expanded_url" : "http:\/\/9gag.com\/gag\/aeNLjWq?ref=t",
      "display_url" : "9gag.com\/gag\/aeNLjWq?re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681141144592498688",
  "text" : "RT @mbekezm: Quantum Physics for Babies Vol.1 https:\/\/t.co\/MFK2W5lu3d via @9GAG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "9GAG",
        "screen_name" : "9GAG",
        "indices" : [ 61, 66 ],
        "id_str" : "16548023",
        "id" : 16548023
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/MFK2W5lu3d",
        "expanded_url" : "http:\/\/9gag.com\/gag\/aeNLjWq?ref=t",
        "display_url" : "9gag.com\/gag\/aeNLjWq?re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681138966108749824",
    "text" : "Quantum Physics for Babies Vol.1 https:\/\/t.co\/MFK2W5lu3d via @9GAG",
    "id" : 681138966108749824,
    "created_at" : "2015-12-27 15:45:59 +0000",
    "user" : {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "protected" : false,
      "id_str" : "61363491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3337131859\/41d874380de15e72dd638ac8d9c8dd1a_normal.jpeg",
      "id" : 61363491,
      "verified" : false
    }
  },
  "id" : 681141144592498688,
  "created_at" : "2015-12-27 15:54:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/FMOF7laAFe",
      "expanded_url" : "https:\/\/twitter.com\/gemswinc\/status\/681137224277176320",
      "display_url" : "twitter.com\/gemswinc\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681140646992809985",
  "text" : "gorgeous! https:\/\/t.co\/FMOF7laAFe",
  "id" : 681140646992809985,
  "created_at" : "2015-12-27 15:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VZKjmIKdgu",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2948",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681122055073337346",
  "text" : "last night in bed listened to \"Gone Girl\" from library using new little speaker. DD above (bunk) didnt hear i\u2026 #win https:\/\/t.co\/VZKjmIKdgu",
  "id" : 681122055073337346,
  "created_at" : "2015-12-27 14:38:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "historicalfiction",
      "indices" : [ 43, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/FX0lIUN6qX",
      "expanded_url" : "https:\/\/www.reddit.com\/r\/audiobooks\/comments\/3ybrzu\/only_time_will_tell_by_jeffrey_archer_a_really\/",
      "display_url" : "reddit.com\/r\/audiobooks\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680915949898317829",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields free ebook, free whispersync #historicalfiction https:\/\/t.co\/FX0lIUN6qX",
  "id" : 680915949898317829,
  "created_at" : "2015-12-27 00:59:47 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/680903511412989952\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/mEXsXrBikm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXMOIslWsAA0pCy.jpg",
      "id_str" : "680903511232655360",
      "id" : 680903511232655360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXMOIslWsAA0pCy.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mEXsXrBikm"
    } ],
    "hashtags" : [ {
      "text" : "thinking",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680903511412989952",
  "text" : "Isn't he adorable? Needs a name. #thinking https:\/\/t.co\/mEXsXrBikm",
  "id" : 680903511412989952,
  "created_at" : "2015-12-27 00:10:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/R0Utd8obbo",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2946",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680822995003179008",
  "text" : "been taking sudafed (original, sign for it kind) all week and sinuses still icky. still feeling sick. blah. (from https:\/\/t.co\/R0Utd8obbo)",
  "id" : 680822995003179008,
  "created_at" : "2015-12-26 18:50:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/YQCjq4yHjg",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2945",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680822316050202624",
  "in_reply_to_user_id" : 20929609,
  "text" : "@silvercrone apparently I rub you the wrong way..fine. but did you have to be so mean, esp xmas day? jeepers. I sa\u2026 https:\/\/t.co\/YQCjq4yHjg",
  "id" : 680822316050202624,
  "created_at" : "2015-12-26 18:47:43 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680573325828042754",
  "text" : "@cabindweller93 hmm.. sorta makes sense. i'll have to let it marinate.",
  "id" : 680573325828042754,
  "created_at" : "2015-12-26 02:18:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feedly",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "audiobookreviews",
      "indices" : [ 63, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/NSTajHncVS",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=Ft3Ky4bpq_8",
      "display_url" : "youtube.com\/watch?v=Ft3Ky4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680572320574996480",
  "text" : "Anybody Want a free Audiobook? https:\/\/t.co\/NSTajHncVS #feedly #audiobookreviews",
  "id" : 680572320574996480,
  "created_at" : "2015-12-26 02:14:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680564964478828544",
  "text" : "I used to hate myself, then accepted myself. Heading into my 50's, now I feel like back at the beginning. WTF is wrong w me??",
  "id" : 680564964478828544,
  "created_at" : "2015-12-26 01:45:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680554352851955712",
  "text" : "How quickly life can turn on a dime. One minute its fine, the next its upside down.",
  "id" : 680554352851955712,
  "created_at" : "2015-12-26 01:02:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680451687874740225",
  "geo" : { },
  "id_str" : "680553968796348416",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone no one cares. And it's all going back.",
  "id" : 680553968796348416,
  "in_reply_to_status_id" : 680451687874740225,
  "created_at" : "2015-12-26 01:01:24 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680553561655259136",
  "text" : "@cabindweller93 your reply is not making sense to me?",
  "id" : 680553561655259136,
  "created_at" : "2015-12-26 00:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680444594857840640",
  "geo" : { },
  "id_str" : "680446850667778050",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves what an awesome shot! good work, my friend. : )",
  "id" : 680446850667778050,
  "in_reply_to_status_id" : 680444594857840640,
  "created_at" : "2015-12-25 17:55:45 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/680444185338589184\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/ElfRi1VCKx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXFsYZKW8AApk4z.jpg",
      "id_str" : "680444185036648448",
      "id" : 680444185036648448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXFsYZKW8AApk4z.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ElfRi1VCKx"
    } ],
    "hashtags" : [ {
      "text" : "rockandrollbaby",
      "indices" : [ 23, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680444185338589184",
  "text" : "My Christmas Haul 2015 #rockandrollbaby https:\/\/t.co\/ElfRi1VCKx",
  "id" : 680444185338589184,
  "created_at" : "2015-12-25 17:45:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J&M Acres Rescue",
      "screen_name" : "JMRescue",
      "indices" : [ 3, 12 ],
      "id_str" : "177459425",
      "id" : 177459425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "horses",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "adoptdontshop",
      "indices" : [ 86, 100 ]
    }, {
      "text" : "equestrianhour",
      "indices" : [ 101, 116 ]
    }, {
      "text" : "christmas",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/26dig2ExQA",
      "expanded_url" : "http:\/\/www.jmacresrescue.com",
      "display_url" : "jmacresrescue.com"
    } ]
  },
  "geo" : { },
  "id_str" : "680426702779084800",
  "text" : "RT @JMRescue: Still no interest in sweet Miss Dotti \u2764 https:\/\/t.co\/26dig2ExQA #horses #adoptdontshop #equestrianhour #christmas https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JMRescue\/status\/679761060853751808\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/3iRy2UaumR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW7_FSpUAAAaow2.jpg",
        "id_str" : "679761060149067776",
        "id" : 679761060149067776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW7_FSpUAAAaow2.jpg",
        "sizes" : [ {
          "h" : 451,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3iRy2UaumR"
      } ],
      "hashtags" : [ {
        "text" : "horses",
        "indices" : [ 64, 71 ]
      }, {
        "text" : "adoptdontshop",
        "indices" : [ 72, 86 ]
      }, {
        "text" : "equestrianhour",
        "indices" : [ 87, 102 ]
      }, {
        "text" : "christmas",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/26dig2ExQA",
        "expanded_url" : "http:\/\/www.jmacresrescue.com",
        "display_url" : "jmacresrescue.com"
      } ]
    },
    "geo" : { },
    "id_str" : "679761060853751808",
    "text" : "Still no interest in sweet Miss Dotti \u2764 https:\/\/t.co\/26dig2ExQA #horses #adoptdontshop #equestrianhour #christmas https:\/\/t.co\/3iRy2UaumR",
    "id" : 679761060853751808,
    "created_at" : "2015-12-23 20:30:40 +0000",
    "user" : {
      "name" : "J&M Acres Rescue",
      "screen_name" : "JMRescue",
      "protected" : false,
      "id_str" : "177459425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684131577425571840\/U1ksCYf8_normal.jpg",
      "id" : 177459425,
      "verified" : false
    }
  },
  "id" : 680426702779084800,
  "created_at" : "2015-12-25 16:35:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "680376187995164673",
  "geo" : { },
  "id_str" : "680426459282935808",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves is this your shot, dwayne? beautiful!!",
  "id" : 680426459282935808,
  "in_reply_to_status_id" : 680376187995164673,
  "created_at" : "2015-12-25 16:34:44 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680425454495514624",
  "text" : "RT @onealexharms: Good morning! Happy you-are-just-fine day! You are loveable, just as you are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680400595958763520",
    "text" : "Good morning! Happy you-are-just-fine day! You are loveable, just as you are.",
    "id" : 680400595958763520,
    "created_at" : "2015-12-25 14:51:57 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 680425454495514624,
  "created_at" : "2015-12-25 16:30:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "indices" : [ 3, 10 ],
      "id_str" : "110396781",
      "id" : 110396781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "25000tuques",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/1kyyB9H1Ji",
      "expanded_url" : "http:\/\/ajplus.co\/hus4",
      "display_url" : "ajplus.co\/hus4"
    } ]
  },
  "geo" : { },
  "id_str" : "680098690405679104",
  "text" : "RT @ajplus: Mass hat-knitting movement spreads across Canada to welcome resettled refugees. #25000tuques https:\/\/t.co\/1kyyB9H1Ji",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "25000tuques",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/1kyyB9H1Ji",
        "expanded_url" : "http:\/\/ajplus.co\/hus4",
        "display_url" : "ajplus.co\/hus4"
      } ]
    },
    "geo" : { },
    "id_str" : "680042520416391168",
    "text" : "Mass hat-knitting movement spreads across Canada to welcome resettled refugees. #25000tuques https:\/\/t.co\/1kyyB9H1Ji",
    "id" : 680042520416391168,
    "created_at" : "2015-12-24 15:09:06 +0000",
    "user" : {
      "name" : "AJ+",
      "screen_name" : "ajplus",
      "protected" : false,
      "id_str" : "110396781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510269137071783936\/AOB0NWwG_normal.png",
      "id" : 110396781,
      "verified" : true
    }
  },
  "id" : 680098690405679104,
  "created_at" : "2015-12-24 18:52:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nova Scotia Shepherd",
      "screen_name" : "ns_sheep",
      "indices" : [ 3, 12 ],
      "id_str" : "2932750929",
      "id" : 2932750929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ns_sheep\/status\/680036360510554112\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/PBG2dXIa49",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW_5d3yUMAAW5IN.jpg",
      "id_str" : "680036360342745088",
      "id" : 680036360342745088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW_5d3yUMAAW5IN.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1728,
        "resize" : "fit",
        "w" : 3072
      } ],
      "display_url" : "pic.twitter.com\/PBG2dXIa49"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680097973380988928",
  "text" : "RT @ns_sheep: Second cut makes the softest bed. https:\/\/t.co\/PBG2dXIa49",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ns_sheep\/status\/680036360510554112\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/PBG2dXIa49",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW_5d3yUMAAW5IN.jpg",
        "id_str" : "680036360342745088",
        "id" : 680036360342745088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW_5d3yUMAAW5IN.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1728,
          "resize" : "fit",
          "w" : 3072
        } ],
        "display_url" : "pic.twitter.com\/PBG2dXIa49"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680036360510554112",
    "text" : "Second cut makes the softest bed. https:\/\/t.co\/PBG2dXIa49",
    "id" : 680036360510554112,
    "created_at" : "2015-12-24 14:44:37 +0000",
    "user" : {
      "name" : "Nova Scotia Shepherd",
      "screen_name" : "ns_sheep",
      "protected" : false,
      "id_str" : "2932750929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546090724572557312\/ZWZKMbPu_normal.png",
      "id" : 2932750929,
      "verified" : false
    }
  },
  "id" : 680097973380988928,
  "created_at" : "2015-12-24 18:49:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukio Strachan",
      "screen_name" : "boldandworthy",
      "indices" : [ 3, 17 ],
      "id_str" : "387050961",
      "id" : 387050961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680096191502090240",
  "text" : "RT @boldandworthy: When we minimize a person's distress because it seems like no big deal, it can make the person who is hurting shut down.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "680092119248195585",
    "geo" : { },
    "id_str" : "680093529272532992",
    "in_reply_to_user_id" : 387050961,
    "text" : "When we minimize a person's distress because it seems like no big deal, it can make the person who is hurting shut down.",
    "id" : 680093529272532992,
    "in_reply_to_status_id" : 680092119248195585,
    "created_at" : "2015-12-24 18:31:47 +0000",
    "in_reply_to_screen_name" : "boldandworthy",
    "in_reply_to_user_id_str" : "387050961",
    "user" : {
      "name" : "Yukio Strachan",
      "screen_name" : "boldandworthy",
      "protected" : false,
      "id_str" : "387050961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1578150952\/198527_5420177210_541112210_139543_8107_n_normal.jpg",
      "id" : 387050961,
      "verified" : false
    }
  },
  "id" : 680096191502090240,
  "created_at" : "2015-12-24 18:42:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "High Museum of Art",
      "screen_name" : "HighMuseumofArt",
      "indices" : [ 3, 19 ],
      "id_str" : "29471232",
      "id" : 29471232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Christmas",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680068613810839553",
  "text" : "RT @HighMuseumofArt: It may not be cold outside, but we're still channeling a white #Christmas \u00E0 la Mrs. W. A. Barbon's \"Winter Morning\" ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HighMuseumofArt\/status\/680047402225659904\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/VR3jE4Leln",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXADgkxWEAAw6YD.jpg",
        "id_str" : "680047401894285312",
        "id" : 680047401894285312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXADgkxWEAAw6YD.jpg",
        "sizes" : [ {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 739,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 739,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/VR3jE4Leln"
      } ],
      "hashtags" : [ {
        "text" : "Christmas",
        "indices" : [ 63, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680047402225659904",
    "text" : "It may not be cold outside, but we're still channeling a white #Christmas \u00E0 la Mrs. W. A. Barbon's \"Winter Morning\" https:\/\/t.co\/VR3jE4Leln",
    "id" : 680047402225659904,
    "created_at" : "2015-12-24 15:28:30 +0000",
    "user" : {
      "name" : "High Museum of Art",
      "screen_name" : "HighMuseumofArt",
      "protected" : false,
      "id_str" : "29471232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755817443633852417\/p_kyqytY_normal.jpg",
      "id" : 29471232,
      "verified" : true
    }
  },
  "id" : 680068613810839553,
  "created_at" : "2015-12-24 16:52:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "Wallace 'J' Nichols",
      "screen_name" : "wallacejnichols",
      "indices" : [ 18, 34 ],
      "id_str" : "15575625",
      "id" : 15575625
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/oceanshaman\/status\/680065898443476996\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/symUFgYeyC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXAUUovUEAAUmAS.jpg",
      "id_str" : "680065888498749440",
      "id" : 680065888498749440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXAUUovUEAAUmAS.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/symUFgYeyC"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/oceanshaman\/status\/680065898443476996\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/symUFgYeyC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXAUU6-UEAAZJ__.jpg",
      "id_str" : "680065893393502208",
      "id" : 680065893393502208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXAUU6-UEAAZJ__.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/symUFgYeyC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680066844485619713",
  "text" : "RT @oceanshaman: .@wallacejnichols  Check all the head perches! Bearded dragon on the loose! https:\/\/t.co\/symUFgYeyC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wallace 'J' Nichols",
        "screen_name" : "wallacejnichols",
        "indices" : [ 1, 17 ],
        "id_str" : "15575625",
        "id" : 15575625
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oceanshaman\/status\/680065898443476996\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/symUFgYeyC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXAUUovUEAAUmAS.jpg",
        "id_str" : "680065888498749440",
        "id" : 680065888498749440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXAUUovUEAAUmAS.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/symUFgYeyC"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/oceanshaman\/status\/680065898443476996\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/symUFgYeyC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXAUU6-UEAAZJ__.jpg",
        "id_str" : "680065893393502208",
        "id" : 680065893393502208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXAUU6-UEAAZJ__.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/symUFgYeyC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "679849485682360320",
    "geo" : { },
    "id_str" : "680065898443476996",
    "in_reply_to_user_id" : 15575625,
    "text" : ".@wallacejnichols  Check all the head perches! Bearded dragon on the loose! https:\/\/t.co\/symUFgYeyC",
    "id" : 680065898443476996,
    "in_reply_to_status_id" : 679849485682360320,
    "created_at" : "2015-12-24 16:41:59 +0000",
    "in_reply_to_screen_name" : "wallacejnichols",
    "in_reply_to_user_id_str" : "15575625",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 680066844485619713,
  "created_at" : "2015-12-24 16:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis In NH",
      "screen_name" : "AlexisinNH",
      "indices" : [ 3, 14 ],
      "id_str" : "926317914",
      "id" : 926317914
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AlexisinNH\/status\/679873705019871232\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1TIj2WSa32",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW9lh2sUAAAqp9X.jpg",
      "id_str" : "679873701047697408",
      "id" : 679873701047697408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW9lh2sUAAAqp9X.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/1TIj2WSa32"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680065957281312769",
  "text" : "RT @AlexisinNH: This is Madonna's son Rocco (on left) When did he become an adult &amp; when did I get so old? https:\/\/t.co\/1TIj2WSa32",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlexisinNH\/status\/679873705019871232\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/1TIj2WSa32",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW9lh2sUAAAqp9X.jpg",
        "id_str" : "679873701047697408",
        "id" : 679873701047697408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW9lh2sUAAAqp9X.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/1TIj2WSa32"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679873705019871232",
    "text" : "This is Madonna's son Rocco (on left) When did he become an adult &amp; when did I get so old? https:\/\/t.co\/1TIj2WSa32",
    "id" : 679873705019871232,
    "created_at" : "2015-12-24 03:58:17 +0000",
    "user" : {
      "name" : "Alexis In NH",
      "screen_name" : "AlexisinNH",
      "protected" : false,
      "id_str" : "926317914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000232832198\/3cff1b2bad29130401b0cb2726cfe6f8_normal.jpeg",
      "id" : 926317914,
      "verified" : false
    }
  },
  "id" : 680065957281312769,
  "created_at" : "2015-12-24 16:42:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nothingtowear",
      "indices" : [ 71, 85 ]
    }, {
      "text" : "cantdressmeup",
      "indices" : [ 86, 100 ]
    }, {
      "text" : "shortandfat",
      "indices" : [ 101, 113 ]
    }, {
      "text" : "idontevenmatch",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680065718302457856",
  "text" : "good thing my mom isnt here to see how I dress. she'd be so upset. : ( #nothingtowear #cantdressmeup #shortandfat #idontevenmatch",
  "id" : 680065718302457856,
  "created_at" : "2015-12-24 16:41:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wood works crando",
      "screen_name" : "crando0630",
      "indices" : [ 3, 14 ],
      "id_str" : "362750077",
      "id" : 362750077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680042526586306560",
  "text" : "RT @crando0630: Merry Christmas! We wish your Merry Christmas.:)\n\u30E1\u30EA\u30FC\u30AF\u30EA\u30B9\u30DE\u30B9(^^)\u4ECA\u5E74\u3082\u3082\u3046\u5C11\u3057\u3067\u7D42\u308F\u308A\u307E\u3059\u3002\u3084\u308A\u6B8B\u3057\u305F\u3053\u3068\u304C\u3042\u308B\u3088\u3046\u306A\u3001\u7121\u3044\u3088\u3046\u306A\u3002\u6696\u304B\u304F\u3066\u5E2B\u8D70\u306A\u6C17\u5206\u3058\u3083\u7121\u3044\u3067\u3059\u306D\u301C\u3002 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crando0630\/status\/679894793690845184\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/b0yqyhxHT2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW94tmgUkAAPe3k.jpg",
        "id_str" : "679894793581793280",
        "id" : 679894793581793280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW94tmgUkAAPe3k.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/b0yqyhxHT2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679894793690845184",
    "text" : "Merry Christmas! We wish your Merry Christmas.:)\n\u30E1\u30EA\u30FC\u30AF\u30EA\u30B9\u30DE\u30B9(^^)\u4ECA\u5E74\u3082\u3082\u3046\u5C11\u3057\u3067\u7D42\u308F\u308A\u307E\u3059\u3002\u3084\u308A\u6B8B\u3057\u305F\u3053\u3068\u304C\u3042\u308B\u3088\u3046\u306A\u3001\u7121\u3044\u3088\u3046\u306A\u3002\u6696\u304B\u304F\u3066\u5E2B\u8D70\u306A\u6C17\u5206\u3058\u3083\u7121\u3044\u3067\u3059\u306D\u301C\u3002 https:\/\/t.co\/b0yqyhxHT2",
    "id" : 679894793690845184,
    "created_at" : "2015-12-24 05:22:05 +0000",
    "user" : {
      "name" : "wood works crando",
      "screen_name" : "crando0630",
      "protected" : false,
      "id_str" : "362750077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1519067772\/007_normal.JPG",
      "id" : 362750077,
      "verified" : false
    }
  },
  "id" : 680042526586306560,
  "created_at" : "2015-12-24 15:09:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fayetteville PD PIO",
      "screen_name" : "PIOFPD",
      "indices" : [ 3, 10 ],
      "id_str" : "3538482437",
      "id" : 3538482437
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PIOFPD\/status\/679794057426661376\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/4HkU725ueE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW8dEAsWYAEqVB4.jpg",
      "id_str" : "679794023498932225",
      "id" : 679794023498932225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW8dEAsWYAEqVB4.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4HkU725ueE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680040410643824640",
  "text" : "RT @PIOFPD: Sgt. Ketchum passes out toys to children at the Wal-Mart on Skibo Rd. https:\/\/t.co\/4HkU725ueE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PIOFPD\/status\/679794057426661376\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/4HkU725ueE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW8dEAsWYAEqVB4.jpg",
        "id_str" : "679794023498932225",
        "id" : 679794023498932225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW8dEAsWYAEqVB4.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4HkU725ueE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679794057426661376",
    "text" : "Sgt. Ketchum passes out toys to children at the Wal-Mart on Skibo Rd. https:\/\/t.co\/4HkU725ueE",
    "id" : 679794057426661376,
    "created_at" : "2015-12-23 22:41:47 +0000",
    "user" : {
      "name" : "Fayetteville PD PIO",
      "screen_name" : "PIOFPD",
      "protected" : false,
      "id_str" : "3538482437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639816908540407809\/lp9gZD-r_normal.jpg",
      "id" : 3538482437,
      "verified" : false
    }
  },
  "id" : 680040410643824640,
  "created_at" : "2015-12-24 15:00:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emergency Kittens",
      "screen_name" : "EmrgencyKittens",
      "indices" : [ 3, 19 ],
      "id_str" : "1041346340",
      "id" : 1041346340
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/lUKr6nduV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKaZWMAAd64L.jpg",
      "id_str" : "679457682919665664",
      "id" : 679457682919665664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKaZWMAAd64L.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/lUKr6nduV4"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/lUKr6nduV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKZzUEAATrDe.jpg",
      "id_str" : "679457682760142848",
      "id" : 679457682760142848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKZzUEAATrDe.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/lUKr6nduV4"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/lUKr6nduV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKUIWwAA1l9M.jpg",
      "id_str" : "679457681237786624",
      "id" : 679457681237786624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKUIWwAA1l9M.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/lUKr6nduV4"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/lUKr6nduV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKcLUQAEO3_S.jpg",
      "id_str" : "679457683397689345",
      "id" : 679457683397689345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKcLUQAEO3_S.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/lUKr6nduV4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679871036645576704",
  "text" : "RT @EmrgencyKittens: trying to wrap presents around cats https:\/\/t.co\/lUKr6nduV4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/lUKr6nduV4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKaZWMAAd64L.jpg",
        "id_str" : "679457682919665664",
        "id" : 679457682919665664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKaZWMAAd64L.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/lUKr6nduV4"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/lUKr6nduV4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKZzUEAATrDe.jpg",
        "id_str" : "679457682760142848",
        "id" : 679457682760142848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKZzUEAATrDe.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/lUKr6nduV4"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/lUKr6nduV4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKUIWwAA1l9M.jpg",
        "id_str" : "679457681237786624",
        "id" : 679457681237786624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKUIWwAA1l9M.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/lUKr6nduV4"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/EmrgencyKittens\/status\/679457684018606080\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/lUKr6nduV4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3rKcLUQAEO3_S.jpg",
        "id_str" : "679457683397689345",
        "id" : 679457683397689345,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3rKcLUQAEO3_S.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/lUKr6nduV4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679457684018606080",
    "text" : "trying to wrap presents around cats https:\/\/t.co\/lUKr6nduV4",
    "id" : 679457684018606080,
    "created_at" : "2015-12-23 00:25:10 +0000",
    "user" : {
      "name" : "Emergency Kittens",
      "screen_name" : "EmrgencyKittens",
      "protected" : false,
      "id_str" : "1041346340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562466745340817408\/_nIu8KHX_normal.jpeg",
      "id" : 1041346340,
      "verified" : false
    }
  },
  "id" : 679871036645576704,
  "created_at" : "2015-12-24 03:47:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cute Emergency\uD83C\uDF84",
      "screen_name" : "CuteEmergency",
      "indices" : [ 3, 17 ],
      "id_str" : "568825492",
      "id" : 568825492
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CuteEmergency\/status\/679850291961946113\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/6i6bNnyXTm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW9QPQXWcAEgVds.jpg",
      "id_str" : "679850291777400833",
      "id" : 679850291777400833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW9QPQXWcAEgVds.jpg",
      "sizes" : [ {
        "h" : 619,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 528
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6i6bNnyXTm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679870516321202178",
  "text" : "RT @CuteEmergency: forest puppy https:\/\/t.co\/6i6bNnyXTm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CuteEmergency\/status\/679850291961946113\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/6i6bNnyXTm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW9QPQXWcAEgVds.jpg",
        "id_str" : "679850291777400833",
        "id" : 679850291777400833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW9QPQXWcAEgVds.jpg",
        "sizes" : [ {
          "h" : 619,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 528
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6i6bNnyXTm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679850291961946113",
    "text" : "forest puppy https:\/\/t.co\/6i6bNnyXTm",
    "id" : 679850291961946113,
    "created_at" : "2015-12-24 02:25:15 +0000",
    "user" : {
      "name" : "Cute Emergency\uD83C\uDF84",
      "screen_name" : "CuteEmergency",
      "protected" : false,
      "id_str" : "568825492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551428167760486404\/DMyfmQDA_normal.jpeg",
      "id" : 568825492,
      "verified" : true
    }
  },
  "id" : 679870516321202178,
  "created_at" : "2015-12-24 03:45:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679856784304148485",
  "text" : "RT @CoryBooker: Douglas, this is more important than most realize. Ever since I worked in legal clinics, I've been committed to this https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rPaOog4mVA",
        "expanded_url" : "https:\/\/twitter.com\/DGershuny\/status\/679853236577300480",
        "display_url" : "twitter.com\/DGershuny\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679854242765639681",
    "text" : "Douglas, this is more important than most realize. Ever since I worked in legal clinics, I've been committed to this https:\/\/t.co\/rPaOog4mVA",
    "id" : 679854242765639681,
    "created_at" : "2015-12-24 02:40:57 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 679856784304148485,
  "created_at" : "2015-12-24 02:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    }, {
      "name" : "Sylvia on Broadway",
      "screen_name" : "SylviaBroadway",
      "indices" : [ 88, 103 ],
      "id_str" : "2866314009",
      "id" : 2866314009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679855771966910464",
  "text" : "RT @FreeRangeKids: Do people save dogs -- or vice versa? Sweet and scientific findings. @SylviaBroadway @GoodDogFoundation https:\/\/t.co\/m55\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sylvia on Broadway",
        "screen_name" : "SylviaBroadway",
        "indices" : [ 69, 84 ],
        "id_str" : "2866314009",
        "id" : 2866314009
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/m55FzWLhzQ",
        "expanded_url" : "https:\/\/lnkd.in\/eUna9YH",
        "display_url" : "lnkd.in\/eUna9YH"
      } ]
    },
    "geo" : { },
    "id_str" : "679854983093841920",
    "text" : "Do people save dogs -- or vice versa? Sweet and scientific findings. @SylviaBroadway @GoodDogFoundation https:\/\/t.co\/m55FzWLhzQ",
    "id" : 679854983093841920,
    "created_at" : "2015-12-24 02:43:53 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 679855771966910464,
  "created_at" : "2015-12-24 02:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Dragash",
      "screen_name" : "jakedragash",
      "indices" : [ 3, 15 ],
      "id_str" : "2612177631",
      "id" : 2612177631
    }, {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 113, 126 ],
      "id_str" : "6091632",
      "id" : 6091632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/8lazME8gwO",
      "expanded_url" : "https:\/\/www.quantamagazine.org\/20151216-physicists-and-philosophers-debate-the-boundaries-of-science\/",
      "display_url" : "quantamagazine.org\/20151216-physi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679837658458243072",
  "text" : "RT @jakedragash: Sentences like these make me take a deep breath in sheer amazement. https:\/\/t.co\/8lazME8gwO via @mikemchargue https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Science Mike",
        "screen_name" : "mikemchargue",
        "indices" : [ 96, 109 ],
        "id_str" : "6091632",
        "id" : 6091632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jakedragash\/status\/679833536073994240\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/mY7GrKmf2c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW9A9w3WYAAIzu3.jpg",
        "id_str" : "679833498589487104",
        "id" : 679833498589487104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW9A9w3WYAAIzu3.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/mY7GrKmf2c"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/8lazME8gwO",
        "expanded_url" : "https:\/\/www.quantamagazine.org\/20151216-physicists-and-philosophers-debate-the-boundaries-of-science\/",
        "display_url" : "quantamagazine.org\/20151216-physi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679833536073994240",
    "text" : "Sentences like these make me take a deep breath in sheer amazement. https:\/\/t.co\/8lazME8gwO via @mikemchargue https:\/\/t.co\/mY7GrKmf2c",
    "id" : 679833536073994240,
    "created_at" : "2015-12-24 01:18:40 +0000",
    "user" : {
      "name" : "Jake Dragash",
      "screen_name" : "jakedragash",
      "protected" : false,
      "id_str" : "2612177631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683264897485017088\/kUgrVW16_normal.jpg",
      "id" : 2612177631,
      "verified" : false
    }
  },
  "id" : 679837658458243072,
  "created_at" : "2015-12-24 01:35:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bread Savage",
      "screen_name" : "papasuncle",
      "indices" : [ 3, 14 ],
      "id_str" : "2321744516",
      "id" : 2321744516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679829592568365056",
  "text" : "RT @papasuncle: I'm not anti-social, just pro-silence.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "444987707094487040",
    "text" : "I'm not anti-social, just pro-silence.",
    "id" : 444987707094487040,
    "created_at" : "2014-03-16 00:05:11 +0000",
    "user" : {
      "name" : "Bread Savage",
      "screen_name" : "papasuncle",
      "protected" : false,
      "id_str" : "2321744516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799282053028204544\/PgvHpr3B_normal.jpg",
      "id" : 2321744516,
      "verified" : false
    }
  },
  "id" : 679829592568365056,
  "created_at" : "2015-12-24 01:03:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/679819049954611200\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/5Rm8lgFcgW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW8z0ljWMAAu7Kw.png",
      "id_str" : "679819047282814976",
      "id" : 679819047282814976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW8z0ljWMAAu7Kw.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 474
      } ],
      "display_url" : "pic.twitter.com\/5Rm8lgFcgW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/eQUJ9cmbhy",
      "expanded_url" : "https:\/\/www.facebook.com\/LargeFamiliesOnPurpose\/posts\/999489426760825?_ts=1450916464",
      "display_url" : "facebook.com\/LargeFamiliesO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679819049954611200",
  "text" : "just punishment? God's wrath? I just can't fathom this. https:\/\/t.co\/eQUJ9cmbhy https:\/\/t.co\/5Rm8lgFcgW",
  "id" : 679819049954611200,
  "created_at" : "2015-12-24 00:21:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gash",
      "screen_name" : "MarkG76",
      "indices" : [ 3, 11 ],
      "id_str" : "83209197",
      "id" : 83209197
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarkG76\/status\/679760132138479616\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/sKc2czl35L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW7-PNbWMAAX2kI.jpg",
      "id_str" : "679760131035377664",
      "id" : 679760131035377664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW7-PNbWMAAX2kI.jpg",
      "sizes" : [ {
        "h" : 844,
        "resize" : "fit",
        "w" : 1250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 691,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/sKc2czl35L"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/MarkG76\/status\/679760132138479616\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/sKc2czl35L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW7-PEBWAAAXHWw.jpg",
      "id_str" : "679760128510394368",
      "id" : 679760128510394368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW7-PEBWAAAXHWw.jpg",
      "sizes" : [ {
        "h" : 299,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 622,
        "resize" : "fit",
        "w" : 1250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sKc2czl35L"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 44, 50 ]
    }, {
      "text" : "birding",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679807976715194368",
  "text" : "RT @MarkG76: Goldcrest taken few weeks ago. #birds #birding https:\/\/t.co\/sKc2czl35L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkG76\/status\/679760132138479616\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/sKc2czl35L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW7-PNbWMAAX2kI.jpg",
        "id_str" : "679760131035377664",
        "id" : 679760131035377664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW7-PNbWMAAX2kI.jpg",
        "sizes" : [ {
          "h" : 844,
          "resize" : "fit",
          "w" : 1250
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 691,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sKc2czl35L"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MarkG76\/status\/679760132138479616\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/sKc2czl35L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW7-PEBWAAAXHWw.jpg",
        "id_str" : "679760128510394368",
        "id" : 679760128510394368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW7-PEBWAAAXHWw.jpg",
        "sizes" : [ {
          "h" : 299,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 622,
          "resize" : "fit",
          "w" : 1250
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sKc2czl35L"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 31, 37 ]
      }, {
        "text" : "birding",
        "indices" : [ 38, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679760132138479616",
    "text" : "Goldcrest taken few weeks ago. #birds #birding https:\/\/t.co\/sKc2czl35L",
    "id" : 679760132138479616,
    "created_at" : "2015-12-23 20:26:59 +0000",
    "user" : {
      "name" : "Mark Gash",
      "screen_name" : "MarkG76",
      "protected" : false,
      "id_str" : "83209197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519936095123820545\/XEB3BwND_normal.png",
      "id" : 83209197,
      "verified" : false
    }
  },
  "id" : 679807976715194368,
  "created_at" : "2015-12-23 23:37:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter",
      "screen_name" : "woodcarver_t",
      "indices" : [ 3, 16 ],
      "id_str" : "831927198",
      "id" : 831927198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/OUz5KHvQXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqU6WUAA7yex.jpg",
      "id_str" : "679431842924220416",
      "id" : 679431842924220416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqU6WUAA7yex.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/OUz5KHvQXh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/OUz5KHvQXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqVGWwAAG5qT.jpg",
      "id_str" : "679431842974580736",
      "id" : 679431842974580736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqVGWwAAG5qT.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OUz5KHvQXh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/OUz5KHvQXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqVNWoAAd-ou.jpg",
      "id_str" : "679431843003932672",
      "id" : 679431843003932672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqVNWoAAd-ou.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 586,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OUz5KHvQXh"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/OUz5KHvQXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqiDW4AA8aj5.jpg",
      "id_str" : "679431846451666944",
      "id" : 679431846451666944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqiDW4AA8aj5.jpg",
      "sizes" : [ {
        "h" : 295,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 888,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OUz5KHvQXh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679802907219378176",
  "text" : "RT @woodcarver_t: Definitely last one for 2015 \uD83D\uDE0A https:\/\/t.co\/OUz5KHvQXh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/OUz5KHvQXh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqU6WUAA7yex.jpg",
        "id_str" : "679431842924220416",
        "id" : 679431842924220416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqU6WUAA7yex.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        } ],
        "display_url" : "pic.twitter.com\/OUz5KHvQXh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/OUz5KHvQXh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqVGWwAAG5qT.jpg",
        "id_str" : "679431842974580736",
        "id" : 679431842974580736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqVGWwAAG5qT.jpg",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OUz5KHvQXh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/OUz5KHvQXh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqVNWoAAd-ou.jpg",
        "id_str" : "679431843003932672",
        "id" : 679431843003932672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqVNWoAAd-ou.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OUz5KHvQXh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/woodcarver_t\/status\/679431861463052289\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/OUz5KHvQXh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3TqiDW4AA8aj5.jpg",
        "id_str" : "679431846451666944",
        "id" : 679431846451666944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3TqiDW4AA8aj5.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 888,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 888,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OUz5KHvQXh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679431861463052289",
    "text" : "Definitely last one for 2015 \uD83D\uDE0A https:\/\/t.co\/OUz5KHvQXh",
    "id" : 679431861463052289,
    "created_at" : "2015-12-22 22:42:33 +0000",
    "user" : {
      "name" : "Peter",
      "screen_name" : "woodcarver_t",
      "protected" : false,
      "id_str" : "831927198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796487744113508352\/1ui6JNzH_normal.jpg",
      "id" : 831927198,
      "verified" : false
    }
  },
  "id" : 679802907219378176,
  "created_at" : "2015-12-23 23:16:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriele Corno",
      "screen_name" : "Gabriele_Corno",
      "indices" : [ 3, 18 ],
      "id_str" : "374752807",
      "id" : 374752807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gabriele_Corno\/status\/678585633145622528\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/2pJ5dgIsvS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWrSCZwUsAEhJES.jpg",
      "id_str" : "678585632587821057",
      "id" : 678585632587821057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWrSCZwUsAEhJES.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/2pJ5dgIsvS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679796736081170436",
  "text" : "RT @Gabriele_Corno: December light.......bu Igor Vassiliev https:\/\/t.co\/2pJ5dgIsvS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gabriele_Corno\/status\/678585633145622528\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/2pJ5dgIsvS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWrSCZwUsAEhJES.jpg",
        "id_str" : "678585632587821057",
        "id" : 678585632587821057,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWrSCZwUsAEhJES.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 792
        } ],
        "display_url" : "pic.twitter.com\/2pJ5dgIsvS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678585633145622528",
    "text" : "December light.......bu Igor Vassiliev https:\/\/t.co\/2pJ5dgIsvS",
    "id" : 678585633145622528,
    "created_at" : "2015-12-20 14:39:57 +0000",
    "user" : {
      "name" : "Gabriele Corno",
      "screen_name" : "Gabriele_Corno",
      "protected" : false,
      "id_str" : "374752807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557958031606939649\/jExOWkdO_normal.jpeg",
      "id" : 374752807,
      "verified" : false
    }
  },
  "id" : 679796736081170436,
  "created_at" : "2015-12-23 22:52:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679777877592768518",
  "geo" : { },
  "id_str" : "679792521464147968",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe im so hoping its a mix up of some sort and that is NOT your gift. ((hugs))",
  "id" : 679792521464147968,
  "in_reply_to_status_id" : 679777877592768518,
  "created_at" : "2015-12-23 22:35:41 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Patrick Stewart",
      "screen_name" : "SirPatStew",
      "indices" : [ 97, 108 ],
      "id_str" : "602317143",
      "id" : 602317143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "AChristmasCarol",
      "indices" : [ 72, 88 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679785714020659200",
  "text" : "RT @SimonAudio: Follow us &amp; RT this to #win 5\/5 audiobook copies of #AChristmasCarol read by @SirPatStew! #Sweeps rules: https:\/\/t.co\/lTpVU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patrick Stewart",
        "screen_name" : "SirPatStew",
        "indices" : [ 81, 92 ],
        "id_str" : "602317143",
        "id" : 602317143
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "AChristmasCarol",
        "indices" : [ 56, 72 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/lTpVUU3so5",
        "expanded_url" : "http:\/\/bit.ly\/18QxXcs",
        "display_url" : "bit.ly\/18QxXcs"
      } ]
    },
    "geo" : { },
    "id_str" : "679784914150125568",
    "text" : "Follow us &amp; RT this to #win 5\/5 audiobook copies of #AChristmasCarol read by @SirPatStew! #Sweeps rules: https:\/\/t.co\/lTpVUU3so5",
    "id" : 679784914150125568,
    "created_at" : "2015-12-23 22:05:27 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 679785714020659200,
  "created_at" : "2015-12-23 22:08:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Patrick Stewart",
      "screen_name" : "SirPatStew",
      "indices" : [ 108, 119 ],
      "id_str" : "602317143",
      "id" : 602317143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "Dickens",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "AChristmasCarol",
      "indices" : [ 82, 98 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679762363319463936",
  "text" : "RT @SimonAudio: Follow us &amp; RT this to #win 4\/5 audiobook copies of #Dickens' #AChristmasCarol, read by @SirPatStew! #Sweeps rules: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patrick Stewart",
        "screen_name" : "SirPatStew",
        "indices" : [ 92, 103 ],
        "id_str" : "602317143",
        "id" : 602317143
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "Dickens",
        "indices" : [ 56, 64 ]
      }, {
        "text" : "AChristmasCarol",
        "indices" : [ 66, 82 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/lTpVUU3so5",
        "expanded_url" : "http:\/\/bit.ly\/18QxXcs",
        "display_url" : "bit.ly\/18QxXcs"
      } ]
    },
    "geo" : { },
    "id_str" : "679761264348934144",
    "text" : "Follow us &amp; RT this to #win 4\/5 audiobook copies of #Dickens' #AChristmasCarol, read by @SirPatStew! #Sweeps rules: https:\/\/t.co\/lTpVUU3so5",
    "id" : 679761264348934144,
    "created_at" : "2015-12-23 20:31:29 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 679762363319463936,
  "created_at" : "2015-12-23 20:35:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "679682046457966592",
  "geo" : { },
  "id_str" : "679737195201228804",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley I like those dishes. Looks easy for cat to eat out of.",
  "id" : 679737195201228804,
  "in_reply_to_status_id" : 679682046457966592,
  "created_at" : "2015-12-23 18:55:50 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Patrick Stewart",
      "screen_name" : "SirPatStew",
      "indices" : [ 103, 114 ],
      "id_str" : "602317143",
      "id" : 602317143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "AChristmasCarol",
      "indices" : [ 72, 88 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679735721427611648",
  "text" : "RT @SimonAudio: Follow us &amp; RT this to #win 3\/5 audiobook copies of #AChristmasCarol, performed by @SirPatStew! #Sweeps rules: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patrick Stewart",
        "screen_name" : "SirPatStew",
        "indices" : [ 87, 98 ],
        "id_str" : "602317143",
        "id" : 602317143
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "AChristmasCarol",
        "indices" : [ 56, 72 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/lTpVUU3so5",
        "expanded_url" : "http:\/\/bit.ly\/18QxXcs",
        "display_url" : "bit.ly\/18QxXcs"
      } ]
    },
    "geo" : { },
    "id_str" : "679734665318658048",
    "text" : "Follow us &amp; RT this to #win 3\/5 audiobook copies of #AChristmasCarol, performed by @SirPatStew! #Sweeps rules: https:\/\/t.co\/lTpVUU3so5",
    "id" : 679734665318658048,
    "created_at" : "2015-12-23 18:45:47 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 679735721427611648,
  "created_at" : "2015-12-23 18:49:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Patrick Stewart",
      "screen_name" : "SirPatStew",
      "indices" : [ 108, 119 ],
      "id_str" : "602317143",
      "id" : 602317143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 43, 47 ]
    }, {
      "text" : "Dickens",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "AChristmasCarol",
      "indices" : [ 82, 98 ]
    }, {
      "text" : "Sweeps",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679724248374575104",
  "text" : "RT @SimonAudio: Follow us &amp; RT this to #win 2\/5 audiobook copies of #Dickens' #AChristmasCarol, read by @SirPatStew! #Sweeps rules: https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patrick Stewart",
        "screen_name" : "SirPatStew",
        "indices" : [ 92, 103 ],
        "id_str" : "602317143",
        "id" : 602317143
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "Dickens",
        "indices" : [ 56, 64 ]
      }, {
        "text" : "AChristmasCarol",
        "indices" : [ 66, 82 ]
      }, {
        "text" : "Sweeps",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/lTpVUU3so5",
        "expanded_url" : "http:\/\/bit.ly\/18QxXcs",
        "display_url" : "bit.ly\/18QxXcs"
      } ]
    },
    "geo" : { },
    "id_str" : "679716077107044352",
    "text" : "Follow us &amp; RT this to #win 2\/5 audiobook copies of #Dickens' #AChristmasCarol, read by @SirPatStew! #Sweeps rules: https:\/\/t.co\/lTpVUU3so5",
    "id" : 679716077107044352,
    "created_at" : "2015-12-23 17:31:55 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 679724248374575104,
  "created_at" : "2015-12-23 18:04:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Torres, MD",
      "screen_name" : "LeahNTorres",
      "indices" : [ 3, 15 ],
      "id_str" : "195409453",
      "id" : 195409453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679462725316153344",
  "text" : "RT @LeahNTorres: I perform abortions.\n\nI am not evil.\n\nI keep my patients safe.\n\nI respect my patients.\n\nI am a person.\n\nI do not deserve t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671546788470382593",
    "text" : "I perform abortions.\n\nI am not evil.\n\nI keep my patients safe.\n\nI respect my patients.\n\nI am a person.\n\nI do not deserve to be murdered.",
    "id" : 671546788470382593,
    "created_at" : "2015-12-01 04:30:05 +0000",
    "user" : {
      "name" : "Leah Torres, MD",
      "screen_name" : "LeahNTorres",
      "protected" : false,
      "id_str" : "195409453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796512584828493824\/Mgh2Z8HN_normal.jpg",
      "id" : 195409453,
      "verified" : true
    }
  },
  "id" : 679462725316153344,
  "created_at" : "2015-12-23 00:45:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Joyce",
      "screen_name" : "brianjoyce_",
      "indices" : [ 3, 15 ],
      "id_str" : "1488078121",
      "id" : 1488078121
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/brianjoyce25\/status\/657291774596161538\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/3qHKTfRh7t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8rUYaXIAEK1Lg.jpg",
      "id_str" : "657291699769778177",
      "id" : 657291699769778177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8rUYaXIAEK1Lg.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3qHKTfRh7t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679438968153329664",
  "text" : "RT @brianjoyce_: Sharing secrets \uD83D\uDE1D https:\/\/t.co\/3qHKTfRh7t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/brianjoyce25\/status\/657291774596161538\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/3qHKTfRh7t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8rUYaXIAEK1Lg.jpg",
        "id_str" : "657291699769778177",
        "id" : 657291699769778177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8rUYaXIAEK1Lg.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3qHKTfRh7t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657291774596161538",
    "text" : "Sharing secrets \uD83D\uDE1D https:\/\/t.co\/3qHKTfRh7t",
    "id" : 657291774596161538,
    "created_at" : "2015-10-22 20:25:45 +0000",
    "user" : {
      "name" : "Brian Joyce",
      "screen_name" : "brianjoyce_",
      "protected" : false,
      "id_str" : "1488078121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717070584153300992\/7xqM1d9C_normal.jpg",
      "id" : 1488078121,
      "verified" : false
    }
  },
  "id" : 679438968153329664,
  "created_at" : "2015-12-22 23:10:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "FarmerJPH",
      "indices" : [ 3, 13 ],
      "id_str" : "371881653",
      "id" : 371881653
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FarmerJPH\/status\/665884964169363456\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kFARWVRfwv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT2yunqWoAAbB6O.jpg",
      "id_str" : "665884833911054336",
      "id" : 665884833911054336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT2yunqWoAAbB6O.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kFARWVRfwv"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/FarmerJPH\/status\/665884964169363456\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/kFARWVRfwv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT2yxpRW4AA_4ZT.jpg",
      "id_str" : "665884885882691584",
      "id" : 665884885882691584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT2yxpRW4AA_4ZT.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kFARWVRfwv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679438653635092480",
  "text" : "RT @FarmerJPH: Cuddled under the fence https:\/\/t.co\/kFARWVRfwv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmerJPH\/status\/665884964169363456\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/kFARWVRfwv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT2yunqWoAAbB6O.jpg",
        "id_str" : "665884833911054336",
        "id" : 665884833911054336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT2yunqWoAAbB6O.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kFARWVRfwv"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FarmerJPH\/status\/665884964169363456\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/kFARWVRfwv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT2yxpRW4AA_4ZT.jpg",
        "id_str" : "665884885882691584",
        "id" : 665884885882691584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT2yxpRW4AA_4ZT.jpg",
        "sizes" : [ {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1152
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1820,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kFARWVRfwv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665884964169363456",
    "text" : "Cuddled under the fence https:\/\/t.co\/kFARWVRfwv",
    "id" : 665884964169363456,
    "created_at" : "2015-11-15 13:32:01 +0000",
    "user" : {
      "name" : "John",
      "screen_name" : "FarmerJPH",
      "protected" : false,
      "id_str" : "371881653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732597881190813696\/X-dAkaN2_normal.jpg",
      "id" : 371881653,
      "verified" : false
    }
  },
  "id" : 679438653635092480,
  "created_at" : "2015-12-22 23:09:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle Most Wanted",
      "screen_name" : "kindlemw",
      "indices" : [ 3, 12 ],
      "id_str" : "2592125335",
      "id" : 2592125335
    }, {
      "name" : "Barry Eisler",
      "screen_name" : "barryeisler",
      "indices" : [ 87, 99 ],
      "id_str" : "26177586",
      "id" : 26177586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/sIjyy6cCom",
      "expanded_url" : "http:\/\/amzn.to\/1UYIzLn",
      "display_url" : "amzn.to\/1UYIzLn"
    } ]
  },
  "geo" : { },
  "id_str" : "679388644025769985",
  "text" : "RT @kindlemw: Sign up for Kindle Whispercast for a chance to win The God\u2019s Eye View by @barryeisler! https:\/\/t.co\/sIjyy6cCom https:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barry Eisler",
        "screen_name" : "barryeisler",
        "indices" : [ 73, 85 ],
        "id_str" : "26177586",
        "id" : 26177586
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kindlemw\/status\/679119222060900352\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/1hjNrzncsa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyN_-iUAAENtdr.png",
        "id_str" : "679073774084292609",
        "id" : 679073774084292609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyN_-iUAAENtdr.png",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1hjNrzncsa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/sIjyy6cCom",
        "expanded_url" : "http:\/\/amzn.to\/1UYIzLn",
        "display_url" : "amzn.to\/1UYIzLn"
      } ]
    },
    "geo" : { },
    "id_str" : "679119222060900352",
    "text" : "Sign up for Kindle Whispercast for a chance to win The God\u2019s Eye View by @barryeisler! https:\/\/t.co\/sIjyy6cCom https:\/\/t.co\/1hjNrzncsa",
    "id" : 679119222060900352,
    "created_at" : "2015-12-22 02:00:14 +0000",
    "user" : {
      "name" : "Kindle Most Wanted",
      "screen_name" : "kindlemw",
      "protected" : false,
      "id_str" : "2592125335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486191745269379072\/Lz3OaOjo_normal.png",
      "id" : 2592125335,
      "verified" : false
    }
  },
  "id" : 679388644025769985,
  "created_at" : "2015-12-22 19:50:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird and Moon",
      "screen_name" : "RosemaryMosco",
      "indices" : [ 3, 17 ],
      "id_str" : "1020952663",
      "id" : 1020952663
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RosemaryMosco\/status\/679334760225767424\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/nsLhERScS6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW17XT4VEAAOfyl.jpg",
      "id_str" : "679334759206555648",
      "id" : 679334759206555648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW17XT4VEAAOfyl.jpg",
      "sizes" : [ {
        "h" : 747,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 872,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 872,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/nsLhERScS6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/VW626Hxh4F",
      "expanded_url" : "http:\/\/birdandmoon.com\/comic\/christmas-field-guide\/",
      "display_url" : "birdandmoon.com\/comic\/christma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679381685943799808",
  "text" : "RT @RosemaryMosco: Here's one more older Christmas comic repost: a Christmas Field Guide. https:\/\/t.co\/VW626Hxh4F https:\/\/t.co\/nsLhERScS6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RosemaryMosco\/status\/679334760225767424\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/nsLhERScS6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW17XT4VEAAOfyl.jpg",
        "id_str" : "679334759206555648",
        "id" : 679334759206555648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW17XT4VEAAOfyl.jpg",
        "sizes" : [ {
          "h" : 747,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 872,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 872,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/nsLhERScS6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/VW626Hxh4F",
        "expanded_url" : "http:\/\/birdandmoon.com\/comic\/christmas-field-guide\/",
        "display_url" : "birdandmoon.com\/comic\/christma\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679334760225767424",
    "text" : "Here's one more older Christmas comic repost: a Christmas Field Guide. https:\/\/t.co\/VW626Hxh4F https:\/\/t.co\/nsLhERScS6",
    "id" : 679334760225767424,
    "created_at" : "2015-12-22 16:16:42 +0000",
    "user" : {
      "name" : "Bird and Moon",
      "screen_name" : "RosemaryMosco",
      "protected" : false,
      "id_str" : "1020952663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800519480401154050\/AkUITeM-_normal.jpg",
      "id" : 1020952663,
      "verified" : false
    }
  },
  "id" : 679381685943799808,
  "created_at" : "2015-12-22 19:23:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Moore",
      "screen_name" : "TheAuthorGuy",
      "indices" : [ 3, 16 ],
      "id_str" : "25893353",
      "id" : 25893353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679368326771056640",
  "text" : "RT @TheAuthorGuy: Update: Sky Tower at Sea World still stuck. \n\"Oh, you guys are in a little tank and can't get out? That's so sad. LOLZ.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679033058083737600",
    "text" : "Update: Sky Tower at Sea World still stuck. \n\"Oh, you guys are in a little tank and can't get out? That's so sad. LOLZ.\" -Shamu",
    "id" : 679033058083737600,
    "created_at" : "2015-12-21 20:17:51 +0000",
    "user" : {
      "name" : "Christopher Moore",
      "screen_name" : "TheAuthorGuy",
      "protected" : false,
      "id_str" : "25893353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360234735394816\/wlzT7vmJ_normal.jpg",
      "id" : 25893353,
      "verified" : true
    }
  },
  "id" : 679368326771056640,
  "created_at" : "2015-12-22 18:30:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Flaherty",
      "screen_name" : "Rob_Flaherty",
      "indices" : [ 3, 16 ],
      "id_str" : "24613245",
      "id" : 24613245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679368285306114049",
  "text" : "RT @Rob_Flaherty: Today at Seaworld: dozens trapped in a small, glass-enclosed space. \n\nAlso, people are stuck in the Sky Tower.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679033610091888640",
    "text" : "Today at Seaworld: dozens trapped in a small, glass-enclosed space. \n\nAlso, people are stuck in the Sky Tower.",
    "id" : 679033610091888640,
    "created_at" : "2015-12-21 20:20:03 +0000",
    "user" : {
      "name" : "Rob Flaherty",
      "screen_name" : "Rob_Flaherty",
      "protected" : false,
      "id_str" : "24613245",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788246509036929024\/0eQiwJnT_normal.jpg",
      "id" : 24613245,
      "verified" : false
    }
  },
  "id" : 679368285306114049,
  "created_at" : "2015-12-22 18:29:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 3, 16 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mental_floss\/status\/679308668907610112\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/BrKdO53XPv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW1joo-VEAEE2Xj.png",
      "id_str" : "679308668647575553",
      "id" : 679308668647575553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW1joo-VEAEE2Xj.png",
      "sizes" : [ {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BrKdO53XPv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/RSbX8R7Em8",
      "expanded_url" : "http:\/\/bit.ly\/1R4U8Aw",
      "display_url" : "bit.ly\/1R4U8Aw"
    } ]
  },
  "geo" : { },
  "id_str" : "679368117395566592",
  "text" : "RT @mental_floss: High School\u2019s Anonymous Pantry Offers Discreet Access to Necessities \u2014 https:\/\/t.co\/RSbX8R7Em8 https:\/\/t.co\/BrKdO53XPv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mental_floss\/status\/679308668907610112\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/BrKdO53XPv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW1joo-VEAEE2Xj.png",
        "id_str" : "679308668647575553",
        "id" : 679308668647575553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW1joo-VEAEE2Xj.png",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BrKdO53XPv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/RSbX8R7Em8",
        "expanded_url" : "http:\/\/bit.ly\/1R4U8Aw",
        "display_url" : "bit.ly\/1R4U8Aw"
      } ]
    },
    "geo" : { },
    "id_str" : "679308668907610112",
    "text" : "High School\u2019s Anonymous Pantry Offers Discreet Access to Necessities \u2014 https:\/\/t.co\/RSbX8R7Em8 https:\/\/t.co\/BrKdO53XPv",
    "id" : 679308668907610112,
    "created_at" : "2015-12-22 14:33:02 +0000",
    "user" : {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "protected" : false,
      "id_str" : "20065936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725736720327708672\/QHUualpe_normal.jpg",
      "id" : 20065936,
      "verified" : true
    }
  },
  "id" : 679368117395566592,
  "created_at" : "2015-12-22 18:29:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sinuses",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Uq97t6AESk",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2918",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679367178269798400",
  "text" : "brain is on fire #sinuses .. need to get more advil congestion (from https:\/\/t.co\/Uq97t6AESk)",
  "id" : 679367178269798400,
  "created_at" : "2015-12-22 18:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vern L",
      "screen_name" : "SpeargunWI",
      "indices" : [ 3, 14 ],
      "id_str" : "456331554",
      "id" : 456331554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/R3cvm8a1pl",
      "expanded_url" : "https:\/\/www.facebook.com\/LiberalAndProudOfIt\/posts\/1248682958492050",
      "display_url" : "facebook.com\/LiberalAndProu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679332795848794113",
  "text" : "RT @SpeargunWI: https:\/\/t.co\/R3cvm8a1pl\n\n...why do you suppose RW wants to keep these Americans uneducated, uniformed and unable to VOTE?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/R3cvm8a1pl",
        "expanded_url" : "https:\/\/www.facebook.com\/LiberalAndProudOfIt\/posts\/1248682958492050",
        "display_url" : "facebook.com\/LiberalAndProu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679328497853030400",
    "text" : "https:\/\/t.co\/R3cvm8a1pl\n\n...why do you suppose RW wants to keep these Americans uneducated, uniformed and unable to VOTE?",
    "id" : 679328497853030400,
    "created_at" : "2015-12-22 15:51:49 +0000",
    "user" : {
      "name" : "Vern L",
      "screen_name" : "SpeargunWI",
      "protected" : false,
      "id_str" : "456331554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794521739896193024\/SNG_ZM5a_normal.jpg",
      "id" : 456331554,
      "verified" : false
    }
  },
  "id" : 679332795848794113,
  "created_at" : "2015-12-22 16:08:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slicedlime",
      "screen_name" : "slicedlime",
      "indices" : [ 3, 14 ],
      "id_str" : "16926230",
      "id" : 16926230
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slicedlime\/status\/679270671365615616\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/1qFstS90cS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW1BE1wWwAASEJO.jpg",
      "id_str" : "679270670207991808",
      "id" : 679270670207991808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW1BE1wWwAASEJO.jpg",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1qFstS90cS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679313133756915714",
  "text" : "RT @slicedlime: Oh but it's only metadata. https:\/\/t.co\/1qFstS90cS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slicedlime\/status\/679270671365615616\/photo\/1",
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/1qFstS90cS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW1BE1wWwAASEJO.jpg",
        "id_str" : "679270670207991808",
        "id" : 679270670207991808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW1BE1wWwAASEJO.jpg",
        "sizes" : [ {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1qFstS90cS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679270671365615616",
    "text" : "Oh but it's only metadata. https:\/\/t.co\/1qFstS90cS",
    "id" : 679270671365615616,
    "created_at" : "2015-12-22 12:02:02 +0000",
    "user" : {
      "name" : "slicedlime",
      "screen_name" : "slicedlime",
      "protected" : false,
      "id_str" : "16926230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793440926316322816\/QzMhUDYK_normal.jpg",
      "id" : 16926230,
      "verified" : false
    }
  },
  "id" : 679313133756915714,
  "created_at" : "2015-12-22 14:50:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyeux noel ignatiev",
      "screen_name" : "redstatist",
      "indices" : [ 3, 14 ],
      "id_str" : "992456030",
      "id" : 992456030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679312988663382016",
  "text" : "RT @redstatist: teacher: your child won't stop yelling \"this is bourgeois propaganda\" in social studies\nme: have you tried not teaching bou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "658325493004005376",
    "geo" : { },
    "id_str" : "658326464924921856",
    "in_reply_to_user_id" : 992456030,
    "text" : "teacher: your child won't stop yelling \"this is bourgeois propaganda\" in social studies\nme: have you tried not teaching bourgeois propaganda",
    "id" : 658326464924921856,
    "in_reply_to_status_id" : 658325493004005376,
    "created_at" : "2015-10-25 16:57:15 +0000",
    "in_reply_to_screen_name" : "redstatist",
    "in_reply_to_user_id_str" : "992456030",
    "user" : {
      "name" : "joyeux noel ignatiev",
      "screen_name" : "redstatist",
      "protected" : false,
      "id_str" : "992456030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798985839661449216\/n4lPkqa0_normal.jpg",
      "id" : 992456030,
      "verified" : false
    }
  },
  "id" : 679312988663382016,
  "created_at" : "2015-12-22 14:50:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 3, 7 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUS",
      "indices" : [ 9, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/XxG4a8LwH7",
      "expanded_url" : "http:\/\/n.pr\/1J32UgW",
      "display_url" : "n.pr\/1J32UgW"
    } ]
  },
  "geo" : { },
  "id_str" : "679312172703436800",
  "text" : "RT @NPR: #POTUS advice to college protesters: Disagree w\/others \u201Cbut don\u2019t try to just shut them up\u201D https:\/\/t.co\/XxG4a8LwH7 https:\/\/t.co\/O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NPR\/status\/679299322983370752\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/OViqcQ5aPM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW1bHDmWoAA1GgQ.png",
        "id_str" : "679299295586197504",
        "id" : 679299295586197504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW1bHDmWoAA1GgQ.png",
        "sizes" : [ {
          "h" : 562,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OViqcQ5aPM"
      } ],
      "hashtags" : [ {
        "text" : "POTUS",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/XxG4a8LwH7",
        "expanded_url" : "http:\/\/n.pr\/1J32UgW",
        "display_url" : "n.pr\/1J32UgW"
      } ]
    },
    "geo" : { },
    "id_str" : "679299322983370752",
    "text" : "#POTUS advice to college protesters: Disagree w\/others \u201Cbut don\u2019t try to just shut them up\u201D https:\/\/t.co\/XxG4a8LwH7 https:\/\/t.co\/OViqcQ5aPM",
    "id" : 679299322983370752,
    "created_at" : "2015-12-22 13:55:54 +0000",
    "user" : {
      "name" : "NPR",
      "screen_name" : "NPR",
      "protected" : false,
      "id_str" : "5392522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722199003845304320\/s2zwEoao_normal.jpg",
      "id" : 5392522,
      "verified" : true
    }
  },
  "id" : 679312172703436800,
  "created_at" : "2015-12-22 14:46:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "indices" : [ 3, 16 ],
      "id_str" : "17068546",
      "id" : 17068546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/9G7nm8BL9i",
      "expanded_url" : "https:\/\/twitter.com\/BruceVH\/status\/678960627885457408",
      "display_url" : "twitter.com\/BruceVH\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679141237614641153",
  "text" : "RT @TorontoLydia: This is my life philosophy.  https:\/\/t.co\/9G7nm8BL9i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/9G7nm8BL9i",
        "expanded_url" : "https:\/\/twitter.com\/BruceVH\/status\/678960627885457408",
        "display_url" : "twitter.com\/BruceVH\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679140145581326336",
    "text" : "This is my life philosophy.  https:\/\/t.co\/9G7nm8BL9i",
    "id" : 679140145581326336,
    "created_at" : "2015-12-22 03:23:23 +0000",
    "user" : {
      "name" : "Lydia Schoch",
      "screen_name" : "TorontoLydia",
      "protected" : false,
      "id_str" : "17068546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2110881642\/LydiaTea_normal",
      "id" : 17068546,
      "verified" : false
    }
  },
  "id" : 679141237614641153,
  "created_at" : "2015-12-22 03:27:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox Wild Life",
      "screen_name" : "FoxWLife",
      "indices" : [ 3, 12 ],
      "id_str" : "2309896052",
      "id" : 2309896052
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoxWLife\/status\/677896074141507585\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/x3anOFvvKk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhe4wHUkAAwjWF.jpg",
      "id_str" : "677896073000554496",
      "id" : 677896073000554496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhe4wHUkAAwjWF.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/x3anOFvvKk"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 36, 42 ]
    }, {
      "text" : "nature",
      "indices" : [ 43, 50 ]
    }, {
      "text" : "harbour",
      "indices" : [ 51, 59 ]
    }, {
      "text" : "Lauwersoog",
      "indices" : [ 60, 71 ]
    }, {
      "text" : "Waddensea",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "Netherlands",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679138507760263168",
  "text" : "RT @FoxWLife: I can see you!....... #birds #nature #harbour #Lauwersoog #Waddensea #Netherlands https:\/\/t.co\/x3anOFvvKk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxWLife\/status\/677896074141507585\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/x3anOFvvKk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhe4wHUkAAwjWF.jpg",
        "id_str" : "677896073000554496",
        "id" : 677896073000554496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhe4wHUkAAwjWF.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/x3anOFvvKk"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 22, 28 ]
      }, {
        "text" : "nature",
        "indices" : [ 29, 36 ]
      }, {
        "text" : "harbour",
        "indices" : [ 37, 45 ]
      }, {
        "text" : "Lauwersoog",
        "indices" : [ 46, 57 ]
      }, {
        "text" : "Waddensea",
        "indices" : [ 58, 68 ]
      }, {
        "text" : "Netherlands",
        "indices" : [ 69, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677896074141507585",
    "text" : "I can see you!....... #birds #nature #harbour #Lauwersoog #Waddensea #Netherlands https:\/\/t.co\/x3anOFvvKk",
    "id" : 677896074141507585,
    "created_at" : "2015-12-18 16:59:53 +0000",
    "user" : {
      "name" : "Fox Wild Life",
      "screen_name" : "FoxWLife",
      "protected" : false,
      "id_str" : "2309896052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703903077565214724\/Pu0PwaqM_normal.jpg",
      "id" : 2309896052,
      "verified" : false
    }
  },
  "id" : 679138507760263168,
  "created_at" : "2015-12-22 03:16:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 3, 18 ],
      "id_str" : "112037009",
      "id" : 112037009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679128828590088192",
  "text" : "RT @oliverburkeman: OMG, I can't believe that embarrassing Miss Universe slip-up, where they held the Miss Universe contest even though it'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679072366794641408",
    "text" : "OMG, I can't believe that embarrassing Miss Universe slip-up, where they held the Miss Universe contest even though it's 2015",
    "id" : 679072366794641408,
    "created_at" : "2015-12-21 22:54:03 +0000",
    "user" : {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "protected" : false,
      "id_str" : "112037009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795977217645813760\/AVU2knN3_normal.jpg",
      "id" : 112037009,
      "verified" : true
    }
  },
  "id" : 679128828590088192,
  "created_at" : "2015-12-22 02:38:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/679082798674644994\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/zsv1pbr84y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyWM-kUwAAM72t.jpg",
      "id_str" : "679082793524051968",
      "id" : 679082793524051968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyWM-kUwAAM72t.jpg",
      "sizes" : [ {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zsv1pbr84y"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/679082798674644994\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/zsv1pbr84y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyWM-qU8AA1MP4.jpg",
      "id_str" : "679082793549230080",
      "id" : 679082793549230080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyWM-qU8AA1MP4.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zsv1pbr84y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679087483888472065",
  "text" : "RT @ErinEFarley: Moory Christmas\uD83C\uDF84\uD83D\uDC2E\uD83C\uDF84 \nFleece Navidad \uD83C\uDF84\uD83D\uDC0F\uD83C\uDF84\nPlaying with my toys again. \uD83D\uDE00 https:\/\/t.co\/zsv1pbr84y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/679082798674644994\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/zsv1pbr84y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyWM-kUwAAM72t.jpg",
        "id_str" : "679082793524051968",
        "id" : 679082793524051968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyWM-kUwAAM72t.jpg",
        "sizes" : [ {
          "h" : 696,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/zsv1pbr84y"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/679082798674644994\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/zsv1pbr84y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyWM-qU8AA1MP4.jpg",
        "id_str" : "679082793549230080",
        "id" : 679082793549230080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyWM-qU8AA1MP4.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zsv1pbr84y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679082798674644994",
    "text" : "Moory Christmas\uD83C\uDF84\uD83D\uDC2E\uD83C\uDF84 \nFleece Navidad \uD83C\uDF84\uD83D\uDC0F\uD83C\uDF84\nPlaying with my toys again. \uD83D\uDE00 https:\/\/t.co\/zsv1pbr84y",
    "id" : 679082798674644994,
    "created_at" : "2015-12-21 23:35:30 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 679087483888472065,
  "created_at" : "2015-12-21 23:54:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 3, 15 ],
      "id_str" : "298992506",
      "id" : 298992506
    }, {
      "name" : "Ian Steel",
      "screen_name" : "Snettisher",
      "indices" : [ 20, 31 ],
      "id_str" : "97523471",
      "id" : 97523471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679086070055743489",
  "text" : "RT @wildlife_uk: RT @Snettisher: Female Pheasant coming to feed. Not sure that little tray was designed to take such hefty birds! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Steel",
        "screen_name" : "Snettisher",
        "indices" : [ 3, 14 ],
        "id_str" : "97523471",
        "id" : 97523471
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Snettisher\/status\/678993911017283584\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/rrmocO5isY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWxFXQhWoAEthDq.jpg",
        "id_str" : "678993909700272129",
        "id" : 678993909700272129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWxFXQhWoAEthDq.jpg",
        "sizes" : [ {
          "h" : 2225,
          "resize" : "fit",
          "w" : 2225
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rrmocO5isY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679053772568530944",
    "text" : "RT @Snettisher: Female Pheasant coming to feed. Not sure that little tray was designed to take such hefty birds! https:\/\/t.co\/rrmocO5isY",
    "id" : 679053772568530944,
    "created_at" : "2015-12-21 21:40:10 +0000",
    "user" : {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "protected" : false,
      "id_str" : "298992506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543830606543478784\/DvQW3ag9_normal.png",
      "id" : 298992506,
      "verified" : false
    }
  },
  "id" : 679086070055743489,
  "created_at" : "2015-12-21 23:48:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Poole",
      "screen_name" : "Heather_Poole",
      "indices" : [ 3, 17 ],
      "id_str" : "16688389",
      "id" : 16688389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679070614129418240",
  "text" : "RT @Heather_Poole: Which reminds me, there are two kinds of people in this world.....  I used to say dog people and cat people. Now it's Tw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "679047291488100352",
    "geo" : { },
    "id_str" : "679047661366943744",
    "in_reply_to_user_id" : 16688389,
    "text" : "Which reminds me, there are two kinds of people in this world.....  I used to say dog people and cat people. Now it's Twitter or Facebook.",
    "id" : 679047661366943744,
    "in_reply_to_status_id" : 679047291488100352,
    "created_at" : "2015-12-21 21:15:53 +0000",
    "in_reply_to_screen_name" : "Heather_Poole",
    "in_reply_to_user_id_str" : "16688389",
    "user" : {
      "name" : "Heather Poole",
      "screen_name" : "Heather_Poole",
      "protected" : false,
      "id_str" : "16688389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794649263007379456\/gdgKQ_7u_normal.jpg",
      "id" : 16688389,
      "verified" : false
    }
  },
  "id" : 679070614129418240,
  "created_at" : "2015-12-21 22:47:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 54, 65 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/679006639685558274\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/M5CGH9Vw3v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWxQ8OoW4AEhs-_.jpg",
      "id_str" : "679006639475843073",
      "id" : 679006639475843073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWxQ8OoW4AEhs-_.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/M5CGH9Vw3v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679006639685558274",
  "text" : "Here is card with cat &amp; tree I got last year from @UnseelieMe . Isn't she awesome? : ) https:\/\/t.co\/M5CGH9Vw3v",
  "id" : 679006639685558274,
  "created_at" : "2015-12-21 18:32:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 10, 21 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/679005787306463232\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/UKwRSc2HQJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWxQKnTWoAAALwu.jpg",
      "id_str" : "679005787105173504",
      "id" : 679005787105173504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWxQKnTWoAAALwu.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UKwRSc2HQJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679005787306463232",
  "text" : "Thank you @UnseelieMe for beautiful card. I love it!! : ) https:\/\/t.co\/UKwRSc2HQJ",
  "id" : 679005787306463232,
  "created_at" : "2015-12-21 18:29:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "book",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678950407763283968",
  "text" : "fascinating .. part about brain mapping body .. what's you, not you. and how inner thoughts could be mistaken for voices. #book",
  "id" : 678950407763283968,
  "created_at" : "2015-12-21 14:49:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neuro",
      "indices" : [ 119, 125 ]
    }, {
      "text" : "brain",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678949411515428864",
  "text" : "finished last night &gt; The Man Who Wasn't There: Investigations into the Strange New Science of the Self - exc read! #neuro #brain",
  "id" : 678949411515428864,
  "created_at" : "2015-12-21 14:45:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678928061962825728",
  "geo" : { },
  "id_str" : "678936160933163008",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides ugh. me, too. but mine is hormones i think. will go away shortly. hope you feel better soon.",
  "id" : 678936160933163008,
  "in_reply_to_status_id" : 678928061962825728,
  "created_at" : "2015-12-21 13:52:49 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WarOnChristmas",
      "indices" : [ 93, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/CZKYOkNtJ6",
      "expanded_url" : "https:\/\/twitter.com\/RelUnrelated\/status\/678757877402603520",
      "display_url" : "twitter.com\/RelUnrelated\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678760192604053504",
  "text" : "RT @ZachsMind: It appears those currently running congress have completely lost their minds. #WarOnChristmas  https:\/\/t.co\/CZKYOkNtJ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WarOnChristmas",
        "indices" : [ 78, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/CZKYOkNtJ6",
        "expanded_url" : "https:\/\/twitter.com\/RelUnrelated\/status\/678757877402603520",
        "display_url" : "twitter.com\/RelUnrelated\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "678758195121119232",
    "text" : "It appears those currently running congress have completely lost their minds. #WarOnChristmas  https:\/\/t.co\/CZKYOkNtJ6",
    "id" : 678758195121119232,
    "created_at" : "2015-12-21 02:05:39 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 678760192604053504,
  "created_at" : "2015-12-21 02:13:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "King Alfred",
      "screen_name" : "KingDouyeAlfred",
      "indices" : [ 3, 19 ],
      "id_str" : "440690311",
      "id" : 440690311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678748407041773568",
  "text" : "RT @KingDouyeAlfred: Apartheid was \"legal\"\nSlavery was \"legal\"\nColonialism was \"legal\"\n\nLegality is a construct of the powerful\n\nNot of jus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574650474407849984",
    "text" : "Apartheid was \"legal\"\nSlavery was \"legal\"\nColonialism was \"legal\"\n\nLegality is a construct of the powerful\n\nNot of justice",
    "id" : 574650474407849984,
    "created_at" : "2015-03-08 19:18:44 +0000",
    "user" : {
      "name" : "King Alfred",
      "screen_name" : "KingDouyeAlfred",
      "protected" : false,
      "id_str" : "440690311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733674377255002113\/RSg5-4fs_normal.jpg",
      "id" : 440690311,
      "verified" : false
    }
  },
  "id" : 678748407041773568,
  "created_at" : "2015-12-21 01:26:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CalgaryPublicLibrary",
      "screen_name" : "calgarylibrary",
      "indices" : [ 3, 18 ],
      "id_str" : "27901722",
      "id" : 27901722
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/calgarylibrary\/status\/678379303910768640\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/WR4xr06ZGN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWoWYfOU8AEHczv.jpg",
      "id_str" : "678379303826944001",
      "id" : 678379303826944001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWoWYfOU8AEHczv.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WR4xr06ZGN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678725270447267842",
  "text" : "RT @calgarylibrary: We don't have all of the following formats yet, but remain intrigued by the mechanical raven. https:\/\/t.co\/WR4xr06ZGN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/calgarylibrary\/status\/678379303910768640\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/WR4xr06ZGN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWoWYfOU8AEHczv.jpg",
        "id_str" : "678379303826944001",
        "id" : 678379303826944001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWoWYfOU8AEHczv.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WR4xr06ZGN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678379303910768640",
    "text" : "We don't have all of the following formats yet, but remain intrigued by the mechanical raven. https:\/\/t.co\/WR4xr06ZGN",
    "id" : 678379303910768640,
    "created_at" : "2015-12-20 01:00:04 +0000",
    "user" : {
      "name" : "CalgaryPublicLibrary",
      "screen_name" : "calgarylibrary",
      "protected" : false,
      "id_str" : "27901722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551072090699218944\/vkXVpO4__normal.png",
      "id" : 27901722,
      "verified" : false
    }
  },
  "id" : 678725270447267842,
  "created_at" : "2015-12-20 23:54:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/678678200671674368\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/G4HOOnWFrx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWsmOaJWoAAzkNN.jpg",
      "id_str" : "678678197827969024",
      "id" : 678678197827969024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWsmOaJWoAAzkNN.jpg",
      "sizes" : [ {
        "h" : 715,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G4HOOnWFrx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/dPOH4z7IYj",
      "expanded_url" : "https:\/\/www.facebook.com\/greenrenaissance\/photos\/a.210721328945659.58322.120085081342618\/1113419262009190\/?type=3&_ts=1450644462",
      "display_url" : "facebook.com\/greenrenaissan\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678678200671674368",
  "text" : "While rescuing injured birds, the swan wrapped... https:\/\/t.co\/dPOH4z7IYj https:\/\/t.co\/G4HOOnWFrx",
  "id" : 678678200671674368,
  "created_at" : "2015-12-20 20:47:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vsSBgm72rJ",
      "expanded_url" : "https:\/\/twitter.com\/TLaTela\/status\/678577295888539648",
      "display_url" : "twitter.com\/TLaTela\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678671023315787780",
  "text" : "wth did I just watch? why did he sit on him after handcuffed? was that a paramedic at 6:43 who then walked away? https:\/\/t.co\/vsSBgm72rJ",
  "id" : 678671023315787780,
  "created_at" : "2015-12-20 20:19:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stardust",
      "screen_name" : "rockermom53",
      "indices" : [ 3, 15 ],
      "id_str" : "14522779",
      "id" : 14522779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678404677332033537",
  "text" : "RT @rockermom53: Elf on a shelf. Accustoming your children to a world of being continually monitored. Willingly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678200001672011776",
    "text" : "Elf on a shelf. Accustoming your children to a world of being continually monitored. Willingly.",
    "id" : 678200001672011776,
    "created_at" : "2015-12-19 13:07:35 +0000",
    "user" : {
      "name" : "stardust",
      "screen_name" : "rockermom53",
      "protected" : false,
      "id_str" : "14522779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793606996817645569\/hFlxXf9M_normal.jpg",
      "id" : 14522779,
      "verified" : false
    }
  },
  "id" : 678404677332033537,
  "created_at" : "2015-12-20 02:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trevor Noah",
      "screen_name" : "Trevornoah",
      "indices" : [ 3, 14 ],
      "id_str" : "46335511",
      "id" : 46335511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678362024322187264",
  "text" : "RT @Trevornoah: Video game difficulty settings should be - \n\n1. Full Time Job\n2. Part Time\n3. Unemployed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678295571728310272",
    "text" : "Video game difficulty settings should be - \n\n1. Full Time Job\n2. Part Time\n3. Unemployed",
    "id" : 678295571728310272,
    "created_at" : "2015-12-19 19:27:21 +0000",
    "user" : {
      "name" : "Trevor Noah",
      "screen_name" : "Trevornoah",
      "protected" : false,
      "id_str" : "46335511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743628279106650112\/WSAe7LOv_normal.jpg",
      "id" : 46335511,
      "verified" : true
    }
  },
  "id" : 678362024322187264,
  "created_at" : "2015-12-19 23:51:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/5twWeIHoee",
      "expanded_url" : "https:\/\/twitter.com\/PastorMark\/status\/677953990156529665",
      "display_url" : "twitter.com\/PastorMark\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678358891806269441",
  "text" : "o-O https:\/\/t.co\/5twWeIHoee",
  "id" : 678358891806269441,
  "created_at" : "2015-12-19 23:38:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neuro",
      "indices" : [ 93, 99 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/JH8dZ6F3Xd",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2890",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678355785257062400",
  "text" : "DD says she has increased time looping this week.. something she's exp on and off thru the \u2026 #neuro #chronicillness https:\/\/t.co\/JH8dZ6F3Xd",
  "id" : 678355785257062400,
  "created_at" : "2015-12-19 23:26:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Irish Stewart)))",
      "screen_name" : "NakedAxiom",
      "indices" : [ 3, 14 ],
      "id_str" : "23780154",
      "id" : 23780154
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 126, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678277339831214080",
  "text" : "RT @NakedAxiom: Your progressive\/liberal \"principles\" will mean NOTHING in a country ruled by conservative fascists. Nothing. #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 110, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678276142088871936",
    "text" : "Your progressive\/liberal \"principles\" will mean NOTHING in a country ruled by conservative fascists. Nothing. #p2",
    "id" : 678276142088871936,
    "created_at" : "2015-12-19 18:10:08 +0000",
    "user" : {
      "name" : "(((Irish Stewart)))",
      "screen_name" : "NakedAxiom",
      "protected" : false,
      "id_str" : "23780154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798404337777176577\/0k0RMEX9_normal.jpg",
      "id" : 23780154,
      "verified" : false
    }
  },
  "id" : 678277339831214080,
  "created_at" : "2015-12-19 18:14:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Irish Stewart)))",
      "screen_name" : "NakedAxiom",
      "indices" : [ 3, 14 ],
      "id_str" : "23780154",
      "id" : 23780154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678277310194302976",
  "text" : "RT @NakedAxiom: To \"stick together\" doesn't mean we all agree who the BEST candidate is; it means we RESPECT each other &amp; stand behind the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 139, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678274862423523328",
    "text" : "To \"stick together\" doesn't mean we all agree who the BEST candidate is; it means we RESPECT each other &amp; stand behind the chosen nom. #p2",
    "id" : 678274862423523328,
    "created_at" : "2015-12-19 18:05:03 +0000",
    "user" : {
      "name" : "(((Irish Stewart)))",
      "screen_name" : "NakedAxiom",
      "protected" : false,
      "id_str" : "23780154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798404337777176577\/0k0RMEX9_normal.jpg",
      "id" : 23780154,
      "verified" : false
    }
  },
  "id" : 678277310194302976,
  "created_at" : "2015-12-19 18:14:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Irish Stewart)))",
      "screen_name" : "NakedAxiom",
      "indices" : [ 3, 14 ],
      "id_str" : "23780154",
      "id" : 23780154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678276842592329729",
  "text" : "RT @NakedAxiom: You don't win votes for your candidate by insulting others. Talk about why your candidate is great, not why the other one s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 129, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677984085978030080",
    "text" : "You don't win votes for your candidate by insulting others. Talk about why your candidate is great, not why the other one sucks. #p2",
    "id" : 677984085978030080,
    "created_at" : "2015-12-18 22:49:37 +0000",
    "user" : {
      "name" : "(((Irish Stewart)))",
      "screen_name" : "NakedAxiom",
      "protected" : false,
      "id_str" : "23780154",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798404337777176577\/0k0RMEX9_normal.jpg",
      "id" : 23780154,
      "verified" : false
    }
  },
  "id" : 678276842592329729,
  "created_at" : "2015-12-19 18:12:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashleigh",
      "screen_name" : "ashleigh_young",
      "indices" : [ 3, 18 ],
      "id_str" : "156501287",
      "id" : 156501287
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ashleigh_young\/status\/677187812702089216\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/mMw2YbcIcX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXauKjUAAAkXnZ.jpg",
      "id_str" : "677187805630431232",
      "id" : 677187805630431232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXauKjUAAAkXnZ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mMw2YbcIcX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678237322773733380",
  "text" : "RT @ashleigh_young: 'You may have your shoes if you answer me these questions three' https:\/\/t.co\/mMw2YbcIcX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ashleigh_young\/status\/677187812702089216\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/mMw2YbcIcX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXauKjUAAAkXnZ.jpg",
        "id_str" : "677187805630431232",
        "id" : 677187805630431232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXauKjUAAAkXnZ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mMw2YbcIcX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677187812702089216",
    "text" : "'You may have your shoes if you answer me these questions three' https:\/\/t.co\/mMw2YbcIcX",
    "id" : 677187812702089216,
    "created_at" : "2015-12-16 18:05:30 +0000",
    "user" : {
      "name" : "ashleigh",
      "screen_name" : "ashleigh_young",
      "protected" : false,
      "id_str" : "156501287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746859970361102338\/e-gTbOo__normal.jpg",
      "id" : 156501287,
      "verified" : false
    }
  },
  "id" : 678237322773733380,
  "created_at" : "2015-12-19 15:35:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Lawrence",
      "screen_name" : "WoodSplitters",
      "indices" : [ 3, 17 ],
      "id_str" : "120956491",
      "id" : 120956491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tree",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/d3SauEQLEe",
      "expanded_url" : "http:\/\/bit.ly\/1JC1aVC",
      "display_url" : "bit.ly\/1JC1aVC"
    } ]
  },
  "geo" : { },
  "id_str" : "678237265253031936",
  "text" : "RT @WoodSplitters: Take a look at what a #tree looks like when it gets sliced for use. Amazing, isn't it? https:\/\/t.co\/d3SauEQLEe https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/meetedgar.com\" rel=\"nofollow\"\u003EMeet Edgar\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WoodSplitters\/status\/677179214378967040\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Emom2P38a7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXS6FQW4AITM9M.jpg",
        "id_str" : "677179214274158594",
        "id" : 677179214274158594,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXS6FQW4AITM9M.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 265,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/Emom2P38a7"
      } ],
      "hashtags" : [ {
        "text" : "tree",
        "indices" : [ 22, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/d3SauEQLEe",
        "expanded_url" : "http:\/\/bit.ly\/1JC1aVC",
        "display_url" : "bit.ly\/1JC1aVC"
      } ]
    },
    "geo" : { },
    "id_str" : "677179214378967040",
    "text" : "Take a look at what a #tree looks like when it gets sliced for use. Amazing, isn't it? https:\/\/t.co\/d3SauEQLEe https:\/\/t.co\/Emom2P38a7",
    "id" : 677179214378967040,
    "created_at" : "2015-12-16 17:31:20 +0000",
    "user" : {
      "name" : "Andy Lawrence",
      "screen_name" : "WoodSplitters",
      "protected" : false,
      "id_str" : "120956491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531645256161189888\/sZ-86aLS_normal.jpeg",
      "id" : 120956491,
      "verified" : false
    }
  },
  "id" : 678237265253031936,
  "created_at" : "2015-12-19 15:35:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eileen Ridge",
      "screen_name" : "notbangalore",
      "indices" : [ 3, 16 ],
      "id_str" : "499865594",
      "id" : 499865594
    }, {
      "name" : "explore.org",
      "screen_name" : "exploreorg",
      "indices" : [ 100, 111 ],
      "id_str" : "20565876",
      "id" : 20565876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "polarbearcam",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/qc15z3Q7dI",
      "expanded_url" : "https:\/\/vine.co\/v\/eLKtQ9z55dr",
      "display_url" : "vine.co\/v\/eLKtQ9z55dr"
    } ]
  },
  "geo" : { },
  "id_str" : "678237141332271106",
  "text" : "RT @notbangalore: Oh good morning, beautiful gyrfalcon. Funny seeing you on #polarbearcam. (Vine by @exploreorg) https:\/\/t.co\/qc15z3Q7dI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "explore.org",
        "screen_name" : "exploreorg",
        "indices" : [ 82, 93 ],
        "id_str" : "20565876",
        "id" : 20565876
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "polarbearcam",
        "indices" : [ 58, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/qc15z3Q7dI",
        "expanded_url" : "https:\/\/vine.co\/v\/eLKtQ9z55dr",
        "display_url" : "vine.co\/v\/eLKtQ9z55dr"
      } ]
    },
    "geo" : { },
    "id_str" : "662071772397903872",
    "text" : "Oh good morning, beautiful gyrfalcon. Funny seeing you on #polarbearcam. (Vine by @exploreorg) https:\/\/t.co\/qc15z3Q7dI",
    "id" : 662071772397903872,
    "created_at" : "2015-11-05 00:59:45 +0000",
    "user" : {
      "name" : "Eileen Ridge",
      "screen_name" : "notbangalore",
      "protected" : false,
      "id_str" : "499865594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764984264265916416\/E4959FNU_normal.jpg",
      "id" : 499865594,
      "verified" : false
    }
  },
  "id" : 678237141332271106,
  "created_at" : "2015-12-19 15:35:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roo Reynolds",
      "screen_name" : "rooreynolds",
      "indices" : [ 3, 15 ],
      "id_str" : "787166",
      "id" : 787166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678236897483890688",
  "text" : "RT @rooreynolds: My wife has been knitting Clangers. Our sofa looks like the scene of a horrific Clanger skinning incident. https:\/\/t.co\/16\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rooreynolds\/status\/678147727226748928\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/16qWvh9iX7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWlDwjjXIAAzlc2.jpg",
        "id_str" : "678147720352309248",
        "id" : 678147720352309248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWlDwjjXIAAzlc2.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/16qWvh9iX7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678147727226748928",
    "text" : "My wife has been knitting Clangers. Our sofa looks like the scene of a horrific Clanger skinning incident. https:\/\/t.co\/16qWvh9iX7",
    "id" : 678147727226748928,
    "created_at" : "2015-12-19 09:39:52 +0000",
    "user" : {
      "name" : "Roo Reynolds",
      "screen_name" : "rooreynolds",
      "protected" : false,
      "id_str" : "787166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458878917558800384\/LREXqxJJ_normal.jpeg",
      "id" : 787166,
      "verified" : false
    }
  },
  "id" : 678236897483890688,
  "created_at" : "2015-12-19 15:34:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squirrelcam",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/LedXNPDYFH",
      "expanded_url" : "http:\/\/wildlifegadgetman.com\/live-cams\/live-stream-2\/",
      "display_url" : "wildlifegadgetman.com\/live-cams\/live\u2026"
    }, {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Dsn1eim2bQ",
      "expanded_url" : "https:\/\/vine.co\/v\/iKAe3YUeXFZ",
      "display_url" : "vine.co\/v\/iKAe3YUeXFZ"
    } ]
  },
  "geo" : { },
  "id_str" : "678236266425679872",
  "text" : "RT @WildlifeGadgets: Time for an afternoon nibble on #squirrelcam https:\/\/t.co\/LedXNPDYFH https:\/\/t.co\/Dsn1eim2bQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squirrelcam",
        "indices" : [ 32, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/LedXNPDYFH",
        "expanded_url" : "http:\/\/wildlifegadgetman.com\/live-cams\/live-stream-2\/",
        "display_url" : "wildlifegadgetman.com\/live-cams\/live\u2026"
      }, {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/Dsn1eim2bQ",
        "expanded_url" : "https:\/\/vine.co\/v\/iKAe3YUeXFZ",
        "display_url" : "vine.co\/v\/iKAe3YUeXFZ"
      } ]
    },
    "geo" : { },
    "id_str" : "678229120619323396",
    "text" : "Time for an afternoon nibble on #squirrelcam https:\/\/t.co\/LedXNPDYFH https:\/\/t.co\/Dsn1eim2bQ",
    "id" : 678229120619323396,
    "created_at" : "2015-12-19 15:03:17 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 678236266425679872,
  "created_at" : "2015-12-19 15:31:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Odd News from @UPI",
      "screen_name" : "OddNewsUPI",
      "indices" : [ 84, 95 ],
      "id_str" : "16747333",
      "id" : 16747333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/d10Oo48KJD",
      "expanded_url" : "http:\/\/upi.com\/6189757t",
      "display_url" : "upi.com\/6189757t"
    } ]
  },
  "geo" : { },
  "id_str" : "678224283273928705",
  "text" : ": (  Clay's Corner Possum Drop gets go-ahead from judge https:\/\/t.co\/d10Oo48KJD via @oddnewsupi",
  "id" : 678224283273928705,
  "created_at" : "2015-12-19 14:44:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 2, 13 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677252586253230080",
  "geo" : { },
  "id_str" : "678222024435703808",
  "in_reply_to_user_id" : 93747129,
  "text" : ". @moosebegab well, peeps.. you were no help but DH figured it out. I pulled off the wrong side. its a reg usb.",
  "id" : 678222024435703808,
  "in_reply_to_status_id" : 677252586253230080,
  "created_at" : "2015-12-19 14:35:06 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KSwa50",
      "screen_name" : "KSwa50",
      "indices" : [ 3, 10 ],
      "id_str" : "885601772",
      "id" : 885601772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/Pz6uQjAV79",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/flint-lead-poisoning_56732a38e4b06fa6887ca710",
      "display_url" : "huffingtonpost.com\/entry\/flint-le\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "678214855535566848",
  "text" : "RT @KSwa50: Why Flint's water crisis is so incredibly bad https:\/\/t.co\/Pz6uQjAV79\npoisoning of these children\/people is crimminal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/Pz6uQjAV79",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/flint-lead-poisoning_56732a38e4b06fa6887ca710",
        "display_url" : "huffingtonpost.com\/entry\/flint-le\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "678044481048850432",
    "text" : "Why Flint's water crisis is so incredibly bad https:\/\/t.co\/Pz6uQjAV79\npoisoning of these children\/people is crimminal",
    "id" : 678044481048850432,
    "created_at" : "2015-12-19 02:49:36 +0000",
    "user" : {
      "name" : "KSwa50",
      "screen_name" : "KSwa50",
      "protected" : false,
      "id_str" : "885601772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734957248208769024\/5Z8y9_ev_normal.jpg",
      "id" : 885601772,
      "verified" : false
    }
  },
  "id" : 678214855535566848,
  "created_at" : "2015-12-19 14:06:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Featured Creature",
      "screen_name" : "ftcreature",
      "indices" : [ 3, 14 ],
      "id_str" : "200405814",
      "id" : 200405814
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ftcreature\/status\/678072773277646849\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/VbDXDpIExJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWj_mBPUsAETF2s.png",
      "id_str" : "678072772552077313",
      "id" : 678072772552077313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWj_mBPUsAETF2s.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 716
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 716
      } ],
      "display_url" : "pic.twitter.com\/VbDXDpIExJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678076345457500160",
  "text" : "RT @ftcreature: How to Become a Circle\nby Cat. https:\/\/t.co\/VbDXDpIExJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ftcreature\/status\/678072773277646849\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/VbDXDpIExJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWj_mBPUsAETF2s.png",
        "id_str" : "678072772552077313",
        "id" : 678072772552077313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWj_mBPUsAETF2s.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 515,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 716
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 716
        } ],
        "display_url" : "pic.twitter.com\/VbDXDpIExJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678072773277646849",
    "text" : "How to Become a Circle\nby Cat. https:\/\/t.co\/VbDXDpIExJ",
    "id" : 678072773277646849,
    "created_at" : "2015-12-19 04:42:01 +0000",
    "user" : {
      "name" : "Featured Creature",
      "screen_name" : "ftcreature",
      "protected" : false,
      "id_str" : "200405814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551555671250849792\/OfxvQB_p_normal.png",
      "id" : 200405814,
      "verified" : false
    }
  },
  "id" : 678076345457500160,
  "created_at" : "2015-12-19 04:56:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen",
      "screen_name" : "helen_a15",
      "indices" : [ 0, 10 ],
      "id_str" : "3495798616",
      "id" : 3495798616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "678001841800683520",
  "geo" : { },
  "id_str" : "678006709659529216",
  "in_reply_to_user_id" : 3495798616,
  "text" : "@helen_a15 yes",
  "id" : 678006709659529216,
  "in_reply_to_status_id" : 678001841800683520,
  "created_at" : "2015-12-19 00:19:30 +0000",
  "in_reply_to_screen_name" : "helen_a15",
  "in_reply_to_user_id_str" : "3495798616",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 3, 18 ],
      "id_str" : "18655567",
      "id" : 18655567
    }, {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 27, 34 ],
      "id_str" : "91478624",
      "id" : 91478624
    }, {
      "name" : "Tara Haelle",
      "screen_name" : "tarahaelle",
      "indices" : [ 36, 47 ],
      "id_str" : "16931273",
      "id" : 16931273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeuroTribes",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677886890645721088",
  "text" : "RT @stevesilberman: ICYMI: @Forbes' @tarahaelle says \"Everyone needs to read #NeuroTribes. Everyone.\" Plus, in-depth interview with me. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Forbes",
        "screen_name" : "Forbes",
        "indices" : [ 7, 14 ],
        "id_str" : "91478624",
        "id" : 91478624
      }, {
        "name" : "Tara Haelle",
        "screen_name" : "tarahaelle",
        "indices" : [ 16, 27 ],
        "id_str" : "16931273",
        "id" : 16931273
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NeuroTribes",
        "indices" : [ 57, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/BMYeMoon5E",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/tarahaelle\/2015\/12\/17\/why-you-should-buy-neurotribes-for-everyone-on-your-christmas-list\/",
        "display_url" : "forbes.com\/sites\/tarahael\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677861542969217024",
    "text" : "ICYMI: @Forbes' @tarahaelle says \"Everyone needs to read #NeuroTribes. Everyone.\" Plus, in-depth interview with me. https:\/\/t.co\/BMYeMoon5E",
    "id" : 677861542969217024,
    "created_at" : "2015-12-18 14:42:40 +0000",
    "user" : {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "protected" : false,
      "id_str" : "18655567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759556547336818689\/atgxGu8g_normal.jpg",
      "id" : 18655567,
      "verified" : false
    }
  },
  "id" : 677886890645721088,
  "created_at" : "2015-12-18 16:23:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bambi L Albert",
      "screen_name" : "blamom",
      "indices" : [ 3, 10 ],
      "id_str" : "20839221",
      "id" : 20839221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/pOkCQY41VS",
      "expanded_url" : "http:\/\/fb.me\/2CXPV42LR",
      "display_url" : "fb.me\/2CXPV42LR"
    } ]
  },
  "geo" : { },
  "id_str" : "677885153767649280",
  "text" : "RT @blamom: BREAKING: NYC Judge Blocks Mandatory Flu Vaccines https:\/\/t.co\/pOkCQY41VS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/pOkCQY41VS",
        "expanded_url" : "http:\/\/fb.me\/2CXPV42LR",
        "display_url" : "fb.me\/2CXPV42LR"
      } ]
    },
    "geo" : { },
    "id_str" : "677822575737765888",
    "text" : "BREAKING: NYC Judge Blocks Mandatory Flu Vaccines https:\/\/t.co\/pOkCQY41VS",
    "id" : 677822575737765888,
    "created_at" : "2015-12-18 12:07:50 +0000",
    "user" : {
      "name" : "Bambi L Albert",
      "screen_name" : "blamom",
      "protected" : false,
      "id_str" : "20839221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574910934881169410\/onaDy9Eh_normal.jpeg",
      "id" : 20839221,
      "verified" : false
    }
  },
  "id" : 677885153767649280,
  "created_at" : "2015-12-18 16:16:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "It's Abby. Yep.",
      "screen_name" : "abbycohenwl",
      "indices" : [ 3, 15 ],
      "id_str" : "73797299",
      "id" : 73797299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677884630184267776",
  "text" : "RT @abbycohenwl: *releases helium-filled heart balloon*\nMe: You're free now\nBalloon: Ima choke a bird",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566775887681441792",
    "text" : "*releases helium-filled heart balloon*\nMe: You're free now\nBalloon: Ima choke a bird",
    "id" : 566775887681441792,
    "created_at" : "2015-02-15 01:47:56 +0000",
    "user" : {
      "name" : "It's Abby. Yep.",
      "screen_name" : "abbycohenwl",
      "protected" : false,
      "id_str" : "73797299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793314258503081984\/joFtVwo8_normal.jpg",
      "id" : 73797299,
      "verified" : false
    }
  },
  "id" : 677884630184267776,
  "created_at" : "2015-12-18 16:14:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PolicethePoliceACP",
      "screen_name" : "PolicePoliceACP",
      "indices" : [ 3, 19 ],
      "id_str" : "1965576588",
      "id" : 1965576588
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PolicePoliceACP\/status\/677670892344754176\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/TYHG4HICq7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWcq9VFWwAIGCNs.jpg",
      "id_str" : "677557502062542850",
      "id" : 677557502062542850,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWcq9VFWwAIGCNs.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/TYHG4HICq7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677883381569425408",
  "text" : "RT @PolicePoliceACP: Cue the Bernie Sanders supporters https:\/\/t.co\/TYHG4HICq7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PolicePoliceACP\/status\/677670892344754176\/photo\/1",
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/TYHG4HICq7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWcq9VFWwAIGCNs.jpg",
        "id_str" : "677557502062542850",
        "id" : 677557502062542850,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWcq9VFWwAIGCNs.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/TYHG4HICq7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677670892344754176",
    "text" : "Cue the Bernie Sanders supporters https:\/\/t.co\/TYHG4HICq7",
    "id" : 677670892344754176,
    "created_at" : "2015-12-18 02:05:05 +0000",
    "user" : {
      "name" : "PolicethePoliceACP",
      "screen_name" : "PolicePoliceACP",
      "protected" : false,
      "id_str" : "1965576588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600697462634876928\/6hg2Txi9_normal.jpg",
      "id" : 1965576588,
      "verified" : false
    }
  },
  "id" : 677883381569425408,
  "created_at" : "2015-12-18 16:09:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677697130287472640",
  "geo" : { },
  "id_str" : "677698442270007296",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 : )",
  "id" : 677698442270007296,
  "in_reply_to_status_id" : 677697130287472640,
  "created_at" : "2015-12-18 03:54:34 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spry Guy",
      "screen_name" : "SpryGuy",
      "indices" : [ 3, 11 ],
      "id_str" : "228015335",
      "id" : 228015335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677687837173653505",
  "text" : "RT @SpryGuy: Banks collected $30 Billion in over-draft fees last year...which means highly profitable banks collected $30B from people who \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563872147500572672",
    "text" : "Banks collected $30 Billion in over-draft fees last year...which means highly profitable banks collected $30B from people who HAD NO MONEY.",
    "id" : 563872147500572672,
    "created_at" : "2015-02-07 01:29:30 +0000",
    "user" : {
      "name" : "Spry Guy",
      "screen_name" : "SpryGuy",
      "protected" : false,
      "id_str" : "228015335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3358487599\/b7e72aaa11db9b615a2017dc45c8ee13_normal.png",
      "id" : 228015335,
      "verified" : false
    }
  },
  "id" : 677687837173653505,
  "created_at" : "2015-12-18 03:12:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank M. Howell",
      "screen_name" : "frankhowell7911",
      "indices" : [ 9, 25 ],
      "id_str" : "2871899817",
      "id" : 2871899817
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QizXvcxwSn",
      "expanded_url" : "http:\/\/nydn.us\/1LXHkGm",
      "display_url" : "nydn.us\/1LXHkGm"
    } ]
  },
  "geo" : { },
  "id_str" : "677687441864675329",
  "text" : "Sick  RT @frankhowell7911: City of Cleveland says Tamir Rice's death was his own fault https:\/\/t.co\/QizXvcxwSn",
  "id" : 677687441864675329,
  "created_at" : "2015-12-18 03:10:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/eW81VfCdDl",
      "expanded_url" : "http:\/\/flip.it\/FUi8X",
      "display_url" : "flip.it\/FUi8X"
    } ]
  },
  "geo" : { },
  "id_str" : "677664026529275904",
  "text" : "RT @SpiritualNurse: \"I Felt Set Up\": Why More Women Seeking Abortions Are Ending Up at Anti-Abortion Pregnancy \u2026\nhttps:\/\/t.co\/eW81VfCdDl ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/677660261558390786\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/VAmdimN42I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWeIatZWcAADSkU.jpg",
        "id_str" : "677660261386448896",
        "id" : 677660261386448896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWeIatZWcAADSkU.jpg",
        "sizes" : [ {
          "h" : 616,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/VAmdimN42I"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/eW81VfCdDl",
        "expanded_url" : "http:\/\/flip.it\/FUi8X",
        "display_url" : "flip.it\/FUi8X"
      } ]
    },
    "geo" : { },
    "id_str" : "677660261558390786",
    "text" : "\"I Felt Set Up\": Why More Women Seeking Abortions Are Ending Up at Anti-Abortion Pregnancy \u2026\nhttps:\/\/t.co\/eW81VfCdDl https:\/\/t.co\/VAmdimN42I",
    "id" : 677660261558390786,
    "created_at" : "2015-12-18 01:22:51 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 677664026529275904,
  "created_at" : "2015-12-18 01:37:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Beatty",
      "screen_name" : "LindaBeatty",
      "indices" : [ 3, 15 ],
      "id_str" : "178704473",
      "id" : 178704473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheistbecause",
      "indices" : [ 89, 104 ]
    }, {
      "text" : "ReligionPoisonsEverything",
      "indices" : [ 105, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677653424985522179",
  "text" : "RT @LindaBeatty: A god torturing people for eternity isn't just. He's an evil psychopath #atheistbecause #ReligionPoisonsEverything https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheistbecause",
        "indices" : [ 72, 87 ]
      }, {
        "text" : "ReligionPoisonsEverything",
        "indices" : [ 88, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/JcIQPKVL52",
        "expanded_url" : "https:\/\/twitter.com\/theidealtwit\/status\/677463375832416256",
        "display_url" : "twitter.com\/theidealtwit\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677653237718216706",
    "text" : "A god torturing people for eternity isn't just. He's an evil psychopath #atheistbecause #ReligionPoisonsEverything https:\/\/t.co\/JcIQPKVL52",
    "id" : 677653237718216706,
    "created_at" : "2015-12-18 00:54:56 +0000",
    "user" : {
      "name" : "Linda Beatty",
      "screen_name" : "LindaBeatty",
      "protected" : false,
      "id_str" : "178704473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692919150688231426\/5Xyc1ALq_normal.jpg",
      "id" : 178704473,
      "verified" : false
    }
  },
  "id" : 677653424985522179,
  "created_at" : "2015-12-18 00:55:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677638209376018434",
  "geo" : { },
  "id_str" : "677650111820861440",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time albertcamuuuuuus! (voice from audiobook.. absurdity and Albert Camus)",
  "id" : 677650111820861440,
  "in_reply_to_status_id" : 677638209376018434,
  "created_at" : "2015-12-18 00:42:31 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677638691540615168",
  "geo" : { },
  "id_str" : "677649668612952064",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe oh dear...",
  "id" : 677649668612952064,
  "in_reply_to_status_id" : 677638691540615168,
  "created_at" : "2015-12-18 00:40:45 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 3, 15 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    }, {
      "name" : "Serial",
      "screen_name" : "serial",
      "indices" : [ 53, 60 ],
      "id_str" : "2319108198",
      "id" : 2319108198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/mVwo5z4jbm",
      "expanded_url" : "https:\/\/www.producthunt.com\/podcasts\/serial-s2e2-the-golden-chicken",
      "display_url" : "producthunt.com\/podcasts\/seria\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677649044253057026",
  "text" : "RT @ProductHunt: \u201CWhat is Bergdahl worth to us?\"\n\nOn @Serial S2E2 each side ends up asking the same thing https:\/\/t.co\/mVwo5z4jbm \uD83C\uDFA7\uD83C\uDF99 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Serial",
        "screen_name" : "serial",
        "indices" : [ 36, 43 ],
        "id_str" : "2319108198",
        "id" : 2319108198
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ProductHunt\/status\/677647592000499712\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/PQQalISoin",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWd84ktXAAEz0iJ.png",
        "id_str" : "677647580310994945",
        "id" : 677647580310994945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWd84ktXAAEz0iJ.png",
        "sizes" : [ {
          "h" : 281,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PQQalISoin"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/mVwo5z4jbm",
        "expanded_url" : "https:\/\/www.producthunt.com\/podcasts\/serial-s2e2-the-golden-chicken",
        "display_url" : "producthunt.com\/podcasts\/seria\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677647592000499712",
    "text" : "\u201CWhat is Bergdahl worth to us?\"\n\nOn @Serial S2E2 each side ends up asking the same thing https:\/\/t.co\/mVwo5z4jbm \uD83C\uDFA7\uD83C\uDF99 https:\/\/t.co\/PQQalISoin",
    "id" : 677647592000499712,
    "created_at" : "2015-12-18 00:32:30 +0000",
    "user" : {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "protected" : false,
      "id_str" : "2208027565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783677864831021057\/fNU8i_FW_normal.jpg",
      "id" : 2208027565,
      "verified" : true
    }
  },
  "id" : 677649044253057026,
  "created_at" : "2015-12-18 00:38:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Mo",
      "screen_name" : "TheChuckMo",
      "indices" : [ 3, 14 ],
      "id_str" : "14557247",
      "id" : 14557247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChristianValues",
      "indices" : [ 16, 32 ]
    }, {
      "text" : "ChristianNation",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/AcpJmULMXD",
      "expanded_url" : "https:\/\/twitter.com\/ShanuKurd\/status\/677296212358381568",
      "display_url" : "twitter.com\/ShanuKurd\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677648919921303556",
  "text" : "RT @TheChuckMo: #ChristianValues in a #ChristianNation  https:\/\/t.co\/AcpJmULMXD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChristianValues",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "ChristianNation",
        "indices" : [ 22, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/AcpJmULMXD",
        "expanded_url" : "https:\/\/twitter.com\/ShanuKurd\/status\/677296212358381568",
        "display_url" : "twitter.com\/ShanuKurd\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677647061999869954",
    "text" : "#ChristianValues in a #ChristianNation  https:\/\/t.co\/AcpJmULMXD",
    "id" : 677647061999869954,
    "created_at" : "2015-12-18 00:30:24 +0000",
    "user" : {
      "name" : "Chuck Mo",
      "screen_name" : "TheChuckMo",
      "protected" : false,
      "id_str" : "14557247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371170308\/24db85375f0696c5fc7008a97c2a6f7c_normal.jpeg",
      "id" : 14557247,
      "verified" : false
    }
  },
  "id" : 677648919921303556,
  "created_at" : "2015-12-18 00:37:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Undine",
      "screen_name" : "HorribleSanity",
      "indices" : [ 3, 18 ],
      "id_str" : "356219597",
      "id" : 356219597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/FtQxjicpUg",
      "expanded_url" : "http:\/\/tnw.to\/d4l7Q",
      "display_url" : "tnw.to\/d4l7Q"
    } ]
  },
  "geo" : { },
  "id_str" : "677630599264366593",
  "text" : "RT @HorribleSanity: I don't think I've ever seen a better example of a cure being worse than the disease. https:\/\/t.co\/FtQxjicpUg via @then\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Next Web \uD83D\uDCF1\uD83D\uDCBB\uD83C\uDF0D",
        "screen_name" : "TheNextWeb",
        "indices" : [ 114, 125 ],
        "id_str" : "10876852",
        "id" : 10876852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/FtQxjicpUg",
        "expanded_url" : "http:\/\/tnw.to\/d4l7Q",
        "display_url" : "tnw.to\/d4l7Q"
      } ]
    },
    "geo" : { },
    "id_str" : "677623714490511364",
    "text" : "I don't think I've ever seen a better example of a cure being worse than the disease. https:\/\/t.co\/FtQxjicpUg via @thenextweb",
    "id" : 677623714490511364,
    "created_at" : "2015-12-17 22:57:37 +0000",
    "user" : {
      "name" : "Undine",
      "screen_name" : "HorribleSanity",
      "protected" : false,
      "id_str" : "356219597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549284892769386496\/AMSg4NFM_normal.jpeg",
      "id" : 356219597,
      "verified" : false
    }
  },
  "id" : 677630599264366593,
  "created_at" : "2015-12-17 23:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/soXt0Of6Je",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2856",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677623269189660672",
  "text" : "2 parts to EEG test.. rest then 1) deep breathing for 3 min, rest then 2) 9 ten sec strobe flashes in face. (from https:\/\/t.co\/soXt0Of6Je)",
  "id" : 677623269189660672,
  "created_at" : "2015-12-17 22:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Og4nPuMx3S",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2855",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677622542929166336",
  "text" : "DD had EEG today. it exhausted her. she washed hair and went back to bed. (from https:\/\/t.co\/Og4nPuMx3S)",
  "id" : 677622542929166336,
  "created_at" : "2015-12-17 22:52:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/lNbksERjvL",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2791?discuss",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677622180449009664",
  "text" : "(re: https:\/\/t.co\/lNbksERjvL) she's only 20.. but also she doesnt remember 8th grade o\/n trip, taking karate class for 1 year.. things tha\u2026",
  "id" : 677622180449009664,
  "created_at" : "2015-12-17 22:51:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677614701048565760",
  "geo" : { },
  "id_str" : "677616663056031744",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time googled \"connor mckenna facebook regressive left\" :D ...and I'm magical! lol",
  "id" : 677616663056031744,
  "in_reply_to_status_id" : 677614701048565760,
  "created_at" : "2015-12-17 22:29:36 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/v44KOvFZnu",
      "expanded_url" : "https:\/\/www.facebook.com\/notes\/connor-mckenna\/the-regressive-shuffle\/10153794683593627?_rdr=p",
      "display_url" : "facebook.com\/notes\/connor-m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "677601493969580032",
  "geo" : { },
  "id_str" : "677613722051944448",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time this it? https:\/\/t.co\/v44KOvFZnu",
  "id" : 677613722051944448,
  "in_reply_to_status_id" : 677601493969580032,
  "created_at" : "2015-12-17 22:17:55 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 57, 62 ]
    }, {
      "text" : "feedly",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/cOLEJaaKDy",
      "expanded_url" : "http:\/\/scripting.com\/liveblog\/users\/davewiner\/2015\/12\/17\/0661.html",
      "display_url" : "scripting.com\/liveblog\/users\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677594059729469443",
  "text" : "Re Trump's plan to kill families https:\/\/t.co\/cOLEJaaKDy #tech #feedly",
  "id" : 677594059729469443,
  "created_at" : "2015-12-17 20:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677539976305901568",
  "text" : "i have no decent clothes. i look like crap. just got bleach on shirt and pants. F**K!",
  "id" : 677539976305901568,
  "created_at" : "2015-12-17 17:24:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youghourta Benali",
      "screen_name" : "djug",
      "indices" : [ 56, 61 ],
      "id_str" : "64828710",
      "id" : 64828710
    }, {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 65, 77 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    }, {
      "name" : "Smab",
      "screen_name" : "SmabAudio",
      "indices" : [ 102, 112 ],
      "id_str" : "556351761",
      "id" : 556351761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/810PpBwba9",
      "expanded_url" : "https:\/\/www.producthunt.com\/tech\/smab",
      "display_url" : "producthunt.com\/tech\/smab"
    } ]
  },
  "geo" : { },
  "id_str" : "677528508344717312",
  "text" : "SMAB: Add notes and bookmarks to your audio content via @djug on @ProductHunt https:\/\/t.co\/810PpBwba9 @smabaudio",
  "id" : 677528508344717312,
  "created_at" : "2015-12-17 16:39:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677522725997576192",
  "text" : "woohoo.. i made it. I can vote in Primary election.. got postcard in mail.",
  "id" : 677522725997576192,
  "created_at" : "2015-12-17 16:16:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "feedly",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/KF02fCnVoe",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/33efe2e778ce34\/44653?app_id=339",
      "display_url" : "producthunt.com\/r\/33efe2e778ce\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677520421911175168",
  "text" : "SMAB \u2014 Add notes and bookmarks to your audio content https:\/\/t.co\/KF02fCnVoe #tech #feedly",
  "id" : 677520421911175168,
  "created_at" : "2015-12-17 16:07:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/676954052102615040\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/elkH3JJjie",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWUGH6XWsAIAtQP.jpg",
      "id_str" : "676954051985190914",
      "id" : 676954051985190914,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWUGH6XWsAIAtQP.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 148
      }, {
        "h" : 148,
        "resize" : "crop",
        "w" : 148
      } ],
      "display_url" : "pic.twitter.com\/elkH3JJjie"
    } ],
    "hashtags" : [ {
      "text" : "FreeBook",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "WWII",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "Historical",
      "indices" : [ 82, 93 ]
    }, {
      "text" : "Military",
      "indices" : [ 94, 103 ]
    }, {
      "text" : "War",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/KPlhsH0YJJ",
      "expanded_url" : "http:\/\/bit.ly\/1Mg7Mdt",
      "display_url" : "bit.ly\/1Mg7Mdt"
    } ]
  },
  "geo" : { },
  "id_str" : "677507987360096256",
  "text" : "RT @BooksOnTheKnob: #FreeBook The Zero Hour Trilogy https:\/\/t.co\/KPlhsH0YJJ #WWII #Historical #Military #War https:\/\/t.co\/elkH3JJjie",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blog.booksontheknob.org\/\" rel=\"nofollow\"\u003EBooksOnTheKnob\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/676954052102615040\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/elkH3JJjie",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWUGH6XWsAIAtQP.jpg",
        "id_str" : "676954051985190914",
        "id" : 676954051985190914,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWUGH6XWsAIAtQP.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 148,
          "resize" : "crop",
          "w" : 148
        } ],
        "display_url" : "pic.twitter.com\/elkH3JJjie"
      } ],
      "hashtags" : [ {
        "text" : "FreeBook",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "WWII",
        "indices" : [ 56, 61 ]
      }, {
        "text" : "Historical",
        "indices" : [ 62, 73 ]
      }, {
        "text" : "Military",
        "indices" : [ 74, 83 ]
      }, {
        "text" : "War",
        "indices" : [ 84, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 55 ],
        "url" : "https:\/\/t.co\/KPlhsH0YJJ",
        "expanded_url" : "http:\/\/bit.ly\/1Mg7Mdt",
        "display_url" : "bit.ly\/1Mg7Mdt"
      } ]
    },
    "geo" : { },
    "id_str" : "676954052102615040",
    "text" : "#FreeBook The Zero Hour Trilogy https:\/\/t.co\/KPlhsH0YJJ #WWII #Historical #Military #War https:\/\/t.co\/elkH3JJjie",
    "id" : 676954052102615040,
    "created_at" : "2015-12-16 02:36:37 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 677507987360096256,
  "created_at" : "2015-12-17 15:17:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abi Reader",
      "screen_name" : "AbiReader",
      "indices" : [ 3, 13 ],
      "id_str" : "1227440088",
      "id" : 1227440088
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "12MoosOfChristmas",
      "indices" : [ 15, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677501089772650496",
  "text" : "RT @AbiReader: #12MoosOfChristmas On the 4th day of christmas their faces aglow, two little ones kissed under the mistletoe! https:\/\/t.co\/8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AbiReader\/status\/677389943480705024\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/8EmpYHN40i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWaSjOHWsAAZyWV.jpg",
        "id_str" : "677389927747858432",
        "id" : 677389927747858432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWaSjOHWsAAZyWV.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8EmpYHN40i"
      } ],
      "hashtags" : [ {
        "text" : "12MoosOfChristmas",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677389943480705024",
    "text" : "#12MoosOfChristmas On the 4th day of christmas their faces aglow, two little ones kissed under the mistletoe! https:\/\/t.co\/8EmpYHN40i",
    "id" : 677389943480705024,
    "created_at" : "2015-12-17 07:28:42 +0000",
    "user" : {
      "name" : "Abi Reader",
      "screen_name" : "AbiReader",
      "protected" : false,
      "id_str" : "1227440088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632430031659098112\/LHjg68y-_normal.png",
      "id" : 1227440088,
      "verified" : false
    }
  },
  "id" : 677501089772650496,
  "created_at" : "2015-12-17 14:50:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677285269616349185",
  "geo" : { },
  "id_str" : "677287289962278912",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe aww.. im sorry for kiddo : (",
  "id" : 677287289962278912,
  "in_reply_to_status_id" : 677285269616349185,
  "created_at" : "2015-12-17 00:40:47 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/677266677403402240\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/9MsOCuN53D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWYidDCWoAEgsHT.jpg",
      "id_str" : "677266676392566785",
      "id" : 677266676392566785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWYidDCWoAEgsHT.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9MsOCuN53D"
    } ],
    "hashtags" : [ {
      "text" : "weirdusb",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "whatisit",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677266677403402240",
  "text" : "A better view of #weirdusb thingy. Maybe up to 2 yrs old. #whatisit I don't know what to do with it. https:\/\/t.co\/9MsOCuN53D",
  "id" : 677266677403402240,
  "created_at" : "2015-12-16 23:18:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677260447238656001",
  "geo" : { },
  "id_str" : "677262372046639104",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time it looks like a usb but its got 2 \"teeth\" on the end to keep it from going into usb port.",
  "id" : 677262372046639104,
  "in_reply_to_status_id" : 677260447238656001,
  "created_at" : "2015-12-16 23:01:47 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Miller",
      "screen_name" : "DanFMillerArt",
      "indices" : [ 3, 17 ],
      "id_str" : "503484846",
      "id" : 503484846
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DanFMillerArt\/status\/676493680333598720\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/CtrPfUurQx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWNjZ5xUYAA-7rw.jpg",
      "id_str" : "676493665691262976",
      "id" : 676493665691262976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWNjZ5xUYAA-7rw.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/CtrPfUurQx"
    } ],
    "hashtags" : [ {
      "text" : "colorado",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "bird",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/2M1b3929cT",
      "expanded_url" : "http:\/\/fineartamerica.com\/featured\/mountain-bluebird-juvenile-dan-miller.html",
      "display_url" : "fineartamerica.com\/featured\/mount\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677261712911806464",
  "text" : "RT @DanFMillerArt: Mountain Bluebird Juvenile https:\/\/t.co\/2M1b3929cT #colorado #bird https:\/\/t.co\/CtrPfUurQx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DanFMillerArt\/status\/676493680333598720\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/CtrPfUurQx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWNjZ5xUYAA-7rw.jpg",
        "id_str" : "676493665691262976",
        "id" : 676493665691262976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWNjZ5xUYAA-7rw.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/CtrPfUurQx"
      } ],
      "hashtags" : [ {
        "text" : "colorado",
        "indices" : [ 51, 60 ]
      }, {
        "text" : "bird",
        "indices" : [ 61, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/2M1b3929cT",
        "expanded_url" : "http:\/\/fineartamerica.com\/featured\/mountain-bluebird-juvenile-dan-miller.html",
        "display_url" : "fineartamerica.com\/featured\/mount\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676493680333598720",
    "text" : "Mountain Bluebird Juvenile https:\/\/t.co\/2M1b3929cT #colorado #bird https:\/\/t.co\/CtrPfUurQx",
    "id" : 676493680333598720,
    "created_at" : "2015-12-14 20:07:16 +0000",
    "user" : {
      "name" : "Dan Miller",
      "screen_name" : "DanFMillerArt",
      "protected" : false,
      "id_str" : "503484846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781355086383415297\/D3SiXp_z_normal.jpg",
      "id" : 503484846,
      "verified" : false
    }
  },
  "id" : 677261712911806464,
  "created_at" : "2015-12-16 22:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "677226115023417344",
  "geo" : { },
  "id_str" : "677253751183417345",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides never.",
  "id" : 677253751183417345,
  "in_reply_to_status_id" : 677226115023417344,
  "created_at" : "2015-12-16 22:27:31 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/677252586253230080\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/bzESBG9eEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWYVo4gW4AAaiTn.jpg",
      "id_str" : "677252586072891392",
      "id" : 677252586072891392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWYVo4gW4AAaiTn.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bzESBG9eEx"
    } ],
    "hashtags" : [ {
      "text" : "weirdusb",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677252586253230080",
  "text" : "What is this? #weirdusb https:\/\/t.co\/bzESBG9eEx",
  "id" : 677252586253230080,
  "created_at" : "2015-12-16 22:22:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baratunde",
      "screen_name" : "baratunde",
      "indices" : [ 3, 13 ],
      "id_str" : "820585",
      "id" : 820585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/oi3wwfYfni",
      "expanded_url" : "http:\/\/worldwithouthate.org\/coming-from-peace-an-open-letter-to-donald-trump\/",
      "display_url" : "worldwithouthate.org\/coming-from-pe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677207101454860288",
  "text" : "RT @baratunde: An American muslim, nearly killed by a white supremacist after 9\/11 has words for Trump https:\/\/t.co\/oi3wwfYfni https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/baratunde\/status\/677180397990641664\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/IUprkJntMC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXT-8yWoAQB3yo.png",
        "id_str" : "677180397411803140",
        "id" : 677180397411803140,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXT-8yWoAQB3yo.png",
        "sizes" : [ {
          "h" : 273,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 269,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 610
        } ],
        "display_url" : "pic.twitter.com\/IUprkJntMC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/oi3wwfYfni",
        "expanded_url" : "http:\/\/worldwithouthate.org\/coming-from-peace-an-open-letter-to-donald-trump\/",
        "display_url" : "worldwithouthate.org\/coming-from-pe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677180397990641664",
    "text" : "An American muslim, nearly killed by a white supremacist after 9\/11 has words for Trump https:\/\/t.co\/oi3wwfYfni https:\/\/t.co\/IUprkJntMC",
    "id" : 677180397990641664,
    "created_at" : "2015-12-16 17:36:02 +0000",
    "user" : {
      "name" : "Baratunde",
      "screen_name" : "baratunde",
      "protected" : false,
      "id_str" : "820585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636925930686930944\/NEjicosS_normal.jpg",
      "id" : 820585,
      "verified" : true
    }
  },
  "id" : 677207101454860288,
  "created_at" : "2015-12-16 19:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Lo7osAmP7f",
      "expanded_url" : "http:\/\/scottbrick.net\/article\/how_to_break_into_narration",
      "display_url" : "scottbrick.net\/article\/how_to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677184090311929856",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time came across this and thought of you &gt; https:\/\/t.co\/Lo7osAmP7f",
  "id" : 677184090311929856,
  "created_at" : "2015-12-16 17:50:43 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2661 \u02D8\uFE36\u02D8 \u2661",
      "screen_name" : "thinkbri",
      "indices" : [ 3, 12 ],
      "id_str" : "342518767",
      "id" : 342518767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677182610343387136",
  "text" : "RT @thinkbri: a man took the audio of the media's commentary of BLACK PROTESTORS and put it over a video of white rioters. http:\/\/t.co\/AgK1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thinkbri\/status\/613430475844100096\/video\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/AgK1qz6WKj",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/613430225100148736\/pu\/img\/7X_tWn44wfNGjO2L.jpg",
        "id_str" : "613430225100148736",
        "id" : 613430225100148736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/613430225100148736\/pu\/img\/7X_tWn44wfNGjO2L.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 426
        } ],
        "display_url" : "pic.twitter.com\/AgK1qz6WKj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613430475844100096",
    "text" : "a man took the audio of the media's commentary of BLACK PROTESTORS and put it over a video of white rioters. http:\/\/t.co\/AgK1qz6WKj",
    "id" : 613430475844100096,
    "created_at" : "2015-06-23 19:36:37 +0000",
    "user" : {
      "name" : "\u2661 \u02D8\uFE36\u02D8 \u2661",
      "screen_name" : "thinkbri",
      "protected" : false,
      "id_str" : "342518767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796486571750989824\/CQb2gZWa_normal.jpg",
      "id" : 342518767,
      "verified" : false
    }
  },
  "id" : 677182610343387136,
  "created_at" : "2015-12-16 17:44:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "indices" : [ 3, 15 ],
      "id_str" : "321774180",
      "id" : 321774180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677178168470601728",
  "text" : "RT @ChrisJZullo: What I hear on this stage is Anger, Anger, Anger. WAR, WAR, WAR. Debt, Debt, Debt. Fear, Fear, Fear. This isn't the path t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676971680556843008",
    "text" : "What I hear on this stage is Anger, Anger, Anger. WAR, WAR, WAR. Debt, Debt, Debt. Fear, Fear, Fear. This isn't the path to peace #GOPDebate",
    "id" : 676971680556843008,
    "created_at" : "2015-12-16 03:46:40 +0000",
    "user" : {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "protected" : false,
      "id_str" : "321774180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614520488266727424\/MJBPfrGG_normal.jpg",
      "id" : 321774180,
      "verified" : false
    }
  },
  "id" : 677178168470601728,
  "created_at" : "2015-12-16 17:27:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "indices" : [ 3, 15 ],
      "id_str" : "321774180",
      "id" : 321774180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677178115991449600",
  "text" : "RT @ChrisJZullo: Thank God #GOPDebate is over. How are you supposed to feel safe and secure after listening to all that. Wait, that's the p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 10, 20 ]
      }, {
        "text" : "GOPDebate",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676977059164504064",
    "text" : "Thank God #GOPDebate is over. How are you supposed to feel safe and secure after listening to all that. Wait, that's the point #GOPDebate",
    "id" : 676977059164504064,
    "created_at" : "2015-12-16 04:08:03 +0000",
    "user" : {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "protected" : false,
      "id_str" : "321774180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614520488266727424\/MJBPfrGG_normal.jpg",
      "id" : 321774180,
      "verified" : false
    }
  },
  "id" : 677178115991449600,
  "created_at" : "2015-12-16 17:26:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 47, 52 ]
    }, {
      "text" : "feedly",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/hJfOjxq7WZ",
      "expanded_url" : "http:\/\/scripting.com\/liveblog\/users\/davewiner\/2015\/12\/16\/0649.html",
      "display_url" : "scripting.com\/liveblog\/users\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677133808089481216",
  "text" : "Send marijuana to ISIS https:\/\/t.co\/hJfOjxq7WZ #tech #feedly",
  "id" : 677133808089481216,
  "created_at" : "2015-12-16 14:30:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/676842492411691009\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/m0xiqVyg4T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWSgqSFXAAApCAa.jpg",
      "id_str" : "676842492281683968",
      "id" : 676842492281683968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWSgqSFXAAApCAa.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 225
      } ],
      "display_url" : "pic.twitter.com\/m0xiqVyg4T"
    } ],
    "hashtags" : [ {
      "text" : "tablets",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/AGxtaPZ7cU",
      "expanded_url" : "http:\/\/bit.ly\/1Mfrmqa",
      "display_url" : "bit.ly\/1Mfrmqa"
    } ]
  },
  "geo" : { },
  "id_str" : "676933248845520898",
  "text" : "RT @BooksOnTheKnob: Mini-Tablet\/Camera\/MP3 Player under $12 https:\/\/t.co\/AGxtaPZ7cU #tablets https:\/\/t.co\/m0xiqVyg4T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blog.booksontheknob.org\/\" rel=\"nofollow\"\u003EBooksOnTheKnob\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/676842492411691009\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/m0xiqVyg4T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWSgqSFXAAApCAa.jpg",
        "id_str" : "676842492281683968",
        "id" : 676842492281683968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWSgqSFXAAApCAa.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 225
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 225
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 225
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 225
        } ],
        "display_url" : "pic.twitter.com\/m0xiqVyg4T"
      } ],
      "hashtags" : [ {
        "text" : "tablets",
        "indices" : [ 64, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/AGxtaPZ7cU",
        "expanded_url" : "http:\/\/bit.ly\/1Mfrmqa",
        "display_url" : "bit.ly\/1Mfrmqa"
      } ]
    },
    "geo" : { },
    "id_str" : "676842492411691009",
    "text" : "Mini-Tablet\/Camera\/MP3 Player under $12 https:\/\/t.co\/AGxtaPZ7cU #tablets https:\/\/t.co\/m0xiqVyg4T",
    "id" : 676842492411691009,
    "created_at" : "2015-12-15 19:13:19 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 676933248845520898,
  "created_at" : "2015-12-16 01:13:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "indices" : [ 3, 15 ],
      "id_str" : "321774180",
      "id" : 321774180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676926952348000257",
  "text" : "RT @ChrisJZullo: Not exactly sure why they call this a #GOPDebate. I don't hear any substantive thoughts other than fear-mongering by red h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 38, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676923815251832833",
    "text" : "Not exactly sure why they call this a #GOPDebate. I don't hear any substantive thoughts other than fear-mongering by red herrings for votes",
    "id" : 676923815251832833,
    "created_at" : "2015-12-16 00:36:28 +0000",
    "user" : {
      "name" : "\u267B\uFE0F Christopher Zullo",
      "screen_name" : "ChrisJZullo",
      "protected" : false,
      "id_str" : "321774180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614520488266727424\/MJBPfrGG_normal.jpg",
      "id" : 321774180,
      "verified" : false
    }
  },
  "id" : 676926952348000257,
  "created_at" : "2015-12-16 00:48:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676926573350690817",
  "text" : "RT @Lesism: If you have a 'mental health history', GPs treat you like naughty children. They don't allow you to make your own decisions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676926175688695808",
    "text" : "If you have a 'mental health history', GPs treat you like naughty children. They don't allow you to make your own decisions.",
    "id" : 676926175688695808,
    "created_at" : "2015-12-16 00:45:51 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 676926573350690817,
  "created_at" : "2015-12-16 00:47:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676925841650094080",
  "text" : "RT @Lesism: It was the most patronising, dismissive and false 'Aw' I'd ever heard. I was going to tell her, but what was the point?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676925397544628224",
    "text" : "It was the most patronising, dismissive and false 'Aw' I'd ever heard. I was going to tell her, but what was the point?",
    "id" : 676925397544628224,
    "created_at" : "2015-12-16 00:42:46 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 676925841650094080,
  "created_at" : "2015-12-16 00:44:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676925790022467584",
  "text" : "RT @Lesism: When I said to my GP that I needed help, and maybe Christmas was part of the hurt, she said :'Aw...'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676925204027846656",
    "text" : "When I said to my GP that I needed help, and maybe Christmas was part of the hurt, she said :'Aw...'",
    "id" : 676925204027846656,
    "created_at" : "2015-12-16 00:41:59 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 676925790022467584,
  "created_at" : "2015-12-16 00:44:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Nemo",
      "screen_name" : "mr_modular",
      "indices" : [ 3, 14 ],
      "id_str" : "3075601",
      "id" : 3075601
    }, {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 84, 94 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/4ZEB0KtlZX",
      "expanded_url" : "http:\/\/www.vox.com\/business-and-finance\/2015\/12\/15\/10126144\/serial-podcast-huge-hit?utm_campaign=vox&utm_content=article%3Atop&utm_medium=social&utm_source=twitter",
      "display_url" : "vox.com\/business-and-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676925116677271553",
  "text" : "RT @mr_modular: Podcasting is getting huge. Here's why. https:\/\/t.co\/4ZEB0KtlZX via @voxdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vox",
        "screen_name" : "voxdotcom",
        "indices" : [ 68, 78 ],
        "id_str" : "2347049341",
        "id" : 2347049341
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/4ZEB0KtlZX",
        "expanded_url" : "http:\/\/www.vox.com\/business-and-finance\/2015\/12\/15\/10126144\/serial-podcast-huge-hit?utm_campaign=vox&utm_content=article%3Atop&utm_medium=social&utm_source=twitter",
        "display_url" : "vox.com\/business-and-f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676921720838758402",
    "text" : "Podcasting is getting huge. Here's why. https:\/\/t.co\/4ZEB0KtlZX via @voxdotcom",
    "id" : 676921720838758402,
    "created_at" : "2015-12-16 00:28:09 +0000",
    "user" : {
      "name" : "Allen Nemo",
      "screen_name" : "mr_modular",
      "protected" : false,
      "id_str" : "3075601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1222439597\/74218_10100386005613530_7910885_66100595_6660556_n_normal.jpg",
      "id" : 3075601,
      "verified" : false
    }
  },
  "id" : 676925116677271553,
  "created_at" : "2015-12-16 00:41:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel ennis",
      "screen_name" : "Hrothgar777",
      "indices" : [ 0, 12 ],
      "id_str" : "279783538",
      "id" : 279783538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676797847245873152",
  "geo" : { },
  "id_str" : "676802278565748740",
  "in_reply_to_user_id" : 279783538,
  "text" : "@Hrothgar777 breathe...",
  "id" : 676802278565748740,
  "in_reply_to_status_id" : 676797847245873152,
  "created_at" : "2015-12-15 16:33:32 +0000",
  "in_reply_to_screen_name" : "Hrothgar777",
  "in_reply_to_user_id_str" : "279783538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676799485570236416",
  "geo" : { },
  "id_str" : "676801614393511936",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks just started w Serial (S2E1) waiting for E2! .. Ask Science Mike (science\/spirituality)",
  "id" : 676801614393511936,
  "in_reply_to_status_id" : 676799485570236416,
  "created_at" : "2015-12-15 16:30:53 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676779002099572738",
  "text" : "really getting into audiobooks now. listening to Love May Fail last night .. giggling out loud! thinking about wireless headphones.",
  "id" : 676779002099572738,
  "created_at" : "2015-12-15 15:01:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676778013275594752",
  "text" : "RT @dhammagirl: Checking the \"To Do List\" for today...\n\nDo No Harm\nBe Kind\nSmile\nListen\nBe Generous\nLove\nBe Courteous\nMeditate\nBe Grateful\n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676747187515203584",
    "text" : "Checking the \"To Do List\" for today...\n\nDo No Harm\nBe Kind\nSmile\nListen\nBe Generous\nLove\nBe Courteous\nMeditate\nBe Grateful\nExpand the heart",
    "id" : 676747187515203584,
    "created_at" : "2015-12-15 12:54:37 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 676778013275594752,
  "created_at" : "2015-12-15 14:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wisdomalive",
      "screen_name" : "wisdomalive",
      "indices" : [ 3, 15 ],
      "id_str" : "88444336",
      "id" : 88444336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "attitude",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676777487356006401",
  "text" : "RT @wisdomalive: Approach experiences with the #attitude of \"learning from\" rather than with the judgmental mindset of \"agreeing with.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "attitude",
        "indices" : [ 30, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676745116481122304",
    "text" : "Approach experiences with the #attitude of \"learning from\" rather than with the judgmental mindset of \"agreeing with.\"",
    "id" : 676745116481122304,
    "created_at" : "2015-12-15 12:46:23 +0000",
    "user" : {
      "name" : "Wisdomalive",
      "screen_name" : "wisdomalive",
      "protected" : false,
      "id_str" : "88444336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694343116\/wisdom_green_sign.jpeg_normal.jpg",
      "id" : 88444336,
      "verified" : false
    }
  },
  "id" : 676777487356006401,
  "created_at" : "2015-12-15 14:55:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676609704638967809",
  "text" : "Listening to some brain entrainment.",
  "id" : 676609704638967809,
  "created_at" : "2015-12-15 03:48:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "indices" : [ 3, 17 ],
      "id_str" : "2977412266",
      "id" : 2977412266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/farmingmadire\/status\/676550081299021824\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/DFxlJgMvyR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWOWs_vWsAATk2f.jpg",
      "id_str" : "676550068804169728",
      "id" : 676550068804169728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWOWs_vWsAATk2f.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/DFxlJgMvyR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676607760725909504",
  "text" : "RT @farmingmadire: Motherly love \u2764\uFE0F\u2764\uFE0F\u2764\uFE0F https:\/\/t.co\/DFxlJgMvyR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/farmingmadire\/status\/676550081299021824\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/DFxlJgMvyR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWOWs_vWsAATk2f.jpg",
        "id_str" : "676550068804169728",
        "id" : 676550068804169728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWOWs_vWsAATk2f.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/DFxlJgMvyR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676550081299021824",
    "text" : "Motherly love \u2764\uFE0F\u2764\uFE0F\u2764\uFE0F https:\/\/t.co\/DFxlJgMvyR",
    "id" : 676550081299021824,
    "created_at" : "2015-12-14 23:51:23 +0000",
    "user" : {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "protected" : false,
      "id_str" : "2977412266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723980308874420224\/USPqubG3_normal.jpg",
      "id" : 2977412266,
      "verified" : false
    }
  },
  "id" : 676607760725909504,
  "created_at" : "2015-12-15 03:40:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/676565427946979328\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/aIaBg0hIjh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWOkq22XAAAD-dO.png",
      "id_str" : "676565425220681728",
      "id" : 676565425220681728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWOkq22XAAAD-dO.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aIaBg0hIjh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/RcPLgu3hc7",
      "expanded_url" : "http:\/\/thebean10.blogspot.com\/p\/feed-cat-for-christmas.html?_ts=1450140740",
      "display_url" : "thebean10.blogspot.com\/p\/feed-cat-for\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676565427946979328",
  "text" : "Feed a Cat for Christmas https:\/\/t.co\/RcPLgu3hc7 https:\/\/t.co\/aIaBg0hIjh",
  "id" : 676565427946979328,
  "created_at" : "2015-12-15 00:52:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/676562992620785664\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/aqMjrvH6xU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWOidEVWsAAD_Tr.jpg",
      "id_str" : "676562989298921472",
      "id" : 676562989298921472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWOidEVWsAAD_Tr.jpg",
      "sizes" : [ {
        "h" : 291,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/aqMjrvH6xU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/xYSQ5SYUqZ",
      "expanded_url" : "http:\/\/thebloggess.com\/2015\/12\/the-sixth-annual-james-garfield-miracle\/?_ts=1450140157#comment-919725",
      "display_url" : "thebloggess.com\/2015\/12\/the-si\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676562992620785664",
  "text" : "The Sixth Annual James Garfield Miracle https:\/\/t.co\/xYSQ5SYUqZ https:\/\/t.co\/aqMjrvH6xU",
  "id" : 676562992620785664,
  "created_at" : "2015-12-15 00:42:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 3, 13 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xANxxcwNPz",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/12\/14\/nyregion\/clinton-correctional-facility-inmate-brutality.html?_r=1",
      "display_url" : "nytimes.com\/2015\/12\/14\/nyr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676482879589871617",
  "text" : "RT @ShaunKing: NY Times exposes how prisoners in New York are being killed at will by guards - with no punishment. \n\nhttps:\/\/t.co\/xANxxcwNPz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/xANxxcwNPz",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/12\/14\/nyregion\/clinton-correctional-facility-inmate-brutality.html?_r=1",
        "display_url" : "nytimes.com\/2015\/12\/14\/nyr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676481459574697986",
    "text" : "NY Times exposes how prisoners in New York are being killed at will by guards - with no punishment. \n\nhttps:\/\/t.co\/xANxxcwNPz",
    "id" : 676481459574697986,
    "created_at" : "2015-12-14 19:18:43 +0000",
    "user" : {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "protected" : false,
      "id_str" : "755113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690138574050705408\/HkB9XCu4_normal.jpg",
      "id" : 755113,
      "verified" : true
    }
  },
  "id" : 676482879589871617,
  "created_at" : "2015-12-14 19:24:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/676426186927525888\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ogtnZtVr2J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWMmB96W4AAyBCX.jpg",
      "id_str" : "676426184276762624",
      "id" : 676426184276762624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWMmB96W4AAyBCX.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 532
      } ],
      "display_url" : "pic.twitter.com\/ogtnZtVr2J"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/wdGvui5Zqj",
      "expanded_url" : "http:\/\/www.flyinginthespirit.cuttys.net\/2015\/12\/14\/aspergic-christian\/?_ts=1450107543",
      "display_url" : "flyinginthespirit.cuttys.net\/2015\/12\/14\/asp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676426186927525888",
  "text" : "The Aspergic Christian | Flying in the Spirit https:\/\/t.co\/wdGvui5Zqj https:\/\/t.co\/ogtnZtVr2J",
  "id" : 676426186927525888,
  "created_at" : "2015-12-14 15:39:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eReaderIQ",
      "screen_name" : "eReaderIQ",
      "indices" : [ 23, 33 ],
      "id_str" : "153435359",
      "id" : 153435359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676419387780370432",
  "text" : "we need something like @eReaderIQ for #audiobooks",
  "id" : 676419387780370432,
  "created_at" : "2015-12-14 15:12:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676269686175211520",
  "text" : "Finished \"The Whistlers\" #audiobook from No Sleep Podcast. Excellent. Suspenseful.",
  "id" : 676269686175211520,
  "created_at" : "2015-12-14 05:17:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tantor Audio",
      "screen_name" : "TantorAudio",
      "indices" : [ 3, 15 ],
      "id_str" : "36229151",
      "id" : 36229151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TantorAudio\/status\/676103254086959104\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/TzUomPMUUg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWIAU8DXAAACKuW.jpg",
      "id_str" : "676103253776596992",
      "id" : 676103253776596992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWIAU8DXAAACKuW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TzUomPMUUg"
    } ],
    "hashtags" : [ {
      "text" : "12DaysofGiveaways",
      "indices" : [ 30, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/tmNUtrOlLX",
      "expanded_url" : "http:\/\/on.fb.me\/1KRB3zR",
      "display_url" : "on.fb.me\/1KRB3zR"
    } ]
  },
  "geo" : { },
  "id_str" : "676223700723744769",
  "text" : "RT @TantorAudio: Day 1 of the #12DaysofGiveaways is happening now on our Facebook page! https:\/\/t.co\/tmNUtrOlLX https:\/\/t.co\/TzUomPMUUg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TantorAudio\/status\/676103254086959104\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/TzUomPMUUg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWIAU8DXAAACKuW.jpg",
        "id_str" : "676103253776596992",
        "id" : 676103253776596992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWIAU8DXAAACKuW.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TzUomPMUUg"
      } ],
      "hashtags" : [ {
        "text" : "12DaysofGiveaways",
        "indices" : [ 13, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/tmNUtrOlLX",
        "expanded_url" : "http:\/\/on.fb.me\/1KRB3zR",
        "display_url" : "on.fb.me\/1KRB3zR"
      } ]
    },
    "geo" : { },
    "id_str" : "676103254086959104",
    "text" : "Day 1 of the #12DaysofGiveaways is happening now on our Facebook page! https:\/\/t.co\/tmNUtrOlLX https:\/\/t.co\/TzUomPMUUg",
    "id" : 676103254086959104,
    "created_at" : "2015-12-13 18:15:51 +0000",
    "user" : {
      "name" : "Tantor Audio",
      "screen_name" : "TantorAudio",
      "protected" : false,
      "id_str" : "36229151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2364777444\/b78ebmeq2b2b5vx8uvwd_normal.png",
      "id" : 36229151,
      "verified" : false
    }
  },
  "id" : 676223700723744769,
  "created_at" : "2015-12-14 02:14:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676163813486538753",
  "text" : "RT @ZachsMind: We had this argument with Roe v Wade back when i was a baby. WHY are we right back here? We are DEvolving!  https:\/\/t.co\/3nD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/3nDEbfns2Y",
        "expanded_url" : "https:\/\/twitter.com\/Pro_Mov_\/status\/676148793369214980",
        "display_url" : "twitter.com\/Pro_Mov_\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676158213188923396",
    "text" : "We had this argument with Roe v Wade back when i was a baby. WHY are we right back here? We are DEvolving!  https:\/\/t.co\/3nDEbfns2Y",
    "id" : 676158213188923396,
    "created_at" : "2015-12-13 21:54:15 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 676163813486538753,
  "created_at" : "2015-12-13 22:16:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 0, 16 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/09nbYcCt3y",
      "expanded_url" : "http:\/\/www.portlandtx.com\/index.aspx?NID=199",
      "display_url" : "portlandtx.com\/index.aspx?NID\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "676157353394372612",
  "in_reply_to_user_id" : 111579405,
  "text" : "@thDigitalReader did you know you're linked here? https:\/\/t.co\/09nbYcCt3y cool beans!",
  "id" : 676157353394372612,
  "created_at" : "2015-12-13 21:50:50 +0000",
  "in_reply_to_screen_name" : "thDigitalReader",
  "in_reply_to_user_id_str" : "111579405",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kylie Riordan \u262E \u2764",
      "screen_name" : "mindfulheal",
      "indices" : [ 3, 15 ],
      "id_str" : "278975121",
      "id" : 278975121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676107236356288512",
  "text" : "RT @mindfulheal: We are all a part of the same living universe. What we say, think, feel and do affects every single one of us. Be mindful \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675553782088908800",
    "text" : "We are all a part of the same living universe. What we say, think, feel and do affects every single one of us. Be mindful to choose #love.",
    "id" : 675553782088908800,
    "created_at" : "2015-12-12 05:52:27 +0000",
    "user" : {
      "name" : "Kylie Riordan \u262E \u2764",
      "screen_name" : "mindfulheal",
      "protected" : false,
      "id_str" : "278975121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768228246097793026\/eXnIQar3_normal.jpg",
      "id" : 278975121,
      "verified" : false
    }
  },
  "id" : 676107236356288512,
  "created_at" : "2015-12-13 18:31:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "676103288358576130",
  "geo" : { },
  "id_str" : "676106185200820224",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre yup...",
  "id" : 676106185200820224,
  "in_reply_to_status_id" : 676103288358576130,
  "created_at" : "2015-12-13 18:27:30 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/675882892745117696\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/v5J7tOU821",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWE36O2WEAExfRF.jpg",
      "id_str" : "675882892640260097",
      "id" : 675882892640260097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWE36O2WEAExfRF.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 180
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 180
      } ],
      "display_url" : "pic.twitter.com\/v5J7tOU821"
    } ],
    "hashtags" : [ {
      "text" : "FreeBook",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "Medicine",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "Science",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/FEn2v1ATVl",
      "expanded_url" : "http:\/\/bit.ly\/1lEZo2m",
      "display_url" : "bit.ly\/1lEZo2m"
    } ]
  },
  "geo" : { },
  "id_str" : "676075113901596672",
  "text" : "RT @BooksOnTheKnob: #FreeBook The Hostage Brain https:\/\/t.co\/FEn2v1ATVl #Medicine #Science https:\/\/t.co\/v5J7tOU821",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blog.booksontheknob.org\/\" rel=\"nofollow\"\u003EBooksOnTheKnob\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/675882892745117696\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/v5J7tOU821",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWE36O2WEAExfRF.jpg",
        "id_str" : "675882892640260097",
        "id" : 675882892640260097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWE36O2WEAExfRF.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 180
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 180
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 180
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 180
        } ],
        "display_url" : "pic.twitter.com\/v5J7tOU821"
      } ],
      "hashtags" : [ {
        "text" : "FreeBook",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "Medicine",
        "indices" : [ 52, 61 ]
      }, {
        "text" : "Science",
        "indices" : [ 62, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/FEn2v1ATVl",
        "expanded_url" : "http:\/\/bit.ly\/1lEZo2m",
        "display_url" : "bit.ly\/1lEZo2m"
      } ]
    },
    "geo" : { },
    "id_str" : "675882892745117696",
    "text" : "#FreeBook The Hostage Brain https:\/\/t.co\/FEn2v1ATVl #Medicine #Science https:\/\/t.co\/v5J7tOU821",
    "id" : 675882892745117696,
    "created_at" : "2015-12-13 03:40:13 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 676075113901596672,
  "created_at" : "2015-12-13 16:24:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 3, 18 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/675525823051509760\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/zB2AJY2SSY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV_zKCDWUAA_yWm.jpg",
      "id_str" : "675525822804021248",
      "id" : 675525822804021248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV_zKCDWUAA_yWm.jpg",
      "sizes" : [ {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com\/zB2AJY2SSY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/CCFp561Oi1",
      "expanded_url" : "http:\/\/bit.ly\/1NLNy0E",
      "display_url" : "bit.ly\/1NLNy0E"
    } ]
  },
  "geo" : { },
  "id_str" : "676074945529708547",
  "text" : "RT @BooksOnTheKnob: Free $5 Amazon Credit https:\/\/t.co\/CCFp561Oi1 https:\/\/t.co\/zB2AJY2SSY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blog.booksontheknob.org\/\" rel=\"nofollow\"\u003EBooksOnTheKnob\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BooksOnTheKnob\/status\/675525823051509760\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/zB2AJY2SSY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV_zKCDWUAA_yWm.jpg",
        "id_str" : "675525822804021248",
        "id" : 675525822804021248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV_zKCDWUAA_yWm.jpg",
        "sizes" : [ {
          "h" : 160,
          "resize" : "fit",
          "w" : 160
        }, {
          "h" : 160,
          "resize" : "fit",
          "w" : 160
        }, {
          "h" : 160,
          "resize" : "fit",
          "w" : 160
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 160,
          "resize" : "fit",
          "w" : 160
        } ],
        "display_url" : "pic.twitter.com\/zB2AJY2SSY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/CCFp561Oi1",
        "expanded_url" : "http:\/\/bit.ly\/1NLNy0E",
        "display_url" : "bit.ly\/1NLNy0E"
      } ]
    },
    "geo" : { },
    "id_str" : "675525823051509760",
    "text" : "Free $5 Amazon Credit https:\/\/t.co\/CCFp561Oi1 https:\/\/t.co\/zB2AJY2SSY",
    "id" : 675525823051509760,
    "created_at" : "2015-12-12 04:01:21 +0000",
    "user" : {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "protected" : false,
      "id_str" : "29451040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523432404\/51ML1U9bmTL._SL500_AA252_PIkin2_1__normal.jpg",
      "id" : 29451040,
      "verified" : false
    }
  },
  "id" : 676074945529708547,
  "created_at" : "2015-12-13 16:23:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "indices" : [ 3, 16 ],
      "id_str" : "2423532173",
      "id" : 2423532173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/675449257806143488\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/cH8sqgTERh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV-tf48WsAA8ySi.jpg",
      "id_str" : "675449232501944320",
      "id" : 675449232501944320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV-tf48WsAA8ySi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 950
      } ],
      "display_url" : "pic.twitter.com\/cH8sqgTERh"
    } ],
    "hashtags" : [ {
      "text" : "highlandbullcalf",
      "indices" : [ 29, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675464886659506177",
  "text" : "RT @Maolfarmiona: You rang?? #highlandbullcalf https:\/\/t.co\/cH8sqgTERh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/675449257806143488\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/cH8sqgTERh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV-tf48WsAA8ySi.jpg",
        "id_str" : "675449232501944320",
        "id" : 675449232501944320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV-tf48WsAA8ySi.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 950
        } ],
        "display_url" : "pic.twitter.com\/cH8sqgTERh"
      } ],
      "hashtags" : [ {
        "text" : "highlandbullcalf",
        "indices" : [ 11, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675449257806143488",
    "text" : "You rang?? #highlandbullcalf https:\/\/t.co\/cH8sqgTERh",
    "id" : 675449257806143488,
    "created_at" : "2015-12-11 22:57:06 +0000",
    "user" : {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "protected" : false,
      "id_str" : "2423532173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798860009874472961\/v5GADWSz_normal.jpg",
      "id" : 2423532173,
      "verified" : false
    }
  },
  "id" : 675464886659506177,
  "created_at" : "2015-12-11 23:59:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/1nyd4Bp4ay",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2789",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675444150829842432",
  "text" : "neuro said could be related to #hashimotos .. (from https:\/\/t.co\/1nyd4Bp4ay)",
  "id" : 675444150829842432,
  "created_at" : "2015-12-11 22:36:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Vb7oBmVuKy",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2788",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675443872357474304",
  "text" : "soo.. my DD 20yo basically doesn't remember 6th-8th grade years. is that weird?? (she started noticing memory loss\u2026 https:\/\/t.co\/Vb7oBmVuKy",
  "id" : 675443872357474304,
  "created_at" : "2015-12-11 22:35:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "indices" : [ 3, 15 ],
      "id_str" : "21833728",
      "id" : 21833728
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Brasilmagic\/status\/675315680107999232\/photo\/1",
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/cN9WMgSy3s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV80CHHXIAA0xIW.jpg",
      "id_str" : "675315680003170304",
      "id" : 675315680003170304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV80CHHXIAA0xIW.jpg",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 444
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 444
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 444
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cN9WMgSy3s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675428298206412800",
  "text" : "RT @Brasilmagic: Cool thought https:\/\/t.co\/cN9WMgSy3s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Brasilmagic\/status\/675315680107999232\/photo\/1",
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/cN9WMgSy3s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV80CHHXIAA0xIW.jpg",
        "id_str" : "675315680003170304",
        "id" : 675315680003170304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV80CHHXIAA0xIW.jpg",
        "sizes" : [ {
          "h" : 241,
          "resize" : "fit",
          "w" : 444
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 444
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 444
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/cN9WMgSy3s"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675315680107999232",
    "text" : "Cool thought https:\/\/t.co\/cN9WMgSy3s",
    "id" : 675315680107999232,
    "created_at" : "2015-12-11 14:06:19 +0000",
    "user" : {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "protected" : false,
      "id_str" : "21833728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789894919787679744\/CXf0r3bi_normal.jpg",
      "id" : 21833728,
      "verified" : false
    }
  },
  "id" : 675428298206412800,
  "created_at" : "2015-12-11 21:33:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "indices" : [ 3, 15 ],
      "id_str" : "21833728",
      "id" : 21833728
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Brasilmagic\/status\/675315977278627840\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/j28VNiRrke",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV80TZ9WsAAByLm.jpg",
      "id_str" : "675315977119248384",
      "id" : 675315977119248384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV80TZ9WsAAByLm.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/j28VNiRrke"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675427980248793088",
  "text" : "RT @Brasilmagic: Hey anti-choicers (\"pro-lifers\"), this might very well happen.... https:\/\/t.co\/j28VNiRrke",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Brasilmagic\/status\/675315977278627840\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/j28VNiRrke",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV80TZ9WsAAByLm.jpg",
        "id_str" : "675315977119248384",
        "id" : 675315977119248384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV80TZ9WsAAByLm.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/j28VNiRrke"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675315977278627840",
    "text" : "Hey anti-choicers (\"pro-lifers\"), this might very well happen.... https:\/\/t.co\/j28VNiRrke",
    "id" : 675315977278627840,
    "created_at" : "2015-12-11 14:07:30 +0000",
    "user" : {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "protected" : false,
      "id_str" : "21833728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789894919787679744\/CXf0r3bi_normal.jpg",
      "id" : 21833728,
      "verified" : false
    }
  },
  "id" : 675427980248793088,
  "created_at" : "2015-12-11 21:32:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "675353847749980160",
  "geo" : { },
  "id_str" : "675421323678625792",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater COOKIES!!!",
  "id" : 675421323678625792,
  "in_reply_to_status_id" : 675353847749980160,
  "created_at" : "2015-12-11 21:06:06 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 12, 16 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DanielHoltzclaw",
      "indices" : [ 48, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675149511757574144",
  "text" : "RT @deray: .@CNN, where is your coverage of the #DanielHoltzclaw verdict? Or do you require the threat of unrest for coverage?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 1, 5 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DanielHoltzclaw",
        "indices" : [ 37, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675145059638091776",
    "text" : ".@CNN, where is your coverage of the #DanielHoltzclaw verdict? Or do you require the threat of unrest for coverage?",
    "id" : 675145059638091776,
    "created_at" : "2015-12-11 02:48:20 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 675149511757574144,
  "created_at" : "2015-12-11 03:06:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kara [ Boho Berry ]",
      "screen_name" : "BohoBerry",
      "indices" : [ 5, 15 ],
      "id_str" : "3148883803",
      "id" : 3148883803
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BulletJournal",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/9DXbxKf9Qr",
      "expanded_url" : "http:\/\/www.bohoberry.com\/moleskine-vs-leuchtturm\/",
      "display_url" : "bohoberry.com\/moleskine-vs-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675128148632207361",
  "text" : "Kara @BohoBerry is giving away an epic #BulletJournal supplies bundle! Check it out! :) https:\/\/t.co\/9DXbxKf9Qr",
  "id" : 675128148632207361,
  "created_at" : "2015-12-11 01:41:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674973801667522560",
  "geo" : { },
  "id_str" : "675088968501850112",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ME!!! ((and I still have that adorable cat and tree from last year. sits on my windowsill. &lt;3 ))",
  "id" : 675088968501850112,
  "in_reply_to_status_id" : 674973801667522560,
  "created_at" : "2015-12-10 23:05:27 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcast",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/FLLbSMSfhG",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2757",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675005242270875648",
  "text" : "i keep forgetting about latr.fm for adding #podcast episodes (from https:\/\/t.co\/FLLbSMSfhG)",
  "id" : 675005242270875648,
  "created_at" : "2015-12-10 17:32:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/91RUeMUw1b",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2755",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674997152246947841",
  "text" : "its a big responsibility when ppl like you.. gah. did i say how much i dont like responsibility? (from https:\/\/t.co\/91RUeMUw1b)",
  "id" : 674997152246947841,
  "created_at" : "2015-12-10 17:00:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/cwqf4nia9e",
      "expanded_url" : "http:\/\/tun.in\/tg8w77",
      "display_url" : "tun.in\/tg8w77"
    } ]
  },
  "geo" : { },
  "id_str" : "674712800057532416",
  "text" : "listen to The Message with TuneIn. https:\/\/t.co\/cwqf4nia9e",
  "id" : 674712800057532416,
  "created_at" : "2015-12-09 22:10:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smab",
      "screen_name" : "SmabAudio",
      "indices" : [ 0, 10 ],
      "id_str" : "556351761",
      "id" : 556351761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674679031942418433",
  "geo" : { },
  "id_str" : "674695996559986689",
  "in_reply_to_user_id" : 556351761,
  "text" : "@SmabAudio no.. im a reader, listener not a publisher. : )",
  "id" : 674695996559986689,
  "in_reply_to_status_id" : 674679031942418433,
  "created_at" : "2015-12-09 21:03:55 +0000",
  "in_reply_to_screen_name" : "SmabAudio",
  "in_reply_to_user_id_str" : "556351761",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674638615750815745",
  "text" : "in my music player searching.. quite a few ppl looking for player that supports audiobooks (bookmarks, separate from music ie shuffle, etc)",
  "id" : 674638615750815745,
  "created_at" : "2015-12-09 17:15:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 29, 36 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firephone",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "audiobooks",
      "indices" : [ 86, 97 ]
    }, {
      "text" : "podcasts",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637717251219457",
  "text" : "instead of the #firephone .. @amazon .. a music\/video player that also well-supported #audiobooks &amp; #podcasts . THAT would sell!",
  "id" : 674637717251219457,
  "created_at" : "2015-12-09 17:12:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/GnHQBtMNGE",
      "expanded_url" : "https:\/\/www.thedodo.com\/cows-adopt-boar-1496742707.html",
      "display_url" : "thedodo.com\/cows-adopt-boa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674605064133152768",
  "text" : "Nice Cows Adopt A Lonely Wild Boar Into Their Herd https:\/\/t.co\/GnHQBtMNGE",
  "id" : 674605064133152768,
  "created_at" : "2015-12-09 15:02:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Fish and Wildlife",
      "screen_name" : "USFWS",
      "indices" : [ 3, 9 ],
      "id_str" : "57625403",
      "id" : 57625403
    }, {
      "name" : "San Diego Zoo",
      "screen_name" : "sandiegozoo",
      "indices" : [ 112, 124 ],
      "id_str" : "15526913",
      "id" : 15526913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/S0Tj7JUaGt",
      "expanded_url" : "http:\/\/bzfd.it\/1HUa7PP",
      "display_url" : "bzfd.it\/1HUa7PP"
    } ]
  },
  "geo" : { },
  "id_str" : "674026711290376192",
  "text" : "RT @USFWS: Proof bats are impressively complex (and adorable) in their relationships: https:\/\/t.co\/S0Tj7JUaGt \uD83D\uDCF7 @sandiegozoo https:\/\/t.co\/n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "San Diego Zoo",
        "screen_name" : "sandiegozoo",
        "indices" : [ 101, 113 ],
        "id_str" : "15526913",
        "id" : 15526913
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USFWS\/status\/674024850755747846\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/nlRLcTErFj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVqeB8-UYAACHy0.jpg",
        "id_str" : "674024850629877760",
        "id" : 674024850629877760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVqeB8-UYAACHy0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 791,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 791,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 659,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/nlRLcTErFj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/S0Tj7JUaGt",
        "expanded_url" : "http:\/\/bzfd.it\/1HUa7PP",
        "display_url" : "bzfd.it\/1HUa7PP"
      } ]
    },
    "geo" : { },
    "id_str" : "674024850755747846",
    "text" : "Proof bats are impressively complex (and adorable) in their relationships: https:\/\/t.co\/S0Tj7JUaGt \uD83D\uDCF7 @sandiegozoo https:\/\/t.co\/nlRLcTErFj",
    "id" : 674024850755747846,
    "created_at" : "2015-12-08 00:37:01 +0000",
    "user" : {
      "name" : "US Fish and Wildlife",
      "screen_name" : "USFWS",
      "protected" : false,
      "id_str" : "57625403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476357561268969473\/sFkAJc7o_normal.jpeg",
      "id" : 57625403,
      "verified" : true
    }
  },
  "id" : 674026711290376192,
  "created_at" : "2015-12-08 00:44:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laffy",
      "screen_name" : "GottaLaff",
      "indices" : [ 3, 13 ],
      "id_str" : "15368940",
      "id" : 15368940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ay2sFgO4TQ",
      "expanded_url" : "https:\/\/twitter.com\/KatyTurNBC\/status\/674024775891722240",
      "display_url" : "twitter.com\/KatyTurNBC\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674025830889164800",
  "text" : "RT @GottaLaff: This makes me feel very unsafe. And I'm neither a refugee nor Muslim. https:\/\/t.co\/ay2sFgO4TQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/ay2sFgO4TQ",
        "expanded_url" : "https:\/\/twitter.com\/KatyTurNBC\/status\/674024775891722240",
        "display_url" : "twitter.com\/KatyTurNBC\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674025196353814528",
    "text" : "This makes me feel very unsafe. And I'm neither a refugee nor Muslim. https:\/\/t.co\/ay2sFgO4TQ",
    "id" : 674025196353814528,
    "created_at" : "2015-12-08 00:38:24 +0000",
    "user" : {
      "name" : "Laffy",
      "screen_name" : "GottaLaff",
      "protected" : false,
      "id_str" : "15368940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744981043778772992\/Et1n4zy7_normal.jpg",
      "id" : 15368940,
      "verified" : false
    }
  },
  "id" : 674025830889164800,
  "created_at" : "2015-12-08 00:40:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673990486642806784",
  "text" : "RT @SenSanders: Drilling in the Arctic Circle and the Arctic National Wildlife Refuge at a time when we face a serious climate emergency is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673989168788320261",
    "text" : "Drilling in the Arctic Circle and the Arctic National Wildlife Refuge at a time when we face a serious climate emergency is unthinkable.",
    "id" : 673989168788320261,
    "created_at" : "2015-12-07 22:15:14 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 673990486642806784,
  "created_at" : "2015-12-07 22:20:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Fine Art America",
      "screen_name" : "FineArtAmerica",
      "indices" : [ 106, 121 ],
      "id_str" : "16828262",
      "id" : 16828262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/pHlFSRKmXW",
      "expanded_url" : "http:\/\/fineartamerica.com\/profiles\/3-dwayne-reaves.html",
      "display_url" : "fineartamerica.com\/profiles\/3-dwa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673949863944593408",
  "text" : "RT @dwaynereaves: Only a few more days to order a print as a Christmas gift.  https:\/\/t.co\/pHlFSRKmXW via @fineartamerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fine Art America",
        "screen_name" : "FineArtAmerica",
        "indices" : [ 88, 103 ],
        "id_str" : "16828262",
        "id" : 16828262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/pHlFSRKmXW",
        "expanded_url" : "http:\/\/fineartamerica.com\/profiles\/3-dwayne-reaves.html",
        "display_url" : "fineartamerica.com\/profiles\/3-dwa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "673935458229989379",
    "text" : "Only a few more days to order a print as a Christmas gift.  https:\/\/t.co\/pHlFSRKmXW via @fineartamerica",
    "id" : 673935458229989379,
    "created_at" : "2015-12-07 18:41:49 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 673949863944593408,
  "created_at" : "2015-12-07 19:39:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camilla L.",
      "screen_name" : "readdreamwrite",
      "indices" : [ 3, 18 ],
      "id_str" : "815924858",
      "id" : 815924858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/zTbsuf9abz",
      "expanded_url" : "https:\/\/twitter.com\/NoM0reSilence\/status\/673301152331644928",
      "display_url" : "twitter.com\/NoM0reSilence\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673716795270938624",
  "text" : "RT @readdreamwrite: Terrible and so sad. https:\/\/t.co\/zTbsuf9abz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/zTbsuf9abz",
        "expanded_url" : "https:\/\/twitter.com\/NoM0reSilence\/status\/673301152331644928",
        "display_url" : "twitter.com\/NoM0reSilence\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "673690322430390273",
    "text" : "Terrible and so sad. https:\/\/t.co\/zTbsuf9abz",
    "id" : 673690322430390273,
    "created_at" : "2015-12-07 02:27:44 +0000",
    "user" : {
      "name" : "Camilla L.",
      "screen_name" : "readdreamwrite",
      "protected" : false,
      "id_str" : "815924858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800796767000215552\/Qj-t9QPP_normal.jpg",
      "id" : 815924858,
      "verified" : false
    }
  },
  "id" : 673716795270938624,
  "created_at" : "2015-12-07 04:12:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "indices" : [ 3, 19 ],
      "id_str" : "30364057",
      "id" : 30364057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673700646634307584",
  "text" : "RT @SarahKSilverman: Everyone thinks the people on the other side are drinking the Kool Aid but Baby we're all drinking the Kool Aid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673648036183187456",
    "text" : "Everyone thinks the people on the other side are drinking the Kool Aid but Baby we're all drinking the Kool Aid",
    "id" : 673648036183187456,
    "created_at" : "2015-12-06 23:39:42 +0000",
    "user" : {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "protected" : false,
      "id_str" : "30364057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533405266658615296\/ULwCXwFs_normal.jpeg",
      "id" : 30364057,
      "verified" : true
    }
  },
  "id" : 673700646634307584,
  "created_at" : "2015-12-07 03:08:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallStNYC",
      "indices" : [ 3, 19 ],
      "id_str" : "335972576",
      "id" : 335972576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Finland",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "BasicIncome",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/NzQpWADPbA",
      "expanded_url" : "http:\/\/ow.ly\/Vy3Zs",
      "display_url" : "ow.ly\/Vy3Zs"
    } ]
  },
  "geo" : { },
  "id_str" : "673700254391365633",
  "text" : "RT @OccupyWallStNYC: Awesome! #Finland will pay everyone in the country $876 a month #BasicIncome https:\/\/t.co\/NzQpWADPbA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Finland",
        "indices" : [ 9, 17 ]
      }, {
        "text" : "BasicIncome",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/NzQpWADPbA",
        "expanded_url" : "http:\/\/ow.ly\/Vy3Zs",
        "display_url" : "ow.ly\/Vy3Zs"
      } ]
    },
    "geo" : { },
    "id_str" : "673655696819421184",
    "text" : "Awesome! #Finland will pay everyone in the country $876 a month #BasicIncome https:\/\/t.co\/NzQpWADPbA",
    "id" : 673655696819421184,
    "created_at" : "2015-12-07 00:10:08 +0000",
    "user" : {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallStNYC",
      "protected" : false,
      "id_str" : "335972576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567403358772662272\/BxNhe6D1_normal.jpeg",
      "id" : 335972576,
      "verified" : false
    }
  },
  "id" : 673700254391365633,
  "created_at" : "2015-12-07 03:07:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/jdoOPx0LlZ",
      "expanded_url" : "http:\/\/www.therebelgod.com\/2015\/12\/why-do-we-need-to-believe-in-hell-part.html",
      "display_url" : "therebelgod.com\/2015\/12\/why-do\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673666587895980032",
  "text" : "If you understand the gospel, you understand that what it proposes is the opposite of hell. https:\/\/t.co\/jdoOPx0LlZ",
  "id" : 673666587895980032,
  "created_at" : "2015-12-07 00:53:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673529797482385408",
  "geo" : { },
  "id_str" : "673631072740114432",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater oh my. sounds awful. : (",
  "id" : 673631072740114432,
  "in_reply_to_status_id" : 673529797482385408,
  "created_at" : "2015-12-06 22:32:17 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673550653822775297",
  "text" : "RT @rachelheldevans: We think genocide is something other people in other countries do. But how does it begin? With tribalism, fear, &amp; dehu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673549504570908672",
    "text" : "We think genocide is something other people in other countries do. But how does it begin? With tribalism, fear, &amp; dehumanization.",
    "id" : 673549504570908672,
    "created_at" : "2015-12-06 17:08:10 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 673550653822775297,
  "created_at" : "2015-12-06 17:12:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TDouble",
      "screen_name" : "CheerwinePapi",
      "indices" : [ 3, 17 ],
      "id_str" : "18824893",
      "id" : 18824893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673550466349998082",
  "text" : "RT @CheerwinePapi: It's taken me a minute to accept it, but some of y'all will never be happy on here. You are forever in a state of threat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673501817502752768",
    "text" : "It's taken me a minute to accept it, but some of y'all will never be happy on here. You are forever in a state of threat level orange.",
    "id" : 673501817502752768,
    "created_at" : "2015-12-06 13:58:41 +0000",
    "user" : {
      "name" : "TDouble",
      "screen_name" : "CheerwinePapi",
      "protected" : false,
      "id_str" : "18824893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769549363223736321\/F738-3G__normal.jpg",
      "id" : 18824893,
      "verified" : false
    }
  },
  "id" : 673550466349998082,
  "created_at" : "2015-12-06 17:11:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/4ZnCsbPsYN",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2603",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673539005913260034",
  "text" : "Adam Ruins Everything .. omg.. (from https:\/\/t.co\/4ZnCsbPsYN)",
  "id" : 673539005913260034,
  "created_at" : "2015-12-06 16:26:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "673181860864925696",
  "geo" : { },
  "id_str" : "673316474983981057",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe love this one!!",
  "id" : 673316474983981057,
  "in_reply_to_status_id" : 673181860864925696,
  "created_at" : "2015-12-06 01:42:11 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ISz5PISDH0",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2598",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673200109987880960",
  "text" : "anyone familiar w getting ipod music\/videos off ipod onto computer? (without itunes) (from https:\/\/t.co\/ISz5PISDH0)",
  "id" : 673200109987880960,
  "created_at" : "2015-12-05 17:59:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Hassan",
      "screen_name" : "CultExpert",
      "indices" : [ 3, 14 ],
      "id_str" : "137369407",
      "id" : 137369407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673165819946377216",
  "text" : "RT @CultExpert: Twenty years ago today: The final hours of Lisa McPherson\u2019s Scientology life \u00AB The Underground Bunker https:\/\/t.co\/BZCZy1fl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/BZCZy1flJ1",
        "expanded_url" : "http:\/\/ow.ly\/3ywaT4",
        "display_url" : "ow.ly\/3ywaT4"
      } ]
    },
    "geo" : { },
    "id_str" : "673137128310747136",
    "text" : "Twenty years ago today: The final hours of Lisa McPherson\u2019s Scientology life \u00AB The Underground Bunker https:\/\/t.co\/BZCZy1flJ1",
    "id" : 673137128310747136,
    "created_at" : "2015-12-05 13:49:32 +0000",
    "user" : {
      "name" : "Steven Hassan",
      "screen_name" : "CultExpert",
      "protected" : false,
      "id_str" : "137369407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634359625769422848\/3QH498iT_normal.jpg",
      "id" : 137369407,
      "verified" : false
    }
  },
  "id" : 673165819946377216,
  "created_at" : "2015-12-05 15:43:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/672824260264632321\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/CVd4ydbsi8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVZaGYjWcAEtN31.jpg",
      "id_str" : "672824260054904833",
      "id" : 672824260054904833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVZaGYjWcAEtN31.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CVd4ydbsi8"
    } ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 33, 39 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 44, 51 ]
    }, {
      "text" : "google",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/TVjvAWKoJv",
      "expanded_url" : "http:\/\/ebks.to\/1EsoSaV",
      "display_url" : "ebks.to\/1EsoSaV"
    } ]
  },
  "geo" : { },
  "id_str" : "672825547303596032",
  "text" : "RT @ebookfriendly: Searching for #books and #ebooks made easier with #google https:\/\/t.co\/TVjvAWKoJv https:\/\/t.co\/CVd4ydbsi8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/672824260264632321\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/CVd4ydbsi8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVZaGYjWcAEtN31.jpg",
        "id_str" : "672824260054904833",
        "id" : 672824260054904833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVZaGYjWcAEtN31.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CVd4ydbsi8"
      } ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 14, 20 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 25, 32 ]
      }, {
        "text" : "google",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/TVjvAWKoJv",
        "expanded_url" : "http:\/\/ebks.to\/1EsoSaV",
        "display_url" : "ebks.to\/1EsoSaV"
      } ]
    },
    "geo" : { },
    "id_str" : "672824260264632321",
    "text" : "Searching for #books and #ebooks made easier with #google https:\/\/t.co\/TVjvAWKoJv https:\/\/t.co\/CVd4ydbsi8",
    "id" : 672824260264632321,
    "created_at" : "2015-12-04 17:06:18 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 672825547303596032,
  "created_at" : "2015-12-04 17:11:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672808054660952064",
  "text" : "grateful im home to care for her. if i was working.. i'd have had to leave. (i did leave when she was 12\/13 and needed me home)",
  "id" : 672808054660952064,
  "created_at" : "2015-12-04 16:01:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672807421895680001",
  "text" : "its just frustrating not knowing what is happening in her body to make her feel so weird and ill.",
  "id" : 672807421895680001,
  "created_at" : "2015-12-04 15:59:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicallyill",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672806992046608384",
  "text" : "i dont think she has anything physiologically fatal but it certainly has impeded her quality of life.. and she's only 20. #chronicallyill",
  "id" : 672806992046608384,
  "created_at" : "2015-12-04 15:57:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672806192838766592",
  "text" : "i hope the mri, eeg show something but im not expecting much. if its chemical, it wouldnt show, right? #hashimotos",
  "id" : 672806192838766592,
  "created_at" : "2015-12-04 15:54:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672804674483986437",
  "text" : "DD had nightmare so she took ativan before levo this am.. false awakening dream.",
  "id" : 672804674483986437,
  "created_at" : "2015-12-04 15:48:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/INv2r4LAiB",
      "expanded_url" : "http:\/\/blog.booksontheknob.org\/2015\/12\/free-videos-property-brothers-at-home.html",
      "display_url" : "blog.booksontheknob.org\/2015\/12\/free-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672181865365786629",
  "text" : "Free Videos - Property Brothers at Home https:\/\/t.co\/INv2r4LAiB",
  "id" : 672181865365786629,
  "created_at" : "2015-12-02 22:33:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/rB6GpWpUgL",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2538",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672095348421033984",
  "text" : "at least she's getting mri, eeg done... (from https:\/\/t.co\/rB6GpWpUgL)",
  "id" : 672095348421033984,
  "created_at" : "2015-12-02 16:49:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "symptoms",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 64, 79 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 80, 91 ]
    }, {
      "text" : "brain",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/mAHSWC14rn",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2537",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672094249102348288",
  "text" : "so endo says its neuro and neuro says its endo.. gah. #symptoms #chronicillness #hashimotos #brain (from https:\/\/t.co\/mAHSWC14rn)",
  "id" : 672094249102348288,
  "created_at" : "2015-12-02 16:45:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 0, 16 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "671902191381307393",
  "geo" : { },
  "id_str" : "671906697108156416",
  "in_reply_to_user_id" : 111579405,
  "text" : "@thDigitalReader I'm sharpening all the time . Love using pencils. : )",
  "id" : 671906697108156416,
  "in_reply_to_status_id" : 671902191381307393,
  "created_at" : "2015-12-02 04:20:14 +0000",
  "in_reply_to_screen_name" : "thDigitalReader",
  "in_reply_to_user_id_str" : "111579405",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sharkey",
      "screen_name" : "rsharkbait",
      "indices" : [ 3, 14 ],
      "id_str" : "4632360627",
      "id" : 4632360627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671890971651653632",
  "text" : "RT @rsharkbait: YOU are not fat. YOU are not ugly. YOU are not a body.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671866450248728576",
    "text" : "YOU are not fat. YOU are not ugly. YOU are not a body.",
    "id" : 671866450248728576,
    "created_at" : "2015-12-02 01:40:19 +0000",
    "user" : {
      "name" : "Ryan Sharkey",
      "screen_name" : "SunshineShark",
      "protected" : false,
      "id_str" : "331434059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793834517538627584\/D0-8ehpn_normal.jpg",
      "id" : 331434059,
      "verified" : false
    }
  },
  "id" : 671890971651653632,
  "created_at" : "2015-12-02 03:17:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Adams",
      "screen_name" : "sampoppy71",
      "indices" : [ 3, 14 ],
      "id_str" : "2512225558",
      "id" : 2512225558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671749526257029120",
  "text" : "RT @sampoppy71: Sam Adams @respectorganics.com #fantasy #waterlily #scape \"#Dream #colours\" #original #watercolour \u00A380 https:\/\/t.co\/kQjV52n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sampoppy71\/status\/671745889980039168\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/kQjV52nLnc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVKFU-PWcAAE3iv.jpg",
        "id_str" : "671745889782886400",
        "id" : 671745889782886400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVKFU-PWcAAE3iv.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kQjV52nLnc"
      } ],
      "hashtags" : [ {
        "text" : "fantasy",
        "indices" : [ 31, 39 ]
      }, {
        "text" : "waterlily",
        "indices" : [ 40, 50 ]
      }, {
        "text" : "scape",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "Dream",
        "indices" : [ 59, 65 ]
      }, {
        "text" : "colours",
        "indices" : [ 66, 74 ]
      }, {
        "text" : "original",
        "indices" : [ 76, 85 ]
      }, {
        "text" : "watercolour",
        "indices" : [ 86, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.006822, -2.195854 ]
    },
    "id_str" : "671745889980039168",
    "text" : "Sam Adams @respectorganics.com #fantasy #waterlily #scape \"#Dream #colours\" #original #watercolour \u00A380 https:\/\/t.co\/kQjV52nLnc",
    "id" : 671745889980039168,
    "created_at" : "2015-12-01 17:41:15 +0000",
    "user" : {
      "name" : "Samantha Adams",
      "screen_name" : "sampoppy71",
      "protected" : false,
      "id_str" : "2512225558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770940958284378113\/CL1FWQoC_normal.jpg",
      "id" : 2512225558,
      "verified" : false
    }
  },
  "id" : 671749526257029120,
  "created_at" : "2015-12-01 17:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/T1kdT5tFLS",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2524",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671737057727791104",
  "text" : "checking directions for DD neuro appt tomorrow and thinking might go w new ipod touch (but I dont want apple\/itune\u2026 https:\/\/t.co\/T1kdT5tFLS",
  "id" : 671737057727791104,
  "created_at" : "2015-12-01 17:06:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]