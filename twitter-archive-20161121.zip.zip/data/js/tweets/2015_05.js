Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/lrKBtflgkU",
      "expanded_url" : "http:\/\/goo.gl\/fb\/9610LO",
      "display_url" : "goo.gl\/fb\/9610LO"
    } ]
  },
  "geo" : { },
  "id_str" : "605176043100622850",
  "text" : "RT @Mahala: Cemetery Stomping and Hiking in the Woods http:\/\/t.co\/lrKBtflgkU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/lrKBtflgkU",
        "expanded_url" : "http:\/\/goo.gl\/fb\/9610LO",
        "display_url" : "goo.gl\/fb\/9610LO"
      } ]
    },
    "geo" : { },
    "id_str" : "605154510084829185",
    "text" : "Cemetery Stomping and Hiking in the Woods http:\/\/t.co\/lrKBtflgkU",
    "id" : 605154510084829185,
    "created_at" : "2015-05-31 23:30:53 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 605176043100622850,
  "created_at" : "2015-06-01 00:56:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605114732861919232",
  "text" : "RT @adamrshields: Since I am cutting back on my number of blog posts I decided to write about where to I find free ebooks\u2026 http:\/\/t.co\/Y0II\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/Y0IImu0Zdk",
        "expanded_url" : "http:\/\/bookwi.se\/where-to-find-free-books\/",
        "display_url" : "bookwi.se\/where-to-find-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605113983826198528",
    "text" : "Since I am cutting back on my number of blog posts I decided to write about where to I find free ebooks\u2026 http:\/\/t.co\/Y0IImu0Zdk",
    "id" : 605113983826198528,
    "created_at" : "2015-05-31 20:49:50 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 605114732861919232,
  "created_at" : "2015-05-31 20:52:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MARC EGLON",
      "screen_name" : "MarcEglon",
      "indices" : [ 3, 13 ],
      "id_str" : "17352083",
      "id" : 17352083
    }, {
      "name" : "NextDraft Newsletter",
      "screen_name" : "nextdraft",
      "indices" : [ 67, 77 ],
      "id_str" : "86986414",
      "id" : 86986414
    }, {
      "name" : "Product Hunt",
      "screen_name" : "ProductHunt",
      "indices" : [ 79, 91 ],
      "id_str" : "2208027565",
      "id" : 2208027565
    }, {
      "name" : "500 Distribution",
      "screen_name" : "500Distribution",
      "indices" : [ 98, 114 ],
      "id_str" : "1534893631",
      "id" : 1534893631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605053229077016576",
  "text" : "RT @MarcEglon: A wee app to help you find amazing newsletters like @nextdraft, @producthunt &amp; @500Distribution. You're welcome.\n\nhttp:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sharedby.co\" rel=\"nofollow\"\u003ESharedBy\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NextDraft Newsletter",
        "screen_name" : "nextdraft",
        "indices" : [ 52, 62 ],
        "id_str" : "86986414",
        "id" : 86986414
      }, {
        "name" : "Product Hunt",
        "screen_name" : "ProductHunt",
        "indices" : [ 64, 76 ],
        "id_str" : "2208027565",
        "id" : 2208027565
      }, {
        "name" : "500 Distribution",
        "screen_name" : "500Distribution",
        "indices" : [ 83, 99 ],
        "id_str" : "1534893631",
        "id" : 1534893631
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/YNCp1cspvX",
        "expanded_url" : "http:\/\/j.mp\/1KxBuwi",
        "display_url" : "j.mp\/1KxBuwi"
      } ]
    },
    "geo" : { },
    "id_str" : "593817289868218368",
    "text" : "A wee app to help you find amazing newsletters like @nextdraft, @producthunt &amp; @500Distribution. You're welcome.\n\nhttp:\/\/t.co\/YNCp1cspvX",
    "id" : 593817289868218368,
    "created_at" : "2015-04-30 16:40:49 +0000",
    "user" : {
      "name" : "MARC EGLON",
      "screen_name" : "MarcEglon",
      "protected" : false,
      "id_str" : "17352083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706113961784168449\/fVGZ5a9f_normal.jpg",
      "id" : 17352083,
      "verified" : false
    }
  },
  "id" : 605053229077016576,
  "created_at" : "2015-05-31 16:48:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MARC EGLON",
      "screen_name" : "MarcEglon",
      "indices" : [ 3, 13 ],
      "id_str" : "17352083",
      "id" : 17352083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basicincome",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/IrSL74amVa",
      "expanded_url" : "http:\/\/buff.ly\/1Qj4DfO",
      "display_url" : "buff.ly\/1Qj4DfO"
    } ]
  },
  "geo" : { },
  "id_str" : "605053053436342272",
  "text" : "RT @MarcEglon: A thought-provoking email digest about universal #basicincome &amp; alternative economics. Subscribe at  http:\/\/t.co\/IrSL74amVa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "basicincome",
        "indices" : [ 49, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/IrSL74amVa",
        "expanded_url" : "http:\/\/buff.ly\/1Qj4DfO",
        "display_url" : "buff.ly\/1Qj4DfO"
      } ]
    },
    "geo" : { },
    "id_str" : "604953834427949056",
    "text" : "A thought-provoking email digest about universal #basicincome &amp; alternative economics. Subscribe at  http:\/\/t.co\/IrSL74amVa",
    "id" : 604953834427949056,
    "created_at" : "2015-05-31 10:13:28 +0000",
    "user" : {
      "name" : "MARC EGLON",
      "screen_name" : "MarcEglon",
      "protected" : false,
      "id_str" : "17352083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706113961784168449\/fVGZ5a9f_normal.jpg",
      "id" : 17352083,
      "verified" : false
    }
  },
  "id" : 605053053436342272,
  "created_at" : "2015-05-31 16:47:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605003514000101376",
  "text" : "those ATI (Duggar curriculum) homeschool pages look like from the 60's... and how you look is under \"medicine resources\".",
  "id" : 605003514000101376,
  "created_at" : "2015-05-31 13:30:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 21, 34 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Music",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "Video",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "Classic",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/aONyzugG33",
      "expanded_url" : "http:\/\/youtu.be\/MbXWrmQW-OE",
      "display_url" : "youtu.be\/MbXWrmQW-OE"
    } ]
  },
  "in_reply_to_status_id_str" : "604771490534297600",
  "geo" : { },
  "id_str" : "604818497491861504",
  "in_reply_to_user_id" : 36008885,
  "text" : "Oh the memories.. RT @UnseeingEyes: The Police - Message In A Bottle #Music #Video #Classic http:\/\/t.co\/aONyzugG33",
  "id" : 604818497491861504,
  "in_reply_to_status_id" : 604771490534297600,
  "created_at" : "2015-05-31 01:15:41 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Stevenson",
      "screen_name" : "tourscotland",
      "indices" : [ 3, 16 ],
      "id_str" : "15842676",
      "id" : 15842676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604817475369349120",
  "text" : "RT @tourscotland: As requested, Tour Scotland photo of Highland Cows by Duart Castle on ancestry visit to Isle of Mull, Inner Hebrides http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tourscotland\/status\/604780195481010176\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xewQuRluWd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGScYYtXEAEywZD.jpg",
        "id_str" : "604780192737988609",
        "id" : 604780192737988609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGScYYtXEAEywZD.jpg",
        "sizes" : [ {
          "h" : 437,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 765
        } ],
        "display_url" : "pic.twitter.com\/xewQuRluWd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604780195481010176",
    "text" : "As requested, Tour Scotland photo of Highland Cows by Duart Castle on ancestry visit to Isle of Mull, Inner Hebrides http:\/\/t.co\/xewQuRluWd",
    "id" : 604780195481010176,
    "created_at" : "2015-05-30 22:43:29 +0000",
    "user" : {
      "name" : "Sandy Stevenson",
      "screen_name" : "tourscotland",
      "protected" : false,
      "id_str" : "15842676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/70101487\/Sandy_Stevenson_normal.jpg",
      "id" : 15842676,
      "verified" : false
    }
  },
  "id" : 604817475369349120,
  "created_at" : "2015-05-31 01:11:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604817111274409985",
  "text" : "RT @UnseeingEyes: I'd like to thank the people not viewing everything as a WAR for or against something...but yet an unfolding of positive \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604777281488220160",
    "text" : "I'd like to thank the people not viewing everything as a WAR for or against something...but yet an unfolding of positive solutions.",
    "id" : 604777281488220160,
    "created_at" : "2015-05-30 22:31:54 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 604817111274409985,
  "created_at" : "2015-05-31 01:10:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604817019259789312",
  "text" : "RT @UnseeingEyes: I'd like to thank the extraordinary \"regular people\" who enrich &amp; infuse this medium daily with hope, love, kindness, &amp; l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604776401372250112",
    "text" : "I'd like to thank the extraordinary \"regular people\" who enrich &amp; infuse this medium daily with hope, love, kindness, &amp; light.",
    "id" : 604776401372250112,
    "created_at" : "2015-05-30 22:28:24 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 604817019259789312,
  "created_at" : "2015-05-31 01:09:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "con",
      "screen_name" : "ConnorFranta",
      "indices" : [ 123, 136 ],
      "id_str" : "180949358",
      "id" : 180949358
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 62, 66 ]
    }, {
      "text" : "AWorkInProgress",
      "indices" : [ 88, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604722775190847489",
  "text" : "RT @SimonAudio: Here\u2019s your last chance to follow &amp; RT to #win the last copy of the #AWorkInProgress audiobook read by @ConnorFranta http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "con",
        "screen_name" : "ConnorFranta",
        "indices" : [ 107, 120 ],
        "id_str" : "180949358",
        "id" : 180949358
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 46, 50 ]
      }, {
        "text" : "AWorkInProgress",
        "indices" : [ 72, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/ZbanwiRZQn",
        "expanded_url" : "http:\/\/bit.ly\/1KovYvj",
        "display_url" : "bit.ly\/1KovYvj"
      } ]
    },
    "geo" : { },
    "id_str" : "604709227614105600",
    "text" : "Here\u2019s your last chance to follow &amp; RT to #win the last copy of the #AWorkInProgress audiobook read by @ConnorFranta http:\/\/t.co\/ZbanwiRZQn",
    "id" : 604709227614105600,
    "created_at" : "2015-05-30 18:01:29 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 604722775190847489,
  "created_at" : "2015-05-30 18:55:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604684314907955200",
  "text" : "RT @Irish_Atheist: The tragic thing about not knowing every language is all the brilliant books I will never read.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604683247570825216",
    "text" : "The tragic thing about not knowing every language is all the brilliant books I will never read.",
    "id" : 604683247570825216,
    "created_at" : "2015-05-30 16:18:15 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 604684314907955200,
  "created_at" : "2015-05-30 16:22:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604684217453289472",
  "text" : "i dont know who i am anymore.. i used to be switzerland.. and now, im not. im less tolerant, more judgemental. wth??",
  "id" : 604684217453289472,
  "created_at" : "2015-05-30 16:22:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "Connor Franta",
      "screen_name" : "ConnorFranta",
      "indices" : [ 113, 126 ],
      "id_str" : "180949358",
      "id" : 180949358
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "AWorkInProgress",
      "indices" : [ 67, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604676195679145986",
  "text" : "RT @SimonAudio: Follow &amp; RT to #win the 3rd of 5 copies of the #AWorkInProgress audiobook read by the author @ConnorFranta http:\/\/t.co\/Zban\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Connor Franta",
        "screen_name" : "ConnorFranta",
        "indices" : [ 97, 110 ],
        "id_str" : "180949358",
        "id" : 180949358
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 19, 23 ]
      }, {
        "text" : "AWorkInProgress",
        "indices" : [ 51, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/ZbanwiRZQn",
        "expanded_url" : "http:\/\/bit.ly\/1KovYvj",
        "display_url" : "bit.ly\/1KovYvj"
      } ]
    },
    "geo" : { },
    "id_str" : "604459825636982784",
    "text" : "Follow &amp; RT to #win the 3rd of 5 copies of the #AWorkInProgress audiobook read by the author @ConnorFranta http:\/\/t.co\/ZbanwiRZQn",
    "id" : 604459825636982784,
    "created_at" : "2015-05-30 01:30:27 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 604676195679145986,
  "created_at" : "2015-05-30 15:50:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "indices" : [ 3, 14 ],
      "id_str" : "87207875",
      "id" : 87207875
    }, {
      "name" : "con",
      "screen_name" : "ConnorFranta",
      "indices" : [ 28, 41 ],
      "id_str" : "180949358",
      "id" : 180949358
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 67, 71 ]
    }, {
      "text" : "AWorkInProgress",
      "indices" : [ 79, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ZbanwiRZQn",
      "expanded_url" : "http:\/\/bit.ly\/1KovYvj",
      "display_url" : "bit.ly\/1KovYvj"
    } ]
  },
  "geo" : { },
  "id_str" : "604355149180592129",
  "text" : "RT @SimonAudio: Calling all @ConnorFranta fans! Follow &amp; RT to #win 1 of 5 #AWorkInProgress audiobooks! Rules: http:\/\/t.co\/ZbanwiRZQn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "con",
        "screen_name" : "ConnorFranta",
        "indices" : [ 12, 25 ],
        "id_str" : "180949358",
        "id" : 180949358
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 51, 55 ]
      }, {
        "text" : "AWorkInProgress",
        "indices" : [ 63, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/ZbanwiRZQn",
        "expanded_url" : "http:\/\/bit.ly\/1KovYvj",
        "display_url" : "bit.ly\/1KovYvj"
      } ]
    },
    "geo" : { },
    "id_str" : "604354175321948160",
    "text" : "Calling all @ConnorFranta fans! Follow &amp; RT to #win 1 of 5 #AWorkInProgress audiobooks! Rules: http:\/\/t.co\/ZbanwiRZQn",
    "id" : 604354175321948160,
    "created_at" : "2015-05-29 18:30:38 +0000",
    "user" : {
      "name" : "S&S Audio",
      "screen_name" : "SimonAudio",
      "protected" : false,
      "id_str" : "87207875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3371134106\/10ea612a2f1eccfec5556945c94ba9e4_normal.jpeg",
      "id" : 87207875,
      "verified" : true
    }
  },
  "id" : 604355149180592129,
  "created_at" : "2015-05-29 18:34:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "indices" : [ 3, 15 ],
      "id_str" : "629225037",
      "id" : 629225037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604346210443481090",
  "text" : "RT @AndyBoxHill: This lady is doing her best for the robin population. She already fledged 5 from this nest and is brooding another 6! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/604175175924486144\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/w15siCDAtl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGJ2GSTWQAAhFsk.jpg",
        "id_str" : "604175150385348608",
        "id" : 604175150385348608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGJ2GSTWQAAhFsk.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 686,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/w15siCDAtl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604175175924486144",
    "text" : "This lady is doing her best for the robin population. She already fledged 5 from this nest and is brooding another 6! http:\/\/t.co\/w15siCDAtl",
    "id" : 604175175924486144,
    "created_at" : "2015-05-29 06:39:21 +0000",
    "user" : {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "protected" : false,
      "id_str" : "629225037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543479254550593536\/nw_rTozc_normal.jpeg",
      "id" : 629225037,
      "verified" : false
    }
  },
  "id" : 604346210443481090,
  "created_at" : "2015-05-29 17:58:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604332958682583040",
  "text" : "RT @RustBeltRebel: state supreme court ruled that MI has no legal obligation to give 'quality' education to students, just 'education.'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604284792927064064",
    "text" : "state supreme court ruled that MI has no legal obligation to give 'quality' education to students, just 'education.'",
    "id" : 604284792927064064,
    "created_at" : "2015-05-29 13:54:56 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 604332958682583040,
  "created_at" : "2015-05-29 17:06:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604332731443625984",
  "text" : "RT @RustBeltRebel: they state refuses any obligation to give students an education that could actually allow them to move up economic ladde\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604285251419009024",
    "text" : "they state refuses any obligation to give students an education that could actually allow them to move up economic ladder-",
    "id" : 604285251419009024,
    "created_at" : "2015-05-29 13:56:45 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 604332731443625984,
  "created_at" : "2015-05-29 17:05:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "In Other News",
      "screen_name" : "Newsacious",
      "indices" : [ 3, 14 ],
      "id_str" : "2836453703",
      "id" : 2836453703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/4sUiPJYWoO",
      "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2015\/05\/150521143926.htm",
      "display_url" : "sciencedaily.com\/releases\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604083237951029248",
  "text" : "RT @Newsacious: Gravitational disturbance from Antarctic ice melt http:\/\/t.co\/4sUiPJYWoO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/4sUiPJYWoO",
        "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2015\/05\/150521143926.htm",
        "display_url" : "sciencedaily.com\/releases\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "604014561339957249",
    "text" : "Gravitational disturbance from Antarctic ice melt http:\/\/t.co\/4sUiPJYWoO",
    "id" : 604014561339957249,
    "created_at" : "2015-05-28 20:01:08 +0000",
    "user" : {
      "name" : "In Other News",
      "screen_name" : "Newsacious",
      "protected" : false,
      "id_str" : "2836453703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578867986343141376\/W1Wf8dDD_normal.jpeg",
      "id" : 2836453703,
      "verified" : false
    }
  },
  "id" : 604083237951029248,
  "created_at" : "2015-05-29 00:34:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schell",
      "screen_name" : "DavidMSchell",
      "indices" : [ 74, 87 ],
      "id_str" : "393079584",
      "id" : 393079584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/5yEUXIGiaB",
      "expanded_url" : "http:\/\/davidmschell.com\/defending-the-duggars\/",
      "display_url" : "davidmschell.com\/defending-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604070206164582400",
  "text" : "Why Conservative Christians Defend the Duggars http:\/\/t.co\/5yEUXIGiaB via @DavidMSchell",
  "id" : 604070206164582400,
  "created_at" : "2015-05-28 23:42:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Demers",
      "screen_name" : "walruswhisperer",
      "indices" : [ 3, 19 ],
      "id_str" : "244120148",
      "id" : 244120148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604039779362172928",
  "text" : "RT @walruswhisperer: Remember this date. We just saved orcas from ever being captured\/bred by Marineland ever again. It's a law now. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/imzN7m3xp9",
        "expanded_url" : "http:\/\/news.ontario.ca\/mcscs\/en\/2015\/05\/new-legislation-passes-to-end-acquisition-and-breeding-of-killer-whales-in-ontario.html?utm_source=ondemand&utm_medium=email&utm_campaign=o",
        "display_url" : "news.ontario.ca\/mcscs\/en\/2015\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603962225221566464",
    "text" : "Remember this date. We just saved orcas from ever being captured\/bred by Marineland ever again. It's a law now. http:\/\/t.co\/imzN7m3xp9",
    "id" : 603962225221566464,
    "created_at" : "2015-05-28 16:33:10 +0000",
    "user" : {
      "name" : "Phil Demers",
      "screen_name" : "walruswhisperer",
      "protected" : false,
      "id_str" : "244120148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687413658499059713\/X6RLU7uM_normal.jpg",
      "id" : 244120148,
      "verified" : true
    }
  },
  "id" : 604039779362172928,
  "created_at" : "2015-05-28 21:41:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Quiverfull",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "cult",
      "indices" : [ 121, 126 ]
    }, {
      "text" : "brainwashing",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604030949265903616",
  "text" : "i must stop reading about #Quiverfull families.. ack! gen im pretty tolerant but they make me scream. those poor kids... #cult #brainwashing",
  "id" : 604030949265903616,
  "created_at" : "2015-05-28 21:06:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/J6obmtWIRt",
      "expanded_url" : "http:\/\/fiddlrts.blogspot.com\/2015\/04\/john-piper-steps-in-it-on-rape-and-sex.html?spref=tw",
      "display_url" : "fiddlrts.blogspot.com\/2015\/04\/john-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603971986973417472",
  "text" : "Diary of an Autodidact: John Piper Steps In It on Rape and Sex http:\/\/t.co\/J6obmtWIRt",
  "id" : 603971986973417472,
  "created_at" : "2015-05-28 17:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lana Hope",
      "screen_name" : "wideopenground",
      "indices" : [ 3, 18 ],
      "id_str" : "1281022819",
      "id" : 1281022819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/fIgHU2PG7z",
      "expanded_url" : "http:\/\/fiddlrts.blogspot.com\/2015\/05\/the-duggars-how-fundamentalisms.html?spref=tw",
      "display_url" : "fiddlrts.blogspot.com\/2015\/05\/the-du\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603940527860490240",
  "text" : "RT @wideopenground: Diary of an Autodidact: The Duggars: How Fundamentalism's Teachings on Sex... http:\/\/t.co\/fIgHU2PG7z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/fIgHU2PG7z",
        "expanded_url" : "http:\/\/fiddlrts.blogspot.com\/2015\/05\/the-duggars-how-fundamentalisms.html?spref=tw",
        "display_url" : "fiddlrts.blogspot.com\/2015\/05\/the-du\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602556317836804096",
    "text" : "Diary of an Autodidact: The Duggars: How Fundamentalism's Teachings on Sex... http:\/\/t.co\/fIgHU2PG7z",
    "id" : 602556317836804096,
    "created_at" : "2015-05-24 19:26:35 +0000",
    "user" : {
      "name" : "Lana Hope",
      "screen_name" : "wideopenground",
      "protected" : false,
      "id_str" : "1281022819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3401580261\/c7c5d8f4f98485610f1151880a2c07f3_normal.jpeg",
      "id" : 1281022819,
      "verified" : false
    }
  },
  "id" : 603940527860490240,
  "created_at" : "2015-05-28 15:06:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/603779327533129728\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/i35nf7aqWx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGEOGGLXIAA2nEb.jpg",
      "id_str" : "603779322944626688",
      "id" : 603779322944626688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGEOGGLXIAA2nEb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/i35nf7aqWx"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/603779327533129728\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/i35nf7aqWx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGEOGGvWIAA3Mhd.jpg",
      "id_str" : "603779323095556096",
      "id" : 603779323095556096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGEOGGvWIAA3Mhd.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i35nf7aqWx"
    } ],
    "hashtags" : [ {
      "text" : "yearofmaking",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603924757059411968",
  "text" : "RT @ErinEFarley: More hedgehogs! I'm liking these eyes much better. #yearofmaking http:\/\/t.co\/i35nf7aqWx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/603779327533129728\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/i35nf7aqWx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGEOGGLXIAA2nEb.jpg",
        "id_str" : "603779322944626688",
        "id" : 603779322944626688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGEOGGLXIAA2nEb.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/i35nf7aqWx"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/603779327533129728\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/i35nf7aqWx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGEOGGvWIAA3Mhd.jpg",
        "id_str" : "603779323095556096",
        "id" : 603779323095556096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGEOGGvWIAA3Mhd.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/i35nf7aqWx"
      } ],
      "hashtags" : [ {
        "text" : "yearofmaking",
        "indices" : [ 51, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603779327533129728",
    "text" : "More hedgehogs! I'm liking these eyes much better. #yearofmaking http:\/\/t.co\/i35nf7aqWx",
    "id" : 603779327533129728,
    "created_at" : "2015-05-28 04:26:24 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 603924757059411968,
  "created_at" : "2015-05-28 14:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan",
      "screen_name" : "geminicat7",
      "indices" : [ 3, 14 ],
      "id_str" : "1704413916",
      "id" : 1704413916
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/geminicat7\/status\/603742744931127296\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ZGj9ATATB6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGDs0AhWoAEDFk6.jpg",
      "id_str" : "603742728304893953",
      "id" : 603742728304893953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGDs0AhWoAEDFk6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ZGj9ATATB6"
    } ],
    "hashtags" : [ {
      "text" : "art",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603912802668040192",
  "text" : "RT @geminicat7: 'Tulips'\nStanley Spencer, 1938 (1891-1959) #art http:\/\/t.co\/ZGj9ATATB6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/geminicat7\/status\/603742744931127296\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/ZGj9ATATB6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGDs0AhWoAEDFk6.jpg",
        "id_str" : "603742728304893953",
        "id" : 603742728304893953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGDs0AhWoAEDFk6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/ZGj9ATATB6"
      } ],
      "hashtags" : [ {
        "text" : "art",
        "indices" : [ 43, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603742744931127296",
    "text" : "'Tulips'\nStanley Spencer, 1938 (1891-1959) #art http:\/\/t.co\/ZGj9ATATB6",
    "id" : 603742744931127296,
    "created_at" : "2015-05-28 02:01:02 +0000",
    "user" : {
      "name" : "Jan",
      "screen_name" : "geminicat7",
      "protected" : false,
      "id_str" : "1704413916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566524030535352320\/e64XS3wl_normal.jpeg",
      "id" : 1704413916,
      "verified" : false
    }
  },
  "id" : 603912802668040192,
  "created_at" : "2015-05-28 13:16:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 3, 15 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/g7dlSnJli8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP0LW8AEZYxH.jpg",
      "id_str" : "602966950818541569",
      "id" : 602966950818541569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP0LW8AEZYxH.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g7dlSnJli8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/g7dlSnJli8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP0hWIAEIx1F.jpg",
      "id_str" : "602966950910763009",
      "id" : 602966950910763009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP0hWIAEIx1F.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g7dlSnJli8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/g7dlSnJli8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP06WEAArpvo.jpg",
      "id_str" : "602966951015616512",
      "id" : 602966951015616512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP06WEAArpvo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g7dlSnJli8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/g7dlSnJli8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP1ZXIAEwpV0.jpg",
      "id_str" : "602966951145709569",
      "id" : 602966951145709569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP1ZXIAEwpV0.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g7dlSnJli8"
    } ],
    "hashtags" : [ {
      "text" : "dailyMorag",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603737131710820352",
  "text" : "RT @newlandfarm: #dailyMorag Rolls eyes, more photos! http:\/\/t.co\/g7dlSnJli8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/g7dlSnJli8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP0LW8AEZYxH.jpg",
        "id_str" : "602966950818541569",
        "id" : 602966950818541569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP0LW8AEZYxH.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g7dlSnJli8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/g7dlSnJli8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP0hWIAEIx1F.jpg",
        "id_str" : "602966950910763009",
        "id" : 602966950910763009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP0hWIAEIx1F.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g7dlSnJli8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/g7dlSnJli8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP06WEAArpvo.jpg",
        "id_str" : "602966951015616512",
        "id" : 602966951015616512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP06WEAArpvo.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g7dlSnJli8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/newlandfarm\/status\/602967049393025024\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/g7dlSnJli8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4rP1ZXIAEwpV0.jpg",
        "id_str" : "602966951145709569",
        "id" : 602966951145709569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4rP1ZXIAEwpV0.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g7dlSnJli8"
      } ],
      "hashtags" : [ {
        "text" : "dailyMorag",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "602625015989809152",
    "geo" : { },
    "id_str" : "602967049393025024",
    "in_reply_to_user_id" : 2259182801,
    "text" : "#dailyMorag Rolls eyes, more photos! http:\/\/t.co\/g7dlSnJli8",
    "id" : 602967049393025024,
    "in_reply_to_status_id" : 602625015989809152,
    "created_at" : "2015-05-25 22:38:41 +0000",
    "in_reply_to_screen_name" : "newlandfarm",
    "in_reply_to_user_id_str" : "2259182801",
    "user" : {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "protected" : false,
      "id_str" : "2259182801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712286940666662913\/KTwREe4z_normal.jpg",
      "id" : 2259182801,
      "verified" : false
    }
  },
  "id" : 603737131710820352,
  "created_at" : "2015-05-28 01:38:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Simpson",
      "screen_name" : "robin182zz",
      "indices" : [ 3, 14 ],
      "id_str" : "145659451",
      "id" : 145659451
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UniteBlue",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "LibCrib",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/qgSxfp380s",
      "expanded_url" : "http:\/\/www.mediaite.com\/online\/jon-stewart-has-been-quietly-running-a-tv-program-to-help-u-s-veterans\/",
      "display_url" : "mediaite.com\/online\/jon-ste\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603730321721446401",
  "text" : "RT @robin182zz: \"Jon Stewart Has Been Quietly Running a Program to Help U.S. Veterans\" #UniteBlue #LibCrib   http:\/\/t.co\/qgSxfp380s http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/robin182zz\/status\/602904786116182016\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/3fvS70sDp6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF3ytCVWEAA_fep.jpg",
        "id_str" : "602904780671946752",
        "id" : 602904780671946752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF3ytCVWEAA_fep.jpg",
        "sizes" : [ {
          "h" : 210,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/3fvS70sDp6"
      } ],
      "hashtags" : [ {
        "text" : "UniteBlue",
        "indices" : [ 71, 81 ]
      }, {
        "text" : "LibCrib",
        "indices" : [ 82, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/qgSxfp380s",
        "expanded_url" : "http:\/\/www.mediaite.com\/online\/jon-stewart-has-been-quietly-running-a-tv-program-to-help-u-s-veterans\/",
        "display_url" : "mediaite.com\/online\/jon-ste\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602904786116182016",
    "text" : "\"Jon Stewart Has Been Quietly Running a Program to Help U.S. Veterans\" #UniteBlue #LibCrib   http:\/\/t.co\/qgSxfp380s http:\/\/t.co\/3fvS70sDp6",
    "id" : 602904786116182016,
    "created_at" : "2015-05-25 18:31:17 +0000",
    "user" : {
      "name" : "Robin Simpson",
      "screen_name" : "robin182zz",
      "protected" : false,
      "id_str" : "145659451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728978607771541505\/YIHLYDT4_normal.jpg",
      "id" : 145659451,
      "verified" : false
    }
  },
  "id" : 603730321721446401,
  "created_at" : "2015-05-28 01:11:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/t2dlIPKdS7",
      "expanded_url" : "http:\/\/wp.me\/s5lelX-genesis",
      "display_url" : "wp.me\/s5lelX-genesis"
    } ]
  },
  "geo" : { },
  "id_str" : "603723368454627328",
  "text" : "RT @Joshua_St_John: As promised: why the fuck is everything itching? I wrote more words. Read more words -&gt;\n\nGenesis http:\/\/t.co\/t2dlIPKdS7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 127, 143 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/t2dlIPKdS7",
        "expanded_url" : "http:\/\/wp.me\/s5lelX-genesis",
        "display_url" : "wp.me\/s5lelX-genesis"
      } ]
    },
    "geo" : { },
    "id_str" : "603721458410487810",
    "text" : "As promised: why the fuck is everything itching? I wrote more words. Read more words -&gt;\n\nGenesis http:\/\/t.co\/t2dlIPKdS7 via @wordpressdotcom",
    "id" : 603721458410487810,
    "created_at" : "2015-05-28 00:36:26 +0000",
    "user" : {
      "name" : "\uD83C\uDF84Joshua \u2603\uFE0F",
      "screen_name" : "ALifeRelentless",
      "protected" : false,
      "id_str" : "197910360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770384906639724544\/mN91OZP1_normal.jpg",
      "id" : 197910360,
      "verified" : false
    }
  },
  "id" : 603723368454627328,
  "created_at" : "2015-05-28 00:44:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "indices" : [ 3, 15 ],
      "id_str" : "17592150",
      "id" : 17592150
    }, {
      "name" : "Inquisitr News",
      "screen_name" : "theinquisitr",
      "indices" : [ 123, 136 ],
      "id_str" : "14722676",
      "id" : 14722676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/6qrOSRGwXo",
      "expanded_url" : "http:\/\/www.inquisitr.com\/2106782\/opossums-the-unsung-heroes-against-lyme-disease-and-other-tick-borne-diseases\/",
      "display_url" : "inquisitr.com\/2106782\/opossu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603695829711486976",
  "text" : "RT @thomaspluck: Opossums: The Unsung Heroes Against Lyme Disease And Other Tick-Borne Diseases http:\/\/t.co\/6qrOSRGwXo via @theinquisitr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Inquisitr News",
        "screen_name" : "theinquisitr",
        "indices" : [ 106, 119 ],
        "id_str" : "14722676",
        "id" : 14722676
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/6qrOSRGwXo",
        "expanded_url" : "http:\/\/www.inquisitr.com\/2106782\/opossums-the-unsung-heroes-against-lyme-disease-and-other-tick-borne-diseases\/",
        "display_url" : "inquisitr.com\/2106782\/opossu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603687947548897280",
    "text" : "Opossums: The Unsung Heroes Against Lyme Disease And Other Tick-Borne Diseases http:\/\/t.co\/6qrOSRGwXo via @theinquisitr",
    "id" : 603687947548897280,
    "created_at" : "2015-05-27 22:23:17 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 603695829711486976,
  "created_at" : "2015-05-27 22:54:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/h0q6LLYwFC",
      "expanded_url" : "http:\/\/sp.lc\/NwjFp",
      "display_url" : "sp.lc\/NwjFp"
    } ]
  },
  "geo" : { },
  "id_str" : "603694932591824897",
  "text" : "RT @benjamincorey: Nebraska votes to abolish the death penalty. A big \"amen\" and a \"hell yeah\" from me! http:\/\/t.co\/h0q6LLYwFC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/h0q6LLYwFC",
        "expanded_url" : "http:\/\/sp.lc\/NwjFp",
        "display_url" : "sp.lc\/NwjFp"
      } ]
    },
    "geo" : { },
    "id_str" : "603691522056331264",
    "text" : "Nebraska votes to abolish the death penalty. A big \"amen\" and a \"hell yeah\" from me! http:\/\/t.co\/h0q6LLYwFC",
    "id" : 603691522056331264,
    "created_at" : "2015-05-27 22:37:29 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 603694932591824897,
  "created_at" : "2015-05-27 22:51:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "indices" : [ 3, 14 ],
      "id_str" : "46213956",
      "id" : 46213956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603675918834540544",
  "text" : "RT @JamilSmith: Slow clap for Nebraska, which just became the first red state in more than 40 years to abolish the death penalty. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/qdnRq0YZOl",
        "expanded_url" : "http:\/\/nyti.ms\/1cjKtF8",
        "display_url" : "nyti.ms\/1cjKtF8"
      } ]
    },
    "geo" : { },
    "id_str" : "603673661707419648",
    "text" : "Slow clap for Nebraska, which just became the first red state in more than 40 years to abolish the death penalty. http:\/\/t.co\/qdnRq0YZOl",
    "id" : 603673661707419648,
    "created_at" : "2015-05-27 21:26:31 +0000",
    "user" : {
      "name" : "Jamil Smith",
      "screen_name" : "JamilSmith",
      "protected" : false,
      "id_str" : "46213956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760482723853168644\/ndDX2s1z_normal.jpg",
      "id" : 46213956,
      "verified" : true
    }
  },
  "id" : 603675918834540544,
  "created_at" : "2015-05-27 21:35:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/BK2KGRNVt9",
      "expanded_url" : "http:\/\/bit.ly\/1dyrto2",
      "display_url" : "bit.ly\/1dyrto2"
    } ]
  },
  "geo" : { },
  "id_str" : "603650113345556480",
  "text" : "RT @holycutenesss: Small bird takes a bath in man's hands http:\/\/t.co\/BK2KGRNVt9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/BK2KGRNVt9",
        "expanded_url" : "http:\/\/bit.ly\/1dyrto2",
        "display_url" : "bit.ly\/1dyrto2"
      } ]
    },
    "geo" : { },
    "id_str" : "603648364358541312",
    "text" : "Small bird takes a bath in man's hands http:\/\/t.co\/BK2KGRNVt9",
    "id" : 603648364358541312,
    "created_at" : "2015-05-27 19:45:59 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 603650113345556480,
  "created_at" : "2015-05-27 19:52:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Watts",
      "screen_name" : "AlanWattsDaily",
      "indices" : [ 3, 18 ],
      "id_str" : "77394327",
      "id" : 77394327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603596871962075137",
  "text" : "RT @AlanWattsDaily: I am chained to fear only so long as I am trying to get away from it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509316627629080576",
    "text" : "I am chained to fear only so long as I am trying to get away from it.",
    "id" : 509316627629080576,
    "created_at" : "2014-09-09 12:25:21 +0000",
    "user" : {
      "name" : "Alan Watts",
      "screen_name" : "AlanWattsDaily",
      "protected" : false,
      "id_str" : "77394327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431104967299321856\/z0auawQq_normal.jpeg",
      "id" : 77394327,
      "verified" : false
    }
  },
  "id" : 603596871962075137,
  "created_at" : "2015-05-27 16:21:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Bovill",
      "screen_name" : "HBovill",
      "indices" : [ 3, 11 ],
      "id_str" : "826826574",
      "id" : 826826574
    }, {
      "name" : "Greer",
      "screen_name" : "LewisPRIDESFan",
      "indices" : [ 108, 123 ],
      "id_str" : "2647555092",
      "id" : 2647555092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Raven",
      "indices" : [ 44, 50 ]
    }, {
      "text" : "Islay",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603347502419550208",
  "text" : "RT @HBovill: The first time I'd seen a wild #Raven -at the Oa Peninsula on #Islay last week. Especially for @LewisPRIDESFan Greer! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Greer",
        "screen_name" : "LewisPRIDESFan",
        "indices" : [ 95, 110 ],
        "id_str" : "2647555092",
        "id" : 2647555092
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HBovill\/status\/602905939801460738\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/EqZA6JuiuQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF3zwcCWMAAILdb.jpg",
        "id_str" : "602905938622820352",
        "id" : 602905938622820352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF3zwcCWMAAILdb.jpg",
        "sizes" : [ {
          "h" : 2262,
          "resize" : "fit",
          "w" : 3018
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EqZA6JuiuQ"
      } ],
      "hashtags" : [ {
        "text" : "Raven",
        "indices" : [ 31, 37 ]
      }, {
        "text" : "Islay",
        "indices" : [ 62, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602905939801460738",
    "text" : "The first time I'd seen a wild #Raven -at the Oa Peninsula on #Islay last week. Especially for @LewisPRIDESFan Greer! http:\/\/t.co\/EqZA6JuiuQ",
    "id" : 602905939801460738,
    "created_at" : "2015-05-25 18:35:52 +0000",
    "user" : {
      "name" : "Helen Bovill",
      "screen_name" : "HBovill",
      "protected" : false,
      "id_str" : "826826574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475605646750932992\/PwmRl_5N_normal.jpeg",
      "id" : 826826574,
      "verified" : false
    }
  },
  "id" : 603347502419550208,
  "created_at" : "2015-05-26 23:50:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 3, 17 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603339493425418240",
  "text" : "RT @TheTweetOfGod: Once you start allowing gay people to marry, what's next? Going on with your life in exactly the same way you did before\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "slipperyslope",
        "indices" : [ 122, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466648286141894656",
    "text" : "Once you start allowing gay people to marry, what's next? Going on with your life in exactly the same way you did before? #slipperyslope",
    "id" : 466648286141894656,
    "created_at" : "2014-05-14 18:36:35 +0000",
    "user" : {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "protected" : false,
      "id_str" : "204832963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577952058680070144\/6hlNZ0_Y_normal.jpeg",
      "id" : 204832963,
      "verified" : false
    }
  },
  "id" : 603339493425418240,
  "created_at" : "2015-05-26 23:18:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603321229311877122",
  "text" : "Hot feet!! Meh.",
  "id" : 603321229311877122,
  "created_at" : "2015-05-26 22:06:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel A Davis",
      "screen_name" : "vagabondbaker",
      "indices" : [ 3, 17 ],
      "id_str" : "497361285",
      "id" : 497361285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "housesparrow",
      "indices" : [ 28, 41 ]
    }, {
      "text" : "Springwatch",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603319301001650177",
  "text" : "RT @vagabondbaker: Save the #housesparrow! Thanks #Springwatch! Had pleasure of rescuing\/raising one in NZ, such an individual! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vagabondbaker\/status\/603289650631938048\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/sGaHVMvWSe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF9QWYGWMAAKwrB.jpg",
        "id_str" : "603289220447350784",
        "id" : 603289220447350784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF9QWYGWMAAKwrB.jpg",
        "sizes" : [ {
          "h" : 476,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 431
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 431
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 431
        } ],
        "display_url" : "pic.twitter.com\/sGaHVMvWSe"
      } ],
      "hashtags" : [ {
        "text" : "housesparrow",
        "indices" : [ 9, 22 ]
      }, {
        "text" : "Springwatch",
        "indices" : [ 31, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603289650631938048",
    "text" : "Save the #housesparrow! Thanks #Springwatch! Had pleasure of rescuing\/raising one in NZ, such an individual! http:\/\/t.co\/sGaHVMvWSe",
    "id" : 603289650631938048,
    "created_at" : "2015-05-26 20:00:35 +0000",
    "user" : {
      "name" : "Rachel A Davis",
      "screen_name" : "vagabondbaker",
      "protected" : false,
      "id_str" : "497361285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589707204284022784\/6OncyMtL_normal.jpg",
      "id" : 497361285,
      "verified" : false
    }
  },
  "id" : 603319301001650177,
  "created_at" : "2015-05-26 21:58:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/522604372065140736\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/4QKHGPD8Em",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Cp6EWCEAAnqYu.jpg",
      "id_str" : "522604371838636032",
      "id" : 522604371838636032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Cp6EWCEAAnqYu.jpg",
      "sizes" : [ {
        "h" : 443,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 736
      } ],
      "display_url" : "pic.twitter.com\/4QKHGPD8Em"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603281607613652992",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/4QKHGPD8Em",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/522604372065140736\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/4QKHGPD8Em",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Cp6EWCEAAnqYu.jpg",
        "id_str" : "522604371838636032",
        "id" : 522604371838636032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Cp6EWCEAAnqYu.jpg",
        "sizes" : [ {
          "h" : 443,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 736
        } ],
        "display_url" : "pic.twitter.com\/4QKHGPD8Em"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603279472670932992",
    "text" : "http:\/\/t.co\/4QKHGPD8Em",
    "id" : 603279472670932992,
    "created_at" : "2015-05-26 19:20:09 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 603281607613652992,
  "created_at" : "2015-05-26 19:28:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603013270027575296",
  "text" : "RT @FreeRangeKids: My newest phrase: TRAGICAL THINKING. Imagining tragedies in any situation. Like when kids wait in car 5 mins:  http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/stHkqcd8hD",
        "expanded_url" : "http:\/\/bit.ly\/1Q6nwTc",
        "display_url" : "bit.ly\/1Q6nwTc"
      } ]
    },
    "geo" : { },
    "id_str" : "603012412091068416",
    "text" : "My newest phrase: TRAGICAL THINKING. Imagining tragedies in any situation. Like when kids wait in car 5 mins:  http:\/\/t.co\/stHkqcd8hD",
    "id" : 603012412091068416,
    "created_at" : "2015-05-26 01:38:57 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 603013270027575296,
  "created_at" : "2015-05-26 01:42:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Deitz",
      "screen_name" : "JessDeitz",
      "indices" : [ 3, 13 ],
      "id_str" : "2743179005",
      "id" : 2743179005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/YbNc9Nhx90",
      "expanded_url" : "https:\/\/www.facebook.com\/JLDeitzPhotography\/photos\/a.456221531128627.1073741830.456203554463758\/824771150940328\/?l=5b63e989df",
      "display_url" : "facebook.com\/JLDeitzPhotogr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602997117360185344",
  "text" : "RT @JessDeitz: There is more to this Grebe a.k.a. \"Water Witch\" than meets the eye.. read more here-&gt;\nhttps:\/\/t.co\/YbNc9Nhx90 http:\/\/t.co\/5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JessDeitz\/status\/602994744105541634\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/5OxsO8D0w1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF5EhjzWIAA-KD9.jpg",
        "id_str" : "602994743451197440",
        "id" : 602994743451197440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF5EhjzWIAA-KD9.jpg",
        "sizes" : [ {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 632,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 926,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/5OxsO8D0w1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/YbNc9Nhx90",
        "expanded_url" : "https:\/\/www.facebook.com\/JLDeitzPhotography\/photos\/a.456221531128627.1073741830.456203554463758\/824771150940328\/?l=5b63e989df",
        "display_url" : "facebook.com\/JLDeitzPhotogr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "602994744105541634",
    "text" : "There is more to this Grebe a.k.a. \"Water Witch\" than meets the eye.. read more here-&gt;\nhttps:\/\/t.co\/YbNc9Nhx90 http:\/\/t.co\/5OxsO8D0w1",
    "id" : 602994744105541634,
    "created_at" : "2015-05-26 00:28:44 +0000",
    "user" : {
      "name" : "Jess Deitz",
      "screen_name" : "JessDeitz",
      "protected" : false,
      "id_str" : "2743179005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799684589912518656\/wvxM5XiO_normal.jpg",
      "id" : 2743179005,
      "verified" : false
    }
  },
  "id" : 602997117360185344,
  "created_at" : "2015-05-26 00:38:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William J. Bryan",
      "screen_name" : "Will_J_Bryan",
      "indices" : [ 3, 16 ],
      "id_str" : "2719268039",
      "id" : 2719268039
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Will_J_Bryan\/status\/602695661419687936\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/HTri4VQh5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF00fBKVIAAtx36.png",
      "id_str" : "602695632629866496",
      "id" : 602695632629866496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF00fBKVIAAtx36.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 954,
        "resize" : "fit",
        "w" : 715
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 954,
        "resize" : "fit",
        "w" : 715
      } ],
      "display_url" : "pic.twitter.com\/HTri4VQh5E"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Will_J_Bryan\/status\/602695661419687936\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/HTri4VQh5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF00f58VAAEDDis.png",
      "id_str" : "602695647871959041",
      "id" : 602695647871959041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF00f58VAAEDDis.png",
      "sizes" : [ {
        "h" : 863,
        "resize" : "fit",
        "w" : 719
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 863,
        "resize" : "fit",
        "w" : 719
      } ],
      "display_url" : "pic.twitter.com\/HTri4VQh5E"
    } ],
    "hashtags" : [ {
      "text" : "SinglePayerSunday",
      "indices" : [ 18, 36 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 44, 59 ]
    }, {
      "text" : "Ohio",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602996752678047744",
  "text" : "RT @Will_J_Bryan: #SinglePayerSunday Primer #MedicareForAll #Ohio http:\/\/t.co\/HTri4VQh5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Will_J_Bryan\/status\/602695661419687936\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/HTri4VQh5E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF00fBKVIAAtx36.png",
        "id_str" : "602695632629866496",
        "id" : 602695632629866496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF00fBKVIAAtx36.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 954,
          "resize" : "fit",
          "w" : 715
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 801,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 954,
          "resize" : "fit",
          "w" : 715
        } ],
        "display_url" : "pic.twitter.com\/HTri4VQh5E"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Will_J_Bryan\/status\/602695661419687936\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/HTri4VQh5E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF00f58VAAEDDis.png",
        "id_str" : "602695647871959041",
        "id" : 602695647871959041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF00f58VAAEDDis.png",
        "sizes" : [ {
          "h" : 863,
          "resize" : "fit",
          "w" : 719
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 863,
          "resize" : "fit",
          "w" : 719
        } ],
        "display_url" : "pic.twitter.com\/HTri4VQh5E"
      } ],
      "hashtags" : [ {
        "text" : "SinglePayerSunday",
        "indices" : [ 0, 18 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 26, 41 ]
      }, {
        "text" : "Ohio",
        "indices" : [ 42, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602695661419687936",
    "text" : "#SinglePayerSunday Primer #MedicareForAll #Ohio http:\/\/t.co\/HTri4VQh5E",
    "id" : 602695661419687936,
    "created_at" : "2015-05-25 04:40:17 +0000",
    "user" : {
      "name" : "William J. Bryan",
      "screen_name" : "Will_J_Bryan",
      "protected" : false,
      "id_str" : "2719268039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491465032329609216\/nwOZe8sb_normal.jpeg",
      "id" : 2719268039,
      "verified" : false
    }
  },
  "id" : 602996752678047744,
  "created_at" : "2015-05-26 00:36:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "indices" : [ 3, 18 ],
      "id_str" : "1323776491",
      "id" : 1323776491
    }, {
      "name" : "The J\u00FCrgenmeister",
      "screen_name" : "postmoltmannian",
      "indices" : [ 113, 129 ],
      "id_str" : "807027204",
      "id" : 807027204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/xKuwhLc0hM",
      "expanded_url" : "http:\/\/bit.ly\/1Fc5olM",
      "display_url" : "bit.ly\/1Fc5olM"
    } ]
  },
  "geo" : { },
  "id_str" : "602996038673276928",
  "text" : "RT @humblethinker1: The Annihilation of Hell\nwith forward by Moltmann\n\nLooks interesting: http:\/\/t.co\/xKuwhLc0hM @postmoltmannian",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The J\u00FCrgenmeister",
        "screen_name" : "postmoltmannian",
        "indices" : [ 93, 109 ],
        "id_str" : "807027204",
        "id" : 807027204
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/xKuwhLc0hM",
        "expanded_url" : "http:\/\/bit.ly\/1Fc5olM",
        "display_url" : "bit.ly\/1Fc5olM"
      } ]
    },
    "geo" : { },
    "id_str" : "602993686582992896",
    "text" : "The Annihilation of Hell\nwith forward by Moltmann\n\nLooks interesting: http:\/\/t.co\/xKuwhLc0hM @postmoltmannian",
    "id" : 602993686582992896,
    "created_at" : "2015-05-26 00:24:32 +0000",
    "user" : {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "protected" : false,
      "id_str" : "1323776491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744730630085173249\/ApIVKrhX_normal.jpg",
      "id" : 1323776491,
      "verified" : false
    }
  },
  "id" : 602996038673276928,
  "created_at" : "2015-05-26 00:33:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "King Alfred",
      "screen_name" : "KingDouyeAlfred",
      "indices" : [ 3, 19 ],
      "id_str" : "440690311",
      "id" : 440690311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602875902393999360",
  "text" : "RT @KingDouyeAlfred: Apartheid was \"legal\"\nSlavery was \"legal\"\nColonialism was \"legal\"\n\nLegality is a construct of the powerful\n\nNot of jus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574650474407849984",
    "text" : "Apartheid was \"legal\"\nSlavery was \"legal\"\nColonialism was \"legal\"\n\nLegality is a construct of the powerful\n\nNot of justice",
    "id" : 574650474407849984,
    "created_at" : "2015-03-08 19:18:44 +0000",
    "user" : {
      "name" : "King Alfred",
      "screen_name" : "KingDouyeAlfred",
      "protected" : false,
      "id_str" : "440690311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733674377255002113\/RSg5-4fs_normal.jpg",
      "id" : 440690311,
      "verified" : false
    }
  },
  "id" : 602875902393999360,
  "created_at" : "2015-05-25 16:36:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abandoned Places",
      "screen_name" : "abandonedspaces",
      "indices" : [ 3, 19 ],
      "id_str" : "2297978858",
      "id" : 2297978858
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/abandonedspaces\/status\/550270716781031425\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/JIjtE0jZrZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6L0TPyCcAEvwdZ.jpg",
      "id_str" : "550270715983720449",
      "id" : 550270715983720449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6L0TPyCcAEvwdZ.jpg",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 1243
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JIjtE0jZrZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602861214939619329",
  "text" : "RT @abandonedspaces: Last stop... http:\/\/t.co\/JIjtE0jZrZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abandonedspaces\/status\/550270716781031425\/photo\/1",
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/JIjtE0jZrZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6L0TPyCcAEvwdZ.jpg",
        "id_str" : "550270715983720449",
        "id" : 550270715983720449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6L0TPyCcAEvwdZ.jpg",
        "sizes" : [ {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 1243
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JIjtE0jZrZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "550270716781031425",
    "text" : "Last stop... http:\/\/t.co\/JIjtE0jZrZ",
    "id" : 550270716781031425,
    "created_at" : "2014-12-31 12:42:17 +0000",
    "user" : {
      "name" : "Abandoned Places",
      "screen_name" : "abandonedspaces",
      "protected" : false,
      "id_str" : "2297978858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579312495707484161\/NTtZCCIj_normal.jpg",
      "id" : 2297978858,
      "verified" : false
    }
  },
  "id" : 602861214939619329,
  "created_at" : "2015-05-25 15:38:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spanking",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "obedience",
      "indices" : [ 91, 101 ]
    }, {
      "text" : "authority",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/t39T3jPVUK",
      "expanded_url" : "http:\/\/huff.to\/1stUTaE",
      "display_url" : "huff.to\/1stUTaE"
    } ]
  },
  "geo" : { },
  "id_str" : "602846219128418306",
  "text" : "James Dobson: Beat Your Dog, Spank Your Kid, Go to Heaven http:\/\/t.co\/t39T3jPVUK #spanking #obedience #authority",
  "id" : 602846219128418306,
  "created_at" : "2015-05-25 14:38:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Dot",
      "screen_name" : "dailydot",
      "indices" : [ 3, 12 ],
      "id_str" : "211620426",
      "id" : 211620426
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailydot\/status\/602801485857062912\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/eZ7TBAo5lz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF2UwcHUsAAwx4h.jpg",
      "id_str" : "602801485039054848",
      "id" : 602801485039054848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF2UwcHUsAAwx4h.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eZ7TBAo5lz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/DySywlC1sT",
      "expanded_url" : "http:\/\/trib.al\/ZjnU8WA",
      "display_url" : "trib.al\/ZjnU8WA"
    } ]
  },
  "geo" : { },
  "id_str" : "602835900364632065",
  "text" : "RT @dailydot: Why does this crow need to break into this house so badly? http:\/\/t.co\/DySywlC1sT http:\/\/t.co\/eZ7TBAo5lz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailydot\/status\/602801485857062912\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/eZ7TBAo5lz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF2UwcHUsAAwx4h.jpg",
        "id_str" : "602801485039054848",
        "id" : 602801485039054848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF2UwcHUsAAwx4h.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eZ7TBAo5lz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/DySywlC1sT",
        "expanded_url" : "http:\/\/trib.al\/ZjnU8WA",
        "display_url" : "trib.al\/ZjnU8WA"
      } ]
    },
    "geo" : { },
    "id_str" : "602801485857062912",
    "text" : "Why does this crow need to break into this house so badly? http:\/\/t.co\/DySywlC1sT http:\/\/t.co\/eZ7TBAo5lz",
    "id" : 602801485857062912,
    "created_at" : "2015-05-25 11:40:48 +0000",
    "user" : {
      "name" : "The Daily Dot",
      "screen_name" : "dailydot",
      "protected" : false,
      "id_str" : "211620426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748197754174844928\/mGPSWPg__normal.jpg",
      "id" : 211620426,
      "verified" : true
    }
  },
  "id" : 602835900364632065,
  "created_at" : "2015-05-25 13:57:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "indices" : [ 3, 12 ],
      "id_str" : "2375492109",
      "id" : 2375492109
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/602834198890729472\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/f5nB8lrGA2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF2ygn5WMAESwtQ.jpg",
      "id_str" : "602834198672584705",
      "id" : 602834198672584705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF2ygn5WMAESwtQ.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 981,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 654,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/f5nB8lrGA2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602834275491323905",
  "text" : "RT @cw_mills: Baby sparrow waits patiently for mum http:\/\/t.co\/f5nB8lrGA2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/602834198890729472\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/f5nB8lrGA2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF2ygn5WMAESwtQ.jpg",
        "id_str" : "602834198672584705",
        "id" : 602834198672584705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF2ygn5WMAESwtQ.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 981,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 654,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/f5nB8lrGA2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602834198890729472",
    "text" : "Baby sparrow waits patiently for mum http:\/\/t.co\/f5nB8lrGA2",
    "id" : 602834198890729472,
    "created_at" : "2015-05-25 13:50:47 +0000",
    "user" : {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "protected" : false,
      "id_str" : "2375492109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648076476613533696\/1aq5VLpS_normal.jpg",
      "id" : 2375492109,
      "verified" : false
    }
  },
  "id" : 602834275491323905,
  "created_at" : "2015-05-25 13:51:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmers of Canada",
      "screen_name" : "FarmersOfCanada",
      "indices" : [ 3, 19 ],
      "id_str" : "1117252483",
      "id" : 1117252483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontmissathing",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602823346095529984",
  "text" : "RT @FarmersOfCanada: Proper name for their bangs is dossan.  Don\u2019t be fooled \u2013 they can see perfectly. #dontmissathing http:\/\/t.co\/9Tb74RPh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FarmersOfCanada\/status\/602817974827929600\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/9Tb74RPhLA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF2jwNZW8AAzNZQ.jpg",
        "id_str" : "602817973762584576",
        "id" : 602817973762584576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF2jwNZW8AAzNZQ.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/9Tb74RPhLA"
      } ],
      "hashtags" : [ {
        "text" : "dontmissathing",
        "indices" : [ 82, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602817974827929600",
    "text" : "Proper name for their bangs is dossan.  Don\u2019t be fooled \u2013 they can see perfectly. #dontmissathing http:\/\/t.co\/9Tb74RPhLA",
    "id" : 602817974827929600,
    "created_at" : "2015-05-25 12:46:19 +0000",
    "user" : {
      "name" : "Farmers of Canada",
      "screen_name" : "FarmersOfCanada",
      "protected" : false,
      "id_str" : "1117252483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787824728719306752\/sz_-_Kpa_normal.jpg",
      "id" : 1117252483,
      "verified" : false
    }
  },
  "id" : 602823346095529984,
  "created_at" : "2015-05-25 13:07:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602652063147937792",
  "text" : "ugh.. spent too much reading about quiverfull families today.. : (",
  "id" : 602652063147937792,
  "created_at" : "2015-05-25 01:47:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602579739061157888",
  "text" : "RT @RustBeltRebel: what do u think those girls are going to do? when every breathing moment of ur life is *god*--do u just give god up?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602578186342305792",
    "text" : "what do u think those girls are going to do? when every breathing moment of ur life is *god*--do u just give god up?",
    "id" : 602578186342305792,
    "created_at" : "2015-05-24 20:53:29 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 602579739061157888,
  "created_at" : "2015-05-24 20:59:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/MoEh9r6FZT",
      "expanded_url" : "http:\/\/bit.ly\/1FoklDp",
      "display_url" : "bit.ly\/1FoklDp"
    } ]
  },
  "geo" : { },
  "id_str" : "602529260092444672",
  "text" : "RT @OMGFacts: This Architect Must Have A Sense Of Humor...Take A Look At This Building's Overhead View --&gt; http:\/\/t.co\/MoEh9r6FZT http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OMGFacts\/status\/602528007174127616\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/GQCqlvD8Ip",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFycB7dWYAEXjse.jpg",
        "id_str" : "602528007115399169",
        "id" : 602528007115399169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFycB7dWYAEXjse.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GQCqlvD8Ip"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/MoEh9r6FZT",
        "expanded_url" : "http:\/\/bit.ly\/1FoklDp",
        "display_url" : "bit.ly\/1FoklDp"
      } ]
    },
    "geo" : { },
    "id_str" : "602528007174127616",
    "text" : "This Architect Must Have A Sense Of Humor...Take A Look At This Building's Overhead View --&gt; http:\/\/t.co\/MoEh9r6FZT http:\/\/t.co\/GQCqlvD8Ip",
    "id" : 602528007174127616,
    "created_at" : "2015-05-24 17:34:05 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 602529260092444672,
  "created_at" : "2015-05-24 17:39:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 3, 18 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "creation",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/pbXrG2A7ed",
      "expanded_url" : "https:\/\/instagram.com\/p\/3Er5JGInZy\/",
      "display_url" : "instagram.com\/p\/3Er5JGInZy\/"
    } ]
  },
  "geo" : { },
  "id_str" : "602528475996692481",
  "text" : "RT @SkypilotOfHope: Hello, baby Mourning Dove. Thanks for being you. #nature #creation https:\/\/t.co\/pbXrG2A7ed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 49, 56 ]
      }, {
        "text" : "creation",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/pbXrG2A7ed",
        "expanded_url" : "https:\/\/instagram.com\/p\/3Er5JGInZy\/",
        "display_url" : "instagram.com\/p\/3Er5JGInZy\/"
      } ]
    },
    "geo" : { },
    "id_str" : "602528036643282946",
    "text" : "Hello, baby Mourning Dove. Thanks for being you. #nature #creation https:\/\/t.co\/pbXrG2A7ed",
    "id" : 602528036643282946,
    "created_at" : "2015-05-24 17:34:13 +0000",
    "user" : {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "protected" : false,
      "id_str" : "140291463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800179726635663360\/f7iKj4AL_normal.jpg",
      "id" : 140291463,
      "verified" : false
    }
  },
  "id" : 602528475996692481,
  "created_at" : "2015-05-24 17:35:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602502875537891329",
  "geo" : { },
  "id_str" : "602507706927325185",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides no.. just voicing the characters. :  )",
  "id" : 602507706927325185,
  "in_reply_to_status_id" : 602502875537891329,
  "created_at" : "2015-05-24 16:13:26 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica",
      "screen_name" : "JessyLamb44",
      "indices" : [ 3, 15 ],
      "id_str" : "1475613240",
      "id" : 1475613240
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JessyLamb44\/status\/602486032739741696\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/iBFeTcJKWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFx11K1WAAAjkm3.jpg",
      "id_str" : "602486006462414848",
      "id" : 602486006462414848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFx11K1WAAAjkm3.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 579
      } ],
      "display_url" : "pic.twitter.com\/iBFeTcJKWP"
    } ],
    "hashtags" : [ {
      "text" : "dogvcat",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602500939442954240",
  "text" : "RT @JessyLamb44: Refereeing a staring competition. We're on round 36. Pup has no chance with this wise one #dogvcat http:\/\/t.co\/iBFeTcJKWP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JessyLamb44\/status\/602486032739741696\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/iBFeTcJKWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFx11K1WAAAjkm3.jpg",
        "id_str" : "602486006462414848",
        "id" : 602486006462414848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFx11K1WAAAjkm3.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 579
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 579
        } ],
        "display_url" : "pic.twitter.com\/iBFeTcJKWP"
      } ],
      "hashtags" : [ {
        "text" : "dogvcat",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602486032739741696",
    "text" : "Refereeing a staring competition. We're on round 36. Pup has no chance with this wise one #dogvcat http:\/\/t.co\/iBFeTcJKWP",
    "id" : 602486032739741696,
    "created_at" : "2015-05-24 14:47:18 +0000",
    "user" : {
      "name" : "Jessica",
      "screen_name" : "JessyLamb44",
      "protected" : false,
      "id_str" : "1475613240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787295216235638784\/Y33rfzg-_normal.jpg",
      "id" : 1475613240,
      "verified" : false
    }
  },
  "id" : 602500939442954240,
  "created_at" : "2015-05-24 15:46:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602500818173034497",
  "text" : "DH hosting playdate with his RPG friends today.. picnic style. Sunny day. Lots of laughing out there!",
  "id" : 602500818173034497,
  "created_at" : "2015-05-24 15:46:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602485140498030592",
  "text" : "RT @benjamincorey: 7 years submerged in theology and I have more questions now than answers- so I am learning to follow Jesus while embraci\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601881075741241344",
    "text" : "7 years submerged in theology and I have more questions now than answers- so I am learning to follow Jesus while embracing the tension.",
    "id" : 601881075741241344,
    "created_at" : "2015-05-22 22:43:25 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 602485140498030592,
  "created_at" : "2015-05-24 14:43:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Flood",
      "screen_name" : "therebelgod",
      "indices" : [ 3, 15 ],
      "id_str" : "320235077",
      "id" : 320235077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Ck3fQAKuax",
      "expanded_url" : "http:\/\/dlvr.it\/9xc763",
      "display_url" : "dlvr.it\/9xc763"
    } ]
  },
  "geo" : { },
  "id_str" : "602484872205205504",
  "text" : "RT @therebelgod: NEW POST: The Bible is Flawed and Inspired: Learning to Read Christocentrically with Karl Barth http:\/\/t.co\/Ck3fQAKuax",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Ck3fQAKuax",
        "expanded_url" : "http:\/\/dlvr.it\/9xc763",
        "display_url" : "dlvr.it\/9xc763"
      } ]
    },
    "geo" : { },
    "id_str" : "602304528185044992",
    "text" : "NEW POST: The Bible is Flawed and Inspired: Learning to Read Christocentrically with Karl Barth http:\/\/t.co\/Ck3fQAKuax",
    "id" : 602304528185044992,
    "created_at" : "2015-05-24 02:46:04 +0000",
    "user" : {
      "name" : "Derek Flood",
      "screen_name" : "therebelgod",
      "protected" : false,
      "id_str" : "320235077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526156541536133120\/5efXtUZN_normal.jpeg",
      "id" : 320235077,
      "verified" : false
    }
  },
  "id" : 602484872205205504,
  "created_at" : "2015-05-24 14:42:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "indices" : [ 3, 15 ],
      "id_str" : "629225037",
      "id" : 629225037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602477102735196160",
  "text" : "RT @AndyBoxHill: Hang on, there's an imposter amongst the ranks. You're not a chicken. You know who you are Mrs Redleg Partridge. \uD83D\uDE0A http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/602369535191216128\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/IGQ4BkxE1S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFwL39iWIAEqEoq.jpg",
        "id_str" : "602369506200133633",
        "id" : 602369506200133633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFwL39iWIAEqEoq.jpg",
        "sizes" : [ {
          "h" : 857,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 717
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 717
        } ],
        "display_url" : "pic.twitter.com\/IGQ4BkxE1S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602369535191216128",
    "text" : "Hang on, there's an imposter amongst the ranks. You're not a chicken. You know who you are Mrs Redleg Partridge. \uD83D\uDE0A http:\/\/t.co\/IGQ4BkxE1S",
    "id" : 602369535191216128,
    "created_at" : "2015-05-24 07:04:23 +0000",
    "user" : {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "protected" : false,
      "id_str" : "629225037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543479254550593536\/nw_rTozc_normal.jpeg",
      "id" : 629225037,
      "verified" : false
    }
  },
  "id" : 602477102735196160,
  "created_at" : "2015-05-24 14:11:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hargrove",
      "screen_name" : "johnjhargrove",
      "indices" : [ 3, 17 ],
      "id_str" : "393111194",
      "id" : 393111194
    }, {
      "name" : "CNNFilms",
      "screen_name" : "CNNFilms",
      "indices" : [ 30, 39 ],
      "id_str" : "1633723646",
      "id" : 1633723646
    }, {
      "name" : "SeaWorld",
      "screen_name" : "SeaWorld",
      "indices" : [ 64, 73 ],
      "id_str" : "94618543",
      "id" : 94618543
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602271734507687936",
  "text" : "RT @johnjhargrove: #Blackfish @CNNFilms another manipulation by @SeaWorld saying they only have 5 whales who were captured. Those are the o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNNFilms",
        "screen_name" : "CNNFilms",
        "indices" : [ 11, 20 ],
        "id_str" : "1633723646",
        "id" : 1633723646
      }, {
        "name" : "SeaWorld",
        "screen_name" : "SeaWorld",
        "indices" : [ 45, 54 ],
        "id_str" : "94618543",
        "id" : 94618543
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602267258505822208",
    "text" : "#Blackfish @CNNFilms another manipulation by @SeaWorld saying they only have 5 whales who were captured. Those are the only ones still alive",
    "id" : 602267258505822208,
    "created_at" : "2015-05-24 00:17:58 +0000",
    "user" : {
      "name" : "John Hargrove",
      "screen_name" : "johnjhargrove",
      "protected" : false,
      "id_str" : "393111194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716028746067808257\/MR_UTBNZ_normal.jpg",
      "id" : 393111194,
      "verified" : false
    }
  },
  "id" : 602271734507687936,
  "created_at" : "2015-05-24 00:35:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikko Alanne",
      "screen_name" : "MikkoAlanne",
      "indices" : [ 3, 15 ],
      "id_str" : "437874669",
      "id" : 437874669
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/motherboard\/status\/602268295941652480\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MVTCRIIafd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFihOI7XIAEZXJS.jpg",
      "id_str" : "601407814540664833",
      "id" : 601407814540664833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFihOI7XIAEZXJS.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MVTCRIIafd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/s6E6Un5qtQ",
      "expanded_url" : "http:\/\/bit.ly\/1JwwZU7",
      "display_url" : "bit.ly\/1JwwZU7"
    } ]
  },
  "geo" : { },
  "id_str" : "602271311042355200",
  "text" : "RT @MikkoAlanne: Six men spent 520 days locked in a room to see if we could live on Mars:\nhttp:\/\/t.co\/s6E6Un5qtQ http:\/\/t.co\/MVTCRIIafd v @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Motherboard",
        "screen_name" : "motherboard",
        "indices" : [ 121, 133 ],
        "id_str" : "56510427",
        "id" : 56510427
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/motherboard\/status\/602268295941652480\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/MVTCRIIafd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFihOI7XIAEZXJS.jpg",
        "id_str" : "601407814540664833",
        "id" : 601407814540664833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFihOI7XIAEZXJS.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MVTCRIIafd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/s6E6Un5qtQ",
        "expanded_url" : "http:\/\/bit.ly\/1JwwZU7",
        "display_url" : "bit.ly\/1JwwZU7"
      } ]
    },
    "geo" : { },
    "id_str" : "602268566889443330",
    "text" : "Six men spent 520 days locked in a room to see if we could live on Mars:\nhttp:\/\/t.co\/s6E6Un5qtQ http:\/\/t.co\/MVTCRIIafd v @motherboard",
    "id" : 602268566889443330,
    "created_at" : "2015-05-24 00:23:10 +0000",
    "user" : {
      "name" : "Mikko Alanne",
      "screen_name" : "MikkoAlanne",
      "protected" : false,
      "id_str" : "437874669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796618707166334976\/mVGJkKOU_normal.jpg",
      "id" : 437874669,
      "verified" : false
    }
  },
  "id" : 602271311042355200,
  "created_at" : "2015-05-24 00:34:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grim_Chickn",
      "screen_name" : "grm_chikn",
      "indices" : [ 3, 13 ],
      "id_str" : "842718474",
      "id" : 842718474
    }, {
      "name" : "Jeffrey Ventre",
      "screen_name" : "jeffrey_ventre",
      "indices" : [ 74, 89 ],
      "id_str" : "475165737",
      "id" : 475165737
    }, {
      "name" : "John Hargrove",
      "screen_name" : "johnjhargrove",
      "indices" : [ 96, 110 ],
      "id_str" : "393111194",
      "id" : 393111194
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602169967426023426",
  "text" : "RT @grm_chikn: Watch #Blackfish Saturday &amp; join some of the cast inc. @jeffrey_ventre &amp; @johnjhargrove for a LIVE social media event http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeffrey Ventre",
        "screen_name" : "jeffrey_ventre",
        "indices" : [ 59, 74 ],
        "id_str" : "475165737",
        "id" : 475165737
      }, {
        "name" : "John Hargrove",
        "screen_name" : "johnjhargrove",
        "indices" : [ 81, 95 ],
        "id_str" : "393111194",
        "id" : 393111194
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/grm_chikn\/status\/601938108649644034\/photo\/1",
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/6i1zoT0jrL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFfNn6MWAAAm7_Y.jpg",
        "id_str" : "601175160796872704",
        "id" : 601175160796872704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFfNn6MWAAAm7_Y.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 735,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 735,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 735,
          "resize" : "fit",
          "w" : 490
        } ],
        "display_url" : "pic.twitter.com\/6i1zoT0jrL"
      } ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 6, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601938108649644034",
    "text" : "Watch #Blackfish Saturday &amp; join some of the cast inc. @jeffrey_ventre &amp; @johnjhargrove for a LIVE social media event http:\/\/t.co\/6i1zoT0jrL",
    "id" : 601938108649644034,
    "created_at" : "2015-05-23 02:30:03 +0000",
    "user" : {
      "name" : "Grim_Chickn",
      "screen_name" : "grm_chikn",
      "protected" : false,
      "id_str" : "842718474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697811042445893632\/bbsmifaK_normal.png",
      "id" : 842718474,
      "verified" : false
    }
  },
  "id" : 602169967426023426,
  "created_at" : "2015-05-23 17:51:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Binksy \/ Jackie",
      "screen_name" : "jabinks846",
      "indices" : [ 3, 14 ],
      "id_str" : "2700353103",
      "id" : 2700353103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602169750525980672",
  "text" : "RT @jabinks846: little dunnock chick ( I think) was happy to perch on my hand in the garden before flying off after a little rest http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jabinks846\/status\/601756031090298881\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/VghjP7oY7Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFnd6oYWAAAeNJQ.jpg",
        "id_str" : "601756024572346368",
        "id" : 601756024572346368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFnd6oYWAAAeNJQ.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/VghjP7oY7Q"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/jabinks846\/status\/601756031090298881\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/VghjP7oY7Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFnd6oWWIAAXyD4.jpg",
        "id_str" : "601756024563965952",
        "id" : 601756024563965952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFnd6oWWIAAXyD4.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/VghjP7oY7Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601756031090298881",
    "text" : "little dunnock chick ( I think) was happy to perch on my hand in the garden before flying off after a little rest http:\/\/t.co\/VghjP7oY7Q",
    "id" : 601756031090298881,
    "created_at" : "2015-05-22 14:26:32 +0000",
    "user" : {
      "name" : "Binksy \/ Jackie",
      "screen_name" : "jabinks846",
      "protected" : false,
      "id_str" : "2700353103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735826657391595521\/n3KBNey9_normal.jpg",
      "id" : 2700353103,
      "verified" : false
    }
  },
  "id" : 602169750525980672,
  "created_at" : "2015-05-23 17:50:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "angeledenUK",
      "screen_name" : "angeledenUK",
      "indices" : [ 3, 15 ],
      "id_str" : "3350851121",
      "id" : 3350851121
    }, {
      "name" : "Joy Elizabeth Briggs",
      "screen_name" : "joyelizabethb",
      "indices" : [ 43, 57 ],
      "id_str" : "1442224590",
      "id" : 1442224590
    }, {
      "name" : "Joanne Clements",
      "screen_name" : "joannekarma",
      "indices" : [ 58, 70 ],
      "id_str" : "232144061",
      "id" : 232144061
    }, {
      "name" : "Belper and Proud",
      "screen_name" : "BelperAndProud",
      "indices" : [ 71, 86 ],
      "id_str" : "1676778325",
      "id" : 1676778325
    }, {
      "name" : "Corridor Arts",
      "screen_name" : "CorridorArts",
      "indices" : [ 87, 100 ],
      "id_str" : "103375027",
      "id" : 103375027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woollenwoods",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602169643919343616",
  "text" : "RT @AngelEdenUK: Down in the #woollenwoods @joyelizabethb @joannekarma @BelperAndProud @CorridorArts @VolArtsWeek @BBCGetCreative http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joy Elizabeth Briggs",
        "screen_name" : "joyelizabethb",
        "indices" : [ 26, 40 ],
        "id_str" : "1442224590",
        "id" : 1442224590
      }, {
        "name" : "Joanne Clements",
        "screen_name" : "joannekarma",
        "indices" : [ 41, 53 ],
        "id_str" : "232144061",
        "id" : 232144061
      }, {
        "name" : "Belper and Proud",
        "screen_name" : "BelperAndProud",
        "indices" : [ 54, 69 ],
        "id_str" : "1676778325",
        "id" : 1676778325
      }, {
        "name" : "Corridor Arts",
        "screen_name" : "CorridorArts",
        "indices" : [ 70, 83 ],
        "id_str" : "103375027",
        "id" : 103375027
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AngelEdenUK\/status\/602160621761736704\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KWnUO9oKb7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFtNtX7W8AA0fYZ.jpg",
        "id_str" : "602160417096527872",
        "id" : 602160417096527872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFtNtX7W8AA0fYZ.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KWnUO9oKb7"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AngelEdenUK\/status\/602160621761736704\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KWnUO9oKb7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFtNtX0WgAAYoOY.jpg",
        "id_str" : "602160417067139072",
        "id" : 602160417067139072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFtNtX0WgAAYoOY.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KWnUO9oKb7"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AngelEdenUK\/status\/602160621761736704\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KWnUO9oKb7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFtNtXuW8AEfEOd.jpg",
        "id_str" : "602160417042001921",
        "id" : 602160417042001921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFtNtXuW8AEfEOd.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KWnUO9oKb7"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AngelEdenUK\/status\/602160621761736704\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KWnUO9oKb7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFtNtZNXIAIXoV3.jpg",
        "id_str" : "602160417440473090",
        "id" : 602160417440473090,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFtNtZNXIAIXoV3.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KWnUO9oKb7"
      } ],
      "hashtags" : [ {
        "text" : "woollenwoods",
        "indices" : [ 12, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602160621761736704",
    "text" : "Down in the #woollenwoods @joyelizabethb @joannekarma @BelperAndProud @CorridorArts @VolArtsWeek @BBCGetCreative http:\/\/t.co\/KWnUO9oKb7",
    "id" : 602160621761736704,
    "created_at" : "2015-05-23 17:14:14 +0000",
    "user" : {
      "name" : "Anne",
      "screen_name" : "anneclarkHM",
      "protected" : false,
      "id_str" : "52795041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773895828914180096\/EFlS1Gzx_normal.jpg",
      "id" : 52795041,
      "verified" : false
    }
  },
  "id" : 602169643919343616,
  "created_at" : "2015-05-23 17:50:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Beast",
      "screen_name" : "thedailybeast",
      "indices" : [ 3, 17 ],
      "id_str" : "16012783",
      "id" : 16012783
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thedailybeast\/status\/602131095186976768\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ulD3USrm3g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFszCkuUEAADdPI.jpg",
      "id_str" : "602131094494777344",
      "id" : 602131094494777344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFszCkuUEAADdPI.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ulD3USrm3g"
    } ],
    "hashtags" : [ {
      "text" : "FreeTheNipple",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/vkmdHg3DQh",
      "expanded_url" : "http:\/\/thebea.st\/1IRk28f",
      "display_url" : "thebea.st\/1IRk28f"
    } ]
  },
  "geo" : { },
  "id_str" : "602134871046279168",
  "text" : "RT @thedailybeast: Why hide something so beautiful and natural? http:\/\/t.co\/vkmdHg3DQh #FreeTheNipple http:\/\/t.co\/ulD3USrm3g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thedailybeast\/status\/602131095186976768\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/ulD3USrm3g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFszCkuUEAADdPI.jpg",
        "id_str" : "602131094494777344",
        "id" : 602131094494777344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFszCkuUEAADdPI.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/ulD3USrm3g"
      } ],
      "hashtags" : [ {
        "text" : "FreeTheNipple",
        "indices" : [ 68, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/vkmdHg3DQh",
        "expanded_url" : "http:\/\/thebea.st\/1IRk28f",
        "display_url" : "thebea.st\/1IRk28f"
      } ]
    },
    "geo" : { },
    "id_str" : "602131095186976768",
    "text" : "Why hide something so beautiful and natural? http:\/\/t.co\/vkmdHg3DQh #FreeTheNipple http:\/\/t.co\/ulD3USrm3g",
    "id" : 602131095186976768,
    "created_at" : "2015-05-23 15:16:54 +0000",
    "user" : {
      "name" : "The Daily Beast",
      "screen_name" : "thedailybeast",
      "protected" : false,
      "id_str" : "16012783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2722860646\/378326807a778b3cdf2bfe33348aab73_normal.png",
      "id" : 16012783,
      "verified" : true
    }
  },
  "id" : 602134871046279168,
  "created_at" : "2015-05-23 15:31:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/602120054944112640\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/PziOiQ2hkf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFso_8qWoAEpljU.jpg",
      "id_str" : "602120054264733697",
      "id" : 602120054264733697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFso_8qWoAEpljU.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/PziOiQ2hkf"
    } ],
    "hashtags" : [ {
      "text" : "vabirdlibrary",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602121597378555904",
  "text" : "RT @Library4birds: We've been squirreled. #vabirdlibrary http:\/\/t.co\/PziOiQ2hkf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/602120054944112640\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/PziOiQ2hkf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFso_8qWoAEpljU.jpg",
        "id_str" : "602120054264733697",
        "id" : 602120054264733697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFso_8qWoAEpljU.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/PziOiQ2hkf"
      } ],
      "hashtags" : [ {
        "text" : "vabirdlibrary",
        "indices" : [ 23, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602120054944112640",
    "text" : "We've been squirreled. #vabirdlibrary http:\/\/t.co\/PziOiQ2hkf",
    "id" : 602120054944112640,
    "created_at" : "2015-05-23 14:33:02 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 602121597378555904,
  "created_at" : "2015-05-23 14:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cargo short mr darcy",
      "screen_name" : "oogster_mc_gurk",
      "indices" : [ 3, 19 ],
      "id_str" : "125170663",
      "id" : 125170663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601907125825200128",
  "text" : "RT @oogster_mc_gurk: so i do all the legwork, take insurance-induced stress, &amp; pay for it all out of pocket anyhow. what's insurance for ag\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601845269383131136",
    "text" : "so i do all the legwork, take insurance-induced stress, &amp; pay for it all out of pocket anyhow. what's insurance for again? #singlepayer",
    "id" : 601845269383131136,
    "created_at" : "2015-05-22 20:21:08 +0000",
    "user" : {
      "name" : "cargo short mr darcy",
      "screen_name" : "oogster_mc_gurk",
      "protected" : false,
      "id_str" : "125170663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790339967\/feets_normal.jpg",
      "id" : 125170663,
      "verified" : false
    }
  },
  "id" : 601907125825200128,
  "created_at" : "2015-05-23 00:26:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mariano",
      "screen_name" : "art2u2",
      "indices" : [ 3, 10 ],
      "id_str" : "47677431",
      "id" : 47677431
    }, {
      "name" : "TLC Network",
      "screen_name" : "TLC",
      "indices" : [ 28, 32 ],
      "id_str" : "21313855",
      "id" : 21313855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601907011836583936",
  "text" : "RT @art2u2: ...and who owns @TLC you might ask? The same person who owns the Discovery Channel and Fox News, Rupert Murdoch. #duggarfamilyv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TLC Network",
        "screen_name" : "TLC",
        "indices" : [ 16, 20 ],
        "id_str" : "21313855",
        "id" : 21313855
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "duggarfamilyvalues",
        "indices" : [ 113, 132 ]
      }, {
        "text" : "p2",
        "indices" : [ 133, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601783471862841344",
    "text" : "...and who owns @TLC you might ask? The same person who owns the Discovery Channel and Fox News, Rupert Murdoch. #duggarfamilyvalues #p2",
    "id" : 601783471862841344,
    "created_at" : "2015-05-22 16:15:34 +0000",
    "user" : {
      "name" : "Mariano",
      "screen_name" : "art2u2",
      "protected" : false,
      "id_str" : "47677431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784740797442760704\/lsHU4loK_normal.jpg",
      "id" : 47677431,
      "verified" : false
    }
  },
  "id" : 601907011836583936,
  "created_at" : "2015-05-23 00:26:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fat chick in LA",
      "screen_name" : "FatChickinLA",
      "indices" : [ 3, 16 ],
      "id_str" : "43155647",
      "id" : 43155647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601906888029114368",
  "text" : "RT @FatChickinLA: Let's all imagine what the news would say if Josh Duggar was black (Musical Interlude) Hey wheres Mike Huckabee?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601902010913292288",
    "text" : "Let's all imagine what the news would say if Josh Duggar was black (Musical Interlude) Hey wheres Mike Huckabee?",
    "id" : 601902010913292288,
    "created_at" : "2015-05-23 00:06:36 +0000",
    "user" : {
      "name" : "Fat chick in LA",
      "screen_name" : "FatChickinLA",
      "protected" : false,
      "id_str" : "43155647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381736037\/1c80387e6a7b6350e958710a2214673c_normal.jpeg",
      "id" : 43155647,
      "verified" : false
    }
  },
  "id" : 601906888029114368,
  "created_at" : "2015-05-23 00:25:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristi Chadwick",
      "screen_name" : "booksNyarn",
      "indices" : [ 3, 14 ],
      "id_str" : "40269827",
      "id" : 40269827
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/booksNyarn\/status\/601902912185458688\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/LbBT5JGMez",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFpjgm_XIAEa1Lp.jpg",
      "id_str" : "601902912080650241",
      "id" : 601902912080650241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFpjgm_XIAEa1Lp.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/LbBT5JGMez"
    } ],
    "hashtags" : [ {
      "text" : "Jadecat",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "jaspercat",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "cats",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601906536240324608",
  "text" : "RT @booksNyarn: Bird TV is very popular here. #Jadecat #jaspercat #cats http:\/\/t.co\/LbBT5JGMez",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/booksNyarn\/status\/601902912185458688\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/LbBT5JGMez",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFpjgm_XIAEa1Lp.jpg",
        "id_str" : "601902912080650241",
        "id" : 601902912080650241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFpjgm_XIAEa1Lp.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/LbBT5JGMez"
      } ],
      "hashtags" : [ {
        "text" : "Jadecat",
        "indices" : [ 30, 38 ]
      }, {
        "text" : "jaspercat",
        "indices" : [ 39, 49 ]
      }, {
        "text" : "cats",
        "indices" : [ 50, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601902912185458688",
    "text" : "Bird TV is very popular here. #Jadecat #jaspercat #cats http:\/\/t.co\/LbBT5JGMez",
    "id" : 601902912185458688,
    "created_at" : "2015-05-23 00:10:11 +0000",
    "user" : {
      "name" : "Kristi Chadwick",
      "screen_name" : "booksNyarn",
      "protected" : false,
      "id_str" : "40269827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799025640334905350\/j5-9MV3g_normal.jpg",
      "id" : 40269827,
      "verified" : false
    }
  },
  "id" : 601906536240324608,
  "created_at" : "2015-05-23 00:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life With Dogs",
      "screen_name" : "LifeWithDogsTV",
      "indices" : [ 3, 18 ],
      "id_str" : "18418936",
      "id" : 18418936
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LifeWithDogsTV\/status\/601904252039094274\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/nS1VTa8M8j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFpkukMWYAAgC7c.jpg",
      "id_str" : "601904251359617024",
      "id" : 601904251359617024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFpkukMWYAAgC7c.jpg",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 711
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 711
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nS1VTa8M8j"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/BG2VsZDbqj",
      "expanded_url" : "http:\/\/bit.ly\/1FEHbrW",
      "display_url" : "bit.ly\/1FEHbrW"
    } ]
  },
  "geo" : { },
  "id_str" : "601906377729126400",
  "text" : "RT @LifeWithDogsTV: Blinded Rescue Dog's Little Brothers Step Up to Be Her Guides\n\nhttp:\/\/t.co\/BG2VsZDbqj http:\/\/t.co\/nS1VTa8M8j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LifeWithDogsTV\/status\/601904252039094274\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/nS1VTa8M8j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFpkukMWYAAgC7c.jpg",
        "id_str" : "601904251359617024",
        "id" : 601904251359617024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFpkukMWYAAgC7c.jpg",
        "sizes" : [ {
          "h" : 358,
          "resize" : "fit",
          "w" : 711
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 711
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nS1VTa8M8j"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/BG2VsZDbqj",
        "expanded_url" : "http:\/\/bit.ly\/1FEHbrW",
        "display_url" : "bit.ly\/1FEHbrW"
      } ]
    },
    "geo" : { },
    "id_str" : "601904252039094274",
    "text" : "Blinded Rescue Dog's Little Brothers Step Up to Be Her Guides\n\nhttp:\/\/t.co\/BG2VsZDbqj http:\/\/t.co\/nS1VTa8M8j",
    "id" : 601904252039094274,
    "created_at" : "2015-05-23 00:15:31 +0000",
    "user" : {
      "name" : "Life With Dogs",
      "screen_name" : "LifeWithDogsTV",
      "protected" : false,
      "id_str" : "18418936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788959945546993664\/nOy2XTo5_normal.jpg",
      "id" : 18418936,
      "verified" : false
    }
  },
  "id" : 601906377729126400,
  "created_at" : "2015-05-23 00:23:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601901870387372032",
  "geo" : { },
  "id_str" : "601906074896179200",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time not bad for the most part : )",
  "id" : 601906074896179200,
  "in_reply_to_status_id" : 601901870387372032,
  "created_at" : "2015-05-23 00:22:45 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#LoveWins",
      "screen_name" : "SojoCommunity",
      "indices" : [ 3, 17 ],
      "id_str" : "379461132",
      "id" : 379461132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTQIA",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601904715060924416",
  "text" : "RT @SojoCommunity: For #LGBTQIA, \nYou are made in God's image.\nGod loves you unconditionally.\nYou are not an abomination! \nYou are beloved.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTQIA",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "BlackChurchSex",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601757956951027712",
    "text" : "For #LGBTQIA, \nYou are made in God's image.\nGod loves you unconditionally.\nYou are not an abomination! \nYou are beloved.\n#BlackChurchSex",
    "id" : 601757956951027712,
    "created_at" : "2015-05-22 14:34:11 +0000",
    "user" : {
      "name" : "#LoveWins",
      "screen_name" : "SojoCommunity",
      "protected" : false,
      "id_str" : "379461132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1558432275\/Sojourner_Truth_01_1__normal.jpg",
      "id" : 379461132,
      "verified" : false
    }
  },
  "id" : 601904715060924416,
  "created_at" : "2015-05-23 00:17:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "randy r. potts",
      "screen_name" : "thephatic",
      "indices" : [ 3, 13 ],
      "id_str" : "27576090",
      "id" : 27576090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601893489232769024",
  "text" : "RT @thephatic: Strange but true: I was too scared to go to therapy until I was 27 bc the evangelical xtian community I came from said it wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601889441494343680",
    "text" : "Strange but true: I was too scared to go to therapy until I was 27 bc the evangelical xtian community I came from said it would harm me.",
    "id" : 601889441494343680,
    "created_at" : "2015-05-22 23:16:40 +0000",
    "user" : {
      "name" : "randy r. potts",
      "screen_name" : "thephatic",
      "protected" : false,
      "id_str" : "27576090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797936529339453440\/mBw1pqLY_normal.jpg",
      "id" : 27576090,
      "verified" : false
    }
  },
  "id" : 601893489232769024,
  "created_at" : "2015-05-22 23:32:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Swanner",
      "screen_name" : "NateSwanner",
      "indices" : [ 3, 15 ],
      "id_str" : "1023084860",
      "id" : 1023084860
    }, {
      "name" : "Owen \u26A1\uFE0F",
      "screen_name" : "ow",
      "indices" : [ 17, 20 ],
      "id_str" : "14767730",
      "id" : 14767730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601891122403741697",
  "text" : "RT @NateSwanner: @ow so do I. I dislike phone conversation. I\u2019m too misanthropic for live discussion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Owen \u26A1\uFE0F",
        "screen_name" : "ow",
        "indices" : [ 0, 3 ],
        "id_str" : "14767730",
        "id" : 14767730
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "601816687915184129",
    "geo" : { },
    "id_str" : "601816860900855808",
    "in_reply_to_user_id" : 14767730,
    "text" : "@ow so do I. I dislike phone conversation. I\u2019m too misanthropic for live discussion.",
    "id" : 601816860900855808,
    "in_reply_to_status_id" : 601816687915184129,
    "created_at" : "2015-05-22 18:28:15 +0000",
    "in_reply_to_screen_name" : "ow",
    "in_reply_to_user_id_str" : "14767730",
    "user" : {
      "name" : "Nate Swanner",
      "screen_name" : "NateSwanner",
      "protected" : false,
      "id_str" : "1023084860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656693152720420864\/IUZHKQt7_normal.jpg",
      "id" : 1023084860,
      "verified" : true
    }
  },
  "id" : 601891122403741697,
  "created_at" : "2015-05-22 23:23:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "indices" : [ 3, 17 ],
      "id_str" : "20640860",
      "id" : 20640860
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/homesteadwool\/status\/601850452095832065\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/FltyUH7Fei",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFozy-RUsAEjt8c.jpg",
      "id_str" : "601850451009515521",
      "id" : 601850451009515521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFozy-RUsAEjt8c.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/FltyUH7Fei"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/XPC5rYZO0b",
      "expanded_url" : "https:\/\/homesteadwoolandgiftfarm.wordpress.com\/2015\/05\/22\/rosies-bad-day",
      "display_url" : "homesteadwoolandgiftfarm.wordpress.com\/2015\/05\/22\/ros\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601851548772265985",
  "text" : "RT @homesteadwool: Rosie's Bad Day.... https:\/\/t.co\/XPC5rYZO0b http:\/\/t.co\/FltyUH7Fei",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/homesteadwool\/status\/601850452095832065\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/FltyUH7Fei",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFozy-RUsAEjt8c.jpg",
        "id_str" : "601850451009515521",
        "id" : 601850451009515521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFozy-RUsAEjt8c.jpg",
        "sizes" : [ {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/FltyUH7Fei"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/XPC5rYZO0b",
        "expanded_url" : "https:\/\/homesteadwoolandgiftfarm.wordpress.com\/2015\/05\/22\/rosies-bad-day",
        "display_url" : "homesteadwoolandgiftfarm.wordpress.com\/2015\/05\/22\/ros\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601850452095832065",
    "text" : "Rosie's Bad Day.... https:\/\/t.co\/XPC5rYZO0b http:\/\/t.co\/FltyUH7Fei",
    "id" : 601850452095832065,
    "created_at" : "2015-05-22 20:41:44 +0000",
    "user" : {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "protected" : false,
      "id_str" : "20640860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462783906903629824\/PO5lx_HY_normal.jpeg",
      "id" : 20640860,
      "verified" : false
    }
  },
  "id" : 601851548772265985,
  "created_at" : "2015-05-22 20:46:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "indices" : [ 3, 17 ],
      "id_str" : "20640860",
      "id" : 20640860
    }, {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "indices" : [ 91, 105 ],
      "id_str" : "20640860",
      "id" : 20640860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/3aIj4Nuuoe",
      "expanded_url" : "http:\/\/wp.me\/p4zJQ3-I",
      "display_url" : "wp.me\/p4zJQ3-I"
    } ]
  },
  "geo" : { },
  "id_str" : "601851410846765056",
  "text" : "RT @homesteadwool: Rosie The Little Border Collie's Bad Day.... http:\/\/t.co\/3aIj4Nuuoe via @homesteadwool",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandy Ryan",
        "screen_name" : "homesteadwool",
        "indices" : [ 72, 86 ],
        "id_str" : "20640860",
        "id" : 20640860
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/3aIj4Nuuoe",
        "expanded_url" : "http:\/\/wp.me\/p4zJQ3-I",
        "display_url" : "wp.me\/p4zJQ3-I"
      } ]
    },
    "geo" : { },
    "id_str" : "601850606836383745",
    "text" : "Rosie The Little Border Collie's Bad Day.... http:\/\/t.co\/3aIj4Nuuoe via @homesteadwool",
    "id" : 601850606836383745,
    "created_at" : "2015-05-22 20:42:21 +0000",
    "user" : {
      "name" : "Sandy Ryan",
      "screen_name" : "homesteadwool",
      "protected" : false,
      "id_str" : "20640860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462783906903629824\/PO5lx_HY_normal.jpeg",
      "id" : 20640860,
      "verified" : false
    }
  },
  "id" : 601851410846765056,
  "created_at" : "2015-05-22 20:45:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SHEREDWOLF\/status\/601848282168569856\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/3wGn2wSmtF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFox0qFWEAAbNNf.jpg",
      "id_str" : "601848280927047680",
      "id" : 601848280927047680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFox0qFWEAAbNNf.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/3wGn2wSmtF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601849405109567488",
  "text" : "RT @SHEREDWOLF: http:\/\/t.co\/3wGn2wSmtF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SHEREDWOLF\/status\/601848282168569856\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/3wGn2wSmtF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFox0qFWEAAbNNf.jpg",
        "id_str" : "601848280927047680",
        "id" : 601848280927047680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFox0qFWEAAbNNf.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/3wGn2wSmtF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601848282168569856",
    "text" : "http:\/\/t.co\/3wGn2wSmtF",
    "id" : 601848282168569856,
    "created_at" : "2015-05-22 20:33:06 +0000",
    "user" : {
      "name" : "\uADF8\uB140 - \uB291\uB300",
      "screen_name" : "wolves_my_love",
      "protected" : false,
      "id_str" : "560545385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752248927899021313\/APaMam9p_normal.jpg",
      "id" : 560545385,
      "verified" : false
    }
  },
  "id" : 601849405109567488,
  "created_at" : "2015-05-22 20:37:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scottsigler\/status\/601808187524780032\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/jNbCLxXoVO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFoNKaOWEAAexij.jpg",
      "id_str" : "601807972696723456",
      "id" : 601807972696723456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFoNKaOWEAAexij.jpg",
      "sizes" : [ {
        "h" : 2400,
        "resize" : "fit",
        "w" : 2400
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jNbCLxXoVO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/R48yBL6CIb",
      "expanded_url" : "http:\/\/scottsigler.com\/itunes",
      "display_url" : "scottsigler.com\/itunes"
    } ]
  },
  "geo" : { },
  "id_str" : "601813271356780544",
  "text" : "RT @scottsigler: ALIVE serialized audiobook podcast begins 6\/23. Subscribe! http:\/\/t.co\/R48yBL6CIb http:\/\/t.co\/jNbCLxXoVO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scottsigler\/status\/601808187524780032\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/jNbCLxXoVO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFoNKaOWEAAexij.jpg",
        "id_str" : "601807972696723456",
        "id" : 601807972696723456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFoNKaOWEAAexij.jpg",
        "sizes" : [ {
          "h" : 2400,
          "resize" : "fit",
          "w" : 2400
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jNbCLxXoVO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/R48yBL6CIb",
        "expanded_url" : "http:\/\/scottsigler.com\/itunes",
        "display_url" : "scottsigler.com\/itunes"
      } ]
    },
    "geo" : { },
    "id_str" : "601808187524780032",
    "text" : "ALIVE serialized audiobook podcast begins 6\/23. Subscribe! http:\/\/t.co\/R48yBL6CIb http:\/\/t.co\/jNbCLxXoVO",
    "id" : 601808187524780032,
    "created_at" : "2015-05-22 17:53:47 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 601813271356780544,
  "created_at" : "2015-05-22 18:13:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601739080423079937",
  "text" : "RT @CrystalLewis: Churches teach contents w\/ no context, creating Christians who can't imagine that the Bible was redacted &amp; even intention\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "601736900194529280",
    "geo" : { },
    "id_str" : "601738473029107712",
    "in_reply_to_user_id" : 135615040,
    "text" : "Churches teach contents w\/ no context, creating Christians who can't imagine that the Bible was redacted &amp; even intentionally mistranslated.",
    "id" : 601738473029107712,
    "in_reply_to_status_id" : 601736900194529280,
    "created_at" : "2015-05-22 13:16:46 +0000",
    "in_reply_to_screen_name" : "CrystalLewis",
    "in_reply_to_user_id_str" : "135615040",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 601739080423079937,
  "created_at" : "2015-05-22 13:19:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrownBlaze",
      "screen_name" : "brownblaze",
      "indices" : [ 3, 14 ],
      "id_str" : "21280975",
      "id" : 21280975
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/brownblaze\/status\/601442031236321280\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yOtWHJmyGC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFjAUkFUgAElFmK.jpg",
      "id_str" : "601442009769869313",
      "id" : 601442009769869313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFjAUkFUgAElFmK.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yOtWHJmyGC"
    } ],
    "hashtags" : [ {
      "text" : "SayHerName",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601528702707437569",
  "text" : "RT @brownblaze: This action today was healing. So amazing. Black women are infinitely powerful, ya'll. #SayHerName http:\/\/t.co\/yOtWHJmyGC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/brownblaze\/status\/601442031236321280\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/yOtWHJmyGC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFjAUkFUgAElFmK.jpg",
        "id_str" : "601442009769869313",
        "id" : 601442009769869313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFjAUkFUgAElFmK.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/yOtWHJmyGC"
      } ],
      "hashtags" : [ {
        "text" : "SayHerName",
        "indices" : [ 87, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601442031236321280",
    "text" : "This action today was healing. So amazing. Black women are infinitely powerful, ya'll. #SayHerName http:\/\/t.co\/yOtWHJmyGC",
    "id" : 601442031236321280,
    "created_at" : "2015-05-21 17:38:49 +0000",
    "user" : {
      "name" : "BrownBlaze",
      "screen_name" : "brownblaze",
      "protected" : false,
      "id_str" : "21280975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799394753670328321\/p3rWzBTv_normal.jpg",
      "id" : 21280975,
      "verified" : false
    }
  },
  "id" : 601528702707437569,
  "created_at" : "2015-05-21 23:23:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/MEQu6Mk3zt",
      "expanded_url" : "https:\/\/instagram.com\/p\/29ImYthH4E\/",
      "display_url" : "instagram.com\/p\/29ImYthH4E\/"
    } ]
  },
  "geo" : { },
  "id_str" : "601466086387679235",
  "text" : "RT @ducksandclucks: Close talkers, Chester Sugarmont and Teddy Crispin https:\/\/t.co\/MEQu6Mk3zt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/MEQu6Mk3zt",
        "expanded_url" : "https:\/\/instagram.com\/p\/29ImYthH4E\/",
        "display_url" : "instagram.com\/p\/29ImYthH4E\/"
      } ]
    },
    "geo" : { },
    "id_str" : "601465270033494016",
    "text" : "Close talkers, Chester Sugarmont and Teddy Crispin https:\/\/t.co\/MEQu6Mk3zt",
    "id" : 601465270033494016,
    "created_at" : "2015-05-21 19:11:09 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 601466086387679235,
  "created_at" : "2015-05-21 19:14:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/505359040323780608\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/lfKg1eggTP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwNlXpfIgAAbqYJ.jpg",
      "id_str" : "505359040143458304",
      "id" : 505359040143458304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwNlXpfIgAAbqYJ.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/lfKg1eggTP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601458875192086528",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/lfKg1eggTP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/505359040323780608\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/lfKg1eggTP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwNlXpfIgAAbqYJ.jpg",
        "id_str" : "505359040143458304",
        "id" : 505359040143458304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwNlXpfIgAAbqYJ.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/lfKg1eggTP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601456218054348801",
    "text" : "http:\/\/t.co\/lfKg1eggTP",
    "id" : 601456218054348801,
    "created_at" : "2015-05-21 18:35:11 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 601458875192086528,
  "created_at" : "2015-05-21 18:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/mmdUmmuEfc",
      "expanded_url" : "http:\/\/qpolitical.com\/they-told-matthew-mcconaughey-keep-jesus-to-yourself-his-response-silenced-the-stadium\/",
      "display_url" : "qpolitical.com\/they-told-matt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601421838204444672",
  "text" : "wow.. awesome commencement speech! http:\/\/t.co\/mmdUmmuEfc",
  "id" : 601421838204444672,
  "created_at" : "2015-05-21 16:18:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SeaWorld Exposed",
      "screen_name" : "SeaWorldExposed",
      "indices" : [ 3, 19 ],
      "id_str" : "1629475578",
      "id" : 1629475578
    }, {
      "name" : "Jeffrey Ventre",
      "screen_name" : "jeffrey_ventre",
      "indices" : [ 59, 74 ],
      "id_str" : "475165737",
      "id" : 475165737
    }, {
      "name" : "Voice of the Orcas",
      "screen_name" : "Voice_OT_Orcas",
      "indices" : [ 76, 91 ],
      "id_str" : "479840612",
      "id" : 479840612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601142896176279554",
  "text" : "RT @SeaWorldExposed: If #Blackfish airs Saturday, pls join @jeffrey_ventre, @Voice_OT_Orcas &amp; cast HERE LIVE tweeting  \n8P ET\n5P PT http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeffrey Ventre",
        "screen_name" : "jeffrey_ventre",
        "indices" : [ 38, 53 ],
        "id_str" : "475165737",
        "id" : 475165737
      }, {
        "name" : "Voice of the Orcas",
        "screen_name" : "Voice_OT_Orcas",
        "indices" : [ 55, 70 ],
        "id_str" : "479840612",
        "id" : 479840612
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SeaWorldExposed\/status\/601137860931145728\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/MbOoyHREc3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFersNEWAAA8sWR.jpg",
        "id_str" : "601137851187724288",
        "id" : 601137851187724288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFersNEWAAA8sWR.jpg",
        "sizes" : [ {
          "h" : 740,
          "resize" : "fit",
          "w" : 955
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 955
        } ],
        "display_url" : "pic.twitter.com\/MbOoyHREc3"
      } ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 3, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601137860931145728",
    "text" : "If #Blackfish airs Saturday, pls join @jeffrey_ventre, @Voice_OT_Orcas &amp; cast HERE LIVE tweeting  \n8P ET\n5P PT http:\/\/t.co\/MbOoyHREc3",
    "id" : 601137860931145728,
    "created_at" : "2015-05-20 21:30:09 +0000",
    "user" : {
      "name" : "SeaWorld Exposed",
      "screen_name" : "SeaWorldExposed",
      "protected" : false,
      "id_str" : "1629475578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000226485873\/ea75d131116a1a660e9dff4c9ed042bf_normal.jpeg",
      "id" : 1629475578,
      "verified" : false
    }
  },
  "id" : 601142896176279554,
  "created_at" : "2015-05-20 21:50:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOL Factory",
      "screen_name" : "LOL_factory1",
      "indices" : [ 3, 16 ],
      "id_str" : "2720083357",
      "id" : 2720083357
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LOL_factory1\/status\/600585142357233665\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/FagfYiBTNq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFW0_B0VIAA0nuk.jpg",
      "id_str" : "600585120236511232",
      "id" : 600585120236511232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFW0_B0VIAA0nuk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FagfYiBTNq"
    } ],
    "hashtags" : [ {
      "text" : "lol",
      "indices" : [ 37, 41 ]
    }, {
      "text" : "funny",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601086191212109825",
  "text" : "RT @LOL_factory1: Found this at work\n#lol #funny http:\/\/t.co\/FagfYiBTNq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LOL_factory1\/status\/600585142357233665\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/FagfYiBTNq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFW0_B0VIAA0nuk.jpg",
        "id_str" : "600585120236511232",
        "id" : 600585120236511232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFW0_B0VIAA0nuk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FagfYiBTNq"
      } ],
      "hashtags" : [ {
        "text" : "lol",
        "indices" : [ 19, 23 ]
      }, {
        "text" : "funny",
        "indices" : [ 24, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600585142357233665",
    "text" : "Found this at work\n#lol #funny http:\/\/t.co\/FagfYiBTNq",
    "id" : 600585142357233665,
    "created_at" : "2015-05-19 08:53:50 +0000",
    "user" : {
      "name" : "LOL Factory",
      "screen_name" : "LOL_factory1",
      "protected" : false,
      "id_str" : "2720083357",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/498200976881225729\/2bAyTbsD_normal.png",
      "id" : 2720083357,
      "verified" : false
    }
  },
  "id" : 601086191212109825,
  "created_at" : "2015-05-20 18:04:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 0, 11 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601028439995457537",
  "geo" : { },
  "id_str" : "601032934871715840",
  "in_reply_to_user_id" : 276314137,
  "text" : "@jonlieffmd Fascinating.. and scary to think of plants that way!",
  "id" : 601032934871715840,
  "in_reply_to_status_id" : 601028439995457537,
  "created_at" : "2015-05-20 14:33:12 +0000",
  "in_reply_to_screen_name" : "jonlieffmd",
  "in_reply_to_user_id_str" : "276314137",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/601028439995457537\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/WQIAIRqCQR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdILoNWoAA6-Sf.jpg",
      "id_str" : "601028439886438400",
      "id" : 601028439886438400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdILoNWoAA6-Sf.jpg",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/WQIAIRqCQR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/GMPOxzRST8",
      "expanded_url" : "http:\/\/bit.ly\/1FewrjS",
      "display_url" : "bit.ly\/1FewrjS"
    } ]
  },
  "geo" : { },
  "id_str" : "601032567563931648",
  "text" : "RT @jonlieffmd: Is the Dodder the most intelligent plant? http:\/\/t.co\/GMPOxzRST8 http:\/\/t.co\/WQIAIRqCQR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/601028439995457537\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/WQIAIRqCQR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdILoNWoAA6-Sf.jpg",
        "id_str" : "601028439886438400",
        "id" : 601028439886438400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdILoNWoAA6-Sf.jpg",
        "sizes" : [ {
          "h" : 216,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/WQIAIRqCQR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/GMPOxzRST8",
        "expanded_url" : "http:\/\/bit.ly\/1FewrjS",
        "display_url" : "bit.ly\/1FewrjS"
      } ]
    },
    "geo" : { },
    "id_str" : "601028439995457537",
    "text" : "Is the Dodder the most intelligent plant? http:\/\/t.co\/GMPOxzRST8 http:\/\/t.co\/WQIAIRqCQR",
    "id" : 601028439995457537,
    "created_at" : "2015-05-20 14:15:21 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 601032567563931648,
  "created_at" : "2015-05-20 14:31:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/510620771035914240\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/GSjNbWoqS0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxYW4r1IAAAbir2.jpg",
      "id_str" : "510620770847162368",
      "id" : 510620770847162368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxYW4r1IAAAbir2.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 468
      } ],
      "display_url" : "pic.twitter.com\/GSjNbWoqS0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601030471271714816",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/GSjNbWoqS0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/510620771035914240\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/GSjNbWoqS0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxYW4r1IAAAbir2.jpg",
        "id_str" : "510620770847162368",
        "id" : 510620770847162368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxYW4r1IAAAbir2.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/GSjNbWoqS0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601029669274701824",
    "text" : "http:\/\/t.co\/GSjNbWoqS0",
    "id" : 601029669274701824,
    "created_at" : "2015-05-20 14:20:14 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 601030471271714816,
  "created_at" : "2015-05-20 14:23:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Olin",
      "screen_name" : "olinj",
      "indices" : [ 3, 9 ],
      "id_str" : "153875560",
      "id" : 153875560
    }, {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 42, 56 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601021952359272448",
  "text" : "RT @olinj: Seriously, though, why doesn't @Library4birds have more followers? IT'S A BIRD LIBRARY, PEOPLE!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bird Library",
        "screen_name" : "Library4birds",
        "indices" : [ 31, 45 ],
        "id_str" : "3230864579",
        "id" : 3230864579
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601021115511746561",
    "text" : "Seriously, though, why doesn't @Library4birds have more followers? IT'S A BIRD LIBRARY, PEOPLE!",
    "id" : 601021115511746561,
    "created_at" : "2015-05-20 13:46:15 +0000",
    "user" : {
      "name" : "Jessica Olin",
      "screen_name" : "olinj",
      "protected" : false,
      "id_str" : "153875560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799678879858302976\/F2ooht00_normal.jpg",
      "id" : 153875560,
      "verified" : false
    }
  },
  "id" : 601021952359272448,
  "created_at" : "2015-05-20 13:49:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CG",
      "screen_name" : "acuriousgal1",
      "indices" : [ 3, 16 ],
      "id_str" : "2293715275",
      "id" : 2293715275
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/acuriousgal1\/status\/600840156879327234\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/7gr0CTUlXG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFac7oHVEAAodg_.jpg",
      "id_str" : "600840148494913536",
      "id" : 600840148494913536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFac7oHVEAAodg_.jpg",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7gr0CTUlXG"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "gilbertandsullivan",
      "indices" : [ 66, 85 ]
    }, {
      "text" : "play",
      "indices" : [ 87, 92 ]
    }, {
      "text" : "nature",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600841607819206656",
  "text" : "RT @acuriousgal1: \uD83C\uDFB6Three little maids from school are we\uD83C\uDFB6 #birds, #gilbertandsullivan, #play, #nature http:\/\/t.co\/7gr0CTUlXG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/acuriousgal1\/status\/600840156879327234\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/7gr0CTUlXG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFac7oHVEAAodg_.jpg",
        "id_str" : "600840148494913536",
        "id" : 600840148494913536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFac7oHVEAAodg_.jpg",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7gr0CTUlXG"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 40, 46 ]
      }, {
        "text" : "gilbertandsullivan",
        "indices" : [ 48, 67 ]
      }, {
        "text" : "play",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "nature",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600840156879327234",
    "text" : "\uD83C\uDFB6Three little maids from school are we\uD83C\uDFB6 #birds, #gilbertandsullivan, #play, #nature http:\/\/t.co\/7gr0CTUlXG",
    "id" : 600840156879327234,
    "created_at" : "2015-05-20 01:47:11 +0000",
    "user" : {
      "name" : "CG",
      "screen_name" : "acuriousgal1",
      "protected" : false,
      "id_str" : "2293715275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676589567500095488\/jI9wzTBE_normal.jpg",
      "id" : 2293715275,
      "verified" : false
    }
  },
  "id" : 600841607819206656,
  "created_at" : "2015-05-20 01:52:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR Goats",
      "screen_name" : "NPRGlobalHealth",
      "indices" : [ 3, 19 ],
      "id_str" : "4212424695",
      "id" : 4212424695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/LUyhfXV7eE",
      "expanded_url" : "http:\/\/n.pr\/1PURWYp",
      "display_url" : "n.pr\/1PURWYp"
    } ]
  },
  "geo" : { },
  "id_str" : "600789432917176320",
  "text" : "RT @nprGlobalHealth: Home-brewed Morphine Is Just Around The Corner http:\/\/t.co\/LUyhfXV7eE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/LUyhfXV7eE",
        "expanded_url" : "http:\/\/n.pr\/1PURWYp",
        "display_url" : "n.pr\/1PURWYp"
      } ]
    },
    "geo" : { },
    "id_str" : "600786395993485314",
    "text" : "Home-brewed Morphine Is Just Around The Corner http:\/\/t.co\/LUyhfXV7eE",
    "id" : 600786395993485314,
    "created_at" : "2015-05-19 22:13:33 +0000",
    "user" : {
      "name" : "NPR Goats & Soda",
      "screen_name" : "NPRGoatsandSoda",
      "protected" : false,
      "id_str" : "707512656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707271210372087808\/98xjNlz__normal.jpg",
      "id" : 707512656,
      "verified" : true
    }
  },
  "id" : 600789432917176320,
  "created_at" : "2015-05-19 22:25:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "indices" : [ 3, 17 ],
      "id_str" : "2977412266",
      "id" : 2977412266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/FEhCr99RM0",
      "expanded_url" : "https:\/\/vine.co\/v\/eADzgzzmJJT",
      "display_url" : "vine.co\/v\/eADzgzzmJJT"
    } ]
  },
  "geo" : { },
  "id_str" : "600786565414137856",
  "text" : "RT @farmingmadire: Noses \uD83D\uDC2E\uD83D\uDC2E https:\/\/t.co\/FEhCr99RM0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/FEhCr99RM0",
        "expanded_url" : "https:\/\/vine.co\/v\/eADzgzzmJJT",
        "display_url" : "vine.co\/v\/eADzgzzmJJT"
      } ]
    },
    "geo" : { },
    "id_str" : "600754027224113153",
    "text" : "Noses \uD83D\uDC2E\uD83D\uDC2E https:\/\/t.co\/FEhCr99RM0",
    "id" : 600754027224113153,
    "created_at" : "2015-05-19 20:04:56 +0000",
    "user" : {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "protected" : false,
      "id_str" : "2977412266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723980308874420224\/USPqubG3_normal.jpg",
      "id" : 2977412266,
      "verified" : false
    }
  },
  "id" : 600786565414137856,
  "created_at" : "2015-05-19 22:14:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/9B2yl3UYwN",
      "expanded_url" : "http:\/\/www.treehugger.com\/urban-design\/uk-its-make-way-ducklings-duck-lanes-are-installed-towpaths.html",
      "display_url" : "treehugger.com\/urban-design\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600746455880617985",
  "text" : "Forget bikes; In the UK even the ducks get their own lanes http:\/\/t.co\/9B2yl3UYwN",
  "id" : 600746455880617985,
  "created_at" : "2015-05-19 19:34:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emergency Fox",
      "screen_name" : "emergency_fox",
      "indices" : [ 3, 17 ],
      "id_str" : "785588682",
      "id" : 785588682
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/emergency_fox\/status\/600643287389732864\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/lsDqRSnUif",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFXp4gZWAAAq9sZ.jpg",
      "id_str" : "600643282302009344",
      "id" : 600643282302009344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFXp4gZWAAAq9sZ.jpg",
      "sizes" : [ {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lsDqRSnUif"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600649594914140160",
  "text" : "RT @emergency_fox: BITE THE TOES OF THE BOURGEOISIE http:\/\/t.co\/lsDqRSnUif",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/emergency_fox\/status\/600643287389732864\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/lsDqRSnUif",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFXp4gZWAAAq9sZ.jpg",
        "id_str" : "600643282302009344",
        "id" : 600643282302009344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFXp4gZWAAAq9sZ.jpg",
        "sizes" : [ {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 625,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lsDqRSnUif"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600643287389732864",
    "text" : "BITE THE TOES OF THE BOURGEOISIE http:\/\/t.co\/lsDqRSnUif",
    "id" : 600643287389732864,
    "created_at" : "2015-05-19 12:44:53 +0000",
    "user" : {
      "name" : "Emergency Fox",
      "screen_name" : "emergency_fox",
      "protected" : false,
      "id_str" : "785588682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620330251583942657\/6-XOHuXf_normal.jpg",
      "id" : 785588682,
      "verified" : false
    }
  },
  "id" : 600649594914140160,
  "created_at" : "2015-05-19 13:09:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/600535199038836737\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/UmuqtVwjha",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFWHkP8UMAAwtc2.jpg",
      "id_str" : "600535182148382720",
      "id" : 600535182148382720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFWHkP8UMAAwtc2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UmuqtVwjha"
    } ],
    "hashtags" : [ {
      "text" : "yearofmaking",
      "indices" : [ 53, 66 ]
    }, {
      "text" : "stayeduptoolateseaming",
      "indices" : [ 67, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600646915647270912",
  "text" : "RT @ErinEFarley: Nibbler guardian of the bum fodder! #yearofmaking #stayeduptoolateseaming http:\/\/t.co\/UmuqtVwjha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/600535199038836737\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/UmuqtVwjha",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFWHkP8UMAAwtc2.jpg",
        "id_str" : "600535182148382720",
        "id" : 600535182148382720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFWHkP8UMAAwtc2.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UmuqtVwjha"
      } ],
      "hashtags" : [ {
        "text" : "yearofmaking",
        "indices" : [ 36, 49 ]
      }, {
        "text" : "stayeduptoolateseaming",
        "indices" : [ 50, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600535199038836737",
    "text" : "Nibbler guardian of the bum fodder! #yearofmaking #stayeduptoolateseaming http:\/\/t.co\/UmuqtVwjha",
    "id" : 600535199038836737,
    "created_at" : "2015-05-19 05:35:23 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 600646915647270912,
  "created_at" : "2015-05-19 12:59:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/504532666243633152\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/f63RHvwsSU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwB1yU5IgAABHEL.jpg",
      "id_str" : "504532665727746048",
      "id" : 504532665727746048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwB1yU5IgAABHEL.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/f63RHvwsSU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600646789054779392",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/f63RHvwsSU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/504532666243633152\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/f63RHvwsSU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwB1yU5IgAABHEL.jpg",
        "id_str" : "504532665727746048",
        "id" : 504532665727746048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwB1yU5IgAABHEL.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/f63RHvwsSU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600609401263755264",
    "text" : "http:\/\/t.co\/f63RHvwsSU",
    "id" : 600609401263755264,
    "created_at" : "2015-05-19 10:30:14 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 600646789054779392,
  "created_at" : "2015-05-19 12:58:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brenda P. Williamson",
      "screen_name" : "BrendaPerrott",
      "indices" : [ 3, 17 ],
      "id_str" : "534841923",
      "id" : 534841923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ZnwXam28jO",
      "expanded_url" : "http:\/\/nyccats.urgentpodr.org\/adam-a1034877\/",
      "display_url" : "nyccats.urgentpodr.org\/adam-a1034877\/"
    } ]
  },
  "geo" : { },
  "id_str" : "600456439698694146",
  "text" : "RT @BrendaPerrott: PRECIOUS BICOLOR BEAUTY ADAM-THAT SWEET FACE -- MAKES EYE CONTACT WHENEVER HIS NAME IS CALLED http:\/\/t.co\/ZnwXam28jO htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BrendaPerrott\/status\/600438505844662274\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/RB6GfWmwa9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFUvo4uXIAA1qVn.jpg",
        "id_str" : "600438504791941120",
        "id" : 600438504791941120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFUvo4uXIAA1qVn.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/RB6GfWmwa9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ZnwXam28jO",
        "expanded_url" : "http:\/\/nyccats.urgentpodr.org\/adam-a1034877\/",
        "display_url" : "nyccats.urgentpodr.org\/adam-a1034877\/"
      } ]
    },
    "geo" : { },
    "id_str" : "600438505844662274",
    "text" : "PRECIOUS BICOLOR BEAUTY ADAM-THAT SWEET FACE -- MAKES EYE CONTACT WHENEVER HIS NAME IS CALLED http:\/\/t.co\/ZnwXam28jO http:\/\/t.co\/RB6GfWmwa9",
    "id" : 600438505844662274,
    "created_at" : "2015-05-18 23:11:10 +0000",
    "user" : {
      "name" : "Brenda P. Williamson",
      "screen_name" : "BrendaPerrott",
      "protected" : false,
      "id_str" : "534841923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793670272910000128\/xCHgVFEO_normal.jpg",
      "id" : 534841923,
      "verified" : false
    }
  },
  "id" : 600456439698694146,
  "created_at" : "2015-05-19 00:22:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "indices" : [ 3, 15 ],
      "id_str" : "23034673",
      "id" : 23034673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/4CqC9qsZUl",
      "expanded_url" : "http:\/\/tinyurl.com\/mxp6b95",
      "display_url" : "tinyurl.com\/mxp6b95"
    } ]
  },
  "geo" : { },
  "id_str" : "600456203450359808",
  "text" : "RT @hemantmehta: An Atheist Interviewed a Creationist from Answers in Genesis\u2026 and the Conversation is Fascinating http:\/\/t.co\/4CqC9qsZUl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/4CqC9qsZUl",
        "expanded_url" : "http:\/\/tinyurl.com\/mxp6b95",
        "display_url" : "tinyurl.com\/mxp6b95"
      } ]
    },
    "geo" : { },
    "id_str" : "600448249934192641",
    "text" : "An Atheist Interviewed a Creationist from Answers in Genesis\u2026 and the Conversation is Fascinating http:\/\/t.co\/4CqC9qsZUl",
    "id" : 600448249934192641,
    "created_at" : "2015-05-18 23:49:53 +0000",
    "user" : {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "protected" : false,
      "id_str" : "23034673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3393754882\/07184fa9526af00257538d818b6f72f7_normal.jpeg",
      "id" : 23034673,
      "verified" : true
    }
  },
  "id" : 600456203450359808,
  "created_at" : "2015-05-19 00:21:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600455012641275904",
  "text" : "RT @POTUS: Hello, Twitter! It's Barack. Really! Six years in, they're finally giving me my own account.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600324682190053376",
    "text" : "Hello, Twitter! It's Barack. Really! Six years in, they're finally giving me my own account.",
    "id" : 600324682190053376,
    "created_at" : "2015-05-18 15:38:52 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 600455012641275904,
  "created_at" : "2015-05-19 00:16:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Paul Turner",
      "screen_name" : "JesusNeedsNewPR",
      "indices" : [ 3, 19 ],
      "id_str" : "727580030084251648",
      "id" : 727580030084251648
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JesusNeedsNewPR\/status\/600448279772536832\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/0yUJarOKOg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFU4h2sXIAE3W9F.jpg",
      "id_str" : "600448279592247297",
      "id" : 600448279592247297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFU4h2sXIAE3W9F.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/0yUJarOKOg"
    } ],
    "hashtags" : [ {
      "text" : "Hillary",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "POTUS",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/V93yrVJaxx",
      "expanded_url" : "http:\/\/ift.tt\/1JVbFFL",
      "display_url" : "ift.tt\/1JVbFFL"
    } ]
  },
  "geo" : { },
  "id_str" : "600453401433010177",
  "text" : "RT @JesusNeedsNewPR: This wins. #Hillary #POTUS #2016 http:\/\/t.co\/V93yrVJaxx http:\/\/t.co\/0yUJarOKOg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JesusNeedsNewPR\/status\/600448279772536832\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/0yUJarOKOg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFU4h2sXIAE3W9F.jpg",
        "id_str" : "600448279592247297",
        "id" : 600448279592247297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFU4h2sXIAE3W9F.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/0yUJarOKOg"
      } ],
      "hashtags" : [ {
        "text" : "Hillary",
        "indices" : [ 11, 19 ]
      }, {
        "text" : "POTUS",
        "indices" : [ 20, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/V93yrVJaxx",
        "expanded_url" : "http:\/\/ift.tt\/1JVbFFL",
        "display_url" : "ift.tt\/1JVbFFL"
      } ]
    },
    "geo" : { },
    "id_str" : "600448279772536832",
    "text" : "This wins. #Hillary #POTUS #2016 http:\/\/t.co\/V93yrVJaxx http:\/\/t.co\/0yUJarOKOg",
    "id" : 600448279772536832,
    "created_at" : "2015-05-18 23:50:00 +0000",
    "user" : {
      "name" : "Matthew Paul Turner",
      "screen_name" : "HeyMPT",
      "protected" : false,
      "id_str" : "10206812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749619882552098816\/HgjwUHtr_normal.jpg",
      "id" : 10206812,
      "verified" : false
    }
  },
  "id" : 600453401433010177,
  "created_at" : "2015-05-19 00:10:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Tapper",
      "screen_name" : "jaketapper",
      "indices" : [ 3, 14 ],
      "id_str" : "14529929",
      "id" : 14529929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/yyhkpYaUoM",
      "expanded_url" : "http:\/\/cnn.it\/1JUQtj0",
      "display_url" : "cnn.it\/1JUQtj0"
    } ]
  },
  "geo" : { },
  "id_str" : "600452973542711297",
  "text" : "RT @jaketapper: Soldier dies in police custody screaming: I'm choking on my blood http:\/\/t.co\/yyhkpYaUoM Warning: Video hard to watch http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheLeadCNN\/status\/600423803156586497\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/L1vONoBS4d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFUiRFtUUAAfeLO.jpg",
        "id_str" : "600423802309201920",
        "id" : 600423802309201920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFUiRFtUUAAfeLO.jpg",
        "sizes" : [ {
          "h" : 438,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/L1vONoBS4d"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/yyhkpYaUoM",
        "expanded_url" : "http:\/\/cnn.it\/1JUQtj0",
        "display_url" : "cnn.it\/1JUQtj0"
      } ]
    },
    "geo" : { },
    "id_str" : "600431194811994113",
    "text" : "Soldier dies in police custody screaming: I'm choking on my blood http:\/\/t.co\/yyhkpYaUoM Warning: Video hard to watch http:\/\/t.co\/L1vONoBS4d",
    "id" : 600431194811994113,
    "created_at" : "2015-05-18 22:42:06 +0000",
    "user" : {
      "name" : "Jake Tapper",
      "screen_name" : "jaketapper",
      "protected" : false,
      "id_str" : "14529929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416044148425502720\/FRKCS5pH_normal.jpeg",
      "id" : 14529929,
      "verified" : true
    }
  },
  "id" : 600452973542711297,
  "created_at" : "2015-05-19 00:08:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600451419867631616",
  "text" : "RT @Joshua_St_John: Cherry caught this shot of a vicious Rottweiler terrorizing the neighborhood. Chilling. Just chilling. http:\/\/t.co\/HLDL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joshua_St_John\/status\/600449716082511873\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/HLDLLZQ3pn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFU51FAUsAAOAgC.jpg",
        "id_str" : "600449709363212288",
        "id" : 600449709363212288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFU51FAUsAAOAgC.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HLDLLZQ3pn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600449716082511873",
    "text" : "Cherry caught this shot of a vicious Rottweiler terrorizing the neighborhood. Chilling. Just chilling. http:\/\/t.co\/HLDLLZQ3pn",
    "id" : 600449716082511873,
    "created_at" : "2015-05-18 23:55:42 +0000",
    "user" : {
      "name" : "\uD83C\uDF84Joshua \u2603\uFE0F",
      "screen_name" : "ALifeRelentless",
      "protected" : false,
      "id_str" : "197910360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770384906639724544\/mN91OZP1_normal.jpg",
      "id" : 197910360,
      "verified" : false
    }
  },
  "id" : 600451419867631616,
  "created_at" : "2015-05-19 00:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 31 ],
      "url" : "https:\/\/t.co\/gHxBjVCGS6",
      "expanded_url" : "https:\/\/twitter.com\/Lluminous_\/status\/600278425778003969",
      "display_url" : "twitter.com\/Lluminous_\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600418119241306113",
  "text" : "deep... https:\/\/t.co\/gHxBjVCGS6",
  "id" : 600418119241306113,
  "created_at" : "2015-05-18 21:50:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Schell",
      "screen_name" : "DavidMSchell",
      "indices" : [ 3, 16 ],
      "id_str" : "393079584",
      "id" : 393079584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/oUOCr91oLK",
      "expanded_url" : "http:\/\/wp.me\/p4gI8n-IT",
      "display_url" : "wp.me\/p4gI8n-IT"
    } ]
  },
  "geo" : { },
  "id_str" : "600358894779691008",
  "text" : "RT @DavidMSchell: New post: The Myth of \"Biblical Christianity\" http:\/\/t.co\/oUOCr91oLK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/oUOCr91oLK",
        "expanded_url" : "http:\/\/wp.me\/p4gI8n-IT",
        "display_url" : "wp.me\/p4gI8n-IT"
      } ]
    },
    "geo" : { },
    "id_str" : "600325739523649537",
    "text" : "New post: The Myth of \"Biblical Christianity\" http:\/\/t.co\/oUOCr91oLK",
    "id" : 600325739523649537,
    "created_at" : "2015-05-18 15:43:04 +0000",
    "user" : {
      "name" : "David Schell",
      "screen_name" : "DavidMSchell",
      "protected" : false,
      "id_str" : "393079584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452547994760409088\/SStgaaJv_normal.jpeg",
      "id" : 393079584,
      "verified" : false
    }
  },
  "id" : 600358894779691008,
  "created_at" : "2015-05-18 17:54:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kfuller",
      "screen_name" : "Kfuller117",
      "indices" : [ 3, 14 ],
      "id_str" : "3229686363",
      "id" : 3229686363
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Kfuller117\/status\/600079433513443328\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/F0FOBRWtv9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFPpD1YUsAA2Z8z.jpg",
      "id_str" : "600079427448385536",
      "id" : 600079427448385536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFPpD1YUsAA2Z8z.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/F0FOBRWtv9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600079627151880193",
  "text" : "RT @Kfuller117: http:\/\/t.co\/F0FOBRWtv9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kfuller117\/status\/600079433513443328\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/F0FOBRWtv9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFPpD1YUsAA2Z8z.jpg",
        "id_str" : "600079427448385536",
        "id" : 600079427448385536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFPpD1YUsAA2Z8z.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/F0FOBRWtv9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600079433513443328",
    "text" : "http:\/\/t.co\/F0FOBRWtv9",
    "id" : 600079433513443328,
    "created_at" : "2015-05-17 23:24:20 +0000",
    "user" : {
      "name" : "Kfuller",
      "screen_name" : "Kfuller117",
      "protected" : false,
      "id_str" : "3229686363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726769435881644033\/uOlOfcLt_normal.jpg",
      "id" : 3229686363,
      "verified" : false
    }
  },
  "id" : 600079627151880193,
  "created_at" : "2015-05-17 23:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "indices" : [ 3, 12 ],
      "id_str" : "2375492109",
      "id" : 2375492109
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/599984142399438848\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/3KVPIGZA0x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFOSZgJWAAA2PLr.jpg",
      "id_str" : "599984142193917952",
      "id" : 599984142193917952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFOSZgJWAAA2PLr.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/3KVPIGZA0x"
    } ],
    "hashtags" : [ {
      "text" : "canadageese",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600076921230209024",
  "text" : "RT @cw_mills: mum looking after goslings #canadageese http:\/\/t.co\/3KVPIGZA0x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cw_mills\/status\/599984142399438848\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/3KVPIGZA0x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFOSZgJWAAA2PLr.jpg",
        "id_str" : "599984142193917952",
        "id" : 599984142193917952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFOSZgJWAAA2PLr.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/3KVPIGZA0x"
      } ],
      "hashtags" : [ {
        "text" : "canadageese",
        "indices" : [ 27, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599984142399438848",
    "text" : "mum looking after goslings #canadageese http:\/\/t.co\/3KVPIGZA0x",
    "id" : 599984142399438848,
    "created_at" : "2015-05-17 17:05:41 +0000",
    "user" : {
      "name" : "Harry Mills",
      "screen_name" : "cw_mills",
      "protected" : false,
      "id_str" : "2375492109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648076476613533696\/1aq5VLpS_normal.jpg",
      "id" : 2375492109,
      "verified" : false
    }
  },
  "id" : 600076921230209024,
  "created_at" : "2015-05-17 23:14:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BirdNote",
      "screen_name" : "BirdNoteRadio",
      "indices" : [ 3, 17 ],
      "id_str" : "111359139",
      "id" : 111359139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/5OabYgvLVC",
      "expanded_url" : "http:\/\/birdnote.org\/show\/robins-raise-brood-hurry",
      "display_url" : "birdnote.org\/show\/robins-ra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600073951356780544",
  "text" : "RT @BirdNoteRadio: http:\/\/t.co\/5OabYgvLVC Didn\u2019t robins just return North? Many are now feeding chicks \u2014 each ~40 times a day! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BirdNoteRadio\/status\/599919826442682368\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/OOM2RXZ68q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFIqj0CW0AAOYsQ.jpg",
        "id_str" : "599588495146012672",
        "id" : 599588495146012672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFIqj0CW0AAOYsQ.jpg",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/OOM2RXZ68q"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/5OabYgvLVC",
        "expanded_url" : "http:\/\/birdnote.org\/show\/robins-raise-brood-hurry",
        "display_url" : "birdnote.org\/show\/robins-ra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599919826442682368",
    "text" : "http:\/\/t.co\/5OabYgvLVC Didn\u2019t robins just return North? Many are now feeding chicks \u2014 each ~40 times a day! http:\/\/t.co\/OOM2RXZ68q",
    "id" : 599919826442682368,
    "created_at" : "2015-05-17 12:50:07 +0000",
    "user" : {
      "name" : "BirdNote",
      "screen_name" : "BirdNoteRadio",
      "protected" : false,
      "id_str" : "111359139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459464891124826112\/Zin-PcNV_normal.jpeg",
      "id" : 111359139,
      "verified" : true
    }
  },
  "id" : 600073951356780544,
  "created_at" : "2015-05-17 23:02:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Hoshaw",
      "screen_name" : "ahoshaw",
      "indices" : [ 3, 11 ],
      "id_str" : "2180288557",
      "id" : 2180288557
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 93, 99 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/KVKcIMlzLX",
      "expanded_url" : "http:\/\/www.wired.com\/2015\/05\/feds-say-banned-researcher-commandeered-plane\/",
      "display_url" : "wired.com\/2015\/05\/feds-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600061981333282818",
  "text" : "RT @ahoshaw: Feds Say That Banned Researcher Commandeered a Plane http:\/\/t.co\/KVKcIMlzLX via @WIRED",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 80, 86 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/KVKcIMlzLX",
        "expanded_url" : "http:\/\/www.wired.com\/2015\/05\/feds-say-banned-researcher-commandeered-plane\/",
        "display_url" : "wired.com\/2015\/05\/feds-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599948112220794881",
    "text" : "Feds Say That Banned Researcher Commandeered a Plane http:\/\/t.co\/KVKcIMlzLX via @WIRED",
    "id" : 599948112220794881,
    "created_at" : "2015-05-17 14:42:31 +0000",
    "user" : {
      "name" : "Anthony Hoshaw",
      "screen_name" : "ahoshaw",
      "protected" : false,
      "id_str" : "2180288557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725485378640039937\/tzuMHC4W_normal.jpg",
      "id" : 2180288557,
      "verified" : false
    }
  },
  "id" : 600061981333282818,
  "created_at" : "2015-05-17 22:14:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 3, 12 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/599960494636736512\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/6sLONgAM1k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFN84_QWIAAVhYT.jpg",
      "id_str" : "599960493864919040",
      "id" : 599960493864919040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFN84_QWIAAVhYT.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      } ],
      "display_url" : "pic.twitter.com\/6sLONgAM1k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599963857742868481",
  "text" : "RT @BobTarte: Yellow Warbler, Magee Marsh Estuary Trail. Not sure if this is first-year male or bright female. http:\/\/t.co\/6sLONgAM1k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/599960494636736512\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/6sLONgAM1k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFN84_QWIAAVhYT.jpg",
        "id_str" : "599960493864919040",
        "id" : 599960493864919040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFN84_QWIAAVhYT.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/6sLONgAM1k"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599960494636736512",
    "text" : "Yellow Warbler, Magee Marsh Estuary Trail. Not sure if this is first-year male or bright female. http:\/\/t.co\/6sLONgAM1k",
    "id" : 599960494636736512,
    "created_at" : "2015-05-17 15:31:43 +0000",
    "user" : {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "protected" : false,
      "id_str" : "490591746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570578729\/6y9pn9ap800am8pkqsku_normal.jpeg",
      "id" : 490591746,
      "verified" : false
    }
  },
  "id" : 599963857742868481,
  "created_at" : "2015-05-17 15:45:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aku News",
      "screen_name" : "an_blogs",
      "indices" : [ 3, 12 ],
      "id_str" : "1419037717",
      "id" : 1419037717
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/an_blogs\/status\/599859435373133824\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/CjP94FPN3d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFMg-mVVIAANW1w.jpg",
      "id_str" : "599859435184398336",
      "id" : 599859435184398336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFMg-mVVIAANW1w.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 863
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 863
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CjP94FPN3d"
    } ],
    "hashtags" : [ {
      "text" : "architecture",
      "indices" : [ 63, 76 ]
    }, {
      "text" : "photo",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "travel",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599949277272657920",
  "text" : "RT @an_blogs: an old, wooden house in countryside of Finland - #architecture #photo by Aku Eronen #travel http:\/\/t.co\/CjP94FPN3d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/manageflitter.com\" rel=\"nofollow\"\u003EManageFlitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/an_blogs\/status\/599859435373133824\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/CjP94FPN3d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFMg-mVVIAANW1w.jpg",
        "id_str" : "599859435184398336",
        "id" : 599859435184398336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFMg-mVVIAANW1w.jpg",
        "sizes" : [ {
          "h" : 381,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 863
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 863
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CjP94FPN3d"
      } ],
      "hashtags" : [ {
        "text" : "architecture",
        "indices" : [ 49, 62 ]
      }, {
        "text" : "photo",
        "indices" : [ 63, 69 ]
      }, {
        "text" : "travel",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599859435373133824",
    "text" : "an old, wooden house in countryside of Finland - #architecture #photo by Aku Eronen #travel http:\/\/t.co\/CjP94FPN3d",
    "id" : 599859435373133824,
    "created_at" : "2015-05-17 08:50:08 +0000",
    "user" : {
      "name" : "Aku News",
      "screen_name" : "an_blogs",
      "protected" : false,
      "id_str" : "1419037717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659858574357749760\/6DzLhRKi_normal.jpg",
      "id" : 1419037717,
      "verified" : false
    }
  },
  "id" : 599949277272657920,
  "created_at" : "2015-05-17 14:47:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NAKBA",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "BoycottIsrael",
      "indices" : [ 105, 119 ]
    }, {
      "text" : "FreePalestine",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599949240136310784",
  "text" : "RT @JamiaStarheart: Not global warming, not natural erosion but Israeli ethnic cleansing at work. #NAKBA #BoycottIsrael #FreePalestine http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Aboujahjah\/status\/599124347320725504\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/UBEEiZnoPq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFCEaRBVIAAuLHl.jpg",
        "id_str" : "599124337220722688",
        "id" : 599124337220722688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFCEaRBVIAAuLHl.jpg",
        "sizes" : [ {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/UBEEiZnoPq"
      } ],
      "hashtags" : [ {
        "text" : "NAKBA",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "BoycottIsrael",
        "indices" : [ 85, 99 ]
      }, {
        "text" : "FreePalestine",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599909945245626369",
    "text" : "Not global warming, not natural erosion but Israeli ethnic cleansing at work. #NAKBA #BoycottIsrael #FreePalestine http:\/\/t.co\/UBEEiZnoPq",
    "id" : 599909945245626369,
    "created_at" : "2015-05-17 12:10:51 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 599949240136310784,
  "created_at" : "2015-05-17 14:47:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "indices" : [ 3, 19 ],
      "id_str" : "239313282",
      "id" : 239313282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599737041585319936",
  "text" : "RT @saatchi_gallery: Cameron Bloom beautifully photographs his son Noah with the family's rescued pet magpie called Penguin http:\/\/t.co\/6TD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/saatchi_gallery\/status\/586053720137408512\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/6TDgOHbj4F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCIUwMlW4AA6NMH.png",
        "id_str" : "586053719755776000",
        "id" : 586053719755776000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCIUwMlW4AA6NMH.png",
        "sizes" : [ {
          "h" : 987,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1174,
          "resize" : "fit",
          "w" : 1218
        }, {
          "h" : 578,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6TDgOHbj4F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586053720137408512",
    "text" : "Cameron Bloom beautifully photographs his son Noah with the family's rescued pet magpie called Penguin http:\/\/t.co\/6TDgOHbj4F",
    "id" : 586053720137408512,
    "created_at" : "2015-04-09 06:31:09 +0000",
    "user" : {
      "name" : "Saatchi Gallery",
      "screen_name" : "saatchi_gallery",
      "protected" : false,
      "id_str" : "239313282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1217964288\/sg_normal.jpg",
      "id" : 239313282,
      "verified" : true
    }
  },
  "id" : 599737041585319936,
  "created_at" : "2015-05-17 00:43:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599736775989456896",
  "text" : "RT @fairlyspiritual: Christian books that narrowly define masculinity\/femininity do not honor the God-given diversity that exists in every \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599734668888412160",
    "text" : "Christian books that narrowly define masculinity\/femininity do not honor the God-given diversity that exists in every human &amp; every gender.",
    "id" : 599734668888412160,
    "created_at" : "2015-05-17 00:34:22 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 599736775989456896,
  "created_at" : "2015-05-17 00:42:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599736579473678336",
  "text" : "RT @Buddhaworld: I hope when i die, i have done a bit more good then bad, if i did, all will be fine. Volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599734210274942976",
    "text" : "I hope when i die, i have done a bit more good then bad, if i did, all will be fine. Volko",
    "id" : 599734210274942976,
    "created_at" : "2015-05-17 00:32:32 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 599736579473678336,
  "created_at" : "2015-05-17 00:41:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Godless Father",
      "screen_name" : "ThGodlessFather",
      "indices" : [ 3, 19 ],
      "id_str" : "3119074766",
      "id" : 3119074766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/F8T2bKWgYG",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/friendlyatheist\/2015\/05\/13\/christian-evangelist-promotes-new-childrens-book-all-about-eternal-damnation\/",
      "display_url" : "patheos.com\/blogs\/friendly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599736099980890112",
  "text" : "RT @ThGodlessFather: Christian Evangelist Promotes New Children\u2019s Book\u2026 All About Eternal Damnation\n\nhttp:\/\/t.co\/F8T2bKWgYG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/F8T2bKWgYG",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/friendlyatheist\/2015\/05\/13\/christian-evangelist-promotes-new-childrens-book-all-about-eternal-damnation\/",
        "display_url" : "patheos.com\/blogs\/friendly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599703958647476224",
    "text" : "Christian Evangelist Promotes New Children\u2019s Book\u2026 All About Eternal Damnation\n\nhttp:\/\/t.co\/F8T2bKWgYG",
    "id" : 599703958647476224,
    "created_at" : "2015-05-16 22:32:20 +0000",
    "user" : {
      "name" : "The Godless Father",
      "screen_name" : "ThGodlessFather",
      "protected" : false,
      "id_str" : "3119074766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582754401959329792\/vSi75ZMn_normal.png",
      "id" : 3119074766,
      "verified" : false
    }
  },
  "id" : 599736099980890112,
  "created_at" : "2015-05-17 00:40:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leefeller Guy",
      "screen_name" : "Leefellerguy",
      "indices" : [ 0, 13 ],
      "id_str" : "460584206",
      "id" : 460584206
    }, {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 14, 30 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599709888135081984",
  "geo" : { },
  "id_str" : "599720387459600386",
  "in_reply_to_user_id" : 460584206,
  "text" : "@Leefellerguy @AWorldOutOfMind lol.. Had to look up solipsist.. interesting.",
  "id" : 599720387459600386,
  "in_reply_to_status_id" : 599709888135081984,
  "created_at" : "2015-05-16 23:37:37 +0000",
  "in_reply_to_screen_name" : "Leefellerguy",
  "in_reply_to_user_id_str" : "460584206",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reservoir Jesus",
      "screen_name" : "JesusChitChat",
      "indices" : [ 3, 17 ],
      "id_str" : "459852491",
      "id" : 459852491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JesusChitChat\/status\/599703402214490112\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/S9FJYeVp0o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFKTER4WAAEApEP.jpg",
      "id_str" : "599703402122182657",
      "id" : 599703402122182657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFKTER4WAAEApEP.jpg",
      "sizes" : [ {
        "h" : 433,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/S9FJYeVp0o"
    } ],
    "hashtags" : [ {
      "text" : "GlennBeck",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "uniteBlue",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/k6OPtvapRO",
      "expanded_url" : "http:\/\/bit.ly\/1d7L7GY",
      "display_url" : "bit.ly\/1d7L7GY"
    } ]
  },
  "geo" : { },
  "id_str" : "599708231196344321",
  "text" : "RT @JesusChitChat: #GlennBeck: Free Education Will Make You A Slave #uniteBlue http:\/\/t.co\/k6OPtvapRO http:\/\/t.co\/S9FJYeVp0o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JesusChitChat\/status\/599703402214490112\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/S9FJYeVp0o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFKTER4WAAEApEP.jpg",
        "id_str" : "599703402122182657",
        "id" : 599703402122182657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFKTER4WAAEApEP.jpg",
        "sizes" : [ {
          "h" : 433,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/S9FJYeVp0o"
      } ],
      "hashtags" : [ {
        "text" : "GlennBeck",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "uniteBlue",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/k6OPtvapRO",
        "expanded_url" : "http:\/\/bit.ly\/1d7L7GY",
        "display_url" : "bit.ly\/1d7L7GY"
      } ]
    },
    "geo" : { },
    "id_str" : "599703402214490112",
    "text" : "#GlennBeck: Free Education Will Make You A Slave #uniteBlue http:\/\/t.co\/k6OPtvapRO http:\/\/t.co\/S9FJYeVp0o",
    "id" : 599703402214490112,
    "created_at" : "2015-05-16 22:30:07 +0000",
    "user" : {
      "name" : "Reservoir Jesus",
      "screen_name" : "JesusChitChat",
      "protected" : false,
      "id_str" : "459852491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529465579158003713\/40e-n4YU_normal.png",
      "id" : 459852491,
      "verified" : false
    }
  },
  "id" : 599708231196344321,
  "created_at" : "2015-05-16 22:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leefeller Guy",
      "screen_name" : "Leefellerguy",
      "indices" : [ 0, 13 ],
      "id_str" : "460584206",
      "id" : 460584206
    }, {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 14, 30 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599704600413736960",
  "geo" : { },
  "id_str" : "599707817814155264",
  "in_reply_to_user_id" : 460584206,
  "text" : "@Leefellerguy @AWorldOutOfMind hey.. What does introvert have to do with it?? Signed Introvert Liberal",
  "id" : 599707817814155264,
  "in_reply_to_status_id" : 599704600413736960,
  "created_at" : "2015-05-16 22:47:40 +0000",
  "in_reply_to_screen_name" : "Leefellerguy",
  "in_reply_to_user_id_str" : "460584206",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "indices" : [ 3, 17 ],
      "id_str" : "39764564",
      "id" : 39764564
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ruslandvalley\/status\/599690911057113088\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/dN3ESFQaaK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFKHtMmWIAEziUV.jpg",
      "id_str" : "599690910939619329",
      "id" : 599690910939619329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFKHtMmWIAEziUV.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/dN3ESFQaaK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599699047587385344",
  "text" : "RT @ruslandvalley: Geese on the top of Bethecar. http:\/\/t.co\/dN3ESFQaaK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ruslandvalley\/status\/599690911057113088\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/dN3ESFQaaK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFKHtMmWIAEziUV.jpg",
        "id_str" : "599690910939619329",
        "id" : 599690910939619329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFKHtMmWIAEziUV.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/dN3ESFQaaK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599690911057113088",
    "text" : "Geese on the top of Bethecar. http:\/\/t.co\/dN3ESFQaaK",
    "id" : 599690911057113088,
    "created_at" : "2015-05-16 21:40:29 +0000",
    "user" : {
      "name" : "RuslandShepherdess",
      "screen_name" : "ruslandvalley",
      "protected" : false,
      "id_str" : "39764564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724649178589179904\/f5KDvdpC_normal.jpg",
      "id" : 39764564,
      "verified" : false
    }
  },
  "id" : 599699047587385344,
  "created_at" : "2015-05-16 22:12:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DartmoorTweed\/status\/599692583808401408\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/fBGf78pL1y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFKJMUyWIAE9Sc7.jpg",
      "id_str" : "599692545225007105",
      "id" : 599692545225007105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFKJMUyWIAE9Sc7.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fBGf78pL1y"
    } ],
    "hashtags" : [ {
      "text" : "sheep",
      "indices" : [ 79, 85 ]
    }, {
      "text" : "lambs",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "woolisace",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "woolly",
      "indices" : [ 104, 111 ]
    }, {
      "text" : "wool",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599698740249780226",
  "text" : "RT @DartmoorTweed: \u2764\uFE0F my little mixed flock and they love our telegraph pole ? #sheep #lambs #woolisace #woolly #wool http:\/\/t.co\/fBGf78pL1y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DartmoorTweed\/status\/599692583808401408\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/fBGf78pL1y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFKJMUyWIAE9Sc7.jpg",
        "id_str" : "599692545225007105",
        "id" : 599692545225007105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFKJMUyWIAE9Sc7.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fBGf78pL1y"
      } ],
      "hashtags" : [ {
        "text" : "sheep",
        "indices" : [ 60, 66 ]
      }, {
        "text" : "lambs",
        "indices" : [ 67, 73 ]
      }, {
        "text" : "woolisace",
        "indices" : [ 74, 84 ]
      }, {
        "text" : "woolly",
        "indices" : [ 85, 92 ]
      }, {
        "text" : "wool",
        "indices" : [ 93, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599692583808401408",
    "text" : "\u2764\uFE0F my little mixed flock and they love our telegraph pole ? #sheep #lambs #woolisace #woolly #wool http:\/\/t.co\/fBGf78pL1y",
    "id" : 599692583808401408,
    "created_at" : "2015-05-16 21:47:08 +0000",
    "user" : {
      "name" : "SouthWestWoolFest",
      "screen_name" : "SWWoolFest",
      "protected" : false,
      "id_str" : "2788705551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780366884831109120\/6uh3Zi-S_normal.jpg",
      "id" : 2788705551,
      "verified" : false
    }
  },
  "id" : 599698740249780226,
  "created_at" : "2015-05-16 22:11:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 79, 94 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/FgYdWgy8T4",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/05\/death-by-duck-the-photograph-that-almost-killed-me\/",
      "display_url" : "brucegerencser.net\/2015\/05\/death-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599688829289832448",
  "text" : "Death by Duck: The Photograph that Almost Killed Me http:\/\/t.co\/FgYdWgy8T4 via @BruceGerencser",
  "id" : 599688829289832448,
  "created_at" : "2015-05-16 21:32:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599647612464144384",
  "text" : "She has GI doc appt next wk. Will discuss anxiety meds w primary doc in 2 wks.",
  "id" : 599647612464144384,
  "created_at" : "2015-05-16 18:48:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599647060019826688",
  "text" : "We were supposed to go to grad party today but DD not feeling up to it. Still recovering from last week.",
  "id" : 599647060019826688,
  "created_at" : "2015-05-16 18:46:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "indices" : [ 3, 18 ],
      "id_str" : "189759304",
      "id" : 189759304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/PsdIOxrtn8",
      "expanded_url" : "https:\/\/defeatingthedragons.wordpress.com\/2015\/05\/15\/teaching-virginity-is-anti-christian\/",
      "display_url" : "defeatingthedragons.wordpress.com\/2015\/05\/15\/tea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599594650681348096",
  "text" : "RT @samanthapfield: NEW POST: teaching virginity is anti-Christian. https:\/\/t.co\/PsdIOxrtn8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/PsdIOxrtn8",
        "expanded_url" : "https:\/\/defeatingthedragons.wordpress.com\/2015\/05\/15\/teaching-virginity-is-anti-christian\/",
        "display_url" : "defeatingthedragons.wordpress.com\/2015\/05\/15\/tea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599244382903078912",
    "text" : "NEW POST: teaching virginity is anti-Christian. https:\/\/t.co\/PsdIOxrtn8",
    "id" : 599244382903078912,
    "created_at" : "2015-05-15 16:06:08 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 599594650681348096,
  "created_at" : "2015-05-16 15:17:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ycc7mNI1qv",
      "expanded_url" : "http:\/\/magazine.good.is\/articles\/tea-never-looked-so-good",
      "display_url" : "magazine.good.is\/articles\/tea-n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599572107652128768",
  "text" : "Understand Consent With the Help of Stick Figures and a Cup of Tea http:\/\/t.co\/ycc7mNI1qv",
  "id" : 599572107652128768,
  "created_at" : "2015-05-16 13:48:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "indices" : [ 3, 14 ],
      "id_str" : "2236808551",
      "id" : 2236808551
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JenLRPhoto\/status\/599265096062279680\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/XSKTOiKWvz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFEEa1lUkAAukrp.jpg",
      "id_str" : "599265084523712512",
      "id" : 599265084523712512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFEEa1lUkAAukrp.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 641,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 641,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XSKTOiKWvz"
    } ],
    "hashtags" : [ {
      "text" : "finches",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "photography",
      "indices" : [ 36, 48 ]
    }, {
      "text" : "birds",
      "indices" : [ 49, 55 ]
    }, {
      "text" : "goldfinch",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "natureisbeauty",
      "indices" : [ 67, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599377670460317696",
  "text" : "RT @JenLRPhoto: Tree of #finches :) #photography #birds #goldfinch #natureisbeauty http:\/\/t.co\/XSKTOiKWvz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JenLRPhoto\/status\/599265096062279680\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/XSKTOiKWvz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFEEa1lUkAAukrp.jpg",
        "id_str" : "599265084523712512",
        "id" : 599265084523712512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFEEa1lUkAAukrp.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 641,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 641,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XSKTOiKWvz"
      } ],
      "hashtags" : [ {
        "text" : "finches",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "photography",
        "indices" : [ 20, 32 ]
      }, {
        "text" : "birds",
        "indices" : [ 33, 39 ]
      }, {
        "text" : "goldfinch",
        "indices" : [ 40, 50 ]
      }, {
        "text" : "natureisbeauty",
        "indices" : [ 51, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599265096062279680",
    "text" : "Tree of #finches :) #photography #birds #goldfinch #natureisbeauty http:\/\/t.co\/XSKTOiKWvz",
    "id" : 599265096062279680,
    "created_at" : "2015-05-15 17:28:27 +0000",
    "user" : {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "protected" : false,
      "id_str" : "2236808551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916989995909120\/ZPqHp6yp_normal.jpg",
      "id" : 2236808551,
      "verified" : false
    }
  },
  "id" : 599377670460317696,
  "created_at" : "2015-05-16 00:55:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599353346600861696",
  "geo" : { },
  "id_str" : "599358030535335936",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley donkeys! : )",
  "id" : 599358030535335936,
  "in_reply_to_status_id" : 599353346600861696,
  "created_at" : "2015-05-15 23:37:44 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599353565698662400",
  "geo" : { },
  "id_str" : "599357776125648896",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft oh my... Is he for real? Ugh.",
  "id" : 599357776125648896,
  "in_reply_to_status_id" : 599353565698662400,
  "created_at" : "2015-05-15 23:36:44 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 63, 73 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/lYEam9tqNP",
      "expanded_url" : "https:\/\/shar.es\/1rub5d",
      "display_url" : "shar.es\/1rub5d"
    } ]
  },
  "geo" : { },
  "id_str" : "599292953002147840",
  "text" : "An Open Letter to Duggar Defenders https:\/\/t.co\/lYEam9tqNP via @sharethis",
  "id" : 599292953002147840,
  "created_at" : "2015-05-15 19:19:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sherry borgstrom",
      "screen_name" : "sherry4201",
      "indices" : [ 3, 14 ],
      "id_str" : "2756388564",
      "id" : 2756388564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/PQOPeolC0F",
      "expanded_url" : "http:\/\/www.rawstory.com\/2015\/05\/tennessee-republican-who-pressured-mistress-to-have-abortion-votes-to-restrict-them-for-other-women\/#.VVYb2gRT6tE.twitter",
      "display_url" : "rawstory.com\/2015\/05\/tennes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599247800665317376",
  "text" : "RT @sherry4201: Tennessee Republican who pressured mistress to have abortion votes to restrict them for other women http:\/\/t.co\/PQOPeolC0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/PQOPeolC0F",
        "expanded_url" : "http:\/\/www.rawstory.com\/2015\/05\/tennessee-republican-who-pressured-mistress-to-have-abortion-votes-to-restrict-them-for-other-women\/#.VVYb2gRT6tE.twitter",
        "display_url" : "rawstory.com\/2015\/05\/tennes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "599246990543695872",
    "text" : "Tennessee Republican who pressured mistress to have abortion votes to restrict them for other women http:\/\/t.co\/PQOPeolC0F",
    "id" : 599246990543695872,
    "created_at" : "2015-05-15 16:16:30 +0000",
    "user" : {
      "name" : "sherry borgstrom",
      "screen_name" : "sherry4201",
      "protected" : false,
      "id_str" : "2756388564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713459123942195200\/tKvr0UU5_normal.jpg",
      "id" : 2756388564,
      "verified" : false
    }
  },
  "id" : 599247800665317376,
  "created_at" : "2015-05-15 16:19:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599237429351084033",
  "geo" : { },
  "id_str" : "599240895716859904",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem Ugh! WTF.",
  "id" : 599240895716859904,
  "in_reply_to_status_id" : 599237429351084033,
  "created_at" : "2015-05-15 15:52:17 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "599236930065342464",
  "geo" : { },
  "id_str" : "599240587167047680",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem ((hugs))",
  "id" : 599240587167047680,
  "in_reply_to_status_id" : 599236930065342464,
  "created_at" : "2015-05-15 15:51:03 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Word Monger",
      "screen_name" : "Tazatator",
      "indices" : [ 3, 13 ],
      "id_str" : "350018443",
      "id" : 350018443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599014081769648128",
  "text" : "RT @Tazatator: A typical politician shapes their rhetoric around popular opinion. When they vote on a Bill, they mind mostly lobbyists. Con\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598192959599706112",
    "text" : "A typical politician shapes their rhetoric around popular opinion. When they vote on a Bill, they mind mostly lobbyists. Constitution? HA",
    "id" : 598192959599706112,
    "created_at" : "2015-05-12 18:28:10 +0000",
    "user" : {
      "name" : "Word Monger",
      "screen_name" : "Tazatator",
      "protected" : false,
      "id_str" : "350018443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648848842201280512\/0Y2zGpau_normal.jpg",
      "id" : 350018443,
      "verified" : false
    }
  },
  "id" : 599014081769648128,
  "created_at" : "2015-05-15 00:51:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "indices" : [ 3, 18 ],
      "id_str" : "189759304",
      "id" : 189759304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599003875585224704",
  "text" : "RT @samanthapfield: I'm working on a post for tomorrow with the title \"Teaching Virginity is Anti-Christian\" because I, of course, *never* \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599002103290470400",
    "text" : "I'm working on a post for tomorrow with the title \"Teaching Virginity is Anti-Christian\" because I, of course, *never* court controversy.",
    "id" : 599002103290470400,
    "created_at" : "2015-05-15 00:03:25 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 599003875585224704,
  "created_at" : "2015-05-15 00:10:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "indices" : [ 3, 15 ],
      "id_str" : "23034673",
      "id" : 23034673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Bl0LhchKlG",
      "expanded_url" : "http:\/\/tinyurl.com\/ntv6n8m",
      "display_url" : "tinyurl.com\/ntv6n8m"
    } ]
  },
  "geo" : { },
  "id_str" : "598890409205624833",
  "text" : "RT @hemantmehta: Arizona Christians Work Together\u2026 To Destroy the One Progressive Church in the Area http:\/\/t.co\/Bl0LhchKlG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/Bl0LhchKlG",
        "expanded_url" : "http:\/\/tinyurl.com\/ntv6n8m",
        "display_url" : "tinyurl.com\/ntv6n8m"
      } ]
    },
    "geo" : { },
    "id_str" : "598889783704694785",
    "text" : "Arizona Christians Work Together\u2026 To Destroy the One Progressive Church in the Area http:\/\/t.co\/Bl0LhchKlG",
    "id" : 598889783704694785,
    "created_at" : "2015-05-14 16:37:05 +0000",
    "user" : {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "protected" : false,
      "id_str" : "23034673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3393754882\/07184fa9526af00257538d818b6f72f7_normal.jpeg",
      "id" : 23034673,
      "verified" : true
    }
  },
  "id" : 598890409205624833,
  "created_at" : "2015-05-14 16:39:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/TslUwD0bv0",
      "expanded_url" : "https:\/\/shar.es\/1rsydM",
      "display_url" : "shar.es\/1rsydM"
    } ]
  },
  "geo" : { },
  "id_str" : "598886713130385409",
  "text" : "Why Are Palo Alto's Kids Killing Themselves? https:\/\/t.co\/TslUwD0bv0",
  "id" : 598886713130385409,
  "created_at" : "2015-05-14 16:24:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/VaXSDCFAlq",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/rachelzarrell\/professor-teaches-life-lessons",
      "display_url" : "buzzfeed.com\/rachelzarrell\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598840176828383232",
  "text" : "When A Student\u2019s Baby Started Crying In Class, This Professor Did The Most Awesome Thing http:\/\/t.co\/VaXSDCFAlq",
  "id" : 598840176828383232,
  "created_at" : "2015-05-14 13:19:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/uQ093WeEfO",
      "expanded_url" : "https:\/\/instagram.com\/p\/2pNZeuPzTD\/",
      "display_url" : "instagram.com\/p\/2pNZeuPzTD\/"
    } ]
  },
  "geo" : { },
  "id_str" : "598663390211497984",
  "text" : "RT @JacksonPearce: Look a possum! They are charming when they don't know you're in the car, staring. https:\/\/t.co\/uQ093WeEfO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/uQ093WeEfO",
        "expanded_url" : "https:\/\/instagram.com\/p\/2pNZeuPzTD\/",
        "display_url" : "instagram.com\/p\/2pNZeuPzTD\/"
      } ]
    },
    "geo" : { },
    "id_str" : "598661066290241536",
    "text" : "Look a possum! They are charming when they don't know you're in the car, staring. https:\/\/t.co\/uQ093WeEfO",
    "id" : 598661066290241536,
    "created_at" : "2015-05-14 01:28:15 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 598663390211497984,
  "created_at" : "2015-05-14 01:37:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/QzA0WVDI3T",
      "expanded_url" : "https:\/\/www.facebook.com\/LeftyMathProf\/posts\/10155507636455104",
      "display_url" : "facebook.com\/LeftyMathProf\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598639368849457152",
  "text" : "Science for sale  https:\/\/t.co\/QzA0WVDI3T",
  "id" : 598639368849457152,
  "created_at" : "2015-05-14 00:02:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "indices" : [ 3, 11 ],
      "id_str" : "250852478",
      "id" : 250852478
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jeczaja\/status\/598610193254096897\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/Z6saG9tkBU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE6wzHkWIAAixj8.png",
      "id_str" : "598610192738164736",
      "id" : 598610192738164736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE6wzHkWIAAixj8.png",
      "sizes" : [ {
        "h" : 159,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 317
      } ],
      "display_url" : "pic.twitter.com\/Z6saG9tkBU"
    } ],
    "hashtags" : [ {
      "text" : "Jesus",
      "indices" : [ 13, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598611124427300864",
  "text" : "RT @jeczaja: #Jesus said... http:\/\/t.co\/Z6saG9tkBU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeczaja\/status\/598610193254096897\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/Z6saG9tkBU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE6wzHkWIAAixj8.png",
        "id_str" : "598610192738164736",
        "id" : 598610192738164736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE6wzHkWIAAixj8.png",
        "sizes" : [ {
          "h" : 159,
          "resize" : "fit",
          "w" : 317
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 317
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 317
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 317
        } ],
        "display_url" : "pic.twitter.com\/Z6saG9tkBU"
      } ],
      "hashtags" : [ {
        "text" : "Jesus",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598610193254096897",
    "text" : "#Jesus said... http:\/\/t.co\/Z6saG9tkBU",
    "id" : 598610193254096897,
    "created_at" : "2015-05-13 22:06:06 +0000",
    "user" : {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "protected" : false,
      "id_str" : "250852478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545010686699393024\/wxdpPJoe_normal.jpeg",
      "id" : 250852478,
      "verified" : false
    }
  },
  "id" : 598611124427300864,
  "created_at" : "2015-05-13 22:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flow Home",
      "screen_name" : "flowhomeapp",
      "indices" : [ 3, 15 ],
      "id_str" : "2696538775",
      "id" : 2696538775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/iBUNVPqz1F",
      "expanded_url" : "http:\/\/lifehacker.com\/flowhome-turns-your-android-home-screen-into-a-useful-1703498670",
      "display_url" : "lifehacker.com\/flowhome-turns\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598528633192521728",
  "text" : "RT @flowhomeapp: Oh look, we're on lifehacker today! Code at the bottom too if you still need one: http:\/\/t.co\/iBUNVPqz1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/iBUNVPqz1F",
        "expanded_url" : "http:\/\/lifehacker.com\/flowhome-turns-your-android-home-screen-into-a-useful-1703498670",
        "display_url" : "lifehacker.com\/flowhome-turns\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597792160340168704",
    "text" : "Oh look, we're on lifehacker today! Code at the bottom too if you still need one: http:\/\/t.co\/iBUNVPqz1F",
    "id" : 597792160340168704,
    "created_at" : "2015-05-11 15:55:32 +0000",
    "user" : {
      "name" : "Flow Home",
      "screen_name" : "flowhomeapp",
      "protected" : false,
      "id_str" : "2696538775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584115302637658112\/gGYzlxYJ_normal.jpg",
      "id" : 2696538775,
      "verified" : false
    }
  },
  "id" : 598528633192521728,
  "created_at" : "2015-05-13 16:42:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Hartmann",
      "screen_name" : "Thom_Hartmann",
      "indices" : [ 3, 17 ],
      "id_str" : "21414576",
      "id" : 21414576
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 84, 92 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/jLD4aYXj2L",
      "expanded_url" : "http:\/\/youtu.be\/fF72rA4jZqc?a",
      "display_url" : "youtu.be\/fF72rA4jZqc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "598496648382193666",
  "text" : "RT @Thom_Hartmann: When did Rats Become Better than Us?: http:\/\/t.co\/jLD4aYXj2L via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 65, 73 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/jLD4aYXj2L",
        "expanded_url" : "http:\/\/youtu.be\/fF72rA4jZqc?a",
        "display_url" : "youtu.be\/fF72rA4jZqc?a"
      } ]
    },
    "geo" : { },
    "id_str" : "598269192094253058",
    "text" : "When did Rats Become Better than Us?: http:\/\/t.co\/jLD4aYXj2L via @YouTube",
    "id" : 598269192094253058,
    "created_at" : "2015-05-12 23:31:05 +0000",
    "user" : {
      "name" : "Thom Hartmann",
      "screen_name" : "Thom_Hartmann",
      "protected" : false,
      "id_str" : "21414576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1284920980\/thom-2011-150_normal.jpg",
      "id" : 21414576,
      "verified" : true
    }
  },
  "id" : 598496648382193666,
  "created_at" : "2015-05-13 14:34:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598285577881018368",
  "text" : "RT @Lesism: Six months ago, I was convinced suicide was my only way out. Now, I'm happy. Imagine the lives those who weren't so lucky would\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598281574061314048",
    "text" : "Six months ago, I was convinced suicide was my only way out. Now, I'm happy. Imagine the lives those who weren't so lucky would have lived?",
    "id" : 598281574061314048,
    "created_at" : "2015-05-13 00:20:17 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 598285577881018368,
  "created_at" : "2015-05-13 00:36:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598279367408517120",
  "geo" : { },
  "id_str" : "598282079403651072",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem just read thru how sick you've been.. Ugh. Hope DR can do something for you. ((hugs))",
  "id" : 598282079403651072,
  "in_reply_to_status_id" : 598279367408517120,
  "created_at" : "2015-05-13 00:22:17 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeaniene Frost",
      "screen_name" : "Jeaniene_Frost",
      "indices" : [ 3, 18 ],
      "id_str" : "25837521",
      "id" : 25837521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598280376000339968",
  "text" : "RT @Jeaniene_Frost: Gypsy using the TV tray as a headrest. Okay, so she thinks that everything in the house is for her :). http:\/\/t.co\/Me5r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Jeaniene_Frost\/status\/598279440095928320\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Me5r3teY6N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE2D-bRWYAAYvNk.jpg",
        "id_str" : "598279434005798912",
        "id" : 598279434005798912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE2D-bRWYAAYvNk.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/Me5r3teY6N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598279440095928320",
    "text" : "Gypsy using the TV tray as a headrest. Okay, so she thinks that everything in the house is for her :). http:\/\/t.co\/Me5r3teY6N",
    "id" : 598279440095928320,
    "created_at" : "2015-05-13 00:11:48 +0000",
    "user" : {
      "name" : "Jeaniene Frost",
      "screen_name" : "Jeaniene_Frost",
      "protected" : false,
      "id_str" : "25837521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1471122348\/Twitter_Pic__508x640__normal.jpg",
      "id" : 25837521,
      "verified" : false
    }
  },
  "id" : 598280376000339968,
  "created_at" : "2015-05-13 00:15:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeeshan Aleem",
      "screen_name" : "ZeeshanAleem",
      "indices" : [ 79, 92 ],
      "id_str" : "33774289",
      "id" : 33774289
    }, {
      "name" : "Mic",
      "screen_name" : "micnews",
      "indices" : [ 120, 128 ],
      "id_str" : "738709709608353792",
      "id" : 738709709608353792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/vp8wERIweR",
      "expanded_url" : "http:\/\/mic.com\/articles\/117944\/7-charts-show-the-socialist-hellscape-america-would-be-under-bernie-sanders",
      "display_url" : "mic.com\/articles\/11794\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598270284370673664",
  "text" : "7 Charts Show the Socialist Hellscape America Would Be Under Bernie Sanders by @zeeshanaleem http:\/\/t.co\/vp8wERIweR via @MicNews",
  "id" : 598270284370673664,
  "created_at" : "2015-05-12 23:35:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Birds and Critters",
      "screen_name" : "BirdNCritter",
      "indices" : [ 3, 16 ],
      "id_str" : "3137365596",
      "id" : 3137365596
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BirdNCritter\/status\/597424811199963137\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/DNHLUEXMPE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEp6sE3VEAA7Agn.jpg",
      "id_str" : "597424798218653696",
      "id" : 597424798218653696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEp6sE3VEAA7Agn.jpg",
      "sizes" : [ {
        "h" : 596,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DNHLUEXMPE"
    } ],
    "hashtags" : [ {
      "text" : "ducklings",
      "indices" : [ 44, 54 ]
    }, {
      "text" : "nature",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598258645965635584",
  "text" : "RT @BirdNCritter: Mommy mallard leading her #ducklings to the pond. #nature #wildlife http:\/\/t.co\/DNHLUEXMPE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BirdNCritter\/status\/597424811199963137\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/DNHLUEXMPE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEp6sE3VEAA7Agn.jpg",
        "id_str" : "597424798218653696",
        "id" : 597424798218653696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEp6sE3VEAA7Agn.jpg",
        "sizes" : [ {
          "h" : 596,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DNHLUEXMPE"
      } ],
      "hashtags" : [ {
        "text" : "ducklings",
        "indices" : [ 26, 36 ]
      }, {
        "text" : "nature",
        "indices" : [ 50, 57 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597424811199963137",
    "text" : "Mommy mallard leading her #ducklings to the pond. #nature #wildlife http:\/\/t.co\/DNHLUEXMPE",
    "id" : 597424811199963137,
    "created_at" : "2015-05-10 15:35:49 +0000",
    "user" : {
      "name" : "Birds and Critters",
      "screen_name" : "BirdNCritter",
      "protected" : false,
      "id_str" : "3137365596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690607688783294464\/9Qn7WQ_g_normal.jpg",
      "id" : 3137365596,
      "verified" : false
    }
  },
  "id" : 598258645965635584,
  "created_at" : "2015-05-12 22:49:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "598244393682915328",
  "geo" : { },
  "id_str" : "598245090079805440",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny ((hugs))",
  "id" : 598245090079805440,
  "in_reply_to_status_id" : 598244393682915328,
  "created_at" : "2015-05-12 21:55:18 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayerNow",
      "indices" : [ 0, 15 ]
    }, {
      "text" : "Healthcare",
      "indices" : [ 16, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/6h3jRgXrDB",
      "expanded_url" : "https:\/\/twitter.com\/ThatGuySpike\/status\/598200019573821440",
      "display_url" : "twitter.com\/ThatGuySpike\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598201037267312640",
  "text" : "#SinglePayerNow #Healthcare https:\/\/t.co\/6h3jRgXrDB",
  "id" : 598201037267312640,
  "created_at" : "2015-05-12 19:00:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Cantrell",
      "screen_name" : "courtcan",
      "indices" : [ 3, 12 ],
      "id_str" : "144576840",
      "id" : 144576840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598186581426577408",
  "text" : "RT @courtcan: Found this random note in my writing notebook:\n\n\"Marriage = mutant ant lizards that you realize, up close, are an ice cream t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whut",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598152265686323200",
    "text" : "Found this random note in my writing notebook:\n\n\"Marriage = mutant ant lizards that you realize, up close, are an ice cream truck.\"\n\n#whut",
    "id" : 598152265686323200,
    "created_at" : "2015-05-12 15:46:27 +0000",
    "user" : {
      "name" : "Courtney Cantrell",
      "screen_name" : "courtcan",
      "protected" : false,
      "id_str" : "144576840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800923140507377664\/HMzcDjJc_normal.jpg",
      "id" : 144576840,
      "verified" : false
    }
  },
  "id" : 598186581426577408,
  "created_at" : "2015-05-12 18:02:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    }, {
      "name" : "Dylan Matthews",
      "screen_name" : "dylanmatt",
      "indices" : [ 78, 88 ],
      "id_str" : "15950086",
      "id" : 15950086
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ezraklein\/status\/598118334454845440\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/OjAdMyt3eL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEzxdKSUgAAr3Rc.png",
      "id_str" : "598118333813129216",
      "id" : 598118333813129216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEzxdKSUgAAr3Rc.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 86,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 775
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 775
      } ],
      "display_url" : "pic.twitter.com\/OjAdMyt3eL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Fi6XqRtH75",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/5\/12\/8590639\/stephen-schwarzman-yale-donation",
      "display_url" : "vox.com\/2015\/5\/12\/8590\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598120111145406464",
  "text" : "RT @ezraklein: If you are thinking of giving $150 million to Yale, don't tell @dylanmatt: http:\/\/t.co\/Fi6XqRtH75 http:\/\/t.co\/OjAdMyt3eL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dylan Matthews",
        "screen_name" : "dylanmatt",
        "indices" : [ 63, 73 ],
        "id_str" : "15950086",
        "id" : 15950086
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ezraklein\/status\/598118334454845440\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/OjAdMyt3eL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEzxdKSUgAAr3Rc.png",
        "id_str" : "598118333813129216",
        "id" : 598118333813129216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEzxdKSUgAAr3Rc.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 151,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 86,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 775
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 775
        } ],
        "display_url" : "pic.twitter.com\/OjAdMyt3eL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/Fi6XqRtH75",
        "expanded_url" : "http:\/\/www.vox.com\/2015\/5\/12\/8590639\/stephen-schwarzman-yale-donation",
        "display_url" : "vox.com\/2015\/5\/12\/8590\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "598118334454845440",
    "text" : "If you are thinking of giving $150 million to Yale, don't tell @dylanmatt: http:\/\/t.co\/Fi6XqRtH75 http:\/\/t.co\/OjAdMyt3eL",
    "id" : 598118334454845440,
    "created_at" : "2015-05-12 13:31:38 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 598120111145406464,
  "created_at" : "2015-05-12 13:38:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597936784929124352",
  "text" : "RT @JAScribbles: I'm in between books. Been that way for almost 24 hours. Scary.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597933850606575616",
    "text" : "I'm in between books. Been that way for almost 24 hours. Scary.",
    "id" : 597933850606575616,
    "created_at" : "2015-05-12 01:18:33 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 597936784929124352,
  "created_at" : "2015-05-12 01:30:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "50 Shades of Gran",
      "screen_name" : "50ShadesGran",
      "indices" : [ 3, 16 ],
      "id_str" : "2495786409",
      "id" : 2495786409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597935965299179520",
  "text" : "RT @50ShadesGran: She sat there squirming, her legs bound together and her hands tied behind her back. She never could get the hang of knit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "558588078433243136",
    "text" : "She sat there squirming, her legs bound together and her hands tied behind her back. She never could get the hang of knitting.",
    "id" : 558588078433243136,
    "created_at" : "2015-01-23 11:32:30 +0000",
    "user" : {
      "name" : "50 Shades of Gran",
      "screen_name" : "50ShadesGran",
      "protected" : false,
      "id_str" : "2495786409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558318761158385665\/Nz8RvfgK_normal.jpeg",
      "id" : 2495786409,
      "verified" : false
    }
  },
  "id" : 597935965299179520,
  "created_at" : "2015-05-12 01:26:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abortion",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/pR93u4ovLq",
      "expanded_url" : "https:\/\/shar.es\/1ro1hF",
      "display_url" : "shar.es\/1ro1hF"
    } ]
  },
  "geo" : { },
  "id_str" : "597903840139223040",
  "text" : "When It Really Is about Controlling Women https:\/\/t.co\/pR93u4ovLq #abortion",
  "id" : 597903840139223040,
  "created_at" : "2015-05-11 23:19:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "indices" : [ 3, 17 ],
      "id_str" : "23372297",
      "id" : 23372297
    }, {
      "name" : "Sean Ryan Sullivan",
      "screen_name" : "seanrsullivan",
      "indices" : [ 98, 112 ],
      "id_str" : "18637326",
      "id" : 18637326
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LorenzoTheCat\/status\/597889781025021952\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MPKnr1LRx8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEwhll2UIAANTwC.jpg",
      "id_str" : "597889780232232960",
      "id" : 597889780232232960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEwhll2UIAANTwC.jpg",
      "sizes" : [ {
        "h" : 259,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MPKnr1LRx8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597892125032902656",
  "text" : "RT @LorenzoTheCat: Hey, what's that cat doing on my beach?  Miami Beach lifeguard stand, photo by @seanrsullivan http:\/\/t.co\/MPKnr1LRx8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Ryan Sullivan",
        "screen_name" : "seanrsullivan",
        "indices" : [ 79, 93 ],
        "id_str" : "18637326",
        "id" : 18637326
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LorenzoTheCat\/status\/597889781025021952\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/MPKnr1LRx8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEwhll2UIAANTwC.jpg",
        "id_str" : "597889780232232960",
        "id" : 597889780232232960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEwhll2UIAANTwC.jpg",
        "sizes" : [ {
          "h" : 259,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 432
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MPKnr1LRx8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597889781025021952",
    "text" : "Hey, what's that cat doing on my beach?  Miami Beach lifeguard stand, photo by @seanrsullivan http:\/\/t.co\/MPKnr1LRx8",
    "id" : 597889781025021952,
    "created_at" : "2015-05-11 22:23:26 +0000",
    "user" : {
      "name" : "Lorenzo The Cat",
      "screen_name" : "LorenzoTheCat",
      "protected" : false,
      "id_str" : "23372297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1047336743\/Marked-Americana_normal.jpg",
      "id" : 23372297,
      "verified" : true
    }
  },
  "id" : 597892125032902656,
  "created_at" : "2015-05-11 22:32:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "naturefacts",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597891615844347904",
  "text" : "RT @petersonguides: Killer Whales are one of the few non-human mammals that go through menopause. #naturefacts",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "naturefacts",
        "indices" : [ 78, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597890446279348224",
    "text" : "Killer Whales are one of the few non-human mammals that go through menopause. #naturefacts",
    "id" : 597890446279348224,
    "created_at" : "2015-05-11 22:26:05 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 597891615844347904,
  "created_at" : "2015-05-11 22:30:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Stephens",
      "screen_name" : "jffstphns3",
      "indices" : [ 3, 14 ],
      "id_str" : "285175597",
      "id" : 285175597
    }, {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 16, 27 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597883311235723268",
  "text" : "RT @jffstphns3: @sarahnmoon a thought-what if Matthew 25:34ff is literal &amp; God's literally incarnate in the least? So God has become human \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Emily",
        "screen_name" : "sarahnmoon",
        "indices" : [ 0, 11 ],
        "id_str" : "748426543987318784",
        "id" : 748426543987318784
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "597876654761971716",
    "geo" : { },
    "id_str" : "597880758968025088",
    "in_reply_to_user_id" : 24254537,
    "text" : "@sarahnmoon a thought-what if Matthew 25:34ff is literal &amp; God's literally incarnate in the least? So God has become human billions of times",
    "id" : 597880758968025088,
    "in_reply_to_status_id" : 597876654761971716,
    "created_at" : "2015-05-11 21:47:35 +0000",
    "in_reply_to_screen_name" : "GrumpyTheology",
    "in_reply_to_user_id_str" : "24254537",
    "user" : {
      "name" : "Jeff Stephens",
      "screen_name" : "jffstphns3",
      "protected" : false,
      "id_str" : "285175597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3350430562\/77b5bb0484ce972463311dbd2a4b8d1e_normal.png",
      "id" : 285175597,
      "verified" : false
    }
  },
  "id" : 597883311235723268,
  "created_at" : "2015-05-11 21:57:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lorraine cumming",
      "screen_name" : "wildlifelass",
      "indices" : [ 3, 16 ],
      "id_str" : "526710903",
      "id" : 526710903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597883087113027584",
  "text" : "RT @wildlifelass: Every time I go to Dalzell Estate I cannot resist these little cuties, love his dirty little nose from foraging :-) http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/597161686634786816\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/nTFILbjHLR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEmLXyVWAAIXGeg.jpg",
        "id_str" : "597161666367848450",
        "id" : 597161666367848450,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEmLXyVWAAIXGeg.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nTFILbjHLR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/597161686634786816\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/nTFILbjHLR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEmLYkUWIAAOv28.jpg",
        "id_str" : "597161679785435136",
        "id" : 597161679785435136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEmLYkUWIAAOv28.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nTFILbjHLR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597161686634786816",
    "text" : "Every time I go to Dalzell Estate I cannot resist these little cuties, love his dirty little nose from foraging :-) http:\/\/t.co\/nTFILbjHLR",
    "id" : 597161686634786816,
    "created_at" : "2015-05-09 22:10:15 +0000",
    "user" : {
      "name" : "lorraine cumming",
      "screen_name" : "wildlifelass",
      "protected" : false,
      "id_str" : "526710903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686952360673996800\/EGTFCaqx_normal.jpg",
      "id" : 526710903,
      "verified" : false
    }
  },
  "id" : 597883087113027584,
  "created_at" : "2015-05-11 21:56:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen J. Graham",
      "screen_name" : "sjggraham",
      "indices" : [ 3, 13 ],
      "id_str" : "1568067380",
      "id" : 1568067380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597882934134202369",
  "text" : "RT @sjggraham: Productive evening of research for possible book on charismania; fascinating how psychological techniques are used to contro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597881455675625472",
    "text" : "Productive evening of research for possible book on charismania; fascinating how psychological techniques are used to control entire crowds.",
    "id" : 597881455675625472,
    "created_at" : "2015-05-11 21:50:21 +0000",
    "user" : {
      "name" : "Stephen J. Graham",
      "screen_name" : "sjggraham",
      "protected" : false,
      "id_str" : "1568067380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631891491468779521\/1W_Ch-ZW_normal.jpg",
      "id" : 1568067380,
      "verified" : false
    }
  },
  "id" : 597882934134202369,
  "created_at" : "2015-05-11 21:56:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cheney",
      "screen_name" : "Oldbirder",
      "indices" : [ 3, 13 ],
      "id_str" : "125918155",
      "id" : 125918155
    }, {
      "name" : "RSPB Rye Meads",
      "screen_name" : "RSPBRyeMeads",
      "indices" : [ 46, 59 ],
      "id_str" : "439180320",
      "id" : 439180320
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Oldbirder\/status\/593121116081803264\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/iydWYafduk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDswguoXIAECRL4.jpg",
      "id_str" : "593121114760617985",
      "id" : 593121114760617985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDswguoXIAECRL4.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iydWYafduk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597846321106657280",
  "text" : "RT @Oldbirder: Follow me, Canada Geese family @RSPBRyeMeads today. http:\/\/t.co\/iydWYafduk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RSPB Rye Meads",
        "screen_name" : "RSPBRyeMeads",
        "indices" : [ 31, 44 ],
        "id_str" : "439180320",
        "id" : 439180320
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Oldbirder\/status\/593121116081803264\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/iydWYafduk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDswguoXIAECRL4.jpg",
        "id_str" : "593121114760617985",
        "id" : 593121114760617985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDswguoXIAECRL4.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 2560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iydWYafduk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593121116081803264",
    "text" : "Follow me, Canada Geese family @RSPBRyeMeads today. http:\/\/t.co\/iydWYafduk",
    "id" : 593121116081803264,
    "created_at" : "2015-04-28 18:34:28 +0000",
    "user" : {
      "name" : "John Cheney",
      "screen_name" : "Oldbirder",
      "protected" : false,
      "id_str" : "125918155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787016662407122948\/jCBG5SLW_normal.jpg",
      "id" : 125918155,
      "verified" : false
    }
  },
  "id" : 597846321106657280,
  "created_at" : "2015-05-11 19:30:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anglian Water",
      "screen_name" : "AnglianWater",
      "indices" : [ 3, 16 ],
      "id_str" : "52770745",
      "id" : 52770745
    }, {
      "name" : "Grafham Water",
      "screen_name" : "GrafhamWater1",
      "indices" : [ 49, 63 ],
      "id_str" : "1686332460",
      "id" : 1686332460
    }, {
      "name" : "BTO",
      "screen_name" : "_BTO",
      "indices" : [ 82, 87 ],
      "id_str" : "31094727",
      "id" : 31094727
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nightingales",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597846234951503872",
  "text" : "RT @AnglianWater: We're tagging #nightingales at @GrafhamWater1 this morning with @_BTO to track their annual migration... http:\/\/t.co\/xwCI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.conversocial.com\" rel=\"nofollow\"\u003EConversocial\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grafham Water",
        "screen_name" : "GrafhamWater1",
        "indices" : [ 31, 45 ],
        "id_str" : "1686332460",
        "id" : 1686332460
      }, {
        "name" : "BTO",
        "screen_name" : "_BTO",
        "indices" : [ 64, 69 ],
        "id_str" : "31094727",
        "id" : 31094727
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AnglianWater\/status\/593346117925998592\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/xwCIrJ6T53",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDv9JnwXIAAMOPL.jpg",
        "id_str" : "593346117661827072",
        "id" : 593346117661827072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDv9JnwXIAAMOPL.jpg",
        "sizes" : [ {
          "h" : 279,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 841,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1069,
          "resize" : "fit",
          "w" : 1302
        } ],
        "display_url" : "pic.twitter.com\/xwCIrJ6T53"
      } ],
      "hashtags" : [ {
        "text" : "nightingales",
        "indices" : [ 14, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593346117925998592",
    "text" : "We're tagging #nightingales at @GrafhamWater1 this morning with @_BTO to track their annual migration... http:\/\/t.co\/xwCIrJ6T53",
    "id" : 593346117925998592,
    "created_at" : "2015-04-29 09:28:33 +0000",
    "user" : {
      "name" : "Anglian Water",
      "screen_name" : "AnglianWater",
      "protected" : false,
      "id_str" : "52770745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798144758715678720\/qPCO-00G_normal.jpg",
      "id" : 52770745,
      "verified" : true
    }
  },
  "id" : 597846234951503872,
  "created_at" : "2015-05-11 19:30:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cheney",
      "screen_name" : "Oldbirder",
      "indices" : [ 3, 13 ],
      "id_str" : "125918155",
      "id" : 125918155
    }, {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 15, 29 ],
      "id_str" : "272369448",
      "id" : 272369448
    }, {
      "name" : "ForestOfMarstonVale",
      "screen_name" : "forest_centre",
      "indices" : [ 69, 83 ],
      "id_str" : "161636994",
      "id" : 161636994
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Oldbirder\/status\/597845269036834818\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/PRYE5c3c4w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEv5GoJWgAAxRXJ.jpg",
      "id_str" : "597845267807895552",
      "id" : 597845267807895552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEv5GoJWgAAxRXJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PRYE5c3c4w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597845898207612929",
  "text" : "RT @Oldbirder: @Swanwhisperer Hi Ryan, found another Swan nest today @forest_centre but no cygnets as yet. http:\/\/t.co\/PRYE5c3c4w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlifeloverforever",
        "screen_name" : "Swanwhisperer",
        "indices" : [ 0, 14 ],
        "id_str" : "272369448",
        "id" : 272369448
      }, {
        "name" : "ForestOfMarstonVale",
        "screen_name" : "forest_centre",
        "indices" : [ 54, 68 ],
        "id_str" : "161636994",
        "id" : 161636994
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Oldbirder\/status\/597845269036834818\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/PRYE5c3c4w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEv5GoJWgAAxRXJ.jpg",
        "id_str" : "597845267807895552",
        "id" : 597845267807895552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEv5GoJWgAAxRXJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PRYE5c3c4w"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597845269036834818",
    "in_reply_to_user_id" : 272369448,
    "text" : "@Swanwhisperer Hi Ryan, found another Swan nest today @forest_centre but no cygnets as yet. http:\/\/t.co\/PRYE5c3c4w",
    "id" : 597845269036834818,
    "created_at" : "2015-05-11 19:26:34 +0000",
    "in_reply_to_screen_name" : "Swanwhisperer",
    "in_reply_to_user_id_str" : "272369448",
    "user" : {
      "name" : "John Cheney",
      "screen_name" : "Oldbirder",
      "protected" : false,
      "id_str" : "125918155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787016662407122948\/jCBG5SLW_normal.jpg",
      "id" : 125918155,
      "verified" : false
    }
  },
  "id" : 597845898207612929,
  "created_at" : "2015-05-11 19:29:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Enns",
      "screen_name" : "peteenns",
      "indices" : [ 102, 111 ],
      "id_str" : "130267418",
      "id" : 130267418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597836514773639168",
  "text" : "almost done reading \"The Bible Tells Me So: Why Defending Scripture Has Made Us Unable to Read It\" by @peteenns getting so much new insight!",
  "id" : 597836514773639168,
  "created_at" : "2015-05-11 18:51:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597835983573413888",
  "text" : "DD is finally up and downstairs. still a bit shaky but eating more each day.",
  "id" : 597835983573413888,
  "created_at" : "2015-05-11 18:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597828120536813568",
  "text" : "my body is heavy. i feel like an elephant.",
  "id" : 597828120536813568,
  "created_at" : "2015-05-11 18:18:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597783670984957952",
  "text" : "RT @TheChristianLft: Following Jesus Is About Love. Why do so many people get that mixed up, even Christians? We have have to keep... http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/HkVTcBqi6f",
        "expanded_url" : "http:\/\/fb.me\/1IvMytqlJ",
        "display_url" : "fb.me\/1IvMytqlJ"
      } ]
    },
    "geo" : { },
    "id_str" : "597782329319370752",
    "text" : "Following Jesus Is About Love. Why do so many people get that mixed up, even Christians? We have have to keep... http:\/\/t.co\/HkVTcBqi6f",
    "id" : 597782329319370752,
    "created_at" : "2015-05-11 15:16:28 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 597783670984957952,
  "created_at" : "2015-05-11 15:21:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/597448884147859456\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/yixrfuHN07",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEqQlFPWgAE7xnq.jpg",
      "id_str" : "597448867316137985",
      "id" : 597448867316137985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEqQlFPWgAE7xnq.jpg",
      "sizes" : [ {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yixrfuHN07"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597452314883006464",
  "text" : "RT @Salmonae1: Family gathering. http:\/\/t.co\/yixrfuHN07",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/597448884147859456\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/yixrfuHN07",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEqQlFPWgAE7xnq.jpg",
        "id_str" : "597448867316137985",
        "id" : 597448867316137985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEqQlFPWgAE7xnq.jpg",
        "sizes" : [ {
          "h" : 706,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 706,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/yixrfuHN07"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597448884147859456",
    "text" : "Family gathering. http:\/\/t.co\/yixrfuHN07",
    "id" : 597448884147859456,
    "created_at" : "2015-05-10 17:11:28 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 597452314883006464,
  "created_at" : "2015-05-10 17:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthday",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597451353884065794",
  "text" : "20 years ago today I was 29, scared to death, in the hospital waiting for a baby. 11:33 pm she was pulled out. #HappyBirthday",
  "id" : 597451353884065794,
  "created_at" : "2015-05-10 17:21:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lee paris",
      "screen_name" : "leeparisdaylee",
      "indices" : [ 3, 18 ],
      "id_str" : "1855986320",
      "id" : 1855986320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/a6i4DMY5lq",
      "expanded_url" : "http:\/\/www.millbrook.org\/Page\/School-Life\/Trevor-Zoo\/Trevor-Zoo-Live\/Trevor-Zoo-Live---Herons",
      "display_url" : "millbrook.org\/Page\/School-Li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597397502774611968",
  "text" : "RT @leeparisdaylee: Watch Newborn Herons  (GBH) &amp; Eggs!\n\n    Live on Trevor Zoo Nest Cam in Upper State NY\n\nhttp:\/\/t.co\/a6i4DMY5lq http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/leeparisdaylee\/status\/597154128066916352\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/clOPkwtKYu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEmEg-SWEAEnOVV.jpg",
        "id_str" : "597154127613923329",
        "id" : 597154127613923329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEmEg-SWEAEnOVV.jpg",
        "sizes" : [ {
          "h" : 777,
          "resize" : "fit",
          "w" : 944
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 944
        }, {
          "h" : 280,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/clOPkwtKYu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/a6i4DMY5lq",
        "expanded_url" : "http:\/\/www.millbrook.org\/Page\/School-Life\/Trevor-Zoo\/Trevor-Zoo-Live\/Trevor-Zoo-Live---Herons",
        "display_url" : "millbrook.org\/Page\/School-Li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597154128066916352",
    "text" : "Watch Newborn Herons  (GBH) &amp; Eggs!\n\n    Live on Trevor Zoo Nest Cam in Upper State NY\n\nhttp:\/\/t.co\/a6i4DMY5lq http:\/\/t.co\/clOPkwtKYu",
    "id" : 597154128066916352,
    "created_at" : "2015-05-09 21:40:13 +0000",
    "user" : {
      "name" : "lee paris",
      "screen_name" : "leeparisdaylee",
      "protected" : false,
      "id_str" : "1855986320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000838345496\/85e63360e52f3968bf82753ba8b0596d_normal.jpeg",
      "id" : 1855986320,
      "verified" : false
    }
  },
  "id" : 597397502774611968,
  "created_at" : "2015-05-10 13:47:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SonnyBee",
      "screen_name" : "SonnyBeez",
      "indices" : [ 3, 13 ],
      "id_str" : "589164746",
      "id" : 589164746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SonnyBeez\/status\/590658223943905281\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/0329WDahxP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDJwhE3WAAEX5MX.jpg",
      "id_str" : "590658214682820609",
      "id" : 590658214682820609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDJwhE3WAAEX5MX.jpg",
      "sizes" : [ {
        "h" : 277,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0329WDahxP"
    } ],
    "hashtags" : [ {
      "text" : "bees",
      "indices" : [ 26, 31 ]
    }, {
      "text" : "environment",
      "indices" : [ 111, 123 ]
    }, {
      "text" : "gardenchat",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597135725751103488",
  "text" : "RT @SonnyBeez: Wanna help #bees? Of course you do! Here's a real easy way YOU can help: http:\/\/t.co\/0329WDahxP #environment #gardenchat #be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SonnyBeez\/status\/590658223943905281\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/0329WDahxP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDJwhE3WAAEX5MX.jpg",
        "id_str" : "590658214682820609",
        "id" : 590658214682820609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDJwhE3WAAEX5MX.jpg",
        "sizes" : [ {
          "h" : 277,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 277,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 148,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0329WDahxP"
      } ],
      "hashtags" : [ {
        "text" : "bees",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "environment",
        "indices" : [ 96, 108 ]
      }, {
        "text" : "gardenchat",
        "indices" : [ 109, 120 ]
      }, {
        "text" : "beechat",
        "indices" : [ 121, 129 ]
      }, {
        "text" : "garden",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594131543708303362",
    "text" : "Wanna help #bees? Of course you do! Here's a real easy way YOU can help: http:\/\/t.co\/0329WDahxP #environment #gardenchat #beechat #garden",
    "id" : 594131543708303362,
    "created_at" : "2015-05-01 13:29:33 +0000",
    "user" : {
      "name" : "SonnyBee",
      "screen_name" : "SonnyBeez",
      "protected" : false,
      "id_str" : "589164746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567498769315688448\/eavs4ebh_normal.jpeg",
      "id" : 589164746,
      "verified" : false
    }
  },
  "id" : 597135725751103488,
  "created_at" : "2015-05-09 20:27:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597127787703504896",
  "geo" : { },
  "id_str" : "597135360817258496",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous no specific reason. I think I remembered you being in NY (my state)",
  "id" : 597135360817258496,
  "in_reply_to_status_id" : 597127787703504896,
  "created_at" : "2015-05-09 20:25:38 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "597108214996533248",
  "geo" : { },
  "id_str" : "597112320167387136",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous you're in PA now?",
  "id" : 597112320167387136,
  "in_reply_to_status_id" : 597108214996533248,
  "created_at" : "2015-05-09 18:54:05 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "indices" : [ 3, 12 ],
      "id_str" : "490591746",
      "id" : 490591746
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/597109239107158016\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/tgtFt8gI1a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CElbsFAW0AAnhf_.jpg",
      "id_str" : "597109238419345408",
      "id" : 597109238419345408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CElbsFAW0AAnhf_.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1008
      } ],
      "display_url" : "pic.twitter.com\/tgtFt8gI1a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597111851353251840",
  "text" : "RT @BobTarte: Jesse the dove won't stand for an ordinary potato. http:\/\/t.co\/tgtFt8gI1a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BobTarte\/status\/597109239107158016\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/tgtFt8gI1a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CElbsFAW0AAnhf_.jpg",
        "id_str" : "597109238419345408",
        "id" : 597109238419345408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CElbsFAW0AAnhf_.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/tgtFt8gI1a"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597109239107158016",
    "text" : "Jesse the dove won't stand for an ordinary potato. http:\/\/t.co\/tgtFt8gI1a",
    "id" : 597109239107158016,
    "created_at" : "2015-05-09 18:41:51 +0000",
    "user" : {
      "name" : "Bob Tarte",
      "screen_name" : "BobTarte",
      "protected" : false,
      "id_str" : "490591746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570578729\/6y9pn9ap800am8pkqsku_normal.jpeg",
      "id" : 490591746,
      "verified" : false
    }
  },
  "id" : 597111851353251840,
  "created_at" : "2015-05-09 18:52:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 3, 18 ],
      "id_str" : "17134268",
      "id" : 17134268
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CBSThisMorning\/status\/596108848253009920\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/BGHlL6Gf9q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEXN1s-W8AA5ykg.jpg",
      "id_str" : "596108848185929728",
      "id" : 596108848185929728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEXN1s-W8AA5ykg.jpg",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 610
      } ],
      "display_url" : "pic.twitter.com\/BGHlL6Gf9q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/0kB0BKYEuy",
      "expanded_url" : "http:\/\/cbsn.ws\/1IhlYqm",
      "display_url" : "cbsn.ws\/1IhlYqm"
    } ]
  },
  "geo" : { },
  "id_str" : "597072234407165953",
  "text" : "RT @CBSThisMorning: How to get a better night's sleep without pills: http:\/\/t.co\/0kB0BKYEuy http:\/\/t.co\/BGHlL6Gf9q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CBSThisMorning\/status\/596108848253009920\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/BGHlL6Gf9q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEXN1s-W8AA5ykg.jpg",
        "id_str" : "596108848185929728",
        "id" : 596108848185929728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEXN1s-W8AA5ykg.jpg",
        "sizes" : [ {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 610
        } ],
        "display_url" : "pic.twitter.com\/BGHlL6Gf9q"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/0kB0BKYEuy",
        "expanded_url" : "http:\/\/cbsn.ws\/1IhlYqm",
        "display_url" : "cbsn.ws\/1IhlYqm"
      } ]
    },
    "geo" : { },
    "id_str" : "596108848253009920",
    "text" : "How to get a better night's sleep without pills: http:\/\/t.co\/0kB0BKYEuy http:\/\/t.co\/BGHlL6Gf9q",
    "id" : 596108848253009920,
    "created_at" : "2015-05-07 00:26:39 +0000",
    "user" : {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "protected" : false,
      "id_str" : "17134268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651362377540112384\/eNioIfCp_normal.jpg",
      "id" : 17134268,
      "verified" : true
    }
  },
  "id" : 597072234407165953,
  "created_at" : "2015-05-09 16:14:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kylie George",
      "screen_name" : "KylieGeorge7",
      "indices" : [ 3, 16 ],
      "id_str" : "1643453666",
      "id" : 1643453666
    }, {
      "name" : "CNN Tonight",
      "screen_name" : "CNNTonight",
      "indices" : [ 18, 29 ],
      "id_str" : "2415053456",
      "id" : 2415053456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597064165350604800",
  "text" : "RT @KylieGeorge7: @CNNTonight Why you choose to quote Simmons book is baffling. This man brokers sentient creatures 4 profit. http:\/\/t.co\/f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN Tonight",
        "screen_name" : "CNNTonight",
        "indices" : [ 0, 11 ],
        "id_str" : "2415053456",
        "id" : 2415053456
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/fCCVy7Vm57",
        "expanded_url" : "http:\/\/www.cetaceaninspiration.com\/blog\/2014\/3\/20\/who-is-mark-simmons-and-ocean-embassy",
        "display_url" : "cetaceaninspiration.com\/blog\/2014\/3\/20\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "588899691430944768",
    "geo" : { },
    "id_str" : "588908161836392449",
    "in_reply_to_user_id" : 2415053456,
    "text" : "@CNNTonight Why you choose to quote Simmons book is baffling. This man brokers sentient creatures 4 profit. http:\/\/t.co\/fCCVy7Vm57",
    "id" : 588908161836392449,
    "in_reply_to_status_id" : 588899691430944768,
    "created_at" : "2015-04-17 03:33:41 +0000",
    "in_reply_to_screen_name" : "CNNTonight",
    "in_reply_to_user_id_str" : "2415053456",
    "user" : {
      "name" : "Kylie George",
      "screen_name" : "KylieGeorge7",
      "protected" : false,
      "id_str" : "1643453666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713526387336982533\/CU4PJcuu_normal.jpg",
      "id" : 1643453666,
      "verified" : false
    }
  },
  "id" : 597064165350604800,
  "created_at" : "2015-05-09 15:42:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "North Woods Ranch",
      "screen_name" : "NorthWoodsRanch",
      "indices" : [ 3, 19 ],
      "id_str" : "431004831",
      "id" : 431004831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NorthWoodsRanch\/status\/597004154645647362\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/bK4vrDkRs9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEj8HV0WEAARe1O.jpg",
      "id_str" : "597004153672568832",
      "id" : 597004153672568832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEj8HV0WEAARe1O.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2148,
        "resize" : "fit",
        "w" : 3223
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bK4vrDkRs9"
    } ],
    "hashtags" : [ {
      "text" : "weecalf",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "newcoo",
      "indices" : [ 54, 61 ]
    }, {
      "text" : "calf",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597062965205049344",
  "text" : "RT @NorthWoodsRanch: Wookerina her new calf!\n#weecalf #newcoo #calf http:\/\/t.co\/bK4vrDkRs9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NorthWoodsRanch\/status\/597004154645647362\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/bK4vrDkRs9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEj8HV0WEAARe1O.jpg",
        "id_str" : "597004153672568832",
        "id" : 597004153672568832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEj8HV0WEAARe1O.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2148,
          "resize" : "fit",
          "w" : 3223
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/bK4vrDkRs9"
      } ],
      "hashtags" : [ {
        "text" : "weecalf",
        "indices" : [ 24, 32 ]
      }, {
        "text" : "newcoo",
        "indices" : [ 33, 40 ]
      }, {
        "text" : "calf",
        "indices" : [ 41, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597004154645647362",
    "text" : "Wookerina her new calf!\n#weecalf #newcoo #calf http:\/\/t.co\/bK4vrDkRs9",
    "id" : 597004154645647362,
    "created_at" : "2015-05-09 11:44:16 +0000",
    "user" : {
      "name" : "North Woods Ranch",
      "screen_name" : "NorthWoodsRanch",
      "protected" : false,
      "id_str" : "431004831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1735387668\/DSC05143_normal.JPG",
      "id" : 431004831,
      "verified" : false
    }
  },
  "id" : 597062965205049344,
  "created_at" : "2015-05-09 15:37:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Barratt",
      "screen_name" : "BarrattKelly",
      "indices" : [ 3, 16 ],
      "id_str" : "1915074738",
      "id" : 1915074738
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BarrattKelly\/status\/597011874752950272\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/mmcIlP3znz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEkDHikWAAAlrNd.jpg",
      "id_str" : "597011853676511232",
      "id" : 597011853676511232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEkDHikWAAAlrNd.jpg",
      "sizes" : [ {
        "h" : 931,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 660
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mmcIlP3znz"
    } ],
    "hashtags" : [ {
      "text" : "Dexter",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "happycows",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "happyvet",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "HappyWeekend",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597062520592007168",
  "text" : "RT @BarrattKelly: Just a #Dexter eating her breakfast in the sun... #happycows #happyvet #HappyWeekend http:\/\/t.co\/mmcIlP3znz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BarrattKelly\/status\/597011874752950272\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/mmcIlP3znz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEkDHikWAAAlrNd.jpg",
        "id_str" : "597011853676511232",
        "id" : 597011853676511232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEkDHikWAAAlrNd.jpg",
        "sizes" : [ {
          "h" : 931,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 660
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mmcIlP3znz"
      } ],
      "hashtags" : [ {
        "text" : "Dexter",
        "indices" : [ 7, 14 ]
      }, {
        "text" : "happycows",
        "indices" : [ 50, 60 ]
      }, {
        "text" : "happyvet",
        "indices" : [ 61, 70 ]
      }, {
        "text" : "HappyWeekend",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597011874752950272",
    "text" : "Just a #Dexter eating her breakfast in the sun... #happycows #happyvet #HappyWeekend http:\/\/t.co\/mmcIlP3znz",
    "id" : 597011874752950272,
    "created_at" : "2015-05-09 12:14:57 +0000",
    "user" : {
      "name" : "Kelly Barratt",
      "screen_name" : "BarrattKelly",
      "protected" : false,
      "id_str" : "1915074738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708308351222988800\/hWH81Zsl_normal.jpg",
      "id" : 1915074738,
      "verified" : false
    }
  },
  "id" : 597062520592007168,
  "created_at" : "2015-05-09 15:36:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597052308774645761",
  "text" : "DD back to er yesterday. she got a nice GI cocktail which calmed her insides. hopefully today is better for her.",
  "id" : 597052308774645761,
  "created_at" : "2015-05-09 14:55:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "indices" : [ 3, 19 ],
      "id_str" : "105926473",
      "id" : 105926473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "ernestholmes",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/E63Z0AZKLM",
      "expanded_url" : "http:\/\/is.gd\/Th2UG8",
      "display_url" : "is.gd\/Th2UG8"
    } ]
  },
  "geo" : { },
  "id_str" : "596862173114052608",
  "text" : "RT @consciousbridge: Read That Book Again! http:\/\/t.co\/E63Z0AZKLM  #books #ernestholmes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 46, 52 ]
      }, {
        "text" : "ernestholmes",
        "indices" : [ 53, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/E63Z0AZKLM",
        "expanded_url" : "http:\/\/is.gd\/Th2UG8",
        "display_url" : "is.gd\/Th2UG8"
      } ]
    },
    "geo" : { },
    "id_str" : "596840470342275072",
    "text" : "Read That Book Again! http:\/\/t.co\/E63Z0AZKLM  #books #ernestholmes",
    "id" : 596840470342275072,
    "created_at" : "2015-05-09 00:53:51 +0000",
    "user" : {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "protected" : false,
      "id_str" : "105926473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200394907\/172_normal.JPG",
      "id" : 105926473,
      "verified" : false
    }
  },
  "id" : 596862173114052608,
  "created_at" : "2015-05-09 02:20:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596680665275506688",
  "text" : "First ride in front of ambulance yesterday. DD had sudden nausea, shakes. we thought heat. labs, vitals good. dx: viral, panic attack.",
  "id" : 596680665275506688,
  "created_at" : "2015-05-08 14:18:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farm Sanctuary",
      "screen_name" : "FarmSanctuary",
      "indices" : [ 3, 17 ],
      "id_str" : "16908562",
      "id" : 16908562
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 89, 97 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/zkUpi8SUSJ",
      "expanded_url" : "http:\/\/youtu.be\/243avILQUNM?a",
      "display_url" : "youtu.be\/243avILQUNM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "596057746132357120",
  "text" : "RT @FarmSanctuary: Ferdinand Sheep Arrives at Farm Sanctuary: http:\/\/t.co\/zkUpi8SUSJ via @YouTube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 70, 78 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/zkUpi8SUSJ",
        "expanded_url" : "http:\/\/youtu.be\/243avILQUNM?a",
        "display_url" : "youtu.be\/243avILQUNM?a"
      } ]
    },
    "geo" : { },
    "id_str" : "596057068450217984",
    "text" : "Ferdinand Sheep Arrives at Farm Sanctuary: http:\/\/t.co\/zkUpi8SUSJ via @YouTube",
    "id" : 596057068450217984,
    "created_at" : "2015-05-06 21:00:53 +0000",
    "user" : {
      "name" : "Farm Sanctuary",
      "screen_name" : "FarmSanctuary",
      "protected" : false,
      "id_str" : "16908562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440957631226580992\/Pk-bFWfT_normal.jpeg",
      "id" : 16908562,
      "verified" : false
    }
  },
  "id" : 596057746132357120,
  "created_at" : "2015-05-06 21:03:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SonnyBee",
      "screen_name" : "SonnyBeez",
      "indices" : [ 3, 13 ],
      "id_str" : "589164746",
      "id" : 589164746
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SonnyBeez\/status\/596002192823312384\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/6i8S1gIO21",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVs1igWAAAsQ6C.jpg",
      "id_str" : "596002192747790336",
      "id" : 596002192747790336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVs1igWAAAsQ6C.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 580
      } ],
      "display_url" : "pic.twitter.com\/6i8S1gIO21"
    } ],
    "hashtags" : [ {
      "text" : "Help",
      "indices" : [ 15, 20 ]
    }, {
      "text" : "bees",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596048764244197376",
  "text" : "RT @SonnyBeez: #Help #bees http:\/\/t.co\/6i8S1gIO21",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SonnyBeez\/status\/596002192823312384\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/6i8S1gIO21",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVs1igWAAAsQ6C.jpg",
        "id_str" : "596002192747790336",
        "id" : 596002192747790336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVs1igWAAAsQ6C.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com\/6i8S1gIO21"
      } ],
      "hashtags" : [ {
        "text" : "Help",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "bees",
        "indices" : [ 6, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596002192823312384",
    "text" : "#Help #bees http:\/\/t.co\/6i8S1gIO21",
    "id" : 596002192823312384,
    "created_at" : "2015-05-06 17:22:50 +0000",
    "user" : {
      "name" : "SonnyBee",
      "screen_name" : "SonnyBeez",
      "protected" : false,
      "id_str" : "589164746",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567498769315688448\/eavs4ebh_normal.jpeg",
      "id" : 589164746,
      "verified" : false
    }
  },
  "id" : 596048764244197376,
  "created_at" : "2015-05-06 20:27:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasts",
      "indices" : [ 115, 124 ]
    }, {
      "text" : "feedly",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/mNDH0OHCh3",
      "expanded_url" : "http:\/\/legalise-freedom.com\/radio\/courtney-brown-remote-viewing-cydonia-mars-part-two\/",
      "display_url" : "legalise-freedom.com\/radio\/courtney\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596033720697643008",
  "text" : "LOL \"We're the soap opera of the galaxy right now.\" Courtney Brown \u2013 Remote Viewing Mars: 2 http:\/\/t.co\/mNDH0OHCh3 #podcasts #feedly",
  "id" : 596033720697643008,
  "created_at" : "2015-05-06 19:28:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcasts",
      "indices" : [ 98, 107 ]
    }, {
      "text" : "feedly",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/mNDH0OHCh3",
      "expanded_url" : "http:\/\/legalise-freedom.com\/radio\/courtney-brown-remote-viewing-cydonia-mars-part-two\/",
      "display_url" : "legalise-freedom.com\/radio\/courtney\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596018651259641857",
  "text" : "now listening &gt; Courtney Brown \u2013 Remote Viewing Cydonia, Mars: Part Two http:\/\/t.co\/mNDH0OHCh3 #podcasts #feedly",
  "id" : 596018651259641857,
  "created_at" : "2015-05-06 18:28:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcast",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595966968718618624",
  "text" : "how do I separate #podcast opml from my other feeds opml? I add links to #feedly#feedbunch but how do I upload podcast only opml to player?",
  "id" : 595966968718618624,
  "created_at" : "2015-05-06 15:02:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595747584708366337",
  "text" : "you know how your eyes harden in 40s? I feel like \"I\" have hardened. less tolerant, more righteous. dont like it.",
  "id" : 595747584708366337,
  "created_at" : "2015-05-06 00:31:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randal Rauser",
      "screen_name" : "RandalRauser",
      "indices" : [ 3, 16 ],
      "id_str" : "384611030",
      "id" : 384611030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/o2yI7yGrK7",
      "expanded_url" : "http:\/\/randalrauser.com\/2015\/05\/if-you-want-to-see-folk-damned-there-is-something-wrong-with-you\/",
      "display_url" : "randalrauser.com\/2015\/05\/if-you\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595721411651641344",
  "text" : "RT @RandalRauser: If you want to see folk damned, there is something wrong with you! http:\/\/t.co\/o2yI7yGrK7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/o2yI7yGrK7",
        "expanded_url" : "http:\/\/randalrauser.com\/2015\/05\/if-you-want-to-see-folk-damned-there-is-something-wrong-with-you\/",
        "display_url" : "randalrauser.com\/2015\/05\/if-you\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595719905862885376",
    "text" : "If you want to see folk damned, there is something wrong with you! http:\/\/t.co\/o2yI7yGrK7",
    "id" : 595719905862885376,
    "created_at" : "2015-05-05 22:41:08 +0000",
    "user" : {
      "name" : "Randal Rauser",
      "screen_name" : "RandalRauser",
      "protected" : false,
      "id_str" : "384611030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452541600741076992\/U1bR7T-i_normal.jpeg",
      "id" : 384611030,
      "verified" : false
    }
  },
  "id" : 595721411651641344,
  "created_at" : "2015-05-05 22:47:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Procter",
      "screen_name" : "adgarleyfarm",
      "indices" : [ 3, 16 ],
      "id_str" : "968211836",
      "id" : 968211836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ayrshire",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "calf",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "dairycalves",
      "indices" : [ 92, 104 ]
    }, {
      "text" : "teamdairy",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/7j3osQTzND",
      "expanded_url" : "https:\/\/vine.co\/v\/eZ6UKUPJYKg",
      "display_url" : "vine.co\/v\/eZ6UKUPJYKg"
    } ]
  },
  "geo" : { },
  "id_str" : "595678606178820097",
  "text" : "RT @adgarleyfarm: Sandra got a bit over excited about the straw in her pen! #ayrshire #calf #dairycalves #teamdairy https:\/\/t.co\/7j3osQTzND",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ayrshire",
        "indices" : [ 58, 67 ]
      }, {
        "text" : "calf",
        "indices" : [ 68, 73 ]
      }, {
        "text" : "dairycalves",
        "indices" : [ 74, 86 ]
      }, {
        "text" : "teamdairy",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/7j3osQTzND",
        "expanded_url" : "https:\/\/vine.co\/v\/eZ6UKUPJYKg",
        "display_url" : "vine.co\/v\/eZ6UKUPJYKg"
      } ]
    },
    "geo" : { },
    "id_str" : "595659001410510849",
    "text" : "Sandra got a bit over excited about the straw in her pen! #ayrshire #calf #dairycalves #teamdairy https:\/\/t.co\/7j3osQTzND",
    "id" : 595659001410510849,
    "created_at" : "2015-05-05 18:39:07 +0000",
    "user" : {
      "name" : "Meg Procter",
      "screen_name" : "adgarleyfarm",
      "protected" : false,
      "id_str" : "968211836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753859812136521729\/y4Ls08Bs_normal.jpg",
      "id" : 968211836,
      "verified" : false
    }
  },
  "id" : 595678606178820097,
  "created_at" : "2015-05-05 19:57:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595677905826488320",
  "text" : "@Lluminous_ me,too.",
  "id" : 595677905826488320,
  "created_at" : "2015-05-05 19:54:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "indices" : [ 3, 14 ],
      "id_str" : "548388698",
      "id" : 548388698
    }, {
      "name" : "Peter Enns",
      "screen_name" : "peteenns",
      "indices" : [ 108, 117 ],
      "id_str" : "130267418",
      "id" : 130267418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/GTCLleurCM",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/peterenns\/2015\/05\/whos-up-for-a-little-new-testament-quiz-sure-you-are-do-it\/",
      "display_url" : "patheos.com\/blogs\/peterenn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595668463970050050",
  "text" : "RT @JohnUmland: Who\u2019s up for a little New Testament quiz? (sure you are. do it.) http:\/\/t.co\/GTCLleurCM via @peteenns",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Enns",
        "screen_name" : "peteenns",
        "indices" : [ 92, 101 ],
        "id_str" : "130267418",
        "id" : 130267418
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/GTCLleurCM",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/peterenns\/2015\/05\/whos-up-for-a-little-new-testament-quiz-sure-you-are-do-it\/",
        "display_url" : "patheos.com\/blogs\/peterenn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595667423975624708",
    "text" : "Who\u2019s up for a little New Testament quiz? (sure you are. do it.) http:\/\/t.co\/GTCLleurCM via @peteenns",
    "id" : 595667423975624708,
    "created_at" : "2015-05-05 19:12:35 +0000",
    "user" : {
      "name" : "Johnny the Pooh \uD83D\uDD87",
      "screen_name" : "JohnUmland",
      "protected" : false,
      "id_str" : "548388698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797536354452340736\/6SfqJlHp_normal.jpg",
      "id" : 548388698,
      "verified" : false
    }
  },
  "id" : 595668463970050050,
  "created_at" : "2015-05-05 19:16:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 70, 77 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcast",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/OfPHYkFJ6X",
      "expanded_url" : "http:\/\/pocket.co\/so1_t5",
      "display_url" : "pocket.co\/so1_t5"
    } ]
  },
  "geo" : { },
  "id_str" : "595642566927917059",
  "text" : "listening now #podcast The Evangelical Nomad \u2013 Brandan Robertson (via @Pocket) http:\/\/t.co\/OfPHYkFJ6X",
  "id" : 595642566927917059,
  "created_at" : "2015-05-05 17:33:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595637469237932033",
  "text" : "@Lluminous_ I have a goat?",
  "id" : 595637469237932033,
  "created_at" : "2015-05-05 17:13:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595631827462815745",
  "text" : "i usually like bible study but today was a bad day. im all out of sorts.",
  "id" : 595631827462815745,
  "created_at" : "2015-05-05 16:51:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/l7AvtBUCWW",
      "expanded_url" : "http:\/\/tmblr.co\/ZJssJy1k2tY-M",
      "display_url" : "tmblr.co\/ZJssJy1k2tY-M"
    } ]
  },
  "geo" : { },
  "id_str" : "595394702641405952",
  "text" : "RT @ShhDragon: Photoset:  http:\/\/t.co\/l7AvtBUCWW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/l7AvtBUCWW",
        "expanded_url" : "http:\/\/tmblr.co\/ZJssJy1k2tY-M",
        "display_url" : "tmblr.co\/ZJssJy1k2tY-M"
      } ]
    },
    "geo" : { },
    "id_str" : "595391393327112192",
    "text" : "Photoset:  http:\/\/t.co\/l7AvtBUCWW",
    "id" : 595391393327112192,
    "created_at" : "2015-05-05 00:55:44 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 595394702641405952,
  "created_at" : "2015-05-05 01:08:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PzFeed Advertising",
      "screen_name" : "PzFeed",
      "indices" : [ 0, 7 ],
      "id_str" : "2838219291",
      "id" : 2838219291
    }, {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 8, 18 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595386393444089857",
  "geo" : { },
  "id_str" : "595387910427385857",
  "in_reply_to_user_id" : 292777349,
  "text" : "@PzFeed @Matth3ous jeezus.. I didn't need to know about this. Poor dear pup : (((",
  "id" : 595387910427385857,
  "in_reply_to_status_id" : 595386393444089857,
  "created_at" : "2015-05-05 00:41:54 +0000",
  "in_reply_to_screen_name" : "pzf",
  "in_reply_to_user_id_str" : "292777349",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595361247618555904",
  "geo" : { },
  "id_str" : "595372508351766529",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ahhh...",
  "id" : 595372508351766529,
  "in_reply_to_status_id" : 595361247618555904,
  "created_at" : "2015-05-04 23:40:42 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "595357922647023617",
  "geo" : { },
  "id_str" : "595360994584559617",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous doesn't necessarily mean they're romantic...",
  "id" : 595360994584559617,
  "in_reply_to_status_id" : 595357922647023617,
  "created_at" : "2015-05-04 22:54:57 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "huffduffer",
      "screen_name" : "huffduffer",
      "indices" : [ 3, 14 ],
      "id_str" : "15709661",
      "id" : 15709661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/cVR2lEYw9F",
      "expanded_url" : "https:\/\/huffduffer.com\/DhammaSeeker\/228009",
      "display_url" : "huffduffer.com\/DhammaSeeker\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595359905722331136",
  "text" : "RT @huffduffer: \u261E Sounds True - Waking Up Session 09 - Saying Yes To Being Found with Richard Rohr https:\/\/t.co\/cVR2lEYw9F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/cVR2lEYw9F",
        "expanded_url" : "https:\/\/huffduffer.com\/DhammaSeeker\/228009",
        "display_url" : "huffduffer.com\/DhammaSeeker\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595353761947746304",
    "text" : "\u261E Sounds True - Waking Up Session 09 - Saying Yes To Being Found with Richard Rohr https:\/\/t.co\/cVR2lEYw9F",
    "id" : 595353761947746304,
    "created_at" : "2015-05-04 22:26:12 +0000",
    "user" : {
      "name" : "huffduffer",
      "screen_name" : "huffduffer",
      "protected" : false,
      "id_str" : "15709661",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/62413788\/huffduffer_normal.jpg",
      "id" : 15709661,
      "verified" : false
    }
  },
  "id" : 595359905722331136,
  "created_at" : "2015-05-04 22:50:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FourCreeksBison",
      "screen_name" : "FourCreeksBison",
      "indices" : [ 3, 19 ],
      "id_str" : "2992737986",
      "id" : 2992737986
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FourCreeksBison\/status\/594669490090151936\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/u2Cl5I4nCD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CECwwB4WAAAFfr2.jpg",
      "id_str" : "594669489997873152",
      "id" : 594669489997873152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CECwwB4WAAAFfr2.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u2Cl5I4nCD"
    } ],
    "hashtags" : [ {
      "text" : "bison",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "animals",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/qszWc4HJU1",
      "expanded_url" : "http:\/\/buff.ly\/1IAxnjR",
      "display_url" : "buff.ly\/1IAxnjR"
    } ]
  },
  "geo" : { },
  "id_str" : "595336222349877248",
  "text" : "RT @FourCreeksBison: Mom cleanin' up baby bison with some kisses (Source: http:\/\/t.co\/qszWc4HJU1) #bison #animals http:\/\/t.co\/u2Cl5I4nCD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FourCreeksBison\/status\/594669490090151936\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/u2Cl5I4nCD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CECwwB4WAAAFfr2.jpg",
        "id_str" : "594669489997873152",
        "id" : 594669489997873152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CECwwB4WAAAFfr2.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 529
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/u2Cl5I4nCD"
      } ],
      "hashtags" : [ {
        "text" : "bison",
        "indices" : [ 77, 83 ]
      }, {
        "text" : "animals",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/qszWc4HJU1",
        "expanded_url" : "http:\/\/buff.ly\/1IAxnjR",
        "display_url" : "buff.ly\/1IAxnjR"
      } ]
    },
    "geo" : { },
    "id_str" : "594669490090151936",
    "text" : "Mom cleanin' up baby bison with some kisses (Source: http:\/\/t.co\/qszWc4HJU1) #bison #animals http:\/\/t.co\/u2Cl5I4nCD",
    "id" : 594669490090151936,
    "created_at" : "2015-05-03 01:07:09 +0000",
    "user" : {
      "name" : "FourCreeksBison",
      "screen_name" : "FourCreeksBison",
      "protected" : false,
      "id_str" : "2992737986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558425828543848448\/vUUbzlpB_normal.jpeg",
      "id" : 2992737986,
      "verified" : false
    }
  },
  "id" : 595336222349877248,
  "created_at" : "2015-05-04 21:16:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FourCreeksBison",
      "screen_name" : "FourCreeksBison",
      "indices" : [ 3, 19 ],
      "id_str" : "2992737986",
      "id" : 2992737986
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FourCreeksBison\/status\/594998631431852032\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uFO7L64e9Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEHcGlGWgAAe8Fe.jpg",
      "id_str" : "594998631385694208",
      "id" : 594998631385694208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEHcGlGWgAAe8Fe.jpg",
      "sizes" : [ {
        "h" : 530,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/uFO7L64e9Z"
    } ],
    "hashtags" : [ {
      "text" : "bison",
      "indices" : [ 99, 105 ]
    }, {
      "text" : "animals",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/fSL8NWDxpi",
      "expanded_url" : "http:\/\/buff.ly\/1DLx7Yy",
      "display_url" : "buff.ly\/1DLx7Yy"
    } ]
  },
  "geo" : { },
  "id_str" : "595336125759258626",
  "text" : "RT @FourCreeksBison: Mama and baby gettin' ready for Mother's Day (source: http:\/\/t.co\/fSL8NWDxpi) #bison #animals http:\/\/t.co\/uFO7L64e9Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FourCreeksBison\/status\/594998631431852032\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/uFO7L64e9Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEHcGlGWgAAe8Fe.jpg",
        "id_str" : "594998631385694208",
        "id" : 594998631385694208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEHcGlGWgAAe8Fe.jpg",
        "sizes" : [ {
          "h" : 530,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/uFO7L64e9Z"
      } ],
      "hashtags" : [ {
        "text" : "bison",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "animals",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/fSL8NWDxpi",
        "expanded_url" : "http:\/\/buff.ly\/1DLx7Yy",
        "display_url" : "buff.ly\/1DLx7Yy"
      } ]
    },
    "geo" : { },
    "id_str" : "594998631431852032",
    "text" : "Mama and baby gettin' ready for Mother's Day (source: http:\/\/t.co\/fSL8NWDxpi) #bison #animals http:\/\/t.co\/uFO7L64e9Z",
    "id" : 594998631431852032,
    "created_at" : "2015-05-03 22:55:02 +0000",
    "user" : {
      "name" : "FourCreeksBison",
      "screen_name" : "FourCreeksBison",
      "protected" : false,
      "id_str" : "2992737986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558425828543848448\/vUUbzlpB_normal.jpeg",
      "id" : 2992737986,
      "verified" : false
    }
  },
  "id" : 595336125759258626,
  "created_at" : "2015-05-04 21:16:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WeeMan",
      "screen_name" : "AntrimLens",
      "indices" : [ 3, 14 ],
      "id_str" : "294769826",
      "id" : 294769826
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/lS3trmp5Jy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3nnHcW0AAbhcK.jpg",
      "id_str" : "593885385081671680",
      "id" : 593885385081671680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3nnHcW0AAbhcK.jpg",
      "sizes" : [ {
        "h" : 1913,
        "resize" : "fit",
        "w" : 2869
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lS3trmp5Jy"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/lS3trmp5Jy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3nnuMWEAEsGOp.jpg",
      "id_str" : "593885395483496449",
      "id" : 593885395483496449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3nnuMWEAEsGOp.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2104,
        "resize" : "fit",
        "w" : 3155
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lS3trmp5Jy"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/lS3trmp5Jy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3nn-SWoAAjyVS.jpg",
      "id_str" : "593885399803666432",
      "id" : 593885399803666432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3nn-SWoAAjyVS.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1913,
        "resize" : "fit",
        "w" : 2869
      } ],
      "display_url" : "pic.twitter.com\/lS3trmp5Jy"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/lS3trmp5Jy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3noJOWMAIPWs9.jpg",
      "id_str" : "593885402739650562",
      "id" : 593885402739650562,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3noJOWMAIPWs9.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2104,
        "resize" : "fit",
        "w" : 3156
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/lS3trmp5Jy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595309250932559873",
  "text" : "RT @AntrimLens: I took a short walk over the fields after dinner and I came across this Irish Hare. http:\/\/t.co\/lS3trmp5Jy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/lS3trmp5Jy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3nnHcW0AAbhcK.jpg",
        "id_str" : "593885385081671680",
        "id" : 593885385081671680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3nnHcW0AAbhcK.jpg",
        "sizes" : [ {
          "h" : 1913,
          "resize" : "fit",
          "w" : 2869
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lS3trmp5Jy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/lS3trmp5Jy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3nnuMWEAEsGOp.jpg",
        "id_str" : "593885395483496449",
        "id" : 593885395483496449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3nnuMWEAEsGOp.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2104,
          "resize" : "fit",
          "w" : 3155
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/lS3trmp5Jy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/lS3trmp5Jy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3nn-SWoAAjyVS.jpg",
        "id_str" : "593885399803666432",
        "id" : 593885399803666432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3nn-SWoAAjyVS.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1913,
          "resize" : "fit",
          "w" : 2869
        } ],
        "display_url" : "pic.twitter.com\/lS3trmp5Jy"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AntrimLens\/status\/593885404459315200\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/lS3trmp5Jy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3noJOWMAIPWs9.jpg",
        "id_str" : "593885402739650562",
        "id" : 593885402739650562,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3noJOWMAIPWs9.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2104,
          "resize" : "fit",
          "w" : 3156
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/lS3trmp5Jy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593885404459315200",
    "text" : "I took a short walk over the fields after dinner and I came across this Irish Hare. http:\/\/t.co\/lS3trmp5Jy",
    "id" : 593885404459315200,
    "created_at" : "2015-04-30 21:11:28 +0000",
    "user" : {
      "name" : "WeeMan",
      "screen_name" : "AntrimLens",
      "protected" : false,
      "id_str" : "294769826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491237470139215872\/WRwZ6Xqa_normal.jpeg",
      "id" : 294769826,
      "verified" : false
    }
  },
  "id" : 595309250932559873,
  "created_at" : "2015-05-04 19:29:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kory Westerhold",
      "screen_name" : "iamkory",
      "indices" : [ 3, 11 ],
      "id_str" : "7407282",
      "id" : 7407282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/1fkJPH9deZ",
      "expanded_url" : "http:\/\/droplr.com",
      "display_url" : "droplr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "595301730495127555",
  "text" : "RT @iamkory: Finally! Sharing made simple. Checking out http:\/\/t.co\/1fkJPH9deZ for quickly sharing screenshots, files and links.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/droplr.com\" rel=\"nofollow\"\u003EDroplr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/1fkJPH9deZ",
        "expanded_url" : "http:\/\/droplr.com",
        "display_url" : "droplr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "595301005350211584",
    "text" : "Finally! Sharing made simple. Checking out http:\/\/t.co\/1fkJPH9deZ for quickly sharing screenshots, files and links.",
    "id" : 595301005350211584,
    "created_at" : "2015-05-04 18:56:34 +0000",
    "user" : {
      "name" : "Kory Westerhold",
      "screen_name" : "iamkory",
      "protected" : false,
      "id_str" : "7407282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796419506054627328\/GnBp--kT_normal.jpg",
      "id" : 7407282,
      "verified" : false
    }
  },
  "id" : 595301730495127555,
  "created_at" : "2015-05-04 18:59:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Green",
      "screen_name" : "getgreeny",
      "indices" : [ 3, 13 ],
      "id_str" : "1555715245",
      "id" : 1555715245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/jV2Y4R0N2C",
      "expanded_url" : "https:\/\/flic.kr\/p\/s9Cmtp",
      "display_url" : "flic.kr\/p\/s9Cmtp"
    } ]
  },
  "geo" : { },
  "id_str" : "595290932012052480",
  "text" : "RT @getgreeny: Bonkers nesting site for a mistle thrush - in a traffic light on the busy Leeds ring road!\nhttps:\/\/t.co\/jV2Y4R0N2C http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/getgreeny\/status\/595290558827991040\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Nu1c7bHzUP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CELlm7VW0AAT6P1.jpg",
        "id_str" : "595290557691383808",
        "id" : 595290557691383808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CELlm7VW0AAT6P1.jpg",
        "sizes" : [ {
          "h" : 482,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 748
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 748
        } ],
        "display_url" : "pic.twitter.com\/Nu1c7bHzUP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/jV2Y4R0N2C",
        "expanded_url" : "https:\/\/flic.kr\/p\/s9Cmtp",
        "display_url" : "flic.kr\/p\/s9Cmtp"
      } ]
    },
    "geo" : { },
    "id_str" : "595290558827991040",
    "text" : "Bonkers nesting site for a mistle thrush - in a traffic light on the busy Leeds ring road!\nhttps:\/\/t.co\/jV2Y4R0N2C http:\/\/t.co\/Nu1c7bHzUP",
    "id" : 595290558827991040,
    "created_at" : "2015-05-04 18:15:03 +0000",
    "user" : {
      "name" : "Paul Green",
      "screen_name" : "getgreeny",
      "protected" : false,
      "id_str" : "1555715245",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572421382579814400\/z-FzKMpY_normal.jpeg",
      "id" : 1555715245,
      "verified" : false
    }
  },
  "id" : 595290932012052480,
  "created_at" : "2015-05-04 18:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Happify",
      "screen_name" : "Happify",
      "indices" : [ 3, 11 ],
      "id_str" : "476366739",
      "id" : 476366739
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 13, 24 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595251500605124608",
  "text" : "RT @Happify: @moosebegab isn't it amazing how much joy seeing kindness can bring us?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "595244702208761857",
    "geo" : { },
    "id_str" : "595250131865309184",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab isn't it amazing how much joy seeing kindness can bring us?",
    "id" : 595250131865309184,
    "in_reply_to_status_id" : 595244702208761857,
    "created_at" : "2015-05-04 15:34:25 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Happify",
      "screen_name" : "Happify",
      "protected" : false,
      "id_str" : "476366739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654055127817560064\/rvN2mcuB_normal.png",
      "id" : 476366739,
      "verified" : false
    }
  },
  "id" : 595251500605124608,
  "created_at" : "2015-05-04 15:39:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/SIvPwGaVb9",
      "expanded_url" : "http:\/\/my.happify.com\/hd\/students-kindness-knows-no-bounds\/?s=cf58660c",
      "display_url" : "my.happify.com\/hd\/students-ki\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595244702208761857",
  "text" : "I cried &gt;&gt; Students\u2019 Kindness Knows No Bounds When They Surprise a Juvenile Prison Basketball Team http:\/\/t.co\/SIvPwGaVb9",
  "id" : 595244702208761857,
  "created_at" : "2015-05-04 15:12:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Gibson",
      "screen_name" : "dgpixphoto",
      "indices" : [ 3, 14 ],
      "id_str" : "114216659",
      "id" : 114216659
    }, {
      "name" : "Tina Gibson",
      "screen_name" : "JellyCrisp",
      "indices" : [ 80, 91 ],
      "id_str" : "180461389",
      "id" : 180461389
    }, {
      "name" : "BBC Springwatch",
      "screen_name" : "BBCSpringwatch",
      "indices" : [ 92, 107 ],
      "id_str" : "71229689",
      "id" : 71229689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "signsofspring",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595234927228125184",
  "text" : "RT @dgpixphoto: I was lucky to capture this dipper courtship display today with @JellyCrisp @BBCSpringwatch #signsofspring http:\/\/t.co\/egST\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tina Gibson",
        "screen_name" : "JellyCrisp",
        "indices" : [ 64, 75 ],
        "id_str" : "180461389",
        "id" : 180461389
      }, {
        "name" : "BBC Springwatch",
        "screen_name" : "BBCSpringwatch",
        "indices" : [ 76, 91 ],
        "id_str" : "71229689",
        "id" : 71229689
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dgpixphoto\/status\/584377157834694656\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/egSTTTNNfb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBwf7XzUoAAm0L0.jpg",
        "id_str" : "584377156513341440",
        "id" : 584377156513341440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBwf7XzUoAAm0L0.jpg",
        "sizes" : [ {
          "h" : 1642,
          "resize" : "fit",
          "w" : 2480
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/egSTTTNNfb"
      } ],
      "hashtags" : [ {
        "text" : "signsofspring",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584377157834694656",
    "text" : "I was lucky to capture this dipper courtship display today with @JellyCrisp @BBCSpringwatch #signsofspring http:\/\/t.co\/egSTTTNNfb",
    "id" : 584377157834694656,
    "created_at" : "2015-04-04 15:29:06 +0000",
    "user" : {
      "name" : "Danny Gibson",
      "screen_name" : "dgpixphoto",
      "protected" : false,
      "id_str" : "114216659",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711610343689166848\/WKIBXWq-_normal.jpg",
      "id" : 114216659,
      "verified" : false
    }
  },
  "id" : 595234927228125184,
  "created_at" : "2015-05-04 14:34:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/4BwMq70hTD",
      "expanded_url" : "http:\/\/Audible.com",
      "display_url" : "Audible.com"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/gi12ltaNmi",
      "expanded_url" : "http:\/\/wp.me\/p1pu8r-bCe",
      "display_url" : "wp.me\/p1pu8r-bCe"
    } ]
  },
  "geo" : { },
  "id_str" : "595034386590015488",
  "text" : "RT @adamrshields: http:\/\/t.co\/4BwMq70hTD Sale - Great Courses (College Lectures) $6.95 Each http:\/\/t.co\/gi12ltaNmi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/4BwMq70hTD",
        "expanded_url" : "http:\/\/Audible.com",
        "display_url" : "Audible.com"
      }, {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/gi12ltaNmi",
        "expanded_url" : "http:\/\/wp.me\/p1pu8r-bCe",
        "display_url" : "wp.me\/p1pu8r-bCe"
      } ]
    },
    "geo" : { },
    "id_str" : "594832178816503810",
    "text" : "http:\/\/t.co\/4BwMq70hTD Sale - Great Courses (College Lectures) $6.95 Each http:\/\/t.co\/gi12ltaNmi",
    "id" : 594832178816503810,
    "created_at" : "2015-05-03 11:53:37 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 595034386590015488,
  "created_at" : "2015-05-04 01:17:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 3, 15 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MotherJones\/status\/593407110349778944\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cuWMJc9I40",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDw0n2bWIAAsYJC.png",
      "id_str" : "593407110135816192",
      "id" : 593407110135816192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDw0n2bWIAAsYJC.png",
      "sizes" : [ {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/cuWMJc9I40"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/e2UhDsoxro",
      "expanded_url" : "http:\/\/bit.ly\/1bbIZfx",
      "display_url" : "bit.ly\/1bbIZfx"
    } ]
  },
  "geo" : { },
  "id_str" : "595020476600156160",
  "text" : "RT @MotherJones: Welcome to America, where if you're born poor, you'll probably stay that way http:\/\/t.co\/e2UhDsoxro http:\/\/t.co\/cuWMJc9I40",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MotherJones\/status\/593407110349778944\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/cuWMJc9I40",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDw0n2bWIAAsYJC.png",
        "id_str" : "593407110135816192",
        "id" : 593407110135816192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDw0n2bWIAAsYJC.png",
        "sizes" : [ {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/cuWMJc9I40"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/e2UhDsoxro",
        "expanded_url" : "http:\/\/bit.ly\/1bbIZfx",
        "display_url" : "bit.ly\/1bbIZfx"
      } ]
    },
    "geo" : { },
    "id_str" : "595001183066030080",
    "text" : "Welcome to America, where if you're born poor, you'll probably stay that way http:\/\/t.co\/e2UhDsoxro http:\/\/t.co\/cuWMJc9I40",
    "id" : 595001183066030080,
    "created_at" : "2015-05-03 23:05:11 +0000",
    "user" : {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "protected" : false,
      "id_str" : "18510860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731988002206027776\/c0HB7fbs_normal.jpg",
      "id" : 18510860,
      "verified" : true
    }
  },
  "id" : 595020476600156160,
  "created_at" : "2015-05-04 00:21:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soraya Chemaly",
      "screen_name" : "schemaly",
      "indices" : [ 3, 12 ],
      "id_str" : "43532023",
      "id" : 43532023
    }, {
      "name" : "Amnesty UK",
      "screen_name" : "AmnestyUK",
      "indices" : [ 121, 131 ],
      "id_str" : "14095052",
      "id" : 14095052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Y9KGtby2Yr",
      "expanded_url" : "https:\/\/www.amnesty.org.uk\/actions\/child-denied-abortion-after-rape-save-her-life#.VUYStIXX2wE.twitter",
      "display_url" : "amnesty.org.uk\/actions\/child-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595020327878578176",
  "text" : "RT @schemaly: 10-yr-old girl pregnant after being raped by her stepfather denied an abortion https:\/\/t.co\/Y9KGtby2Yr via @amnestyuk http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amnesty UK",
        "screen_name" : "AmnestyUK",
        "indices" : [ 107, 117 ],
        "id_str" : "14095052",
        "id" : 14095052
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/schemaly\/status\/594871758513111040\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/HB301S27ay",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEFotL3VEAAlPmq.jpg",
        "id_str" : "594871751277875200",
        "id" : 594871751277875200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEFotL3VEAAlPmq.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/HB301S27ay"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/Y9KGtby2Yr",
        "expanded_url" : "https:\/\/www.amnesty.org.uk\/actions\/child-denied-abortion-after-rape-save-her-life#.VUYStIXX2wE.twitter",
        "display_url" : "amnesty.org.uk\/actions\/child-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594871758513111040",
    "text" : "10-yr-old girl pregnant after being raped by her stepfather denied an abortion https:\/\/t.co\/Y9KGtby2Yr via @amnestyuk http:\/\/t.co\/HB301S27ay",
    "id" : 594871758513111040,
    "created_at" : "2015-05-03 14:30:54 +0000",
    "user" : {
      "name" : "Soraya Chemaly",
      "screen_name" : "schemaly",
      "protected" : false,
      "id_str" : "43532023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797994938864726016\/7qcO_p9p_normal.jpg",
      "id" : 43532023,
      "verified" : false
    }
  },
  "id" : 595020327878578176,
  "created_at" : "2015-05-04 00:21:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "indices" : [ 3, 14 ],
      "id_str" : "1046103560",
      "id" : 1046103560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/594759517885341696\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/zh1IXzea1u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEECnXIWEAA5ABu.jpg",
      "id_str" : "594759501036785664",
      "id" : 594759501036785664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEECnXIWEAA5ABu.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zh1IXzea1u"
    } ],
    "hashtags" : [ {
      "text" : "lambinghighlights15",
      "indices" : [ 16, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595008732276400128",
  "text" : "RT @PVickerton: #lambinghighlights15 http:\/\/t.co\/zh1IXzea1u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PVickerton\/status\/594759517885341696\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/zh1IXzea1u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEECnXIWEAA5ABu.jpg",
        "id_str" : "594759501036785664",
        "id" : 594759501036785664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEECnXIWEAA5ABu.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zh1IXzea1u"
      } ],
      "hashtags" : [ {
        "text" : "lambinghighlights15",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594759517885341696",
    "text" : "#lambinghighlights15 http:\/\/t.co\/zh1IXzea1u",
    "id" : 594759517885341696,
    "created_at" : "2015-05-03 07:04:53 +0000",
    "user" : {
      "name" : "Hawcroft Lleyn",
      "screen_name" : "PVickerton",
      "protected" : false,
      "id_str" : "1046103560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773840339463438336\/-PvOKg0h_normal.jpg",
      "id" : 1046103560,
      "verified" : false
    }
  },
  "id" : 595008732276400128,
  "created_at" : "2015-05-03 23:35:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Pilcher",
      "screen_name" : "DerekPilcher",
      "indices" : [ 3, 16 ],
      "id_str" : "14491446",
      "id" : 14491446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/zCjdk1r3xC",
      "expanded_url" : "https:\/\/www.swarmapp.com\/c\/dr1E91HQi9z",
      "display_url" : "swarmapp.com\/c\/dr1E91HQi9z"
    } ]
  },
  "geo" : { },
  "id_str" : "594960312299814912",
  "text" : "RT @DerekPilcher: Stopped by a family of days old cygnets &amp; swans on the walk to Sunday Lunch at the pub https:\/\/t.co\/zCjdk1r3xC http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DerekPilcher\/status\/594873429913894912\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/0FG61i4uqF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEFqO4TWgAA_i8s.jpg",
        "id_str" : "594873429653880832",
        "id" : 594873429653880832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEFqO4TWgAA_i8s.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1440,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0FG61i4uqF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/zCjdk1r3xC",
        "expanded_url" : "https:\/\/www.swarmapp.com\/c\/dr1E91HQi9z",
        "display_url" : "swarmapp.com\/c\/dr1E91HQi9z"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.799837828779104, -0.07500905664852284 ]
    },
    "id_str" : "594873429913894912",
    "text" : "Stopped by a family of days old cygnets &amp; swans on the walk to Sunday Lunch at the pub https:\/\/t.co\/zCjdk1r3xC http:\/\/t.co\/0FG61i4uqF",
    "id" : 594873429913894912,
    "created_at" : "2015-05-03 14:37:32 +0000",
    "user" : {
      "name" : "Derek Pilcher",
      "screen_name" : "DerekPilcher",
      "protected" : false,
      "id_str" : "14491446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602786859379347457\/CQKdgBlp_normal.png",
      "id" : 14491446,
      "verified" : false
    }
  },
  "id" : 594960312299814912,
  "created_at" : "2015-05-03 20:22:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/juliaf78\/status\/593200575673552896\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/fMwP9XisHe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDt4x6zUMAED5YW.jpg",
      "id_str" : "593200574922764289",
      "id" : 593200574922764289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDt4x6zUMAED5YW.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fMwP9XisHe"
    } ],
    "hashtags" : [ {
      "text" : "ORCA",
      "indices" : [ 20, 25 ]
    }, {
      "text" : "Blackfish",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "SeaWorld",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594957985304162307",
  "text" : "RT @oceanshaman: NO #ORCA EVER SIGNED UP FOR THIS!! #Blackfish #SeaWorld  http:\/\/t.co\/fMwP9XisHe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/juliaf78\/status\/593200575673552896\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/fMwP9XisHe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDt4x6zUMAED5YW.jpg",
        "id_str" : "593200574922764289",
        "id" : 593200574922764289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDt4x6zUMAED5YW.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fMwP9XisHe"
      } ],
      "hashtags" : [ {
        "text" : "ORCA",
        "indices" : [ 3, 8 ]
      }, {
        "text" : "Blackfish",
        "indices" : [ 35, 45 ]
      }, {
        "text" : "SeaWorld",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594957449980841984",
    "text" : "NO #ORCA EVER SIGNED UP FOR THIS!! #Blackfish #SeaWorld  http:\/\/t.co\/fMwP9XisHe",
    "id" : 594957449980841984,
    "created_at" : "2015-05-03 20:11:24 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 594957985304162307,
  "created_at" : "2015-05-03 20:13:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rebels mom",
      "screen_name" : "anonhumanperson",
      "indices" : [ 3, 19 ],
      "id_str" : "2163883202",
      "id" : 2163883202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594957960494882816",
  "text" : "RT @anonhumanperson: Narnia, Captured in 2012, shown on plane being transferred to Moscow, should be in sea not in sky #Blackfish http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/juliaf78\/status\/593200575673552896\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/jKDjIhEkeN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDt4x6zUMAED5YW.jpg",
        "id_str" : "593200574922764289",
        "id" : 593200574922764289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDt4x6zUMAED5YW.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jKDjIhEkeN"
      } ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594926384872460289",
    "text" : "Narnia, Captured in 2012, shown on plane being transferred to Moscow, should be in sea not in sky #Blackfish http:\/\/t.co\/jKDjIhEkeN",
    "id" : 594926384872460289,
    "created_at" : "2015-05-03 18:07:58 +0000",
    "user" : {
      "name" : "rebels mom",
      "screen_name" : "anonhumanperson",
      "protected" : false,
      "id_str" : "2163883202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797945241387106304\/6vP2dScM_normal.jpg",
      "id" : 2163883202,
      "verified" : false
    }
  },
  "id" : 594957960494882816,
  "created_at" : "2015-05-03 20:13:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stunning Pictures",
      "screen_name" : "PicturesEarth",
      "indices" : [ 3, 17 ],
      "id_str" : "1098364164",
      "id" : 1098364164
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PicturesEarth\/status\/594918067852996608\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/sYN4YcLoma",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEGS1EmUIAEHEFB.jpg",
      "id_str" : "594918066254782465",
      "id" : 594918066254782465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEGS1EmUIAEHEFB.jpg",
      "sizes" : [ {
        "h" : 592,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 592
      } ],
      "display_url" : "pic.twitter.com\/sYN4YcLoma"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594936020690403328",
  "text" : "RT @PicturesEarth: 2 year old little girl being protected by her 4 year old brother in Nepal http:\/\/t.co\/sYN4YcLoma",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PicturesEarth\/status\/594918067852996608\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/sYN4YcLoma",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEGS1EmUIAEHEFB.jpg",
        "id_str" : "594918066254782465",
        "id" : 594918066254782465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEGS1EmUIAEHEFB.jpg",
        "sizes" : [ {
          "h" : 592,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 592
        } ],
        "display_url" : "pic.twitter.com\/sYN4YcLoma"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594918067852996608",
    "text" : "2 year old little girl being protected by her 4 year old brother in Nepal http:\/\/t.co\/sYN4YcLoma",
    "id" : 594918067852996608,
    "created_at" : "2015-05-03 17:34:55 +0000",
    "user" : {
      "name" : "Stunning Pictures",
      "screen_name" : "PicturesEarth",
      "protected" : false,
      "id_str" : "1098364164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000821899035\/3c54c23ddce812cef8c1a0e2141e4505_normal.jpeg",
      "id" : 1098364164,
      "verified" : false
    }
  },
  "id" : 594936020690403328,
  "created_at" : "2015-05-03 18:46:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle McElveen",
      "screen_name" : "mmcelveen64",
      "indices" : [ 3, 15 ],
      "id_str" : "2590257525",
      "id" : 2590257525
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Akhan2001\/status\/594479477050241025\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/HyUtLeUSyg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEAD6-BWMAAt01b.jpg",
      "id_str" : "594479462428848128",
      "id" : 594479462428848128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEAD6-BWMAAt01b.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 445
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 445
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 445
      } ],
      "display_url" : "pic.twitter.com\/HyUtLeUSyg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594916788959313920",
  "text" : "RT @mmcelveen64: http:\/\/t.co\/HyUtLeUSyg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Akhan2001\/status\/594479477050241025\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/HyUtLeUSyg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEAD6-BWMAAt01b.jpg",
        "id_str" : "594479462428848128",
        "id" : 594479462428848128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEAD6-BWMAAt01b.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 445
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 445
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 445
        } ],
        "display_url" : "pic.twitter.com\/HyUtLeUSyg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594832369049346048",
    "text" : "http:\/\/t.co\/HyUtLeUSyg",
    "id" : 594832369049346048,
    "created_at" : "2015-05-03 11:54:22 +0000",
    "user" : {
      "name" : "Michelle McElveen",
      "screen_name" : "mmcelveen64",
      "protected" : false,
      "id_str" : "2590257525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650278834579898369\/Dewl08ce_normal.jpg",
      "id" : 2590257525,
      "verified" : false
    }
  },
  "id" : 594916788959313920,
  "created_at" : "2015-05-03 17:29:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/HoDbal4E2M",
      "expanded_url" : "https:\/\/twitter.com\/webs\/status\/594914345877958657",
      "display_url" : "twitter.com\/webs\/status\/59\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594914554779455488",
  "text" : "now this is hilarious. i love it! https:\/\/t.co\/HoDbal4E2M",
  "id" : 594914554779455488,
  "created_at" : "2015-05-03 17:20:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594914363036803072",
  "text" : "Dear Universe, I need some understanding w this whole church thing cuz my nerves are getting a bit toasted IYKWIM.. kthxbye",
  "id" : 594914363036803072,
  "created_at" : "2015-05-03 17:20:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Arel",
      "screen_name" : "danarel",
      "indices" : [ 3, 11 ],
      "id_str" : "11994002",
      "id" : 11994002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BernieSanders",
      "indices" : [ 28, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/3LWGEbQ9on",
      "expanded_url" : "https:\/\/medium.com\/@honeystaysuper\/how-to-talk-to-your-kids-about-bernie-sanders-db1263608fff",
      "display_url" : "medium.com\/@honeystaysupe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594679029401288705",
  "text" : "RT @danarel: How to explain #BernieSanders to your kids.\n\nThis is just great\n\nhttps:\/\/t.co\/3LWGEbQ9on",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BernieSanders",
        "indices" : [ 15, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/3LWGEbQ9on",
        "expanded_url" : "https:\/\/medium.com\/@honeystaysuper\/how-to-talk-to-your-kids-about-bernie-sanders-db1263608fff",
        "display_url" : "medium.com\/@honeystaysupe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594588317766680576",
    "text" : "How to explain #BernieSanders to your kids.\n\nThis is just great\n\nhttps:\/\/t.co\/3LWGEbQ9on",
    "id" : 594588317766680576,
    "created_at" : "2015-05-02 19:44:36 +0000",
    "user" : {
      "name" : "Dan Arel",
      "screen_name" : "danarel",
      "protected" : false,
      "id_str" : "11994002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695653919834267648\/PBUEr0D7_normal.png",
      "id" : 11994002,
      "verified" : true
    }
  },
  "id" : 594679029401288705,
  "created_at" : "2015-05-03 01:45:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/I0cKTEhueA",
      "expanded_url" : "https:\/\/youtu.be\/3DWxqXsIX1E",
      "display_url" : "youtu.be\/3DWxqXsIX1E"
    } ]
  },
  "geo" : { },
  "id_str" : "594572171533496320",
  "text" : "LOL \"Ask some physicists about which which multi-verse theory is correct...\" Mike McHargue 01:02:06 https:\/\/t.co\/I0cKTEhueA",
  "id" : 594572171533496320,
  "created_at" : "2015-05-02 18:40:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/I0cKTEhueA",
      "expanded_url" : "https:\/\/youtu.be\/3DWxqXsIX1E",
      "display_url" : "youtu.be\/3DWxqXsIX1E"
    } ]
  },
  "geo" : { },
  "id_str" : "594512639872610305",
  "text" : "\"A part of you slowly dies when you pretend to be something you are not all the time.\" Mike McHargue 23:45 https:\/\/t.co\/I0cKTEhueA",
  "id" : 594512639872610305,
  "created_at" : "2015-05-02 14:43:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    }, {
      "name" : "The Village Square",
      "screen_name" : "VillageSquareFL",
      "indices" : [ 85, 101 ],
      "id_str" : "76342176",
      "id" : 76342176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594502860303409152",
  "text" : "RT @mikemchargue: Audio from my recent appearance at the Faith vs Science panel with @VillageSquareFL for those of you who asked. :) http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Village Square",
        "screen_name" : "VillageSquareFL",
        "indices" : [ 67, 83 ],
        "id_str" : "76342176",
        "id" : 76342176
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/SRF5qSpZBj",
        "expanded_url" : "http:\/\/wiki.tothevillagesquare.org\/display\/events\/Faith+vs.+Science",
        "display_url" : "wiki.tothevillagesquare.org\/display\/events\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594490947439853568",
    "text" : "Audio from my recent appearance at the Faith vs Science panel with @VillageSquareFL for those of you who asked. :) http:\/\/t.co\/SRF5qSpZBj",
    "id" : 594490947439853568,
    "created_at" : "2015-05-02 13:17:41 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 594502860303409152,
  "created_at" : "2015-05-02 14:05:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "indices" : [ 3, 19 ],
      "id_str" : "2163374389",
      "id" : 2163374389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594300433927118848",
  "text" : "RT @existentialcoms: The major problem with being alive is that you have to be awake for very large portions of it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594300294575435776",
    "text" : "The major problem with being alive is that you have to be awake for very large portions of it.",
    "id" : 594300294575435776,
    "created_at" : "2015-05-02 00:40:06 +0000",
    "user" : {
      "name" : "Existential Comics",
      "screen_name" : "existentialcoms",
      "protected" : false,
      "id_str" : "2163374389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916557403795456\/d-iEnfPD_normal.jpg",
      "id" : 2163374389,
      "verified" : false
    }
  },
  "id" : 594300433927118848,
  "created_at" : "2015-05-02 00:40:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/8uDrJePeGq",
      "expanded_url" : "http:\/\/bit.ly\/1I3GpH7",
      "display_url" : "bit.ly\/1I3GpH7"
    } ]
  },
  "geo" : { },
  "id_str" : "594295825620140032",
  "text" : "RT @Floridaline: Princeton professor claims the 'Christian nation' idea was invented by corporate America \n\nhttp:\/\/t.co\/8uDrJePeGq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/8uDrJePeGq",
        "expanded_url" : "http:\/\/bit.ly\/1I3GpH7",
        "display_url" : "bit.ly\/1I3GpH7"
      } ]
    },
    "geo" : { },
    "id_str" : "594237067145650176",
    "text" : "Princeton professor claims the 'Christian nation' idea was invented by corporate America \n\nhttp:\/\/t.co\/8uDrJePeGq",
    "id" : 594237067145650176,
    "created_at" : "2015-05-01 20:28:51 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 594295825620140032,
  "created_at" : "2015-05-02 00:22:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tilikum",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "Blackfish",
      "indices" : [ 54, 64 ]
    }, {
      "text" : "orcas",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "cetaceans",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594274269246402560",
  "text" : "RT @oceanshaman: #Tilikum  Our Ambassador for Change! #Blackfish #orcas #cetaceans ALL CAPTURED &amp; HELD CAPTIVE AGAINST THEIR WILL! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oceanshaman\/status\/594269490306805760\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/lRcXfdnwOU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD9E8h3VAAAmAfZ.jpg",
        "id_str" : "594269482509467648",
        "id" : 594269482509467648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD9E8h3VAAAmAfZ.jpg",
        "sizes" : [ {
          "h" : 489,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lRcXfdnwOU"
      } ],
      "hashtags" : [ {
        "text" : "Tilikum",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "Blackfish",
        "indices" : [ 37, 47 ]
      }, {
        "text" : "orcas",
        "indices" : [ 48, 54 ]
      }, {
        "text" : "cetaceans",
        "indices" : [ 55, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594269490306805760",
    "text" : "#Tilikum  Our Ambassador for Change! #Blackfish #orcas #cetaceans ALL CAPTURED &amp; HELD CAPTIVE AGAINST THEIR WILL! http:\/\/t.co\/lRcXfdnwOU",
    "id" : 594269490306805760,
    "created_at" : "2015-05-01 22:37:42 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 594274269246402560,
  "created_at" : "2015-05-01 22:56:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594273980158242816",
  "text" : "Android does not have good audiobook apps. Got a nice one on my WP.",
  "id" : 594273980158242816,
  "created_at" : "2015-05-01 22:55:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Granny_of_10\/status\/550474580788510720\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Hey1NDVg4j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B6OtXmRCcAAdwFj.jpg",
      "id_str" : "550474200389939200",
      "id" : 550474200389939200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6OtXmRCcAAdwFj.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Hey1NDVg4j"
    } ],
    "hashtags" : [ {
      "text" : "TILIKUM",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "Blackfish",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594236006867595264",
  "text" : "RT @oceanshaman: YOU WANT TO LIVE THIS WAY, NEITHER DOES #TILIKUM! #Blackfish   http:\/\/t.co\/Hey1NDVg4j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Granny_of_10\/status\/550474580788510720\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Hey1NDVg4j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B6OtXmRCcAAdwFj.jpg",
        "id_str" : "550474200389939200",
        "id" : 550474200389939200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B6OtXmRCcAAdwFj.jpg",
        "sizes" : [ {
          "h" : 254,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Hey1NDVg4j"
      } ],
      "hashtags" : [ {
        "text" : "TILIKUM",
        "indices" : [ 40, 48 ]
      }, {
        "text" : "Blackfish",
        "indices" : [ 50, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594233388476735488",
    "text" : "YOU WANT TO LIVE THIS WAY, NEITHER DOES #TILIKUM! #Blackfish   http:\/\/t.co\/Hey1NDVg4j",
    "id" : 594233388476735488,
    "created_at" : "2015-05-01 20:14:14 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 594236006867595264,
  "created_at" : "2015-05-01 20:24:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicky Nelson",
      "screen_name" : "CanDoNicky",
      "indices" : [ 3, 14 ],
      "id_str" : "386045721",
      "id" : 386045721
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 73, 85 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CanDoNicky\/status\/594208737038073857\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/LMUZS9o4IE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD8NsnUW8AEE-4d.jpg",
      "id_str" : "594208735955972097",
      "id" : 594208735955972097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD8NsnUW8AEE-4d.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 721,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LMUZS9o4IE"
    } ],
    "hashtags" : [ {
      "text" : "wildlifephotography",
      "indices" : [ 86, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594235806979629056",
  "text" : "RT @CanDoNicky: Couldn't resist popping back to take more squirrel snaps @wildlife_uk #wildlifephotography http:\/\/t.co\/LMUZS9o4IE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 57, 69 ],
        "id_str" : "298992506",
        "id" : 298992506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CanDoNicky\/status\/594208737038073857\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/LMUZS9o4IE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD8NsnUW8AEE-4d.jpg",
        "id_str" : "594208735955972097",
        "id" : 594208735955972097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD8NsnUW8AEE-4d.jpg",
        "sizes" : [ {
          "h" : 774,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 721,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LMUZS9o4IE"
      } ],
      "hashtags" : [ {
        "text" : "wildlifephotography",
        "indices" : [ 70, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594208737038073857",
    "text" : "Couldn't resist popping back to take more squirrel snaps @wildlife_uk #wildlifephotography http:\/\/t.co\/LMUZS9o4IE",
    "id" : 594208737038073857,
    "created_at" : "2015-05-01 18:36:17 +0000",
    "user" : {
      "name" : "Nicky Nelson",
      "screen_name" : "CanDoNicky",
      "protected" : false,
      "id_str" : "386045721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793476332118167553\/ktaR9icE_normal.jpg",
      "id" : 386045721,
      "verified" : false
    }
  },
  "id" : 594235806979629056,
  "created_at" : "2015-05-01 20:23:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/0nitg0es\/status\/580064660222771200\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/vsvVUbeX6a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzNtC2UIAAR_ra.png",
      "id_str" : "580064625766440960",
      "id" : 580064625766440960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzNtC2UIAAR_ra.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 458
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 458
      } ],
      "display_url" : "pic.twitter.com\/vsvVUbeX6a"
    } ],
    "hashtags" : [ {
      "text" : "SeaWorld",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "OpSeaWorld",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594235525948678144",
  "text" : "RT @tweetforcetacea: Tilikum has sired 21 calves, 10 are dead now. Unnatural breeding at #SeaWorld http:\/\/t.co\/vsvVUbeX6a #OpSeaWorld",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/0nitg0es\/status\/580064660222771200\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/vsvVUbeX6a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzNtC2UIAAR_ra.png",
        "id_str" : "580064625766440960",
        "id" : 580064625766440960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzNtC2UIAAR_ra.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 458
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 458
        } ],
        "display_url" : "pic.twitter.com\/vsvVUbeX6a"
      } ],
      "hashtags" : [ {
        "text" : "SeaWorld",
        "indices" : [ 68, 77 ]
      }, {
        "text" : "OpSeaWorld",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594158707702894594",
    "text" : "Tilikum has sired 21 calves, 10 are dead now. Unnatural breeding at #SeaWorld http:\/\/t.co\/vsvVUbeX6a #OpSeaWorld",
    "id" : 594158707702894594,
    "created_at" : "2015-05-01 15:17:29 +0000",
    "user" : {
      "name" : "Army of Poppies",
      "screen_name" : "tweet4cetacea",
      "protected" : false,
      "id_str" : "2943934487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799937288314593280\/iZ2DynWh_normal.jpg",
      "id" : 2943934487,
      "verified" : false
    }
  },
  "id" : 594235525948678144,
  "created_at" : "2015-05-01 20:22:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicky Nelson",
      "screen_name" : "CanDoNicky",
      "indices" : [ 3, 14 ],
      "id_str" : "386045721",
      "id" : 386045721
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CanDoNicky\/status\/594167784877207552\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Oc01c5v63O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7ocPNXIAA1X57.jpg",
      "id_str" : "594167772676038656",
      "id" : 594167772676038656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7ocPNXIAA1X57.jpg",
      "sizes" : [ {
        "h" : 615,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Oc01c5v63O"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/CanDoNicky\/status\/594167784877207552\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Oc01c5v63O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7ocnpW8AEedRZ.jpg",
      "id_str" : "594167779235917825",
      "id" : 594167779235917825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7ocnpW8AEedRZ.jpg",
      "sizes" : [ {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 963
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 963
      } ],
      "display_url" : "pic.twitter.com\/Oc01c5v63O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594234901441990657",
  "text" : "RT @CanDoNicky: Gorgeous baby squirrels from yesterday - did I tweet these already?? http:\/\/t.co\/Oc01c5v63O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CanDoNicky\/status\/594167784877207552\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/Oc01c5v63O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7ocPNXIAA1X57.jpg",
        "id_str" : "594167772676038656",
        "id" : 594167772676038656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7ocPNXIAA1X57.jpg",
        "sizes" : [ {
          "h" : 615,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 615,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Oc01c5v63O"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CanDoNicky\/status\/594167784877207552\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/Oc01c5v63O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7ocnpW8AEedRZ.jpg",
        "id_str" : "594167779235917825",
        "id" : 594167779235917825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7ocnpW8AEedRZ.jpg",
        "sizes" : [ {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 729,
          "resize" : "fit",
          "w" : 963
        } ],
        "display_url" : "pic.twitter.com\/Oc01c5v63O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594167784877207552",
    "text" : "Gorgeous baby squirrels from yesterday - did I tweet these already?? http:\/\/t.co\/Oc01c5v63O",
    "id" : 594167784877207552,
    "created_at" : "2015-05-01 15:53:33 +0000",
    "user" : {
      "name" : "Nicky Nelson",
      "screen_name" : "CanDoNicky",
      "protected" : false,
      "id_str" : "386045721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793476332118167553\/ktaR9icE_normal.jpg",
      "id" : 386045721,
      "verified" : false
    }
  },
  "id" : 594234901441990657,
  "created_at" : "2015-05-01 20:20:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Martin",
      "screen_name" : "carolmmartin10",
      "indices" : [ 3, 18 ],
      "id_str" : "1558144946",
      "id" : 1558144946
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/carolmmartin10\/status\/594161681208627203\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/lyHfxna4Mc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7i4bzWAAAmN_E.jpg",
      "id_str" : "594161660023144448",
      "id" : 594161660023144448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7i4bzWAAAmN_E.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lyHfxna4Mc"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/carolmmartin10\/status\/594161681208627203\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/lyHfxna4Mc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7i4mxWEAAKC7g.jpg",
      "id_str" : "594161662967549952",
      "id" : 594161662967549952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7i4mxWEAAKC7g.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lyHfxna4Mc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594226902199599105",
  "text" : "RT @carolmmartin10: Got back from shopping &amp; found Foxy asleep in the garden. \"Hurry up love I'm starving\"\uD83D\uDC3A http:\/\/t.co\/lyHfxna4Mc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/carolmmartin10\/status\/594161681208627203\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/lyHfxna4Mc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7i4bzWAAAmN_E.jpg",
        "id_str" : "594161660023144448",
        "id" : 594161660023144448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7i4bzWAAAmN_E.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lyHfxna4Mc"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/carolmmartin10\/status\/594161681208627203\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/lyHfxna4Mc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7i4mxWEAAKC7g.jpg",
        "id_str" : "594161662967549952",
        "id" : 594161662967549952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7i4mxWEAAKC7g.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lyHfxna4Mc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594161681208627203",
    "text" : "Got back from shopping &amp; found Foxy asleep in the garden. \"Hurry up love I'm starving\"\uD83D\uDC3A http:\/\/t.co\/lyHfxna4Mc",
    "id" : 594161681208627203,
    "created_at" : "2015-05-01 15:29:18 +0000",
    "user" : {
      "name" : "Carol Martin",
      "screen_name" : "carolmmartin10",
      "protected" : false,
      "id_str" : "1558144946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681888586250215424\/F5d4dg20_normal.jpg",
      "id" : 1558144946,
      "verified" : false
    }
  },
  "id" : 594226902199599105,
  "created_at" : "2015-05-01 19:48:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rex Graham",
      "screen_name" : "TopBirdingTours",
      "indices" : [ 3, 19 ],
      "id_str" : "2830022213",
      "id" : 2830022213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/R4nStRHHOJ",
      "expanded_url" : "https:\/\/topbirdingtours.com\/?p=8450",
      "display_url" : "topbirdingtours.com\/?p=8450"
    } ]
  },
  "geo" : { },
  "id_str" : "594174005684379648",
  "text" : "RT @TopBirdingTours: Once nearly extinct, 16,000 Trumpeter Swans preparing to migrate mostly to Alaska &amp; Canada\nhttps:\/\/t.co\/R4nStRHHOJ htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TopBirdingTours\/status\/594172438641946625\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/CfFa1MCyKg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7srzZUMAAuS5T.jpg",
        "id_str" : "594172438134403072",
        "id" : 594172438134403072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7srzZUMAAuS5T.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/CfFa1MCyKg"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/R4nStRHHOJ",
        "expanded_url" : "https:\/\/topbirdingtours.com\/?p=8450",
        "display_url" : "topbirdingtours.com\/?p=8450"
      } ]
    },
    "geo" : { },
    "id_str" : "594172438641946625",
    "text" : "Once nearly extinct, 16,000 Trumpeter Swans preparing to migrate mostly to Alaska &amp; Canada\nhttps:\/\/t.co\/R4nStRHHOJ http:\/\/t.co\/CfFa1MCyKg",
    "id" : 594172438641946625,
    "created_at" : "2015-05-01 16:12:03 +0000",
    "user" : {
      "name" : "Rex Graham",
      "screen_name" : "TopBirdingTours",
      "protected" : false,
      "id_str" : "2830022213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637758382456221696\/KisYzDlh_normal.jpg",
      "id" : 2830022213,
      "verified" : false
    }
  },
  "id" : 594174005684379648,
  "created_at" : "2015-05-01 16:18:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594165692028563458",
  "text" : "I believe I'm right in my views (like any person does) but try not to feel superior. I fail sometimes.",
  "id" : 594165692028563458,
  "created_at" : "2015-05-01 15:45:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594164705368920064",
  "text" : "I don't strictly identify with any group. I'm a hodgepodge.",
  "id" : 594164705368920064,
  "created_at" : "2015-05-01 15:41:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "indices" : [ 3, 19 ],
      "id_str" : "457436503",
      "id" : 457436503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/594156105581928448\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/tl4GR1DwZc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7dsC8WYAAEMrE.jpg",
      "id_str" : "594155949633462272",
      "id" : 594155949633462272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7dsC8WYAAEMrE.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/tl4GR1DwZc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594163057863057408",
  "text" : "RT @hilltopfarmgirl: A Black Wensleydale ewe on a glorious morning. http:\/\/t.co\/tl4GR1DwZc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/594156105581928448\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/tl4GR1DwZc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7dsC8WYAAEMrE.jpg",
        "id_str" : "594155949633462272",
        "id" : 594155949633462272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7dsC8WYAAEMrE.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/tl4GR1DwZc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594156105581928448",
    "text" : "A Black Wensleydale ewe on a glorious morning. http:\/\/t.co\/tl4GR1DwZc",
    "id" : 594156105581928448,
    "created_at" : "2015-05-01 15:07:09 +0000",
    "user" : {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "protected" : false,
      "id_str" : "457436503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3491566457\/61244b7682c638ad4b0a097321ae762e_normal.jpeg",
      "id" : 457436503,
      "verified" : false
    }
  },
  "id" : 594163057863057408,
  "created_at" : "2015-05-01 15:34:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FeedBunch",
      "screen_name" : "FeedBunch",
      "indices" : [ 42, 52 ],
      "id_str" : "2443578122",
      "id" : 2443578122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/OEPfPRITdp",
      "expanded_url" : "http:\/\/scripting.com\/2015\/04\/30\/reproducible.html",
      "display_url" : "scripting.com\/2015\/04\/30\/rep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594155261973143552",
  "text" : "\"Reproducible\" http:\/\/t.co\/OEPfPRITdp via @feedbunch \"Key question: What were you doing?\"",
  "id" : 594155261973143552,
  "created_at" : "2015-05-01 15:03:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Climate Council",
      "screen_name" : "climatecouncil",
      "indices" : [ 3, 18 ],
      "id_str" : "1892683062",
      "id" : 1892683062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/HeabJWW6j5",
      "expanded_url" : "http:\/\/on.nrdc.org\/1JaimTR",
      "display_url" : "on.nrdc.org\/1JaimTR"
    } ]
  },
  "geo" : { },
  "id_str" : "594151820215320576",
  "text" : "RT @climatecouncil: Michelle Obama announces that the US solar industry will hire 30,000 military veterans http:\/\/t.co\/HeabJWW6j5 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/climatecouncil\/status\/594013395013095424\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/nPnGVzvBvL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDzN7QzW0AEXOKW.png",
        "id_str" : "593575668912410625",
        "id" : 593575668912410625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDzN7QzW0AEXOKW.png",
        "sizes" : [ {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 497
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 497
        } ],
        "display_url" : "pic.twitter.com\/nPnGVzvBvL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/HeabJWW6j5",
        "expanded_url" : "http:\/\/on.nrdc.org\/1JaimTR",
        "display_url" : "on.nrdc.org\/1JaimTR"
      } ]
    },
    "geo" : { },
    "id_str" : "594013395013095424",
    "text" : "Michelle Obama announces that the US solar industry will hire 30,000 military veterans http:\/\/t.co\/HeabJWW6j5 http:\/\/t.co\/nPnGVzvBvL",
    "id" : 594013395013095424,
    "created_at" : "2015-05-01 05:40:04 +0000",
    "user" : {
      "name" : "Climate Council",
      "screen_name" : "climatecouncil",
      "protected" : false,
      "id_str" : "1892683062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504862206479970304\/rWWL00qW_normal.jpeg",
      "id" : 1892683062,
      "verified" : false
    }
  },
  "id" : 594151820215320576,
  "created_at" : "2015-05-01 14:50:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jeremy scahill",
      "screen_name" : "jeremyscahill",
      "indices" : [ 3, 17 ],
      "id_str" : "23839835",
      "id" : 23839835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594146533269987328",
  "text" : "RT @jeremyscahill: The way \"journalists\" demand Black people condemn violent protests is how they should question US officials on their war\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593591567316852736",
    "text" : "The way \"journalists\" demand Black people condemn violent protests is how they should question US officials on their wars. But they won't.",
    "id" : 593591567316852736,
    "created_at" : "2015-04-30 01:43:52 +0000",
    "user" : {
      "name" : "jeremy scahill",
      "screen_name" : "jeremyscahill",
      "protected" : false,
      "id_str" : "23839835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568816509741301760\/sR2mQ2nb_normal.jpeg",
      "id" : 23839835,
      "verified" : true
    }
  },
  "id" : 594146533269987328,
  "created_at" : "2015-05-01 14:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]