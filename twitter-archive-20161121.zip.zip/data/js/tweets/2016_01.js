Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittani",
      "screen_name" : "farr_brittani",
      "indices" : [ 3, 17 ],
      "id_str" : "3025205145",
      "id" : 3025205145
    }, {
      "name" : "The Gospel Coalition",
      "screen_name" : "TGC",
      "indices" : [ 97, 101 ],
      "id_str" : "31014746",
      "id" : 31014746
    }, {
      "name" : "John Piper",
      "screen_name" : "JohnPiper",
      "indices" : [ 107, 117 ],
      "id_str" : "27500565",
      "id" : 27500565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693978217724649472",
  "text" : "RT @farr_brittani: This should be required reading for anyone who supports The Gospel Coalition (@TGC ) or @JohnPiper. https:\/\/t.co\/KQfND0n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Gospel Coalition",
        "screen_name" : "TGC",
        "indices" : [ 78, 82 ],
        "id_str" : "31014746",
        "id" : 31014746
      }, {
        "name" : "John Piper",
        "screen_name" : "JohnPiper",
        "indices" : [ 88, 98 ],
        "id_str" : "27500565",
        "id" : 27500565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/KQfND0nRJm",
        "expanded_url" : "https:\/\/natesparks130.wordpress.com\/2016\/01\/31\/injustice-an-open-letter-to-the-gospel-coalition\/?utm_content=bufferbbcf5&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer",
        "display_url" : "natesparks130.wordpress.com\/2016\/01\/31\/inj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693864936708120576",
    "text" : "This should be required reading for anyone who supports The Gospel Coalition (@TGC ) or @JohnPiper. https:\/\/t.co\/KQfND0nRJm",
    "id" : 693864936708120576,
    "created_at" : "2016-01-31 18:34:26 +0000",
    "user" : {
      "name" : "Brittani",
      "screen_name" : "farr_brittani",
      "protected" : false,
      "id_str" : "3025205145",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/693286072197988352\/afq7TJeq_normal.jpg",
      "id" : 3025205145,
      "verified" : false
    }
  },
  "id" : 693978217724649472,
  "created_at" : "2016-02-01 02:04:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael",
      "screen_name" : "RafaelStepanian",
      "indices" : [ 3, 19 ],
      "id_str" : "444933627",
      "id" : 444933627
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RafaelStepanian\/status\/693935140423204865\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/q55aici11Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaFaUrRWEAA1Faf.jpg",
      "id_str" : "693935128851124224",
      "id" : 693935128851124224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaFaUrRWEAA1Faf.jpg",
      "sizes" : [ {
        "h" : 650,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/q55aici11Z"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/RafaelStepanian\/status\/693935140423204865\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/q55aici11Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaFaVSHWYAA0LaJ.jpg",
      "id_str" : "693935139278184448",
      "id" : 693935139278184448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaFaVSHWYAA0LaJ.jpg",
      "sizes" : [ {
        "h" : 246,
        "resize" : "fit",
        "w" : 365
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 365
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 365
      } ],
      "display_url" : "pic.twitter.com\/q55aici11Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693946736625242113",
  "text" : "RT @RafaelStepanian: Capitalism is prehistoric savagery https:\/\/t.co\/q55aici11Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RafaelStepanian\/status\/693935140423204865\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/q55aici11Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaFaUrRWEAA1Faf.jpg",
        "id_str" : "693935128851124224",
        "id" : 693935128851124224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaFaUrRWEAA1Faf.jpg",
        "sizes" : [ {
          "h" : 650,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 650,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q55aici11Z"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/RafaelStepanian\/status\/693935140423204865\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/q55aici11Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaFaVSHWYAA0LaJ.jpg",
        "id_str" : "693935139278184448",
        "id" : 693935139278184448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaFaVSHWYAA0LaJ.jpg",
        "sizes" : [ {
          "h" : 246,
          "resize" : "fit",
          "w" : 365
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 365
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 365
        } ],
        "display_url" : "pic.twitter.com\/q55aici11Z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693935140423204865",
    "text" : "Capitalism is prehistoric savagery https:\/\/t.co\/q55aici11Z",
    "id" : 693935140423204865,
    "created_at" : "2016-01-31 23:13:24 +0000",
    "user" : {
      "name" : "Rafael",
      "screen_name" : "RafaelStepanian",
      "protected" : false,
      "id_str" : "444933627",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737308245488984066\/bxKDNtxI_normal.jpg",
      "id" : 444933627,
      "verified" : false
    }
  },
  "id" : 693946736625242113,
  "created_at" : "2016-01-31 23:59:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "indices" : [ 3, 13 ],
      "id_str" : "15104467",
      "id" : 15104467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlintWaterCrisis",
      "indices" : [ 27, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/nhxgLLq2YC",
      "expanded_url" : "https:\/\/twitter.com\/ksecus\/status\/692790082324054017",
      "display_url" : "twitter.com\/ksecus\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693943671876644864",
  "text" : "RT @FogBelter: Absolutely. #FlintWaterCrisis  https:\/\/t.co\/nhxgLLq2YC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FlintWaterCrisis",
        "indices" : [ 12, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/nhxgLLq2YC",
        "expanded_url" : "https:\/\/twitter.com\/ksecus\/status\/692790082324054017",
        "display_url" : "twitter.com\/ksecus\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693942579155456000",
    "text" : "Absolutely. #FlintWaterCrisis  https:\/\/t.co\/nhxgLLq2YC",
    "id" : 693942579155456000,
    "created_at" : "2016-01-31 23:42:58 +0000",
    "user" : {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "protected" : false,
      "id_str" : "15104467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/263286875\/Joshua_A_Norton_normal.jpg",
      "id" : 15104467,
      "verified" : false
    }
  },
  "id" : 693943671876644864,
  "created_at" : "2016-01-31 23:47:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pooks",
      "screen_name" : "zeeemanq",
      "indices" : [ 3, 12 ],
      "id_str" : "3289944587",
      "id" : 3289944587
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zeeemanq\/status\/693042473006940160\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/4HAM5trVjA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ4udQVWQAApTKH.jpg",
      "id_str" : "693042472797224960",
      "id" : 693042472797224960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ4udQVWQAApTKH.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 910,
        "resize" : "fit",
        "w" : 1215
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4HAM5trVjA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693943601949216773",
  "text" : "RT @zeeemanq: I don't know what it is but he sends a x https:\/\/t.co\/4HAM5trVjA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zeeemanq\/status\/693042473006940160\/photo\/1",
        "indices" : [ 41, 64 ],
        "url" : "https:\/\/t.co\/4HAM5trVjA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ4udQVWQAApTKH.jpg",
        "id_str" : "693042472797224960",
        "id" : 693042472797224960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ4udQVWQAApTKH.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 910,
          "resize" : "fit",
          "w" : 1215
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4HAM5trVjA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693042473006940160",
    "text" : "I don't know what it is but he sends a x https:\/\/t.co\/4HAM5trVjA",
    "id" : 693042473006940160,
    "created_at" : "2016-01-29 12:06:16 +0000",
    "user" : {
      "name" : "pooks",
      "screen_name" : "zeeemanq",
      "protected" : false,
      "id_str" : "3289944587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771040360344813568\/6rB2tM0B_normal.jpg",
      "id" : 3289944587,
      "verified" : false
    }
  },
  "id" : 693943601949216773,
  "created_at" : "2016-01-31 23:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mia farrow",
      "screen_name" : "MiaFarrow",
      "indices" : [ 3, 13 ],
      "id_str" : "33235771",
      "id" : 33235771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlintWaterCrisis",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693935051411693573",
  "text" : "RT @MiaFarrow: Some 8000 children under 6 may have suffered irreversible brain damage due to lead poisoning #FlintWaterCrisis https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FlintWaterCrisis",
        "indices" : [ 93, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/4X8k9IazFW",
        "expanded_url" : "http:\/\/mobile.nytimes.com\/2016\/01\/30\/us\/flint-weighs-scope-of-harm-to-children-caused-by-lead-in-water.html?referer=",
        "display_url" : "mobile.nytimes.com\/2016\/01\/30\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693835014820216832",
    "text" : "Some 8000 children under 6 may have suffered irreversible brain damage due to lead poisoning #FlintWaterCrisis https:\/\/t.co\/4X8k9IazFW",
    "id" : 693835014820216832,
    "created_at" : "2016-01-31 16:35:33 +0000",
    "user" : {
      "name" : "mia farrow",
      "screen_name" : "MiaFarrow",
      "protected" : false,
      "id_str" : "33235771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757378355951964160\/DwFS5-fG_normal.jpg",
      "id" : 33235771,
      "verified" : true
    }
  },
  "id" : 693935051411693573,
  "created_at" : "2016-01-31 23:13:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "indices" : [ 3, 11 ],
      "id_str" : "20479813",
      "id" : 20479813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693907753388109824",
  "text" : "RT @MMFlint: They once said it wasn't \"realistic\" to pass an Amendment giving women the vote because only all-male legislators would be vot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693905082031611908",
    "text" : "They once said it wasn't \"realistic\" to pass an Amendment giving women the vote because only all-male legislators would be voting on it.",
    "id" : 693905082031611908,
    "created_at" : "2016-01-31 21:13:58 +0000",
    "user" : {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "protected" : false,
      "id_str" : "20479813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440557378027520000\/DTvD2bbr_normal.jpeg",
      "id" : 20479813,
      "verified" : true
    }
  },
  "id" : 693907753388109824,
  "created_at" : "2016-01-31 21:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elnigma",
      "screen_name" : "galaxiou",
      "indices" : [ 3, 12 ],
      "id_str" : "455972590",
      "id" : 455972590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/1XK2IuuJFa",
      "expanded_url" : "https:\/\/twitter.com\/EmrgencyKittens\/status\/693867643242168320",
      "display_url" : "twitter.com\/EmrgencyKitten\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693878324293140480",
  "text" : "RT @galaxiou: got something in my eyes https:\/\/t.co\/1XK2IuuJFa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/1XK2IuuJFa",
        "expanded_url" : "https:\/\/twitter.com\/EmrgencyKittens\/status\/693867643242168320",
        "display_url" : "twitter.com\/EmrgencyKitten\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693873634247602177",
    "text" : "got something in my eyes https:\/\/t.co\/1XK2IuuJFa",
    "id" : 693873634247602177,
    "created_at" : "2016-01-31 19:09:00 +0000",
    "user" : {
      "name" : "Elnigma",
      "screen_name" : "galaxiou",
      "protected" : false,
      "id_str" : "455972590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1736502695\/categg_edited-1_normal.jpg",
      "id" : 455972590,
      "verified" : false
    }
  },
  "id" : 693878324293140480,
  "created_at" : "2016-01-31 19:27:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders 2K16",
      "screen_name" : "Bernie2K16",
      "indices" : [ 3, 14 ],
      "id_str" : "1378057123",
      "id" : 1378057123
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Bernie2K16\/status\/691444586863030273\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/AdqSZDjOF6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZiBMBzWYAAGKFj.png",
      "id_str" : "691444586443595776",
      "id" : 691444586443595776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZiBMBzWYAAGKFj.png",
      "sizes" : [ {
        "h" : 928,
        "resize" : "fit",
        "w" : 907
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 348,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 928,
        "resize" : "fit",
        "w" : 907
      } ],
      "display_url" : "pic.twitter.com\/AdqSZDjOF6"
    } ],
    "hashtags" : [ {
      "text" : "BernieForIA",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "FeelTheBern",
      "indices" : [ 71, 83 ]
    }, {
      "text" : "WeAreBernie",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693853039921356802",
  "text" : "RT @Bernie2K16: IOWANS: How to caucus for Bernie Sanders! #BernieForIA #FeelTheBern #WeAreBernie https:\/\/t.co\/AdqSZDjOF6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Bernie2K16\/status\/691444586863030273\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/AdqSZDjOF6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZiBMBzWYAAGKFj.png",
        "id_str" : "691444586443595776",
        "id" : 691444586443595776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZiBMBzWYAAGKFj.png",
        "sizes" : [ {
          "h" : 928,
          "resize" : "fit",
          "w" : 907
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 928,
          "resize" : "fit",
          "w" : 907
        } ],
        "display_url" : "pic.twitter.com\/AdqSZDjOF6"
      } ],
      "hashtags" : [ {
        "text" : "BernieForIA",
        "indices" : [ 42, 54 ]
      }, {
        "text" : "FeelTheBern",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "WeAreBernie",
        "indices" : [ 68, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691444586863030273",
    "text" : "IOWANS: How to caucus for Bernie Sanders! #BernieForIA #FeelTheBern #WeAreBernie https:\/\/t.co\/AdqSZDjOF6",
    "id" : 691444586863030273,
    "created_at" : "2016-01-25 02:16:50 +0000",
    "user" : {
      "name" : "Bernie Sanders 2K16",
      "screen_name" : "Bernie2K16",
      "protected" : false,
      "id_str" : "1378057123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697656286238924800\/nQ_ietAd_normal.jpg",
      "id" : 1378057123,
      "verified" : false
    }
  },
  "id" : 693853039921356802,
  "created_at" : "2016-01-31 17:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Lindahl",
      "screen_name" : "Dan_Lindahl",
      "indices" : [ 3, 15 ],
      "id_str" : "1639112484",
      "id" : 1639112484
    }, {
      "name" : "Forbes",
      "screen_name" : "Forbes",
      "indices" : [ 17, 24 ],
      "id_str" : "91478624",
      "id" : 91478624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693818840795463680",
  "text" : "RT @Dan_Lindahl: @Forbes Why is health care always unaffordable. But never war.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Forbes",
        "screen_name" : "Forbes",
        "indices" : [ 0, 7 ],
        "id_str" : "91478624",
        "id" : 91478624
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "693569630057709568",
    "geo" : { },
    "id_str" : "693570847680770049",
    "in_reply_to_user_id" : 91478624,
    "text" : "@Forbes Why is health care always unaffordable. But never war.",
    "id" : 693570847680770049,
    "in_reply_to_status_id" : 693569630057709568,
    "created_at" : "2016-01-30 23:05:50 +0000",
    "in_reply_to_screen_name" : "Forbes",
    "in_reply_to_user_id_str" : "91478624",
    "user" : {
      "name" : "Dan Lindahl",
      "screen_name" : "Dan_Lindahl",
      "protected" : false,
      "id_str" : "1639112484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677260841683554304\/uHcnaADZ_normal.jpg",
      "id" : 1639112484,
      "verified" : false
    }
  },
  "id" : 693818840795463680,
  "created_at" : "2016-01-31 15:31:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wilkie",
      "screen_name" : "wilkieii",
      "indices" : [ 3, 12 ],
      "id_str" : "17047955",
      "id" : 17047955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693584890986643456",
  "text" : "RT @wilkieii: when an enemy ship tells you to power down your shields so you can truly enjoy the photon torpedo experience https:\/\/t.co\/dgr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/wilkieii\/status\/684270238158958593\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/dgrxYbKbl7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX8EJ99UQAIDcCV.png",
        "id_str" : "684270237680680962",
        "id" : 684270237680680962,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX8EJ99UQAIDcCV.png",
        "sizes" : [ {
          "h" : 463,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dgrxYbKbl7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684270238158958593",
    "text" : "when an enemy ship tells you to power down your shields so you can truly enjoy the photon torpedo experience https:\/\/t.co\/dgrxYbKbl7",
    "id" : 684270238158958593,
    "created_at" : "2016-01-05 07:08:32 +0000",
    "user" : {
      "name" : "wilkie",
      "screen_name" : "wilkieii",
      "protected" : false,
      "id_str" : "17047955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719917946781483009\/DyVtEL-R_normal.jpg",
      "id" : 17047955,
      "verified" : false
    }
  },
  "id" : 693584890986643456,
  "created_at" : "2016-01-31 00:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    }, {
      "name" : "Nichole (Nikki)",
      "screen_name" : "SkepticNikki",
      "indices" : [ 11, 24 ],
      "id_str" : "2235067650",
      "id" : 2235067650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693579098455552000",
  "geo" : { },
  "id_str" : "693584817351495682",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time @SkepticNikki i learned abt that few yrs ago or so. was like \"well that makes better sense than being bad\" : )",
  "id" : 693584817351495682,
  "in_reply_to_status_id" : 693579098455552000,
  "created_at" : "2016-01-31 00:01:21 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L\u20E3e\u20E3e\u20E3s\u20E3y\u20E3\u2640",
      "screen_name" : "unrulyscribe",
      "indices" : [ 3, 16 ],
      "id_str" : "120237396",
      "id" : 120237396
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/unrulyscribe\/status\/693580298433466368\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/MNJwNnBIIw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaAXm0jWQAAgr4q.jpg",
      "id_str" : "693580298324426752",
      "id" : 693580298324426752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaAXm0jWQAAgr4q.jpg",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MNJwNnBIIw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693584274797268992",
  "text" : "RT @unrulyscribe: I agree. https:\/\/t.co\/MNJwNnBIIw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/unrulyscribe\/status\/693580298433466368\/photo\/1",
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/MNJwNnBIIw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaAXm0jWQAAgr4q.jpg",
        "id_str" : "693580298324426752",
        "id" : 693580298324426752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaAXm0jWQAAgr4q.jpg",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MNJwNnBIIw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693580298433466368",
    "text" : "I agree. https:\/\/t.co\/MNJwNnBIIw",
    "id" : 693580298433466368,
    "created_at" : "2016-01-30 23:43:23 +0000",
    "user" : {
      "name" : "L\u20E3e\u20E3e\u20E3s\u20E3y\u20E3\u2640",
      "screen_name" : "unrulyscribe",
      "protected" : false,
      "id_str" : "120237396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795419294926409729\/B86zgTeY_normal.jpg",
      "id" : 120237396,
      "verified" : false
    }
  },
  "id" : 693584274797268992,
  "created_at" : "2016-01-30 23:59:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MEGHAN HOOPER",
      "screen_name" : "WAKEUPPEOPL3",
      "indices" : [ 3, 16 ],
      "id_str" : "769258158921437185",
      "id" : 769258158921437185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WAKEUPPEOPL3\/status\/687424079796809728\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/RMDNN7A3vB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYo4iOoWAAEKLpe.jpg",
      "id_str" : "687424053821440001",
      "id" : 687424053821440001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYo4iOoWAAEKLpe.jpg",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/RMDNN7A3vB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693575572404989952",
  "text" : "RT @WAKEUPPEOPL3: https:\/\/t.co\/RMDNN7A3vB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WAKEUPPEOPL3\/status\/687424079796809728\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/RMDNN7A3vB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYo4iOoWAAEKLpe.jpg",
        "id_str" : "687424053821440001",
        "id" : 687424053821440001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYo4iOoWAAEKLpe.jpg",
        "sizes" : [ {
          "h" : 328,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/RMDNN7A3vB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687424079796809728",
    "text" : "https:\/\/t.co\/RMDNN7A3vB",
    "id" : 687424079796809728,
    "created_at" : "2016-01-14 00:00:47 +0000",
    "user" : {
      "name" : "Perspective Thought",
      "screen_name" : "WakeupPeopIe",
      "protected" : false,
      "id_str" : "286742737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785784832454516736\/NtPfGreB_normal.jpg",
      "id" : 286742737,
      "verified" : false
    }
  },
  "id" : 693575572404989952,
  "created_at" : "2016-01-30 23:24:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichole (Nikki)",
      "screen_name" : "SkepticNikki",
      "indices" : [ 0, 13 ],
      "id_str" : "2235067650",
      "id" : 2235067650
    }, {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 14, 24 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ponders",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693564200145256450",
  "geo" : { },
  "id_str" : "693575317521350657",
  "in_reply_to_user_id" : 2235067650,
  "text" : "@SkepticNikki @bend_time my 1st thought is how is that diff from hate the sin, not the sinner. just TOL... #ponders",
  "id" : 693575317521350657,
  "in_reply_to_status_id" : 693564200145256450,
  "created_at" : "2016-01-30 23:23:36 +0000",
  "in_reply_to_screen_name" : "SkepticNikki",
  "in_reply_to_user_id_str" : "2235067650",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693538302654337025",
  "geo" : { },
  "id_str" : "693553403516080128",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep \"fuss about\" .. lol.. i love that.. heehee : )",
  "id" : 693553403516080128,
  "in_reply_to_status_id" : 693538302654337025,
  "created_at" : "2016-01-30 21:56:31 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blu",
      "screen_name" : "TwoSapphiresBlu",
      "indices" : [ 3, 19 ],
      "id_str" : "3352645452",
      "id" : 3352645452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693552971053940737",
  "text" : "RT @TwoSapphiresBlu: All we are doing is riding a giant rock on a trip around the sun while the moon takes a trip around us. So trippy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693494563042783232",
    "text" : "All we are doing is riding a giant rock on a trip around the sun while the moon takes a trip around us. So trippy.",
    "id" : 693494563042783232,
    "created_at" : "2016-01-30 18:02:42 +0000",
    "user" : {
      "name" : "Blu",
      "screen_name" : "TwoSapphiresBlu",
      "protected" : false,
      "id_str" : "3352645452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792909523321102336\/sHmP7Jtg_normal.jpg",
      "id" : 3352645452,
      "verified" : false
    }
  },
  "id" : 693552971053940737,
  "created_at" : "2016-01-30 21:54:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/JjyIlKCqp2",
      "expanded_url" : "https:\/\/twitter.com\/clmazin\/status\/693550082289831936",
      "display_url" : "twitter.com\/clmazin\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693551187954647041",
  "text" : "why would they think this is a good idea??  https:\/\/t.co\/JjyIlKCqp2",
  "id" : 693551187954647041,
  "created_at" : "2016-01-30 21:47:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Patmore \uD83D\uDC9C",
      "screen_name" : "snowangelmrsp",
      "indices" : [ 3, 17 ],
      "id_str" : "53373674",
      "id" : 53373674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/snowangelmrsp\/status\/693487403105980416\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/OFAUvBBWni",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ_DHiaWkAEwSJN.jpg",
      "id_str" : "693487401902182401",
      "id" : 693487401902182401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ_DHiaWkAEwSJN.jpg",
      "sizes" : [ {
        "h" : 320,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 428
      } ],
      "display_url" : "pic.twitter.com\/OFAUvBBWni"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693496341067124736",
  "text" : "RT @snowangelmrsp: No, I'm not looking! https:\/\/t.co\/OFAUvBBWni",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/snowangelmrsp\/status\/693487403105980416\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/OFAUvBBWni",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ_DHiaWkAEwSJN.jpg",
        "id_str" : "693487401902182401",
        "id" : 693487401902182401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ_DHiaWkAEwSJN.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 428
        } ],
        "display_url" : "pic.twitter.com\/OFAUvBBWni"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693487403105980416",
    "text" : "No, I'm not looking! https:\/\/t.co\/OFAUvBBWni",
    "id" : 693487403105980416,
    "created_at" : "2016-01-30 17:34:15 +0000",
    "user" : {
      "name" : "Michelle Patmore \uD83D\uDC9C",
      "screen_name" : "snowangelmrsp",
      "protected" : false,
      "id_str" : "53373674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797846773125574656\/puud4Vsc_normal.jpg",
      "id" : 53373674,
      "verified" : false
    }
  },
  "id" : 693496341067124736,
  "created_at" : "2016-01-30 18:09:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693491612513648640",
  "text" : "RT @benjamincorey: New installment on the hell series: If Hell Is Real, Why Did God Wait So Darn Long To Warn Us About It? https:\/\/t.co\/CWA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/CWAknEcYGq",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/if-hell-is-real-why-did-god-wait-so-darn-long-to-warn-us-about-it\/",
        "display_url" : "patheos.com\/blogs\/formerly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693483239567130626",
    "text" : "New installment on the hell series: If Hell Is Real, Why Did God Wait So Darn Long To Warn Us About It? https:\/\/t.co\/CWAknEcYGq",
    "id" : 693483239567130626,
    "created_at" : "2016-01-30 17:17:43 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 693491612513648640,
  "created_at" : "2016-01-30 17:50:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/syHkmifpIJ",
      "expanded_url" : "https:\/\/youtu.be\/yUmvJ_hvOOY",
      "display_url" : "youtu.be\/yUmvJ_hvOOY"
    } ]
  },
  "geo" : { },
  "id_str" : "693467417893298176",
  "text" : "The Long Way To A Small Angry Planet by Becky Chambers: Audiobook Review https:\/\/t.co\/syHkmifpIJ",
  "id" : 693467417893298176,
  "created_at" : "2016-01-30 16:14:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VisualiZIN",
      "screen_name" : "breathtakingph",
      "indices" : [ 3, 18 ],
      "id_str" : "34915251",
      "id" : 34915251
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/breathtakingph\/status\/693210294928162816\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/BDvFGeK5rr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ7HFwqWYAMkXPg.jpg",
      "id_str" : "693210294437437443",
      "id" : 693210294437437443,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ7HFwqWYAMkXPg.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/BDvFGeK5rr"
    } ],
    "hashtags" : [ {
      "text" : "Estonia",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "sunset",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/ZacCdeuZ1Z",
      "expanded_url" : "http:\/\/bit.ly\/1HU3NH6",
      "display_url" : "bit.ly\/1HU3NH6"
    } ]
  },
  "geo" : { },
  "id_str" : "693218089303969792",
  "text" : "RT @breathtakingph: Sunset in #Estonia https:\/\/t.co\/ZacCdeuZ1Z #sunset https:\/\/t.co\/BDvFGeK5rr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/breathtakingph\/status\/693210294928162816\/photo\/1",
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/BDvFGeK5rr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ7HFwqWYAMkXPg.jpg",
        "id_str" : "693210294437437443",
        "id" : 693210294437437443,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ7HFwqWYAMkXPg.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/BDvFGeK5rr"
      } ],
      "hashtags" : [ {
        "text" : "Estonia",
        "indices" : [ 10, 18 ]
      }, {
        "text" : "sunset",
        "indices" : [ 43, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/ZacCdeuZ1Z",
        "expanded_url" : "http:\/\/bit.ly\/1HU3NH6",
        "display_url" : "bit.ly\/1HU3NH6"
      } ]
    },
    "geo" : { },
    "id_str" : "693210294928162816",
    "text" : "Sunset in #Estonia https:\/\/t.co\/ZacCdeuZ1Z #sunset https:\/\/t.co\/BDvFGeK5rr",
    "id" : 693210294928162816,
    "created_at" : "2016-01-29 23:13:08 +0000",
    "user" : {
      "name" : "VisualiZIN",
      "screen_name" : "breathtakingph",
      "protected" : false,
      "id_str" : "34915251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459040346723196928\/iii6M9UG_normal.jpeg",
      "id" : 34915251,
      "verified" : false
    }
  },
  "id" : 693218089303969792,
  "created_at" : "2016-01-29 23:44:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693162699425853440",
  "geo" : { },
  "id_str" : "693170238997819392",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater not a good angle to tell but it looks nice? lol",
  "id" : 693170238997819392,
  "in_reply_to_status_id" : 693162699425853440,
  "created_at" : "2016-01-29 20:33:58 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/jYt4c20Yx5",
      "expanded_url" : "https:\/\/twitter.com\/Richard_Kadrey\/status\/693165153999654912",
      "display_url" : "twitter.com\/Richard_Kadrey\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693168689475108864",
  "text" : "LOL https:\/\/t.co\/jYt4c20Yx5",
  "id" : 693168689475108864,
  "created_at" : "2016-01-29 20:27:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "feedly",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/zc1LWZwQWV",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/a27926ca34aa7c\/49425?app_id=339",
      "display_url" : "producthunt.com\/r\/a27926ca34aa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "693129752639606784",
  "text" : "Podcast Profile \u2014 Show everybody which podcasts you listen to https:\/\/t.co\/zc1LWZwQWV #tech #feedly",
  "id" : 693129752639606784,
  "created_at" : "2016-01-29 17:53:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "indices" : [ 3, 18 ],
      "id_str" : "148856572",
      "id" : 148856572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Y6uWVSLtYS",
      "expanded_url" : "http:\/\/fb.me\/7FIKtVUQP",
      "display_url" : "fb.me\/7FIKtVUQP"
    } ]
  },
  "geo" : { },
  "id_str" : "693090425972850690",
  "text" : "RT @Audiobook_Comm: Check out Goodreads Audiobook Group! https:\/\/t.co\/Y6uWVSLtYS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/Y6uWVSLtYS",
        "expanded_url" : "http:\/\/fb.me\/7FIKtVUQP",
        "display_url" : "fb.me\/7FIKtVUQP"
      } ]
    },
    "geo" : { },
    "id_str" : "693058056603611136",
    "text" : "Check out Goodreads Audiobook Group! https:\/\/t.co\/Y6uWVSLtYS",
    "id" : 693058056603611136,
    "created_at" : "2016-01-29 13:08:11 +0000",
    "user" : {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "protected" : false,
      "id_str" : "148856572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716970602259738624\/qDTP4Z12_normal.jpg",
      "id" : 148856572,
      "verified" : false
    }
  },
  "id" : 693090425972850690,
  "created_at" : "2016-01-29 15:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "indices" : [ 3, 18 ],
      "id_str" : "32522055",
      "id" : 32522055
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Kris_Sacrebleu\/status\/692903529615269888\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/spC7p7dZWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ2wFkJUEAA275R.jpg",
      "id_str" : "692903527333498880",
      "id" : 692903527333498880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ2wFkJUEAA275R.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/spC7p7dZWP"
    } ],
    "hashtags" : [ {
      "text" : "GOPDebate",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693088151355723776",
  "text" : "RT @Kris_Sacrebleu: GOP Party Platform: \n\n1. Fear\n\n#GOPDebate https:\/\/t.co\/spC7p7dZWP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kris_Sacrebleu\/status\/692903529615269888\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/spC7p7dZWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ2wFkJUEAA275R.jpg",
        "id_str" : "692903527333498880",
        "id" : 692903527333498880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ2wFkJUEAA275R.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/spC7p7dZWP"
      } ],
      "hashtags" : [ {
        "text" : "GOPDebate",
        "indices" : [ 31, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692903529615269888",
    "text" : "GOP Party Platform: \n\n1. Fear\n\n#GOPDebate https:\/\/t.co\/spC7p7dZWP",
    "id" : 692903529615269888,
    "created_at" : "2016-01-29 02:54:09 +0000",
    "user" : {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "protected" : false,
      "id_str" : "32522055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797097618245459968\/x-mwuPEt_normal.jpg",
      "id" : 32522055,
      "verified" : false
    }
  },
  "id" : 693088151355723776,
  "created_at" : "2016-01-29 15:07:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "indices" : [ 3, 15 ],
      "id_str" : "954590804",
      "id" : 954590804
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/692923422159011840\/photo\/1",
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/V7NIZwgUWJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ3CLloWEAYTLQI.jpg",
      "id_str" : "692923422020603910",
      "id" : 692923422020603910,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ3CLloWEAYTLQI.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/V7NIZwgUWJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693083763245449217",
  "text" : "RT @planetepics: The Buff-tip moth has brilliant camouflage. https:\/\/t.co\/V7NIZwgUWJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/692923422159011840\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/V7NIZwgUWJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ3CLloWEAYTLQI.jpg",
        "id_str" : "692923422020603910",
        "id" : 692923422020603910,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ3CLloWEAYTLQI.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/V7NIZwgUWJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692923422159011840",
    "text" : "The Buff-tip moth has brilliant camouflage. https:\/\/t.co\/V7NIZwgUWJ",
    "id" : 692923422159011840,
    "created_at" : "2016-01-29 04:13:12 +0000",
    "user" : {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "protected" : false,
      "id_str" : "954590804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463495027600015360\/_Jyj6WD6_normal.jpeg",
      "id" : 954590804,
      "verified" : false
    }
  },
  "id" : 693083763245449217,
  "created_at" : "2016-01-29 14:50:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy Paws",
      "screen_name" : "ChristyPawsChat",
      "indices" : [ 3, 19 ],
      "id_str" : "2832610690",
      "id" : 2832610690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692890112166723588",
  "text" : "RT @ChristyPawsChat: Have you heard of whisker fatigue? I tell you about it and review Dr. Catsby's bowl on the blog\u2026 https:\/\/t.co\/GIzqGn3C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/GIzqGn3CiX",
        "expanded_url" : "https:\/\/www.instagram.com\/p\/BBGqzqOCt0r\/",
        "display_url" : "instagram.com\/p\/BBGqzqOCt0r\/"
      } ]
    },
    "geo" : { },
    "id_str" : "692879119881613312",
    "text" : "Have you heard of whisker fatigue? I tell you about it and review Dr. Catsby's bowl on the blog\u2026 https:\/\/t.co\/GIzqGn3CiX",
    "id" : 692879119881613312,
    "created_at" : "2016-01-29 01:17:09 +0000",
    "user" : {
      "name" : "Christy Paws",
      "screen_name" : "ChristyPawsChat",
      "protected" : false,
      "id_str" : "2832610690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608386367442329600\/i0utxE2t_normal.png",
      "id" : 2832610690,
      "verified" : false
    }
  },
  "id" : 692890112166723588,
  "created_at" : "2016-01-29 02:00:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Night Sky",
      "screen_name" : "TheNlGHTSky",
      "indices" : [ 3, 15 ],
      "id_str" : "3501184273",
      "id" : 3501184273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692866011003879424",
  "text" : "RT @TheNlGHTSky: The Eridanus Void. This area shows almost no signs of cosmic matter, meaning no stars, planets, or solar systems https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheNlGHTSky\/status\/692840426508685314\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/DqEC29M70n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ12skJUEAAmbs7.jpg",
        "id_str" : "692840425673986048",
        "id" : 692840425673986048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ12skJUEAAmbs7.jpg",
        "sizes" : [ {
          "h" : 276,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/DqEC29M70n"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692840426508685314",
    "text" : "The Eridanus Void. This area shows almost no signs of cosmic matter, meaning no stars, planets, or solar systems https:\/\/t.co\/DqEC29M70n",
    "id" : 692840426508685314,
    "created_at" : "2016-01-28 22:43:24 +0000",
    "user" : {
      "name" : "The Night Sky",
      "screen_name" : "TheNlGHTSky",
      "protected" : false,
      "id_str" : "3501184273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641492825058578432\/BTFaVRhp_normal.jpg",
      "id" : 3501184273,
      "verified" : false
    }
  },
  "id" : 692866011003879424,
  "created_at" : "2016-01-29 00:25:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 0, 15 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692856905480310784",
  "geo" : { },
  "id_str" : "692858333921878017",
  "in_reply_to_user_id" : 62867227,
  "text" : "@thesexyatheist my condolences.. what a beautiful baby. ((hugs))",
  "id" : 692858333921878017,
  "in_reply_to_status_id" : 692856905480310784,
  "created_at" : "2016-01-28 23:54:34 +0000",
  "in_reply_to_screen_name" : "thesexyatheist",
  "in_reply_to_user_id_str" : "62867227",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692853027108048897",
  "text" : "RT @johnpavlovitz: Doing the best with what I've got.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692846027850711041",
    "text" : "Doing the best with what I've got.",
    "id" : 692846027850711041,
    "created_at" : "2016-01-28 23:05:40 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 692853027108048897,
  "created_at" : "2016-01-28 23:33:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Kevin Lee",
      "screen_name" : "dr_kevinlee",
      "indices" : [ 3, 15 ],
      "id_str" : "2168242034",
      "id" : 2168242034
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hypothyroid",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692851631247880195",
  "text" : "RT @dr_kevinlee: This questionnaire may be a better way to rate #hypothyroid symptoms than trying to explain to others your symptoms https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dr_kevinlee\/status\/692582656102432769\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/glRc3n3iBQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZyMQTdUYAEdsjh.png",
        "id_str" : "692582654437253121",
        "id" : 692582654437253121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZyMQTdUYAEdsjh.png",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 615
        } ],
        "display_url" : "pic.twitter.com\/glRc3n3iBQ"
      } ],
      "hashtags" : [ {
        "text" : "hypothyroid",
        "indices" : [ 47, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692582656102432769",
    "text" : "This questionnaire may be a better way to rate #hypothyroid symptoms than trying to explain to others your symptoms https:\/\/t.co\/glRc3n3iBQ",
    "id" : 692582656102432769,
    "created_at" : "2016-01-28 05:39:07 +0000",
    "user" : {
      "name" : "Dr Kevin Lee",
      "screen_name" : "dr_kevinlee",
      "protected" : false,
      "id_str" : "2168242034",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800663818263138305\/-u_vHD6u_normal.jpg",
      "id" : 2168242034,
      "verified" : false
    }
  },
  "id" : 692851631247880195,
  "created_at" : "2016-01-28 23:27:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "692810936344821760",
  "geo" : { },
  "id_str" : "692832029470134272",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl glad he's going home. ((hugs))",
  "id" : 692832029470134272,
  "in_reply_to_status_id" : 692810936344821760,
  "created_at" : "2016-01-28 22:10:02 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/cVMIWuDf4M",
      "expanded_url" : "http:\/\/www.vulture.com\/2016\/01\/neil-degrasse-tyson-bob-mic-drop.html",
      "display_url" : "vulture.com\/2016\/01\/neil-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692729673671909381",
  "text" : "Neil deGrasse Tyson Drops the Mic Flat on B.o.B https:\/\/t.co\/cVMIWuDf4M",
  "id" : 692729673671909381,
  "created_at" : "2016-01-28 15:23:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "aliens",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/PXbl5o8Mme",
      "expanded_url" : "https:\/\/twitter.com\/adamrshields\/status\/692346790880743424",
      "display_url" : "twitter.com\/adamrshields\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692517595539439616",
  "text" : "this sounds interesting! usually dont think of aliens and historical fiction. #books #aliens https:\/\/t.co\/PXbl5o8Mme",
  "id" : 692517595539439616,
  "created_at" : "2016-01-28 01:20:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/hylHwaaPje",
      "expanded_url" : "https:\/\/twitter.com\/deaninserra\/status\/692094508759158786",
      "display_url" : "twitter.com\/deaninserra\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692463838470541313",
  "text" : "only love your neighbors if they're like you.. o-O https:\/\/t.co\/hylHwaaPje",
  "id" : 692463838470541313,
  "created_at" : "2016-01-27 21:46:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Akin",
      "screen_name" : "DannyAkin",
      "indices" : [ 3, 13 ],
      "id_str" : "32411991",
      "id" : 32411991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692462725168025601",
  "text" : "RT @DannyAkin: Quite simply this is an embarrassment to the gospel and the one who told us to love our neighbor and our enemies.  https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/vExlBjdyAD",
        "expanded_url" : "https:\/\/twitter.com\/deaninserra\/status\/692094508759158786",
        "display_url" : "twitter.com\/deaninserra\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692185499331608576",
    "text" : "Quite simply this is an embarrassment to the gospel and the one who told us to love our neighbor and our enemies.  https:\/\/t.co\/vExlBjdyAD",
    "id" : 692185499331608576,
    "created_at" : "2016-01-27 03:20:57 +0000",
    "user" : {
      "name" : "Daniel Akin",
      "screen_name" : "DannyAkin",
      "protected" : false,
      "id_str" : "32411991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526739222284103681\/5zANVA9-_normal.jpeg",
      "id" : 32411991,
      "verified" : false
    }
  },
  "id" : 692462725168025601,
  "created_at" : "2016-01-27 21:42:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paige",
      "screen_name" : "PeachCoffin",
      "indices" : [ 3, 15 ],
      "id_str" : "261061836",
      "id" : 261061836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692444660665577475",
  "text" : "RT @PeachCoffin: I want  to see a followup commercial where the wife goes back to bed and the husband has crazy deviant phone sex with Jake\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690949915028144128",
    "text" : "I want  to see a followup commercial where the wife goes back to bed and the husband has crazy deviant phone sex with Jake from State Farm",
    "id" : 690949915028144128,
    "created_at" : "2016-01-23 17:31:11 +0000",
    "user" : {
      "name" : "Paige",
      "screen_name" : "PeachCoffin",
      "protected" : false,
      "id_str" : "261061836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760566873763221504\/vJsuzrVr_normal.jpg",
      "id" : 261061836,
      "verified" : false
    }
  },
  "id" : 692444660665577475,
  "created_at" : "2016-01-27 20:30:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie Curtis",
      "screen_name" : "jcurtisart",
      "indices" : [ 3, 14 ],
      "id_str" : "77010084",
      "id" : 77010084
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jcurtisart\/status\/691351008480477184\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/cvTvjUzLI3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZgsFA5WQAEknGI.jpg",
      "id_str" : "691351007452872705",
      "id" : 691351007452872705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZgsFA5WQAEknGI.jpg",
      "sizes" : [ {
        "h" : 422,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 824,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cvTvjUzLI3"
    } ],
    "hashtags" : [ {
      "text" : "Starlings",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "Murmuration",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692443543349104640",
  "text" : "RT @jcurtisart: And they danced some more - Just magical\n#Starlings #Murmuration\nShapwick Heath https:\/\/t.co\/cvTvjUzLI3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jcurtisart\/status\/691351008480477184\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/cvTvjUzLI3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZgsFA5WQAEknGI.jpg",
        "id_str" : "691351007452872705",
        "id" : 691351007452872705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZgsFA5WQAEknGI.jpg",
        "sizes" : [ {
          "h" : 422,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 824,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 140,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/cvTvjUzLI3"
      } ],
      "hashtags" : [ {
        "text" : "Starlings",
        "indices" : [ 41, 51 ]
      }, {
        "text" : "Murmuration",
        "indices" : [ 52, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691351008480477184",
    "text" : "And they danced some more - Just magical\n#Starlings #Murmuration\nShapwick Heath https:\/\/t.co\/cvTvjUzLI3",
    "id" : 691351008480477184,
    "created_at" : "2016-01-24 20:04:59 +0000",
    "user" : {
      "name" : "Jackie Curtis",
      "screen_name" : "jcurtisart",
      "protected" : false,
      "id_str" : "77010084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715081596\/twitter_normal.jpg",
      "id" : 77010084,
      "verified" : false
    }
  },
  "id" : 692443543349104640,
  "created_at" : "2016-01-27 20:26:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692438953878802433",
  "text" : "RT @RustBeltRebel: what are the assumed qualities of pussy? what makes pussy such that they want to bang it but not BE it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "692438386141990912",
    "geo" : { },
    "id_str" : "692438525271240704",
    "in_reply_to_user_id" : 2382724914,
    "text" : "what are the assumed qualities of pussy? what makes pussy such that they want to bang it but not BE it.",
    "id" : 692438525271240704,
    "in_reply_to_status_id" : 692438386141990912,
    "created_at" : "2016-01-27 20:06:23 +0000",
    "in_reply_to_screen_name" : "RustBeltRebel",
    "in_reply_to_user_id_str" : "2382724914",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 692438953878802433,
  "created_at" : "2016-01-27 20:08:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.snipandshare.com\" rel=\"nofollow\"\u003ESnip and Share\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/692399370701033472\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Q2vohxt7GQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZvljoXWYAAZf2q.jpg",
      "id_str" : "692399368025038848",
      "id" : 692399368025038848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZvljoXWYAAZf2q.jpg",
      "sizes" : [ {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/Q2vohxt7GQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/bOIPsU0Ojk",
      "expanded_url" : "http:\/\/www.godofevolution.com\/former-aig-volunteer-yec-apologetics-were-like-a-drug-that-fed-my-addiction?_ts=1453915843",
      "display_url" : "godofevolution.com\/former-aig-vol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692399370701033472",
  "text" : "Former AiG volunteer: YEC apologetics \u2018were like a drug that fed my addiction\u2019 https:\/\/t.co\/bOIPsU0Ojk https:\/\/t.co\/Q2vohxt7GQ",
  "id" : 692399370701033472,
  "created_at" : "2016-01-27 17:30:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God of Evolution",
      "screen_name" : "godofevolution",
      "indices" : [ 3, 18 ],
      "id_str" : "1220319096",
      "id" : 1220319096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/uVnOraKcN0",
      "expanded_url" : "http:\/\/www.godofevolution.com\/former-aig-volunteer-yec-apologetics-were-like-a-drug-that-fed-my-addiction\/",
      "display_url" : "godofevolution.com\/former-aig-vol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692399080304173056",
  "text" : "RT @godofevolution: Former AiG volunteer: YEC apologetics \u2018were like a drug that fed my addiction\u2019 https:\/\/t.co\/uVnOraKcN0 https:\/\/t.co\/Auu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/godofevolution\/status\/692106834656825344\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/AuupKhe8QD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZrbf6QVIAAlWOQ.jpg",
        "id_str" : "692106834014969856",
        "id" : 692106834014969856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZrbf6QVIAAlWOQ.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/AuupKhe8QD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/uVnOraKcN0",
        "expanded_url" : "http:\/\/www.godofevolution.com\/former-aig-volunteer-yec-apologetics-were-like-a-drug-that-fed-my-addiction\/",
        "display_url" : "godofevolution.com\/former-aig-vol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692106834656825344",
    "text" : "Former AiG volunteer: YEC apologetics \u2018were like a drug that fed my addiction\u2019 https:\/\/t.co\/uVnOraKcN0 https:\/\/t.co\/AuupKhe8QD",
    "id" : 692106834656825344,
    "created_at" : "2016-01-26 22:08:22 +0000",
    "user" : {
      "name" : "God of Evolution",
      "screen_name" : "godofevolution",
      "protected" : false,
      "id_str" : "1220319096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674299817472819200\/uHcXuV0d_normal.png",
      "id" : 1220319096,
      "verified" : false
    }
  },
  "id" : 692399080304173056,
  "created_at" : "2016-01-27 17:29:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitten",
      "screen_name" : "42Lives",
      "indices" : [ 3, 11 ],
      "id_str" : "1114886305",
      "id" : 1114886305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/R68YQPbf5P",
      "expanded_url" : "https:\/\/twitter.com\/PPFA\/status\/692026703024132096",
      "display_url" : "twitter.com\/PPFA\/status\/69\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692394984494989312",
  "text" : "RT @42Lives: Bravo Planned Parenthood! ---for giving free water filters to Flint residents. Beautiful! https:\/\/t.co\/R68YQPbf5P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/R68YQPbf5P",
        "expanded_url" : "https:\/\/twitter.com\/PPFA\/status\/692026703024132096",
        "display_url" : "twitter.com\/PPFA\/status\/69\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692385584841650176",
    "text" : "Bravo Planned Parenthood! ---for giving free water filters to Flint residents. Beautiful! https:\/\/t.co\/R68YQPbf5P",
    "id" : 692385584841650176,
    "created_at" : "2016-01-27 16:36:01 +0000",
    "user" : {
      "name" : "Kitten",
      "screen_name" : "42Lives",
      "protected" : false,
      "id_str" : "1114886305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529882176829939712\/9fiet3NA_normal.jpeg",
      "id" : 1114886305,
      "verified" : false
    }
  },
  "id" : 692394984494989312,
  "created_at" : "2016-01-27 17:13:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SSG",
      "screen_name" : "SSGsires",
      "indices" : [ 3, 12 ],
      "id_str" : "3017815991",
      "id" : 3017815991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BellLetsTalk",
      "indices" : [ 85, 98 ]
    }, {
      "text" : "MentalHealthMatters",
      "indices" : [ 99, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692394734325735424",
  "text" : "RT @SSGsires: 'We lose ourselves in the things we love, we find ourselves there too' #BellLetsTalk #MentalHealthMatters https:\/\/t.co\/QQ1c2p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SSGsires\/status\/692336867878924288\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/QQ1c2pceR4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZustlrWQAE0r6I.jpg",
        "id_str" : "692336866939518977",
        "id" : 692336866939518977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZustlrWQAE0r6I.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 414
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 414
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 414
        } ],
        "display_url" : "pic.twitter.com\/QQ1c2pceR4"
      } ],
      "hashtags" : [ {
        "text" : "BellLetsTalk",
        "indices" : [ 71, 84 ]
      }, {
        "text" : "MentalHealthMatters",
        "indices" : [ 85, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692336867878924288",
    "text" : "'We lose ourselves in the things we love, we find ourselves there too' #BellLetsTalk #MentalHealthMatters https:\/\/t.co\/QQ1c2pceR4",
    "id" : 692336867878924288,
    "created_at" : "2016-01-27 13:22:26 +0000",
    "user" : {
      "name" : "SSG",
      "screen_name" : "SSGsires",
      "protected" : false,
      "id_str" : "3017815991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562992966818463744\/ahRYbgL1_normal.jpeg",
      "id" : 3017815991,
      "verified" : false
    }
  },
  "id" : 692394734325735424,
  "created_at" : "2016-01-27 17:12:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Deitz",
      "screen_name" : "JessDeitz",
      "indices" : [ 3, 13 ],
      "id_str" : "2743179005",
      "id" : 2743179005
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MilkyWay",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "Universe",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692206028201541632",
  "text" : "RT @JessDeitz: Just finished watching 3 hours of documentaries on the #MilkyWay and our #Universe..AMAZING! Everything is connected, anythi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MilkyWay",
        "indices" : [ 55, 64 ]
      }, {
        "text" : "Universe",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692200517871767553",
    "text" : "Just finished watching 3 hours of documentaries on the #MilkyWay and our #Universe..AMAZING! Everything is connected, anything is possible.",
    "id" : 692200517871767553,
    "created_at" : "2016-01-27 04:20:38 +0000",
    "user" : {
      "name" : "Jess Deitz",
      "screen_name" : "JessDeitz",
      "protected" : false,
      "id_str" : "2743179005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799684589912518656\/wvxM5XiO_normal.jpg",
      "id" : 2743179005,
      "verified" : false
    }
  },
  "id" : 692206028201541632,
  "created_at" : "2016-01-27 04:42:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 3, 17 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/fvC8nnqR6F",
      "expanded_url" : "http:\/\/fb.me\/3Ui4iOowh",
      "display_url" : "fb.me\/3Ui4iOowh"
    } ]
  },
  "geo" : { },
  "id_str" : "692143490558496769",
  "text" : "RT @UnfundieXians: From Mesopotamia to King James on one handy flowchart.\n\n- Lapham's Quarterly https:\/\/t.co\/fvC8nnqR6F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/fvC8nnqR6F",
        "expanded_url" : "http:\/\/fb.me\/3Ui4iOowh",
        "display_url" : "fb.me\/3Ui4iOowh"
      } ]
    },
    "geo" : { },
    "id_str" : "692139146169679873",
    "text" : "From Mesopotamia to King James on one handy flowchart.\n\n- Lapham's Quarterly https:\/\/t.co\/fvC8nnqR6F",
    "id" : 692139146169679873,
    "created_at" : "2016-01-27 00:16:46 +0000",
    "user" : {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "protected" : false,
      "id_str" : "780850862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000612253854\/d369ca7c4cc3d27a5fe05ca11521b685_normal.jpeg",
      "id" : 780850862,
      "verified" : false
    }
  },
  "id" : 692143490558496769,
  "created_at" : "2016-01-27 00:34:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "indices" : [ 3, 17 ],
      "id_str" : "751200954",
      "id" : 751200954
    }, {
      "name" : "SJ Drummond",
      "screen_name" : "S_JDrummond",
      "indices" : [ 47, 59 ],
      "id_str" : "222539778",
      "id" : 222539778
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 60, 72 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/692110460099887104\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/xoSgw2Wkb9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZrey9uWcAAiBM_.jpg",
      "id_str" : "692110459898589184",
      "id" : 692110459898589184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZrey9uWcAAiBM_.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 3120,
        "resize" : "fit",
        "w" : 3120
      } ],
      "display_url" : "pic.twitter.com\/xoSgw2Wkb9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692121022015881217",
  "text" : "RT @fionagraham13: Miss Fergie on laundry duty @S_JDrummond @ErinEFarley https:\/\/t.co\/xoSgw2Wkb9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SJ Drummond",
        "screen_name" : "S_JDrummond",
        "indices" : [ 28, 40 ],
        "id_str" : "222539778",
        "id" : 222539778
      }, {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 41, 53 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fionagraham13\/status\/692110460099887104\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/xoSgw2Wkb9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZrey9uWcAAiBM_.jpg",
        "id_str" : "692110459898589184",
        "id" : 692110459898589184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZrey9uWcAAiBM_.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 3120,
          "resize" : "fit",
          "w" : 3120
        } ],
        "display_url" : "pic.twitter.com\/xoSgw2Wkb9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692110460099887104",
    "text" : "Miss Fergie on laundry duty @S_JDrummond @ErinEFarley https:\/\/t.co\/xoSgw2Wkb9",
    "id" : 692110460099887104,
    "created_at" : "2016-01-26 22:22:47 +0000",
    "user" : {
      "name" : "Fiona Graham",
      "screen_name" : "fionagraham13",
      "protected" : false,
      "id_str" : "751200954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775421774179819520\/KBk03QHm_normal.jpg",
      "id" : 751200954,
      "verified" : false
    }
  },
  "id" : 692121022015881217,
  "created_at" : "2016-01-26 23:04:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John C. Parkin",
      "screen_name" : "thefuckitlife",
      "indices" : [ 3, 17 ],
      "id_str" : "35800962",
      "id" : 35800962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fkittherapy",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692120968202981376",
  "text" : "RT @thefuckitlife: F**k It, we need to chill, because there's F**k all we can do about this. Don't sweat the small stuff. #fkittherapy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fkittherapy",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692107750487117824",
    "text" : "F**k It, we need to chill, because there's F**k all we can do about this. Don't sweat the small stuff. #fkittherapy",
    "id" : 692107750487117824,
    "created_at" : "2016-01-26 22:12:01 +0000",
    "user" : {
      "name" : "John C. Parkin",
      "screen_name" : "thefuckitlife",
      "protected" : false,
      "id_str" : "35800962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670129824124522496\/m2DP-ypQ_normal.jpg",
      "id" : 35800962,
      "verified" : false
    }
  },
  "id" : 692120968202981376,
  "created_at" : "2016-01-26 23:04:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/OGvtjq7JRs",
      "expanded_url" : "https:\/\/twitter.com\/OutsmartDisease\/status\/692118705078210560",
      "display_url" : "twitter.com\/OutsmartDiseas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692120789454344193",
  "text" : "yup. DDs numbers improved but still feels like crap. been tested for so much.. everything neg or norm. gah. https:\/\/t.co\/OGvtjq7JRs",
  "id" : 692120789454344193,
  "created_at" : "2016-01-26 23:03:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horse Collab",
      "screen_name" : "HorseCollab",
      "indices" : [ 3, 15 ],
      "id_str" : "715179721470910464",
      "id" : 715179721470910464
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HorseCollab\/status\/692103944705839104\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/PFu4k6jZY8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZrY3r0UAAAPL_G.jpg",
      "id_str" : "692103943921336320",
      "id" : 692103943921336320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZrY3r0UAAAPL_G.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1650,
        "resize" : "fit",
        "w" : 1650
      } ],
      "display_url" : "pic.twitter.com\/PFu4k6jZY8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692119966464737288",
  "text" : "RT @HorseCollab: This life we lead... https:\/\/t.co\/PFu4k6jZY8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HorseCollab\/status\/692103944705839104\/photo\/1",
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/PFu4k6jZY8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZrY3r0UAAAPL_G.jpg",
        "id_str" : "692103943921336320",
        "id" : 692103943921336320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZrY3r0UAAAPL_G.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1650,
          "resize" : "fit",
          "w" : 1650
        } ],
        "display_url" : "pic.twitter.com\/PFu4k6jZY8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692103944705839104",
    "text" : "This life we lead... https:\/\/t.co\/PFu4k6jZY8",
    "id" : 692103944705839104,
    "created_at" : "2016-01-26 21:56:53 +0000",
    "user" : {
      "name" : "Horse Network",
      "screen_name" : "HorseNetwrk",
      "protected" : false,
      "id_str" : "303937344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715161596520214532\/oiCgfeCN_normal.jpg",
      "id" : 303937344,
      "verified" : false
    }
  },
  "id" : 692119966464737288,
  "created_at" : "2016-01-26 23:00:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692086736965517312",
  "text" : "my spiritual view is God (original cause) is Love. Love wins! the end. (well, not the end as there's continual evolution).",
  "id" : 692086736965517312,
  "created_at" : "2016-01-26 20:48:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Val Dottycookie",
      "screen_name" : "dottycookie",
      "indices" : [ 3, 15 ],
      "id_str" : "351042631",
      "id" : 351042631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makingwinter",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692085652263952384",
  "text" : "RT @dottycookie: I made a willow sheep a couple of weeks back. He's gone to live with some friends in the next village #makingwinter https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dottycookie\/status\/692082574714368000\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/7zI49KXXdM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZrFb0fWAAELqKe.jpg",
        "id_str" : "692082574492041217",
        "id" : 692082574492041217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZrFb0fWAAELqKe.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7zI49KXXdM"
      } ],
      "hashtags" : [ {
        "text" : "makingwinter",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692082574714368000",
    "text" : "I made a willow sheep a couple of weeks back. He's gone to live with some friends in the next village #makingwinter https:\/\/t.co\/7zI49KXXdM",
    "id" : 692082574714368000,
    "created_at" : "2016-01-26 20:31:58 +0000",
    "user" : {
      "name" : "Val Dottycookie",
      "screen_name" : "dottycookie",
      "protected" : false,
      "id_str" : "351042631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488013587349139457\/hIc6VwZm_normal.jpeg",
      "id" : 351042631,
      "verified" : false
    }
  },
  "id" : 692085652263952384,
  "created_at" : "2016-01-26 20:44:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692085448840212480",
  "text" : "apparently new show \"Lucifer\" is evil and you should not watch, else thou may end up in Hell. consider me lost then. i may or not watch.",
  "id" : 692085448840212480,
  "created_at" : "2016-01-26 20:43:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Schneider",
      "screen_name" : "franklinavenue",
      "indices" : [ 3, 18 ],
      "id_str" : "15423869",
      "id" : 15423869
    }, {
      "name" : "TV Guide Magazine",
      "screen_name" : "TVGuideMagazine",
      "indices" : [ 70, 86 ],
      "id_str" : "17783278",
      "id" : 17783278
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/franklinavenue\/status\/692065026530762752\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/EKyITKLEwH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZq1eW1WEAAf9ah.jpg",
      "id_str" : "692065025884819456",
      "id" : 692065025884819456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZq1eW1WEAAf9ah.jpg",
      "sizes" : [ {
        "h" : 620,
        "resize" : "fit",
        "w" : 423
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 498,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 423
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 423
      } ],
      "display_url" : "pic.twitter.com\/EKyITKLEwH"
    } ],
    "hashtags" : [ {
      "text" : "BarneyMiller",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692081184982065156",
  "text" : "RT @franklinavenue: R.I.P., Abe Vigoda. On the July 19, 1975 cover of @TVGuideMagazine with the #BarneyMiller cast: https:\/\/t.co\/EKyITKLEwH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TV Guide Magazine",
        "screen_name" : "TVGuideMagazine",
        "indices" : [ 50, 66 ],
        "id_str" : "17783278",
        "id" : 17783278
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/franklinavenue\/status\/692065026530762752\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/EKyITKLEwH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZq1eW1WEAAf9ah.jpg",
        "id_str" : "692065025884819456",
        "id" : 692065025884819456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZq1eW1WEAAf9ah.jpg",
        "sizes" : [ {
          "h" : 620,
          "resize" : "fit",
          "w" : 423
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 423
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 423
        } ],
        "display_url" : "pic.twitter.com\/EKyITKLEwH"
      } ],
      "hashtags" : [ {
        "text" : "BarneyMiller",
        "indices" : [ 76, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692065026530762752",
    "text" : "R.I.P., Abe Vigoda. On the July 19, 1975 cover of @TVGuideMagazine with the #BarneyMiller cast: https:\/\/t.co\/EKyITKLEwH",
    "id" : 692065026530762752,
    "created_at" : "2016-01-26 19:22:14 +0000",
    "user" : {
      "name" : "Michael Schneider",
      "screen_name" : "franklinavenue",
      "protected" : false,
      "id_str" : "15423869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473934807374639104\/4M-mQEkB_normal.jpeg",
      "id" : 15423869,
      "verified" : true
    }
  },
  "id" : 692081184982065156,
  "created_at" : "2016-01-26 20:26:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/I6dtJK7IjT",
      "expanded_url" : "http:\/\/forher.aleteia.org\/articles\/body-positive\/",
      "display_url" : "forher.aleteia.org\/articles\/body-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692040275053645825",
  "text" : "RT @jorymicah: \"I\u2019ll never forget the moment I realized I was fat.\" Freeing post called \"Body, Positive\" https:\/\/t.co\/I6dtJK7IjT\n\nGreat fin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Bessey",
        "screen_name" : "sarahbessey",
        "indices" : [ 126, 138 ],
        "id_str" : "9535262",
        "id" : 9535262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/I6dtJK7IjT",
        "expanded_url" : "http:\/\/forher.aleteia.org\/articles\/body-positive\/",
        "display_url" : "forher.aleteia.org\/articles\/body-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "692035870493446144",
    "text" : "\"I\u2019ll never forget the moment I realized I was fat.\" Freeing post called \"Body, Positive\" https:\/\/t.co\/I6dtJK7IjT\n\nGreat find @sarahbessey!",
    "id" : 692035870493446144,
    "created_at" : "2016-01-26 17:26:23 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 692040275053645825,
  "created_at" : "2016-01-26 17:43:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "indices" : [ 3, 15 ],
      "id_str" : "2147864503",
      "id" : 2147864503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/692036084914622464\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/wCTl3mmZP5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZqbJreXEAEhIGy.jpg",
      "id_str" : "692036083345985537",
      "id" : 692036083345985537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZqbJreXEAEhIGy.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/wCTl3mmZP5"
    } ],
    "hashtags" : [ {
      "text" : "birding",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692040112121724928",
  "text" : "RT @goodbirding: Nice variety of dabbling ducks at Springbank Park. #birding https:\/\/t.co\/wCTl3mmZP5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/goodbirding\/status\/692036084914622464\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/wCTl3mmZP5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZqbJreXEAEhIGy.jpg",
        "id_str" : "692036083345985537",
        "id" : 692036083345985537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZqbJreXEAEhIGy.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/wCTl3mmZP5"
      } ],
      "hashtags" : [ {
        "text" : "birding",
        "indices" : [ 51, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692036084914622464",
    "text" : "Nice variety of dabbling ducks at Springbank Park. #birding https:\/\/t.co\/wCTl3mmZP5",
    "id" : 692036084914622464,
    "created_at" : "2016-01-26 17:27:14 +0000",
    "user" : {
      "name" : "Paul Roedding",
      "screen_name" : "goodbirding",
      "protected" : false,
      "id_str" : "2147864503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000630185970\/5de84b9e4fc1f4fdba0d8f537c4d543e_normal.jpeg",
      "id" : 2147864503,
      "verified" : false
    }
  },
  "id" : 692040112121724928,
  "created_at" : "2016-01-26 17:43:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 3, 19 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692039502672560128",
  "text" : "RT @JourneyTheHedgi: I can't be lugging my laptop and drawing tablet up and down stairs and everywhere. I want something portable so I can \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692037952239706112",
    "text" : "I can't be lugging my laptop and drawing tablet up and down stairs and everywhere. I want something portable so I can draw comfortably...",
    "id" : 692037952239706112,
    "created_at" : "2016-01-26 17:34:39 +0000",
    "user" : {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "protected" : false,
      "id_str" : "1137858745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567144176848891905\/-TmPAWNk_normal.png",
      "id" : 1137858745,
      "verified" : false
    }
  },
  "id" : 692039502672560128,
  "created_at" : "2016-01-26 17:40:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 3, 19 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692039453670514690",
  "text" : "RT @JourneyTheHedgi: Can anyone recommend a graphics tablet with a screen that isn't overpriced? Or a tablet that can be used for drawing\/d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692037603122634756",
    "text" : "Can anyone recommend a graphics tablet with a screen that isn't overpriced? Or a tablet that can be used for drawing\/drawing software...",
    "id" : 692037603122634756,
    "created_at" : "2016-01-26 17:33:16 +0000",
    "user" : {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "protected" : false,
      "id_str" : "1137858745",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567144176848891905\/-TmPAWNk_normal.png",
      "id" : 1137858745,
      "verified" : false
    }
  },
  "id" : 692039453670514690,
  "created_at" : "2016-01-26 17:40:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692034788354564097",
  "text" : "RT @JeremyCShipp: You are beautiful. You are 1000 leaves whispering in the wind. You are an unfamiliar word absorbed by an eager mind. You \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692031826194407425",
    "text" : "You are beautiful. You are 1000 leaves whispering in the wind. You are an unfamiliar word absorbed by an eager mind. You are a hopeful dream",
    "id" : 692031826194407425,
    "created_at" : "2016-01-26 17:10:19 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 692034788354564097,
  "created_at" : "2016-01-26 17:22:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/PUOZzAo6Ab",
      "expanded_url" : "https:\/\/twitter.com\/ScientificIdeas\/status\/673687453522202626",
      "display_url" : "twitter.com\/ScientificIdea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692033979428507648",
  "text" : "this pic makes me want to cry... https:\/\/t.co\/PUOZzAo6Ab",
  "id" : 692033979428507648,
  "created_at" : "2016-01-26 17:18:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/692028551357399042\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/9vIxZQFwfx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZqUTHhWwAEQ1-R.jpg",
      "id_str" : "692028548912168961",
      "id" : 692028548912168961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZqUTHhWwAEQ1-R.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2848,
        "resize" : "fit",
        "w" : 4288
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9vIxZQFwfx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692033597390376960",
  "text" : "RT @Swanwhisperer: Perfect Heart in a finish of Mating Courtship https:\/\/t.co\/9vIxZQFwfx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/692028551357399042\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/9vIxZQFwfx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZqUTHhWwAEQ1-R.jpg",
        "id_str" : "692028548912168961",
        "id" : 692028548912168961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZqUTHhWwAEQ1-R.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2848,
          "resize" : "fit",
          "w" : 4288
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9vIxZQFwfx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692028551357399042",
    "text" : "Perfect Heart in a finish of Mating Courtship https:\/\/t.co\/9vIxZQFwfx",
    "id" : 692028551357399042,
    "created_at" : "2016-01-26 16:57:18 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 692033597390376960,
  "created_at" : "2016-01-26 17:17:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692032764212813826",
  "text" : "RT @_NealeDWalsch: You are a three-fold being. You consist of body, mind, and spirit. This is the Holy Trinity, and it has been called by m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692029367384408064",
    "text" : "You are a three-fold being. You consist of body, mind, and spirit. This is the Holy Trinity, and it has been called by many names.",
    "id" : 692029367384408064,
    "created_at" : "2016-01-26 17:00:33 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 692032764212813826,
  "created_at" : "2016-01-26 17:14:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Room",
      "screen_name" : "TheRoomGame",
      "indices" : [ 3, 15 ],
      "id_str" : "3187341148",
      "id" : 3187341148
    }, {
      "name" : "Gadgets 360",
      "screen_name" : "Gadgets_360",
      "indices" : [ 76, 88 ],
      "id_str" : "695625049726799873",
      "id" : 695625049726799873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692026317865377794",
  "text" : "RT @TheRoomGame: \"One of the best puzzle game series ever, a gorgeous game\" @Gadgets_360 enjoy The Room Three on iOS &amp; Android https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gadgets 360",
        "screen_name" : "Gadgets_360",
        "indices" : [ 59, 71 ],
        "id_str" : "695625049726799873",
        "id" : 695625049726799873
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/DfPK6LyWkZ",
        "expanded_url" : "http:\/\/bit.ly\/1ntyZFd",
        "display_url" : "bit.ly\/1ntyZFd"
      } ]
    },
    "geo" : { },
    "id_str" : "689117208379834368",
    "text" : "\"One of the best puzzle game series ever, a gorgeous game\" @Gadgets_360 enjoy The Room Three on iOS &amp; Android https:\/\/t.co\/DfPK6LyWkZ",
    "id" : 689117208379834368,
    "created_at" : "2016-01-18 16:08:40 +0000",
    "user" : {
      "name" : "The Room",
      "screen_name" : "TheRoomGame",
      "protected" : false,
      "id_str" : "3187341148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747801307029848064\/7sG6Pb0g_normal.jpg",
      "id" : 3187341148,
      "verified" : false
    }
  },
  "id" : 692026317865377794,
  "created_at" : "2016-01-26 16:48:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Room",
      "screen_name" : "TheRoomGame",
      "indices" : [ 3, 15 ],
      "id_str" : "3187341148",
      "id" : 3187341148
    }, {
      "name" : "Amazon Appstore",
      "screen_name" : "amazonappstore",
      "indices" : [ 53, 68 ],
      "id_str" : "247483633",
      "id" : 247483633
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheRoomGame\/status\/690555848284901376\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/0tNe6gypDI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CZVYh1kWcAE4QxS.png",
      "id_str" : "690555456209711105",
      "id" : 690555456209711105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CZVYh1kWcAE4QxS.png",
      "sizes" : [ {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 477
      } ],
      "display_url" : "pic.twitter.com\/0tNe6gypDI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/wiUt2eknH6",
      "expanded_url" : "http:\/\/amzn.to\/1Tc7VGx",
      "display_url" : "amzn.to\/1Tc7VGx"
    } ]
  },
  "geo" : { },
  "id_str" : "692026244871917570",
  "text" : "RT @TheRoomGame: Discover a new puzzle experience on @amazonappstore with The Room Three https:\/\/t.co\/wiUt2eknH6 https:\/\/t.co\/0tNe6gypDI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon Appstore",
        "screen_name" : "amazonappstore",
        "indices" : [ 36, 51 ],
        "id_str" : "247483633",
        "id" : 247483633
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheRoomGame\/status\/690555848284901376\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/0tNe6gypDI",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CZVYh1kWcAE4QxS.png",
        "id_str" : "690555456209711105",
        "id" : 690555456209711105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CZVYh1kWcAE4QxS.png",
        "sizes" : [ {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 477
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 477
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 477
        } ],
        "display_url" : "pic.twitter.com\/0tNe6gypDI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/wiUt2eknH6",
        "expanded_url" : "http:\/\/amzn.to\/1Tc7VGx",
        "display_url" : "amzn.to\/1Tc7VGx"
      } ]
    },
    "geo" : { },
    "id_str" : "690555848284901376",
    "text" : "Discover a new puzzle experience on @amazonappstore with The Room Three https:\/\/t.co\/wiUt2eknH6 https:\/\/t.co\/0tNe6gypDI",
    "id" : 690555848284901376,
    "created_at" : "2016-01-22 15:25:18 +0000",
    "user" : {
      "name" : "The Room",
      "screen_name" : "TheRoomGame",
      "protected" : false,
      "id_str" : "3187341148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747801307029848064\/7sG6Pb0g_normal.jpg",
      "id" : 3187341148,
      "verified" : false
    }
  },
  "id" : 692026244871917570,
  "created_at" : "2016-01-26 16:48:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692024654089838592",
  "text" : "RT @bend_time: prisons are not rehabilitative &amp; dont want to be. they NEED recidivism bc profit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "692024315290628096",
    "text" : "prisons are not rehabilitative &amp; dont want to be. they NEED recidivism bc profit.",
    "id" : 692024315290628096,
    "created_at" : "2016-01-26 16:40:28 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 692024654089838592,
  "created_at" : "2016-01-26 16:41:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fireproof Games",
      "screen_name" : "Fireproof_Games",
      "indices" : [ 3, 19 ],
      "id_str" : "607384486",
      "id" : 607384486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/pv1SS6eM4n",
      "expanded_url" : "http:\/\/bit.ly\/1Shf4Vs",
      "display_url" : "bit.ly\/1Shf4Vs"
    } ]
  },
  "geo" : { },
  "id_str" : "692024225088049152",
  "text" : "RT @Fireproof_Games: Interested in how we made The Room Three? Head over to our Flickr to take a peek: https:\/\/t.co\/pv1SS6eM4n https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Fireproof_Games\/status\/692020277342048256\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/hDRrmcggpr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZqMxmAWAAA3uDq.jpg",
        "id_str" : "692020276398260224",
        "id" : 692020276398260224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZqMxmAWAAA3uDq.jpg",
        "sizes" : [ {
          "h" : 269,
          "resize" : "fit",
          "w" : 525
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 269,
          "resize" : "fit",
          "w" : 525
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 269,
          "resize" : "fit",
          "w" : 525
        } ],
        "display_url" : "pic.twitter.com\/hDRrmcggpr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/pv1SS6eM4n",
        "expanded_url" : "http:\/\/bit.ly\/1Shf4Vs",
        "display_url" : "bit.ly\/1Shf4Vs"
      } ]
    },
    "geo" : { },
    "id_str" : "692020277342048256",
    "text" : "Interested in how we made The Room Three? Head over to our Flickr to take a peek: https:\/\/t.co\/pv1SS6eM4n https:\/\/t.co\/hDRrmcggpr",
    "id" : 692020277342048256,
    "created_at" : "2016-01-26 16:24:25 +0000",
    "user" : {
      "name" : "Fireproof Games",
      "screen_name" : "Fireproof_Games",
      "protected" : false,
      "id_str" : "607384486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793386416344600576\/LoK1OXWL_normal.jpg",
      "id" : 607384486,
      "verified" : false
    }
  },
  "id" : 692024225088049152,
  "created_at" : "2016-01-26 16:40:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "indices" : [ 3, 19 ],
      "id_str" : "111095506",
      "id" : 111095506
    }, {
      "name" : "BBC One",
      "screen_name" : "BBCOne",
      "indices" : [ 28, 35 ],
      "id_str" : "871686942",
      "id" : 871686942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WarAndPeace",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/Dv4KPlVyE7",
      "expanded_url" : "http:\/\/bit.ly\/1K8rP3e",
      "display_url" : "bit.ly\/1K8rP3e"
    } ]
  },
  "geo" : { },
  "id_str" : "692024145878609921",
  "text" : "RT @BlackstoneAudio: Loving @BBCOne's #WarAndPeace &amp; inspired to tackle the classic? Get our acclaimed audiobook: https:\/\/t.co\/Dv4KPlVyE7 h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC One",
        "screen_name" : "BBCOne",
        "indices" : [ 7, 14 ],
        "id_str" : "871686942",
        "id" : 871686942
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BlackstoneAudio\/status\/692020318588657664\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/uitMDv056a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZqMz-JUsAIaJHS.jpg",
        "id_str" : "692020317238112258",
        "id" : 692020317238112258,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZqMz-JUsAIaJHS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/uitMDv056a"
      } ],
      "hashtags" : [ {
        "text" : "WarAndPeace",
        "indices" : [ 17, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/Dv4KPlVyE7",
        "expanded_url" : "http:\/\/bit.ly\/1K8rP3e",
        "display_url" : "bit.ly\/1K8rP3e"
      } ]
    },
    "geo" : { },
    "id_str" : "692020318588657664",
    "text" : "Loving @BBCOne's #WarAndPeace &amp; inspired to tackle the classic? Get our acclaimed audiobook: https:\/\/t.co\/Dv4KPlVyE7 https:\/\/t.co\/uitMDv056a",
    "id" : 692020318588657664,
    "created_at" : "2016-01-26 16:24:35 +0000",
    "user" : {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "protected" : false,
      "id_str" : "111095506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556139629351403520\/J5Y-trdL_normal.jpeg",
      "id" : 111095506,
      "verified" : false
    }
  },
  "id" : 692024145878609921,
  "created_at" : "2016-01-26 16:39:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gapol",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ELG0ncoSDS",
      "expanded_url" : "http:\/\/shar.es\/1hlAsO",
      "display_url" : "shar.es\/1hlAsO"
    } ]
  },
  "geo" : { },
  "id_str" : "692024035371290624",
  "text" : "RT @rjmedwed: The headliner for Feb 10's Religious Liberty Rally in GA says \"LGBTQ children are the enemy.\" https:\/\/t.co\/ELG0ncoSDS #gapol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gapol",
        "indices" : [ 118, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/ELG0ncoSDS",
        "expanded_url" : "http:\/\/shar.es\/1hlAsO",
        "display_url" : "shar.es\/1hlAsO"
      } ]
    },
    "geo" : { },
    "id_str" : "692020788023664640",
    "text" : "The headliner for Feb 10's Religious Liberty Rally in GA says \"LGBTQ children are the enemy.\" https:\/\/t.co\/ELG0ncoSDS #gapol",
    "id" : 692020788023664640,
    "created_at" : "2016-01-26 16:26:27 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 692024035371290624,
  "created_at" : "2016-01-26 16:39:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "indices" : [ 3, 18 ],
      "id_str" : "148856572",
      "id" : 148856572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/3tMTh4rHZs",
      "expanded_url" : "http:\/\/Downpour.com",
      "display_url" : "Downpour.com"
    }, {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/optVicJ472",
      "expanded_url" : "http:\/\/fb.me\/78ociG5ca",
      "display_url" : "fb.me\/78ociG5ca"
    } ]
  },
  "geo" : { },
  "id_str" : "692023975262687234",
  "text" : "RT @Audiobook_Comm: War and Peace audiobook at https:\/\/t.co\/3tMTh4rHZs https:\/\/t.co\/optVicJ472",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/3tMTh4rHZs",
        "expanded_url" : "http:\/\/Downpour.com",
        "display_url" : "Downpour.com"
      }, {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/optVicJ472",
        "expanded_url" : "http:\/\/fb.me\/78ociG5ca",
        "display_url" : "fb.me\/78ociG5ca"
      } ]
    },
    "geo" : { },
    "id_str" : "692020782998749184",
    "text" : "War and Peace audiobook at https:\/\/t.co\/3tMTh4rHZs https:\/\/t.co\/optVicJ472",
    "id" : 692020782998749184,
    "created_at" : "2016-01-26 16:26:26 +0000",
    "user" : {
      "name" : "Audiobook Community",
      "screen_name" : "Audiobook_Comm",
      "protected" : false,
      "id_str" : "148856572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716970602259738624\/qDTP4Z12_normal.jpg",
      "id" : 148856572,
      "verified" : false
    }
  },
  "id" : 692023975262687234,
  "created_at" : "2016-01-26 16:39:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/qo5ihT6bdq",
      "expanded_url" : "https:\/\/twitter.com\/DefendTheSheep\/status\/692020544200445953",
      "display_url" : "twitter.com\/DefendTheSheep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692023376941076480",
  "text" : "Amen!! https:\/\/t.co\/qo5ihT6bdq",
  "id" : 692023376941076480,
  "created_at" : "2016-01-26 16:36:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/qAHlFkur5h",
      "expanded_url" : "http:\/\/disq.us\/93pbsy",
      "display_url" : "disq.us\/93pbsy"
    } ]
  },
  "geo" : { },
  "id_str" : "692013933524340736",
  "text" : "\"You asked, How far is too far? How about, I dunno, eternal conscious torment?  If God is a great\u2026\" https:\/\/t.co\/qAHlFkur5h",
  "id" : 692013933524340736,
  "created_at" : "2016-01-26 15:59:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/BscPx3aH8T",
      "expanded_url" : "http:\/\/randalrauser.com\/2016\/01\/sin-junkies-addiction-punishment-and-the-new-problem-of-hell\/",
      "display_url" : "randalrauser.com\/2016\/01\/sin-ju\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "692012243219845120",
  "text" : "Sin Junkies: addiction, punishment, and the new problem of hell https:\/\/t.co\/BscPx3aH8T",
  "id" : 692012243219845120,
  "created_at" : "2016-01-26 15:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dopaminergic13",
      "screen_name" : "dopaminergic13",
      "indices" : [ 3, 18 ],
      "id_str" : "499423390",
      "id" : 499423390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RBCXNbJkwX",
      "expanded_url" : "http:\/\/buff.ly\/1nrxZBA",
      "display_url" : "buff.ly\/1nrxZBA"
    } ]
  },
  "geo" : { },
  "id_str" : "691999765454852097",
  "text" : "RT @dopaminergic13: When Breath Becomes Air: A Young Neurosurgeon Examines the Meaning of Life as He Faces His Death https:\/\/t.co\/RBCXNbJkwX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/RBCXNbJkwX",
        "expanded_url" : "http:\/\/buff.ly\/1nrxZBA",
        "display_url" : "buff.ly\/1nrxZBA"
      } ]
    },
    "geo" : { },
    "id_str" : "688782885965410305",
    "text" : "When Breath Becomes Air: A Young Neurosurgeon Examines the Meaning of Life as He Faces His Death https:\/\/t.co\/RBCXNbJkwX",
    "id" : 688782885965410305,
    "created_at" : "2016-01-17 18:00:11 +0000",
    "user" : {
      "name" : "dopaminergic13",
      "screen_name" : "dopaminergic13",
      "protected" : false,
      "id_str" : "499423390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000374643894\/a98b930bf94b2c6b2d00f1fd8d39c6b5_normal.jpeg",
      "id" : 499423390,
      "verified" : false
    }
  },
  "id" : 691999765454852097,
  "created_at" : "2016-01-26 15:02:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OneFunnyMummy",
      "screen_name" : "OneFunnyMummy",
      "indices" : [ 3, 17 ],
      "id_str" : "2289938047",
      "id" : 2289938047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691996584524005377",
  "text" : "RT @OneFunnyMummy: Here, make sense of this for me.\n\n*throws my life in your lap*",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691672061303861248",
    "text" : "Here, make sense of this for me.\n\n*throws my life in your lap*",
    "id" : 691672061303861248,
    "created_at" : "2016-01-25 17:20:44 +0000",
    "user" : {
      "name" : "OneFunnyMummy",
      "screen_name" : "OneFunnyMummy",
      "protected" : false,
      "id_str" : "2289938047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639838813469052928\/uPnau0pv_normal.jpg",
      "id" : 2289938047,
      "verified" : false
    }
  },
  "id" : 691996584524005377,
  "created_at" : "2016-01-26 14:50:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Moral Agnostic",
      "screen_name" : "MoralAgnostic",
      "indices" : [ 3, 17 ],
      "id_str" : "2504645971",
      "id" : 2504645971
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MoralAgnostic\/status\/659122208485285890\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/NHwkf6aYNn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWsJtqU8AAgIka.jpg",
      "id_str" : "659122203355574272",
      "id" : 659122203355574272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWsJtqU8AAgIka.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NHwkf6aYNn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691773918852583424",
  "text" : "RT @MoralAgnostic: My moral code: https:\/\/t.co\/NHwkf6aYNn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MoralAgnostic\/status\/659122208485285890\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/NHwkf6aYNn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWsJtqU8AAgIka.jpg",
        "id_str" : "659122203355574272",
        "id" : 659122203355574272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWsJtqU8AAgIka.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NHwkf6aYNn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659122208485285890",
    "text" : "My moral code: https:\/\/t.co\/NHwkf6aYNn",
    "id" : 659122208485285890,
    "created_at" : "2015-10-27 21:39:15 +0000",
    "user" : {
      "name" : "The Moral Agnostic",
      "screen_name" : "MoralAgnostic",
      "protected" : false,
      "id_str" : "2504645971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722420975804026880\/CZivpNnL_normal.jpg",
      "id" : 2504645971,
      "verified" : false
    }
  },
  "id" : 691773918852583424,
  "created_at" : "2016-01-26 00:05:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "indices" : [ 3, 12 ],
      "id_str" : "31289431",
      "id" : 31289431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/MgEmeDtZdh",
      "expanded_url" : "https:\/\/twitter.com\/ppnycaction\/status\/691721023377534978",
      "display_url" : "twitter.com\/ppnycaction\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691773406912581633",
  "text" : "RT @RevDebra: More good news for women today.  https:\/\/t.co\/MgEmeDtZdh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/MgEmeDtZdh",
        "expanded_url" : "https:\/\/twitter.com\/ppnycaction\/status\/691721023377534978",
        "display_url" : "twitter.com\/ppnycaction\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691771805296631808",
    "text" : "More good news for women today.  https:\/\/t.co\/MgEmeDtZdh",
    "id" : 691771805296631808,
    "created_at" : "2016-01-25 23:57:05 +0000",
    "user" : {
      "name" : "(((Debra Haffner)))",
      "screen_name" : "RevDebra",
      "protected" : false,
      "id_str" : "31289431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497574055969832961\/qNtCjxUk_normal.jpeg",
      "id" : 31289431,
      "verified" : false
    }
  },
  "id" : 691773406912581633,
  "created_at" : "2016-01-26 00:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 0, 7 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "691763937549926400",
  "geo" : { },
  "id_str" : "691773301862064130",
  "in_reply_to_user_id" : 6872302,
  "text" : "@Mahala thx.. i did. had bought fresh CN even! she checks out the bottom cave w CN but not top. in prev home, she wld climb high to bskt.",
  "id" : 691773301862064130,
  "in_reply_to_status_id" : 691763937549926400,
  "created_at" : "2016-01-26 00:03:02 +0000",
  "in_reply_to_screen_name" : "Mahala",
  "in_reply_to_user_id_str" : "6872302",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/IOCZp3oJky",
      "expanded_url" : "https:\/\/twitter.com\/OHaraBizTips\/status\/691770619478831105",
      "display_url" : "twitter.com\/OHaraBizTips\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691772599618138115",
  "text" : "RT @Irish_Atheist: You sound positively gleeful. https:\/\/t.co\/IOCZp3oJky",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/IOCZp3oJky",
        "expanded_url" : "https:\/\/twitter.com\/OHaraBizTips\/status\/691770619478831105",
        "display_url" : "twitter.com\/OHaraBizTips\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691772250622681089",
    "text" : "You sound positively gleeful. https:\/\/t.co\/IOCZp3oJky",
    "id" : 691772250622681089,
    "created_at" : "2016-01-25 23:58:51 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 691772599618138115,
  "created_at" : "2016-01-26 00:00:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/AV7rOT09PE",
      "expanded_url" : "https:\/\/twitter.com\/LindaBeatty\/status\/691758724008914944",
      "display_url" : "twitter.com\/LindaBeatty\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691761714325504000",
  "text" : "Blue has a point there... https:\/\/t.co\/AV7rOT09PE",
  "id" : 691761714325504000,
  "created_at" : "2016-01-25 23:16:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691760850894454788",
  "text" : "so the cat doesnt like her condo. might as well have set fire to $75. and the other cat is NOT getting it. grrrrr.",
  "id" : 691760850894454788,
  "created_at" : "2016-01-25 23:13:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle Zen",
      "screen_name" : "KindleZen",
      "indices" : [ 3, 13 ],
      "id_str" : "35572816",
      "id" : 35572816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/PFaeT9HeQ8",
      "expanded_url" : "http:\/\/bit.ly\/1UmvfzL",
      "display_url" : "bit.ly\/1UmvfzL"
    } ]
  },
  "geo" : { },
  "id_str" : "691754813290340352",
  "text" : "RT @KindleZen: Nexus 7 2016 &amp; Android N Update Rumoured For Google I\/O 2016 - Know Your Mobile https:\/\/t.co\/PFaeT9HeQ8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/PFaeT9HeQ8",
        "expanded_url" : "http:\/\/bit.ly\/1UmvfzL",
        "display_url" : "bit.ly\/1UmvfzL"
      } ]
    },
    "geo" : { },
    "id_str" : "691750061756305408",
    "text" : "Nexus 7 2016 &amp; Android N Update Rumoured For Google I\/O 2016 - Know Your Mobile https:\/\/t.co\/PFaeT9HeQ8",
    "id" : 691750061756305408,
    "created_at" : "2016-01-25 22:30:41 +0000",
    "user" : {
      "name" : "Kindle Zen",
      "screen_name" : "KindleZen",
      "protected" : false,
      "id_str" : "35572816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/255905919\/KzenTwitterIcon1_normal.png",
      "id" : 35572816,
      "verified" : false
    }
  },
  "id" : 691754813290340352,
  "created_at" : "2016-01-25 22:49:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Handbasket",
      "screen_name" : "PhyllisCopeland",
      "indices" : [ 3, 19 ],
      "id_str" : "456236531",
      "id" : 456236531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691741134645755904",
  "text" : "RT @PhyllisCopeland: How is it just to punish anyone for crimes someone else committed? What kind of sadistic monster do you worship? https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/bcbtfgIua3",
        "expanded_url" : "https:\/\/twitter.com\/aigkenham\/status\/691007603321741312",
        "display_url" : "twitter.com\/aigkenham\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691739353970663424",
    "text" : "How is it just to punish anyone for crimes someone else committed? What kind of sadistic monster do you worship? https:\/\/t.co\/bcbtfgIua3",
    "id" : 691739353970663424,
    "created_at" : "2016-01-25 21:48:08 +0000",
    "user" : {
      "name" : "Helena Handbasket",
      "screen_name" : "PhyllisCopeland",
      "protected" : false,
      "id_str" : "456236531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422034415401717760\/IAWHgsPN_normal.jpeg",
      "id" : 456236531,
      "verified" : false
    }
  },
  "id" : 691741134645755904,
  "created_at" : "2016-01-25 21:55:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grazer",
      "screen_name" : "FrontlineXian",
      "indices" : [ 3, 17 ],
      "id_str" : "555034729",
      "id" : 555034729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691740356468215809",
  "text" : "RT @FrontlineXian: Sometimes it's difficult to forget that people need time to process, we want them to do it immediately",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691739626411786242",
    "text" : "Sometimes it's difficult to forget that people need time to process, we want them to do it immediately",
    "id" : 691739626411786242,
    "created_at" : "2016-01-25 21:49:13 +0000",
    "user" : {
      "name" : "Grazer",
      "screen_name" : "FrontlineXian",
      "protected" : false,
      "id_str" : "555034729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613640482585866240\/zNR2NWwy_normal.png",
      "id" : 555034729,
      "verified" : false
    }
  },
  "id" : 691740356468215809,
  "created_at" : "2016-01-25 21:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "indices" : [ 3, 14 ],
      "id_str" : "15314194",
      "id" : 15314194
    }, {
      "name" : "Anicca \uD83D\uDCAB",
      "screen_name" : "13adh13",
      "indices" : [ 29, 37 ],
      "id_str" : "573688563",
      "id" : 573688563
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/13adh13\/status\/691023003904188416\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/nb2uiFlPU2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZcBwdGWYAApHtL.jpg",
      "id_str" : "691022999781269504",
      "id" : 691022999781269504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZcBwdGWYAApHtL.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/nb2uiFlPU2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691732023380201472",
  "text" : "RT @dee_carney: Adorable! RT @13adh13: I just want someone who looks at me the way my brother looks at ketchup https:\/\/t.co\/nb2uiFlPU2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anicca \uD83D\uDCAB",
        "screen_name" : "13adh13",
        "indices" : [ 13, 21 ],
        "id_str" : "573688563",
        "id" : 573688563
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/13adh13\/status\/691023003904188416\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/nb2uiFlPU2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZcBwdGWYAApHtL.jpg",
        "id_str" : "691022999781269504",
        "id" : 691022999781269504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZcBwdGWYAApHtL.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/nb2uiFlPU2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691728936519213056",
    "text" : "Adorable! RT @13adh13: I just want someone who looks at me the way my brother looks at ketchup https:\/\/t.co\/nb2uiFlPU2",
    "id" : 691728936519213056,
    "created_at" : "2016-01-25 21:06:44 +0000",
    "user" : {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "protected" : false,
      "id_str" : "15314194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649739435890839552\/00nSuPH-_normal.jpg",
      "id" : 15314194,
      "verified" : false
    }
  },
  "id" : 691732023380201472,
  "created_at" : "2016-01-25 21:19:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K\u00F6ksal Ak\u0131n",
      "screen_name" : "Koksalakn",
      "indices" : [ 3, 13 ],
      "id_str" : "1643909461",
      "id" : 1643909461
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Koksalakn\/status\/691270687823106048\/video\/1",
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/FSOvxexMr9",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/691270431630888960\/pu\/img\/EAz2L8ug7F2YxbTW.jpg",
      "id_str" : "691270431630888960",
      "id" : 691270431630888960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/691270431630888960\/pu\/img\/EAz2L8ug7F2YxbTW.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/FSOvxexMr9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691707290500665345",
  "text" : "RT @Koksalakn: https:\/\/t.co\/FSOvxexMr9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Koksalakn\/status\/691270687823106048\/video\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/FSOvxexMr9",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/691270431630888960\/pu\/img\/EAz2L8ug7F2YxbTW.jpg",
        "id_str" : "691270431630888960",
        "id" : 691270431630888960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/691270431630888960\/pu\/img\/EAz2L8ug7F2YxbTW.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/FSOvxexMr9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691270687823106048",
    "text" : "https:\/\/t.co\/FSOvxexMr9",
    "id" : 691270687823106048,
    "created_at" : "2016-01-24 14:45:49 +0000",
    "user" : {
      "name" : "K\u00F6ksal Ak\u0131n",
      "screen_name" : "Koksalakn",
      "protected" : false,
      "id_str" : "1643909461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610196765191589888\/ENC99YX7_normal.jpg",
      "id" : 1643909461,
      "verified" : false
    }
  },
  "id" : 691707290500665345,
  "created_at" : "2016-01-25 19:40:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve McEllistrem",
      "screen_name" : "SteveMcEllis",
      "indices" : [ 3, 16 ],
      "id_str" : "2512494217",
      "id" : 2512494217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691687543679614976",
  "text" : "RT @SteveMcEllis: We grew up accepting absolutes that are no longer absolute. New discoveries have changed our truth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691685767370792960",
    "text" : "We grew up accepting absolutes that are no longer absolute. New discoveries have changed our truth.",
    "id" : 691685767370792960,
    "created_at" : "2016-01-25 18:15:12 +0000",
    "user" : {
      "name" : "Steve McEllistrem",
      "screen_name" : "SteveMcEllis",
      "protected" : false,
      "id_str" : "2512494217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479267873878077444\/RxKC2rdI_normal.jpeg",
      "id" : 2512494217,
      "verified" : false
    }
  },
  "id" : 691687543679614976,
  "created_at" : "2016-01-25 18:22:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiio",
      "indices" : [ 12, 17 ]
    }, {
      "text" : "audiobooks",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691681571024302080",
  "text" : "now if only #fiio could program bookmark feature so I could add #audiobooks",
  "id" : 691681571024302080,
  "created_at" : "2016-01-25 17:58:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fiio",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691680109418450947",
  "text" : "charged my #Fiio X1 on Christmas day. still has full charge after listening in car and sitting in my bag. ipod touch would have been red.",
  "id" : 691680109418450947,
  "created_at" : "2016-01-25 17:52:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "podcast",
      "indices" : [ 63, 71 ]
    }, {
      "text" : "tech",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "feedly",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/3H7taxD98y",
      "expanded_url" : "https:\/\/www.producthunt.com\/r\/423da4f1e4d778\/48651?app_id=339",
      "display_url" : "producthunt.com\/r\/423da4f1e4d7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691669067846041600",
  "text" : "cool idea &gt; Chapters \u2014 The best way to add chapters to your #podcast https:\/\/t.co\/3H7taxD98y #tech #feedly",
  "id" : 691669067846041600,
  "created_at" : "2016-01-25 17:08:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VoicesFromTheField",
      "screen_name" : "FieldVoices",
      "indices" : [ 3, 15 ],
      "id_str" : "4221773074",
      "id" : 4221773074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/Gf793Kltm3",
      "expanded_url" : "http:\/\/fb.me\/4c9EEPPak",
      "display_url" : "fb.me\/4c9EEPPak"
    } ]
  },
  "geo" : { },
  "id_str" : "691665797631053824",
  "text" : "RT @FieldVoices: We accept assembly-line justice for the poor. But we shouldn\u2019t. https:\/\/t.co\/Gf793Kltm3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/Gf793Kltm3",
        "expanded_url" : "http:\/\/fb.me\/4c9EEPPak",
        "display_url" : "fb.me\/4c9EEPPak"
      } ]
    },
    "geo" : { },
    "id_str" : "691340295624065024",
    "text" : "We accept assembly-line justice for the poor. But we shouldn\u2019t. https:\/\/t.co\/Gf793Kltm3",
    "id" : 691340295624065024,
    "created_at" : "2016-01-24 19:22:25 +0000",
    "user" : {
      "name" : "VoicesFromTheField",
      "screen_name" : "FieldVoices",
      "protected" : false,
      "id_str" : "4221773074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667116892516196352\/KlF8wQpU_normal.jpg",
      "id" : 4221773074,
      "verified" : false
    }
  },
  "id" : 691665797631053824,
  "created_at" : "2016-01-25 16:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691642852674248706",
  "text" : "I'm 34% through Syndrome E (Unabridged) by Franck Thilliez, Mark Polizzotti (translator), narrated by Gildart Jackson on my Audible app.",
  "id" : 691642852674248706,
  "created_at" : "2016-01-25 15:24:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Sheepish Spud",
      "screen_name" : "sheepish_spud",
      "indices" : [ 3, 17 ],
      "id_str" : "352291719",
      "id" : 352291719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/OlFtGERUlm",
      "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/691368131021905920",
      "display_url" : "twitter.com\/HeidiStea\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691393473610649600",
  "text" : "RT @sheepish_spud: See the trees  https:\/\/t.co\/OlFtGERUlm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/OlFtGERUlm",
        "expanded_url" : "https:\/\/twitter.com\/HeidiStea\/status\/691368131021905920",
        "display_url" : "twitter.com\/HeidiStea\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691387068195459072",
    "text" : "See the trees  https:\/\/t.co\/OlFtGERUlm",
    "id" : 691387068195459072,
    "created_at" : "2016-01-24 22:28:17 +0000",
    "user" : {
      "name" : "The Sheepish Spud",
      "screen_name" : "sheepish_spud",
      "protected" : false,
      "id_str" : "352291719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000686983872\/04966861bbd866d0d37e11e9af4c85e3_normal.jpeg",
      "id" : 352291719,
      "verified" : false
    }
  },
  "id" : 691393473610649600,
  "created_at" : "2016-01-24 22:53:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/G8HLIjKKdQ",
      "expanded_url" : "https:\/\/twitter.com\/dhammagirl\/status\/691338388260179969",
      "display_url" : "twitter.com\/dhammagirl\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691377619602927616",
  "text" : "&lt;3 https:\/\/t.co\/G8HLIjKKdQ",
  "id" : 691377619602927616,
  "created_at" : "2016-01-24 21:50:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Topher",
      "screen_name" : "TopherJH",
      "indices" : [ 3, 12 ],
      "id_str" : "215996801",
      "id" : 215996801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/RyN9KRd4YP",
      "expanded_url" : "https:\/\/twitter.com\/thehill\/status\/691277284129505280",
      "display_url" : "twitter.com\/thehill\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691299136189157377",
  "text" : "RT @TopherJH: Is he fucking nuts?  https:\/\/t.co\/RyN9KRd4YP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/RyN9KRd4YP",
        "expanded_url" : "https:\/\/twitter.com\/thehill\/status\/691277284129505280",
        "display_url" : "twitter.com\/thehill\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "691286787298201600",
    "text" : "Is he fucking nuts?  https:\/\/t.co\/RyN9KRd4YP",
    "id" : 691286787298201600,
    "created_at" : "2016-01-24 15:49:48 +0000",
    "user" : {
      "name" : "Topher",
      "screen_name" : "TopherJH",
      "protected" : false,
      "id_str" : "215996801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617892852480274432\/koF-pj0N_normal.jpg",
      "id" : 215996801,
      "verified" : false
    }
  },
  "id" : 691299136189157377,
  "created_at" : "2016-01-24 16:38:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "indices" : [ 3, 15 ],
      "id_str" : "318692762",
      "id" : 318692762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/AYSGvg9CKy",
      "expanded_url" : "http:\/\/www.amazon.com\/Dark-Money-History-Billionaires-Radical\/dp\/0307970655",
      "display_url" : "amazon.com\/Dark-Money-His\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "691297670380527616",
  "text" : "RT @SeanMcElwee: Holy. Shit. Holy shit. Holy shit. There are literally no words for how fucked up this is. https:\/\/t.co\/AYSGvg9CKy https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SeanMcElwee\/status\/691134628653068288\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/KorQhru8pY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZdnRJRUAAAAGLs.jpg",
        "id_str" : "691134612068630528",
        "id" : 691134612068630528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZdnRJRUAAAAGLs.jpg",
        "sizes" : [ {
          "h" : 299,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KorQhru8pY"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/AYSGvg9CKy",
        "expanded_url" : "http:\/\/www.amazon.com\/Dark-Money-History-Billionaires-Radical\/dp\/0307970655",
        "display_url" : "amazon.com\/Dark-Money-His\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "691134377913360384",
    "geo" : { },
    "id_str" : "691134628653068288",
    "in_reply_to_user_id" : 318692762,
    "text" : "Holy. Shit. Holy shit. Holy shit. There are literally no words for how fucked up this is. https:\/\/t.co\/AYSGvg9CKy https:\/\/t.co\/KorQhru8pY",
    "id" : 691134628653068288,
    "in_reply_to_status_id" : 691134377913360384,
    "created_at" : "2016-01-24 05:45:10 +0000",
    "in_reply_to_screen_name" : "SeanMcElwee",
    "in_reply_to_user_id_str" : "318692762",
    "user" : {
      "name" : "sean.",
      "screen_name" : "SeanMcElwee",
      "protected" : false,
      "id_str" : "318692762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697656193737748480\/Hc-WgXJw_normal.jpg",
      "id" : 318692762,
      "verified" : false
    }
  },
  "id" : 691297670380527616,
  "created_at" : "2016-01-24 16:33:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691296795079655424",
  "text" : "RT @Charmantides: In other words we should be building things, other than walls, in the refugees home countries, rather than our own.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691296239497957376",
    "text" : "In other words we should be building things, other than walls, in the refugees home countries, rather than our own.",
    "id" : 691296239497957376,
    "created_at" : "2016-01-24 16:27:21 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 691296795079655424,
  "created_at" : "2016-01-24 16:29:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691296743107985409",
  "text" : "RT @Charmantides: Theres only one sure way to stop people wanting to come to your country, its not cement, its making their country hospita\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691295978792603649",
    "text" : "Theres only one sure way to stop people wanting to come to your country, its not cement, its making their country hospitable to them.",
    "id" : 691295978792603649,
    "created_at" : "2016-01-24 16:26:19 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 691296743107985409,
  "created_at" : "2016-01-24 16:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McSpocky\u2122 \uD83D\uDC7D",
      "screen_name" : "mcspocky",
      "indices" : [ 3, 12 ],
      "id_str" : "18082945",
      "id" : 18082945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Netanyahu",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "Obama",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/S1Zfi9Utlw",
      "expanded_url" : "http:\/\/bit.ly\/1Ju2jFP",
      "display_url" : "bit.ly\/1Ju2jFP"
    } ]
  },
  "geo" : { },
  "id_str" : "691291867443494912",
  "text" : "RT @mcspocky: Leaked Wiretaps Reveal #Netanyahu Bribed Republicans To Sabotage #Obama\u2019s Iran Peace Deal https:\/\/t.co\/S1Zfi9Utlw https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mcspocky\/status\/691158601558278145\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/BVwcs7aCYX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZd9FgTWAAAIzc0.jpg",
        "id_str" : "691158601348546560",
        "id" : 691158601348546560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZd9FgTWAAAIzc0.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 941
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 941
        } ],
        "display_url" : "pic.twitter.com\/BVwcs7aCYX"
      } ],
      "hashtags" : [ {
        "text" : "Netanyahu",
        "indices" : [ 23, 33 ]
      }, {
        "text" : "Obama",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/S1Zfi9Utlw",
        "expanded_url" : "http:\/\/bit.ly\/1Ju2jFP",
        "display_url" : "bit.ly\/1Ju2jFP"
      } ]
    },
    "geo" : { },
    "id_str" : "691158601558278145",
    "text" : "Leaked Wiretaps Reveal #Netanyahu Bribed Republicans To Sabotage #Obama\u2019s Iran Peace Deal https:\/\/t.co\/S1Zfi9Utlw https:\/\/t.co\/BVwcs7aCYX",
    "id" : 691158601558278145,
    "created_at" : "2016-01-24 07:20:26 +0000",
    "user" : {
      "name" : "McSpocky\u2122 \uD83D\uDC7D",
      "screen_name" : "mcspocky",
      "protected" : false,
      "id_str" : "18082945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797209606346797056\/R0hSQajN_normal.jpg",
      "id" : 18082945,
      "verified" : false
    }
  },
  "id" : 691291867443494912,
  "created_at" : "2016-01-24 16:09:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691291402978852865",
  "text" : "RT @bend_time: so. fucked. up. riot gear &amp; tanks for ferguson. vanilla creamer for bundy militia using kids as shields, burger king for dyl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691290031806246913",
    "text" : "so. fucked. up. riot gear &amp; tanks for ferguson. vanilla creamer for bundy militia using kids as shields, burger king for dylan roof.",
    "id" : 691290031806246913,
    "created_at" : "2016-01-24 16:02:41 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 691291402978852865,
  "created_at" : "2016-01-24 16:08:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691270243667296257",
  "text" : "got 2 level kitty condo yesterday. so far spent much energy keeping other cat out of it.. o-O",
  "id" : 691270243667296257,
  "created_at" : "2016-01-24 14:44:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691266217315794944",
  "text" : "I'm 22% through Syndrome E (Unabridged) by Franck Thilliez, Mark Polizzotti (translator), narrated by Gildart Jackson on my Audible app.",
  "id" : 691266217315794944,
  "created_at" : "2016-01-24 14:28:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/579186798145961984\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/GZJxf27ELn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAmvUsiWUAA4JRg.jpg",
      "id_str" : "579186797181292544",
      "id" : 579186797181292544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAmvUsiWUAA4JRg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 478
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 478
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 478
      } ],
      "display_url" : "pic.twitter.com\/GZJxf27ELn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691081677213401093",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/GZJxf27ELn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/579186798145961984\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/GZJxf27ELn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAmvUsiWUAA4JRg.jpg",
        "id_str" : "579186797181292544",
        "id" : 579186797181292544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAmvUsiWUAA4JRg.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 478
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 478
        } ],
        "display_url" : "pic.twitter.com\/GZJxf27ELn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691080519300308996",
    "text" : "https:\/\/t.co\/GZJxf27ELn",
    "id" : 691080519300308996,
    "created_at" : "2016-01-24 02:10:10 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 691081677213401093,
  "created_at" : "2016-01-24 02:14:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Corey",
      "screen_name" : "BenjaminCorey",
      "indices" : [ 3, 17 ],
      "id_str" : "767860179543228417",
      "id" : 767860179543228417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691049054684483584",
  "text" : "RT @benjamincorey: I wish you could tweet a smell, cause this place smells awesome. (Spending the weekend in Waterbury, VT) https:\/\/t.co\/2z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/benjamincorey\/status\/691001410838794241\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/2zpekBbG1s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZbt7dsWQAAoJU1.jpg",
        "id_str" : "691001198686650368",
        "id" : 691001198686650368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZbt7dsWQAAoJU1.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2zpekBbG1s"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "691001410838794241",
    "text" : "I wish you could tweet a smell, cause this place smells awesome. (Spending the weekend in Waterbury, VT) https:\/\/t.co\/2zpekBbG1s",
    "id" : 691001410838794241,
    "created_at" : "2016-01-23 20:55:49 +0000",
    "user" : {
      "name" : "Benjamin L Corey",
      "screen_name" : "BenjaminLCorey",
      "protected" : false,
      "id_str" : "134242072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559194237238280192\/3gLMCRmh_normal.jpeg",
      "id" : 134242072,
      "verified" : true
    }
  },
  "id" : 691049054684483584,
  "created_at" : "2016-01-24 00:05:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barnegat Police",
      "screen_name" : "Barnegat_PD",
      "indices" : [ 3, 15 ],
      "id_str" : "257109437",
      "id" : 257109437
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Barnegat_PD\/status\/690896445319299073\/video\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/u50MnHdwn4",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690896207963643904\/pu\/img\/3Pt9DoMHWx15TQ8m.jpg",
      "id_str" : "690896207963643904",
      "id" : 690896207963643904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690896207963643904\/pu\/img\/3Pt9DoMHWx15TQ8m.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/u50MnHdwn4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691001419411881984",
  "text" : "RT @Barnegat_PD: This would be why a mandatory evac was ordered. Bayfront. Humvee. Still 2 hrs until high tide. https:\/\/t.co\/u50MnHdwn4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Barnegat_PD\/status\/690896445319299073\/video\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/u50MnHdwn4",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690896207963643904\/pu\/img\/3Pt9DoMHWx15TQ8m.jpg",
        "id_str" : "690896207963643904",
        "id" : 690896207963643904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690896207963643904\/pu\/img\/3Pt9DoMHWx15TQ8m.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/u50MnHdwn4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690896445319299073",
    "text" : "This would be why a mandatory evac was ordered. Bayfront. Humvee. Still 2 hrs until high tide. https:\/\/t.co\/u50MnHdwn4",
    "id" : 690896445319299073,
    "created_at" : "2016-01-23 13:58:43 +0000",
    "user" : {
      "name" : "Barnegat Police",
      "screen_name" : "Barnegat_PD",
      "protected" : false,
      "id_str" : "257109437",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1254091204\/65rE2CG7_normal",
      "id" : 257109437,
      "verified" : false
    }
  },
  "id" : 691001419411881984,
  "created_at" : "2016-01-23 20:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Trayers",
      "screen_name" : "ltrayers",
      "indices" : [ 3, 12 ],
      "id_str" : "26845214",
      "id" : 26845214
    }, {
      "name" : "Capital Weather Gang",
      "screen_name" : "capitalweather",
      "indices" : [ 63, 78 ],
      "id_str" : "15309804",
      "id" : 15309804
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ltrayers\/status\/690799843506307072\/video\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/UaQ5ZLCj4h",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690799768440815616\/pu\/img\/4qbjRKT4a0xnjA0v.jpg",
      "id_str" : "690799768440815616",
      "id" : 690799768440815616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690799768440815616\/pu\/img\/4qbjRKT4a0xnjA0v.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UaQ5ZLCj4h"
    } ],
    "hashtags" : [ {
      "text" : "Snowzilla",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690971514204770305",
  "text" : "RT @ltrayers: Deer frolicking in the street in Cleveland Park. @capitalweather #Snowzilla https:\/\/t.co\/UaQ5ZLCj4h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Capital Weather Gang",
        "screen_name" : "capitalweather",
        "indices" : [ 49, 64 ],
        "id_str" : "15309804",
        "id" : 15309804
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ltrayers\/status\/690799843506307072\/video\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/UaQ5ZLCj4h",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690799768440815616\/pu\/img\/4qbjRKT4a0xnjA0v.jpg",
        "id_str" : "690799768440815616",
        "id" : 690799768440815616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/690799768440815616\/pu\/img\/4qbjRKT4a0xnjA0v.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UaQ5ZLCj4h"
      } ],
      "hashtags" : [ {
        "text" : "Snowzilla",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690799843506307072",
    "text" : "Deer frolicking in the street in Cleveland Park. @capitalweather #Snowzilla https:\/\/t.co\/UaQ5ZLCj4h",
    "id" : 690799843506307072,
    "created_at" : "2016-01-23 07:34:51 +0000",
    "user" : {
      "name" : "Laurie Trayers",
      "screen_name" : "ltrayers",
      "protected" : false,
      "id_str" : "26845214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575483934651232256\/4p4cmEK-_normal.jpeg",
      "id" : 26845214,
      "verified" : false
    }
  },
  "id" : 690971514204770305,
  "created_at" : "2016-01-23 18:57:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "YellowstoneNPS",
      "screen_name" : "YellowstoneNPS",
      "indices" : [ 48, 63 ],
      "id_str" : "44992488",
      "id" : 44992488
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/690931690886270977\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Oa4qCmlwry",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZautHBWQAAxeZS.jpg",
      "id_str" : "690931682849996800",
      "id" : 690931682849996800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZautHBWQAAxeZS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 826,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 744
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 744
      } ],
      "display_url" : "pic.twitter.com\/Oa4qCmlwry"
    } ],
    "hashtags" : [ {
      "text" : "Wyoming",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "bison",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690946843207933952",
  "text" : "RT @Interior: Snow plows are a little different @YellowstoneNPS in #Wyoming #bison https:\/\/t.co\/Oa4qCmlwry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YellowstoneNPS",
        "screen_name" : "YellowstoneNPS",
        "indices" : [ 34, 49 ],
        "id_str" : "44992488",
        "id" : 44992488
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/690931690886270977\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/Oa4qCmlwry",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZautHBWQAAxeZS.jpg",
        "id_str" : "690931682849996800",
        "id" : 690931682849996800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZautHBWQAAxeZS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 826,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 744
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 744
        } ],
        "display_url" : "pic.twitter.com\/Oa4qCmlwry"
      } ],
      "hashtags" : [ {
        "text" : "Wyoming",
        "indices" : [ 53, 61 ]
      }, {
        "text" : "bison",
        "indices" : [ 62, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690931690886270977",
    "text" : "Snow plows are a little different @YellowstoneNPS in #Wyoming #bison https:\/\/t.co\/Oa4qCmlwry",
    "id" : 690931690886270977,
    "created_at" : "2016-01-23 16:18:46 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 690946843207933952,
  "created_at" : "2016-01-23 17:18:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philosophy",
      "screen_name" : "Philosophy_RR",
      "indices" : [ 3, 17 ],
      "id_str" : "2829011882",
      "id" : 2829011882
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Philosophy_RR\/status\/690867303534034944\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/hwQIHBDUjz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZZ0JstUAAAwZka.jpg",
      "id_str" : "690867302816808960",
      "id" : 690867302816808960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZZ0JstUAAAwZka.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/hwQIHBDUjz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/oIYfxf594d",
      "expanded_url" : "http:\/\/www.rightrelevance.com\/search\/articles\/hero?article=4fce463398db98ddea84973eb15ea4e1598d169b&query=philosophy&taccount=philosophy_rr",
      "display_url" : "rightrelevance.com\/search\/article\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690922340511830016",
  "text" : "RT @Philosophy_RR: Daniel Dennett on Free Will and Consciousness https:\/\/t.co\/oIYfxf594d https:\/\/t.co\/hwQIHBDUjz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.rightrelevance.com\" rel=\"nofollow\"\u003EPhilosophyRR\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Philosophy_RR\/status\/690867303534034944\/photo\/1",
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/hwQIHBDUjz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZZ0JstUAAAwZka.jpg",
        "id_str" : "690867302816808960",
        "id" : 690867302816808960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZZ0JstUAAAwZka.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/hwQIHBDUjz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/oIYfxf594d",
        "expanded_url" : "http:\/\/www.rightrelevance.com\/search\/articles\/hero?article=4fce463398db98ddea84973eb15ea4e1598d169b&query=philosophy&taccount=philosophy_rr",
        "display_url" : "rightrelevance.com\/search\/article\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690867303534034944",
    "text" : "Daniel Dennett on Free Will and Consciousness https:\/\/t.co\/oIYfxf594d https:\/\/t.co\/hwQIHBDUjz",
    "id" : 690867303534034944,
    "created_at" : "2016-01-23 12:02:55 +0000",
    "user" : {
      "name" : "Philosophy",
      "screen_name" : "Philosophy_RR",
      "protected" : false,
      "id_str" : "2829011882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741361745223159808\/9XBBTzQb_normal.jpg",
      "id" : 2829011882,
      "verified" : false
    }
  },
  "id" : 690922340511830016,
  "created_at" : "2016-01-23 15:41:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690918847923294208",
  "text" : "RT @onealexharms: Currently reading, and very much enjoying Crystal Society, which is by my kid. Today's its release day. https:\/\/t.co\/joIP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/joIPGTHbAj",
        "expanded_url" : "https:\/\/twitter.com\/raelifin\/status\/690886871640117248",
        "display_url" : "twitter.com\/raelifin\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690901234056851456",
    "text" : "Currently reading, and very much enjoying Crystal Society, which is by my kid. Today's its release day. https:\/\/t.co\/joIPGTHbAj",
    "id" : 690901234056851456,
    "created_at" : "2016-01-23 14:17:45 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 690918847923294208,
  "created_at" : "2016-01-23 15:27:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secular Outpost",
      "screen_name" : "SecularOutpost",
      "indices" : [ 3, 18 ],
      "id_str" : "1167463664",
      "id" : 1167463664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690713285105225728",
  "text" : "RT @SecularOutpost: I don't understand the phrase \"natural-born citizen\" in US Constitution. As opposed to what? An artificially-born citiz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690702609271762944",
    "text" : "I don't understand the phrase \"natural-born citizen\" in US Constitution. As opposed to what? An artificially-born citizen? C-sections?",
    "id" : 690702609271762944,
    "created_at" : "2016-01-23 01:08:29 +0000",
    "user" : {
      "name" : "Secular Outpost",
      "screen_name" : "SecularOutpost",
      "protected" : false,
      "id_str" : "1167463664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780493989082378240\/CvUytlRW_normal.jpg",
      "id" : 1167463664,
      "verified" : false
    }
  },
  "id" : 690713285105225728,
  "created_at" : "2016-01-23 01:50:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life Tips\uD83D\uDCA1",
      "screen_name" : "BestProAdvice",
      "indices" : [ 3, 17 ],
      "id_str" : "1305995330",
      "id" : 1305995330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BestProAdvice\/status\/690700074788196353\/photo\/1",
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/FU3jfW9WnT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZXcDvPWEAEcIo3.jpg",
      "id_str" : "690700074649784321",
      "id" : 690700074649784321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZXcDvPWEAEcIo3.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/FU3jfW9WnT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690702124028727296",
  "text" : "RT @BestProAdvice: https:\/\/t.co\/FU3jfW9WnT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BestProAdvice\/status\/690700074788196353\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/FU3jfW9WnT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZXcDvPWEAEcIo3.jpg",
        "id_str" : "690700074649784321",
        "id" : 690700074649784321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZXcDvPWEAEcIo3.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/FU3jfW9WnT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690700074788196353",
    "text" : "https:\/\/t.co\/FU3jfW9WnT",
    "id" : 690700074788196353,
    "created_at" : "2016-01-23 00:58:25 +0000",
    "user" : {
      "name" : "Life Tips\uD83D\uDCA1",
      "screen_name" : "BestProAdvice",
      "protected" : false,
      "id_str" : "1305995330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548510647227801601\/0ox2LRwi_normal.jpeg",
      "id" : 1305995330,
      "verified" : false
    }
  },
  "id" : 690702124028727296,
  "created_at" : "2016-01-23 01:06:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/Ox8vzxlqUK",
      "expanded_url" : "https:\/\/twitter.com\/yodasworld\/status\/690687701851369472",
      "display_url" : "twitter.com\/yodasworld\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690689196252647424",
  "text" : "wth? isnt that illegal? separation of church and state!!! ugh!!! https:\/\/t.co\/Ox8vzxlqUK",
  "id" : 690689196252647424,
  "created_at" : "2016-01-23 00:15:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690687883632611328",
  "text" : "my stray cat showed early and got nice meal of full can w kibble and dish of old meatballs.",
  "id" : 690687883632611328,
  "created_at" : "2016-01-23 00:09:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "feedly",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/ZCGI5YFQod",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/formerlyfundie\/you-cant-be-pro-life-and-support-the-mass-deportation-of-immigrants\/",
      "display_url" : "patheos.com\/blogs\/formerly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690630669706338305",
  "text" : "You Can\u2019t Be Pro-Life and Support the Mass-Deportation of Immigrants https:\/\/t.co\/ZCGI5YFQod #religion #feedly",
  "id" : 690630669706338305,
  "created_at" : "2016-01-22 20:22:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Behemoth",
      "screen_name" : "BehemothMag",
      "indices" : [ 3, 15 ],
      "id_str" : "2513359370",
      "id" : 2513359370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/8KWdLfo7nb",
      "expanded_url" : "http:\/\/bit.ly\/1OLrRL2",
      "display_url" : "bit.ly\/1OLrRL2"
    } ]
  },
  "geo" : { },
  "id_str" : "690618669265768453",
  "text" : "RT @BehemothMag: The Carrington Flare happened at the last time humanity could collectively appreciate it. https:\/\/t.co\/8KWdLfo7nb https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BehemothMag\/status\/690582957006819328\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/xJKuK3yhsO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZVxikvUkAAudbA.jpg",
        "id_str" : "690582956662886400",
        "id" : 690582956662886400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZVxikvUkAAudbA.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/xJKuK3yhsO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/8KWdLfo7nb",
        "expanded_url" : "http:\/\/bit.ly\/1OLrRL2",
        "display_url" : "bit.ly\/1OLrRL2"
      } ]
    },
    "geo" : { },
    "id_str" : "690582957006819328",
    "text" : "The Carrington Flare happened at the last time humanity could collectively appreciate it. https:\/\/t.co\/8KWdLfo7nb https:\/\/t.co\/xJKuK3yhsO",
    "id" : 690582957006819328,
    "created_at" : "2016-01-22 17:13:02 +0000",
    "user" : {
      "name" : "The Behemoth",
      "screen_name" : "BehemothMag",
      "protected" : false,
      "id_str" : "2513359370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751107624582668289\/WxqBjrtd_normal.jpg",
      "id" : 2513359370,
      "verified" : false
    }
  },
  "id" : 690618669265768453,
  "created_at" : "2016-01-22 19:34:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K\u00F6ksal Ak\u0131n",
      "screen_name" : "Koksalakn",
      "indices" : [ 3, 13 ],
      "id_str" : "1643909461",
      "id" : 1643909461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690601644149579776",
  "text" : "RT @Koksalakn: - pudding is a resident fox at the national fox welfare society,as he's too friendly to be released back to the wild https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Koksalakn\/status\/690586333547470848\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/bXNlXGG2bL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZV0nEkWYAAZPhd.jpg",
        "id_str" : "690586332461162496",
        "id" : 690586332461162496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZV0nEkWYAAZPhd.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bXNlXGG2bL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690586333547470848",
    "text" : "- pudding is a resident fox at the national fox welfare society,as he's too friendly to be released back to the wild https:\/\/t.co\/bXNlXGG2bL",
    "id" : 690586333547470848,
    "created_at" : "2016-01-22 17:26:27 +0000",
    "user" : {
      "name" : "K\u00F6ksal Ak\u0131n",
      "screen_name" : "Koksalakn",
      "protected" : false,
      "id_str" : "1643909461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610196765191589888\/ENC99YX7_normal.jpg",
      "id" : 1643909461,
      "verified" : false
    }
  },
  "id" : 690601644149579776,
  "created_at" : "2016-01-22 18:27:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690595828180873217",
  "geo" : { },
  "id_str" : "690598049048059905",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep wow!",
  "id" : 690598049048059905,
  "in_reply_to_status_id" : 690595828180873217,
  "created_at" : "2016-01-22 18:13:00 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A\u10E6anda",
      "screen_name" : "GrnEyedMandy",
      "indices" : [ 0, 13 ],
      "id_str" : "834370586",
      "id" : 834370586
    }, {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 14, 24 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690595129451741184",
  "geo" : { },
  "id_str" : "690597911428796416",
  "in_reply_to_user_id" : 834370586,
  "text" : "@GrnEyedMandy @bend_time yup. me, too. prochoice and universal health care are imp 2 me. repub want to take away.",
  "id" : 690597911428796416,
  "in_reply_to_status_id" : 690595129451741184,
  "created_at" : "2016-01-22 18:12:27 +0000",
  "in_reply_to_screen_name" : "GrnEyedMandy",
  "in_reply_to_user_id_str" : "834370586",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A\u10E6anda",
      "screen_name" : "GrnEyedMandy",
      "indices" : [ 0, 13 ],
      "id_str" : "834370586",
      "id" : 834370586
    }, {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 14, 24 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bernie",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690566266495614976",
  "geo" : { },
  "id_str" : "690594537769734144",
  "in_reply_to_user_id" : 834370586,
  "text" : "@GrnEyedMandy @bend_time im #bernie supporter. you should vote for the person that best represents you and your values.",
  "id" : 690594537769734144,
  "in_reply_to_status_id" : 690566266495614976,
  "created_at" : "2016-01-22 17:59:03 +0000",
  "in_reply_to_screen_name" : "GrnEyedMandy",
  "in_reply_to_user_id_str" : "834370586",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "indices" : [ 3, 9 ],
      "id_str" : "38473215",
      "id" : 38473215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690593006349631488",
  "text" : "RT @mikta: Insanity: repeatedly thinking that violence is a good way to bring about love and peace and stability.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690587860638924800",
    "text" : "Insanity: repeatedly thinking that violence is a good way to bring about love and peace and stability.",
    "id" : 690587860638924800,
    "created_at" : "2016-01-22 17:32:31 +0000",
    "user" : {
      "name" : "stephen mattson",
      "screen_name" : "mikta",
      "protected" : false,
      "id_str" : "38473215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605163269968363520\/Xw0d9aky_normal.jpg",
      "id" : 38473215,
      "verified" : false
    }
  },
  "id" : 690593006349631488,
  "created_at" : "2016-01-22 17:52:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "indices" : [ 3, 13 ],
      "id_str" : "58882633",
      "id" : 58882633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreakingTheGlassSteeple",
      "indices" : [ 112, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/a8nz92VqJm",
      "expanded_url" : "http:\/\/www.religionnews.com\/2016\/01\/21\/pope-francis-opens-foot-washing-rite-to-women-in-gesture-of-inclusion\/",
      "display_url" : "religionnews.com\/2016\/01\/21\/pop\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690592907179495424",
  "text" : "RT @jorymicah: \"Pope Francis opens foot-washing rite to women in gesture of inclusion\" https:\/\/t.co\/a8nz92VqJm\n\n#BreakingTheGlassSteeple",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BreakingTheGlassSteeple",
        "indices" : [ 97, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/a8nz92VqJm",
        "expanded_url" : "http:\/\/www.religionnews.com\/2016\/01\/21\/pope-francis-opens-foot-washing-rite-to-women-in-gesture-of-inclusion\/",
        "display_url" : "religionnews.com\/2016\/01\/21\/pop\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690587972916350976",
    "text" : "\"Pope Francis opens foot-washing rite to women in gesture of inclusion\" https:\/\/t.co\/a8nz92VqJm\n\n#BreakingTheGlassSteeple",
    "id" : 690587972916350976,
    "created_at" : "2016-01-22 17:32:57 +0000",
    "user" : {
      "name" : "Jory Micah",
      "screen_name" : "jorymicah",
      "protected" : false,
      "id_str" : "58882633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755029012305547264\/TDPvMc6Y_normal.jpg",
      "id" : 58882633,
      "verified" : false
    }
  },
  "id" : 690592907179495424,
  "created_at" : "2016-01-22 17:52:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690586113640103940",
  "geo" : { },
  "id_str" : "690590480841728000",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides i get this..",
  "id" : 690590480841728000,
  "in_reply_to_status_id" : 690586113640103940,
  "created_at" : "2016-01-22 17:42:55 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "politics",
      "indices" : [ 112, 121 ]
    }, {
      "text" : "religion",
      "indices" : [ 122, 131 ]
    }, {
      "text" : "life",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690571122803359744",
  "text" : "stop it.. just stop it. stop giving the jerks MORE validation than those who are quiet, thoughtful, respectful. #politics #religion #life",
  "id" : 690571122803359744,
  "created_at" : "2016-01-22 16:26:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690549619693096960",
  "geo" : { },
  "id_str" : "690570309972463616",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep i love reading yr posts about all the stuff you do for hubby..lol. makes me think of DH and me..lol",
  "id" : 690570309972463616,
  "in_reply_to_status_id" : 690549619693096960,
  "created_at" : "2016-01-22 16:22:46 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 3, 7 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cats",
      "indices" : [ 105, 110 ]
    }, {
      "text" : "snowmaggedon",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690569765547556866",
  "text" : "RT @5x5: When the sky is hissing at you, stay inside and put your butt on your favorite person's pillow. #cats #snowmaggedon https:\/\/t.co\/j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/5x5\/status\/690552372272222208\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/jp4AQcczA1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZVVuUJXEAENIhH.jpg",
        "id_str" : "690552372041551873",
        "id" : 690552372041551873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZVVuUJXEAENIhH.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jp4AQcczA1"
      } ],
      "hashtags" : [ {
        "text" : "cats",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "snowmaggedon",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690552372272222208",
    "text" : "When the sky is hissing at you, stay inside and put your butt on your favorite person's pillow. #cats #snowmaggedon https:\/\/t.co\/jp4AQcczA1",
    "id" : 690552372272222208,
    "created_at" : "2016-01-22 15:11:30 +0000",
    "user" : {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "protected" : false,
      "id_str" : "4752781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796437594833879040\/UnBcqng-_normal.jpg",
      "id" : 4752781,
      "verified" : false
    }
  },
  "id" : 690569765547556866,
  "created_at" : "2016-01-22 16:20:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/vkTJfgG7sv",
      "expanded_url" : "https:\/\/twitter.com\/audible_com\/status\/690519282443259905",
      "display_url" : "twitter.com\/audible_com\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690546211774947332",
  "text" : "more science! https:\/\/t.co\/vkTJfgG7sv",
  "id" : 690546211774947332,
  "created_at" : "2016-01-22 14:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690544733215690753",
  "text" : "finished The Island of Knowledge last night and started on The Higgs Boson and Beyond #physics",
  "id" : 690544733215690753,
  "created_at" : "2016-01-22 14:41:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Van Praagh",
      "screen_name" : "JamesVanPraagh",
      "indices" : [ 3, 18 ],
      "id_str" : "36117734",
      "id" : 36117734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690344648536166404",
  "text" : "RT @JamesVanPraagh: Be grateful for the little things. There is always something to be thankful for even when we think there isn't. #inspir\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inspiration",
        "indices" : [ 112, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690343191254601728",
    "text" : "Be grateful for the little things. There is always something to be thankful for even when we think there isn't. #inspiration",
    "id" : 690343191254601728,
    "created_at" : "2016-01-22 01:20:17 +0000",
    "user" : {
      "name" : "James Van Praagh",
      "screen_name" : "JamesVanPraagh",
      "protected" : false,
      "id_str" : "36117734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531912694501097472\/0GFqd6F6_normal.jpeg",
      "id" : 36117734,
      "verified" : false
    }
  },
  "id" : 690344648536166404,
  "created_at" : "2016-01-22 01:26:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nyclass",
      "screen_name" : "nyclass",
      "indices" : [ 3, 11 ],
      "id_str" : "234445902",
      "id" : 234445902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpeakOutForHorses",
      "indices" : [ 108, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690344116471881733",
  "text" : "RT @nyclass: Peter Dinklage knows horses don't deserve to live nose-to-tailpipe.\n\nRT if you agree with him! #SpeakOutForHorses https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nyclass\/status\/690338285697286145\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/PWJ2mN7RtM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZSTAykWwAAB6ej.jpg",
        "id_str" : "690338284678070272",
        "id" : 690338284678070272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZSTAykWwAAB6ej.jpg",
        "sizes" : [ {
          "h" : 417,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1592,
          "resize" : "fit",
          "w" : 2288
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 713,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PWJ2mN7RtM"
      } ],
      "hashtags" : [ {
        "text" : "SpeakOutForHorses",
        "indices" : [ 95, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690338285697286145",
    "text" : "Peter Dinklage knows horses don't deserve to live nose-to-tailpipe.\n\nRT if you agree with him! #SpeakOutForHorses https:\/\/t.co\/PWJ2mN7RtM",
    "id" : 690338285697286145,
    "created_at" : "2016-01-22 01:00:47 +0000",
    "user" : {
      "name" : "nyclass",
      "screen_name" : "nyclass",
      "protected" : false,
      "id_str" : "234445902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687362668555038721\/zCAh7d7r_normal.jpg",
      "id" : 234445902,
      "verified" : false
    }
  },
  "id" : 690344116471881733,
  "created_at" : "2016-01-22 01:23:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ananda",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/s1eX9VtlPC",
      "expanded_url" : "http:\/\/j.mp\/Anan_MLSB",
      "display_url" : "j.mp\/Anan_MLSB"
    } ]
  },
  "geo" : { },
  "id_str" : "690343876104691712",
  "text" : "RT @DeepakChopra: We are each on this amazing planet to learn, to grow, to support and help each other https:\/\/t.co\/s1eX9VtlPC #ananda http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.deepakchopra.com\" rel=\"nofollow\"\u003EDeepak Chopra\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeepakChopra\/status\/690341875765608449\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/pAgBTEWDNS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZSWRrLWYAAhQTO.jpg",
        "id_str" : "690341873286799360",
        "id" : 690341873286799360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZSWRrLWYAAhQTO.jpg",
        "sizes" : [ {
          "h" : 582,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/pAgBTEWDNS"
      } ],
      "hashtags" : [ {
        "text" : "ananda",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/s1eX9VtlPC",
        "expanded_url" : "http:\/\/j.mp\/Anan_MLSB",
        "display_url" : "j.mp\/Anan_MLSB"
      } ]
    },
    "geo" : { },
    "id_str" : "690341875765608449",
    "text" : "We are each on this amazing planet to learn, to grow, to support and help each other https:\/\/t.co\/s1eX9VtlPC #ananda https:\/\/t.co\/pAgBTEWDNS",
    "id" : 690341875765608449,
    "created_at" : "2016-01-22 01:15:03 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 690343876104691712,
  "created_at" : "2016-01-22 01:23:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AvonCTStyle",
      "screen_name" : "AvonCTStyle",
      "indices" : [ 3, 15 ],
      "id_str" : "219476078",
      "id" : 219476078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690343514803146752",
  "text" : "RT @AvonCTStyle: Be kind whenever possible. It is always possible. - Dalai Lama #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 63, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690341954865991681",
    "text" : "Be kind whenever possible. It is always possible. - Dalai Lama #quote",
    "id" : 690341954865991681,
    "created_at" : "2016-01-22 01:15:22 +0000",
    "user" : {
      "name" : "AvonCTStyle",
      "screen_name" : "AvonCTStyle",
      "protected" : false,
      "id_str" : "219476078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474286198479798272\/yfxSp2PA_normal.jpeg",
      "id" : 219476078,
      "verified" : false
    }
  },
  "id" : 690343514803146752,
  "created_at" : "2016-01-22 01:21:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Morris",
      "screen_name" : "phil500",
      "indices" : [ 3, 11 ],
      "id_str" : "91673645",
      "id" : 91673645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690342345594781696",
  "text" : "RT @phil500: The planet desperately needs more peacemakers, healers, restorers, story tellers and lovers of all kinds\n\nDalai Lama https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phil500\/status\/690112896743952384\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/AhNaCpwWYu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZPGAvpWAAAoT3n.jpg",
        "id_str" : "690112884009992192",
        "id" : 690112884009992192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZPGAvpWAAAoT3n.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 636,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 636,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/AhNaCpwWYu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690112896743952384",
    "text" : "The planet desperately needs more peacemakers, healers, restorers, story tellers and lovers of all kinds\n\nDalai Lama https:\/\/t.co\/AhNaCpwWYu",
    "id" : 690112896743952384,
    "created_at" : "2016-01-21 10:05:10 +0000",
    "user" : {
      "name" : "Philip Morris",
      "screen_name" : "phil500",
      "protected" : false,
      "id_str" : "91673645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799391552493813762\/2LGfvqdu_normal.jpg",
      "id" : 91673645,
      "verified" : false
    }
  },
  "id" : 690342345594781696,
  "created_at" : "2016-01-22 01:16:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690340961382199296",
  "text" : "1st night zyprexa 2.5 mg for DD. Hoping it doesn't make her ill.",
  "id" : 690340961382199296,
  "created_at" : "2016-01-22 01:11:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jillian Hurley",
      "screen_name" : "BeautyBind",
      "indices" : [ 3, 14 ],
      "id_str" : "149751818",
      "id" : 149751818
    }, {
      "name" : "Commander Nasty",
      "screen_name" : "Anomaly100",
      "indices" : [ 118, 129 ],
      "id_str" : "27234909",
      "id" : 27234909
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Christie",
      "indices" : [ 98, 107 ]
    }, {
      "text" : "GOP",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690291909860986885",
  "text" : "RT @BeautyBind: Where to start with this.....\n\nChristie vetoes mandatory recess in N.J. schools \n\n#Christie #GOP\n\nCc: @Anomaly100  https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Commander Nasty",
        "screen_name" : "Anomaly100",
        "indices" : [ 102, 113 ],
        "id_str" : "27234909",
        "id" : 27234909
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Christie",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "GOP",
        "indices" : [ 92, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/CjwaZqdQOV",
        "expanded_url" : "http:\/\/www.nj.com\/education\/2016\/01\/christie_vetoes_mandatory_recess_in_nj_schools.html",
        "display_url" : "nj.com\/education\/2016\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690198512353550337",
    "text" : "Where to start with this.....\n\nChristie vetoes mandatory recess in N.J. schools \n\n#Christie #GOP\n\nCc: @Anomaly100  https:\/\/t.co\/CjwaZqdQOV",
    "id" : 690198512353550337,
    "created_at" : "2016-01-21 15:45:23 +0000",
    "user" : {
      "name" : "Jillian Hurley",
      "screen_name" : "BeautyBind",
      "protected" : false,
      "id_str" : "149751818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673376753750945792\/gKt4ptTZ_normal.jpg",
      "id" : 149751818,
      "verified" : false
    }
  },
  "id" : 690291909860986885,
  "created_at" : "2016-01-21 21:56:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Lineup",
      "screen_name" : "lineupweekly",
      "indices" : [ 3, 16 ],
      "id_str" : "2528336768",
      "id" : 2528336768
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lineupweekly\/status\/690254429237440514\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/9p0vUKZ6NN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZRGtgCWcAA17fY.jpg",
      "id_str" : "690254390402379776",
      "id" : 690254390402379776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZRGtgCWcAA17fY.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/9p0vUKZ6NN"
    } ],
    "hashtags" : [ {
      "text" : "FolkloreThursday",
      "indices" : [ 72, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/hq1NirowEB",
      "expanded_url" : "http:\/\/bit.ly\/1RWoVSd",
      "display_url" : "bit.ly\/1RWoVSd"
    } ]
  },
  "geo" : { },
  "id_str" : "690257347642552320",
  "text" : "RT @lineupweekly: The Green Children of Woolpit https:\/\/t.co\/hq1NirowEB #FolkloreThursday https:\/\/t.co\/9p0vUKZ6NN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lineupweekly\/status\/690254429237440514\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/9p0vUKZ6NN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZRGtgCWcAA17fY.jpg",
        "id_str" : "690254390402379776",
        "id" : 690254390402379776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZRGtgCWcAA17fY.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/9p0vUKZ6NN"
      } ],
      "hashtags" : [ {
        "text" : "FolkloreThursday",
        "indices" : [ 54, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 53 ],
        "url" : "https:\/\/t.co\/hq1NirowEB",
        "expanded_url" : "http:\/\/bit.ly\/1RWoVSd",
        "display_url" : "bit.ly\/1RWoVSd"
      } ]
    },
    "geo" : { },
    "id_str" : "690254429237440514",
    "text" : "The Green Children of Woolpit https:\/\/t.co\/hq1NirowEB #FolkloreThursday https:\/\/t.co\/9p0vUKZ6NN",
    "id" : 690254429237440514,
    "created_at" : "2016-01-21 19:27:34 +0000",
    "user" : {
      "name" : "The Lineup",
      "screen_name" : "lineupweekly",
      "protected" : false,
      "id_str" : "2528336768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730871245546389505\/CLBx9ok2_normal.jpg",
      "id" : 2528336768,
      "verified" : false
    }
  },
  "id" : 690257347642552320,
  "created_at" : "2016-01-21 19:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "indices" : [ 3, 18 ],
      "id_str" : "26560483",
      "id" : 26560483
    }, {
      "name" : "Sally Hepworth",
      "screen_name" : "SallyHepworth",
      "indices" : [ 121, 135 ],
      "id_str" : "38008736",
      "id" : 38008736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/UmhGf3ikEZ",
      "expanded_url" : "http:\/\/bit.ly\/1SzNP9T",
      "display_url" : "bit.ly\/1SzNP9T"
    } ]
  },
  "geo" : { },
  "id_str" : "690247146268971010",
  "text" : "RT @MacmillanAudio: You're invited! Listen along with us as we kick-off our Audio Book Club: https:\/\/t.co\/UmhGf3ikEZ h\/t @SallyHepworth htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sally Hepworth",
        "screen_name" : "SallyHepworth",
        "indices" : [ 101, 115 ],
        "id_str" : "38008736",
        "id" : 38008736
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MacmillanAudio\/status\/690229351858708481\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/91KisoNU8M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZQv0ytWkAADFSb.jpg",
        "id_str" : "690229226906226688",
        "id" : 690229226906226688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZQv0ytWkAADFSb.jpg",
        "sizes" : [ {
          "h" : 2400,
          "resize" : "fit",
          "w" : 2400
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/91KisoNU8M"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/UmhGf3ikEZ",
        "expanded_url" : "http:\/\/bit.ly\/1SzNP9T",
        "display_url" : "bit.ly\/1SzNP9T"
      } ]
    },
    "geo" : { },
    "id_str" : "690229351858708481",
    "text" : "You're invited! Listen along with us as we kick-off our Audio Book Club: https:\/\/t.co\/UmhGf3ikEZ h\/t @SallyHepworth https:\/\/t.co\/91KisoNU8M",
    "id" : 690229351858708481,
    "created_at" : "2016-01-21 17:47:55 +0000",
    "user" : {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "protected" : false,
      "id_str" : "26560483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473834349394010112\/_cwv_j5v_normal.jpeg",
      "id" : 26560483,
      "verified" : true
    }
  },
  "id" : 690247146268971010,
  "created_at" : "2016-01-21 18:58:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBC News",
      "screen_name" : "CBCNews",
      "indices" : [ 3, 11 ],
      "id_str" : "6433472",
      "id" : 6433472
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CBCNews\/status\/690236800061837312\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/QU3WUED6WI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZQ2tmhWYAAtSMe.jpg",
      "id_str" : "690236799956967424",
      "id" : 690236799956967424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZQ2tmhWYAAtSMe.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/QU3WUED6WI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/SOLNp9NfqS",
      "expanded_url" : "http:\/\/ift.tt\/20heqdn",
      "display_url" : "ift.tt\/20heqdn"
    } ]
  },
  "geo" : { },
  "id_str" : "690245332639322112",
  "text" : "RT @CBCNews: 5 planets visible at once for 1st time in a decade https:\/\/t.co\/SOLNp9NfqS https:\/\/t.co\/QU3WUED6WI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CBCNews\/status\/690236800061837312\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/QU3WUED6WI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZQ2tmhWYAAtSMe.jpg",
        "id_str" : "690236799956967424",
        "id" : 690236799956967424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZQ2tmhWYAAtSMe.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 460
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 460
        } ],
        "display_url" : "pic.twitter.com\/QU3WUED6WI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/SOLNp9NfqS",
        "expanded_url" : "http:\/\/ift.tt\/20heqdn",
        "display_url" : "ift.tt\/20heqdn"
      } ]
    },
    "geo" : { },
    "id_str" : "690236800061837312",
    "text" : "5 planets visible at once for 1st time in a decade https:\/\/t.co\/SOLNp9NfqS https:\/\/t.co\/QU3WUED6WI",
    "id" : 690236800061837312,
    "created_at" : "2016-01-21 18:17:31 +0000",
    "user" : {
      "name" : "CBC News",
      "screen_name" : "CBCNews",
      "protected" : false,
      "id_str" : "6433472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466664981673410560\/886Az0vu_normal.jpeg",
      "id" : 6433472,
      "verified" : true
    }
  },
  "id" : 690245332639322112,
  "created_at" : "2016-01-21 18:51:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Audiobooks",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/iDNa4bOnMh",
      "expanded_url" : "https:\/\/youtu.be\/HnjS-JdkkfY",
      "display_url" : "youtu.be\/HnjS-JdkkfY"
    } ]
  },
  "geo" : { },
  "id_str" : "690228901126279169",
  "text" : "interesting question.. hmm.. &gt; Trigger Warnings On #Audiobooks ??? https:\/\/t.co\/iDNa4bOnMh",
  "id" : 690228901126279169,
  "created_at" : "2016-01-21 17:46:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Audiobooks",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/r4L3RcDGkf",
      "expanded_url" : "https:\/\/youtu.be\/CapyVVFouK0",
      "display_url" : "youtu.be\/CapyVVFouK0"
    } ]
  },
  "geo" : { },
  "id_str" : "690224336008024065",
  "text" : "im enjoying his voice and personality : ) &gt; Why You Should Love #Audiobooks ! And Visit my channel! https:\/\/t.co\/r4L3RcDGkf",
  "id" : 690224336008024065,
  "created_at" : "2016-01-21 17:28:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690187932720766977",
  "geo" : { },
  "id_str" : "690206830514040832",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time aww.. bless you both. : )",
  "id" : 690206830514040832,
  "in_reply_to_status_id" : 690187932720766977,
  "created_at" : "2016-01-21 16:18:26 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690190423869014017",
  "geo" : { },
  "id_str" : "690205957993930752",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe looks interesting! will have to look for audio version (im audiobook obsessed atm)",
  "id" : 690205957993930752,
  "in_reply_to_status_id" : 690190423869014017,
  "created_at" : "2016-01-21 16:14:58 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TopSuspense",
      "screen_name" : "TopSuspense",
      "indices" : [ 3, 15 ],
      "id_str" : "220879221",
      "id" : 220879221
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TopSuspense\/status\/690177040364867586\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/q0FMIEk1ra",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZQAW5PUYAIWeOr.jpg",
      "id_str" : "690177036216721410",
      "id" : 690177036216721410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZQAW5PUYAIWeOr.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 429
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 429
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 429
      } ],
      "display_url" : "pic.twitter.com\/q0FMIEk1ra"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690204580190240768",
  "text" : "RT @TopSuspense: This. https:\/\/t.co\/q0FMIEk1ra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TopSuspense\/status\/690177040364867586\/photo\/1",
        "indices" : [ 6, 29 ],
        "url" : "https:\/\/t.co\/q0FMIEk1ra",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZQAW5PUYAIWeOr.jpg",
        "id_str" : "690177036216721410",
        "id" : 690177036216721410,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZQAW5PUYAIWeOr.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 429
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 429
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 429
        } ],
        "display_url" : "pic.twitter.com\/q0FMIEk1ra"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690177040364867586",
    "text" : "This. https:\/\/t.co\/q0FMIEk1ra",
    "id" : 690177040364867586,
    "created_at" : "2016-01-21 14:20:03 +0000",
    "user" : {
      "name" : "TopSuspense",
      "screen_name" : "TopSuspense",
      "protected" : false,
      "id_str" : "220879221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2456984927\/gpizkwx7erwc5q56rxzh_normal.jpeg",
      "id" : 220879221,
      "verified" : false
    }
  },
  "id" : 690204580190240768,
  "created_at" : "2016-01-21 16:09:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "library",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "books",
      "indices" : [ 108, 114 ]
    }, {
      "text" : "reading",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690204012277276672",
  "text" : "would be nice if #library account showed list of what I borrowed. im sure they have list for their own use. #books #reading",
  "id" : 690204012277276672,
  "created_at" : "2016-01-21 16:07:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    }, {
      "name" : "Scrivener",
      "screen_name" : "ScrivenerApp",
      "indices" : [ 51, 64 ],
      "id_str" : "40837504",
      "id" : 40837504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690203507928997888",
  "text" : "RT @mikemchargue: In two years working on my book, @ScrivenerApp crashed once.\n\nOn the three hours editing the book, Word has crashed 19 ti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scrivener",
        "screen_name" : "ScrivenerApp",
        "indices" : [ 33, 46 ],
        "id_str" : "40837504",
        "id" : 40837504
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "690188743798583297",
    "text" : "In two years working on my book, @ScrivenerApp crashed once.\n\nOn the three hours editing the book, Word has crashed 19 times.\n\n:-|",
    "id" : 690188743798583297,
    "created_at" : "2016-01-21 15:06:34 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 690203507928997888,
  "created_at" : "2016-01-21 16:05:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail",
      "screen_name" : "BirdAndGarden",
      "indices" : [ 0, 14 ],
      "id_str" : "465570280",
      "id" : 465570280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690189388123389952",
  "geo" : { },
  "id_str" : "690203281956691968",
  "in_reply_to_user_id" : 465570280,
  "text" : "@BirdAndGarden me, too. i use it to keep up w fam mostly now. cleaned my list some. want to whittle it down more.",
  "id" : 690203281956691968,
  "in_reply_to_status_id" : 690189388123389952,
  "created_at" : "2016-01-21 16:04:20 +0000",
  "in_reply_to_screen_name" : "BirdAndGarden",
  "in_reply_to_user_id_str" : "465570280",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "indices" : [ 3, 15 ],
      "id_str" : "17592150",
      "id" : 17592150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/nTztXWJK1A",
      "expanded_url" : "https:\/\/twitter.com\/realsaramerica\/status\/690186015907127296",
      "display_url" : "twitter.com\/realsaramerica\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "690202714039566341",
  "text" : "RT @thomaspluck: And he'll never do a year in jail. https:\/\/t.co\/nTztXWJK1A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/nTztXWJK1A",
        "expanded_url" : "https:\/\/twitter.com\/realsaramerica\/status\/690186015907127296",
        "display_url" : "twitter.com\/realsaramerica\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "690190136160718849",
    "text" : "And he'll never do a year in jail. https:\/\/t.co\/nTztXWJK1A",
    "id" : 690190136160718849,
    "created_at" : "2016-01-21 15:12:06 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 690202714039566341,
  "created_at" : "2016-01-21 16:02:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "690190144264007681",
  "geo" : { },
  "id_str" : "690202664123121664",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time i disagree w that. ppl following their passion..",
  "id" : 690202664123121664,
  "in_reply_to_status_id" : 690190144264007681,
  "created_at" : "2016-01-21 16:01:53 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/689774404134440960\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/G4l0mr2bkl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZKSJy6W0AAlzXm.jpg",
      "id_str" : "689774389924122624",
      "id" : 689774389924122624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZKSJy6W0AAlzXm.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/G4l0mr2bkl"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/689774404134440960\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/G4l0mr2bkl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZKSKMgWEAAUL4e.jpg",
      "id_str" : "689774396794343424",
      "id" : 689774396794343424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZKSKMgWEAAUL4e.jpg",
      "sizes" : [ {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/G4l0mr2bkl"
    } ],
    "hashtags" : [ {
      "text" : "MuteSwan",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "TheThames",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690192812185407488",
  "text" : "RT @missmuckyduck: Take off.\n#MuteSwan #TheThames https:\/\/t.co\/G4l0mr2bkl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/689774404134440960\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/G4l0mr2bkl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZKSJy6W0AAlzXm.jpg",
        "id_str" : "689774389924122624",
        "id" : 689774389924122624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZKSJy6W0AAlzXm.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/G4l0mr2bkl"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/689774404134440960\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/G4l0mr2bkl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZKSKMgWEAAUL4e.jpg",
        "id_str" : "689774396794343424",
        "id" : 689774396794343424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZKSKMgWEAAUL4e.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/G4l0mr2bkl"
      } ],
      "hashtags" : [ {
        "text" : "MuteSwan",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "TheThames",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689774404134440960",
    "text" : "Take off.\n#MuteSwan #TheThames https:\/\/t.co\/G4l0mr2bkl",
    "id" : 689774404134440960,
    "created_at" : "2016-01-20 11:40:07 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 690192812185407488,
  "created_at" : "2016-01-21 15:22:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorna d'Entremont",
      "screen_name" : "LornadEnt",
      "indices" : [ 3, 13 ],
      "id_str" : "102265039",
      "id" : 102265039
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LornadEnt\/status\/690174909306241028\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/oohu6iuLQl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZP-bCyUAAARLM0.jpg",
      "id_str" : "690174908475637760",
      "id" : 690174908475637760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZP-bCyUAAARLM0.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/oohu6iuLQl"
    } ],
    "hashtags" : [ {
      "text" : "Asperger",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/DQn85nYIuW",
      "expanded_url" : "https:\/\/shar.es\/1hqA4f",
      "display_url" : "shar.es\/1hqA4f"
    } ]
  },
  "geo" : { },
  "id_str" : "690179544314187776",
  "text" : "RT @LornadEnt: Review - Asperger\u2019s in Pink: Raising Child w\/ #Asperger\u2019s by Julie Clark https:\/\/t.co\/DQn85nYIuW https:\/\/t.co\/oohu6iuLQl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LornadEnt\/status\/690174909306241028\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/oohu6iuLQl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZP-bCyUAAARLM0.jpg",
        "id_str" : "690174908475637760",
        "id" : 690174908475637760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZP-bCyUAAARLM0.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/oohu6iuLQl"
      } ],
      "hashtags" : [ {
        "text" : "Asperger",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/DQn85nYIuW",
        "expanded_url" : "https:\/\/shar.es\/1hqA4f",
        "display_url" : "shar.es\/1hqA4f"
      } ]
    },
    "geo" : { },
    "id_str" : "690174909306241028",
    "text" : "Review - Asperger\u2019s in Pink: Raising Child w\/ #Asperger\u2019s by Julie Clark https:\/\/t.co\/DQn85nYIuW https:\/\/t.co\/oohu6iuLQl",
    "id" : 690174909306241028,
    "created_at" : "2016-01-21 14:11:35 +0000",
    "user" : {
      "name" : "Lorna d'Entremont",
      "screen_name" : "LornadEnt",
      "protected" : false,
      "id_str" : "102265039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701209340\/teachertraks4kidsLOGO_normal.jpg",
      "id" : 102265039,
      "verified" : false
    }
  },
  "id" : 690179544314187776,
  "created_at" : "2016-01-21 14:30:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 3, 15 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MotherJones\/status\/690168280183631872\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/8q5sHMSDm6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZP4ZMCUAAAXyEt.jpg",
      "id_str" : "690168279529160704",
      "id" : 690168279529160704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZP4ZMCUAAAXyEt.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/8q5sHMSDm6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/6AOs2ux4Ep",
      "expanded_url" : "http:\/\/mojo.ly\/1ZNrb2q",
      "display_url" : "mojo.ly\/1ZNrb2q"
    } ]
  },
  "geo" : { },
  "id_str" : "690179298918035456",
  "text" : "RT @MotherJones: The time Gloria Steinem made Bernie Sanders an \"honorary woman\" https:\/\/t.co\/6AOs2ux4Ep https:\/\/t.co\/8q5sHMSDm6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MotherJones\/status\/690168280183631872\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/8q5sHMSDm6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZP4ZMCUAAAXyEt.jpg",
        "id_str" : "690168279529160704",
        "id" : 690168279529160704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZP4ZMCUAAAXyEt.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/8q5sHMSDm6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/6AOs2ux4Ep",
        "expanded_url" : "http:\/\/mojo.ly\/1ZNrb2q",
        "display_url" : "mojo.ly\/1ZNrb2q"
      } ]
    },
    "geo" : { },
    "id_str" : "690168280183631872",
    "text" : "The time Gloria Steinem made Bernie Sanders an \"honorary woman\" https:\/\/t.co\/6AOs2ux4Ep https:\/\/t.co\/8q5sHMSDm6",
    "id" : 690168280183631872,
    "created_at" : "2016-01-21 13:45:15 +0000",
    "user" : {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "protected" : false,
      "id_str" : "18510860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731988002206027776\/c0HB7fbs_normal.jpg",
      "id" : 18510860,
      "verified" : true
    }
  },
  "id" : 690179298918035456,
  "created_at" : "2016-01-21 14:29:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adopt a Donkey",
      "screen_name" : "AdoptADonkey",
      "indices" : [ 3, 16 ],
      "id_str" : "1527563096",
      "id" : 1527563096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalHugDay",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/8KC28Pgf2s",
      "expanded_url" : "http:\/\/www.thedonkeysanctuary.org.uk\/adopt\/ripple",
      "display_url" : "thedonkeysanctuary.org.uk\/adopt\/ripple"
    } ]
  },
  "geo" : { },
  "id_str" : "690178066983841792",
  "text" : "RT @AdoptADonkey: Adoption donkey Ripple loves a good cuddle, could you adopt him? &gt;&gt; https:\/\/t.co\/8KC28Pgf2s #NationalHugDay https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AdoptADonkey\/status\/690177003480313856\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/P8IdEx55rp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZQAKopWkAA_TsR.jpg",
        "id_str" : "690176825604083712",
        "id" : 690176825604083712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZQAKopWkAA_TsR.jpg",
        "sizes" : [ {
          "h" : 537,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 403
        } ],
        "display_url" : "pic.twitter.com\/P8IdEx55rp"
      } ],
      "hashtags" : [ {
        "text" : "NationalHugDay",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/8KC28Pgf2s",
        "expanded_url" : "http:\/\/www.thedonkeysanctuary.org.uk\/adopt\/ripple",
        "display_url" : "thedonkeysanctuary.org.uk\/adopt\/ripple"
      } ]
    },
    "geo" : { },
    "id_str" : "690177003480313856",
    "text" : "Adoption donkey Ripple loves a good cuddle, could you adopt him? &gt;&gt; https:\/\/t.co\/8KC28Pgf2s #NationalHugDay https:\/\/t.co\/P8IdEx55rp",
    "id" : 690177003480313856,
    "created_at" : "2016-01-21 14:19:55 +0000",
    "user" : {
      "name" : "Adopt a Donkey",
      "screen_name" : "AdoptADonkey",
      "protected" : false,
      "id_str" : "1527563096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573062861146095616\/Q0qy5bIj_normal.png",
      "id" : 1527563096,
      "verified" : false
    }
  },
  "id" : 690178066983841792,
  "created_at" : "2016-01-21 14:24:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kayla Reed",
      "screen_name" : "RE_invent_ED",
      "indices" : [ 3, 16 ],
      "id_str" : "210576889",
      "id" : 210576889
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TamirRice",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "Flint",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689994910544588800",
  "text" : "RT @RE_invent_ED: So the grand jury didn't vote in the #TamirRice case AND the EPA knew about the toxic water in #Flint. \n\nAnd yall still a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TamirRice",
        "indices" : [ 37, 47 ]
      }, {
        "text" : "Flint",
        "indices" : [ 95, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689931108234866688",
    "text" : "So the grand jury didn't vote in the #TamirRice case AND the EPA knew about the toxic water in #Flint. \n\nAnd yall still asking why we fight?",
    "id" : 689931108234866688,
    "created_at" : "2016-01-20 22:02:49 +0000",
    "user" : {
      "name" : "Kayla Reed",
      "screen_name" : "RE_invent_ED",
      "protected" : false,
      "id_str" : "210576889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764295903285051392\/7Ia1KfVk_normal.jpg",
      "id" : 210576889,
      "verified" : false
    }
  },
  "id" : 689994910544588800,
  "created_at" : "2016-01-21 02:16:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thepoliticalcat",
      "screen_name" : "thepoliticalcat",
      "indices" : [ 3, 19 ],
      "id_str" : "17686959",
      "id" : 17686959
    }, {
      "name" : "Justin Miller",
      "screen_name" : "justinjm1",
      "indices" : [ 87, 97 ],
      "id_str" : "164397041",
      "id" : 164397041
    }, {
      "name" : "geejayeff",
      "screen_name" : "geejayeff",
      "indices" : [ 98, 108 ],
      "id_str" : "17164664",
      "id" : 17164664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TamirRice",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689963048363298816",
  "text" : "RT @thepoliticalcat: This is interesting. So the prosecutor LIED to us all? #TamirRice @justinjm1 @geejayeff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justin Miller",
        "screen_name" : "justinjm1",
        "indices" : [ 66, 76 ],
        "id_str" : "164397041",
        "id" : 164397041
      }, {
        "name" : "geejayeff",
        "screen_name" : "geejayeff",
        "indices" : [ 77, 87 ],
        "id_str" : "17164664",
        "id" : 17164664
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TamirRice",
        "indices" : [ 55, 65 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "689909797030858752",
    "geo" : { },
    "id_str" : "689914303902670848",
    "in_reply_to_user_id" : 164397041,
    "text" : "This is interesting. So the prosecutor LIED to us all? #TamirRice @justinjm1 @geejayeff",
    "id" : 689914303902670848,
    "in_reply_to_status_id" : 689909797030858752,
    "created_at" : "2016-01-20 20:56:02 +0000",
    "in_reply_to_screen_name" : "justinjm1",
    "in_reply_to_user_id_str" : "164397041",
    "user" : {
      "name" : "thepoliticalcat",
      "screen_name" : "thepoliticalcat",
      "protected" : false,
      "id_str" : "17686959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3167919117\/5b88917ec1fbf457489d0dd010fa18bc_normal.png",
      "id" : 17686959,
      "verified" : false
    }
  },
  "id" : 689963048363298816,
  "created_at" : "2016-01-21 00:09:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/ExnzRGn55O",
      "expanded_url" : "https:\/\/twitter.com\/JamiaStarheart\/status\/689835944195837952",
      "display_url" : "twitter.com\/JamiaStarheart\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689838074600263681",
  "text" : "im a bernie fan but this made me chuckle... : D https:\/\/t.co\/ExnzRGn55O",
  "id" : 689838074600263681,
  "created_at" : "2016-01-20 15:53:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/PMMQm6BWoq",
      "expanded_url" : "http:\/\/m.dailykos.com\/stories\/1471781",
      "display_url" : "m.dailykos.com\/stories\/1471781"
    } ]
  },
  "geo" : { },
  "id_str" : "689583102486802432",
  "text" : "RT @gemswinc: Charles Koch's decades-long plot to overthrow the government https:\/\/t.co\/PMMQm6BWoq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/PMMQm6BWoq",
        "expanded_url" : "http:\/\/m.dailykos.com\/stories\/1471781",
        "display_url" : "m.dailykos.com\/stories\/1471781"
      } ]
    },
    "geo" : { },
    "id_str" : "689580939488411652",
    "text" : "Charles Koch's decades-long plot to overthrow the government https:\/\/t.co\/PMMQm6BWoq",
    "id" : 689580939488411652,
    "created_at" : "2016-01-19 22:51:22 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 689583102486802432,
  "created_at" : "2016-01-19 22:59:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Neyhart",
      "screen_name" : "JenniferNeyhart",
      "indices" : [ 0, 16 ],
      "id_str" : "17425748",
      "id" : 17425748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "689580625028890626",
  "geo" : { },
  "id_str" : "689582627234381824",
  "in_reply_to_user_id" : 17425748,
  "text" : "@JenniferNeyhart it lies like a rug.. step on it! (((hugs)))",
  "id" : 689582627234381824,
  "in_reply_to_status_id" : 689580625028890626,
  "created_at" : "2016-01-19 22:58:04 +0000",
  "in_reply_to_screen_name" : "JenniferNeyhart",
  "in_reply_to_user_id_str" : "17425748",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/6DMkAS3Y78",
      "expanded_url" : "https:\/\/twitter.com\/OMGFacts\/status\/689579374790635520",
      "display_url" : "twitter.com\/OMGFacts\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689581729787568131",
  "text" : "hmm.. i want an explanation of this (assuming if true) #science https:\/\/t.co\/6DMkAS3Y78",
  "id" : 689581729787568131,
  "created_at" : "2016-01-19 22:54:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tobyjack",
      "screen_name" : "tobyjack",
      "indices" : [ 3, 12 ],
      "id_str" : "18817574",
      "id" : 18817574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/QzpPmQHuIg",
      "expanded_url" : "https:\/\/twitter.com\/BreeNewsome\/status\/689259718385217536",
      "display_url" : "twitter.com\/BreeNewsome\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689575710915182593",
  "text" : "RT @tobyjack: Intentionally caused https:\/\/t.co\/QzpPmQHuIg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 44 ],
        "url" : "https:\/\/t.co\/QzpPmQHuIg",
        "expanded_url" : "https:\/\/twitter.com\/BreeNewsome\/status\/689259718385217536",
        "display_url" : "twitter.com\/BreeNewsome\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689535183389720577",
    "text" : "Intentionally caused https:\/\/t.co\/QzpPmQHuIg",
    "id" : 689535183389720577,
    "created_at" : "2016-01-19 19:49:33 +0000",
    "user" : {
      "name" : "tobyjack",
      "screen_name" : "tobyjack",
      "protected" : false,
      "id_str" : "18817574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793152497334362112\/c_UfVznb_normal.jpg",
      "id" : 18817574,
      "verified" : false
    }
  },
  "id" : 689575710915182593,
  "created_at" : "2016-01-19 22:30:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "indices" : [ 3, 14 ],
      "id_str" : "49698134",
      "id" : 49698134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689575457990246401",
  "text" : "RT @JoyAnnReid: If Iran is so implacably evil, why did Dick Cheney as Halliburton's CEO evade US sanctions to do business with them? https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/SUb05PFmkB",
        "expanded_url" : "http:\/\/thinkprogress.org\/politics\/2007\/11\/26\/17845\/cheney-halliburton-iran\/",
        "display_url" : "thinkprogress.org\/politics\/2007\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688399737016455168",
    "text" : "If Iran is so implacably evil, why did Dick Cheney as Halliburton's CEO evade US sanctions to do business with them? https:\/\/t.co\/SUb05PFmkB",
    "id" : 688399737016455168,
    "created_at" : "2016-01-16 16:37:41 +0000",
    "user" : {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "protected" : false,
      "id_str" : "49698134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796364947517161472\/O7jPbVMJ_normal.jpg",
      "id" : 49698134,
      "verified" : true
    }
  },
  "id" : 689575457990246401,
  "created_at" : "2016-01-19 22:29:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanessa Bee Designs",
      "screen_name" : "vanessabeedes",
      "indices" : [ 51, 65 ],
      "id_str" : "3416056083",
      "id" : 3416056083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yarn",
      "indices" : [ 114, 119 ]
    }, {
      "text" : "knitting",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689575260023341057",
  "text" : "RT @woolngrace: Love my giveaway win tote bag from @vanessabeedes; another place to *ahem* hide yarn from my SO \uD83D\uDE06 #yarn #knitting https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vanessa Bee Designs",
        "screen_name" : "vanessabeedes",
        "indices" : [ 35, 49 ],
        "id_str" : "3416056083",
        "id" : 3416056083
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/woolngrace\/status\/689569602326675456\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/9IMScrFpjv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZHX4cNWwAAgh3B.jpg",
        "id_str" : "689569582609252352",
        "id" : 689569582609252352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZHX4cNWwAAgh3B.jpg",
        "sizes" : [ {
          "h" : 1281,
          "resize" : "fit",
          "w" : 1281
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9IMScrFpjv"
      } ],
      "hashtags" : [ {
        "text" : "yarn",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "knitting",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689569602326675456",
    "text" : "Love my giveaway win tote bag from @vanessabeedes; another place to *ahem* hide yarn from my SO \uD83D\uDE06 #yarn #knitting https:\/\/t.co\/9IMScrFpjv",
    "id" : 689569602326675456,
    "created_at" : "2016-01-19 22:06:19 +0000",
    "user" : {
      "name" : "Grace Alice",
      "screen_name" : "brandlewizzy",
      "protected" : false,
      "id_str" : "442378825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703380367525482497\/YJpeT9VB_normal.jpg",
      "id" : 442378825,
      "verified" : false
    }
  },
  "id" : 689575260023341057,
  "created_at" : "2016-01-19 22:28:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/2wJutuem4f",
      "expanded_url" : "https:\/\/twitter.com\/nyclass\/status\/689208935400734722",
      "display_url" : "twitter.com\/nyclass\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689564788746231810",
  "text" : "abso-effin-lutely! horses dont belong in the city! https:\/\/t.co\/2wJutuem4f",
  "id" : 689564788746231810,
  "created_at" : "2016-01-19 21:47:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Filipovic",
      "screen_name" : "JillFilipovic",
      "indices" : [ 3, 17 ],
      "id_str" : "16378093",
      "id" : 16378093
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 50, 58 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/MU4mOaWmnV",
      "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/projects\/portraits\/voters-of-the-people",
      "display_url" : "nytimes.com\/interactive\/pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689564524471541761",
  "text" : "RT @JillFilipovic: This is an incredibly powerful @nytimes interactive feature. Check it out. https:\/\/t.co\/MU4mOaWmnV https:\/\/t.co\/RbxARbrp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 31, 39 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JillFilipovic\/status\/689509405671358464\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/RbxARbrpOS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZGhJQiVIAAf78o.png",
        "id_str" : "689509398394249216",
        "id" : 689509398394249216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZGhJQiVIAAf78o.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 493
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 493
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 493
        } ],
        "display_url" : "pic.twitter.com\/RbxARbrpOS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/MU4mOaWmnV",
        "expanded_url" : "http:\/\/www.nytimes.com\/interactive\/projects\/portraits\/voters-of-the-people",
        "display_url" : "nytimes.com\/interactive\/pr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "689509405671358464",
    "text" : "This is an incredibly powerful @nytimes interactive feature. Check it out. https:\/\/t.co\/MU4mOaWmnV https:\/\/t.co\/RbxARbrpOS",
    "id" : 689509405671358464,
    "created_at" : "2016-01-19 18:07:07 +0000",
    "user" : {
      "name" : "Jill Filipovic",
      "screen_name" : "JillFilipovic",
      "protected" : false,
      "id_str" : "16378093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791533015004577792\/tHODupl8_normal.jpg",
      "id" : 16378093,
      "verified" : true
    }
  },
  "id" : 689564524471541761,
  "created_at" : "2016-01-19 21:46:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "indices" : [ 3, 15 ],
      "id_str" : "6705042",
      "id" : 6705042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AllTrials",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/sDtridmQxO",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/world-europe-35320895",
      "display_url" : "bbc.co.uk\/news\/world-eur\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689522758187945985",
  "text" : "RT @bengoldacre: Ph1 trial in France, disaster. Ph1 data STILL hidden despite recs after TGN1412 #AllTrials https:\/\/t.co\/sDtridmQxO https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bengoldacre\/status\/687980310596874240\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/9yf7usdeTX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYwyCU9WAAAlz90.png",
        "id_str" : "687979858647973888",
        "id" : 687979858647973888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYwyCU9WAAAlz90.png",
        "sizes" : [ {
          "h" : 1659,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 148
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 260
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1659,
          "resize" : "fit",
          "w" : 360
        } ],
        "display_url" : "pic.twitter.com\/9yf7usdeTX"
      } ],
      "hashtags" : [ {
        "text" : "AllTrials",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/sDtridmQxO",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/world-europe-35320895",
        "display_url" : "bbc.co.uk\/news\/world-eur\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "687980310596874240",
    "text" : "Ph1 trial in France, disaster. Ph1 data STILL hidden despite recs after TGN1412 #AllTrials https:\/\/t.co\/sDtridmQxO https:\/\/t.co\/9yf7usdeTX",
    "id" : 687980310596874240,
    "created_at" : "2016-01-15 12:51:02 +0000",
    "user" : {
      "name" : "ben goldacre",
      "screen_name" : "bengoldacre",
      "protected" : false,
      "id_str" : "6705042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523118410419286016\/qXTUFTZR_normal.png",
      "id" : 6705042,
      "verified" : true
    }
  },
  "id" : 689522758187945985,
  "created_at" : "2016-01-19 19:00:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "indices" : [ 3, 14 ],
      "id_str" : "1922414958",
      "id" : 1922414958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LymeDisease",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/wUECP2ekI1",
      "expanded_url" : "https:\/\/peerj.com\/articles\/322\/",
      "display_url" : "peerj.com\/articles\/322\/"
    } ]
  },
  "geo" : { },
  "id_str" : "689522136667545600",
  "text" : "RT @LonnieRhea: A) Severity of chronic #LymeDisease symptoms \nB) Number of symptom days\/month. \nhttps:\/\/t.co\/wUECP2ekI1 https:\/\/t.co\/oddMQg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LonnieRhea\/status\/689319004976975873\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/oddMQgfGDe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZDz-q2UsAAZtvt.jpg",
        "id_str" : "689319000967262208",
        "id" : 689319000967262208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZDz-q2UsAAZtvt.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 968
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 968
        }, {
          "h" : 635,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oddMQgfGDe"
      } ],
      "hashtags" : [ {
        "text" : "LymeDisease",
        "indices" : [ 23, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/wUECP2ekI1",
        "expanded_url" : "https:\/\/peerj.com\/articles\/322\/",
        "display_url" : "peerj.com\/articles\/322\/"
      } ]
    },
    "geo" : { },
    "id_str" : "689319004976975873",
    "text" : "A) Severity of chronic #LymeDisease symptoms \nB) Number of symptom days\/month. \nhttps:\/\/t.co\/wUECP2ekI1 https:\/\/t.co\/oddMQgfGDe",
    "id" : 689319004976975873,
    "created_at" : "2016-01-19 05:30:32 +0000",
    "user" : {
      "name" : "Lonnie R Marcum, PT",
      "screen_name" : "LonnieRhea",
      "protected" : false,
      "id_str" : "1922414958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738411243678007297\/OesFzoaA_normal.jpg",
      "id" : 1922414958,
      "verified" : false
    }
  },
  "id" : 689522136667545600,
  "created_at" : "2016-01-19 18:57:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/OC31BHY8lF",
      "expanded_url" : "https:\/\/shar.es\/1hovzM",
      "display_url" : "shar.es\/1hovzM"
    } ]
  },
  "geo" : { },
  "id_str" : "689471563221983234",
  "text" : "interesting to ponder... Hidden Origins with Michael Tellinger https:\/\/t.co\/OC31BHY8lF",
  "id" : 689471563221983234,
  "created_at" : "2016-01-19 15:36:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689467298126495746",
  "text" : "I'm 62% through The Island of Knowledge (Unabridged) by Marcelo Gleiser, narrated by William Neenan on my Audible app. #physics",
  "id" : 689467298126495746,
  "created_at" : "2016-01-19 15:19:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Voter Valerie Z",
      "screen_name" : "TwitWittyVal",
      "indices" : [ 3, 16 ],
      "id_str" : "117236432",
      "id" : 117236432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689256313499611137",
  "text" : "RT @TwitWittyVal: When an artist dies, and you didn't appreciate their art...keep in mind that the person next to you may have found their \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689250062094893056",
    "text" : "When an artist dies, and you didn't appreciate their art...keep in mind that the person next to you may have found their own purpose in it.",
    "id" : 689250062094893056,
    "created_at" : "2016-01-19 00:56:35 +0000",
    "user" : {
      "name" : "Voter Valerie Z",
      "screen_name" : "TwitWittyVal",
      "protected" : false,
      "id_str" : "117236432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800150083949895680\/Bo7IQ2cI_normal.jpg",
      "id" : 117236432,
      "verified" : false
    }
  },
  "id" : 689256313499611137,
  "created_at" : "2016-01-19 01:21:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    }, {
      "name" : "TV3",
      "screen_name" : "TV3Ireland",
      "indices" : [ 71, 82 ],
      "id_str" : "22609609",
      "id" : 22609609
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/689148045733289985\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/IPHvSfKc5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZBYfwaWYAIDFN0.jpg",
      "id_str" : "689148045582295042",
      "id" : 689148045582295042,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZBYfwaWYAIDFN0.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IPHvSfKc5E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689167633392992257",
  "text" : "RT @ZwartblesIE: Little Dorrit makes herself know by trotting into the @TV3Ireland news room https:\/\/t.co\/IPHvSfKc5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TV3",
        "screen_name" : "TV3Ireland",
        "indices" : [ 54, 65 ],
        "id_str" : "22609609",
        "id" : 22609609
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/689148045733289985\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/IPHvSfKc5E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZBYfwaWYAIDFN0.jpg",
        "id_str" : "689148045582295042",
        "id" : 689148045582295042,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZBYfwaWYAIDFN0.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IPHvSfKc5E"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689148045733289985",
    "text" : "Little Dorrit makes herself know by trotting into the @TV3Ireland news room https:\/\/t.co\/IPHvSfKc5E",
    "id" : 689148045733289985,
    "created_at" : "2016-01-18 18:11:12 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 689167633392992257,
  "created_at" : "2016-01-18 19:29:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter B. Hoffmeister",
      "screen_name" : "peterbrownhoff",
      "indices" : [ 3, 18 ],
      "id_str" : "276819952",
      "id" : 276819952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689137390888349696",
  "text" : "RT @peterbrownhoff: Tyrus Books is giving away copies of my novel Graphic The Valley today to celebrate the National Parks' 100th... https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/vri7X8MFqG",
        "expanded_url" : "http:\/\/fb.me\/M4VU4fI1",
        "display_url" : "fb.me\/M4VU4fI1"
      } ]
    },
    "geo" : { },
    "id_str" : "689124769128665089",
    "text" : "Tyrus Books is giving away copies of my novel Graphic The Valley today to celebrate the National Parks' 100th... https:\/\/t.co\/vri7X8MFqG",
    "id" : 689124769128665089,
    "created_at" : "2016-01-18 16:38:42 +0000",
    "user" : {
      "name" : "Peter B. Hoffmeister",
      "screen_name" : "peterbrownhoff",
      "protected" : false,
      "id_str" : "276819952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483642400330371072\/vUjDOBbR_normal.jpeg",
      "id" : 276819952,
      "verified" : false
    }
  },
  "id" : 689137390888349696,
  "created_at" : "2016-01-18 17:28:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blackops",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "military",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "thriller",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/WGWp0RdXny",
      "expanded_url" : "https:\/\/twitter.com\/BlackstoneAudio\/status\/689110175643480065",
      "display_url" : "twitter.com\/BlackstoneAudi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689126584654127105",
  "text" : "this sounds interesting.. #blackops #military #thriller https:\/\/t.co\/WGWp0RdXny",
  "id" : 689126584654127105,
  "created_at" : "2016-01-18 16:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/688962522653822976\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/921YKaB3FK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY-vwtoWsAAvvxE.jpg",
      "id_str" : "688962519428411392",
      "id" : 688962519428411392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY-vwtoWsAAvvxE.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/921YKaB3FK"
    } ],
    "hashtags" : [ {
      "text" : "yearofmaking",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689077875253886977",
  "text" : "RT @ErinEFarley: Lily of the valley tonight. #yearofmaking https:\/\/t.co\/921YKaB3FK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/688962522653822976\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/921YKaB3FK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY-vwtoWsAAvvxE.jpg",
        "id_str" : "688962519428411392",
        "id" : 688962519428411392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY-vwtoWsAAvvxE.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/921YKaB3FK"
      } ],
      "hashtags" : [ {
        "text" : "yearofmaking",
        "indices" : [ 28, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688962522653822976",
    "text" : "Lily of the valley tonight. #yearofmaking https:\/\/t.co\/921YKaB3FK",
    "id" : 688962522653822976,
    "created_at" : "2016-01-18 05:54:00 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 689077875253886977,
  "created_at" : "2016-01-18 13:32:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "indices" : [ 3, 14 ],
      "id_str" : "2441608651",
      "id" : 2441608651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/689061643938992128\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/KxVY5mQwj2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZAJ6cuU0AAZ19W.jpg",
      "id_str" : "689061642735243264",
      "id" : 689061642735243264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZAJ6cuU0AAZ19W.jpg",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2649,
        "resize" : "fit",
        "w" : 3865
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KxVY5mQwj2"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 38, 44 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "689077807146733568",
  "text" : "RT @mido3bitte: looking up at the sky #birds #wildlife https:\/\/t.co\/KxVY5mQwj2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mido3bitte\/status\/689061643938992128\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/KxVY5mQwj2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZAJ6cuU0AAZ19W.jpg",
        "id_str" : "689061642735243264",
        "id" : 689061642735243264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZAJ6cuU0AAZ19W.jpg",
        "sizes" : [ {
          "h" : 702,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2649,
          "resize" : "fit",
          "w" : 3865
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KxVY5mQwj2"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 22, 28 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "689061643938992128",
    "text" : "looking up at the sky #birds #wildlife https:\/\/t.co\/KxVY5mQwj2",
    "id" : 689061643938992128,
    "created_at" : "2016-01-18 12:27:52 +0000",
    "user" : {
      "name" : "Mido",
      "screen_name" : "mido3bitte",
      "protected" : false,
      "id_str" : "2441608651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746727881498206208\/tfRux6Hm_normal.jpg",
      "id" : 2441608651,
      "verified" : false
    }
  },
  "id" : 689077807146733568,
  "created_at" : "2016-01-18 13:32:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Western Morning News",
      "screen_name" : "WMNNews",
      "indices" : [ 3, 11 ],
      "id_str" : "14396151",
      "id" : 14396151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WMNNews\/status\/688850837318189056\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/kn8Btukgyx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY7ONFEWYAAktfv.jpg",
      "id_str" : "688714517128306688",
      "id" : 688714517128306688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY7ONFEWYAAktfv.jpg",
      "sizes" : [ {
        "h" : 413,
        "resize" : "fit",
        "w" : 569
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 569
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 569
      } ],
      "display_url" : "pic.twitter.com\/kn8Btukgyx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/mcXpNDbnt7",
      "expanded_url" : "http:\/\/bit.ly\/1U3XD9H",
      "display_url" : "bit.ly\/1U3XD9H"
    } ]
  },
  "geo" : { },
  "id_str" : "688866033776619520",
  "text" : "RT @WMNNews: A light-hearted one to end the day - cow cloud picture goes viral: https:\/\/t.co\/mcXpNDbnt7 https:\/\/t.co\/kn8Btukgyx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WMNNews\/status\/688850837318189056\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/kn8Btukgyx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY7ONFEWYAAktfv.jpg",
        "id_str" : "688714517128306688",
        "id" : 688714517128306688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY7ONFEWYAAktfv.jpg",
        "sizes" : [ {
          "h" : 413,
          "resize" : "fit",
          "w" : 569
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 569
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 569
        } ],
        "display_url" : "pic.twitter.com\/kn8Btukgyx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/mcXpNDbnt7",
        "expanded_url" : "http:\/\/bit.ly\/1U3XD9H",
        "display_url" : "bit.ly\/1U3XD9H"
      } ]
    },
    "geo" : { },
    "id_str" : "688850837318189056",
    "text" : "A light-hearted one to end the day - cow cloud picture goes viral: https:\/\/t.co\/mcXpNDbnt7 https:\/\/t.co\/kn8Btukgyx",
    "id" : 688850837318189056,
    "created_at" : "2016-01-17 22:30:12 +0000",
    "user" : {
      "name" : "Western Morning News",
      "screen_name" : "WMNNews",
      "protected" : false,
      "id_str" : "14396151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795998996498104321\/Xp_UvRrH_normal.jpg",
      "id" : 14396151,
      "verified" : true
    }
  },
  "id" : 688866033776619520,
  "created_at" : "2016-01-17 23:30:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688865443474444289",
  "text" : "cross-eyed from looking at cat condos, cat dishes. cant decide. ugh.",
  "id" : 688865443474444289,
  "created_at" : "2016-01-17 23:28:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "feedly",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/FIEsRxABhQ",
      "expanded_url" : "http:\/\/scripting.com\/liveblog\/users\/davewiner\/2016\/01\/17\/0880.html",
      "display_url" : "scripting.com\/liveblog\/users\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688815183779786753",
  "text" : "Black Lives Matter, explained https:\/\/t.co\/FIEsRxABhQ #tech #feedly",
  "id" : 688815183779786753,
  "created_at" : "2016-01-17 20:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HighBridge Audio",
      "screen_name" : "HighBridgeAudio",
      "indices" : [ 3, 19 ],
      "id_str" : "19552359",
      "id" : 19552359
    }, {
      "name" : "Thomas E. Perry",
      "screen_name" : "TPerryauthor",
      "indices" : [ 83, 96 ],
      "id_str" : "269055497",
      "id" : 269055497
    }, {
      "name" : "MysteriousPress.com",
      "screen_name" : "eMysteries",
      "indices" : [ 98, 109 ],
      "id_str" : "346852354",
      "id" : 346852354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/P03deWoC05",
      "expanded_url" : "http:\/\/highbridgecompany.com\/blog\/2016\/01\/11\/featured-audio-giveaway-january-2016-forty-thieves\/",
      "display_url" : "highbridgecompany.com\/blog\/2016\/01\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688814099615092736",
  "text" : "RT @HighBridgeAudio: Don't miss your chance to win a free copy of FORTY THIEVES by @TPerryauthor! @eMysteries https:\/\/t.co\/P03deWoC05",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Thomas E. Perry",
        "screen_name" : "TPerryauthor",
        "indices" : [ 62, 75 ],
        "id_str" : "269055497",
        "id" : 269055497
      }, {
        "name" : "MysteriousPress.com",
        "screen_name" : "eMysteries",
        "indices" : [ 77, 88 ],
        "id_str" : "346852354",
        "id" : 346852354
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/P03deWoC05",
        "expanded_url" : "http:\/\/highbridgecompany.com\/blog\/2016\/01\/11\/featured-audio-giveaway-january-2016-forty-thieves\/",
        "display_url" : "highbridgecompany.com\/blog\/2016\/01\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688800636759068672",
    "text" : "Don't miss your chance to win a free copy of FORTY THIEVES by @TPerryauthor! @eMysteries https:\/\/t.co\/P03deWoC05",
    "id" : 688800636759068672,
    "created_at" : "2016-01-17 19:10:43 +0000",
    "user" : {
      "name" : "HighBridge Audio",
      "screen_name" : "HighBridgeAudio",
      "protected" : false,
      "id_str" : "19552359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461187019364765697\/Pqgn_3iJ_normal.jpeg",
      "id" : 19552359,
      "verified" : false
    }
  },
  "id" : 688814099615092736,
  "created_at" : "2016-01-17 20:04:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/2VD6nhHfpg",
      "expanded_url" : "https:\/\/twitter.com\/onealexharms\/status\/688764304284348416",
      "display_url" : "twitter.com\/onealexharms\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688783680421126144",
  "text" : "precious  https:\/\/t.co\/2VD6nhHfpg",
  "id" : 688783680421126144,
  "created_at" : "2016-01-17 18:03:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Harms",
      "screen_name" : "raelifin",
      "indices" : [ 3, 12 ],
      "id_str" : "16637299",
      "id" : 16637299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/4NnsUHyxBs",
      "expanded_url" : "http:\/\/raelifin.com\/crystalsociety\/",
      "display_url" : "raelifin.com\/crystalsociety\/"
    } ]
  },
  "geo" : { },
  "id_str" : "688780804852465664",
  "text" : "RT @raelifin: My new scifi novel, Crystal Society, comes out on the 23rd! Curious? Here's an excerpt: https:\/\/t.co\/4NnsUHyxBs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/4NnsUHyxBs",
        "expanded_url" : "http:\/\/raelifin.com\/crystalsociety\/",
        "display_url" : "raelifin.com\/crystalsociety\/"
      } ]
    },
    "geo" : { },
    "id_str" : "688757097018847232",
    "text" : "My new scifi novel, Crystal Society, comes out on the 23rd! Curious? Here's an excerpt: https:\/\/t.co\/4NnsUHyxBs",
    "id" : 688757097018847232,
    "created_at" : "2016-01-17 16:17:43 +0000",
    "user" : {
      "name" : "Max Harms",
      "screen_name" : "raelifin",
      "protected" : false,
      "id_str" : "16637299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694238765343248384\/femwW-Q6_normal.png",
      "id" : 16637299,
      "verified" : false
    }
  },
  "id" : 688780804852465664,
  "created_at" : "2016-01-17 17:51:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wild and Wonderful",
      "screen_name" : "EPWVLaw",
      "indices" : [ 3, 11 ],
      "id_str" : "165026086",
      "id" : 165026086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688780592280944643",
  "text" : "RT @EPWVLaw: It still comes down the fundamental question: What right does the gov't have to say that you can't ingest a plant if you want?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Journal",
        "screen_name" : "cspanwj",
        "indices" : [ 127, 135 ],
        "id_str" : "15923226",
        "id" : 15923226
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688733197048385536",
    "text" : "It still comes down the fundamental question: What right does the gov't have to say that you can't ingest a plant if you want? @cspanwj",
    "id" : 688733197048385536,
    "created_at" : "2016-01-17 14:42:44 +0000",
    "user" : {
      "name" : "Wild and Wonderful",
      "screen_name" : "EPWVLaw",
      "protected" : false,
      "id_str" : "165026086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3122370121\/ed113cce13e378f39b0680571cfe8186_normal.jpeg",
      "id" : 165026086,
      "verified" : false
    }
  },
  "id" : 688780592280944643,
  "created_at" : "2016-01-17 17:51:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/HAQHSuSA0d",
      "expanded_url" : "https:\/\/vine.co\/v\/iOpMuxbz2Bh",
      "display_url" : "vine.co\/v\/iOpMuxbz2Bh"
    } ]
  },
  "geo" : { },
  "id_str" : "688780337791524864",
  "text" : "RT @ZwartblesIE: Got to itch that scratch then catch up with mammy on the daily commute https:\/\/t.co\/HAQHSuSA0d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/HAQHSuSA0d",
        "expanded_url" : "https:\/\/vine.co\/v\/iOpMuxbz2Bh",
        "display_url" : "vine.co\/v\/iOpMuxbz2Bh"
      } ]
    },
    "geo" : { },
    "id_str" : "688662279672434688",
    "text" : "Got to itch that scratch then catch up with mammy on the daily commute https:\/\/t.co\/HAQHSuSA0d",
    "id" : 688662279672434688,
    "created_at" : "2016-01-17 10:00:56 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 688780337791524864,
  "created_at" : "2016-01-17 17:50:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil",
      "screen_name" : "SheppeyWildlife",
      "indices" : [ 3, 19 ],
      "id_str" : "118345168",
      "id" : 118345168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SheppeyWildlife\/status\/688778474144837633\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/r59s3rPzCv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY8IXzbWkAALz2q.jpg",
      "id_str" : "688778473045921792",
      "id" : 688778473045921792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY8IXzbWkAALz2q.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/r59s3rPzCv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688778814982373377",
  "text" : "RT @SheppeyWildlife: Swans in the mist. https:\/\/t.co\/r59s3rPzCv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SheppeyWildlife\/status\/688778474144837633\/photo\/1",
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/r59s3rPzCv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY8IXzbWkAALz2q.jpg",
        "id_str" : "688778473045921792",
        "id" : 688778473045921792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY8IXzbWkAALz2q.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/r59s3rPzCv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688778474144837633",
    "text" : "Swans in the mist. https:\/\/t.co\/r59s3rPzCv",
    "id" : 688778474144837633,
    "created_at" : "2016-01-17 17:42:39 +0000",
    "user" : {
      "name" : "Phil",
      "screen_name" : "SheppeyWildlife",
      "protected" : false,
      "id_str" : "118345168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1780960937\/Barn_Owl_normal.JPG",
      "id" : 118345168,
      "verified" : false
    }
  },
  "id" : 688778814982373377,
  "created_at" : "2016-01-17 17:44:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "feedly",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/FtIiKxucLk",
      "expanded_url" : "http:\/\/christianity-without-the-religion.blogspot.com\/2016\/01\/stop-trying-to-get-saved-greg-albrecht.html",
      "display_url" : "\u2026ity-without-the-religion.blogspot.com\/2016\/01\/stop-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688778107948511233",
  "text" : "Stop Trying to Get Saved - Greg Albrecht https:\/\/t.co\/FtIiKxucLk #religion #feedly",
  "id" : 688778107948511233,
  "created_at" : "2016-01-17 17:41:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "upvoted",
      "screen_name" : "upvoted",
      "indices" : [ 90, 98 ],
      "id_str" : "128179820",
      "id" : 128179820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/onYxc4CwhD",
      "expanded_url" : "http:\/\/wp.me\/p6xgta-oS",
      "display_url" : "wp.me\/p6xgta-oS"
    } ]
  },
  "geo" : { },
  "id_str" : "688773452006879232",
  "text" : "How Three Survivors of Suicide Spent Their Last Days On Earth https:\/\/t.co\/onYxc4CwhD via @upvoted",
  "id" : 688773452006879232,
  "created_at" : "2016-01-17 17:22:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wally Callahan",
      "screen_name" : "Wally_Callahan",
      "indices" : [ 3, 18 ],
      "id_str" : "960967081",
      "id" : 960967081
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OccupyDemocrats\/status\/659835287007322116\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/eNPiqSqdHj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSg0snKUsAEHNFj.jpg",
      "id_str" : "659835286440947713",
      "id" : 659835286440947713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSg0snKUsAEHNFj.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eNPiqSqdHj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688765765248544769",
  "text" : "RT @Wally_Callahan: This is ridiculous. https:\/\/t.co\/eNPiqSqdHj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OccupyDemocrats\/status\/659835287007322116\/photo\/1",
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/eNPiqSqdHj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSg0snKUsAEHNFj.jpg",
        "id_str" : "659835286440947713",
        "id" : 659835286440947713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSg0snKUsAEHNFj.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/eNPiqSqdHj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688392662659891200",
    "text" : "This is ridiculous. https:\/\/t.co\/eNPiqSqdHj",
    "id" : 688392662659891200,
    "created_at" : "2016-01-16 16:09:35 +0000",
    "user" : {
      "name" : "Wally Callahan",
      "screen_name" : "Wally_Callahan",
      "protected" : false,
      "id_str" : "960967081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/559758006749913088\/Hjqp1Odp_normal.jpeg",
      "id" : 960967081,
      "verified" : false
    }
  },
  "id" : 688765765248544769,
  "created_at" : "2016-01-17 16:52:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Shiffman",
      "screen_name" : "WhySharksMatter",
      "indices" : [ 3, 19 ],
      "id_str" : "66182591",
      "id" : 66182591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OceanOptimism",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/kFSzyuNSoP",
      "expanded_url" : "http:\/\/buff.ly\/1OKRVba",
      "display_url" : "buff.ly\/1OKRVba"
    } ]
  },
  "geo" : { },
  "id_str" : "688764569754423296",
  "text" : "RT @WhySharksMatter: Angler gives up world record to release massive  shark alive!  Please RT! https:\/\/t.co\/kFSzyuNSoP #OceanOptimism https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhySharksMatter\/status\/688413019668393984\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/iIAaBBOCgI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY27_nPWAAErH4I.jpg",
        "id_str" : "688413019597045761",
        "id" : 688413019597045761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY27_nPWAAErH4I.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 744
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 744
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/iIAaBBOCgI"
      } ],
      "hashtags" : [ {
        "text" : "OceanOptimism",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/kFSzyuNSoP",
        "expanded_url" : "http:\/\/buff.ly\/1OKRVba",
        "display_url" : "buff.ly\/1OKRVba"
      } ]
    },
    "geo" : { },
    "id_str" : "688413019668393984",
    "text" : "Angler gives up world record to release massive  shark alive!  Please RT! https:\/\/t.co\/kFSzyuNSoP #OceanOptimism https:\/\/t.co\/iIAaBBOCgI",
    "id" : 688413019668393984,
    "created_at" : "2016-01-16 17:30:28 +0000",
    "user" : {
      "name" : "David Shiffman",
      "screen_name" : "WhySharksMatter",
      "protected" : false,
      "id_str" : "66182591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661179923378270208\/rKWB0fow_normal.jpg",
      "id" : 66182591,
      "verified" : true
    }
  },
  "id" : 688764569754423296,
  "created_at" : "2016-01-17 16:47:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9s G_74",
      "screen_name" : "andrespeneke",
      "indices" : [ 3, 16 ],
      "id_str" : "2827263783",
      "id" : 2827263783
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/andrespeneke\/status\/688697903628550144\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/ossRBQCdTS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY6_FKaWAAEiDva.jpg",
      "id_str" : "688697888449363969",
      "id" : 688697888449363969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY6_FKaWAAEiDva.jpg",
      "sizes" : [ {
        "h" : 310,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/ossRBQCdTS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688763979523555329",
  "text" : "RT @andrespeneke: Finding Paradise by Jordan McInally. https:\/\/t.co\/ossRBQCdTS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/andrespeneke\/status\/688697903628550144\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/ossRBQCdTS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY6_FKaWAAEiDva.jpg",
        "id_str" : "688697888449363969",
        "id" : 688697888449363969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY6_FKaWAAEiDva.jpg",
        "sizes" : [ {
          "h" : 310,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 547,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/ossRBQCdTS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688697903628550144",
    "text" : "Finding Paradise by Jordan McInally. https:\/\/t.co\/ossRBQCdTS",
    "id" : 688697903628550144,
    "created_at" : "2016-01-17 12:22:30 +0000",
    "user" : {
      "name" : "Andr\u00E9s G_74",
      "screen_name" : "andrespeneke",
      "protected" : false,
      "id_str" : "2827263783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702757158245502976\/He5tGwUb_normal.jpg",
      "id" : 2827263783,
      "verified" : false
    }
  },
  "id" : 688763979523555329,
  "created_at" : "2016-01-17 16:45:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/688755642270617600\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/aoq6JNSVd7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY7zmymWwAAD-Et.jpg",
      "id_str" : "688755640777490432",
      "id" : 688755640777490432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY7zmymWwAAD-Et.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/aoq6JNSVd7"
    } ],
    "hashtags" : [ {
      "text" : "ncsnow",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "weather",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688763694885412864",
  "text" : "RT @dwaynereaves: #ncsnow #weather https:\/\/t.co\/aoq6JNSVd7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/688755642270617600\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/aoq6JNSVd7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY7zmymWwAAD-Et.jpg",
        "id_str" : "688755640777490432",
        "id" : 688755640777490432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY7zmymWwAAD-Et.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/aoq6JNSVd7"
      } ],
      "hashtags" : [ {
        "text" : "ncsnow",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "weather",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688755642270617600",
    "text" : "#ncsnow #weather https:\/\/t.co\/aoq6JNSVd7",
    "id" : 688755642270617600,
    "created_at" : "2016-01-17 16:11:56 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 688763694885412864,
  "created_at" : "2016-01-17 16:43:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "indices" : [ 3, 15 ],
      "id_str" : "16126957",
      "id" : 16126957
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/688758891245645824\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/B6oufcxg20",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY72fbpWUAInqrR.jpg",
      "id_str" : "688758812891828226",
      "id" : 688758812891828226,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY72fbpWUAInqrR.jpg",
      "sizes" : [ {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1623,
        "resize" : "fit",
        "w" : 2056
      } ],
      "display_url" : "pic.twitter.com\/B6oufcxg20"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688762510053380096",
  "text" : "RT @paul_steele: Frank's having a chat with his neighbour Alfie \uD83D\uDE00 https:\/\/t.co\/B6oufcxg20",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paul_steele\/status\/688758891245645824\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/B6oufcxg20",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY72fbpWUAInqrR.jpg",
        "id_str" : "688758812891828226",
        "id" : 688758812891828226,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY72fbpWUAInqrR.jpg",
        "sizes" : [ {
          "h" : 474,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1623,
          "resize" : "fit",
          "w" : 2056
        } ],
        "display_url" : "pic.twitter.com\/B6oufcxg20"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688758891245645824",
    "text" : "Frank's having a chat with his neighbour Alfie \uD83D\uDE00 https:\/\/t.co\/B6oufcxg20",
    "id" : 688758891245645824,
    "created_at" : "2016-01-17 16:24:50 +0000",
    "user" : {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "protected" : false,
      "id_str" : "16126957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788690057599283200\/-_rph72s_normal.jpg",
      "id" : 16126957,
      "verified" : true
    }
  },
  "id" : 688762510053380096,
  "created_at" : "2016-01-17 16:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physics",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "bigbang",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/H8fKdIyt3A",
      "expanded_url" : "https:\/\/twitter.com\/GrrlScientist\/status\/688758401019572224",
      "display_url" : "twitter.com\/GrrlScientist\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688761998880944128",
  "text" : "was listening to universe beginnings last night on Island of Knowledge #physics #bigbang  https:\/\/t.co\/H8fKdIyt3A",
  "id" : 688761998880944128,
  "created_at" : "2016-01-17 16:37:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Most Awesome One",
      "screen_name" : "mostawesomeblog",
      "indices" : [ 3, 19 ],
      "id_str" : "720896389",
      "id" : 720896389
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/alisonst\/status\/683385956028694528\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/6YJkc9aABI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXvf5_uUEAAysZp.jpg",
      "id_str" : "683385955927986176",
      "id" : 683385955927986176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXvf5_uUEAAysZp.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6YJkc9aABI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688759798347730944",
  "text" : "RT @mostawesomeblog: I don't normally like bumper stickers  . . .   but when I do, it's this one . . .     https:\/\/t.co\/6YJkc9aABI https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/alisonst\/status\/683385956028694528\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/6YJkc9aABI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXvf5_uUEAAysZp.jpg",
        "id_str" : "683385955927986176",
        "id" : 683385955927986176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXvf5_uUEAAysZp.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6YJkc9aABI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/51GtpT1cXR",
        "expanded_url" : "https:\/\/twitter.com\/HuffPostBlog\/status\/688722712173346819",
        "display_url" : "twitter.com\/HuffPostBlog\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688758260896116736",
    "text" : "I don't normally like bumper stickers  . . .   but when I do, it's this one . . .     https:\/\/t.co\/6YJkc9aABI https:\/\/t.co\/51GtpT1cXR",
    "id" : 688758260896116736,
    "created_at" : "2016-01-17 16:22:20 +0000",
    "user" : {
      "name" : "Most Awesome One",
      "screen_name" : "mostawesomeblog",
      "protected" : false,
      "id_str" : "720896389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2948328220\/0394324ea145fa3a478980297faa1b8b_normal.jpeg",
      "id" : 720896389,
      "verified" : false
    }
  },
  "id" : 688759798347730944,
  "created_at" : "2016-01-17 16:28:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 3, 17 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688759547549356032",
  "text" : "RT @Swanwhisperer: On 50 Sightings Total is 117 of Mute Swans Keep your Sightings coming in swanwatch 365 days of data recorded https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Swanwhisperer\/status\/688740399456731136\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/2ASp9oClPK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY7lvisWYAIUoTC.jpg",
        "id_str" : "688740397963698178",
        "id" : 688740397963698178,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY7lvisWYAIUoTC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 1055
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2ASp9oClPK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688740399456731136",
    "text" : "On 50 Sightings Total is 117 of Mute Swans Keep your Sightings coming in swanwatch 365 days of data recorded https:\/\/t.co\/2ASp9oClPK",
    "id" : 688740399456731136,
    "created_at" : "2016-01-17 15:11:22 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 688759547549356032,
  "created_at" : "2016-01-17 16:27:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "indices" : [ 3, 18 ],
      "id_str" : "32522055",
      "id" : 32522055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/H4AnIEG91j",
      "expanded_url" : "http:\/\/youtu.be\/DdXdSL8xNYg",
      "display_url" : "youtu.be\/DdXdSL8xNYg"
    } ]
  },
  "geo" : { },
  "id_str" : "688577902150086656",
  "text" : "RT @Kris_Sacrebleu: Def Leppard - Hysteria https:\/\/t.co\/H4AnIEG91j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 46 ],
        "url" : "https:\/\/t.co\/H4AnIEG91j",
        "expanded_url" : "http:\/\/youtu.be\/DdXdSL8xNYg",
        "display_url" : "youtu.be\/DdXdSL8xNYg"
      } ]
    },
    "geo" : { },
    "id_str" : "688569523947999232",
    "text" : "Def Leppard - Hysteria https:\/\/t.co\/H4AnIEG91j",
    "id" : 688569523947999232,
    "created_at" : "2016-01-17 03:52:22 +0000",
    "user" : {
      "name" : "(((DuneMyThang\u2122)))",
      "screen_name" : "Kris_Sacrebleu",
      "protected" : false,
      "id_str" : "32522055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797097618245459968\/x-mwuPEt_normal.jpg",
      "id" : 32522055,
      "verified" : false
    }
  },
  "id" : 688577902150086656,
  "created_at" : "2016-01-17 04:25:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Clarke",
      "screen_name" : "Mr_Mike_Clarke",
      "indices" : [ 3, 18 ],
      "id_str" : "19768990",
      "id" : 19768990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheySayItsImpossibleBut",
      "indices" : [ 20, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688575352914993153",
  "text" : "RT @Mr_Mike_Clarke: #TheySayItsImpossibleBut you will find Ninja Cat in this pic if you look really REALLY carefully. https:\/\/t.co\/3vAn05XI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Mr_Mike_Clarke\/status\/688444886400405504\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/3vAn05XIvg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY3Y-YlW8AAyR7x.jpg",
        "id_str" : "688444884320186368",
        "id" : 688444884320186368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY3Y-YlW8AAyR7x.jpg",
        "sizes" : [ {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/3vAn05XIvg"
      } ],
      "hashtags" : [ {
        "text" : "TheySayItsImpossibleBut",
        "indices" : [ 0, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688444886400405504",
    "text" : "#TheySayItsImpossibleBut you will find Ninja Cat in this pic if you look really REALLY carefully. https:\/\/t.co\/3vAn05XIvg",
    "id" : 688444886400405504,
    "created_at" : "2016-01-16 19:37:06 +0000",
    "user" : {
      "name" : "Michael Clarke",
      "screen_name" : "Mr_Mike_Clarke",
      "protected" : false,
      "id_str" : "19768990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755456702552674305\/Pc7ciPL3_normal.jpg",
      "id" : 19768990,
      "verified" : false
    }
  },
  "id" : 688575352914993153,
  "created_at" : "2016-01-17 04:15:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/audible_com\/status\/688553830506729472\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ONMwQPsi9J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CY48D4ZWYAAF3KN.png",
      "id_str" : "688553830410248192",
      "id" : 688553830410248192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY48D4ZWYAAF3KN.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ONMwQPsi9J"
    } ],
    "hashtags" : [ {
      "text" : "Audiction",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688575118738624512",
  "text" : "RT @audible_com: Seems your Saturday night is booked. Want to play? #Audiction https:\/\/t.co\/ONMwQPsi9J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/audible_com\/status\/688553830506729472\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/ONMwQPsi9J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CY48D4ZWYAAF3KN.png",
        "id_str" : "688553830410248192",
        "id" : 688553830410248192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CY48D4ZWYAAF3KN.png",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ONMwQPsi9J"
      } ],
      "hashtags" : [ {
        "text" : "Audiction",
        "indices" : [ 51, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688553830506729472",
    "text" : "Seems your Saturday night is booked. Want to play? #Audiction https:\/\/t.co\/ONMwQPsi9J",
    "id" : 688553830506729472,
    "created_at" : "2016-01-17 02:50:00 +0000",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 688575118738624512,
  "created_at" : "2016-01-17 04:14:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/51h0bJ4xNJ",
      "expanded_url" : "https:\/\/twitter.com\/medicatedjane\/status\/688451133740732416",
      "display_url" : "twitter.com\/medicatedjane\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688515281514315776",
  "text" : "RT @bend_time: well well well. more of what our government doesnt want u to know.  https:\/\/t.co\/51h0bJ4xNJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/51h0bJ4xNJ",
        "expanded_url" : "https:\/\/twitter.com\/medicatedjane\/status\/688451133740732416",
        "display_url" : "twitter.com\/medicatedjane\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688504583082016768",
    "text" : "well well well. more of what our government doesnt want u to know.  https:\/\/t.co\/51h0bJ4xNJ",
    "id" : 688504583082016768,
    "created_at" : "2016-01-16 23:34:19 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 688515281514315776,
  "created_at" : "2016-01-17 00:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688512659617132544",
  "text" : "need a new water dish for my kitty and want to get her a smaller cat condo to put on stairs. try to lure her to expand territory.",
  "id" : 688512659617132544,
  "created_at" : "2016-01-17 00:06:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pikachu",
      "screen_name" : "PikachuYumm",
      "indices" : [ 3, 15 ],
      "id_str" : "3484271428",
      "id" : 3484271428
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Piiiikaachu\/status\/487471629211938816\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/ZJMQwsmuaR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrCkvBACUAAk06t.jpg",
      "id_str" : "482066287758036992",
      "id" : 482066287758036992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrCkvBACUAAk06t.jpg",
      "sizes" : [ {
        "h" : 664,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/ZJMQwsmuaR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688422716999884800",
  "text" : "RT @PikachuYumm: Awesome tattoo! https:\/\/t.co\/ZJMQwsmuaR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Piiiikaachu\/status\/487471629211938816\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/ZJMQwsmuaR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrCkvBACUAAk06t.jpg",
        "id_str" : "482066287758036992",
        "id" : 482066287758036992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrCkvBACUAAk06t.jpg",
        "sizes" : [ {
          "h" : 664,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 498
        } ],
        "display_url" : "pic.twitter.com\/ZJMQwsmuaR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688399720490905601",
    "text" : "Awesome tattoo! https:\/\/t.co\/ZJMQwsmuaR",
    "id" : 688399720490905601,
    "created_at" : "2016-01-16 16:37:37 +0000",
    "user" : {
      "name" : "Pikachu",
      "screen_name" : "PikachuYumm",
      "protected" : false,
      "id_str" : "3484271428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637746295176863744\/4ptcZz-S_normal.png",
      "id" : 3484271428,
      "verified" : false
    }
  },
  "id" : 688422716999884800,
  "created_at" : "2016-01-16 18:09:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Harms",
      "screen_name" : "raelifin",
      "indices" : [ 3, 12 ],
      "id_str" : "16637299",
      "id" : 16637299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688422515207737344",
  "text" : "RT @raelifin: If you know someone who enjoys hard science fiction about \"singularity\" sorts of things, please consider sharing news of my b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688392400000122881",
    "text" : "If you know someone who enjoys hard science fiction about \"singularity\" sorts of things, please consider sharing news of my book. \uD83D\uDE03",
    "id" : 688392400000122881,
    "created_at" : "2016-01-16 16:08:32 +0000",
    "user" : {
      "name" : "Max Harms",
      "screen_name" : "raelifin",
      "protected" : false,
      "id_str" : "16637299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694238765343248384\/femwW-Q6_normal.png",
      "id" : 16637299,
      "verified" : false
    }
  },
  "id" : 688422515207737344,
  "created_at" : "2016-01-16 18:08:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Harms",
      "screen_name" : "raelifin",
      "indices" : [ 3, 12 ],
      "id_str" : "16637299",
      "id" : 16637299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688422462254641153",
  "text" : "RT @raelifin: I wrote a science fiction novel called Crystal Society! With luck, you'll be able to read it in just a week! Robots! Aliens! \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688391112495644672",
    "text" : "I wrote a science fiction novel called Crystal Society! With luck, you'll be able to read it in just a week! Robots! Aliens! Cyborgs!",
    "id" : 688391112495644672,
    "created_at" : "2016-01-16 16:03:25 +0000",
    "user" : {
      "name" : "Max Harms",
      "screen_name" : "raelifin",
      "protected" : false,
      "id_str" : "16637299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694238765343248384\/femwW-Q6_normal.png",
      "id" : 16637299,
      "verified" : false
    }
  },
  "id" : 688422462254641153,
  "created_at" : "2016-01-16 18:07:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 20, 35 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688155083561816064",
  "text" : "RT @AllOnMedicare: .@HillaryClinton,\n\nOur current health care system sucks.\n\nSo you're not scaring us by saying Bernie will \"end\" it. \n\n#Si\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 1, 16 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 117, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688066833455443970",
    "text" : ".@HillaryClinton,\n\nOur current health care system sucks.\n\nSo you're not scaring us by saying Bernie will \"end\" it. \n\n#SinglePayer",
    "id" : 688066833455443970,
    "created_at" : "2016-01-15 18:34:51 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 688155083561816064,
  "created_at" : "2016-01-16 00:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688081563855253505",
  "text" : "RT @GeneDoucette: \u201CTED CRUZ (R-Tex. ) tells a sweet story about the sacrifice he and his wife made four years ago to...\u201D https:\/\/t.co\/bjltw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/bjltw3NlJZ",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZw1-xLS7A",
        "display_url" : "tmblr.co\/ZYrEZw1-xLS7A"
      } ]
    },
    "geo" : { },
    "id_str" : "688077939133530112",
    "text" : "\u201CTED CRUZ (R-Tex. ) tells a sweet story about the sacrifice he and his wife made four years ago to...\u201D https:\/\/t.co\/bjltw3NlJZ",
    "id" : 688077939133530112,
    "created_at" : "2016-01-15 19:18:59 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 688081563855253505,
  "created_at" : "2016-01-15 19:33:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/688075899430944768\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/A1a0e6hMXA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYyJXCPWsAIpcFg.jpg",
      "id_str" : "688075871912112130",
      "id" : 688075871912112130,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYyJXCPWsAIpcFg.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/A1a0e6hMXA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688081479805591552",
  "text" : "RT @marseelee: Physical Pain... https:\/\/t.co\/A1a0e6hMXA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/688075899430944768\/photo\/1",
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/A1a0e6hMXA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYyJXCPWsAIpcFg.jpg",
        "id_str" : "688075871912112130",
        "id" : 688075871912112130,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYyJXCPWsAIpcFg.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/A1a0e6hMXA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688075899430944768",
    "text" : "Physical Pain... https:\/\/t.co\/A1a0e6hMXA",
    "id" : 688075899430944768,
    "created_at" : "2016-01-15 19:10:52 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 688081479805591552,
  "created_at" : "2016-01-15 19:33:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 17, 28 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688056777884176384",
  "text" : "RT @audible_com: @moosebegab Part 1 begins at chapter 2. At the moment, the chapter breakdown in the app may not always reflect that of the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "688040248698355713",
    "geo" : { },
    "id_str" : "688055296489553923",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab Part 1 begins at chapter 2. At the moment, the chapter breakdown in the app may not always reflect that of the text. Apologies!",
    "id" : 688055296489553923,
    "in_reply_to_status_id" : 688040248698355713,
    "created_at" : "2016-01-15 17:49:00 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 688056777884176384,
  "created_at" : "2016-01-15 17:54:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/MNod8io6iq",
      "expanded_url" : "http:\/\/www.windowscentral.com\/how-use-gwx-control-panel-block-upgrading-windows-10",
      "display_url" : "windowscentral.com\/how-use-gwx-co\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688055794869383168",
  "text" : "Stop your Windows 7 or 8.1 PC from forcing Windows 10 on you with GWX Control Panel https:\/\/t.co\/MNod8io6iq",
  "id" : 688055794869383168,
  "created_at" : "2016-01-15 17:50:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688049282767843328",
  "geo" : { },
  "id_str" : "688050558305996802",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley me, too. i freak out when i hydroplane.",
  "id" : 688050558305996802,
  "in_reply_to_status_id" : 688049282767843328,
  "created_at" : "2016-01-15 17:30:11 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "indices" : [ 3, 10 ],
      "id_str" : "18694547",
      "id" : 18694547
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/4ores7\/status\/688049599794155521\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/hZbN89olqP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYxxdikW8AAAaGi.png",
      "id_str" : "688049595390291968",
      "id" : 688049595390291968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYxxdikW8AAAaGi.png",
      "sizes" : [ {
        "h" : 438,
        "resize" : "fit",
        "w" : 571
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 571
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 571
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hZbN89olqP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688050073226330112",
  "text" : "RT @4ores7: shouts out to all the pears https:\/\/t.co\/hZbN89olqP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/4ores7\/status\/688049599794155521\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/hZbN89olqP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYxxdikW8AAAaGi.png",
        "id_str" : "688049595390291968",
        "id" : 688049595390291968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYxxdikW8AAAaGi.png",
        "sizes" : [ {
          "h" : 438,
          "resize" : "fit",
          "w" : 571
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 571
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 571
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hZbN89olqP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "688049599794155521",
    "text" : "shouts out to all the pears https:\/\/t.co\/hZbN89olqP",
    "id" : 688049599794155521,
    "created_at" : "2016-01-15 17:26:22 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 688050073226330112,
  "created_at" : "2016-01-15 17:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/mKmcr4zm34",
      "expanded_url" : "https:\/\/twitter.com\/BookishHQ\/status\/686610051507859460",
      "display_url" : "twitter.com\/BookishHQ\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688041480389263361",
  "text" : "I loved All the Birds, Singing! https:\/\/t.co\/mKmcr4zm34",
  "id" : 688041480389263361,
  "created_at" : "2016-01-15 16:54:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodi Lou Parkin",
      "screen_name" : "JodiLouParkin",
      "indices" : [ 3, 17 ],
      "id_str" : "2501833320",
      "id" : 2501833320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688041112083234817",
  "text" : "RT @JodiLouParkin: The rain was heavy this morning.. I found this lone highland cow, but the horses were nowhere to be seen x https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JodiLouParkin\/status\/684031828987084800\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/UuHE9rNpRN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX4rUo3WkAApre4.jpg",
        "id_str" : "684031826973855744",
        "id" : 684031826973855744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX4rUo3WkAApre4.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2848,
          "resize" : "fit",
          "w" : 4288
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UuHE9rNpRN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684031828987084800",
    "text" : "The rain was heavy this morning.. I found this lone highland cow, but the horses were nowhere to be seen x https:\/\/t.co\/UuHE9rNpRN",
    "id" : 684031828987084800,
    "created_at" : "2016-01-04 15:21:11 +0000",
    "user" : {
      "name" : "Jodi Lou Parkin",
      "screen_name" : "JodiLouParkin",
      "protected" : false,
      "id_str" : "2501833320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741718755869380608\/xpL4IQCp_normal.jpg",
      "id" : 2501833320,
      "verified" : false
    }
  },
  "id" : 688041112083234817,
  "created_at" : "2016-01-15 16:52:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodi Lou Parkin",
      "screen_name" : "JodiLouParkin",
      "indices" : [ 3, 17 ],
      "id_str" : "2501833320",
      "id" : 2501833320
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JodiLouParkin\/status\/686704878245253121\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/mSFkMF5Sf8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYeqcofWYAApZFz.jpg",
      "id_str" : "686704877079257088",
      "id" : 686704877079257088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYeqcofWYAApZFz.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2848,
        "resize" : "fit",
        "w" : 4288
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mSFkMF5Sf8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688041027706425344",
  "text" : "RT @JodiLouParkin: When wild horses approach you for a conversation.. You know you're ok x https:\/\/t.co\/mSFkMF5Sf8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JodiLouParkin\/status\/686704878245253121\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/mSFkMF5Sf8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYeqcofWYAApZFz.jpg",
        "id_str" : "686704877079257088",
        "id" : 686704877079257088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYeqcofWYAApZFz.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2848,
          "resize" : "fit",
          "w" : 4288
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mSFkMF5Sf8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686704878245253121",
    "text" : "When wild horses approach you for a conversation.. You know you're ok x https:\/\/t.co\/mSFkMF5Sf8",
    "id" : 686704878245253121,
    "created_at" : "2016-01-12 00:22:55 +0000",
    "user" : {
      "name" : "Jodi Lou Parkin",
      "screen_name" : "JodiLouParkin",
      "protected" : false,
      "id_str" : "2501833320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741718755869380608\/xpL4IQCp_normal.jpg",
      "id" : 2501833320,
      "verified" : false
    }
  },
  "id" : 688041027706425344,
  "created_at" : "2016-01-15 16:52:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 80, 92 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audibleapp",
      "indices" : [ 3, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688040248698355713",
  "text" : "my #audibleapp is off by a chapter. shows chap 6 but narrator says im in chap 5 @audible_com The Island of Knowledge",
  "id" : 688040248698355713,
  "created_at" : "2016-01-15 16:49:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 3, 15 ],
      "id_str" : "21001534",
      "id" : 21001534
    }, {
      "name" : "The Great Courses",
      "screen_name" : "TheGreatCourses",
      "indices" : [ 18, 34 ],
      "id_str" : "20479873",
      "id" : 20479873
    }, {
      "name" : "Sean Carroll",
      "screen_name" : "seanmcarroll",
      "indices" : [ 88, 101 ],
      "id_str" : "21611239",
      "id" : 21611239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DailyDeal",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688038925785542657",
  "text" : "RT @audible_com: .@TheGreatCourses brings you \"The Higgs Boson and Beyond\" by physicist @seanmcarroll, just $2.95 #DailyDeal https:\/\/t.co\/n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Great Courses",
        "screen_name" : "TheGreatCourses",
        "indices" : [ 1, 17 ],
        "id_str" : "20479873",
        "id" : 20479873
      }, {
        "name" : "Sean Carroll",
        "screen_name" : "seanmcarroll",
        "indices" : [ 71, 84 ],
        "id_str" : "21611239",
        "id" : 21611239
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DailyDeal",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ni9X7llt0y",
        "expanded_url" : "http:\/\/adbl.co\/higgsboson",
        "display_url" : "adbl.co\/higgsboson"
      } ]
    },
    "geo" : { },
    "id_str" : "687981307951972352",
    "text" : ".@TheGreatCourses brings you \"The Higgs Boson and Beyond\" by physicist @seanmcarroll, just $2.95 #DailyDeal https:\/\/t.co\/ni9X7llt0y",
    "id" : 687981307951972352,
    "created_at" : "2016-01-15 12:55:00 +0000",
    "user" : {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "protected" : false,
      "id_str" : "21001534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611705114936610816\/c2HzYdZs_normal.png",
      "id" : 21001534,
      "verified" : true
    }
  },
  "id" : 688038925785542657,
  "created_at" : "2016-01-15 16:43:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/687940427807363072\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Nypv2G2hOm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYwOKdhWEAAECX4.jpg",
      "id_str" : "687940415966810112",
      "id" : 687940415966810112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYwOKdhWEAAECX4.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1537,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Nypv2G2hOm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/Ewr5KK9nxy",
      "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/988454491228374\/?type=3&theater",
      "display_url" : "facebook.com\/dwaynereavesph\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688038384195993601",
  "text" : "RT @dwaynereaves: I never get tired of photographing railroad tracks.  https:\/\/t.co\/Ewr5KK9nxy https:\/\/t.co\/Nypv2G2hOm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/687940427807363072\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/Nypv2G2hOm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYwOKdhWEAAECX4.jpg",
        "id_str" : "687940415966810112",
        "id" : 687940415966810112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYwOKdhWEAAECX4.jpg",
        "sizes" : [ {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1066
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1537,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Nypv2G2hOm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/Ewr5KK9nxy",
        "expanded_url" : "https:\/\/www.facebook.com\/dwaynereavesphotography\/photos\/a.872592582814566.1073741828.870769196330238\/988454491228374\/?type=3&theater",
        "display_url" : "facebook.com\/dwaynereavesph\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "687940427807363072",
    "text" : "I never get tired of photographing railroad tracks.  https:\/\/t.co\/Ewr5KK9nxy https:\/\/t.co\/Nypv2G2hOm",
    "id" : 687940427807363072,
    "created_at" : "2016-01-15 10:12:33 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 688038384195993601,
  "created_at" : "2016-01-15 16:41:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688037882125225985",
  "text" : "I'm 20% through The Island of Knowledge (Unabridged) by Marcelo Gleiser, narrated by William Neenan on my Audible app",
  "id" : 688037882125225985,
  "created_at" : "2016-01-15 16:39:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/bHKdu8E1at",
      "expanded_url" : "https:\/\/twitter.com\/CoryBooker\/status\/687988099243241472",
      "display_url" : "twitter.com\/CoryBooker\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "688037341747933189",
  "text" : "Forever I will hear \"Albert Camuuuus! Albert Camuuuus!\" from Love May Fail..lol https:\/\/t.co\/bHKdu8E1at",
  "id" : 688037341747933189,
  "created_at" : "2016-01-15 16:37:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodi Lou Parkin",
      "screen_name" : "JodiLouParkin",
      "indices" : [ 3, 17 ],
      "id_str" : "2501833320",
      "id" : 2501833320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688036274016489472",
  "text" : "RT @JodiLouParkin: Month 3 on the Moor.. The recent heavy fog creates a haunting aura. There is an unforgiving silence, seldom broken x htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JodiLouParkin\/status\/677537748660715522\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/n9RexUWGbi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWcY_cTXIAAiAfH.jpg",
        "id_str" : "677537747150774272",
        "id" : 677537747150774272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWcY_cTXIAAiAfH.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2620,
          "resize" : "fit",
          "w" : 3931
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/n9RexUWGbi"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/JodiLouParkin\/status\/677537748660715522\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/n9RexUWGbi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWcY_aqXIAAOzRu.jpg",
        "id_str" : "677537746710372352",
        "id" : 677537746710372352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWcY_aqXIAAOzRu.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2556,
          "resize" : "fit",
          "w" : 3835
        } ],
        "display_url" : "pic.twitter.com\/n9RexUWGbi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677537748660715522",
    "text" : "Month 3 on the Moor.. The recent heavy fog creates a haunting aura. There is an unforgiving silence, seldom broken x https:\/\/t.co\/n9RexUWGbi",
    "id" : 677537748660715522,
    "created_at" : "2015-12-17 17:16:01 +0000",
    "user" : {
      "name" : "Jodi Lou Parkin",
      "screen_name" : "JodiLouParkin",
      "protected" : false,
      "id_str" : "2501833320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741718755869380608\/xpL4IQCp_normal.jpg",
      "id" : 2501833320,
      "verified" : false
    }
  },
  "id" : 688036274016489472,
  "created_at" : "2016-01-15 16:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "688004734331056128",
  "geo" : { },
  "id_str" : "688036155078623237",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre teehee ; )",
  "id" : 688036155078623237,
  "in_reply_to_status_id" : 688004734331056128,
  "created_at" : "2016-01-15 16:32:57 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Schreiner",
      "screen_name" : "MikeSchreiner",
      "indices" : [ 3, 17 ],
      "id_str" : "19050314",
      "id" : 19050314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688034788880551936",
  "text" : "RT @MikeSchreiner: Wind supplied 97% of electricity needs of Scottish homes in 2015 on the way to 100% renewables by 2020 https:\/\/t.co\/4LqI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/linkis.com\" rel=\"nofollow\"\u003EPut your button on any page! \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cleanenergy",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/4LqIgyRPnn",
        "expanded_url" : "http:\/\/ln.is\/www.treehugger.com\/r\/XmdSr",
        "display_url" : "ln.is\/www.treehugger\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "688009473261199360",
    "text" : "Wind supplied 97% of electricity needs of Scottish homes in 2015 on the way to 100% renewables by 2020 https:\/\/t.co\/4LqIgyRPnn #cleanenergy",
    "id" : 688009473261199360,
    "created_at" : "2016-01-15 14:46:55 +0000",
    "user" : {
      "name" : "Mike Schreiner",
      "screen_name" : "MikeSchreiner",
      "protected" : false,
      "id_str" : "19050314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629999677543313408\/OZbqNmj9_normal.jpg",
      "id" : 19050314,
      "verified" : true
    }
  },
  "id" : 688034788880551936,
  "created_at" : "2016-01-15 16:27:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/dr0gok3YQZ",
      "expanded_url" : "http:\/\/go.shr.lc\/1NawLzn",
      "display_url" : "go.shr.lc\/1NawLzn"
    } ]
  },
  "geo" : { },
  "id_str" : "687823409649184772",
  "text" : "poor dear kitty doesnt want bath... No! And I Mean It! - https:\/\/t.co\/dr0gok3YQZ",
  "id" : 687823409649184772,
  "created_at" : "2016-01-15 02:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Rac0evvhC7",
      "expanded_url" : "https:\/\/twitter.com\/ProductHunt\/status\/687754174394597376",
      "display_url" : "twitter.com\/ProductHunt\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687757333838049281",
  "text" : "i keep hearing about this peach thing but I dont know what it is? https:\/\/t.co\/Rac0evvhC7",
  "id" : 687757333838049281,
  "created_at" : "2016-01-14 22:05:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 15, 30 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bookreview",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "feedly",
      "indices" : [ 113, 120 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/20MNkJjbxx",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/01\/book-review-sound-wild-snail-eating-elisabeth-tova-bailey\/",
      "display_url" : "brucegerencser.net\/2016\/01\/book-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "687705368194093056",
  "text" : "#bookreview by @brucegerencser The Sound of a Wild Snail Eating by Elisabeth Tova Bailey https:\/\/t.co\/20MNkJjbxx #feedly #chronicillness",
  "id" : 687705368194093056,
  "created_at" : "2016-01-14 18:38:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "Amazing Travel Pics",
      "screen_name" : "_TravelPix",
      "indices" : [ 23, 34 ],
      "id_str" : "4629281241",
      "id" : 4629281241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/9HHojtWPxF",
      "expanded_url" : "https:\/\/twitter.com\/_TravelPix\/status\/687637264336162816\/photo\/1",
      "display_url" : "pic.twitter.com\/9HHojtWPxF"
    } ]
  },
  "geo" : { },
  "id_str" : "687698268965466112",
  "text" : "RT @JamiaStarheart: RT @_TravelPix: https:\/\/t.co\/9HHojtWPxF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazing Travel Pics",
        "screen_name" : "_TravelPix",
        "indices" : [ 3, 14 ],
        "id_str" : "4629281241",
        "id" : 4629281241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/9HHojtWPxF",
        "expanded_url" : "https:\/\/twitter.com\/_TravelPix\/status\/687637264336162816\/photo\/1",
        "display_url" : "pic.twitter.com\/9HHojtWPxF"
      } ]
    },
    "geo" : { },
    "id_str" : "687697359313178624",
    "text" : "RT @_TravelPix: https:\/\/t.co\/9HHojtWPxF",
    "id" : 687697359313178624,
    "created_at" : "2016-01-14 18:06:41 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 687698268965466112,
  "created_at" : "2016-01-14 18:10:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOA",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "Abraham",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687673591333294082",
  "text" : "most important words taken to heart \"reach for the better feeling\" via esther hicks. #LOA #Abraham I think of that when feeling desolate.",
  "id" : 687673591333294082,
  "created_at" : "2016-01-14 16:32:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687672309281329152",
  "text" : "if I get mean.. im poking with my stick causing more strife. i already have enough bad karma, tyvm.",
  "id" : 687672309281329152,
  "created_at" : "2016-01-14 16:27:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687671625551052800",
  "text" : "sometimes ppl say things I disagree with and I want to get mean. Why? (introspection) because I have taken personal offense.",
  "id" : 687671625551052800,
  "created_at" : "2016-01-14 16:24:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687670039902863360",
  "text" : "ppl in pain poke sticks at each other. we're all in pain. the only solution.. painkiller &gt;&gt; love. Reach for it. Keep reaching.",
  "id" : 687670039902863360,
  "created_at" : "2016-01-14 16:18:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687666662380822529",
  "text" : "RT @AnAmericanMonk: Our task is not to judge or punish. Karma will take care of that. Our task is love. Aarti Jain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687666031666577409",
    "text" : "Our task is not to judge or punish. Karma will take care of that. Our task is love. Aarti Jain",
    "id" : 687666031666577409,
    "created_at" : "2016-01-14 16:02:12 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 687666662380822529,
  "created_at" : "2016-01-14 16:04:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rock",
      "screen_name" : "TheMichaelRock",
      "indices" : [ 3, 18 ],
      "id_str" : "98973513",
      "id" : 98973513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687652385188114433",
  "text" : "RT @TheMichaelRock: Many people don't know this, but it's possible to read something you don't agree with on the internet and simply move o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685554922822086657",
    "text" : "Many people don't know this, but it's possible to read something you don't agree with on the internet and simply move on with your life.",
    "id" : 685554922822086657,
    "created_at" : "2016-01-08 20:13:25 +0000",
    "user" : {
      "name" : "Rock",
      "screen_name" : "TheMichaelRock",
      "protected" : false,
      "id_str" : "98973513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787388908237647873\/1ZprFH8D_normal.jpg",
      "id" : 98973513,
      "verified" : false
    }
  },
  "id" : 687652385188114433,
  "created_at" : "2016-01-14 15:07:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren \uD83C\uDF83\uD83C\uDF41\uD83C\uDF42\uD83D\uDD78\uD83D\uDD77\uD83D\uDC7B",
      "screen_name" : "LaurenDeStefano",
      "indices" : [ 3, 19 ],
      "id_str" : "16144298",
      "id" : 16144298
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LaurenDeStefano\/status\/687307522269671424\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/eSyr9TBoah",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYnOjMRWAAErlBr.jpg",
      "id_str" : "687307522135425025",
      "id" : 687307522135425025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYnOjMRWAAErlBr.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/eSyr9TBoah"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687651662153003008",
  "text" : "RT @LaurenDeStefano: RT by 1\/20 to enter to win a $50 B&amp;N gift card! https:\/\/t.co\/eSyr9TBoah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaurenDeStefano\/status\/687307522269671424\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/eSyr9TBoah",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYnOjMRWAAErlBr.jpg",
        "id_str" : "687307522135425025",
        "id" : 687307522135425025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYnOjMRWAAErlBr.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/eSyr9TBoah"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687307522269671424",
    "text" : "RT by 1\/20 to enter to win a $50 B&amp;N gift card! https:\/\/t.co\/eSyr9TBoah",
    "id" : 687307522269671424,
    "created_at" : "2016-01-13 16:17:37 +0000",
    "user" : {
      "name" : "Lauren \uD83C\uDF83\uD83C\uDF41\uD83C\uDF42\uD83D\uDD78\uD83D\uDD77\uD83D\uDC7B",
      "screen_name" : "LaurenDeStefano",
      "protected" : false,
      "id_str" : "16144298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768823537083813888\/OS1PMYSx_normal.jpg",
      "id" : 16144298,
      "verified" : true
    }
  },
  "id" : 687651662153003008,
  "created_at" : "2016-01-14 15:05:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 3, 17 ],
      "id_str" : "183854047",
      "id" : 183854047
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/687451862514163713\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/n9sp1WZpTO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYpR010UEAAAztm.jpg",
      "id_str" : "687451861368967168",
      "id" : 687451861368967168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYpR010UEAAAztm.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/n9sp1WZpTO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687463996644012032",
  "text" : "RT @CatFoodBreath: MEOW https:\/\/t.co\/n9sp1WZpTO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatFoodBreath\/status\/687451862514163713\/photo\/1",
        "indices" : [ 5, 28 ],
        "url" : "https:\/\/t.co\/n9sp1WZpTO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYpR010UEAAAztm.jpg",
        "id_str" : "687451861368967168",
        "id" : 687451861368967168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYpR010UEAAAztm.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        } ],
        "display_url" : "pic.twitter.com\/n9sp1WZpTO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687451862514163713",
    "text" : "MEOW https:\/\/t.co\/n9sp1WZpTO",
    "id" : 687451862514163713,
    "created_at" : "2016-01-14 01:51:10 +0000",
    "user" : {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "protected" : false,
      "id_str" : "183854047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1112259384\/birman_normal.jpg",
      "id" : 183854047,
      "verified" : false
    }
  },
  "id" : 687463996644012032,
  "created_at" : "2016-01-14 02:39:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/508918020006109184\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/ZPrH1nIRB9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxAKPh0CIAABtmO.jpg",
      "id_str" : "508918019783794688",
      "id" : 508918019783794688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxAKPh0CIAABtmO.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/ZPrH1nIRB9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687454229817102336",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/ZPrH1nIRB9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/508918020006109184\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/ZPrH1nIRB9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxAKPh0CIAABtmO.jpg",
        "id_str" : "508918019783794688",
        "id" : 508918019783794688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxAKPh0CIAABtmO.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/ZPrH1nIRB9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "687451587288154112",
    "text" : "https:\/\/t.co\/ZPrH1nIRB9",
    "id" : 687451587288154112,
    "created_at" : "2016-01-14 01:50:05 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 687454229817102336,
  "created_at" : "2016-01-14 02:00:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chronicillness",
      "indices" : [ 87, 102 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687379763250462720",
  "text" : "DD feeling down. mri, eeg normal. neuro rx'd imitrix for headaches (but DD wont take.) #chronicillness #hashimotos",
  "id" : 687379763250462720,
  "created_at" : "2016-01-13 21:04:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "687290186401726467",
  "text" : "I'm 5% through The Island of Knowledge (Unabridged) by Marcelo Gleiser, narrated by William Neenan on my Audible app.",
  "id" : 687290186401726467,
  "created_at" : "2016-01-13 15:08:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "687010816613167104",
  "geo" : { },
  "id_str" : "687014963811094528",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater adorable! but the neurotic ocd part of me wouldnt like me wearing them..lol",
  "id" : 687014963811094528,
  "in_reply_to_status_id" : 687010816613167104,
  "created_at" : "2016-01-12 20:55:06 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Longbush Pork",
      "screen_name" : "longbushpork",
      "indices" : [ 3, 16 ],
      "id_str" : "1526830477",
      "id" : 1526830477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686994161191546880",
  "text" : "RT @longbushpork: The thing about George is he always looks at me as if sad, mad or disappointed. I call it his resting boar face. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/longbushpork\/status\/686991009394262016\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ByR4l9Q2Fq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYiuqjkUMAEn7yK.jpg",
        "id_str" : "686990989299298305",
        "id" : 686990989299298305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYiuqjkUMAEn7yK.jpg",
        "sizes" : [ {
          "h" : 293,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 882,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 882,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ByR4l9Q2Fq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686991009394262016",
    "text" : "The thing about George is he always looks at me as if sad, mad or disappointed. I call it his resting boar face. https:\/\/t.co\/ByR4l9Q2Fq",
    "id" : 686991009394262016,
    "created_at" : "2016-01-12 19:19:54 +0000",
    "user" : {
      "name" : "Longbush Pork",
      "screen_name" : "longbushpork",
      "protected" : false,
      "id_str" : "1526830477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644750736832630785\/vpETMOFo_normal.jpg",
      "id" : 1526830477,
      "verified" : false
    }
  },
  "id" : 686994161191546880,
  "created_at" : "2016-01-12 19:32:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LukeRomyn\/status\/686948057682817024\/photo\/1",
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/HKB0zyC1iI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYiHnh3UQAAn5-5.jpg",
      "id_str" : "686948056349032448",
      "id" : 686948056349032448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYiHnh3UQAAn5-5.jpg",
      "sizes" : [ {
        "h" : 873,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 873,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HKB0zyC1iI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686951549151621120",
  "text" : "RT @LukeRomyn: It's true. https:\/\/t.co\/HKB0zyC1iI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LukeRomyn\/status\/686948057682817024\/photo\/1",
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/HKB0zyC1iI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYiHnh3UQAAn5-5.jpg",
        "id_str" : "686948056349032448",
        "id" : 686948056349032448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYiHnh3UQAAn5-5.jpg",
        "sizes" : [ {
          "h" : 873,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HKB0zyC1iI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686948057682817024",
    "text" : "It's true. https:\/\/t.co\/HKB0zyC1iI",
    "id" : 686948057682817024,
    "created_at" : "2016-01-12 16:29:14 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 686951549151621120,
  "created_at" : "2016-01-12 16:43:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "indices" : [ 3, 15 ],
      "id_str" : "17592150",
      "id" : 17592150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ymjv5U4ac7",
      "expanded_url" : "http:\/\/thedo.do\/1kQO5mi",
      "display_url" : "thedo.do\/1kQO5mi"
    } ]
  },
  "geo" : { },
  "id_str" : "686951461058641920",
  "text" : "RT @thomaspluck: Cat Refuses To Leave Supermarket No Matter How Many Times He's Kicked Out https:\/\/t.co\/ymjv5U4ac7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/ymjv5U4ac7",
        "expanded_url" : "http:\/\/thedo.do\/1kQO5mi",
        "display_url" : "thedo.do\/1kQO5mi"
      } ]
    },
    "geo" : { },
    "id_str" : "686948137680920577",
    "text" : "Cat Refuses To Leave Supermarket No Matter How Many Times He's Kicked Out https:\/\/t.co\/ymjv5U4ac7",
    "id" : 686948137680920577,
    "created_at" : "2016-01-12 16:29:33 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 686951461058641920,
  "created_at" : "2016-01-12 16:42:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/79VbZ9Ydb5",
      "expanded_url" : "http:\/\/twishort.com\/mDKjc",
      "display_url" : "twishort.com\/mDKjc"
    } ]
  },
  "geo" : { },
  "id_str" : "686949744946606081",
  "text" : "RT @parkstepp: Spiritual progress...  \n\nIt is not our usual experience to wake up suddenly one day fro\u2026 https:\/\/t.co\/79VbZ9Ydb5 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/parkstepp\/status\/686949285804552192\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/k8dKNQvIvZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYiIvEiWEAEat37.jpg",
        "id_str" : "686949285427023873",
        "id" : 686949285427023873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYiIvEiWEAEat37.jpg",
        "sizes" : [ {
          "h" : 358,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/k8dKNQvIvZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/79VbZ9Ydb5",
        "expanded_url" : "http:\/\/twishort.com\/mDKjc",
        "display_url" : "twishort.com\/mDKjc"
      } ]
    },
    "geo" : { },
    "id_str" : "686949285804552192",
    "text" : "Spiritual progress...  \n\nIt is not our usual experience to wake up suddenly one day fro\u2026 https:\/\/t.co\/79VbZ9Ydb5 https:\/\/t.co\/k8dKNQvIvZ",
    "id" : 686949285804552192,
    "created_at" : "2016-01-12 16:34:07 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 686949744946606081,
  "created_at" : "2016-01-12 16:35:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "template",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686949311083601921",
  "text" : "trying to find a medication log #template I had seen which had room for rx stickers (you peel off from big sheet when you get rx filled)",
  "id" : 686949311083601921,
  "created_at" : "2016-01-12 16:34:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HighBridge Audio",
      "screen_name" : "HighBridgeAudio",
      "indices" : [ 3, 19 ],
      "id_str" : "19552359",
      "id" : 19552359
    }, {
      "name" : "Thomas E. Perry",
      "screen_name" : "TPerryauthor",
      "indices" : [ 79, 92 ],
      "id_str" : "269055497",
      "id" : 269055497
    }, {
      "name" : "MysteriousPress.com",
      "screen_name" : "eMysteries",
      "indices" : [ 94, 105 ],
      "id_str" : "346852354",
      "id" : 346852354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/P03deWoC05",
      "expanded_url" : "http:\/\/highbridgecompany.com\/blog\/2016\/01\/11\/featured-audio-giveaway-january-2016-forty-thieves\/",
      "display_url" : "highbridgecompany.com\/blog\/2016\/01\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686656783142752256",
  "text" : "RT @HighBridgeAudio: This month on our blog we're giving away FORTY THIEVES by @TPerryauthor! @eMysteries https:\/\/t.co\/P03deWoC05",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Thomas E. Perry",
        "screen_name" : "TPerryauthor",
        "indices" : [ 58, 71 ],
        "id_str" : "269055497",
        "id" : 269055497
      }, {
        "name" : "MysteriousPress.com",
        "screen_name" : "eMysteries",
        "indices" : [ 73, 84 ],
        "id_str" : "346852354",
        "id" : 346852354
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/P03deWoC05",
        "expanded_url" : "http:\/\/highbridgecompany.com\/blog\/2016\/01\/11\/featured-audio-giveaway-january-2016-forty-thieves\/",
        "display_url" : "highbridgecompany.com\/blog\/2016\/01\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686640029637165056",
    "text" : "This month on our blog we're giving away FORTY THIEVES by @TPerryauthor! @eMysteries https:\/\/t.co\/P03deWoC05",
    "id" : 686640029637165056,
    "created_at" : "2016-01-11 20:05:14 +0000",
    "user" : {
      "name" : "HighBridge Audio",
      "screen_name" : "HighBridgeAudio",
      "protected" : false,
      "id_str" : "19552359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461187019364765697\/Pqgn_3iJ_normal.jpeg",
      "id" : 19552359,
      "verified" : false
    }
  },
  "id" : 686656783142752256,
  "created_at" : "2016-01-11 21:11:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 24, 28 ]
    }, {
      "text" : "socialism",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686637706995216384",
  "text" : "some ppl talk about the #woo like others talk about #socialism",
  "id" : 686637706995216384,
  "created_at" : "2016-01-11 19:56:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686597103393574913",
  "geo" : { },
  "id_str" : "686635061563789312",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe (((hugs)))",
  "id" : 686635061563789312,
  "in_reply_to_status_id" : 686597103393574913,
  "created_at" : "2016-01-11 19:45:30 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/kK0WH3JB8V",
      "expanded_url" : "http:\/\/gu.com\/p\/3j7a2\/stw",
      "display_url" : "gu.com\/p\/3j7a2\/stw"
    } ]
  },
  "geo" : { },
  "id_str" : "686591700756762624",
  "text" : "David Bowie's top 100 must-read books https:\/\/t.co\/kK0WH3JB8V",
  "id" : 686591700756762624,
  "created_at" : "2016-01-11 16:53:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Wells",
      "screen_name" : "MikeWellsAuthor",
      "indices" : [ 3, 19 ],
      "id_str" : "261431332",
      "id" : 261431332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Audiobooks",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/wlrKCPB3Bh",
      "expanded_url" : "http:\/\/mikewellsblog.blogspot.com\/2014\/03\/why-audiobooks.html",
      "display_url" : "mikewellsblog.blogspot.com\/2014\/03\/why-au\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686577286372585472",
  "text" : "RT @MikeWellsAuthor: Why #Audiobooks? New blog post - https:\/\/t.co\/wlrKCPB3Bh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Audiobooks",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/wlrKCPB3Bh",
        "expanded_url" : "http:\/\/mikewellsblog.blogspot.com\/2014\/03\/why-audiobooks.html",
        "display_url" : "mikewellsblog.blogspot.com\/2014\/03\/why-au\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686555304843198464",
    "text" : "Why #Audiobooks? New blog post - https:\/\/t.co\/wlrKCPB3Bh",
    "id" : 686555304843198464,
    "created_at" : "2016-01-11 14:28:34 +0000",
    "user" : {
      "name" : "Mike Wells",
      "screen_name" : "MikeWellsAuthor",
      "protected" : false,
      "id_str" : "261431332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618302613231153152\/Ov_thqBz_normal.jpg",
      "id" : 261431332,
      "verified" : false
    }
  },
  "id" : 686577286372585472,
  "created_at" : "2016-01-11 15:55:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie David Burns",
      "screen_name" : "DrLeslieDBurns",
      "indices" : [ 3, 18 ],
      "id_str" : "4706732031",
      "id" : 4706732031
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachonpurpose",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686575892479512577",
  "text" : "RT @DrLeslieDBurns: Professional teachers are not soldiers or robots or cogs. They build minds. Real teachers #teachonpurpose. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrLeslieDBurns\/status\/686544366253510656\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/nvpUIy5o6A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYcYdOCWcAA9n_D.jpg",
        "id_str" : "686544358460518400",
        "id" : 686544358460518400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYcYdOCWcAA9n_D.jpg",
        "sizes" : [ {
          "h" : 548,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 876,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 876,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/nvpUIy5o6A"
      } ],
      "hashtags" : [ {
        "text" : "teachonpurpose",
        "indices" : [ 90, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686544366253510656",
    "text" : "Professional teachers are not soldiers or robots or cogs. They build minds. Real teachers #teachonpurpose. https:\/\/t.co\/nvpUIy5o6A",
    "id" : 686544366253510656,
    "created_at" : "2016-01-11 13:45:06 +0000",
    "user" : {
      "name" : "Leslie David Burns",
      "screen_name" : "DrLeslieDBurns",
      "protected" : false,
      "id_str" : "4706732031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684064572697915394\/uZwcmK9p_normal.jpg",
      "id" : 4706732031,
      "verified" : false
    }
  },
  "id" : 686575892479512577,
  "created_at" : "2016-01-11 15:50:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686563575482159104",
  "geo" : { },
  "id_str" : "686575665844469768",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe i usually cry when I play this one...",
  "id" : 686575665844469768,
  "in_reply_to_status_id" : 686563575482159104,
  "created_at" : "2016-01-11 15:49:29 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ask Science Mike",
      "screen_name" : "asksciencemike",
      "indices" : [ 3, 18 ],
      "id_str" : "2970458165",
      "id" : 2970458165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/i0YTWn9BoC",
      "expanded_url" : "http:\/\/mikemchargue.com\/asksciencemike\/2016\/1\/10\/episode-52-empaths-genesis-and-life-in-space",
      "display_url" : "mikemchargue.com\/asksciencemike\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686574168847028224",
  "text" : "RT @asksciencemike: New year, new episode of the show: Episode 52 - Empaths, Genesis, and Life in Space https:\/\/t.co\/i0YTWn9BoC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/i0YTWn9BoC",
        "expanded_url" : "http:\/\/mikemchargue.com\/asksciencemike\/2016\/1\/10\/episode-52-empaths-genesis-and-life-in-space",
        "display_url" : "mikemchargue.com\/asksciencemike\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686571541945974784",
    "text" : "New year, new episode of the show: Episode 52 - Empaths, Genesis, and Life in Space https:\/\/t.co\/i0YTWn9BoC",
    "id" : 686571541945974784,
    "created_at" : "2016-01-11 15:33:06 +0000",
    "user" : {
      "name" : "Ask Science Mike",
      "screen_name" : "asksciencemike",
      "protected" : false,
      "id_str" : "2970458165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701170538954141696\/-HYTfCrE_normal.jpg",
      "id" : 2970458165,
      "verified" : false
    }
  },
  "id" : 686574168847028224,
  "created_at" : "2016-01-11 15:43:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Stanley, MD MPH",
      "screen_name" : "dirkstanley",
      "indices" : [ 3, 15 ],
      "id_str" : "18262104",
      "id" : 18262104
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 69, 77 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/cwCOVPXO97",
      "expanded_url" : "http:\/\/www.nytimes.com\/2016\/01\/10\/magazine\/the-lawyer-who-became-duponts-worst-nightmare.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
      "display_url" : "nytimes.com\/2016\/01\/10\/mag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686559757482721281",
  "text" : "RT @dirkstanley: The Lawyer Who Became DuPont\u2019s Worst Nightmare, via @nytimes https:\/\/t.co\/cwCOVPXO97",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 52, 60 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/cwCOVPXO97",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/01\/10\/magazine\/the-lawyer-who-became-duponts-worst-nightmare.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
        "display_url" : "nytimes.com\/2016\/01\/10\/mag\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685808109177077760",
    "text" : "The Lawyer Who Became DuPont\u2019s Worst Nightmare, via @nytimes https:\/\/t.co\/cwCOVPXO97",
    "id" : 685808109177077760,
    "created_at" : "2016-01-09 12:59:29 +0000",
    "user" : {
      "name" : "Dirk Stanley, MD MPH",
      "screen_name" : "dirkstanley",
      "protected" : false,
      "id_str" : "18262104",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737491754686009344\/rW_PJmC3_normal.jpg",
      "id" : 18262104,
      "verified" : false
    }
  },
  "id" : 686559757482721281,
  "created_at" : "2016-01-11 14:46:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 3, 6 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686557688088653824",
  "text" : "RT @AP: APNewsBreak: Ringling Brothers circus to retire its elephants in May, a year and a half earlier than planned: https:\/\/t.co\/xo2m3F4T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/xo2m3F4Tok",
        "expanded_url" : "http:\/\/apne.ws\/1P2IXDy",
        "display_url" : "apne.ws\/1P2IXDy"
      } ]
    },
    "geo" : { },
    "id_str" : "686533522887196672",
    "text" : "APNewsBreak: Ringling Brothers circus to retire its elephants in May, a year and a half earlier than planned: https:\/\/t.co\/xo2m3F4Tok",
    "id" : 686533522887196672,
    "created_at" : "2016-01-11 13:02:01 +0000",
    "user" : {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "protected" : false,
      "id_str" : "51241574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461964160838803457\/8z9FImcv_normal.png",
      "id" : 51241574,
      "verified" : true
    }
  },
  "id" : 686557688088653824,
  "created_at" : "2016-01-11 14:38:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlene White",
      "screen_name" : "CharleneWhite",
      "indices" : [ 3, 17 ],
      "id_str" : "46017944",
      "id" : 46017944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686556094752288768",
  "text" : "RT @CharleneWhite: There are many reasons to love David Bowie. Here's one. 1982: challenging  MTV on their refusal to play black music: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CharleneWhite\/status\/686496949902675968\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0ku30wccVG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYbtVYJWMAA6x7o.jpg",
        "id_str" : "686496944735268864",
        "id" : 686496944735268864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYbtVYJWMAA6x7o.jpg",
        "sizes" : [ {
          "h" : 939,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1023,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1023,
          "resize" : "fit",
          "w" : 654
        } ],
        "display_url" : "pic.twitter.com\/0ku30wccVG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686496949902675968",
    "text" : "There are many reasons to love David Bowie. Here's one. 1982: challenging  MTV on their refusal to play black music: https:\/\/t.co\/0ku30wccVG",
    "id" : 686496949902675968,
    "created_at" : "2016-01-11 10:36:42 +0000",
    "user" : {
      "name" : "Charlene White",
      "screen_name" : "CharleneWhite",
      "protected" : false,
      "id_str" : "46017944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739781615992381441\/viNNdxA1_normal.jpg",
      "id" : 46017944,
      "verified" : true
    }
  },
  "id" : 686556094752288768,
  "created_at" : "2016-01-11 14:31:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 0, 12 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 13, 25 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686329810210177024",
  "geo" : { },
  "id_str" : "686370216406859776",
  "in_reply_to_user_id" : 229428507,
  "text" : "@Floridaline @VirgoJohnny UGH!",
  "id" : 686370216406859776,
  "in_reply_to_status_id" : 686329810210177024,
  "created_at" : "2016-01-11 02:13:06 +0000",
  "in_reply_to_screen_name" : "Floridaline",
  "in_reply_to_user_id_str" : "229428507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686325980923822081",
  "geo" : { },
  "id_str" : "686334026660089856",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe Nantasket Beach in Hull.. oops, not on the cape. further up than I thought.",
  "id" : 686334026660089856,
  "in_reply_to_status_id" : 686325980923822081,
  "created_at" : "2016-01-10 23:49:18 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686324590214279169",
  "text" : "DH booked cape cod rental so I guess I have to start looking for swimwear. might get a bikini. more comfy than 1 piece.",
  "id" : 686324590214279169,
  "created_at" : "2016-01-10 23:11:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686319887753588737",
  "text" : "looking at MyDatabase Home and Business but they want $40.. any suggestions to similar cheaper alternative?",
  "id" : 686319887753588737,
  "created_at" : "2016-01-10 22:53:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "686263836047884288",
  "geo" : { },
  "id_str" : "686266845062651904",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley which labelmaker? do you like it? been thinking of getting one (kitchen, gadget cables...)",
  "id" : 686266845062651904,
  "in_reply_to_status_id" : 686263836047884288,
  "created_at" : "2016-01-10 19:22:20 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Silvia",
      "screen_name" : "Antlady69",
      "indices" : [ 3, 13 ],
      "id_str" : "34692294",
      "id" : 34692294
    }, {
      "name" : "Ravenmaster",
      "screen_name" : "ravenmaster1",
      "indices" : [ 39, 52 ],
      "id_str" : "357816281",
      "id" : 357816281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/675363069401370624\/video\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/rFx1GjMASH",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/675362857651957760\/pu\/img\/zeZ7jsgLjrijj5Ui.jpg",
      "id_str" : "675362857651957760",
      "id" : 675362857651957760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/675362857651957760\/pu\/img\/zeZ7jsgLjrijj5Ui.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 404
      }, {
        "h" : 606,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 404
      } ],
      "display_url" : "pic.twitter.com\/rFx1GjMASH"
    } ],
    "hashtags" : [ {
      "text" : "ravens",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686242674807050240",
  "text" : "RT @Antlady69: How utterly amazing! RT @ravenmaster1: Early morning Raven cuddles. #ravens https:\/\/t.co\/rFx1GjMASH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ravenmaster",
        "screen_name" : "ravenmaster1",
        "indices" : [ 24, 37 ],
        "id_str" : "357816281",
        "id" : 357816281
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ravenmaster1\/status\/675363069401370624\/video\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/rFx1GjMASH",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/675362857651957760\/pu\/img\/zeZ7jsgLjrijj5Ui.jpg",
        "id_str" : "675362857651957760",
        "id" : 675362857651957760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/675362857651957760\/pu\/img\/zeZ7jsgLjrijj5Ui.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 404
        }, {
          "h" : 606,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 404
        } ],
        "display_url" : "pic.twitter.com\/rFx1GjMASH"
      } ],
      "hashtags" : [ {
        "text" : "ravens",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686235773625053185",
    "text" : "How utterly amazing! RT @ravenmaster1: Early morning Raven cuddles. #ravens https:\/\/t.co\/rFx1GjMASH",
    "id" : 686235773625053185,
    "created_at" : "2016-01-10 17:18:52 +0000",
    "user" : {
      "name" : "Silvia",
      "screen_name" : "Antlady69",
      "protected" : false,
      "id_str" : "34692294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756792241998426112\/lFje-Mr6_normal.jpg",
      "id" : 34692294,
      "verified" : false
    }
  },
  "id" : 686242674807050240,
  "created_at" : "2016-01-10 17:46:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/DQue1VdJ5M",
      "expanded_url" : "http:\/\/www.sciencealert.com\/neuroscientists-have-figured-how-your-brain-wakes-you-up",
      "display_url" : "sciencealert.com\/neuroscientist\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686242396506435584",
  "text" : "RT @SciencePorn: Neuroscientists have figured out how your brain wakes you up https:\/\/t.co\/DQue1VdJ5M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/DQue1VdJ5M",
        "expanded_url" : "http:\/\/www.sciencealert.com\/neuroscientists-have-figured-how-your-brain-wakes-you-up",
        "display_url" : "sciencealert.com\/neuroscientist\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "686237069396578305",
    "text" : "Neuroscientists have figured out how your brain wakes you up https:\/\/t.co\/DQue1VdJ5M",
    "id" : 686237069396578305,
    "created_at" : "2016-01-10 17:24:01 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 686242396506435584,
  "created_at" : "2016-01-10 17:45:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/686209970749100033\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/3iLxTBLyRA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYXoUloUMAAIOXc.jpg",
      "id_str" : "686209958640103424",
      "id" : 686209958640103424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYXoUloUMAAIOXc.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/3iLxTBLyRA"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/686209970749100033\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/3iLxTBLyRA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYXoU91UwAAFxz8.jpg",
      "id_str" : "686209965137117184",
      "id" : 686209965137117184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYXoU91UwAAFxz8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1073,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1509,
        "resize" : "fit",
        "w" : 1440
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3iLxTBLyRA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686216530703564800",
  "text" : "RT @MimiMadeira1: The UFO is back https:\/\/t.co\/3iLxTBLyRA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/686209970749100033\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/3iLxTBLyRA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYXoUloUMAAIOXc.jpg",
        "id_str" : "686209958640103424",
        "id" : 686209958640103424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYXoUloUMAAIOXc.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/3iLxTBLyRA"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MimiMadeira1\/status\/686209970749100033\/photo\/1",
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/3iLxTBLyRA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYXoU91UwAAFxz8.jpg",
        "id_str" : "686209965137117184",
        "id" : 686209965137117184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYXoU91UwAAFxz8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1073,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1509,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3iLxTBLyRA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "686209970749100033",
    "text" : "The UFO is back https:\/\/t.co\/3iLxTBLyRA",
    "id" : 686209970749100033,
    "created_at" : "2016-01-10 15:36:20 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 686216530703564800,
  "created_at" : "2016-01-10 16:02:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685953433115987968",
  "text" : "started listening to The Life We Bury a few days ago. really amazed at how much I like audiobooks.",
  "id" : 685953433115987968,
  "created_at" : "2016-01-09 22:36:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685952506187395074",
  "text" : "bad chest pain. took 1 of DDs ranitidine. hope that helps.",
  "id" : 685952506187395074,
  "created_at" : "2016-01-09 22:33:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "indices" : [ 3, 16 ],
      "id_str" : "59801057",
      "id" : 59801057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AudiobookSYNC16",
      "indices" : [ 105, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685863316804255744",
  "text" : "RT @AudioFileMag: Wow! Thanks to all the audio publishers for giving us a wonderful preliminary list for #AudiobookSYNC16! https:\/\/t.co\/Kn9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AudioFileMag\/status\/685837964920909828\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/Kn9e3hR8eD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYSV_fIWEAAB1rs.jpg",
        "id_str" : "685837961187954688",
        "id" : 685837961187954688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYSV_fIWEAAB1rs.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 276
        }, {
          "h" : 817,
          "resize" : "fit",
          "w" : 332
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 817,
          "resize" : "fit",
          "w" : 332
        }, {
          "h" : 817,
          "resize" : "fit",
          "w" : 332
        } ],
        "display_url" : "pic.twitter.com\/Kn9e3hR8eD"
      } ],
      "hashtags" : [ {
        "text" : "AudiobookSYNC16",
        "indices" : [ 87, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685837964920909828",
    "text" : "Wow! Thanks to all the audio publishers for giving us a wonderful preliminary list for #AudiobookSYNC16! https:\/\/t.co\/Kn9e3hR8eD",
    "id" : 685837964920909828,
    "created_at" : "2016-01-09 14:58:07 +0000",
    "user" : {
      "name" : "AudioFile Magazine",
      "screen_name" : "AudioFileMag",
      "protected" : false,
      "id_str" : "59801057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525009056\/ArrowsforFacebook_normal.jpg",
      "id" : 59801057,
      "verified" : false
    }
  },
  "id" : 685863316804255744,
  "created_at" : "2016-01-09 16:38:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Captain Blondbeard",
      "screen_name" : "CaptainBBeard",
      "indices" : [ 3, 17 ],
      "id_str" : "4608862094",
      "id" : 4608862094
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CaptainBBeard\/status\/685825472362487808\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/LOQF6Zivah",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYSKlMRUwAANyfT.jpg",
      "id_str" : "685825414820839424",
      "id" : 685825414820839424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYSKlMRUwAANyfT.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 897,
        "resize" : "fit",
        "w" : 1594
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/LOQF6Zivah"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685832815301267456",
  "text" : "RT @CaptainBBeard: Laps. I have discovered laps. Why did no one tell me about laps? https:\/\/t.co\/LOQF6Zivah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CaptainBBeard\/status\/685825472362487808\/photo\/1",
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/LOQF6Zivah",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYSKlMRUwAANyfT.jpg",
        "id_str" : "685825414820839424",
        "id" : 685825414820839424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYSKlMRUwAANyfT.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 897,
          "resize" : "fit",
          "w" : 1594
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/LOQF6Zivah"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685825472362487808",
    "text" : "Laps. I have discovered laps. Why did no one tell me about laps? https:\/\/t.co\/LOQF6Zivah",
    "id" : 685825472362487808,
    "created_at" : "2016-01-09 14:08:29 +0000",
    "user" : {
      "name" : "Captain Blondbeard",
      "screen_name" : "CaptainBBeard",
      "protected" : false,
      "id_str" : "4608862094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678419287321677824\/woo2JTtE_normal.jpg",
      "id" : 4608862094,
      "verified" : false
    }
  },
  "id" : 685832815301267456,
  "created_at" : "2016-01-09 14:37:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Gooding",
      "screen_name" : "joegooding",
      "indices" : [ 3, 14 ],
      "id_str" : "63996778",
      "id" : 63996778
    }, {
      "name" : "Joe Gooding",
      "screen_name" : "joegooding",
      "indices" : [ 99, 110 ],
      "id_str" : "63996778",
      "id" : 63996778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PARaven",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/lZrsDspvMo",
      "expanded_url" : "http:\/\/wp.me\/p6h0Gm-zH",
      "display_url" : "wp.me\/p6h0Gm-zH"
    } ]
  },
  "geo" : { },
  "id_str" : "685673006312615936",
  "text" : "RT @joegooding: 15 Things We Need to Stop Saying in the Vaccine Debate https:\/\/t.co\/lZrsDspvMo via @joegooding #PARaven",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Gooding",
        "screen_name" : "joegooding",
        "indices" : [ 83, 94 ],
        "id_str" : "63996778",
        "id" : 63996778
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PARaven",
        "indices" : [ 95, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/lZrsDspvMo",
        "expanded_url" : "http:\/\/wp.me\/p6h0Gm-zH",
        "display_url" : "wp.me\/p6h0Gm-zH"
      } ]
    },
    "geo" : { },
    "id_str" : "685662694125469701",
    "text" : "15 Things We Need to Stop Saying in the Vaccine Debate https:\/\/t.co\/lZrsDspvMo via @joegooding #PARaven",
    "id" : 685662694125469701,
    "created_at" : "2016-01-09 03:21:39 +0000",
    "user" : {
      "name" : "Joe Gooding",
      "screen_name" : "joegooding",
      "protected" : false,
      "id_str" : "63996778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1573060850\/200817_1913529602506_1369901947_2199776_6169020_n_normal.jpg",
      "id" : 63996778,
      "verified" : false
    }
  },
  "id" : 685673006312615936,
  "created_at" : "2016-01-09 04:02:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685630206506348545",
  "text" : "hands slathered in cortisone, vaseline in fleece gloves. right hand so itchy, cracked.",
  "id" : 685630206506348545,
  "created_at" : "2016-01-09 01:12:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Maciag",
      "screen_name" : "SoCaLicous",
      "indices" : [ 3, 14 ],
      "id_str" : "273235048",
      "id" : 273235048
    }, {
      "name" : "Audible",
      "screen_name" : "audible_com",
      "indices" : [ 63, 75 ],
      "id_str" : "21001534",
      "id" : 21001534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685569068301180928",
  "text" : "RT @SoCaLicous: Nothing makes me happier than a new book in my @audible_com library! \uD83D\uDCD6\uD83D\uDCF2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Audible",
        "screen_name" : "audible_com",
        "indices" : [ 47, 59 ],
        "id_str" : "21001534",
        "id" : 21001534
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685504179511635968",
    "text" : "Nothing makes me happier than a new book in my @audible_com library! \uD83D\uDCD6\uD83D\uDCF2",
    "id" : 685504179511635968,
    "created_at" : "2016-01-08 16:51:47 +0000",
    "user" : {
      "name" : "Ashley Maciag",
      "screen_name" : "SoCaLicous",
      "protected" : false,
      "id_str" : "273235048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782757236418416640\/rgPMbujP_normal.jpg",
      "id" : 273235048,
      "verified" : false
    }
  },
  "id" : 685569068301180928,
  "created_at" : "2016-01-08 21:09:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685506760048652288",
  "geo" : { },
  "id_str" : "685568300286373889",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater oh no.. ((hugs))",
  "id" : 685568300286373889,
  "in_reply_to_status_id" : 685506760048652288,
  "created_at" : "2016-01-08 21:06:34 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/685512909095448576\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/CaD5uymvjV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNuWWTUoAAvRMk.jpg",
      "id_str" : "685512898513248256",
      "id" : 685512898513248256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNuWWTUoAAvRMk.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CaD5uymvjV"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 52, 58 ]
    }, {
      "text" : "throughmywindow",
      "indices" : [ 59, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685514265621573632",
  "text" : "RT @rm123077: Sharp-tailed Grouse in my front yard. #birds #throughmywindow https:\/\/t.co\/CaD5uymvjV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/685512909095448576\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/CaD5uymvjV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNuWWTUoAAvRMk.jpg",
        "id_str" : "685512898513248256",
        "id" : 685512898513248256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNuWWTUoAAvRMk.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CaD5uymvjV"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 38, 44 ]
      }, {
        "text" : "throughmywindow",
        "indices" : [ 45, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685512909095448576",
    "text" : "Sharp-tailed Grouse in my front yard. #birds #throughmywindow https:\/\/t.co\/CaD5uymvjV",
    "id" : 685512909095448576,
    "created_at" : "2016-01-08 17:26:28 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 685514265621573632,
  "created_at" : "2016-01-08 17:31:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mystic Aquarium",
      "screen_name" : "mysticaquarium",
      "indices" : [ 3, 18 ],
      "id_str" : "28197486",
      "id" : 28197486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685514029566160896",
  "text" : "RT @mysticaquarium: Josh Davis and Eric Fox show off one of their hobbies of knitting, which they learned from Intern Donna D. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mysticaquarium\/status\/685513881352024065\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/LoDrHZMW3i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYNvPgGWAAEWXZe.jpg",
        "id_str" : "685513880395710465",
        "id" : 685513880395710465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYNvPgGWAAEWXZe.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LoDrHZMW3i"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685513881352024065",
    "text" : "Josh Davis and Eric Fox show off one of their hobbies of knitting, which they learned from Intern Donna D. https:\/\/t.co\/LoDrHZMW3i",
    "id" : 685513881352024065,
    "created_at" : "2016-01-08 17:30:20 +0000",
    "user" : {
      "name" : "Mystic Aquarium",
      "screen_name" : "mysticaquarium",
      "protected" : false,
      "id_str" : "28197486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742402269812002817\/VZ-K89Zp_normal.jpg",
      "id" : 28197486,
      "verified" : true
    }
  },
  "id" : 685514029566160896,
  "created_at" : "2016-01-08 17:30:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grazer",
      "screen_name" : "FrontlineXian",
      "indices" : [ 3, 17 ],
      "id_str" : "555034729",
      "id" : 555034729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/xb33WqTmvZ",
      "expanded_url" : "https:\/\/twitter.com\/WipeHomophobia\/status\/685400099275599872",
      "display_url" : "twitter.com\/WipeHomophobia\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685513675134873600",
  "text" : "RT @FrontlineXian: That's a coffee all over keyboard moment :) https:\/\/t.co\/xb33WqTmvZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/xb33WqTmvZ",
        "expanded_url" : "https:\/\/twitter.com\/WipeHomophobia\/status\/685400099275599872",
        "display_url" : "twitter.com\/WipeHomophobia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685400467216691200",
    "text" : "That's a coffee all over keyboard moment :) https:\/\/t.co\/xb33WqTmvZ",
    "id" : 685400467216691200,
    "created_at" : "2016-01-08 09:59:40 +0000",
    "user" : {
      "name" : "Grazer",
      "screen_name" : "FrontlineXian",
      "protected" : false,
      "id_str" : "555034729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613640482585866240\/zNR2NWwy_normal.png",
      "id" : 555034729,
      "verified" : false
    }
  },
  "id" : 685513675134873600,
  "created_at" : "2016-01-08 17:29:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Howell",
      "screen_name" : "shinydh",
      "indices" : [ 3, 11 ],
      "id_str" : "46467757",
      "id" : 46467757
    }, {
      "name" : "myou",
      "screen_name" : "myou_pub",
      "indices" : [ 52, 61 ],
      "id_str" : "3252798247",
      "id" : 3252798247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685305511944826881",
  "text" : "RT @shinydh: I am going to be transitioning towards @myou_pub as my microblogging account. At present, it's a simulcast with Twitter.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "myou",
        "screen_name" : "myou_pub",
        "indices" : [ 39, 48 ],
        "id_str" : "3252798247",
        "id" : 3252798247
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685207142840713218",
    "text" : "I am going to be transitioning towards @myou_pub as my microblogging account. At present, it's a simulcast with Twitter.",
    "id" : 685207142840713218,
    "created_at" : "2016-01-07 21:11:28 +0000",
    "user" : {
      "name" : "David Howell",
      "screen_name" : "shinydh",
      "protected" : false,
      "id_str" : "46467757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774222566907060224\/m03_pBCH_normal.jpg",
      "id" : 46467757,
      "verified" : false
    }
  },
  "id" : 685305511944826881,
  "created_at" : "2016-01-08 03:42:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685303019320283136",
  "text" : "RT @CoryBooker: Be kind to one another for we are all more fragile than we let on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685299312306327552",
    "text" : "Be kind to one another for we are all more fragile than we let on.",
    "id" : 685299312306327552,
    "created_at" : "2016-01-08 03:17:42 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 685303019320283136,
  "created_at" : "2016-01-08 03:32:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30D4\u30B9\u30B1\u30F3",
      "screen_name" : "kinpika_3",
      "indices" : [ 3, 13 ],
      "id_str" : "3168571506",
      "id" : 3168571506
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kinpika_3\/status\/685287992877961216\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/2ubte0bwYI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYKhyeAUQAEacLs.jpg",
      "id_str" : "685287981733658625",
      "id" : 685287981733658625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYKhyeAUQAEacLs.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 399
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 399
      } ],
      "display_url" : "pic.twitter.com\/2ubte0bwYI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685293350581321728",
  "text" : "RT @kinpika_3: \uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE01\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C https:\/\/t.co\/2ubte0bwYI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kinpika_3\/status\/685287992877961216\/photo\/1",
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/2ubte0bwYI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYKhyeAUQAEacLs.jpg",
        "id_str" : "685287981733658625",
        "id" : 685287981733658625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYKhyeAUQAEacLs.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 399
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 399
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 399
        } ],
        "display_url" : "pic.twitter.com\/2ubte0bwYI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685287992877961216",
    "text" : "\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE01\uD83D\uDE2C\uD83D\uDE2C\uD83D\uDE2C https:\/\/t.co\/2ubte0bwYI",
    "id" : 685287992877961216,
    "created_at" : "2016-01-08 02:32:44 +0000",
    "user" : {
      "name" : "\u30D4\u30B9\u30B1\u30F3",
      "screen_name" : "kinpika_3",
      "protected" : false,
      "id_str" : "3168571506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743051000185901056\/svENc2Km_normal.jpg",
      "id" : 3168571506,
      "verified" : false
    }
  },
  "id" : 685293350581321728,
  "created_at" : "2016-01-08 02:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/652978172825370624\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/1c4ZkHMoYw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ_YMDoW8AAAc4b.jpg",
      "id_str" : "652978172636622848",
      "id" : 652978172636622848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ_YMDoW8AAAc4b.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1c4ZkHMoYw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685293019306786819",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/1c4ZkHMoYw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/652978172825370624\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/1c4ZkHMoYw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ_YMDoW8AAAc4b.jpg",
        "id_str" : "652978172636622848",
        "id" : 652978172636622848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ_YMDoW8AAAc4b.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1c4ZkHMoYw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685289843279134721",
    "text" : "https:\/\/t.co\/1c4ZkHMoYw",
    "id" : 685289843279134721,
    "created_at" : "2016-01-08 02:40:05 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 685293019306786819,
  "created_at" : "2016-01-08 02:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/506125076597440512\/photo\/1",
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/XYWFnmXnh8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
      "id_str" : "506125076387729408",
      "id" : 506125076387729408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XYWFnmXnh8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685289401707020288",
  "text" : "RT @Elverojaguar: https:\/\/t.co\/XYWFnmXnh8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/506125076597440512\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/XYWFnmXnh8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
        "id_str" : "506125076387729408",
        "id" : 506125076387729408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XYWFnmXnh8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685279861330546688",
    "text" : "https:\/\/t.co\/XYWFnmXnh8",
    "id" : 685279861330546688,
    "created_at" : "2016-01-08 02:00:25 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 685289401707020288,
  "created_at" : "2016-01-08 02:38:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MHarvey",
      "screen_name" : "mharvey816",
      "indices" : [ 3, 14 ],
      "id_str" : "20737589",
      "id" : 20737589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/6smdvlut3H",
      "expanded_url" : "https:\/\/twitter.com\/PhilipRucker\/status\/685264993097482241",
      "display_url" : "twitter.com\/PhilipRucker\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "685268106692935680",
  "text" : "RT @mharvey816: Wait, what? https:\/\/t.co\/6smdvlut3H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/6smdvlut3H",
        "expanded_url" : "https:\/\/twitter.com\/PhilipRucker\/status\/685264993097482241",
        "display_url" : "twitter.com\/PhilipRucker\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685266395207172097",
    "text" : "Wait, what? https:\/\/t.co\/6smdvlut3H",
    "id" : 685266395207172097,
    "created_at" : "2016-01-08 01:06:54 +0000",
    "user" : {
      "name" : "MHarvey",
      "screen_name" : "mharvey816",
      "protected" : false,
      "id_str" : "20737589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717136591559462912\/d2q3rsjo_normal.jpg",
      "id" : 20737589,
      "verified" : false
    }
  },
  "id" : 685268106692935680,
  "created_at" : "2016-01-08 01:13:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685260743193792517",
  "text" : "RT @ZachsMind: Agreed. Given modern technology we should have the bare necessities provided for all mankind by now, no worries.  https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/mBb6FF9foZ",
        "expanded_url" : "https:\/\/twitter.com\/viznix\/status\/685249964084039680",
        "display_url" : "twitter.com\/viznix\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "685255876052029440",
    "text" : "Agreed. Given modern technology we should have the bare necessities provided for all mankind by now, no worries.  https:\/\/t.co\/mBb6FF9foZ",
    "id" : 685255876052029440,
    "created_at" : "2016-01-08 00:25:06 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 685260743193792517,
  "created_at" : "2016-01-08 00:44:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neurotic",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685259932921364481",
  "text" : "wanted to get moisturizer today while picking up rx's.. spent 10 minutes looking at all the choices but couldn't decide. #neurotic",
  "id" : 685259932921364481,
  "created_at" : "2016-01-08 00:41:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Ashby",
      "screen_name" : "JM_Ashby",
      "indices" : [ 3, 12 ],
      "id_str" : "214206294",
      "id" : 214206294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685180513464750080",
  "text" : "RT @JM_Ashby: For Paul Ryan, kicking millions of people off Medicaid is just numbers in a spread sheet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685178051966164992",
    "text" : "For Paul Ryan, kicking millions of people off Medicaid is just numbers in a spread sheet.",
    "id" : 685178051966164992,
    "created_at" : "2016-01-07 19:15:52 +0000",
    "user" : {
      "name" : "Jordan Ashby",
      "screen_name" : "JM_Ashby",
      "protected" : false,
      "id_str" : "214206294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424632151053570048\/TDGLYnS1_normal.jpeg",
      "id" : 214206294,
      "verified" : false
    }
  },
  "id" : 685180513464750080,
  "created_at" : "2016-01-07 19:25:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685179983342469120",
  "text" : "out of the blue.. music box music from dining room... ghosts are playing around.",
  "id" : 685179983342469120,
  "created_at" : "2016-01-07 19:23:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noame",
      "screen_name" : "2noame",
      "indices" : [ 3, 10 ],
      "id_str" : "763407955471499264",
      "id" : 763407955471499264
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basicincome",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/3j1IecpNEt",
      "expanded_url" : "http:\/\/www.scottsantens.com\/raffling-basic-income-first-germany-then-the-netherlands-and-now-the-us",
      "display_url" : "scottsantens.com\/raffling-basic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684922609121783808",
  "text" : "RT @2noame: What does #basicincome taste like? Some Germans, Dutch, and Americans are finding out... https:\/\/t.co\/3j1IecpNEt https:\/\/t.co\/l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/2noame\/status\/684920276459454464\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/lqImDcXua9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYFTXKYUsAAXNnn.png",
        "id_str" : "684920275725496320",
        "id" : 684920275725496320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYFTXKYUsAAXNnn.png",
        "sizes" : [ {
          "h" : 276,
          "resize" : "fit",
          "w" : 803
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 117,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 803
        } ],
        "display_url" : "pic.twitter.com\/lqImDcXua9"
      } ],
      "hashtags" : [ {
        "text" : "basicincome",
        "indices" : [ 10, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/3j1IecpNEt",
        "expanded_url" : "http:\/\/www.scottsantens.com\/raffling-basic-income-first-germany-then-the-netherlands-and-now-the-us",
        "display_url" : "scottsantens.com\/raffling-basic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684920276459454464",
    "text" : "What does #basicincome taste like? Some Germans, Dutch, and Americans are finding out... https:\/\/t.co\/3j1IecpNEt https:\/\/t.co\/lqImDcXua9",
    "id" : 684920276459454464,
    "created_at" : "2016-01-07 02:11:33 +0000",
    "user" : {
      "name" : "Scott Santens",
      "screen_name" : "scottsantens",
      "protected" : false,
      "id_str" : "14297863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728327801028239360\/QVZeVLgz_normal.jpg",
      "id" : 14297863,
      "verified" : true
    }
  },
  "id" : 684922609121783808,
  "created_at" : "2016-01-07 02:20:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ferner",
      "screen_name" : "matthewferner",
      "indices" : [ 3, 17 ],
      "id_str" : "187426352",
      "id" : 187426352
    }, {
      "name" : "HuffPost BlackVoices",
      "screen_name" : "blackvoices",
      "indices" : [ 111, 123 ],
      "id_str" : "13557972",
      "id" : 13557972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/b2aC0VB2CA",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/perjury-charges-filed-against-trooper-who-arrested-sandra-bland_568d93f1e4b0cad15e634e8d",
      "display_url" : "huffingtonpost.com\/entry\/perjury-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684864889198919681",
  "text" : "RT @matthewferner: Perjury charges filed against trooper who arrested Sandra Bland https:\/\/t.co\/b2aC0VB2CA via @blackvoices",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost BlackVoices",
        "screen_name" : "blackvoices",
        "indices" : [ 92, 104 ],
        "id_str" : "13557972",
        "id" : 13557972
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/b2aC0VB2CA",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/entry\/perjury-charges-filed-against-trooper-who-arrested-sandra-bland_568d93f1e4b0cad15e634e8d",
        "display_url" : "huffingtonpost.com\/entry\/perjury-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684864628396965888",
    "text" : "Perjury charges filed against trooper who arrested Sandra Bland https:\/\/t.co\/b2aC0VB2CA via @blackvoices",
    "id" : 684864628396965888,
    "created_at" : "2016-01-06 22:30:26 +0000",
    "user" : {
      "name" : "Matt Ferner",
      "screen_name" : "matthewferner",
      "protected" : false,
      "id_str" : "187426352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583410719070093312\/Z6XW8901_normal.jpg",
      "id" : 187426352,
      "verified" : true
    }
  },
  "id" : 684864889198919681,
  "created_at" : "2016-01-06 22:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adblocker",
      "indices" : [ 50, 60 ]
    }, {
      "text" : "privacy",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "hardware",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/bTTTGjEMU2",
      "expanded_url" : "http:\/\/the-digital-reader.com\/2016\/01\/06\/eblocker-offers-a-hardware-solution-to-the-online-privacy-problem\/",
      "display_url" : "the-digital-reader.com\/2016\/01\/06\/ebl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684845719715450881",
  "text" : "interesting &gt; Eblocker https:\/\/t.co\/bTTTGjEMU2 #adblocker #privacy #hardware",
  "id" : 684845719715450881,
  "created_at" : "2016-01-06 21:15:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AudiobookJukebox",
      "screen_name" : "audiobkjkbx",
      "indices" : [ 3, 15 ],
      "id_str" : "181671424",
      "id" : 181671424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684783249814589441",
  "text" : "RT @audiobkjkbx: If you're a book blogger, stop by to select an audiobook to review. Just want to listen? We have links to thousands of aud\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683118785486807040",
    "text" : "If you're a book blogger, stop by to select an audiobook to review. Just want to listen? We have links to thousands of audiobook reviews.",
    "id" : 683118785486807040,
    "created_at" : "2016-01-02 02:53:04 +0000",
    "user" : {
      "name" : "AudiobookJukebox",
      "screen_name" : "audiobkjkbx",
      "protected" : false,
      "id_str" : "181671424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1108703536\/maroonjukebox125notitle_normal.jpg",
      "id" : 181671424,
      "verified" : false
    }
  },
  "id" : 684783249814589441,
  "created_at" : "2016-01-06 17:07:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Y0IImu0Zdk",
      "expanded_url" : "http:\/\/bookwi.se\/where-to-find-free-books\/",
      "display_url" : "bookwi.se\/where-to-find-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684574942713765888",
  "text" : "RT @adamrshields: Where to Find Free Kindle Books - I accidentally deleted this old post, so I am reposting. https:\/\/t.co\/Y0IImu0Zdk https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/adamrshields\/status\/684565273999880192\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/niJ2QTQv6G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYAQfR_UAAE39MC.jpg",
        "id_str" : "684565272951259137",
        "id" : 684565272951259137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYAQfR_UAAE39MC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 280
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 280
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 280
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 280
        } ],
        "display_url" : "pic.twitter.com\/niJ2QTQv6G"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/Y0IImu0Zdk",
        "expanded_url" : "http:\/\/bookwi.se\/where-to-find-free-books\/",
        "display_url" : "bookwi.se\/where-to-find-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684565273999880192",
    "text" : "Where to Find Free Kindle Books - I accidentally deleted this old post, so I am reposting. https:\/\/t.co\/Y0IImu0Zdk https:\/\/t.co\/niJ2QTQv6G",
    "id" : 684565273999880192,
    "created_at" : "2016-01-06 02:40:54 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 684574942713765888,
  "created_at" : "2016-01-06 03:19:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/06zV0e29Tr",
      "expanded_url" : "https:\/\/twitter.com\/HachetteAudio\/status\/684478236042997760",
      "display_url" : "twitter.com\/HachetteAudio\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684497843650953216",
  "text" : "also $4.95 audiobook via amazon (but not audible..weird?) https:\/\/t.co\/06zV0e29Tr",
  "id" : 684497843650953216,
  "created_at" : "2016-01-05 22:12:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebook",
      "indices" : [ 0, 6 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 7, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/qM0eCZ3cgM",
      "expanded_url" : "https:\/\/twitter.com\/adamrshields\/status\/684441896987447297",
      "display_url" : "twitter.com\/adamrshields\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684492681515544577",
  "text" : "#ebook #audiobook lovers should be reading this blog. reviews, sales and good info. https:\/\/t.co\/qM0eCZ3cgM",
  "id" : 684492681515544577,
  "created_at" : "2016-01-05 21:52:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "684473924109783040",
  "geo" : { },
  "id_str" : "684491627851808769",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater i like the red sweater w black polka dot shirt.. and is that gold eye shadow? nice. : )",
  "id" : 684491627851808769,
  "in_reply_to_status_id" : 684473924109783040,
  "created_at" : "2016-01-05 21:48:15 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684433616634556416",
  "text" : "finished Gone Girl by Gillian Flynn (audiobook) last night. oh my.. my emotions were all over while reading.",
  "id" : 684433616634556416,
  "created_at" : "2016-01-05 17:57:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684432674728112128",
  "text" : "grateful for kind people. : )",
  "id" : 684432674728112128,
  "created_at" : "2016-01-05 17:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "indices" : [ 3, 18 ],
      "id_str" : "26560483",
      "id" : 26560483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Msij9IlRVF",
      "expanded_url" : "https:\/\/twitter.com\/The_Millions\/status\/684139141370654721",
      "display_url" : "twitter.com\/The_Millions\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684432260561526785",
  "text" : "RT @MacmillanAudio: And so the to-read (listen) list grows... Which 2016 titles are you all most looking forward to? https:\/\/t.co\/Msij9IlRVF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/Msij9IlRVF",
        "expanded_url" : "https:\/\/twitter.com\/The_Millions\/status\/684139141370654721",
        "display_url" : "twitter.com\/The_Millions\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "684380593308741632",
    "text" : "And so the to-read (listen) list grows... Which 2016 titles are you all most looking forward to? https:\/\/t.co\/Msij9IlRVF",
    "id" : 684380593308741632,
    "created_at" : "2016-01-05 14:27:03 +0000",
    "user" : {
      "name" : "Macmillan Audio",
      "screen_name" : "MacmillanAudio",
      "protected" : false,
      "id_str" : "26560483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473834349394010112\/_cwv_j5v_normal.jpeg",
      "id" : 26560483,
      "verified" : true
    }
  },
  "id" : 684432260561526785,
  "created_at" : "2016-01-05 17:52:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Green",
      "screen_name" : "agreenphotog",
      "indices" : [ 3, 16 ],
      "id_str" : "1556417040",
      "id" : 1556417040
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/agreenphotog\/status\/684101158269370368\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/lHf7StiwWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX5qXKXW8AQ1VKL.jpg",
      "id_str" : "684101139558756356",
      "id" : 684101139558756356,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX5qXKXW8AQ1VKL.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lHf7StiwWP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684207154354597888",
  "text" : "RT @agreenphotog: Members of the Fitchburg Fire Dept. remove swans from Coggshall Park for the winter https:\/\/t.co\/lHf7StiwWP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/agreenphotog\/status\/684101158269370368\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/lHf7StiwWP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX5qXKXW8AQ1VKL.jpg",
        "id_str" : "684101139558756356",
        "id" : 684101139558756356,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX5qXKXW8AQ1VKL.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lHf7StiwWP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684101158269370368",
    "text" : "Members of the Fitchburg Fire Dept. remove swans from Coggshall Park for the winter https:\/\/t.co\/lHf7StiwWP",
    "id" : 684101158269370368,
    "created_at" : "2016-01-04 19:56:40 +0000",
    "user" : {
      "name" : "Ashley Green",
      "screen_name" : "agreenphotog",
      "protected" : false,
      "id_str" : "1556417040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770799773653884928\/begOH0TV_normal.jpg",
      "id" : 1556417040,
      "verified" : false
    }
  },
  "id" : 684207154354597888,
  "created_at" : "2016-01-05 02:57:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "indices" : [ 3, 19 ],
      "id_str" : "364856414",
      "id" : 364856414
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/684193812344889344\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/bIfnoHoHpk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6-pSmW8AABC1L.jpg",
      "id_str" : "684193809983533056",
      "id" : 684193809983533056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6-pSmW8AABC1L.jpg",
      "sizes" : [ {
        "h" : 2837,
        "resize" : "fit",
        "w" : 2837
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bIfnoHoHpk"
    } ],
    "hashtags" : [ {
      "text" : "cats",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "CatsOfTwitter",
      "indices" : [ 59, 73 ]
    }, {
      "text" : "catshaming",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "catsinbags",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684199113739603969",
  "text" : "RT @ThomMoorePhotos: Time to unpack the groceries... #cats #CatsOfTwitter #catshaming #catsinbags https:\/\/t.co\/bIfnoHoHpk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThomMoorePhotos\/status\/684193812344889344\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/bIfnoHoHpk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX6-pSmW8AABC1L.jpg",
        "id_str" : "684193809983533056",
        "id" : 684193809983533056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX6-pSmW8AABC1L.jpg",
        "sizes" : [ {
          "h" : 2837,
          "resize" : "fit",
          "w" : 2837
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/bIfnoHoHpk"
      } ],
      "hashtags" : [ {
        "text" : "cats",
        "indices" : [ 32, 37 ]
      }, {
        "text" : "CatsOfTwitter",
        "indices" : [ 38, 52 ]
      }, {
        "text" : "catshaming",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "catsinbags",
        "indices" : [ 65, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684193812344889344",
    "text" : "Time to unpack the groceries... #cats #CatsOfTwitter #catshaming #catsinbags https:\/\/t.co\/bIfnoHoHpk",
    "id" : 684193812344889344,
    "created_at" : "2016-01-05 02:04:51 +0000",
    "user" : {
      "name" : "Thom Moore",
      "screen_name" : "ThomMoorePhotos",
      "protected" : false,
      "id_str" : "364856414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770204744543563776\/cS24tsF9_normal.jpg",
      "id" : 364856414,
      "verified" : false
    }
  },
  "id" : 684199113739603969,
  "created_at" : "2016-01-05 02:25:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Gerencser",
      "screen_name" : "BruceGerencser",
      "indices" : [ 112, 127 ],
      "id_str" : "2954308119",
      "id" : 2954308119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/RSLb60L8LM",
      "expanded_url" : "http:\/\/brucegerencser.net\/2016\/01\/hey-girlfriend-is-it-a-sin-to-kiss-your-boyfriend\/",
      "display_url" : "brucegerencser.net\/2016\/01\/hey-gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "684176100436635648",
  "text" : "ROTFLMAO at the video! &gt;&gt; Hey Girlfriend: Is it a Sin to Kiss Your Boyfriend? https:\/\/t.co\/RSLb60L8LM via @BruceGerencser",
  "id" : 684176100436635648,
  "created_at" : "2016-01-05 00:54:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLBOOK",
      "screen_name" : "LOLBOOKcom",
      "indices" : [ 3, 14 ],
      "id_str" : "2820857447",
      "id" : 2820857447
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOLBook",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "relationshipproblems",
      "indices" : [ 79, 100 ]
    }, {
      "text" : "cuddles",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "cutecat",
      "indices" : [ 110, 118 ]
    }, {
      "text" : "cathug",
      "indices" : [ 119, 126 ]
    }, {
      "text" : "vine",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684172584359964672",
  "text" : "RT @LOLBOOKcom: We fight, we break up. We kiss, we make up. *cuddles* #LOLBook #relationshipproblems #cuddles #cutecat #cathug #vine https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LOLBook",
        "indices" : [ 54, 62 ]
      }, {
        "text" : "relationshipproblems",
        "indices" : [ 63, 84 ]
      }, {
        "text" : "cuddles",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "cutecat",
        "indices" : [ 94, 102 ]
      }, {
        "text" : "cathug",
        "indices" : [ 103, 110 ]
      }, {
        "text" : "vine",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/52H9VmEYTz",
        "expanded_url" : "https:\/\/vine.co\/v\/iqrObaXVzgP",
        "display_url" : "vine.co\/v\/iqrObaXVzgP"
      } ]
    },
    "geo" : { },
    "id_str" : "684142454531043329",
    "text" : "We fight, we break up. We kiss, we make up. *cuddles* #LOLBook #relationshipproblems #cuddles #cutecat #cathug #vine https:\/\/t.co\/52H9VmEYTz",
    "id" : 684142454531043329,
    "created_at" : "2016-01-04 22:40:46 +0000",
    "user" : {
      "name" : "LOLBOOK",
      "screen_name" : "LOLBOOKcom",
      "protected" : false,
      "id_str" : "2820857447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727444953211670528\/NVR5KSn7_normal.jpg",
      "id" : 2820857447,
      "verified" : false
    }
  },
  "id" : 684172584359964672,
  "created_at" : "2016-01-05 00:40:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Bowler",
      "screen_name" : "RichardBowler1",
      "indices" : [ 3, 18 ],
      "id_str" : "553323788",
      "id" : 553323788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684156665814450176",
  "text" : "RT @RichardBowler1: Thought you may like to see my xmas tree, taken sitting on the sofa yesterday, lazy wildlife photography :-) https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RichardBowler1\/status\/683549653309239296\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/M7OBahyOc1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXx0yXwWsAAPQfw.jpg",
        "id_str" : "683549652172582912",
        "id" : 683549652172582912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXx0yXwWsAAPQfw.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/M7OBahyOc1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683549653309239296",
    "text" : "Thought you may like to see my xmas tree, taken sitting on the sofa yesterday, lazy wildlife photography :-) https:\/\/t.co\/M7OBahyOc1",
    "id" : 683549653309239296,
    "created_at" : "2016-01-03 07:25:11 +0000",
    "user" : {
      "name" : "Richard Bowler",
      "screen_name" : "RichardBowler1",
      "protected" : false,
      "id_str" : "553323788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681757270745587712\/RfB32azg_normal.png",
      "id" : 553323788,
      "verified" : false
    }
  },
  "id" : 684156665814450176,
  "created_at" : "2016-01-04 23:37:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "indices" : [ 3, 16 ],
      "id_str" : "2423532173",
      "id" : 2423532173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/684102759545737217\/video\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/0v6GeXk7Hr",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/684100446655496197\/pu\/img\/-e4SP4QQmJfcEpNQ.jpg",
      "id_str" : "684100446655496197",
      "id" : 684100446655496197,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/684100446655496197\/pu\/img\/-e4SP4QQmJfcEpNQ.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0v6GeXk7Hr"
    } ],
    "hashtags" : [ {
      "text" : "highlandcalves",
      "indices" : [ 31, 46 ]
    }, {
      "text" : "isleofiona",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684109946426920960",
  "text" : "RT @Maolfarmiona: Happy coos!! #highlandcalves munching up their hay #isleofiona https:\/\/t.co\/0v6GeXk7Hr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maolfarmiona\/status\/684102759545737217\/video\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/0v6GeXk7Hr",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/684100446655496197\/pu\/img\/-e4SP4QQmJfcEpNQ.jpg",
        "id_str" : "684100446655496197",
        "id" : 684100446655496197,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/684100446655496197\/pu\/img\/-e4SP4QQmJfcEpNQ.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/0v6GeXk7Hr"
      } ],
      "hashtags" : [ {
        "text" : "highlandcalves",
        "indices" : [ 13, 28 ]
      }, {
        "text" : "isleofiona",
        "indices" : [ 51, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "684102759545737217",
    "text" : "Happy coos!! #highlandcalves munching up their hay #isleofiona https:\/\/t.co\/0v6GeXk7Hr",
    "id" : 684102759545737217,
    "created_at" : "2016-01-04 20:03:02 +0000",
    "user" : {
      "name" : "andrew prentice",
      "screen_name" : "Maolfarmiona",
      "protected" : false,
      "id_str" : "2423532173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798860009874472961\/v5GADWSz_normal.jpg",
      "id" : 2423532173,
      "verified" : false
    }
  },
  "id" : 684109946426920960,
  "created_at" : "2016-01-04 20:31:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683852147558100992",
  "text" : "RT @adamrshields: Free 32 minute lecture from Great Courses on Sherlock Holmes as the first great detective in lit from Audible https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Iug5r202ZF",
        "expanded_url" : "http:\/\/www.audible.com\/pd\/Classics\/Free-Sherlock-Holmes-The-First-Great-Detective-Audiobook\/B019ZBDN80",
        "display_url" : "audible.com\/pd\/Classics\/Fr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683845264931688448",
    "text" : "Free 32 minute lecture from Great Courses on Sherlock Holmes as the first great detective in lit from Audible https:\/\/t.co\/Iug5r202ZF",
    "id" : 683845264931688448,
    "created_at" : "2016-01-04 02:59:51 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 683852147558100992,
  "created_at" : "2016-01-04 03:27:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JAScribbles\/status\/683835998489346049\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/fJT5F50vXE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX15N5SU0AESqs7.jpg",
      "id_str" : "683835998053126145",
      "id" : 683835998053126145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX15N5SU0AESqs7.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/fJT5F50vXE"
    } ],
    "hashtags" : [ {
      "text" : "crocheting",
      "indices" : [ 36, 47 ]
    }, {
      "text" : "HOTH",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683844698230931456",
  "text" : "RT @JAScribbles: I'm done. Kind of. #crocheting #HOTH https:\/\/t.co\/fJT5F50vXE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JAScribbles\/status\/683835998489346049\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/fJT5F50vXE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX15N5SU0AESqs7.jpg",
        "id_str" : "683835998053126145",
        "id" : 683835998053126145,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX15N5SU0AESqs7.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/fJT5F50vXE"
      } ],
      "hashtags" : [ {
        "text" : "crocheting",
        "indices" : [ 19, 30 ]
      }, {
        "text" : "HOTH",
        "indices" : [ 31, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683835998489346049",
    "text" : "I'm done. Kind of. #crocheting #HOTH https:\/\/t.co\/fJT5F50vXE",
    "id" : 683835998489346049,
    "created_at" : "2016-01-04 02:23:01 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 683844698230931456,
  "created_at" : "2016-01-04 02:57:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha for android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antoinette Ravenhall",
      "screen_name" : "Vamp_Blackrose",
      "indices" : [ 3, 18 ],
      "id_str" : "554509993",
      "id" : 554509993
    }, {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 20, 34 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Vamp_Blackrose\/status\/683771600068571136\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/Yy3TAH8CAd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-pWdWsAAML04.jpg",
      "id_str" : "683771598554443776",
      "id" : 683771598554443776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-pWdWsAAML04.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Yy3TAH8CAd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Vamp_Blackrose\/status\/683771600068571136\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/Yy3TAH8CAd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-pYfWMAIRiVu.jpg",
      "id_str" : "683771599099670530",
      "id" : 683771599099670530,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-pYfWMAIRiVu.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Yy3TAH8CAd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Vamp_Blackrose\/status\/683771600068571136\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/Yy3TAH8CAd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-pYgWQAArtcD.jpg",
      "id_str" : "683771599103868928",
      "id" : 683771599103868928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-pYgWQAArtcD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Yy3TAH8CAd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683844142527606785",
  "text" : "RT @Vamp_Blackrose: @BrianRathbone https:\/\/t.co\/Yy3TAH8CAd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fantasy Author",
        "screen_name" : "BrianRathbone",
        "indices" : [ 0, 14 ],
        "id_str" : "16494321",
        "id" : 16494321
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Vamp_Blackrose\/status\/683771600068571136\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/Yy3TAH8CAd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-pWdWsAAML04.jpg",
        "id_str" : "683771598554443776",
        "id" : 683771598554443776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-pWdWsAAML04.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Yy3TAH8CAd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Vamp_Blackrose\/status\/683771600068571136\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/Yy3TAH8CAd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-pYfWMAIRiVu.jpg",
        "id_str" : "683771599099670530",
        "id" : 683771599099670530,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-pYfWMAIRiVu.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Yy3TAH8CAd"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Vamp_Blackrose\/status\/683771600068571136\/photo\/1",
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/Yy3TAH8CAd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CX0-pYgWQAArtcD.jpg",
        "id_str" : "683771599103868928",
        "id" : 683771599103868928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CX0-pYgWQAArtcD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Yy3TAH8CAd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "683771261638557696",
    "geo" : { },
    "id_str" : "683771600068571136",
    "in_reply_to_user_id" : 554509993,
    "text" : "@BrianRathbone https:\/\/t.co\/Yy3TAH8CAd",
    "id" : 683771600068571136,
    "in_reply_to_status_id" : 683771261638557696,
    "created_at" : "2016-01-03 22:07:07 +0000",
    "in_reply_to_screen_name" : "Vamp_Blackrose",
    "in_reply_to_user_id_str" : "554509993",
    "user" : {
      "name" : "Antoinette Ravenhall",
      "screen_name" : "Vamp_Blackrose",
      "protected" : false,
      "id_str" : "554509993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791650035075260416\/QcAIMi0U_normal.jpg",
      "id" : 554509993,
      "verified" : false
    }
  },
  "id" : 683844142527606785,
  "created_at" : "2016-01-04 02:55:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683775041599766528",
  "geo" : { },
  "id_str" : "683789872537141248",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater ohh.. I like it very much!",
  "id" : 683789872537141248,
  "in_reply_to_status_id" : 683775041599766528,
  "created_at" : "2016-01-03 23:19:44 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/D7tgmg901U",
      "expanded_url" : "https:\/\/boingboing.net\/2015\/12\/31\/nh-republican-lawmakers-harass.html",
      "display_url" : "boingboing.net\/2015\/12\/31\/nh-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683775258223087616",
  "text" : "RT @BoingBoing: NH Republican lawmakers say they can grab women's nipples in public. So much for small gov't https:\/\/t.co\/D7tgmg901U https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoingBoing\/status\/683516425923866625\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/NT1M9kuz6I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXxWkVTW8AATd9y.jpg",
        "id_str" : "683516425647091712",
        "id" : 683516425647091712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXxWkVTW8AATd9y.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/NT1M9kuz6I"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/D7tgmg901U",
        "expanded_url" : "https:\/\/boingboing.net\/2015\/12\/31\/nh-republican-lawmakers-harass.html",
        "display_url" : "boingboing.net\/2015\/12\/31\/nh-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "683516425923866625",
    "text" : "NH Republican lawmakers say they can grab women's nipples in public. So much for small gov't https:\/\/t.co\/D7tgmg901U https:\/\/t.co\/NT1M9kuz6I",
    "id" : 683516425923866625,
    "created_at" : "2016-01-03 05:13:09 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 683775258223087616,
  "created_at" : "2016-01-03 22:21:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Hays",
      "screen_name" : "FiatCelebrity",
      "indices" : [ 66, 80 ],
      "id_str" : "99818543",
      "id" : 99818543
    }, {
      "name" : "Audiobook Reviewer",
      "screen_name" : "AudioBookRev",
      "indices" : [ 81, 94 ],
      "id_str" : "457997266",
      "id" : 457997266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "urbanfantasy",
      "indices" : [ 10, 23 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 24, 34 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/EnLrfgj3Wr",
      "expanded_url" : "http:\/\/audiobookreviewer.com\/reviews\/betrayal-the-divine-series-book-2-by-m-r-forbes\/",
      "display_url" : "audiobookreviewer.com\/reviews\/betray\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683721988003749888",
  "text" : "I entered #urbanfantasy #audiobook #giveaway for several works of @FiatCelebrity @audioBookRev https:\/\/t.co\/EnLrfgj3Wr",
  "id" : 683721988003749888,
  "created_at" : "2016-01-03 18:49:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683720383565029376",
  "text" : "RT @adamrshields: Can any SEO people comment about deleting all of the old sale and free book posts from Bookwi.es? I have nearly 1300 revi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683711516118482944",
    "text" : "Can any SEO people comment about deleting all of the old sale and free book posts from Bookwi.es? I have nearly 1300 reviews",
    "id" : 683711516118482944,
    "created_at" : "2016-01-03 18:08:22 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 683720383565029376,
  "created_at" : "2016-01-03 18:43:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683719882664448002",
  "text" : "RT @adamrshields: Just drafted the 5000th Bookwi.se post for Wednesday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683711310304002048",
    "text" : "Just drafted the 5000th Bookwi.se post for Wednesday.",
    "id" : 683711310304002048,
    "created_at" : "2016-01-03 18:07:33 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 683719882664448002,
  "created_at" : "2016-01-03 18:41:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceAlert",
      "screen_name" : "ScienceAlert",
      "indices" : [ 100, 113 ],
      "id_str" : "60813201",
      "id" : 60813201
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "via",
      "indices" : [ 95, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/6fBi0fA8mF",
      "expanded_url" : "http:\/\/www.sciencealert.com\/here-s-the-simple-proof-that-there-must-be-multiple-levels-of-infinity",
      "display_url" : "sciencealert.com\/here-s-the-sim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683702842339766274",
  "text" : "Here\u2019s the simple proof that there must be multiple levels of infinity https:\/\/t.co\/6fBi0fA8mF #via @ScienceAlert",
  "id" : 683702842339766274,
  "created_at" : "2016-01-03 17:33:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlanBaxter",
      "screen_name" : "AlanBaxter",
      "indices" : [ 3, 14 ],
      "id_str" : "17670827",
      "id" : 17670827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683699795614134272",
  "text" : "RT @AlanBaxter: In my alerts often. If you do it, pls rate\/review at Amazon, GR, etc. At least you give the author something then. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlanBaxter\/status\/683637862101745664\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/kUuTHy4RFd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXzFAOWUAAAHcAN.jpg",
        "id_str" : "683637851095826432",
        "id" : 683637851095826432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXzFAOWUAAAHcAN.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kUuTHy4RFd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683637862101745664",
    "text" : "In my alerts often. If you do it, pls rate\/review at Amazon, GR, etc. At least you give the author something then. https:\/\/t.co\/kUuTHy4RFd",
    "id" : 683637862101745664,
    "created_at" : "2016-01-03 13:15:42 +0000",
    "user" : {
      "name" : "AlanBaxter",
      "screen_name" : "AlanBaxter",
      "protected" : false,
      "id_str" : "17670827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654921292529819648\/iC-MKZPv_normal.jpg",
      "id" : 17670827,
      "verified" : true
    }
  },
  "id" : 683699795614134272,
  "created_at" : "2016-01-03 17:21:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlanBaxter",
      "screen_name" : "AlanBaxter",
      "indices" : [ 3, 14 ],
      "id_str" : "17670827",
      "id" : 17670827
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AlanBaxter\/status\/683566387818725376\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/K0b8PhVE4M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXyD_rWUMAEaWji.jpg",
      "id_str" : "683566373444792321",
      "id" : 683566373444792321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXyD_rWUMAEaWji.jpg",
      "sizes" : [ {
        "h" : 672,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 749
      } ],
      "display_url" : "pic.twitter.com\/K0b8PhVE4M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683697890938728448",
  "text" : "RT @AlanBaxter: I don't know who wrote this, but fist-fucking-bump! https:\/\/t.co\/K0b8PhVE4M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlanBaxter\/status\/683566387818725376\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/K0b8PhVE4M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXyD_rWUMAEaWji.jpg",
        "id_str" : "683566373444792321",
        "id" : 683566373444792321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXyD_rWUMAEaWji.jpg",
        "sizes" : [ {
          "h" : 672,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 839,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 381,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 839,
          "resize" : "fit",
          "w" : 749
        } ],
        "display_url" : "pic.twitter.com\/K0b8PhVE4M"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683566387818725376",
    "text" : "I don't know who wrote this, but fist-fucking-bump! https:\/\/t.co\/K0b8PhVE4M",
    "id" : 683566387818725376,
    "created_at" : "2016-01-03 08:31:41 +0000",
    "user" : {
      "name" : "AlanBaxter",
      "screen_name" : "AlanBaxter",
      "protected" : false,
      "id_str" : "17670827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654921292529819648\/iC-MKZPv_normal.jpg",
      "id" : 17670827,
      "verified" : true
    }
  },
  "id" : 683697890938728448,
  "created_at" : "2016-01-03 17:14:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/myou.pub\/\" rel=\"nofollow\"\u003Emyou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/2yYzIOk1xp",
      "expanded_url" : "https:\/\/myou.pub\/moosebegab\/posts\/2996",
      "display_url" : "myou.pub\/moosebegab\/pos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "683692806368448512",
  "text" : "wonder if anyone's made comparison list (like a spreadsheet?) of the diff #audiobook memberships? (from https:\/\/t.co\/2yYzIOk1xp)",
  "id" : 683692806368448512,
  "created_at" : "2016-01-03 16:54:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belkiss Obadia",
      "screen_name" : "BelkissObadia",
      "indices" : [ 3, 17 ],
      "id_str" : "46085118",
      "id" : 46085118
    }, {
      "name" : "Chicago Tribune",
      "screen_name" : "chicagotribune",
      "indices" : [ 19, 34 ],
      "id_str" : "7313362",
      "id" : 7313362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683664367007698944",
  "text" : "RT @BelkissObadia: @chicagotribune If they were black or Muslim they'd be dead or behind bars. Double standard",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Tribune",
        "screen_name" : "chicagotribune",
        "indices" : [ 0, 15 ],
        "id_str" : "7313362",
        "id" : 7313362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "683653734501593088",
    "geo" : { },
    "id_str" : "683656873392926721",
    "in_reply_to_user_id" : 7313362,
    "text" : "@chicagotribune If they were black or Muslim they'd be dead or behind bars. Double standard",
    "id" : 683656873392926721,
    "in_reply_to_status_id" : 683653734501593088,
    "created_at" : "2016-01-03 14:31:15 +0000",
    "in_reply_to_screen_name" : "chicagotribune",
    "in_reply_to_user_id_str" : "7313362",
    "user" : {
      "name" : "Belkiss Obadia",
      "screen_name" : "BelkissObadia",
      "protected" : false,
      "id_str" : "46085118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797478541348716544\/x5hLN0DH_normal.jpg",
      "id" : 46085118,
      "verified" : false
    }
  },
  "id" : 683664367007698944,
  "created_at" : "2016-01-03 15:01:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/DIZrwN0zjY",
      "expanded_url" : "https:\/\/youtu.be\/9WQy4LGUQRg",
      "display_url" : "youtu.be\/9WQy4LGUQRg"
    } ]
  },
  "geo" : { },
  "id_str" : "683404967613435905",
  "text" : "Growing Up Quiverfull - The Duggar's Destructive Cult https:\/\/t.co\/DIZrwN0zjY",
  "id" : 683404967613435905,
  "created_at" : "2016-01-02 21:50:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683332042952683520",
  "text" : "also nice if there was some universal book tracker with formats.. and if in overdrive &gt; Library Extention for #audiobook",
  "id" : 683332042952683520,
  "created_at" : "2016-01-02 17:00:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eReaderIQ",
      "screen_name" : "eReaderIQ",
      "indices" : [ 53, 63 ],
      "id_str" : "153435359",
      "id" : 153435359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683330643275694080",
  "text" : "my audiobook wishlist?  audiobook price tracker like @eReaderIQ does for ebooks.",
  "id" : 683330643275694080,
  "created_at" : "2016-01-02 16:54:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683329883586560001",
  "text" : "ive become obsessed w audiobooks now.. browsing books \"that looks good, does it come in audio?\" annoyed when it doesnt..lol",
  "id" : 683329883586560001,
  "created_at" : "2016-01-02 16:51:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "indices" : [ 0, 16 ],
      "id_str" : "292671486",
      "id" : 292671486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "683087047993757696",
  "geo" : { },
  "id_str" : "683089084290609155",
  "in_reply_to_user_id" : 292671486,
  "text" : "@proudliberalmom innocent in the womb then BAM.. sinful after birth? then better to die in womb as innocent, no? im confused.",
  "id" : 683089084290609155,
  "in_reply_to_status_id" : 683087047993757696,
  "created_at" : "2016-01-02 00:55:03 +0000",
  "in_reply_to_screen_name" : "proudliberalmom",
  "in_reply_to_user_id_str" : "292671486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683043833555382273",
  "text" : "wth is wrong w DRs today? seem to know nothing these days. MIL losing memory.. just old age, do puzzles. Nope.. its not just age.",
  "id" : 683043833555382273,
  "created_at" : "2016-01-01 21:55:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren \uD83C\uDF83\uD83C\uDF41\uD83C\uDF42\uD83D\uDD78\uD83D\uDD77\uD83D\uDC7B",
      "screen_name" : "LaurenDeStefano",
      "indices" : [ 3, 19 ],
      "id_str" : "16144298",
      "id" : 16144298
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LaurenDeStefano\/status\/683038653543759872\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/egomBVNglj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXqkB3fWMAAUhQ1.jpg",
      "id_str" : "683038645482303488",
      "id" : 683038645482303488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXqkB3fWMAAUhQ1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/egomBVNglj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "683043033617678336",
  "text" : "RT @LaurenDeStefano: Start your new year with book feelings. RT by 1\/7 to enter to win a B&amp;N gift card! https:\/\/t.co\/egomBVNglj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaurenDeStefano\/status\/683038653543759872\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/egomBVNglj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXqkB3fWMAAUhQ1.jpg",
        "id_str" : "683038645482303488",
        "id" : 683038645482303488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXqkB3fWMAAUhQ1.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/egomBVNglj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "683038653543759872",
    "text" : "Start your new year with book feelings. RT by 1\/7 to enter to win a B&amp;N gift card! https:\/\/t.co\/egomBVNglj",
    "id" : 683038653543759872,
    "created_at" : "2016-01-01 21:34:39 +0000",
    "user" : {
      "name" : "Lauren \uD83C\uDF83\uD83C\uDF41\uD83C\uDF42\uD83D\uDD78\uD83D\uDD77\uD83D\uDC7B",
      "screen_name" : "LaurenDeStefano",
      "protected" : false,
      "id_str" : "16144298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768823537083813888\/OS1PMYSx_normal.jpg",
      "id" : 16144298,
      "verified" : true
    }
  },
  "id" : 683043033617678336,
  "created_at" : "2016-01-01 21:52:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Herdwick Shepherd",
      "screen_name" : "herdyshepherd1",
      "indices" : [ 3, 18 ],
      "id_str" : "467507215",
      "id" : 467507215
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/682890067959001088\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/RvthwA7tTP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXocW_fWYAAxXiK.jpg",
      "id_str" : "682889474825674752",
      "id" : 682889474825674752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXocW_fWYAAxXiK.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RvthwA7tTP"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/682890067959001088\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/RvthwA7tTP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXocW_xWYAYzMnB.jpg",
      "id_str" : "682889474901172230",
      "id" : 682889474901172230,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXocW_xWYAYzMnB.jpg",
      "sizes" : [ {
        "h" : 724,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/RvthwA7tTP"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/682890067959001088\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/RvthwA7tTP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXocW_xWcAEOB7l.jpg",
      "id_str" : "682889474901176321",
      "id" : 682889474901176321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXocW_xWcAEOB7l.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 782,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 782,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RvthwA7tTP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682975179463639040",
  "text" : "RT @herdyshepherd1: Cows are beautiful.\nYes. I did say that out loud.\nI grew up with cattle.\nLovely animals. https:\/\/t.co\/RvthwA7tTP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/682890067959001088\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/RvthwA7tTP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXocW_fWYAAxXiK.jpg",
        "id_str" : "682889474825674752",
        "id" : 682889474825674752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXocW_fWYAAxXiK.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RvthwA7tTP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/682890067959001088\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/RvthwA7tTP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXocW_xWYAYzMnB.jpg",
        "id_str" : "682889474901172230",
        "id" : 682889474901172230,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXocW_xWYAYzMnB.jpg",
        "sizes" : [ {
          "h" : 724,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/RvthwA7tTP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/herdyshepherd1\/status\/682890067959001088\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/RvthwA7tTP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXocW_xWcAEOB7l.jpg",
        "id_str" : "682889474901176321",
        "id" : 682889474901176321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXocW_xWcAEOB7l.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 782,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 782,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RvthwA7tTP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682890067959001088",
    "text" : "Cows are beautiful.\nYes. I did say that out loud.\nI grew up with cattle.\nLovely animals. https:\/\/t.co\/RvthwA7tTP",
    "id" : 682890067959001088,
    "created_at" : "2016-01-01 11:44:14 +0000",
    "user" : {
      "name" : "Herdwick Shepherd",
      "screen_name" : "herdyshepherd1",
      "protected" : false,
      "id_str" : "467507215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570254290402578432\/b9xZ4wR5_normal.jpeg",
      "id" : 467507215,
      "verified" : true
    }
  },
  "id" : 682975179463639040,
  "created_at" : "2016-01-01 17:22:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682952162226401280",
  "text" : "RT @ChickenJen: Happy New Year! Today only the eBooks 1 &amp; 3 in my Sovereign Series are FREE to download on Amazon. Here's Book 3 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/dA1ZgRpXhF",
        "expanded_url" : "http:\/\/www.amazon.com\/Songbird-Sovereign-Book-ebook\/dp\/B00LU3VIKM\/ref=tmm_kin_swatch_0?_encoding=UTF8&qid=&sr=",
        "display_url" : "amazon.com\/Songbird-Sover\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "682946945325883393",
    "text" : "Happy New Year! Today only the eBooks 1 &amp; 3 in my Sovereign Series are FREE to download on Amazon. Here's Book 3 https:\/\/t.co\/dA1ZgRpXhF",
    "id" : 682946945325883393,
    "created_at" : "2016-01-01 15:30:14 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 682952162226401280,
  "created_at" : "2016-01-01 15:50:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "682948498254266368",
  "geo" : { },
  "id_str" : "682951164053291008",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater oh my..lol. definitely a more coffee look!",
  "id" : 682951164053291008,
  "in_reply_to_status_id" : 682948498254266368,
  "created_at" : "2016-01-01 15:47:00 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natural Bushcraft",
      "screen_name" : "NaturlBushcraft",
      "indices" : [ 3, 19 ],
      "id_str" : "104295318",
      "id" : 104295318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682950801724170240",
  "text" : "RT @NaturlBushcraft: On this wet &amp; stormy day in Cornwall our Robin is taking shelter in my porch &amp; singing me a song in exchange https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NaturlBushcraft\/status\/682946840501862402\/video\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wOZwzKJkhX",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/682946634255351808\/pu\/img\/Jlxd7MwaKMmXvm5b.jpg",
        "id_str" : "682946634255351808",
        "id" : 682946634255351808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/682946634255351808\/pu\/img\/Jlxd7MwaKMmXvm5b.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wOZwzKJkhX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682946840501862402",
    "text" : "On this wet &amp; stormy day in Cornwall our Robin is taking shelter in my porch &amp; singing me a song in exchange https:\/\/t.co\/wOZwzKJkhX",
    "id" : 682946840501862402,
    "created_at" : "2016-01-01 15:29:49 +0000",
    "user" : {
      "name" : "Natural Bushcraft",
      "screen_name" : "NaturlBushcraft",
      "protected" : false,
      "id_str" : "104295318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611639942150811648\/WcbAkXt5_normal.jpg",
      "id" : 104295318,
      "verified" : false
    }
  },
  "id" : 682950801724170240,
  "created_at" : "2016-01-01 15:45:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682948431275520002",
  "text" : "RT @dwaynereaves: Good morning everyone! Happy New Year! Try making a resolution of not hating people this year and showing some love and k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "682878141396840448",
    "text" : "Good morning everyone! Happy New Year! Try making a resolution of not hating people this year and showing some love and kindness!",
    "id" : 682878141396840448,
    "created_at" : "2016-01-01 10:56:50 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 682948431275520002,
  "created_at" : "2016-01-01 15:36:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]