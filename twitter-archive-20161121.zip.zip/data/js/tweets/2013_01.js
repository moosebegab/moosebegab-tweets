Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 0, 16 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    }, {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 32, 42 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297081426279555072",
  "geo" : { },
  "id_str" : "297083995156516864",
  "in_reply_to_user_id" : 1137858745,
  "text" : "@JourneyTheHedgi you might like @CubeMelon for anime, manga, gaming.",
  "id" : 297083995156516864,
  "in_reply_to_status_id" : 297081426279555072,
  "created_at" : "2013-01-31 20:48:38 +0000",
  "in_reply_to_screen_name" : "JourneyTheHedgi",
  "in_reply_to_user_id_str" : "1137858745",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297053390259773441",
  "geo" : { },
  "id_str" : "297055516386025472",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia awesomesauce! : )",
  "id" : 297055516386025472,
  "in_reply_to_status_id" : 297053390259773441,
  "created_at" : "2013-01-31 18:55:28 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 65, 73 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297054296166498305",
  "geo" : { },
  "id_str" : "297054682260570112",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist i think blocking means he cant read your timeline? @twitter",
  "id" : 297054682260570112,
  "in_reply_to_status_id" : 297054296166498305,
  "created_at" : "2013-01-31 18:52:09 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 67, 80 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 81, 95 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Kardashev",
      "screen_name" : "Kardashev1",
      "indices" : [ 96, 107 ],
      "id_str" : "736451084",
      "id" : 736451084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297047392300179457",
  "geo" : { },
  "id_str" : "297049336439787520",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia i attack no one yet ppl dont like me cuz of that... @SisterSadist @BibleAlsoSays @Kardashev1",
  "id" : 297049336439787520,
  "in_reply_to_status_id" : 297047392300179457,
  "created_at" : "2013-01-31 18:30:55 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Michael Brooks",
      "screen_name" : "_michaelbrooks",
      "indices" : [ 70, 85 ],
      "id_str" : "249547283",
      "id" : 249547283
    }, {
      "name" : "Majority Report",
      "screen_name" : "majorityfm",
      "indices" : [ 86, 97 ],
      "id_str" : "208361818",
      "id" : 208361818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297038497729114112",
  "text" : "RT @CharlesBivona: The Health Insurance Industry should be destroyed. @_michaelbrooks @majorityfm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Brooks",
        "screen_name" : "_michaelbrooks",
        "indices" : [ 51, 66 ],
        "id_str" : "249547283",
        "id" : 249547283
      }, {
        "name" : "Majority Report",
        "screen_name" : "majorityfm",
        "indices" : [ 67, 78 ],
        "id_str" : "208361818",
        "id" : 208361818
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "297037581688926209",
    "geo" : { },
    "id_str" : "297037989660467200",
    "in_reply_to_user_id" : 249547283,
    "text" : "The Health Insurance Industry should be destroyed. @_michaelbrooks @majorityfm",
    "id" : 297037989660467200,
    "in_reply_to_status_id" : 297037581688926209,
    "created_at" : "2013-01-31 17:45:50 +0000",
    "in_reply_to_screen_name" : "_michaelbrooks",
    "in_reply_to_user_id_str" : "249547283",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 297038497729114112,
  "created_at" : "2013-01-31 17:47:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297038245475258368",
  "text" : "@ryanholt94 ((hugs))) : )",
  "id" : 297038245475258368,
  "created_at" : "2013-01-31 17:46:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 52, 65 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 66, 80 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Kardashev",
      "screen_name" : "Kardashev1",
      "indices" : [ 81, 92 ],
      "id_str" : "736451084",
      "id" : 736451084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297034792178954240",
  "geo" : { },
  "id_str" : "297037445730537473",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia i think you need a BIG (((hug))) : ) @SisterSadist @BibleAlsoSays @Kardashev1",
  "id" : 297037445730537473,
  "in_reply_to_status_id" : 297034792178954240,
  "created_at" : "2013-01-31 17:43:40 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297032747690639360",
  "text" : "RT @adamrshields: Anyone have a book they would like to review on Bookwi.se sometime in the next week or two?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297032510985101312",
    "text" : "Anyone have a book they would like to review on Bookwi.se sometime in the next week or two?",
    "id" : 297032510985101312,
    "created_at" : "2013-01-31 17:24:03 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 297032747690639360,
  "created_at" : "2013-01-31 17:25:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "297024145739378688",
  "geo" : { },
  "id_str" : "297030514857111552",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist ((hugs)) my mom got panic attacks occ. while driving somewhere unfamiliar. thought she wld be lost forever.",
  "id" : 297030514857111552,
  "in_reply_to_status_id" : 297024145739378688,
  "created_at" : "2013-01-31 17:16:07 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 69, 82 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 83, 97 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Kardashev",
      "screen_name" : "Kardashev1",
      "indices" : [ 98, 109 ],
      "id_str" : "736451084",
      "id" : 736451084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296883184824639488",
  "geo" : { },
  "id_str" : "297007535725084673",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia no wonder, you going after her so aggressively... : ( @SisterSadist @BibleAlsoSays @Kardashev1",
  "id" : 297007535725084673,
  "in_reply_to_status_id" : 296883184824639488,
  "created_at" : "2013-01-31 15:44:49 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 19, 32 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 33, 47 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Kardashev",
      "screen_name" : "Kardashev1",
      "indices" : [ 48, 59 ],
      "id_str" : "736451084",
      "id" : 736451084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296811534213054466",
  "geo" : { },
  "id_str" : "297003906423214080",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia : ( @SisterSadist @BibleAlsoSays @Kardashev1",
  "id" : 297003906423214080,
  "in_reply_to_status_id" : 296811534213054466,
  "created_at" : "2013-01-31 15:30:24 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296818269690679297",
  "geo" : { },
  "id_str" : "297003019923509249",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ((hugs))",
  "id" : 297003019923509249,
  "in_reply_to_status_id" : 296818269690679297,
  "created_at" : "2013-01-31 15:26:52 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296800868894928898",
  "text" : "RT @Squirrely007: Every singing program someone is compared to Adam Lambert and when I go to check them out I wonder what the hell peopl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296800036690489344",
    "text" : "Every singing program someone is compared to Adam Lambert and when I go to check them out I wonder what the hell people were smoking.",
    "id" : 296800036690489344,
    "created_at" : "2013-01-31 02:00:17 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 296800868894928898,
  "created_at" : "2013-01-31 02:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296791186251853824",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous hey... how ya been feeling lately?",
  "id" : 296791186251853824,
  "created_at" : "2013-01-31 01:25:07 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 35, 49 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Kardashev",
      "screen_name" : "Kardashev1",
      "indices" : [ 50, 61 ],
      "id_str" : "736451084",
      "id" : 736451084
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 62, 76 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296787252753874944",
  "geo" : { },
  "id_str" : "296790475661275136",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist I'm loving you, Cam! @BibleAlsoSays @Kardashev1 @deisidiamonia",
  "id" : 296790475661275136,
  "in_reply_to_status_id" : 296787252753874944,
  "created_at" : "2013-01-31 01:22:18 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Effie Mcintosh",
      "screen_name" : "AKbirder",
      "indices" : [ 22, 31 ],
      "id_str" : "4202024795",
      "id" : 4202024795
    }, {
      "name" : "Audubon Society",
      "screen_name" : "audubonsociety",
      "indices" : [ 49, 64 ],
      "id_str" : "19711765",
      "id" : 19711765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raven",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/7RGoU2OU",
      "expanded_url" : "http:\/\/ow.ly\/hcgZk",
      "display_url" : "ow.ly\/hcgZk"
    } ]
  },
  "geo" : { },
  "id_str" : "296765604185124864",
  "text" : "RT @KerriFar: WOW! RT @akbirder: Great photo! RT @audubonsociety:It's so cold this #raven can see its breath: http:\/\/t.co\/7RGoU2OU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Effie Mcintosh",
        "screen_name" : "AKbirder",
        "indices" : [ 8, 17 ],
        "id_str" : "4202024795",
        "id" : 4202024795
      }, {
        "name" : "Audubon Society",
        "screen_name" : "audubonsociety",
        "indices" : [ 35, 50 ],
        "id_str" : "19711765",
        "id" : 19711765
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raven",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/7RGoU2OU",
        "expanded_url" : "http:\/\/ow.ly\/hcgZk",
        "display_url" : "ow.ly\/hcgZk"
      } ]
    },
    "geo" : { },
    "id_str" : "296764780562223104",
    "text" : "WOW! RT @akbirder: Great photo! RT @audubonsociety:It's so cold this #raven can see its breath: http:\/\/t.co\/7RGoU2OU",
    "id" : 296764780562223104,
    "created_at" : "2013-01-30 23:40:11 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 296765604185124864,
  "created_at" : "2013-01-30 23:43:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Yankovic",
      "screen_name" : "alyankovic",
      "indices" : [ 3, 14 ],
      "id_str" : "22461427",
      "id" : 22461427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296709484179517441",
  "text" : "RT @alyankovic: Everybody put your hands in the air and wave them like you don\u2019t have a particularly strong opinion about anything.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296689079427420161",
    "text" : "Everybody put your hands in the air and wave them like you don\u2019t have a particularly strong opinion about anything.",
    "id" : 296689079427420161,
    "created_at" : "2013-01-30 18:39:23 +0000",
    "user" : {
      "name" : "Al Yankovic",
      "screen_name" : "alyankovic",
      "protected" : false,
      "id_str" : "22461427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/246073324\/IL2_normal.jpg",
      "id" : 22461427,
      "verified" : true
    }
  },
  "id" : 296709484179517441,
  "created_at" : "2013-01-30 20:00:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/iCa1tDy8",
      "expanded_url" : "http:\/\/oran.ge\/X7xNDX",
      "display_url" : "oran.ge\/X7xNDX"
    } ]
  },
  "geo" : { },
  "id_str" : "296686249396301824",
  "text" : "Woman crochets all 11 Dr Whos http:\/\/t.co\/iCa1tDy8",
  "id" : 296686249396301824,
  "created_at" : "2013-01-30 18:28:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296664144961220608",
  "text" : "RT @Jamiastar: So they want to just imprison anyone the decide is mentally ill? Sounds like a very slippery slope to me. Who decides?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296663698641125376",
    "text" : "So they want to just imprison anyone the decide is mentally ill? Sounds like a very slippery slope to me. Who decides?",
    "id" : 296663698641125376,
    "created_at" : "2013-01-30 16:58:32 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 296664144961220608,
  "created_at" : "2013-01-30 17:00:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296659161771560960",
  "geo" : { },
  "id_str" : "296660324587814912",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist i am INFP. i love social media cuz i can interact my way.",
  "id" : 296660324587814912,
  "in_reply_to_status_id" : 296659161771560960,
  "created_at" : "2013-01-30 16:45:07 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296655841048817664",
  "geo" : { },
  "id_str" : "296656431682297856",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes maybe cuz he's crazy? Lol",
  "id" : 296656431682297856,
  "in_reply_to_status_id" : 296655841048817664,
  "created_at" : "2013-01-30 16:29:39 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe Ort\u00EDz",
      "screen_name" : "TUSK81",
      "indices" : [ 3, 10 ],
      "id_str" : "14526877",
      "id" : 14526877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296655488878247936",
  "text" : "RT @TUSK81: Wayne LaPierre says gun ownership is a \"God-given\" right. I must have missed that passage in the Bible.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296652526428770304",
    "text" : "Wayne LaPierre says gun ownership is a \"God-given\" right. I must have missed that passage in the Bible.",
    "id" : 296652526428770304,
    "created_at" : "2013-01-30 16:14:08 +0000",
    "user" : {
      "name" : "Gabe Ort\u00EDz",
      "screen_name" : "TUSK81",
      "protected" : false,
      "id_str" : "14526877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725518568691888130\/_ClkDZ0d_normal.jpg",
      "id" : 14526877,
      "verified" : true
    }
  },
  "id" : 296655488878247936,
  "created_at" : "2013-01-30 16:25:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296641547053694976",
  "text" : "RT @PinarAkal1: Not to spoil the ending for you, but everything is gonna be okay ... ~Unknown",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296641088398168064",
    "text" : "Not to spoil the ending for you, but everything is gonna be okay ... ~Unknown",
    "id" : 296641088398168064,
    "created_at" : "2013-01-30 15:28:41 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 296641547053694976,
  "created_at" : "2013-01-30 15:30:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296640780641132544",
  "text" : ". @1stCitizenKane you cant run away from yourself",
  "id" : 296640780641132544,
  "created_at" : "2013-01-30 15:27:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/bkE65rVj",
      "expanded_url" : "http:\/\/huff.to\/129veHv",
      "display_url" : "huff.to\/129veHv"
    } ]
  },
  "geo" : { },
  "id_str" : "296638471961993216",
  "text" : "RT @HuffPostWeird: Nudity dealt a big blow in federal court http:\/\/t.co\/bkE65rVj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/bkE65rVj",
        "expanded_url" : "http:\/\/huff.to\/129veHv",
        "display_url" : "huff.to\/129veHv"
      } ]
    },
    "geo" : { },
    "id_str" : "296635154443689984",
    "text" : "Nudity dealt a big blow in federal court http:\/\/t.co\/bkE65rVj",
    "id" : 296635154443689984,
    "created_at" : "2013-01-30 15:05:06 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 296638471961993216,
  "created_at" : "2013-01-30 15:18:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296631047699963906",
  "text" : "@1stCitizenKane \"consciousness is at the heart of everything\" .. everything is consciousness. : )",
  "id" : 296631047699963906,
  "created_at" : "2013-01-30 14:48:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    }, {
      "name" : "Ging Freecs",
      "screen_name" : "sickdos",
      "indices" : [ 23, 31 ],
      "id_str" : "3880450877",
      "id" : 3880450877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296626557190033410",
  "text" : "@1stCitizenKane BIngo! @SickDos",
  "id" : 296626557190033410,
  "created_at" : "2013-01-30 14:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/lu3dS70E",
      "expanded_url" : "http:\/\/amzn.to\/Q9zsWD",
      "display_url" : "amzn.to\/Q9zsWD"
    } ]
  },
  "geo" : { },
  "id_str" : "296448508473524225",
  "text" : "finished One Angry Julius Katz and Other Stories (Julius Katz Detective) by Dave Zeltserman http:\/\/t.co\/lu3dS70E",
  "id" : 296448508473524225,
  "created_at" : "2013-01-30 02:43:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296420687596376064",
  "geo" : { },
  "id_str" : "296424921851101184",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth he's a cool dude : )",
  "id" : 296424921851101184,
  "in_reply_to_status_id" : 296420687596376064,
  "created_at" : "2013-01-30 01:09:43 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 47, 60 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 61, 75 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296411738448994306",
  "geo" : { },
  "id_str" : "296419506811703297",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia beautiful statement, Amalek : ) @SisterSadist @BibleAlsoSays",
  "id" : 296419506811703297,
  "in_reply_to_status_id" : 296411738448994306,
  "created_at" : "2013-01-30 00:48:12 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/EK8h6zo8",
      "expanded_url" : "http:\/\/www.naturalnews.com\/038874_baby_deer_police_state_jail_time.html",
      "display_url" : "naturalnews.com\/038874_baby_de\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296384595241340928",
  "text" : "RT @HealthRanger: Police state gone wild: Couple facing 60 days in jail for rescuing injured baby deer http:\/\/t.co\/EK8h6zo8 via @HealthR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthRanger",
        "screen_name" : "HealthRanger",
        "indices" : [ 110, 123 ],
        "id_str" : "15843059",
        "id" : 15843059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/EK8h6zo8",
        "expanded_url" : "http:\/\/www.naturalnews.com\/038874_baby_deer_police_state_jail_time.html",
        "display_url" : "naturalnews.com\/038874_baby_de\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "296379874355073024",
    "text" : "Police state gone wild: Couple facing 60 days in jail for rescuing injured baby deer http:\/\/t.co\/EK8h6zo8 via @HealthRanger",
    "id" : 296379874355073024,
    "created_at" : "2013-01-29 22:10:43 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 296384595241340928,
  "created_at" : "2013-01-29 22:29:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 0, 9 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296370898955554817",
  "geo" : { },
  "id_str" : "296379262661951488",
  "in_reply_to_user_id" : 38948326,
  "text" : "@Mortenrb well, I'll be watching to see it change back ; )",
  "id" : 296379262661951488,
  "in_reply_to_status_id" : 296370898955554817,
  "created_at" : "2013-01-29 22:08:17 +0000",
  "in_reply_to_screen_name" : "Mortenrb",
  "in_reply_to_user_id_str" : "38948326",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "indices" : [ 3, 11 ],
      "id_str" : "50815971",
      "id" : 50815971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296371974979063808",
  "text" : "RT @Palidan: \"It is one thing to feel that you are on the right path, but it is another to think yours is the only path.\" Paulo Coelho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296371553950629890",
    "text" : "\"It is one thing to feel that you are on the right path, but it is another to think yours is the only path.\" Paulo Coelho",
    "id" : 296371553950629890,
    "created_at" : "2013-01-29 21:37:39 +0000",
    "user" : {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "protected" : false,
      "id_str" : "50815971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747718513\/twitter_background_normal.jpg",
      "id" : 50815971,
      "verified" : false
    }
  },
  "id" : 296371974979063808,
  "created_at" : "2013-01-29 21:39:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296370264093102082",
  "text" : "@1stCitizenKane Nudity, FTW!",
  "id" : 296370264093102082,
  "created_at" : "2013-01-29 21:32:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296367755152744450",
  "geo" : { },
  "id_str" : "296369615116857346",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen lol. He's still adorable.",
  "id" : 296369615116857346,
  "in_reply_to_status_id" : 296367755152744450,
  "created_at" : "2013-01-29 21:29:57 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296369432656240641",
  "text" : "RT @LaughingBaba: The less you fight with life the happier you'll be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296367521114779648",
    "text" : "The less you fight with life the happier you'll be.",
    "id" : 296367521114779648,
    "created_at" : "2013-01-29 21:21:37 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 296369432656240641,
  "created_at" : "2013-01-29 21:29:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296369362166743040",
  "text" : "RT @worldtreeman: there is food for all.....plenty of it...its just not getting to where it should",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296366837770358784",
    "text" : "there is food for all.....plenty of it...its just not getting to where it should",
    "id" : 296366837770358784,
    "created_at" : "2013-01-29 21:18:55 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 296369362166743040,
  "created_at" : "2013-01-29 21:28:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 0, 9 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296366190928990208",
  "geo" : { },
  "id_str" : "296368792718696448",
  "in_reply_to_user_id" : 38948326,
  "text" : "@Mortenrb btw, saw your FB changed to single. Made me sad.",
  "id" : 296368792718696448,
  "in_reply_to_status_id" : 296366190928990208,
  "created_at" : "2013-01-29 21:26:41 +0000",
  "in_reply_to_screen_name" : "Mortenrb",
  "in_reply_to_user_id_str" : "38948326",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 0, 9 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296366190928990208",
  "geo" : { },
  "id_str" : "296368347803680770",
  "in_reply_to_user_id" : 38948326,
  "text" : "@Mortenrb hey there,you! : ) yeah, I knew that. I felt bk went overboard w banning. : (  I still want him to urban you guys. @ryanholt94",
  "id" : 296368347803680770,
  "in_reply_to_status_id" : 296366190928990208,
  "created_at" : "2013-01-29 21:24:55 +0000",
  "in_reply_to_screen_name" : "Mortenrb",
  "in_reply_to_user_id_str" : "38948326",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/1LWiUmiM",
      "expanded_url" : "http:\/\/bit.ly\/RhlFP6",
      "display_url" : "bit.ly\/RhlFP6"
    } ]
  },
  "geo" : { },
  "id_str" : "296367178184261632",
  "text" : "RT @abandontheherd: Great blog about nonconformity: http:\/\/t.co\/1LWiUmiM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/1LWiUmiM",
        "expanded_url" : "http:\/\/bit.ly\/RhlFP6",
        "display_url" : "bit.ly\/RhlFP6"
      } ]
    },
    "geo" : { },
    "id_str" : "296365139953864704",
    "text" : "Great blog about nonconformity: http:\/\/t.co\/1LWiUmiM",
    "id" : 296365139953864704,
    "created_at" : "2013-01-29 21:12:10 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 296367178184261632,
  "created_at" : "2013-01-29 21:20:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296326478898020353",
  "geo" : { },
  "id_str" : "296364190480883712",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen does he give kisses? I just want to smooch him! Lol",
  "id" : 296364190480883712,
  "in_reply_to_status_id" : 296326478898020353,
  "created_at" : "2013-01-29 21:08:23 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 19, 33 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 34, 48 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296362235356389377",
  "geo" : { },
  "id_str" : "296363357722783745",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist Yes! @BibleAlsoSays @deisidiamonia",
  "id" : 296363357722783745,
  "in_reply_to_status_id" : 296362235356389377,
  "created_at" : "2013-01-29 21:05:05 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/lnzazduW",
      "expanded_url" : "http:\/\/su.pr\/2HInca",
      "display_url" : "su.pr\/2HInca"
    } ]
  },
  "geo" : { },
  "id_str" : "296347827322380288",
  "text" : "RT @dailygalaxy: Oldest Known Alien Planets \u2014Born at Dawn of Universe 8-Billion Years Earlier than Earth http:\/\/t.co\/lnzazduW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.stumbleupon.com\/\" rel=\"nofollow\"\u003EStumbleUpon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/lnzazduW",
        "expanded_url" : "http:\/\/su.pr\/2HInca",
        "display_url" : "su.pr\/2HInca"
      } ]
    },
    "geo" : { },
    "id_str" : "296345648939298817",
    "text" : "Oldest Known Alien Planets \u2014Born at Dawn of Universe 8-Billion Years Earlier than Earth http:\/\/t.co\/lnzazduW",
    "id" : 296345648939298817,
    "created_at" : "2013-01-29 19:54:43 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 296347827322380288,
  "created_at" : "2013-01-29 20:03:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 47, 61 ],
      "id_str" : "280827427",
      "id" : 280827427
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 62, 76 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229938372972531715",
  "geo" : { },
  "id_str" : "296344158220738560",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist ((highfive)) Say it, Sister!! :D @deisidiamonia @BibleAlsoSays",
  "id" : 296344158220738560,
  "in_reply_to_status_id" : 229938372972531715,
  "created_at" : "2013-01-29 19:48:47 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296343106922631168",
  "text" : "@IronAtheist Oy! God is everything.. a rock, a tree, you and me! : )",
  "id" : 296343106922631168,
  "created_at" : "2013-01-29 19:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296330283576344576",
  "text" : "RT @ChickenJen: a face only a mother could love! (our 2 1\/2-year-old Scottish Highland bull Brandon) Note the frost on his back! http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/c77iGOc9",
        "expanded_url" : "http:\/\/twitpic.com\/bzblpx",
        "display_url" : "twitpic.com\/bzblpx"
      } ]
    },
    "geo" : { },
    "id_str" : "296326478898020353",
    "text" : "a face only a mother could love! (our 2 1\/2-year-old Scottish Highland bull Brandon) Note the frost on his back! http:\/\/t.co\/c77iGOc9",
    "id" : 296326478898020353,
    "created_at" : "2013-01-29 18:38:32 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 296330283576344576,
  "created_at" : "2013-01-29 18:53:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juliet Harrison",
      "screen_name" : "lecheval",
      "indices" : [ 3, 12 ],
      "id_str" : "17257283",
      "id" : 17257283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lostdog",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "dutchesscounty",
      "indices" : [ 102, 117 ]
    }, {
      "text" : "hudsonvalley",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/dM6zPE8m",
      "expanded_url" : "http:\/\/fb.me\/2GxFUs84r",
      "display_url" : "fb.me\/2GxFUs84r"
    } ]
  },
  "in_reply_to_status_id_str" : "296029786680197120",
  "geo" : { },
  "id_str" : "296032027256434689",
  "in_reply_to_user_id" : 17257283,
  "text" : "RT @lecheval Dog still missing in the Red Hook, NY area. Please repost. http:\/\/t.co\/dM6zPE8m #lostdog #dutchesscounty #hudsonvalley",
  "id" : 296032027256434689,
  "in_reply_to_status_id" : 296029786680197120,
  "created_at" : "2013-01-28 23:08:29 +0000",
  "in_reply_to_screen_name" : "lecheval",
  "in_reply_to_user_id_str" : "17257283",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/sArpTVmO",
      "expanded_url" : "http:\/\/sphotos-b.xx.fbcdn.net\/hphotos-ash3\/72943_501243543251543_209340690_n.png",
      "display_url" : "sphotos-b.xx.fbcdn.net\/hphotos-ash3\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295984612201619456",
  "text" : "LOLOL.. this is DD and me.. (she's the moose) http:\/\/t.co\/sArpTVmO",
  "id" : 295984612201619456,
  "created_at" : "2013-01-28 20:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heartcapricorn",
      "screen_name" : "HeartCapricorn",
      "indices" : [ 47, 62 ],
      "id_str" : "247463533",
      "id" : 247463533
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pisces",
      "indices" : [ 35, 42 ]
    }, {
      "text" : "Capricorn",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295962157848334336",
  "geo" : { },
  "id_str" : "295972132997955586",
  "in_reply_to_user_id" : 247463533,
  "text" : "im SOOO not a capricorn..lol (im a #pisces) RT @HeartCapricorn #Capricorn's are born workers and always need something productive to do.",
  "id" : 295972132997955586,
  "in_reply_to_status_id" : 295962157848334336,
  "created_at" : "2013-01-28 19:10:30 +0000",
  "in_reply_to_screen_name" : "HeartCapricorn",
  "in_reply_to_user_id_str" : "247463533",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295969811475886080",
  "text" : "RT @missalilove: I see the world with a different prospective than others, but I'm okay with that. \uD83D\uDE0A\uD83D\uDC97",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295958738995658752",
    "text" : "I see the world with a different prospective than others, but I'm okay with that. \uD83D\uDE0A\uD83D\uDC97",
    "id" : 295958738995658752,
    "created_at" : "2013-01-28 18:17:16 +0000",
    "user" : {
      "name" : "ali",
      "screen_name" : "Itsalilove",
      "protected" : false,
      "id_str" : "273739570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777180701770657792\/nj6Mw0uD_normal.jpg",
      "id" : 273739570,
      "verified" : false
    }
  },
  "id" : 295969811475886080,
  "created_at" : "2013-01-28 19:01:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 46, 59 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295952248519946240",
  "text" : "I just bought: 'Mystic Fool' by Andy Hill via @amazonkindle - curr. free",
  "id" : 295952248519946240,
  "created_at" : "2013-01-28 17:51:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295928971856592896",
  "geo" : { },
  "id_str" : "295950407828643841",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool it's comforting and disconcerting at same time.",
  "id" : 295950407828643841,
  "in_reply_to_status_id" : 295928971856592896,
  "created_at" : "2013-01-28 17:44:10 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295949115307749376",
  "text" : "@AnarchistKevin you changed name AGAIN .. lol .. keeping me on my toes! : )",
  "id" : 295949115307749376,
  "created_at" : "2013-01-28 17:39:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kobo",
      "screen_name" : "kobo",
      "indices" : [ 3, 8 ],
      "id_str" : "17348224",
      "id" : 17348224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/wSEL2mW4",
      "expanded_url" : "http:\/\/kobo.to\/XwmK6r",
      "display_url" : "kobo.to\/XwmK6r"
    } ]
  },
  "geo" : { },
  "id_str" : "295923299240771585",
  "text" : "RT @kobo: Give the booklover you love a Kobo Mini this Valentine's Day. You save $20 &amp; get a FREE SnapBack http:\/\/t.co\/wSEL2mW4 (Nor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.awarenessnetworks.com\/home\/\" rel=\"nofollow\"\u003ESocial Marketing Hub\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/wSEL2mW4",
        "expanded_url" : "http:\/\/kobo.to\/XwmK6r",
        "display_url" : "kobo.to\/XwmK6r"
      } ]
    },
    "geo" : { },
    "id_str" : "295921336025493506",
    "text" : "Give the booklover you love a Kobo Mini this Valentine's Day. You save $20 &amp; get a FREE SnapBack http:\/\/t.co\/wSEL2mW4 (North America Only)",
    "id" : 295921336025493506,
    "created_at" : "2013-01-28 15:48:39 +0000",
    "user" : {
      "name" : "Kobo",
      "screen_name" : "kobo",
      "protected" : false,
      "id_str" : "17348224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729704254613508096\/O-HKidTQ_normal.jpg",
      "id" : 17348224,
      "verified" : true
    }
  },
  "id" : 295923299240771585,
  "created_at" : "2013-01-28 15:56:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ram Dass",
      "screen_name" : "BabaRamDass",
      "indices" : [ 3, 15 ],
      "id_str" : "43464948",
      "id" : 43464948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295919698133016577",
  "text" : "RT @BabaRamDass: The spiritual journey is individual, highly personal. It can\u2019t be organized or regulated. It isn\u2019t true that everyone s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295903031843753985",
    "text" : "The spiritual journey is individual, highly personal. It can\u2019t be organized or regulated. It isn\u2019t true that everyone should follow one path",
    "id" : 295903031843753985,
    "created_at" : "2013-01-28 14:35:55 +0000",
    "user" : {
      "name" : "Ram Dass",
      "screen_name" : "BabaRamDass",
      "protected" : false,
      "id_str" : "43464948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476070086696894465\/Vg6Cn2QZ_normal.jpeg",
      "id" : 43464948,
      "verified" : false
    }
  },
  "id" : 295919698133016577,
  "created_at" : "2013-01-28 15:42:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/r5QbVglc",
      "expanded_url" : "http:\/\/bit.ly\/Ws3Lx4",
      "display_url" : "bit.ly\/Ws3Lx4"
    } ]
  },
  "geo" : { },
  "id_str" : "295911000182493186",
  "text" : "RT @screek: A Turkey Vulture Just Out For A Walk http:\/\/t.co\/r5QbVglc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/r5QbVglc",
        "expanded_url" : "http:\/\/bit.ly\/Ws3Lx4",
        "display_url" : "bit.ly\/Ws3Lx4"
      } ]
    },
    "geo" : { },
    "id_str" : "295909606771806208",
    "text" : "A Turkey Vulture Just Out For A Walk http:\/\/t.co\/r5QbVglc",
    "id" : 295909606771806208,
    "created_at" : "2013-01-28 15:02:02 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 295911000182493186,
  "created_at" : "2013-01-28 15:07:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 55, 68 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295910656585105408",
  "text" : "I just bought: 'The Day God Winked' by Mark Jacobs via @amazonkindle - curr free",
  "id" : 295910656585105408,
  "created_at" : "2013-01-28 15:06:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 108, 122 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/zrqI0hdD",
      "expanded_url" : "http:\/\/thkpr.gs\/WqjKeW",
      "display_url" : "thkpr.gs\/WqjKeW"
    } ]
  },
  "geo" : { },
  "id_str" : "295908015964569601",
  "text" : "Arizona Bill Requires Hospitals To Screen Immigration Status Of Uninsured Patients http:\/\/t.co\/zrqI0hdD via @thinkprogress",
  "id" : 295908015964569601,
  "created_at" : "2013-01-28 14:55:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 105, 119 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/ttPvd5UU",
      "expanded_url" : "http:\/\/thkpr.gs\/Wgvkct",
      "display_url" : "thkpr.gs\/Wgvkct"
    } ]
  },
  "geo" : { },
  "id_str" : "295907699898597376",
  "text" : "Mississippi Governor: \u2018There Is No One Who Doesn\u2019t Have Health Care In America\u2019 http:\/\/t.co\/ttPvd5UU via @thinkprogress",
  "id" : 295907699898597376,
  "created_at" : "2013-01-28 14:54:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    }, {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 13, 26 ],
      "id_str" : "51848023",
      "id" : 51848023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295894445444972544",
  "text" : "@IronAtheist @Bailey_san75 I think you meant \"which we both agree on\"",
  "id" : 295894445444972544,
  "created_at" : "2013-01-28 14:01:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nothingelsematters",
      "indices" : [ 79, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295704366982238208",
  "text" : "RT @KyleIsSalty: So close, no matter how far. Forever trust in who we are. And #nothingelsematters",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nothingelsematters",
        "indices" : [ 62, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295700397790724097",
    "text" : "So close, no matter how far. Forever trust in who we are. And #nothingelsematters",
    "id" : 295700397790724097,
    "created_at" : "2013-01-28 01:10:43 +0000",
    "user" : {
      "name" : "Unknown",
      "screen_name" : "ItsKasualKyleB",
      "protected" : false,
      "id_str" : "343244783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000251691961\/0167f2afb5b684094f2d88df90b15803_normal.jpeg",
      "id" : 343244783,
      "verified" : false
    }
  },
  "id" : 295704366982238208,
  "created_at" : "2013-01-28 01:26:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE LIGHTWERKERZ",
      "screen_name" : "tymajestic",
      "indices" : [ 3, 14 ],
      "id_str" : "182467615",
      "id" : 182467615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295698956992782336",
  "text" : "RT @tymajestic: so things that might sound crazy,doesnt make it crazy it could be next level",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295695237081350145",
    "text" : "so things that might sound crazy,doesnt make it crazy it could be next level",
    "id" : 295695237081350145,
    "created_at" : "2013-01-28 00:50:12 +0000",
    "user" : {
      "name" : "THE LIGHTWERKERZ",
      "screen_name" : "tymajestic",
      "protected" : false,
      "id_str" : "182467615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744163730276114432\/8ECTI6wz_normal.jpg",
      "id" : 182467615,
      "verified" : false
    }
  },
  "id" : 295698956992782336,
  "created_at" : "2013-01-28 01:04:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE LIGHTWERKERZ",
      "screen_name" : "tymajestic",
      "indices" : [ 3, 14 ],
      "id_str" : "182467615",
      "id" : 182467615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295698927850766336",
  "text" : "RT @tymajestic: SO WHEN WE ARE IN THE 1940s,AND TALKING ABOUT A IPHONE, THE PEOPLE WOULD CALL YOU NUTS RIGHT  think about it,so i sound  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295694808918421504",
    "text" : "SO WHEN WE ARE IN THE 1940s,AND TALKING ABOUT A IPHONE, THE PEOPLE WOULD CALL YOU NUTS RIGHT  think about it,so i sound nuts to u",
    "id" : 295694808918421504,
    "created_at" : "2013-01-28 00:48:30 +0000",
    "user" : {
      "name" : "THE LIGHTWERKERZ",
      "screen_name" : "tymajestic",
      "protected" : false,
      "id_str" : "182467615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744163730276114432\/8ECTI6wz_normal.jpg",
      "id" : 182467615,
      "verified" : false
    }
  },
  "id" : 295698927850766336,
  "created_at" : "2013-01-28 01:04:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Emrys",
      "screen_name" : "merlinemrys66",
      "indices" : [ 0, 14 ],
      "id_str" : "937393992",
      "id" : 937393992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295665109295050752",
  "geo" : { },
  "id_str" : "295670368696410115",
  "in_reply_to_user_id" : 937393992,
  "text" : "@merlinemrys66 : (((",
  "id" : 295670368696410115,
  "in_reply_to_status_id" : 295665109295050752,
  "created_at" : "2013-01-27 23:11:23 +0000",
  "in_reply_to_screen_name" : "merlinemrys66",
  "in_reply_to_user_id_str" : "937393992",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ycuwxb17",
      "expanded_url" : "http:\/\/amzn.to\/RaA4Oy",
      "display_url" : "amzn.to\/RaA4Oy"
    } ]
  },
  "geo" : { },
  "id_str" : "295665593846231040",
  "text" : "finished Feels Like the First Time: A True Love Story by Shawn Inmon http:\/\/t.co\/ycuwxb17",
  "id" : 295665593846231040,
  "created_at" : "2013-01-27 22:52:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295660308926713856",
  "text" : "RT @UnseeingEyes: Today everyone wants the \"black &amp; white\"...the \"right &amp; wrong\"...the you dumb-ass, I'm smart...more laws &amp; ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295656387478970368",
    "text" : "Today everyone wants the \"black &amp; white\"...the \"right &amp; wrong\"...the you dumb-ass, I'm smart...more laws &amp; false equality...",
    "id" : 295656387478970368,
    "created_at" : "2013-01-27 22:15:50 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 295660308926713856,
  "created_at" : "2013-01-27 22:31:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Tracy Harms",
      "screen_name" : "kaleidic",
      "indices" : [ 60, 69 ],
      "id_str" : "16911769",
      "id" : 16911769
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/angelaharms\/status\/295654850144894976\/photo\/1",
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/5J9GgCXo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBpghQ-CAAAJ6t3.jpg",
      "id_str" : "295654850153283584",
      "id" : 295654850153283584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBpghQ-CAAAJ6t3.jpg",
      "sizes" : [ {
        "h" : 1064,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1816,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1840
      } ],
      "display_url" : "pic.twitter.com\/5J9GgCXo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295659920395739136",
  "text" : "RT @angelaharms: Fat Ladies in Space is delightful! Thanks, @kaleidic :-)  &lt;3 &lt;3 &lt;3 http:\/\/t.co\/5J9GgCXo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tracy Harms",
        "screen_name" : "kaleidic",
        "indices" : [ 43, 52 ],
        "id_str" : "16911769",
        "id" : 16911769
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/angelaharms\/status\/295654850144894976\/photo\/1",
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/5J9GgCXo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBpghQ-CAAAJ6t3.jpg",
        "id_str" : "295654850153283584",
        "id" : 295654850153283584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBpghQ-CAAAJ6t3.jpg",
        "sizes" : [ {
          "h" : 1064,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1816,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 1840
        } ],
        "display_url" : "pic.twitter.com\/5J9GgCXo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295654850144894976",
    "text" : "Fat Ladies in Space is delightful! Thanks, @kaleidic :-)  &lt;3 &lt;3 &lt;3 http:\/\/t.co\/5J9GgCXo",
    "id" : 295654850144894976,
    "created_at" : "2013-01-27 22:09:45 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 295659920395739136,
  "created_at" : "2013-01-27 22:29:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Tracy Harms",
      "screen_name" : "kaleidic",
      "indices" : [ 23, 32 ],
      "id_str" : "16911769",
      "id" : 16911769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295654850144894976",
  "geo" : { },
  "id_str" : "295659865928511488",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms how cool! @kaleidic",
  "id" : 295659865928511488,
  "in_reply_to_status_id" : 295654850144894976,
  "created_at" : "2013-01-27 22:29:39 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    }, {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 13, 26 ],
      "id_str" : "51848023",
      "id" : 51848023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295659108298805249",
  "text" : "@IronAtheist @Bailey_san75 and you are quite right.. religion should not be in govt.",
  "id" : 295659108298805249,
  "created_at" : "2013-01-27 22:26:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    }, {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 13, 26 ],
      "id_str" : "51848023",
      "id" : 51848023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295658826122817537",
  "text" : "@IronAtheist @Bailey_san75 LOL.. Bailey mentioned govt in tweet and I replied w funny. I'm almost anarchist.",
  "id" : 295658826122817537,
  "created_at" : "2013-01-27 22:25:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/QajqaKYI",
      "expanded_url" : "http:\/\/www.tyrusbooks.com\/review-copies-and-street-team",
      "display_url" : "tyrusbooks.com\/review-copies-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "295639530462134273",
  "geo" : { },
  "id_str" : "295642993833160706",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles also http:\/\/t.co\/QajqaKYI",
  "id" : 295642993833160706,
  "in_reply_to_status_id" : 295639530462134273,
  "created_at" : "2013-01-27 21:22:37 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295633001885351936",
  "geo" : { },
  "id_str" : "295640614475812864",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles kindle broke? Or you just had a paper book you wanted to read?",
  "id" : 295640614475812864,
  "in_reply_to_status_id" : 295633001885351936,
  "created_at" : "2013-01-27 21:13:09 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    }, {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 13, 26 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294934911826141184",
  "geo" : { },
  "id_str" : "295638921361125376",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles @bookwiseblog offers guest reviews",
  "id" : 295638921361125376,
  "in_reply_to_status_id" : 294934911826141184,
  "created_at" : "2013-01-27 21:06:26 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295624236033273856",
  "text" : "RT @MWM4444: I wish to God Paul Ryan could be forced to live on the minimum wage for one month, so he can learn how much fun \"opportunit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 130, 133 ]
      }, {
        "text" : "tcot",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295621669081477120",
    "text" : "I wish to God Paul Ryan could be forced to live on the minimum wage for one month, so he can learn how much fun \"opportunity\" is. #p2 #tcot",
    "id" : 295621669081477120,
    "created_at" : "2013-01-27 19:57:52 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 295624236033273856,
  "created_at" : "2013-01-27 20:08:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 0, 6 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295607653453946880",
  "geo" : { },
  "id_str" : "295609015898079233",
  "in_reply_to_user_id" : 33033233,
  "text" : "@oshum haha.. so true! : )",
  "id" : 295609015898079233,
  "in_reply_to_status_id" : 295607653453946880,
  "created_at" : "2013-01-27 19:07:36 +0000",
  "in_reply_to_screen_name" : "Oshum",
  "in_reply_to_user_id_str" : "33033233",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Kathan",
      "screen_name" : "StephanieKathan",
      "indices" : [ 3, 19 ],
      "id_str" : "42990074",
      "id" : 42990074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295593975589527555",
  "text" : "RT @StephanieKathan: When someone points out all the tragedy in the world, and demands that I look at the horror of what they call... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/IE5tq6nK",
        "expanded_url" : "http:\/\/fb.me\/21BW4TnxY",
        "display_url" : "fb.me\/21BW4TnxY"
      } ]
    },
    "geo" : { },
    "id_str" : "295593095230267393",
    "text" : "When someone points out all the tragedy in the world, and demands that I look at the horror of what they call... http:\/\/t.co\/IE5tq6nK",
    "id" : 295593095230267393,
    "created_at" : "2013-01-27 18:04:20 +0000",
    "user" : {
      "name" : "Stephanie Kathan",
      "screen_name" : "StephanieKathan",
      "protected" : false,
      "id_str" : "42990074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779137503206998016\/P3KDquOf_normal.jpg",
      "id" : 42990074,
      "verified" : false
    }
  },
  "id" : 295593975589527555,
  "created_at" : "2013-01-27 18:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295588162837807104",
  "geo" : { },
  "id_str" : "295593192114499584",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles my hands so dry, I globbed Vaseline on them, covered in socks. Then wanted to read in bed... lol",
  "id" : 295593192114499584,
  "in_reply_to_status_id" : 295588162837807104,
  "created_at" : "2013-01-27 18:04:43 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295584302069084160",
  "geo" : { },
  "id_str" : "295585434497589249",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles swipe or tap. It's all touch. No buttons except for on\/off.",
  "id" : 295585434497589249,
  "in_reply_to_status_id" : 295584302069084160,
  "created_at" : "2013-01-27 17:33:53 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295584301955833856",
  "text" : "RT @BirdPicture: I'm really enjoying the two Eastern Bluebirds that have taken up residence in my backyard. Gorgeous birds. http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.snsanalytics.com\" rel=\"nofollow\"\u003ESNS Analytics\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/imYM38cP",
        "expanded_url" : "http:\/\/sns.mx\/lfhoy7",
        "display_url" : "sns.mx\/lfhoy7"
      } ]
    },
    "geo" : { },
    "id_str" : "295579640423145472",
    "text" : "I'm really enjoying the two Eastern Bluebirds that have taken up residence in my backyard. Gorgeous birds. http:\/\/t.co\/imYM38cP",
    "id" : 295579640423145472,
    "created_at" : "2013-01-27 17:10:52 +0000",
    "user" : {
      "name" : "Alvin Dupree News",
      "screen_name" : "AlvinDupreeNews",
      "protected" : false,
      "id_str" : "120532098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/592853525912231937\/Ipjti-Jw_normal.jpg",
      "id" : 120532098,
      "verified" : false
    }
  },
  "id" : 295584301955833856,
  "created_at" : "2013-01-27 17:29:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "paperwhite",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "kindlekeyboard",
      "indices" : [ 108, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295583930856378368",
  "text" : "Discovered last night #kindle #paperwhite does not work when wearing socks on your hands. Good thing I have #kindlekeyboard",
  "id" : 295583930856378368,
  "created_at" : "2013-01-27 17:27:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jourdyn",
      "screen_name" : "Jourdynalexis",
      "indices" : [ 3, 17 ],
      "id_str" : "32134612",
      "id" : 32134612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295572458377990144",
  "text" : "RT @Jourdynalexis: \u028D\u01DD\u0131\u028C \u025Fo \u0287u\u0131od \u0287u\u01DD\u0279\u01DD\u025F\u025F\u0131p \u0250 \u026Fo\u0279\u025F \u01DD\u025F\u0131\u05DF \u0287\u0250 \u029Eoo\u05DF o\u0287 p\u01DD\u01DDu n s\u01DD\u026F\u0131\u0287\u01DD\u026Fos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294498678754902017",
    "text" : "\u028D\u01DD\u0131\u028C \u025Fo \u0287u\u0131od \u0287u\u01DD\u0279\u01DD\u025F\u025F\u0131p \u0250 \u026Fo\u0279\u025F \u01DD\u025F\u0131\u05DF \u0287\u0250 \u029Eoo\u05DF o\u0287 p\u01DD\u01DDu n s\u01DD\u026F\u0131\u0287\u01DD\u026Fos",
    "id" : 294498678754902017,
    "created_at" : "2013-01-24 17:35:31 +0000",
    "user" : {
      "name" : "Jourdyn",
      "screen_name" : "Jourdynalexis",
      "protected" : false,
      "id_str" : "32134612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755717908525944832\/a_G1K7sd_normal.jpg",
      "id" : 32134612,
      "verified" : false
    }
  },
  "id" : 295572458377990144,
  "created_at" : "2013-01-27 16:42:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295566312644702208",
  "geo" : { },
  "id_str" : "295571659916705792",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver cool beans.. accurate!",
  "id" : 295571659916705792,
  "in_reply_to_status_id" : 295566312644702208,
  "created_at" : "2013-01-27 16:39:09 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    }, {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 13, 26 ],
      "id_str" : "51848023",
      "id" : 51848023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295568662243459072",
  "text" : "@IronAtheist @Bailey_san75 govt is not looking out for our best interests. it pretends to do so while keeping things good for powerful.",
  "id" : 295568662243459072,
  "created_at" : "2013-01-27 16:27:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Daniel Komarek",
      "screen_name" : "DanielKomarek",
      "indices" : [ 24, 38 ],
      "id_str" : "76472749",
      "id" : 76472749
    }, {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 43, 57 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alaska",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 119, 128 ]
    }, {
      "text" : "nature",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/ACG6KcDc",
      "expanded_url" : "http:\/\/alaskanaturephotography.zenfolio.com\/p887581789\/e520ffb1a",
      "display_url" : "alaskanaturephotography.zenfolio.com\/p887581789\/e52\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295351674665566208",
  "text" : "RT @KerriFar: Sweet! RT @danielkomarek: RT @Alaskachic907: Four week old twin baby moose. http:\/\/t.co\/ACG6KcDc #alaska #wildlife #nature ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Komarek",
        "screen_name" : "DanielKomarek",
        "indices" : [ 10, 24 ],
        "id_str" : "76472749",
        "id" : 76472749
      }, {
        "name" : "Nancy Stewart",
        "screen_name" : "Alaskachic907",
        "indices" : [ 29, 43 ],
        "id_str" : "80073299",
        "id" : 80073299
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "alaska",
        "indices" : [ 97, 104 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 105, 114 ]
      }, {
        "text" : "nature",
        "indices" : [ 115, 122 ]
      }, {
        "text" : "photography",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/ACG6KcDc",
        "expanded_url" : "http:\/\/alaskanaturephotography.zenfolio.com\/p887581789\/e520ffb1a",
        "display_url" : "alaskanaturephotography.zenfolio.com\/p887581789\/e52\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "295277478438641664",
    "text" : "Sweet! RT @danielkomarek: RT @Alaskachic907: Four week old twin baby moose. http:\/\/t.co\/ACG6KcDc #alaska #wildlife #nature #photography",
    "id" : 295277478438641664,
    "created_at" : "2013-01-26 21:10:11 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 295351674665566208,
  "created_at" : "2013-01-27 02:05:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295235454037532674",
  "text" : "RT @Buddhaworld: Everything is as it is because it has to be so. If not it would be different. Volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 48.1352036, 11.5699823 ]
    },
    "id_str" : "295235082141200384",
    "text" : "Everything is as it is because it has to be so. If not it would be different. Volko",
    "id" : 295235082141200384,
    "created_at" : "2013-01-26 18:21:43 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 295235454037532674,
  "created_at" : "2013-01-26 18:23:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295230162658803713",
  "geo" : { },
  "id_str" : "295235085182046209",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields : )",
  "id" : 295235085182046209,
  "in_reply_to_status_id" : 295230162658803713,
  "created_at" : "2013-01-26 18:21:44 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Florida Native Plant",
      "screen_name" : "PineLilyFNPS",
      "indices" : [ 77, 90 ],
      "id_str" : "23206653",
      "id" : 23206653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 91, 96 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "Central_Florida",
      "indices" : [ 107, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/cUDWaCDE",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/15291",
      "display_url" : "wildobs.com\/wo\/15291"
    } ]
  },
  "geo" : { },
  "id_str" : "295234525049528320",
  "text" : "RT @wildobs: In case you missed it: Eastern Bluebird http:\/\/t.co\/cUDWaCDE by @PineLilyFNPS #EOTD #wildlife #Central_Florida",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Florida Native Plant",
        "screen_name" : "PineLilyFNPS",
        "indices" : [ 64, 77 ],
        "id_str" : "23206653",
        "id" : 23206653
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 78, 83 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "Central_Florida",
        "indices" : [ 94, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/cUDWaCDE",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/15291",
        "display_url" : "wildobs.com\/wo\/15291"
      } ]
    },
    "geo" : { },
    "id_str" : "295231059430367232",
    "text" : "In case you missed it: Eastern Bluebird http:\/\/t.co\/cUDWaCDE by @PineLilyFNPS #EOTD #wildlife #Central_Florida",
    "id" : 295231059430367232,
    "created_at" : "2013-01-26 18:05:44 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 295234525049528320,
  "created_at" : "2013-01-26 18:19:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Richard D. Wolff",
      "screen_name" : "profwolff",
      "indices" : [ 103, 113 ],
      "id_str" : "78768913",
      "id" : 78768913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EconomicUpdate",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295230067242590208",
  "text" : "RT @CharlesBivona: \"We have an educational system that trains people to accept being told what to do.\" @profwolff: #EconomicUpdate - htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard D. Wolff",
        "screen_name" : "profwolff",
        "indices" : [ 84, 94 ],
        "id_str" : "78768913",
        "id" : 78768913
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EconomicUpdate",
        "indices" : [ 96, 111 ]
      }, {
        "text" : "ows",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/8WUTNeQa",
        "expanded_url" : "http:\/\/stream.wbai.org",
        "display_url" : "stream.wbai.org"
      } ]
    },
    "geo" : { },
    "id_str" : "295227536852541441",
    "text" : "\"We have an educational system that trains people to accept being told what to do.\" @profwolff: #EconomicUpdate - http:\/\/t.co\/8WUTNeQa #ows",
    "id" : 295227536852541441,
    "created_at" : "2013-01-26 17:51:44 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 295230067242590208,
  "created_at" : "2013-01-26 18:01:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295222708151676929",
  "text" : "im a liberal, tree-hugger. apparently, that's a bad thing...",
  "id" : 295222708151676929,
  "created_at" : "2013-01-26 17:32:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295213657342742528",
  "text" : "@Llimoner_ cool.. added to my list. thanks.",
  "id" : 295213657342742528,
  "created_at" : "2013-01-26 16:56:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "indices" : [ 3, 12 ],
      "id_str" : "394134197",
      "id" : 394134197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/dmqxVfMQ",
      "expanded_url" : "http:\/\/ow.ly\/h87cK",
      "display_url" : "ow.ly\/h87cK"
    } ]
  },
  "geo" : { },
  "id_str" : "295208973446021120",
  "text" : "RT @mfpenney: Why Serving In Combat Does Not Serve Women (Or Anyone Else) Well - http:\/\/t.co\/dmqxVfMQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/dmqxVfMQ",
        "expanded_url" : "http:\/\/ow.ly\/h87cK",
        "display_url" : "ow.ly\/h87cK"
      } ]
    },
    "geo" : { },
    "id_str" : "295208299824041984",
    "text" : "Why Serving In Combat Does Not Serve Women (Or Anyone Else) Well - http:\/\/t.co\/dmqxVfMQ",
    "id" : 295208299824041984,
    "created_at" : "2013-01-26 16:35:18 +0000",
    "user" : {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "protected" : false,
      "id_str" : "394134197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596470057\/DSCN0545_normal.jpg",
      "id" : 394134197,
      "verified" : false
    }
  },
  "id" : 295208973446021120,
  "created_at" : "2013-01-26 16:37:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Tolstoy",
      "screen_name" : "TolstoySays",
      "indices" : [ 3, 15 ],
      "id_str" : "382991619",
      "id" : 382991619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295207617045856256",
  "text" : "RT @TolstoySays: The main task of life is love. It is impossible to love in the past or the future. Love is only possible in the present ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295206065690255361",
    "text" : "The main task of life is love. It is impossible to love in the past or the future. Love is only possible in the present, now, this minute.",
    "id" : 295206065690255361,
    "created_at" : "2013-01-26 16:26:25 +0000",
    "user" : {
      "name" : "Leo Tolstoy",
      "screen_name" : "TolstoySays",
      "protected" : false,
      "id_str" : "382991619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1567369613\/uewb_10_img0685_normal.jpg",
      "id" : 382991619,
      "verified" : false
    }
  },
  "id" : 295207617045856256,
  "created_at" : "2013-01-26 16:32:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 0, 13 ],
      "id_str" : "51848023",
      "id" : 51848023
    }, {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 14, 26 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295003355556745216",
  "geo" : { },
  "id_str" : "295195386052751360",
  "in_reply_to_user_id" : 51848023,
  "text" : "@Bailey_san75 @IronAtheist \"govt? dont talk to me about govt\" (in my best marvin voice) LOL",
  "id" : 295195386052751360,
  "in_reply_to_status_id" : 295003355556745216,
  "created_at" : "2013-01-26 15:43:59 +0000",
  "in_reply_to_screen_name" : "Bailey_san75",
  "in_reply_to_user_id_str" : "51848023",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/MFsneosD",
      "expanded_url" : "http:\/\/amzn.to\/ULYz3E",
      "display_url" : "amzn.to\/ULYz3E"
    } ]
  },
  "geo" : { },
  "id_str" : "295019366733471744",
  "text" : "finished God's Grammar: A Novel by Mick Mooney http:\/\/t.co\/MFsneosD",
  "id" : 295019366733471744,
  "created_at" : "2013-01-26 04:04:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "indices" : [ 3, 15 ],
      "id_str" : "19791234",
      "id" : 19791234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/K3jv7Aob",
      "expanded_url" : "http:\/\/owl.li\/h4X7T",
      "display_url" : "owl.li\/h4X7T"
    } ]
  },
  "geo" : { },
  "id_str" : "295006414194212864",
  "text" : "RT @Emperor_Bob: CHART: US government spends more on health care than the Canadian government. http:\/\/t.co\/K3jv7Aob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/K3jv7Aob",
        "expanded_url" : "http:\/\/owl.li\/h4X7T",
        "display_url" : "owl.li\/h4X7T"
      } ]
    },
    "geo" : { },
    "id_str" : "295005710037680131",
    "text" : "CHART: US government spends more on health care than the Canadian government. http:\/\/t.co\/K3jv7Aob",
    "id" : 295005710037680131,
    "created_at" : "2013-01-26 03:10:16 +0000",
    "user" : {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "protected" : false,
      "id_str" : "19791234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3352084632\/6ebf06ce559f48c77c691cb928fc62ab_normal.png",
      "id" : 19791234,
      "verified" : false
    }
  },
  "id" : 295006414194212864,
  "created_at" : "2013-01-26 03:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Bird Photographer",
      "screen_name" : "birdphotoman",
      "indices" : [ 17, 30 ],
      "id_str" : "74139677",
      "id" : 74139677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295006090683351040",
  "text" : "RT @KerriFar: RT @birdphotoman: Bluebird and Wisteria........found this old image hidden in one of my many file folders. http:\/\/t.co\/mk1 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bird Photographer",
        "screen_name" : "birdphotoman",
        "indices" : [ 3, 16 ],
        "id_str" : "74139677",
        "id" : 74139677
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/birdphotoman\/status\/293461707806883841\/photo\/1",
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/mk16HFjW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBKV3lGCQAARl8y.jpg",
        "id_str" : "293461707815272448",
        "id" : 293461707815272448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBKV3lGCQAARl8y.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 504
        } ],
        "display_url" : "pic.twitter.com\/mk16HFjW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295005700088815618",
    "text" : "RT @birdphotoman: Bluebird and Wisteria........found this old image hidden in one of my many file folders. http:\/\/t.co\/mk16HFjW",
    "id" : 295005700088815618,
    "created_at" : "2013-01-26 03:10:14 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 295006090683351040,
  "created_at" : "2013-01-26 03:11:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295002548056768512",
  "geo" : { },
  "id_str" : "295003635845324800",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist awww! Lol",
  "id" : 295003635845324800,
  "in_reply_to_status_id" : 295002548056768512,
  "created_at" : "2013-01-26 03:02:02 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294998599056642050",
  "geo" : { },
  "id_str" : "294999205175517184",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 oh yeah.. forgot about that",
  "id" : 294999205175517184,
  "in_reply_to_status_id" : 294998599056642050,
  "created_at" : "2013-01-26 02:44:25 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294995008568827905",
  "geo" : { },
  "id_str" : "294998267568222208",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 thing is.. too many states have gone wacky. There's nowhere to go anymore.",
  "id" : 294998267568222208,
  "in_reply_to_status_id" : 294995008568827905,
  "created_at" : "2013-01-26 02:40:42 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294997038058319874",
  "text" : "@IronAtheist I have no proof. My only beef w you is you insisting I see the world your way, that's all.",
  "id" : 294997038058319874,
  "created_at" : "2013-01-26 02:35:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294994564266196992",
  "text" : "@IronAtheist I absolutely believe in separation of church and state",
  "id" : 294994564266196992,
  "created_at" : "2013-01-26 02:25:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294993526268256257",
  "text" : "@IronAtheist \"my religion is kindness\" - Dalai lama",
  "id" : 294993526268256257,
  "created_at" : "2013-01-26 02:21:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/8xsTf63Q",
      "expanded_url" : "http:\/\/amzn.to\/XGmKRd",
      "display_url" : "amzn.to\/XGmKRd"
    } ]
  },
  "geo" : { },
  "id_str" : "294992170249756672",
  "text" : "finished Thirst by L.A.  Larkin http:\/\/t.co\/8xsTf63Q",
  "id" : 294992170249756672,
  "created_at" : "2013-01-26 02:16:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294961388319817728",
  "text" : "RT @Master_Synaps: When we learn to see others as being of equal value as ourselves, we behave accordingly. This is the secret to peace. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compassion",
        "indices" : [ 118, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294958433206145024",
    "text" : "When we learn to see others as being of equal value as ourselves, we behave accordingly. This is the secret to peace. #compassion",
    "id" : 294958433206145024,
    "created_at" : "2013-01-26 00:02:25 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 294961388319817728,
  "created_at" : "2013-01-26 00:14:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 0, 13 ],
      "id_str" : "51848023",
      "id" : 51848023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294926629665382400",
  "geo" : { },
  "id_str" : "294935984401960960",
  "in_reply_to_user_id" : 51848023,
  "text" : "@Bailey_san75 then I guess I'm religious...",
  "id" : 294935984401960960,
  "in_reply_to_status_id" : 294926629665382400,
  "created_at" : "2013-01-25 22:33:12 +0000",
  "in_reply_to_screen_name" : "Bailey_san75",
  "in_reply_to_user_id_str" : "51848023",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 0, 13 ],
      "id_str" : "51848023",
      "id" : 51848023
    }, {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 84, 96 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294915922806857728",
  "geo" : { },
  "id_str" : "294925918235930625",
  "in_reply_to_user_id" : 51848023,
  "text" : "@Bailey_san75 when I see religious, I think prescribing to a particular religion... @IronAtheist",
  "id" : 294925918235930625,
  "in_reply_to_status_id" : 294915922806857728,
  "created_at" : "2013-01-25 21:53:13 +0000",
  "in_reply_to_screen_name" : "Bailey_san75",
  "in_reply_to_user_id_str" : "51848023",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/6vxYwd0T",
      "expanded_url" : "http:\/\/on.mash.to\/10TM3WO",
      "display_url" : "on.mash.to\/10TM3WO"
    } ]
  },
  "geo" : { },
  "id_str" : "294923158262255616",
  "text" : "RT @mashable: Cory Booker Saves Freezing Dog http:\/\/t.co\/6vxYwd0T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/6vxYwd0T",
        "expanded_url" : "http:\/\/on.mash.to\/10TM3WO",
        "display_url" : "on.mash.to\/10TM3WO"
      } ]
    },
    "geo" : { },
    "id_str" : "294905833689600000",
    "text" : "Cory Booker Saves Freezing Dog http:\/\/t.co\/6vxYwd0T",
    "id" : 294905833689600000,
    "created_at" : "2013-01-25 20:33:24 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 294923158262255616,
  "created_at" : "2013-01-25 21:42:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294922385793114112",
  "text" : "@1stCitizenKane LOLOL",
  "id" : 294922385793114112,
  "created_at" : "2013-01-25 21:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294915271225921536",
  "text" : "@IronAtheist that i can agree with..lol",
  "id" : 294915271225921536,
  "created_at" : "2013-01-25 21:10:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294912900982771713",
  "text" : "@IronAtheist I don't hate anyone. I'm a live &amp; let live type. I don't box you in.. why you box me?",
  "id" : 294912900982771713,
  "created_at" : "2013-01-25 21:01:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294911863706226688",
  "text" : "@IronAtheist I could say same to you.. set aside \"your\" view of God.",
  "id" : 294911863706226688,
  "created_at" : "2013-01-25 20:57:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294911095561388034",
  "text" : "@IronAtheist ewwww.. reality? That's icky. :P",
  "id" : 294911095561388034,
  "created_at" : "2013-01-25 20:54:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294910503178883072",
  "text" : "@IronAtheist wait.. it's wrong to think what I think? And how does it waste time?",
  "id" : 294910503178883072,
  "created_at" : "2013-01-25 20:51:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294900342024462337",
  "text" : "@IronAtheist perhaps I am... I take all my life experience and use that as my view.",
  "id" : 294900342024462337,
  "created_at" : "2013-01-25 20:11:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Bailey",
      "screen_name" : "Bailey_san75",
      "indices" : [ 0, 13 ],
      "id_str" : "51848023",
      "id" : 51848023
    }, {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 84, 96 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294890762267672576",
  "geo" : { },
  "id_str" : "294899760861675520",
  "in_reply_to_user_id" : 51848023,
  "text" : "@Bailey_san75 yes, according to that def, I am but not from my view of that word... @IronAtheist",
  "id" : 294899760861675520,
  "in_reply_to_status_id" : 294890762267672576,
  "created_at" : "2013-01-25 20:09:16 +0000",
  "in_reply_to_screen_name" : "Bailey_san75",
  "in_reply_to_user_id_str" : "51848023",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sabine Holliday",
      "screen_name" : "Sassy_McClever",
      "indices" : [ 0, 15 ],
      "id_str" : "29668574",
      "id" : 29668574
    }, {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 20, 32 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294889697489072128",
  "geo" : { },
  "id_str" : "294899095385026560",
  "in_reply_to_user_id" : 29668574,
  "text" : "@Sassy_McClever me? @IronAtheist",
  "id" : 294899095385026560,
  "in_reply_to_status_id" : 294889697489072128,
  "created_at" : "2013-01-25 20:06:37 +0000",
  "in_reply_to_screen_name" : "Sassy_McClever",
  "in_reply_to_user_id_str" : "29668574",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 0, 12 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294889256038563841",
  "text" : "@IronAtheist so what if I am? i have strong belief in supernatural power but I do not prescribe to any particular religion.",
  "id" : 294889256038563841,
  "created_at" : "2013-01-25 19:27:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Free Script Installs",
      "screen_name" : "FreeScriptInsta",
      "indices" : [ 0, 16 ],
      "id_str" : "311115199",
      "id" : 311115199
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294845460185747458",
  "in_reply_to_user_id" : 311115199,
  "text" : "@FreeScriptInsta @badkarmacore HEY what happened to website\/forum? FIX IT!",
  "id" : 294845460185747458,
  "created_at" : "2013-01-25 16:33:30 +0000",
  "in_reply_to_screen_name" : "FreeScriptInsta",
  "in_reply_to_user_id_str" : "311115199",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 4, 18 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 73 ],
      "url" : "https:\/\/t.co\/hhU4USYr",
      "expanded_url" : "https:\/\/twitter.com\/mjvinas\/status\/294499528919359488",
      "display_url" : "twitter.com\/mjvinas\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294586878710132736",
  "text" : "hey @Wylieknowords did you see this? slogan contest https:\/\/t.co\/hhU4USYr",
  "id" : 294586878710132736,
  "created_at" : "2013-01-24 23:25:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294510332095918081",
  "geo" : { },
  "id_str" : "294518102488662016",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 thanks, I'll have to look at that one",
  "id" : 294518102488662016,
  "in_reply_to_status_id" : 294510332095918081,
  "created_at" : "2013-01-24 18:52:42 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 68, 81 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294503666663165952",
  "text" : "I just bought: 'The Secret Apocalypse (Book 1)' by James Harden via @amazonkindle - curr. free",
  "id" : 294503666663165952,
  "created_at" : "2013-01-24 17:55:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria-Jose Vinas",
      "screen_name" : "mjvinas",
      "indices" : [ 3, 11 ],
      "id_str" : "105203181",
      "id" : 105203181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/uv7KyUPz",
      "expanded_url" : "http:\/\/neven1.typepad.com\/blog\/2013\/01\/slogan-contest.html",
      "display_url" : "neven1.typepad.com\/blog\/2013\/01\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294501509692006400",
  "text" : "RT @mjvinas: Slogan contest (with  cash prizes) for freeway signs on climate change, with focus on Arctic http:\/\/t.co\/uv7KyUPz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/uv7KyUPz",
        "expanded_url" : "http:\/\/neven1.typepad.com\/blog\/2013\/01\/slogan-contest.html",
        "display_url" : "neven1.typepad.com\/blog\/2013\/01\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "294499528919359488",
    "text" : "Slogan contest (with  cash prizes) for freeway signs on climate change, with focus on Arctic http:\/\/t.co\/uv7KyUPz",
    "id" : 294499528919359488,
    "created_at" : "2013-01-24 17:38:53 +0000",
    "user" : {
      "name" : "Maria-Jose Vinas",
      "screen_name" : "mjvinas",
      "protected" : false,
      "id_str" : "105203181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962835711\/a69254941b7973b8062bf72be8df66a4_normal.png",
      "id" : 105203181,
      "verified" : false
    }
  },
  "id" : 294501509692006400,
  "created_at" : "2013-01-24 17:46:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "HuffPost Religion",
      "screen_name" : "HuffPostRelig",
      "indices" : [ 21, 35 ],
      "id_str" : "117189136",
      "id" : 117189136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294491940836216832",
  "text" : "RT @AnnotatedBible: \u201C@HuffPostRelig: 2 authorities on Barack Obama's relationship with God are Barack Obama and God. Not Mark Driscoll h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Religion",
        "screen_name" : "HuffPostRelig",
        "indices" : [ 1, 15 ],
        "id_str" : "117189136",
        "id" : 117189136
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/OOwEWytl",
        "expanded_url" : "http:\/\/huff.to\/10PiTZL",
        "display_url" : "huff.to\/10PiTZL"
      } ]
    },
    "geo" : { },
    "id_str" : "294489025711075328",
    "text" : "\u201C@HuffPostRelig: 2 authorities on Barack Obama's relationship with God are Barack Obama and God. Not Mark Driscoll http:\/\/t.co\/OOwEWytl\u201D",
    "id" : 294489025711075328,
    "created_at" : "2013-01-24 16:57:09 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 294491940836216832,
  "created_at" : "2013-01-24 17:08:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294491426920734721",
  "text" : "@1stCitizenKane hmm... you just might have a point there...",
  "id" : 294491426920734721,
  "created_at" : "2013-01-24 17:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/B48bdYya",
      "expanded_url" : "http:\/\/bookwi.se\/amazon-bought-text-to-speech-software-company\/",
      "display_url" : "bookwi.se\/amazon-bought-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294486130261372928",
  "text" : "RT @adamrshields: Amazon Bought Text-To-Speech Software Company http:\/\/t.co\/B48bdYya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/B48bdYya",
        "expanded_url" : "http:\/\/bookwi.se\/amazon-bought-text-to-speech-software-company\/",
        "display_url" : "bookwi.se\/amazon-bought-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "294479283248840704",
    "text" : "Amazon Bought Text-To-Speech Software Company http:\/\/t.co\/B48bdYya",
    "id" : 294479283248840704,
    "created_at" : "2013-01-24 16:18:26 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 294486130261372928,
  "created_at" : "2013-01-24 16:45:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 61, 74 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294479153837768704",
  "text" : "I just bought: 'World of Archangels' by Sufian Chaudhary via @amazonkindle - curr. free",
  "id" : 294479153837768704,
  "created_at" : "2013-01-24 16:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294471578190741507",
  "text" : "RT @luminanceriver: You are cells in the mind of God ( the universe.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294470644870033408",
    "text" : "You are cells in the mind of God ( the universe.)",
    "id" : 294470644870033408,
    "created_at" : "2013-01-24 15:44:07 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 294471578190741507,
  "created_at" : "2013-01-24 15:47:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/noAVT1lv",
      "expanded_url" : "http:\/\/amzn.to\/NIPANW",
      "display_url" : "amzn.to\/NIPANW"
    } ]
  },
  "geo" : { },
  "id_str" : "294290431133491200",
  "text" : "finished Ascension Day by John Matthews http:\/\/t.co\/noAVT1lv",
  "id" : 294290431133491200,
  "created_at" : "2013-01-24 03:48:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294255054322532352",
  "text" : ". @1stCitizenKane everything is consciousness just different levels...",
  "id" : 294255054322532352,
  "created_at" : "2013-01-24 01:27:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294253649461395456",
  "text" : "@1stCitizenKane well, then... just let it out... lol",
  "id" : 294253649461395456,
  "created_at" : "2013-01-24 01:21:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Umstead",
      "screen_name" : "SteveUmstead",
      "indices" : [ 0, 13 ],
      "id_str" : "173669648",
      "id" : 173669648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ATA",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "TKD",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294233818246832128",
  "geo" : { },
  "id_str" : "294238373688799233",
  "in_reply_to_user_id" : 173669648,
  "text" : "@SteveUmstead i loved my time with #ATA #TKD. didnt like sparring for a long time!",
  "id" : 294238373688799233,
  "in_reply_to_status_id" : 294233818246832128,
  "created_at" : "2013-01-24 00:21:09 +0000",
  "in_reply_to_screen_name" : "SteveUmstead",
  "in_reply_to_user_id_str" : "173669648",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294216334676484096",
  "text" : ". @1stCitizenKane depends upon whom you follow. i mostly follow intelligent, enlightened souls who find the humour in life. : )",
  "id" : 294216334676484096,
  "created_at" : "2013-01-23 22:53:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294215671456362496",
  "text" : "im on my 2nd #kindlefire case and still not happy. i like to use Fire plugged in. want magnetic closure and auto on\/off.",
  "id" : 294215671456362496,
  "created_at" : "2013-01-23 22:50:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294214809971474432",
  "text" : "Can't someone make a chart of #kindlefire cases with all the various options? (camera on left or right? elastic straps or pop in? etc)",
  "id" : 294214809971474432,
  "created_at" : "2013-01-23 22:47:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 21, 30 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/ocP8wf0C",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/YZD",
      "display_url" : "omgf.ac\/ts\/YZD"
    } ]
  },
  "in_reply_to_status_id_str" : "294127710635163648",
  "geo" : { },
  "id_str" : "294144436311560192",
  "in_reply_to_user_id" : 77888423,
  "text" : "awww, cute story! RT @OMGFacts The smallest park in the world is a 2ft wide circle! Check out this hilarious pic ---&gt; http:\/\/t.co\/ocP8wf0C",
  "id" : 294144436311560192,
  "in_reply_to_status_id" : 294127710635163648,
  "created_at" : "2013-01-23 18:07:53 +0000",
  "in_reply_to_screen_name" : "OMGFacts",
  "in_reply_to_user_id_str" : "77888423",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 58, 71 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294124931459981313",
  "text" : "I just bought: 'Thin Places' by Diane Owens Prettyman via @amazonkindle - curr. free",
  "id" : 294124931459981313,
  "created_at" : "2013-01-23 16:50:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 81, 94 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294123063153397761",
  "text" : "I just bought: 'Feels Like the First Time: A True Love Story' by Shawn Inmon via @amazonkindle - curr. free #kindle",
  "id" : 294123063153397761,
  "created_at" : "2013-01-23 16:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/nQJaIneX",
      "expanded_url" : "http:\/\/via.me\/-918oteo",
      "display_url" : "via.me\/-918oteo"
    } ]
  },
  "geo" : { },
  "id_str" : "293855156938874881",
  "text" : "Fire case standing. Not a bad case for $10.00. Maybe I'll get used to the strap? http:\/\/t.co\/nQJaIneX",
  "id" : 293855156938874881,
  "created_at" : "2013-01-22 22:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/6Bbnvns5",
      "expanded_url" : "http:\/\/via.me\/-918mlz0",
      "display_url" : "via.me\/-918mlz0"
    } ]
  },
  "geo" : { },
  "id_str" : "293854061596389376",
  "text" : "Back of case for Kindle Fire HD 7. Rotating case. Cover turns on\/off. http:\/\/t.co\/6Bbnvns5",
  "id" : 293854061596389376,
  "created_at" : "2013-01-22 22:54:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/4zfXMJJR",
      "expanded_url" : "http:\/\/via.me\/-918kti4",
      "display_url" : "via.me\/-918kti4"
    } ]
  },
  "geo" : { },
  "id_str" : "293853311415771136",
  "text" : "Inside of Fintie case. Cover turns on\/off. http:\/\/t.co\/4zfXMJJR",
  "id" : 293853311415771136,
  "created_at" : "2013-01-22 22:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/C5kJhIxK",
      "expanded_url" : "http:\/\/via.me\/-918iupa",
      "display_url" : "via.me\/-918iupa"
    } ]
  },
  "geo" : { },
  "id_str" : "293852391692980224",
  "text" : "New Fintie case for my Kindle Paperwhite. Love the dual color. http:\/\/t.co\/C5kJhIxK",
  "id" : 293852391692980224,
  "created_at" : "2013-01-22 22:47:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/xbyY3vyV",
      "expanded_url" : "http:\/\/via.me\/-915dtnw",
      "display_url" : "via.me\/-915dtnw"
    } ]
  },
  "geo" : { },
  "id_str" : "293796423244320768",
  "text" : "Imcase bought for kindle fire hd 7. Hate strap. No magnetic closure. Argh! http:\/\/t.co\/xbyY3vyV",
  "id" : 293796423244320768,
  "created_at" : "2013-01-22 19:05:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293505020870135810",
  "text" : "love my dog to pieces but im so pissed at her. she squeezed out the door behind me and scared the stray kittys : (",
  "id" : 293505020870135810,
  "created_at" : "2013-01-21 23:47:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293166254158663680",
  "text" : "@SamsaricWarrior LOLOL",
  "id" : 293166254158663680,
  "created_at" : "2013-01-21 01:20:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "warmcookies",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293158276584071168",
  "text" : "@SamsaricWarrior O.M.G. ((glazedeyes)) #warmcookies",
  "id" : 293158276584071168,
  "created_at" : "2013-01-21 00:49:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "artwiculate",
      "screen_name" : "artwiculate",
      "indices" : [ 3, 15 ],
      "id_str" : "44884063",
      "id" : 44884063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Cm7juV0B",
      "expanded_url" : "http:\/\/artwiculate.com",
      "display_url" : "artwiculate.com"
    } ]
  },
  "geo" : { },
  "id_str" : "293147754614624256",
  "text" : "RT @artwiculate: Today's word is: \"struthious\". Definition here - http:\/\/t.co\/Cm7juV0B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/artwiculate.com\" rel=\"nofollow\"\u003EArtwiculate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/Cm7juV0B",
        "expanded_url" : "http:\/\/artwiculate.com",
        "display_url" : "artwiculate.com"
      } ]
    },
    "geo" : { },
    "id_str" : "293146160011550721",
    "text" : "Today's word is: \"struthious\". Definition here - http:\/\/t.co\/Cm7juV0B",
    "id" : 293146160011550721,
    "created_at" : "2013-01-21 00:01:05 +0000",
    "user" : {
      "name" : "artwiculate",
      "screen_name" : "artwiculate",
      "protected" : false,
      "id_str" : "44884063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422117036\/Page_4_normal.png",
      "id" : 44884063,
      "verified" : false
    }
  },
  "id" : 293147754614624256,
  "created_at" : "2013-01-21 00:07:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC1DRibombee\uD83D\uDC1D",
      "screen_name" : "MomoDriller",
      "indices" : [ 3, 15 ],
      "id_str" : "33171019",
      "id" : 33171019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293119245255049216",
  "text" : "RT @MomoDriller: If you're ever feeling bad about your weight, just remember that physical mass on a subatomic level doesn't actually exist!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293115061906595840",
    "text" : "If you're ever feeling bad about your weight, just remember that physical mass on a subatomic level doesn't actually exist!",
    "id" : 293115061906595840,
    "created_at" : "2013-01-20 21:57:31 +0000",
    "user" : {
      "name" : "\uD83D\uDC1DRibombee\uD83D\uDC1D",
      "screen_name" : "MomoDriller",
      "protected" : false,
      "id_str" : "33171019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786926749913407489\/_CuPFM-m_normal.jpg",
      "id" : 33171019,
      "verified" : false
    }
  },
  "id" : 293119245255049216,
  "created_at" : "2013-01-20 22:14:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haig",
      "screen_name" : "matthaig1",
      "indices" : [ 2, 12 ],
      "id_str" : "35270579",
      "id" : 35270579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lovetoread",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "booksarebeautiful",
      "indices" : [ 66, 84 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293078756694827008",
  "geo" : { },
  "id_str" : "293118033675812864",
  "in_reply_to_user_id" : 35270579,
  "text" : ". @matthaig1 love my kindle AND love paper books! : ) #lovetoread #booksarebeautiful",
  "id" : 293118033675812864,
  "in_reply_to_status_id" : 293078756694827008,
  "created_at" : "2013-01-20 22:09:19 +0000",
  "in_reply_to_screen_name" : "matthaig1",
  "in_reply_to_user_id_str" : "35270579",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u272A MG WELLS \u272A",
      "screen_name" : "MG_WELLS",
      "indices" : [ 3, 12 ],
      "id_str" : "216852605",
      "id" : 216852605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293116429518110720",
  "text" : "RT @MG_WELLS: I Am DOING MY BEST. This is ALL I can DO. I Do not HATE anyone or wish them harm. Thank You.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293114721777885184",
    "text" : "I Am DOING MY BEST. This is ALL I can DO. I Do not HATE anyone or wish them harm. Thank You.",
    "id" : 293114721777885184,
    "created_at" : "2013-01-20 21:56:10 +0000",
    "user" : {
      "name" : "\u272A MG WELLS \u272A",
      "screen_name" : "MG_WELLS",
      "protected" : false,
      "id_str" : "216852605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794541674349416449\/y4_4Nefh_normal.jpg",
      "id" : 216852605,
      "verified" : false
    }
  },
  "id" : 293116429518110720,
  "created_at" : "2013-01-20 22:02:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlekeyboard",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293101336340348929",
  "geo" : { },
  "id_str" : "293102578152116225",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields i was going thru so many batteries for light on my #kindlekeyboard and i love seeing the covers. helps remind me.",
  "id" : 293102578152116225,
  "in_reply_to_status_id" : 293101336340348929,
  "created_at" : "2013-01-20 21:07:54 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Morger",
      "screen_name" : "linkytools",
      "indices" : [ 3, 14 ],
      "id_str" : "1625925218",
      "id" : 1625925218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293091613440352257",
  "text" : "RT @LinkyTools: Your readers only care about what you care about if you give them a reason to. YOUR passion isn't automatically theirs.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293090850588745728",
    "text" : "Your readers only care about what you care about if you give them a reason to. YOUR passion isn't automatically theirs. It must be earned.",
    "id" : 293090850588745728,
    "created_at" : "2013-01-20 20:21:18 +0000",
    "user" : {
      "name" : "Brent Riggs - Linky",
      "screen_name" : "LinkyBlog",
      "protected" : false,
      "id_str" : "333649438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000189810515\/0a1b9624a3f8dd86d2c419829c357e7b_normal.png",
      "id" : 333649438,
      "verified" : false
    }
  },
  "id" : 293091613440352257,
  "created_at" : "2013-01-20 20:24:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 0, 10 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293091065257402368",
  "geo" : { },
  "id_str" : "293091484029317120",
  "in_reply_to_user_id" : 15572724,
  "text" : "@ShhDragon big smooches for Saki!! &lt;3",
  "id" : 293091484029317120,
  "in_reply_to_status_id" : 293091065257402368,
  "created_at" : "2013-01-20 20:23:49 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "calibre",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "kobomini",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "kindlepaperwhite",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293091279364042752",
  "text" : "also i could not seem to U\/L any books (yes, drm-free epub and using #calibre) #kobomini i now have #kindlepaperwhite and i LOVE it!",
  "id" : 293091279364042752,
  "created_at" : "2013-01-20 20:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kobomini",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293090550909906944",
  "text" : "DH got me #kobomini but i returned it last week. it was adorable but kindle spoiled me. found software too slow, glitchy.",
  "id" : 293090550909906944,
  "created_at" : "2013-01-20 20:20:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fay Hart",
      "screen_name" : "fayhart101",
      "indices" : [ 3, 14 ],
      "id_str" : "16545730",
      "id" : 16545730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293067646000320512",
  "text" : "RT @fayhart101: Christianity made us think there's only one heaven ~ Patti Smith",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293064250811883522",
    "text" : "Christianity made us think there's only one heaven ~ Patti Smith",
    "id" : 293064250811883522,
    "created_at" : "2013-01-20 18:35:36 +0000",
    "user" : {
      "name" : "Fay Hart",
      "screen_name" : "fayhart101",
      "protected" : false,
      "id_str" : "16545730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1505729901\/faystep_normal.jpg",
      "id" : 16545730,
      "verified" : false
    }
  },
  "id" : 293067646000320512,
  "created_at" : "2013-01-20 18:49:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292892776763359233",
  "geo" : { },
  "id_str" : "293060891908390912",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia : (",
  "id" : 293060891908390912,
  "in_reply_to_status_id" : 292892776763359233,
  "created_at" : "2013-01-20 18:22:16 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 43, 56 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293055488197787648",
  "text" : "I just bought: 'Thirst' by L.A. Larkin via @amazonkindle - curr. free #thriller",
  "id" : 293055488197787648,
  "created_at" : "2013-01-20 18:00:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/5IhlfQ8T",
      "expanded_url" : "http:\/\/goo.gl\/QkRGX",
      "display_url" : "goo.gl\/QkRGX"
    } ]
  },
  "geo" : { },
  "id_str" : "293051280128081920",
  "text" : "RT @grouchypuppy: Vermont has the highest percentage of pet owners of any state http:\/\/t.co\/5IhlfQ8T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/5IhlfQ8T",
        "expanded_url" : "http:\/\/goo.gl\/QkRGX",
        "display_url" : "goo.gl\/QkRGX"
      } ]
    },
    "geo" : { },
    "id_str" : "293049791565410304",
    "text" : "Vermont has the highest percentage of pet owners of any state http:\/\/t.co\/5IhlfQ8T",
    "id" : 293049791565410304,
    "created_at" : "2013-01-20 17:38:09 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 293051280128081920,
  "created_at" : "2013-01-20 17:44:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293041747892764673",
  "geo" : { },
  "id_str" : "293050918079963137",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes i returned kobo mini earlier this month. spoiled by kindles. software too slow, glitchy for me. trouble U\/L books.",
  "id" : 293050918079963137,
  "in_reply_to_status_id" : 293041747892764673,
  "created_at" : "2013-01-20 17:42:38 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293042991449391104",
  "text" : "@SamsaricWarrior you.. mean?? you're a teddy bear! : )",
  "id" : 293042991449391104,
  "created_at" : "2013-01-20 17:11:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beautiful",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "staugustine",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293039895126081537",
  "geo" : { },
  "id_str" : "293041877370941440",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell always enjoy yr pics! #beautiful #staugustine",
  "id" : 293041877370941440,
  "in_reply_to_status_id" : 293039895126081537,
  "created_at" : "2013-01-20 17:06:42 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293037676452519936",
  "text" : "there is no easy way to go through my following, huh? trying to sort thru, unfollow inactive accts, etc.",
  "id" : 293037676452519936,
  "created_at" : "2013-01-20 16:50:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292784575657177088",
  "geo" : { },
  "id_str" : "292785368577765377",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench uh-oh...lol. DH thinks the books I have piled on desk is \"ugly\" while I think its art!",
  "id" : 292785368577765377,
  "in_reply_to_status_id" : 292784575657177088,
  "created_at" : "2013-01-20 00:07:26 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292780264042659840",
  "geo" : { },
  "id_str" : "292781291026403328",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields maybe she's wiser than us and we lose that when we grow up..lol",
  "id" : 292781291026403328,
  "in_reply_to_status_id" : 292780264042659840,
  "created_at" : "2013-01-19 23:51:14 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292777137683959808",
  "geo" : { },
  "id_str" : "292779950413590528",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields heehee.. thats cute.",
  "id" : 292779950413590528,
  "in_reply_to_status_id" : 292777137683959808,
  "created_at" : "2013-01-19 23:45:54 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292683215162970113",
  "geo" : { },
  "id_str" : "292747713051783168",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 I'll keep him in my prayers",
  "id" : 292747713051783168,
  "in_reply_to_status_id" : 292683215162970113,
  "created_at" : "2013-01-19 21:37:48 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292681490372886528",
  "text" : "RT @Buddhaworld: If you believe in yourself  , no need to believe in anything else.volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 48.1055284, 11.5930208 ]
    },
    "id_str" : "292681110306033664",
    "text" : "If you believe in yourself  , no need to believe in anything else.volko",
    "id" : 292681110306033664,
    "created_at" : "2013-01-19 17:13:09 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 292681490372886528,
  "created_at" : "2013-01-19 17:14:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292680637134041088",
  "geo" : { },
  "id_str" : "292681382126297089",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 yuck!! glad its abating. ive avoided it so far ((knockonwood))",
  "id" : 292681382126297089,
  "in_reply_to_status_id" : 292680637134041088,
  "created_at" : "2013-01-19 17:14:13 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292680759217618944",
  "text" : "RT @Buddhaworld: Yes, you are an Island. ,volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 48.1055284, 11.5930208 ]
    },
    "id_str" : "292680334829555713",
    "text" : "Yes, you are an Island. ,volko",
    "id" : 292680334829555713,
    "created_at" : "2013-01-19 17:10:04 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 292680759217618944,
  "created_at" : "2013-01-19 17:11:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purplepoetry77",
      "screen_name" : "purplepoetry77",
      "indices" : [ 3, 18 ],
      "id_str" : "2511633660",
      "id" : 2511633660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292680629773021184",
  "text" : "RT @purplepoetry77: \u201CReality is merely an illusion, albeit a very persistent one.\u201D - Albert Einstein",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292680427070689280",
    "text" : "\u201CReality is merely an illusion, albeit a very persistent one.\u201D - Albert Einstein",
    "id" : 292680427070689280,
    "created_at" : "2013-01-19 17:10:26 +0000",
    "user" : {
      "name" : "poemscape",
      "screen_name" : "poemscape",
      "protected" : true,
      "id_str" : "310624642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552530565875105796\/G7vcRm1e_normal.jpeg",
      "id" : 310624642,
      "verified" : false
    }
  },
  "id" : 292680629773021184,
  "created_at" : "2013-01-19 17:11:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292680573674205184",
  "text" : "we have been led to believe in the reality before us...",
  "id" : 292680573674205184,
  "created_at" : "2013-01-19 17:11:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292678971542355968",
  "text" : "reality is not real",
  "id" : 292678971542355968,
  "created_at" : "2013-01-19 17:04:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/xz4FirrT",
      "expanded_url" : "http:\/\/Audible.com",
      "display_url" : "Audible.com"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/9dZvtRoC",
      "expanded_url" : "http:\/\/bookwi.se\/audible-com-wishes-granted-sale\/",
      "display_url" : "bookwi.se\/audible-com-wi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292678784186986496",
  "text" : "RT @adamrshields: Today is the last day of http:\/\/t.co\/xz4FirrT Wishes Granted Sale - 122 audiobooks for $6.95 each http:\/\/t.co\/9dZvtRoC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/xz4FirrT",
        "expanded_url" : "http:\/\/Audible.com",
        "display_url" : "Audible.com"
      }, {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/9dZvtRoC",
        "expanded_url" : "http:\/\/bookwi.se\/audible-com-wishes-granted-sale\/",
        "display_url" : "bookwi.se\/audible-com-wi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "292678116176969728",
    "text" : "Today is the last day of http:\/\/t.co\/xz4FirrT Wishes Granted Sale - 122 audiobooks for $6.95 each http:\/\/t.co\/9dZvtRoC",
    "id" : 292678116176969728,
    "created_at" : "2013-01-19 17:01:15 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 292678784186986496,
  "created_at" : "2013-01-19 17:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292677672222474241",
  "text" : "@SamsaricWarrior LOL",
  "id" : 292677672222474241,
  "created_at" : "2013-01-19 16:59:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "indices" : [ 3, 15 ],
      "id_str" : "25090088",
      "id" : 25090088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/8D6h108N",
      "expanded_url" : "http:\/\/www.bestsellingreads.com",
      "display_url" : "bestsellingreads.com"
    } ]
  },
  "geo" : { },
  "id_str" : "292676418071044096",
  "text" : "RT @BenMWallace: Have you guys checked out http:\/\/t.co\/8D6h108N ?  You could win an iPad mini and one of my books.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/8D6h108N",
        "expanded_url" : "http:\/\/www.bestsellingreads.com",
        "display_url" : "bestsellingreads.com"
      } ]
    },
    "geo" : { },
    "id_str" : "292673297055891456",
    "text" : "Have you guys checked out http:\/\/t.co\/8D6h108N ?  You could win an iPad mini and one of my books.",
    "id" : 292673297055891456,
    "created_at" : "2013-01-19 16:42:06 +0000",
    "user" : {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "protected" : false,
      "id_str" : "25090088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560492072914796544\/pPK5ZIrh_normal.png",
      "id" : 25090088,
      "verified" : false
    }
  },
  "id" : 292676418071044096,
  "created_at" : "2013-01-19 16:54:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebooks",
      "indices" : [ 93, 100 ]
    }, {
      "text" : "instagram",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/zwa3GS0j",
      "expanded_url" : "http:\/\/bit.ly\/w6Y5MP",
      "display_url" : "bit.ly\/w6Y5MP"
    } ]
  },
  "geo" : { },
  "id_str" : "292676156484886528",
  "text" : "RT @ebookfriendly: 30+ awesome pictures showing how readers love ebooks http:\/\/t.co\/zwa3GS0j #ebooks #instagram",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebooks",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "instagram",
        "indices" : [ 82, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/zwa3GS0j",
        "expanded_url" : "http:\/\/bit.ly\/w6Y5MP",
        "display_url" : "bit.ly\/w6Y5MP"
      } ]
    },
    "geo" : { },
    "id_str" : "292674377563127808",
    "text" : "30+ awesome pictures showing how readers love ebooks http:\/\/t.co\/zwa3GS0j #ebooks #instagram",
    "id" : 292674377563127808,
    "created_at" : "2013-01-19 16:46:23 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 292676156484886528,
  "created_at" : "2013-01-19 16:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292675161172344832",
  "geo" : { },
  "id_str" : "292675633551650816",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater awww..",
  "id" : 292675633551650816,
  "in_reply_to_status_id" : 292675161172344832,
  "created_at" : "2013-01-19 16:51:23 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292667065507135489",
  "geo" : { },
  "id_str" : "292675316797812736",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 how are you, dear mimi? cold here in ny. snow on ground. cannot wait for spring and my bluebird!",
  "id" : 292675316797812736,
  "in_reply_to_status_id" : 292667065507135489,
  "created_at" : "2013-01-19 16:50:07 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 91, 104 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292657182766399488",
  "text" : "I just bought: 'Chickens, Mules and Two Old Fools (Old Fool Series)' by Victoria Twead via @amazonkindle - curr. 99 cents",
  "id" : 292657182766399488,
  "created_at" : "2013-01-19 15:38:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "292426041824272385",
  "geo" : { },
  "id_str" : "292429857009328128",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses so glad riley found you. : ) love hearing about him.",
  "id" : 292429857009328128,
  "in_reply_to_status_id" : 292426041824272385,
  "created_at" : "2013-01-19 00:34:45 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 3, 16 ],
      "id_str" : "14124789",
      "id" : 14124789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCodeFriday",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292387684222124032",
  "text" : "RT @bigfishgames: Alright folks, here are the details. If *10* people ReTweet this, we'll give out a code for a FREE game! #FreeCodeFriday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreeCodeFriday",
        "indices" : [ 105, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292387241534291972",
    "text" : "Alright folks, here are the details. If *10* people ReTweet this, we'll give out a code for a FREE game! #FreeCodeFriday",
    "id" : 292387241534291972,
    "created_at" : "2013-01-18 21:45:25 +0000",
    "user" : {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "protected" : false,
      "id_str" : "14124789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676860668365029376\/hAOsWfK1_normal.jpg",
      "id" : 14124789,
      "verified" : false
    }
  },
  "id" : 292387684222124032,
  "created_at" : "2013-01-18 21:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/3sP35TzJ",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2013\/01\/18\/can-oregon-save-american-health-care\/",
      "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292383525179641857",
  "text" : "Can Oregon save American health care? http:\/\/t.co\/3sP35TzJ",
  "id" : 292383525179641857,
  "created_at" : "2013-01-18 21:30:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292380884764594176",
  "text" : "itunes sucks",
  "id" : 292380884764594176,
  "created_at" : "2013-01-18 21:20:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Dye",
      "screen_name" : "DYECASTING",
      "indices" : [ 3, 14 ],
      "id_str" : "17612162",
      "id" : 17612162
    }, {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 26, 39 ],
      "id_str" : "14835882",
      "id" : 14835882
    }, {
      "name" : "ChurchMag",
      "screen_name" : "ChurchMag",
      "indices" : [ 110, 120 ],
      "id_str" : "16446735",
      "id" : 16446735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292334315596046336",
  "text" : "RT @DYECASTING: Thanks to @adamrshields for this! \/\/ Unroll.me \u2013 Revolutionary Email Subscription Managment | @ChurchMag http:\/\/t.co\/XN5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Shields",
        "screen_name" : "adamrshields",
        "indices" : [ 10, 23 ],
        "id_str" : "14835882",
        "id" : 14835882
      }, {
        "name" : "ChurchMag",
        "screen_name" : "ChurchMag",
        "indices" : [ 94, 104 ],
        "id_str" : "16446735",
        "id" : 16446735
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/XN5UL2PV",
        "expanded_url" : "http:\/\/ht.ly\/gQXBt",
        "display_url" : "ht.ly\/gQXBt"
      } ]
    },
    "geo" : { },
    "id_str" : "291566797658943489",
    "text" : "Thanks to @adamrshields for this! \/\/ Unroll.me \u2013 Revolutionary Email Subscription Managment | @ChurchMag http:\/\/t.co\/XN5UL2PV",
    "id" : 291566797658943489,
    "created_at" : "2013-01-16 15:25:16 +0000",
    "user" : {
      "name" : "Eric Dye",
      "screen_name" : "DYECASTING",
      "protected" : false,
      "id_str" : "17612162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743068356341796864\/PnrJaBc4_normal.jpg",
      "id" : 17612162,
      "verified" : false
    }
  },
  "id" : 292334315596046336,
  "created_at" : "2013-01-18 18:15:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/y0VekkNE",
      "expanded_url" : "http:\/\/Bookwi.se",
      "display_url" : "Bookwi.se"
    } ]
  },
  "geo" : { },
  "id_str" : "292334118992232448",
  "text" : "RT @adamrshields: Just noticed that I passed 2000 total posts on http:\/\/t.co\/y0VekkNE today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http:\/\/t.co\/y0VekkNE",
        "expanded_url" : "http:\/\/Bookwi.se",
        "display_url" : "Bookwi.se"
      } ]
    },
    "geo" : { },
    "id_str" : "290662072717561857",
    "text" : "Just noticed that I passed 2000 total posts on http:\/\/t.co\/y0VekkNE today.",
    "id" : 290662072717561857,
    "created_at" : "2013-01-14 03:30:13 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 292334118992232448,
  "created_at" : "2013-01-18 18:14:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292332165906169856",
  "text" : "RT @adamrshields: Anyone have a book you would like to review on Bookwi.se soon? Let me know, I would love to post it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292033194449051649",
    "text" : "Anyone have a book you would like to review on Bookwi.se soon? Let me know, I would love to post it.",
    "id" : 292033194449051649,
    "created_at" : "2013-01-17 22:18:33 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 292332165906169856,
  "created_at" : "2013-01-18 18:06:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 7, 20 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292319971411914753",
  "text" : "i hope @AmazonKindle adds \"send to email\" option under Share. so i can remember to check out other books mentioned (at end.) #kindle",
  "id" : 292319971411914753,
  "created_at" : "2013-01-18 17:18:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291978145526083584",
  "text" : "@SamsaricWarrior LOLOL",
  "id" : 291978145526083584,
  "created_at" : "2013-01-17 18:39:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 12, 21 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/hwbeYD9C",
      "expanded_url" : "http:\/\/www.free-installations.info\/threads\/spam-this-thread.625\/page-70#post-28356",
      "display_url" : "free-installations.info\/threads\/spam-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291970889287864320",
  "text" : "@ryanholt94 @Mortenrb http:\/\/t.co\/hwbeYD9C",
  "id" : 291970889287864320,
  "created_at" : "2013-01-17 18:10:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 0, 11 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291951023260569601",
  "geo" : { },
  "id_str" : "291960113399488512",
  "in_reply_to_user_id" : 105134401,
  "text" : "@TimGreaton that would be great!",
  "id" : 291960113399488512,
  "in_reply_to_status_id" : 291951023260569601,
  "created_at" : "2013-01-17 17:28:10 +0000",
  "in_reply_to_screen_name" : "TimGreaton",
  "in_reply_to_user_id_str" : "105134401",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291959884906377216",
  "text" : "RT @TimGreaton: Uncle Finneus may be the focus of a future \"Under-Heaven\" sequel. Learn how he rose from Hell to \"Under-Heaven\" http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/WjaHt8Xi",
        "expanded_url" : "http:\/\/goo.gl\/UcKSi",
        "display_url" : "goo.gl\/UcKSi"
      } ]
    },
    "geo" : { },
    "id_str" : "291951023260569601",
    "text" : "Uncle Finneus may be the focus of a future \"Under-Heaven\" sequel. Learn how he rose from Hell to \"Under-Heaven\" http:\/\/t.co\/WjaHt8Xi",
    "id" : 291951023260569601,
    "created_at" : "2013-01-17 16:52:02 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 291959884906377216,
  "created_at" : "2013-01-17 17:27:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camy Tang",
      "screen_name" : "camytang",
      "indices" : [ 128, 137 ],
      "id_str" : "14950452",
      "id" : 14950452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/3Nkz8Z8V",
      "expanded_url" : "http:\/\/ow.ly\/gTBiO",
      "display_url" : "ow.ly\/gTBiO"
    } ]
  },
  "geo" : { },
  "id_str" : "291959243953807360",
  "text" : "RT @NelsonFiction: Love a great action-packed read? 14 more hours to download Protection for Hire for FREE http:\/\/t.co\/3Nkz8Z8V @camytang",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Camy Tang",
        "screen_name" : "camytang",
        "indices" : [ 109, 118 ],
        "id_str" : "14950452",
        "id" : 14950452
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/3Nkz8Z8V",
        "expanded_url" : "http:\/\/ow.ly\/gTBiO",
        "display_url" : "ow.ly\/gTBiO"
      } ]
    },
    "geo" : { },
    "id_str" : "291955678854135808",
    "text" : "Love a great action-packed read? 14 more hours to download Protection for Hire for FREE http:\/\/t.co\/3Nkz8Z8V @camytang",
    "id" : 291955678854135808,
    "created_at" : "2013-01-17 17:10:32 +0000",
    "user" : {
      "name" : "TNZFiction",
      "screen_name" : "TNZFiction",
      "protected" : false,
      "id_str" : "113483630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3476074316\/bb1f0680a3472e1f316fb930048ce35d_normal.jpeg",
      "id" : 113483630,
      "verified" : false
    }
  },
  "id" : 291959243953807360,
  "created_at" : "2013-01-17 17:24:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/t95a9lnf",
      "expanded_url" : "http:\/\/Audible.com",
      "display_url" : "Audible.com"
    }, {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/t95a9lnf",
      "expanded_url" : "http:\/\/Audible.com",
      "display_url" : "Audible.com"
    } ]
  },
  "geo" : { },
  "id_str" : "291944066441175043",
  "text" : "RT @bookwiseblog: http:\/\/t.co\/t95a9lnf Wishes Granted Sale: \nhttp:\/\/t.co\/t95a9lnf is having a 48 hour \u2018Wishes Granted\u2019 sale. \u00A0122 of...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/t95a9lnf",
        "expanded_url" : "http:\/\/Audible.com",
        "display_url" : "Audible.com"
      }, {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/t95a9lnf",
        "expanded_url" : "http:\/\/Audible.com",
        "display_url" : "Audible.com"
      }, {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/2Mdj7Zr0",
        "expanded_url" : "http:\/\/bit.ly\/VqYTaC",
        "display_url" : "bit.ly\/VqYTaC"
      } ]
    },
    "geo" : { },
    "id_str" : "291943659941789696",
    "text" : "http:\/\/t.co\/t95a9lnf Wishes Granted Sale: \nhttp:\/\/t.co\/t95a9lnf is having a 48 hour \u2018Wishes Granted\u2019 sale. \u00A0122 of... http:\/\/t.co\/2Mdj7Zr0",
    "id" : 291943659941789696,
    "created_at" : "2013-01-17 16:22:47 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 291944066441175043,
  "created_at" : "2013-01-17 16:24:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291943619399655426",
  "text" : "focus on the guns will not fix anything. focus on making life better for ALL humans.",
  "id" : 291943619399655426,
  "created_at" : "2013-01-17 16:22:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291942912596533248",
  "text" : "my reality is becoming a van gogh painting...",
  "id" : 291942912596533248,
  "created_at" : "2013-01-17 16:19:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Blomster",
      "screen_name" : "kblomster",
      "indices" : [ 2, 12 ],
      "id_str" : "200648624",
      "id" : 200648624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291931747904544768",
  "geo" : { },
  "id_str" : "291941323169222656",
  "in_reply_to_user_id" : 200648624,
  "text" : ". @kblomster but US doesnt want to be like Europe cuz that would be baaad... o-O",
  "id" : 291941323169222656,
  "in_reply_to_status_id" : 291931747904544768,
  "created_at" : "2013-01-17 16:13:30 +0000",
  "in_reply_to_screen_name" : "kblomster",
  "in_reply_to_user_id_str" : "200648624",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karl Blomster",
      "screen_name" : "kblomster",
      "indices" : [ 3, 13 ],
      "id_str" : "200648624",
      "id" : 200648624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/477xbOFO",
      "expanded_url" : "http:\/\/i.imgur.com\/HKXM8.png",
      "display_url" : "i.imgur.com\/HKXM8.png"
    } ]
  },
  "geo" : { },
  "id_str" : "291940853776277504",
  "text" : "RT @kblomster: http:\/\/t.co\/477xbOFO remember kids, guns don't kill people\n(yes they fucking do, there's a linear fucking relationship ri ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/477xbOFO",
        "expanded_url" : "http:\/\/i.imgur.com\/HKXM8.png",
        "display_url" : "i.imgur.com\/HKXM8.png"
      } ]
    },
    "geo" : { },
    "id_str" : "291931747904544768",
    "text" : "http:\/\/t.co\/477xbOFO remember kids, guns don't kill people\n(yes they fucking do, there's a linear fucking relationship right there)",
    "id" : 291931747904544768,
    "created_at" : "2013-01-17 15:35:27 +0000",
    "user" : {
      "name" : "Karl Blomster",
      "screen_name" : "kblomster",
      "protected" : false,
      "id_str" : "200648624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543696985790767104\/Ynz2fqp__normal.jpeg",
      "id" : 200648624,
      "verified" : false
    }
  },
  "id" : 291940853776277504,
  "created_at" : "2013-01-17 16:11:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 85, 98 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/cacmie8N",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B003UHVYQE\/ref=cm_sw_r_tw_ask_MK.yE.13SF7K9",
      "display_url" : "amazon.com\/dp\/B003UHVYQE\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291927020424806400",
  "text" : "I just bought: 'Peace Warrior (Peace Warrior Trilogy, Book 1)' by Steven L. Hawk via @amazonkindle - curr. free http:\/\/t.co\/cacmie8N",
  "id" : 291927020424806400,
  "created_at" : "2013-01-17 15:16:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/kVcoDW2e",
      "expanded_url" : "http:\/\/amzn.to\/eei61r",
      "display_url" : "amzn.to\/eei61r"
    } ]
  },
  "geo" : { },
  "id_str" : "291738776160583680",
  "text" : "finished Pictures of You by Caroline Leavitt http:\/\/t.co\/kVcoDW2e",
  "id" : 291738776160583680,
  "created_at" : "2013-01-17 02:48:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/P7yLIISC",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/FE6",
      "display_url" : "omgf.ac\/ts\/FE6"
    } ]
  },
  "geo" : { },
  "id_str" : "291721535624990720",
  "text" : "RT @OMGFacts: The movie Hugo cured a person\u2019s stereo-BLINDNESS! Learn more here --&gt; http:\/\/t.co\/P7yLIISC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/P7yLIISC",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/FE6",
        "display_url" : "omgf.ac\/ts\/FE6"
      } ]
    },
    "geo" : { },
    "id_str" : "291719071001616384",
    "text" : "The movie Hugo cured a person\u2019s stereo-BLINDNESS! Learn more here --&gt; http:\/\/t.co\/P7yLIISC",
    "id" : 291719071001616384,
    "created_at" : "2013-01-17 01:30:21 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 291721535624990720,
  "created_at" : "2013-01-17 01:40:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 65, 78 ],
      "id_str" : "84249568",
      "id" : 84249568
    }, {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 110, 123 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291711222997463040",
  "text" : "I just bought: 'Nick of Time (A Bug Man Novel)' by Tim Downs via @amazonkindle curr. on sale 2.99 - thanks to @bookwiseblog",
  "id" : 291711222997463040,
  "created_at" : "2013-01-17 00:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291684088195203072",
  "geo" : { },
  "id_str" : "291709498735857664",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields i picked this one up. looks interesting.",
  "id" : 291709498735857664,
  "in_reply_to_status_id" : 291684088195203072,
  "created_at" : "2013-01-17 00:52:18 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 32, 45 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/b0iugCDZ",
      "expanded_url" : "http:\/\/bookwi.se\/14-christian-kindle-thrillers-for-2-99-or-less\/",
      "display_url" : "bookwi.se\/14-christian-k\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "291703321922789376",
  "geo" : { },
  "id_str" : "291709102466420736",
  "in_reply_to_user_id" : 14835882,
  "text" : "looks like some good ones... RT @adamrshields 14 Christian Kindle Thrillers for $2.99 or Less http:\/\/t.co\/b0iugCDZ",
  "id" : 291709102466420736,
  "in_reply_to_status_id" : 291703321922789376,
  "created_at" : "2013-01-17 00:50:44 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291691839550013441",
  "text" : "RT @adamrshields: Free Audiobook - The B-Team by John Scalzi - first in a collection of short stories from the Old Man's War universe ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/To1OMwCr",
        "expanded_url" : "http:\/\/bookwi.se\/free-audiobook-the-b-team-by-john-scalzi\/",
        "display_url" : "bookwi.se\/free-audiobook\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291684088195203072",
    "text" : "Free Audiobook - The B-Team by John Scalzi - first in a collection of short stories from the Old Man's War universe http:\/\/t.co\/To1OMwCr",
    "id" : 291684088195203072,
    "created_at" : "2013-01-16 23:11:20 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 291691839550013441,
  "created_at" : "2013-01-16 23:42:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sigh",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291323912665587713",
  "text" : "\"the flu has a lot of us terrified\" news person on tv... #sigh (concerned, maybe.. but terrified?)",
  "id" : 291323912665587713,
  "created_at" : "2013-01-15 23:20:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291320828035989504",
  "geo" : { },
  "id_str" : "291322347141619712",
  "in_reply_to_user_id" : 140291463,
  "text" : "@SkypilotOfHope what a sweet face : ) smooches to Ruby!",
  "id" : 291322347141619712,
  "in_reply_to_status_id" : 291320828035989504,
  "created_at" : "2013-01-15 23:13:54 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291314625629278208",
  "geo" : { },
  "id_str" : "291317386592788481",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny occasionally i still have school nightmares...",
  "id" : 291317386592788481,
  "in_reply_to_status_id" : 291314625629278208,
  "created_at" : "2013-01-15 22:54:12 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291314625629278208",
  "geo" : { },
  "id_str" : "291317142316539904",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny me, too. drove my mom nuts. technically, i shouldnt have graduated but teachers felt bad for me..lol",
  "id" : 291317142316539904,
  "in_reply_to_status_id" : 291314625629278208,
  "created_at" : "2013-01-15 22:53:13 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Belderbos",
      "screen_name" : "bbelderbos",
      "indices" : [ 3, 14 ],
      "id_str" : "177360544",
      "id" : 177360544
    }, {
      "name" : "TNW Facebook",
      "screen_name" : "tnwfacebook",
      "indices" : [ 89, 101 ],
      "id_str" : "219716910",
      "id" : 219716910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/cYwdnd3w",
      "expanded_url" : "http:\/\/tnw.to\/d0UGg",
      "display_url" : "tnw.to\/d0UGg"
    } ]
  },
  "geo" : { },
  "id_str" : "291313867013890049",
  "text" : "RT @bbelderbos: What happened when Facebook disabled my account http:\/\/t.co\/cYwdnd3w via @TNWfacebook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TNW Facebook",
        "screen_name" : "tnwfacebook",
        "indices" : [ 73, 85 ],
        "id_str" : "219716910",
        "id" : 219716910
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/cYwdnd3w",
        "expanded_url" : "http:\/\/tnw.to\/d0UGg",
        "display_url" : "tnw.to\/d0UGg"
      } ]
    },
    "geo" : { },
    "id_str" : "291311481717420033",
    "text" : "What happened when Facebook disabled my account http:\/\/t.co\/cYwdnd3w via @TNWfacebook",
    "id" : 291311481717420033,
    "created_at" : "2013-01-15 22:30:44 +0000",
    "user" : {
      "name" : "Bob Belderbos",
      "screen_name" : "bbelderbos",
      "protected" : false,
      "id_str" : "177360544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743034682992906240\/WQ1ZOsHX_normal.jpg",
      "id" : 177360544,
      "verified" : false
    }
  },
  "id" : 291313867013890049,
  "created_at" : "2013-01-15 22:40:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291302059851018242",
  "geo" : { },
  "id_str" : "291312632261132290",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i get excited when i make a new realization.. hubby says \"they didnt teach you that in school?\" prob but it didnt \"take\" LOL",
  "id" : 291312632261132290,
  "in_reply_to_status_id" : 291302059851018242,
  "created_at" : "2013-01-15 22:35:18 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291302059851018242",
  "geo" : { },
  "id_str" : "291312308876099584",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny were you always on honor roll? i loved learning but school too intimidating. too anxious to understand. was a daydreamer.",
  "id" : 291312308876099584,
  "in_reply_to_status_id" : 291302059851018242,
  "created_at" : "2013-01-15 22:34:01 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "indices" : [ 3, 11 ],
      "id_str" : "508402674",
      "id" : 508402674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291310401210163201",
  "text" : "RT @livrada: You can gift Before I Go To Sleep as a livrada card in the US. The book is always worth reading before seeing the movie! @S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "S J Watson",
        "screen_name" : "SJ_Watson",
        "indices" : [ 121, 131 ],
        "id_str" : "14318401",
        "id" : 14318401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291307596672008192",
    "text" : "You can gift Before I Go To Sleep as a livrada card in the US. The book is always worth reading before seeing the movie! @SJ_Watson",
    "id" : 291307596672008192,
    "created_at" : "2013-01-15 22:15:17 +0000",
    "user" : {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "protected" : false,
      "id_str" : "508402674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580472619763400706\/oLAqo7Ph_normal.png",
      "id" : 508402674,
      "verified" : false
    }
  },
  "id" : 291310401210163201,
  "created_at" : "2013-01-15 22:26:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291310249565114368",
  "text" : "RT @RichardMabry: If \"sugary soft drinks\" are responsible for epidemic obesity in the US, but I've been drinking diet Coke for ten years ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291308065607778304",
    "text" : "If \"sugary soft drinks\" are responsible for epidemic obesity in the US, but I've been drinking diet Coke for ten years, why am I overweight?",
    "id" : 291308065607778304,
    "created_at" : "2013-01-15 22:17:09 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 291310249565114368,
  "created_at" : "2013-01-15 22:25:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291285209213706240",
  "geo" : { },
  "id_str" : "291299890124955649",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny you were a straight A student, weren't you? :P",
  "id" : 291299890124955649,
  "in_reply_to_status_id" : 291285209213706240,
  "created_at" : "2013-01-15 21:44:40 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291242708725555200",
  "text" : "RT @SpiritualNurse: If choose to bless another person, I will always end up feeling more blessed. ~ Marianne Williamson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291238391817854977",
    "text" : "If choose to bless another person, I will always end up feeling more blessed. ~ Marianne Williamson",
    "id" : 291238391817854977,
    "created_at" : "2013-01-15 17:40:18 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 291242708725555200,
  "created_at" : "2013-01-15 17:57:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mavireck",
      "screen_name" : "mavireck",
      "indices" : [ 3, 12 ],
      "id_str" : "730172730012618752",
      "id" : 730172730012618752
    }, {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 54, 65 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/k7FVtjvh",
      "expanded_url" : "http:\/\/twitpic.com\/bvi7ny",
      "display_url" : "twitpic.com\/bvi7ny"
    } ]
  },
  "in_reply_to_status_id_str" : "291239470529921025",
  "geo" : { },
  "id_str" : "291242521202393089",
  "in_reply_to_user_id" : 27268080,
  "text" : "RT @mavireck Irish Flu Shots http:\/\/t.co\/k7FVtjvh CC: @TrishScott thinking of your scotch LOL",
  "id" : 291242521202393089,
  "in_reply_to_status_id" : 291239470529921025,
  "created_at" : "2013-01-15 17:56:42 +0000",
  "in_reply_to_screen_name" : "StarStuff_ivan",
  "in_reply_to_user_id_str" : "27268080",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291241586224943104",
  "text" : "we can be diluted w human baggage but we never lose that spark of divinity.. the true soul.",
  "id" : 291241586224943104,
  "created_at" : "2013-01-15 17:52:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291241308817854464",
  "text" : "something popped out at me. salt cannot lose its saltiness (becuz then its not salt.) Same for ppl. Cannot lose our divinity (salt.)",
  "id" : 291241308817854464,
  "created_at" : "2013-01-15 17:51:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291240809213337600",
  "text" : "bible study today.. continued our word study on salt.",
  "id" : 291240809213337600,
  "created_at" : "2013-01-15 17:49:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "indices" : [ 3, 18 ],
      "id_str" : "75708394",
      "id" : 75708394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290638272412123137",
  "text" : "RT @JulianneGarska: I asked Gabriella (7) to do something and she said excitedly and sweetly, \"Momma, I'm hanging out with my sister.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290630850473771009",
    "text" : "I asked Gabriella (7) to do something and she said excitedly and sweetly, \"Momma, I'm hanging out with my sister.\"",
    "id" : 290630850473771009,
    "created_at" : "2013-01-14 01:26:09 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 290638272412123137,
  "created_at" : "2013-01-14 01:55:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack",
      "screen_name" : "JackBlackTheCat",
      "indices" : [ 3, 19 ],
      "id_str" : "760176588",
      "id" : 760176588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290638191474651139",
  "text" : "RT @JackBlackTheCat: Please do not buy fake Ugg boots. The fur is likely to be from racoon dogs which are skinned alive in China. Please ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290587932178382848",
    "text" : "Please do not buy fake Ugg boots. The fur is likely to be from racoon dogs which are skinned alive in China. Please RT to raise awareness \uD83D\uDC9C",
    "id" : 290587932178382848,
    "created_at" : "2013-01-13 22:35:36 +0000",
    "user" : {
      "name" : "Jack",
      "screen_name" : "JackBlackTheCat",
      "protected" : false,
      "id_str" : "760176588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620964937993732096\/lz8BmsSw_normal.jpg",
      "id" : 760176588,
      "verified" : false
    }
  },
  "id" : 290638191474651139,
  "created_at" : "2013-01-14 01:55:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    }, {
      "name" : "Alexander Rosario",
      "screen_name" : "bigalrosario",
      "indices" : [ 14, 27 ],
      "id_str" : "842456604",
      "id" : 842456604
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 36, 46 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290287358509719553",
  "text" : "RT @Pandeism: @bigalrosario Because @neiltyson is a badass.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexander Rosario",
        "screen_name" : "bigalrosario",
        "indices" : [ 0, 13 ],
        "id_str" : "842456604",
        "id" : 842456604
      }, {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 22, 32 ],
        "id_str" : "19725644",
        "id" : 19725644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "290279739002875904",
    "geo" : { },
    "id_str" : "290284076580077568",
    "in_reply_to_user_id" : 19725644,
    "text" : "@bigalrosario Because @neiltyson is a badass.",
    "id" : 290284076580077568,
    "in_reply_to_status_id" : 290279739002875904,
    "created_at" : "2013-01-13 02:28:11 +0000",
    "in_reply_to_screen_name" : "neiltyson",
    "in_reply_to_user_id_str" : "19725644",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 290287358509719553,
  "created_at" : "2013-01-13 02:41:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/WFiCWBbF",
      "expanded_url" : "http:\/\/journal.neilgaiman.com\/2013\/01\/the-power-of-dog-cabal-2003-2013.html",
      "display_url" : "journal.neilgaiman.com\/2013\/01\/the-po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290236819965112322",
  "text" : "The Power of the Dog. Cabal (2003-2013) http:\/\/t.co\/WFiCWBbF",
  "id" : 290236819965112322,
  "created_at" : "2013-01-12 23:20:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/U7VYWBvS",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/Tia",
      "display_url" : "omgf.ac\/ts\/Tia"
    } ]
  },
  "geo" : { },
  "id_str" : "290235896240939008",
  "text" : "RT @OMGFacts: PINE CONES have genders! Wanna know how to tell the difference? Learn here --&gt; http:\/\/t.co\/U7VYWBvS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/U7VYWBvS",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/Tia",
        "display_url" : "omgf.ac\/ts\/Tia"
      } ]
    },
    "geo" : { },
    "id_str" : "290231828999188480",
    "text" : "PINE CONES have genders! Wanna know how to tell the difference? Learn here --&gt; http:\/\/t.co\/U7VYWBvS",
    "id" : 290231828999188480,
    "created_at" : "2013-01-12 23:00:34 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 290235896240939008,
  "created_at" : "2013-01-12 23:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290180743148224512",
  "text" : "RT @angelaharms: Not gonna apologize for standing up to fat abuse. It took all my courage, &amp; I'm glad I did. Fuck that humor.  @sagh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Aghaulor",
        "screen_name" : "saghaulor",
        "indices" : [ 114, 124 ],
        "id_str" : "107083138",
        "id" : 107083138
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "290179286722301952",
    "geo" : { },
    "id_str" : "290179850373840897",
    "in_reply_to_user_id" : 107083138,
    "text" : "Not gonna apologize for standing up to fat abuse. It took all my courage, &amp; I'm glad I did. Fuck that humor.  @saghaulor",
    "id" : 290179850373840897,
    "in_reply_to_status_id" : 290179286722301952,
    "created_at" : "2013-01-12 19:34:02 +0000",
    "in_reply_to_screen_name" : "saghaulor",
    "in_reply_to_user_id_str" : "107083138",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 290180743148224512,
  "created_at" : "2013-01-12 19:37:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie MI-Italia",
      "screen_name" : "brenouf590",
      "indices" : [ 0, 11 ],
      "id_str" : "70111722",
      "id" : 70111722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "290159635476930560",
  "geo" : { },
  "id_str" : "290179974986620929",
  "in_reply_to_user_id" : 70111722,
  "text" : "@brenouf590 at the last minute a home was found for them. : ) (i had my ears covered thinking they were going to have audio of shots)",
  "id" : 290179974986620929,
  "in_reply_to_status_id" : 290159635476930560,
  "created_at" : "2013-01-12 19:34:31 +0000",
  "in_reply_to_screen_name" : "brenouf590",
  "in_reply_to_user_id_str" : "70111722",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290110007578611712",
  "text" : "reality disintegrating piece by piece...",
  "id" : 290110007578611712,
  "created_at" : "2013-01-12 14:56:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289920414510112768",
  "geo" : { },
  "id_str" : "290108169441648640",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste heehee.. kinda figured that : )",
  "id" : 290108169441648640,
  "in_reply_to_status_id" : 289920414510112768,
  "created_at" : "2013-01-12 14:49:12 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "indices" : [ 3, 15 ],
      "id_str" : "18256901",
      "id" : 18256901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289920456105000960",
  "text" : "RT @deonnakelli: Don't believe everything you think. Your head can F-you up. Seriously.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289914716179025920",
    "text" : "Don't believe everything you think. Your head can F-you up. Seriously.",
    "id" : 289914716179025920,
    "created_at" : "2013-01-12 02:00:29 +0000",
    "user" : {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "protected" : false,
      "id_str" : "18256901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796046774813200384\/-eoNtOic_normal.jpg",
      "id" : 18256901,
      "verified" : false
    }
  },
  "id" : 289920456105000960,
  "created_at" : "2013-01-12 02:23:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grumpy cat",
      "screen_name" : "verygrumpycat",
      "indices" : [ 14, 28 ],
      "id_str" : "1871536201",
      "id" : 1871536201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289910638921261057",
  "geo" : { },
  "id_str" : "289919771783352320",
  "in_reply_to_user_id" : 384507734,
  "text" : "Every day! RT @VeryGrumpyCat Have you ever just sat there and realized how weird you are?",
  "id" : 289919771783352320,
  "in_reply_to_status_id" : 289910638921261057,
  "created_at" : "2013-01-12 02:20:34 +0000",
  "in_reply_to_screen_name" : "DrScienceCat",
  "in_reply_to_user_id_str" : "384507734",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289917986922459136",
  "geo" : { },
  "id_str" : "289918867839516672",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste im a nut but im not conservative...",
  "id" : 289918867839516672,
  "in_reply_to_status_id" : 289917986922459136,
  "created_at" : "2013-01-12 02:16:59 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289790786848034818",
  "geo" : { },
  "id_str" : "289796108476092416",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time happyhappy to you, too, my friend! muah! xoxo",
  "id" : 289796108476092416,
  "in_reply_to_status_id" : 289790786848034818,
  "created_at" : "2013-01-11 18:09:11 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u044E\u0448\u0430 \u0410\u043D\u0433\u0435\u043B",
      "screen_name" : "Tomthunkit",
      "indices" : [ 3, 14 ],
      "id_str" : "2371889310",
      "id" : 2371889310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289794759856357377",
  "text" : "RT @Tomthunkit: Congress is like a man telling his wife she has to cut $ on food, CC Bills, kids because HE lost the money gambling.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289792659768369153",
    "text" : "Congress is like a man telling his wife she has to cut $ on food, CC Bills, kids because HE lost the money gambling.",
    "id" : 289792659768369153,
    "created_at" : "2013-01-11 17:55:28 +0000",
    "user" : {
      "name" : "Tomthunkit\u2122",
      "screen_name" : "TomthunkitsMind",
      "protected" : false,
      "id_str" : "289118612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720292487898783746\/B736BdgO_normal.jpg",
      "id" : 289118612,
      "verified" : false
    }
  },
  "id" : 289794759856357377,
  "created_at" : "2013-01-11 18:03:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lissa Rankin, MD",
      "screen_name" : "Lissarankin",
      "indices" : [ 3, 15 ],
      "id_str" : "25393674",
      "id" : 25393674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/nR5VsaYT",
      "expanded_url" : "http:\/\/ow.ly\/gIwaN",
      "display_url" : "ow.ly\/gIwaN"
    } ]
  },
  "geo" : { },
  "id_str" : "289793928062959616",
  "text" : "RT @Lissarankin: Warning: reading this blog post may cause miracles http:\/\/t.co\/nR5VsaYT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/nR5VsaYT",
        "expanded_url" : "http:\/\/ow.ly\/gIwaN",
        "display_url" : "ow.ly\/gIwaN"
      } ]
    },
    "geo" : { },
    "id_str" : "289558945331302400",
    "text" : "Warning: reading this blog post may cause miracles http:\/\/t.co\/nR5VsaYT",
    "id" : 289558945331302400,
    "created_at" : "2013-01-11 02:26:46 +0000",
    "user" : {
      "name" : "Lissa Rankin, MD",
      "screen_name" : "Lissarankin",
      "protected" : false,
      "id_str" : "25393674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3057523939\/b3aea1e848dd07610a24ce145cba96af_normal.jpeg",
      "id" : 25393674,
      "verified" : false
    }
  },
  "id" : 289793928062959616,
  "created_at" : "2013-01-11 18:00:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "indices" : [ 0, 10 ],
      "id_str" : "126764612",
      "id" : 126764612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289786986963795968",
  "geo" : { },
  "id_str" : "289788982118731776",
  "in_reply_to_user_id" : 126764612,
  "text" : "@RuffHaven lol",
  "id" : 289788982118731776,
  "in_reply_to_status_id" : 289786986963795968,
  "created_at" : "2013-01-11 17:40:52 +0000",
  "in_reply_to_screen_name" : "RuffHaven",
  "in_reply_to_user_id_str" : "126764612",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "networks",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289788748022042624",
  "text" : "RT @bend_time: flu outbreak- MSM tries to make it sound epidemic. like they did swine &amp; bird flu. hey #networks who cry wolf: i dont ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "networks",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289788143278882817",
    "text" : "flu outbreak- MSM tries to make it sound epidemic. like they did swine &amp; bird flu. hey #networks who cry wolf: i dont believe u anymore",
    "id" : 289788143278882817,
    "created_at" : "2013-01-11 17:37:32 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 289788748022042624,
  "created_at" : "2013-01-11 17:39:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((TheRReport)))",
      "screen_name" : "TheRReport",
      "indices" : [ 3, 14 ],
      "id_str" : "183876837",
      "id" : 183876837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/jx6OyzDO",
      "expanded_url" : "http:\/\/huff.to\/WxOSVY",
      "display_url" : "huff.to\/WxOSVY"
    } ]
  },
  "geo" : { },
  "id_str" : "289785740362125312",
  "text" : "RT @TheRReport: Cory Booker signs papers for Senate run  http:\/\/t.co\/jx6OyzDO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/jx6OyzDO",
        "expanded_url" : "http:\/\/huff.to\/WxOSVY",
        "display_url" : "huff.to\/WxOSVY"
      } ]
    },
    "geo" : { },
    "id_str" : "289785327097348097",
    "text" : "Cory Booker signs papers for Senate run  http:\/\/t.co\/jx6OyzDO",
    "id" : 289785327097348097,
    "created_at" : "2013-01-11 17:26:20 +0000",
    "user" : {
      "name" : "(((TheRReport)))",
      "screen_name" : "TheRReport",
      "protected" : false,
      "id_str" : "183876837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1395131930\/Blue_R_normal.jpg",
      "id" : 183876837,
      "verified" : false
    }
  },
  "id" : 289785740362125312,
  "created_at" : "2013-01-11 17:27:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "indices" : [ 7, 12 ],
      "id_str" : "355689205",
      "id" : 355689205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 40, 50 ]
    }, {
      "text" : "myeyesaresograteful",
      "indices" : [ 51, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289785647915487232",
  "text" : "i love @EInk .. it's a beautiful thing! #justsayin #myeyesaresograteful",
  "id" : 289785647915487232,
  "created_at" : "2013-01-11 17:27:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289751779137167360",
  "text" : "almost had meltdown watching Alaska State Troopers. 2 orphaned moose were going to be shot (sanctuaries full.) their pitiful baby cries!",
  "id" : 289751779137167360,
  "created_at" : "2013-01-11 15:13:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Lori",
      "screen_name" : "TheResident",
      "indices" : [ 28, 40 ],
      "id_str" : "16380690",
      "id" : 16380690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289749667565146114",
  "text" : "RT @CharlesBivona: Word. RT @theresident: I lost a 3-day job recently because the client deemed me too anti-corporate. My reaction: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lori",
        "screen_name" : "TheResident",
        "indices" : [ 9, 21 ],
        "id_str" : "16380690",
        "id" : 16380690
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ff",
        "indices" : [ 134, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/bGyT8bl9",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ufNLd9y4Nrk",
        "display_url" : "youtube.com\/watch?v=ufNLd9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289748044465971200",
    "text" : "Word. RT @theresident: I lost a 3-day job recently because the client deemed me too anti-corporate. My reaction: http:\/\/t.co\/bGyT8bl9 #ff",
    "id" : 289748044465971200,
    "created_at" : "2013-01-11 14:58:11 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 289749667565146114,
  "created_at" : "2013-01-11 15:04:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289547429785767936",
  "text" : "RT @CaroleODell: Did you count your blessings today or did you grumble about stuff all day?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289530892077129728",
    "text" : "Did you count your blessings today or did you grumble about stuff all day?",
    "id" : 289530892077129728,
    "created_at" : "2013-01-11 00:35:18 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 289547429785767936,
  "created_at" : "2013-01-11 01:41:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Desiring God",
      "screen_name" : "desiringGod",
      "indices" : [ 46, 58 ],
      "id_str" : "15890094",
      "id" : 15890094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289545502171738112",
  "text" : "RT @AnnotatedBible: This doesn't make sense: \u201C@desiringgod: John Piper: \"Good deeds do not pay back grace; they borrow more grace.\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Desiring God",
        "screen_name" : "desiringGod",
        "indices" : [ 26, 38 ],
        "id_str" : "15890094",
        "id" : 15890094
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289540586380337153",
    "text" : "This doesn't make sense: \u201C@desiringgod: John Piper: \"Good deeds do not pay back grace; they borrow more grace.\".",
    "id" : 289540586380337153,
    "created_at" : "2013-01-11 01:13:49 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 289545502171738112,
  "created_at" : "2013-01-11 01:33:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 3, 18 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289523473812946944",
  "text" : "RT @TheAtheistFool: Just think, if Jesus had been carrying, then we would never have had that nasty crucifixion business. #atheist #GunN ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheist",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "GunNutLogic",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289513399317045248",
    "text" : "Just think, if Jesus had been carrying, then we would never have had that nasty crucifixion business. #atheist #GunNutLogic",
    "id" : 289513399317045248,
    "created_at" : "2013-01-10 23:25:47 +0000",
    "user" : {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "protected" : false,
      "id_str" : "550304910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2363295063\/image_normal.jpg",
      "id" : 550304910,
      "verified" : false
    }
  },
  "id" : 289523473812946944,
  "created_at" : "2013-01-11 00:05:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289513751344979968",
  "geo" : { },
  "id_str" : "289523337468706816",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits on the news tonight, newsman says \"do the right thing, get your flu shot.\" o-O ugh.",
  "id" : 289523337468706816,
  "in_reply_to_status_id" : 289513751344979968,
  "created_at" : "2013-01-11 00:05:17 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 3, 10 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/UepvYu90",
      "expanded_url" : "http:\/\/americablog.com\/2013\/01\/tn-gun-ceo-says-hell-start-killing-people-if-obama-restricts-guns.html",
      "display_url" : "americablog.com\/2013\/01\/tn-gun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289502970754772993",
  "text" : "RT @moosep: I hope the Secret Service sees this nut job! http:\/\/t.co\/UepvYu90",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/UepvYu90",
        "expanded_url" : "http:\/\/americablog.com\/2013\/01\/tn-gun-ceo-says-hell-start-killing-people-if-obama-restricts-guns.html",
        "display_url" : "americablog.com\/2013\/01\/tn-gun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289501942084952065",
    "text" : "I hope the Secret Service sees this nut job! http:\/\/t.co\/UepvYu90",
    "id" : 289501942084952065,
    "created_at" : "2013-01-10 22:40:16 +0000",
    "user" : {
      "name" : "moosep",
      "screen_name" : "moosep",
      "protected" : false,
      "id_str" : "13118692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635466686485954560\/I2iA_q6N_normal.jpg",
      "id" : 13118692,
      "verified" : false
    }
  },
  "id" : 289502970754772993,
  "created_at" : "2013-01-10 22:44:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 3, 14 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289500196621144064",
  "text" : "RT @shanecrash: I heard that a major bro-core Christian band declared that there's no such thing as a gay Christian. This is simply untrue.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289500030136623104",
    "text" : "I heard that a major bro-core Christian band declared that there's no such thing as a gay Christian. This is simply untrue.",
    "id" : 289500030136623104,
    "created_at" : "2013-01-10 22:32:40 +0000",
    "user" : {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "protected" : true,
      "id_str" : "25030624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710589208352522240\/fhf4iV5M_normal.jpg",
      "id" : 25030624,
      "verified" : false
    }
  },
  "id" : 289500196621144064,
  "created_at" : "2013-01-10 22:33:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289494250620588032",
  "geo" : { },
  "id_str" : "289496796772827136",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste he has a platform becuz ppl give him attention which assumes validity... did u see barton's \"hate is a virtue\" article?",
  "id" : 289496796772827136,
  "in_reply_to_status_id" : 289494250620588032,
  "created_at" : "2013-01-10 22:19:49 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/t95a9lnf",
      "expanded_url" : "http:\/\/Audible.com",
      "display_url" : "Audible.com"
    }, {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/t95a9lnf",
      "expanded_url" : "http:\/\/Audible.com",
      "display_url" : "Audible.com"
    } ]
  },
  "geo" : { },
  "id_str" : "289390084300619778",
  "text" : "RT @bookwiseblog: http:\/\/t.co\/t95a9lnf 3 for 2 Sale: http:\/\/t.co\/t95a9lnf is having a Buy 3 for 2 Credits Sale. \u00A0There are over 200 ...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/t95a9lnf",
        "expanded_url" : "http:\/\/Audible.com",
        "display_url" : "Audible.com"
      }, {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/t95a9lnf",
        "expanded_url" : "http:\/\/Audible.com",
        "display_url" : "Audible.com"
      }, {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/MlR8wMdA",
        "expanded_url" : "http:\/\/bit.ly\/VLtJsK",
        "display_url" : "bit.ly\/VLtJsK"
      } ]
    },
    "geo" : { },
    "id_str" : "289389086802849792",
    "text" : "http:\/\/t.co\/t95a9lnf 3 for 2 Sale: http:\/\/t.co\/t95a9lnf is having a Buy 3 for 2 Credits Sale. \u00A0There are over 200 ... http:\/\/t.co\/MlR8wMdA",
    "id" : 289389086802849792,
    "created_at" : "2013-01-10 15:11:49 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 289390084300619778,
  "created_at" : "2013-01-10 15:15:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289384356340973568",
  "text" : "RT @CoyoteSings: If the United States is going to be the Keeper of the Free World, shouldn't we start with our own country first? #justw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "justwondering",
        "indices" : [ 113, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289383749483917312",
    "text" : "If the United States is going to be the Keeper of the Free World, shouldn't we start with our own country first? #justwondering...",
    "id" : 289383749483917312,
    "created_at" : "2013-01-10 14:50:37 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 289384356340973568,
  "created_at" : "2013-01-10 14:53:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289383530000183296",
  "text" : "RT @derekrootboy: There is no democracy when the mass media is run by rich parasites who engage in criminality on an industrial scale, b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NOTW",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289380179363639296",
    "text" : "There is no democracy when the mass media is run by rich parasites who engage in criminality on an industrial scale, bribing cops etc. #NOTW",
    "id" : 289380179363639296,
    "created_at" : "2013-01-10 14:36:25 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 289383530000183296,
  "created_at" : "2013-01-10 14:49:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289202376974422016",
  "text" : "RT @adamrshields: Kindle Touch Gets New Software Upgrade (5.3.2) - Lots of the software perks of the paperwhite (reading time, controls) ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/cIZcqTC8",
        "expanded_url" : "http:\/\/bookwi.se\/kindle-touch-gets-new-software-upgrade\/",
        "display_url" : "bookwi.se\/kindle-touch-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289199404391489536",
    "text" : "Kindle Touch Gets New Software Upgrade (5.3.2) - Lots of the software perks of the paperwhite (reading time, controls) http:\/\/t.co\/cIZcqTC8",
    "id" : 289199404391489536,
    "created_at" : "2013-01-10 02:38:05 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 289202376974422016,
  "created_at" : "2013-01-10 02:49:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cystinosis",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/WzZYgJE8",
      "expanded_url" : "http:\/\/www.natalieswish.org\/About-Cystinosis",
      "display_url" : "natalieswish.org\/About-Cystinos\u2026"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/WzZYgJE8",
      "expanded_url" : "http:\/\/www.natalieswish.org\/About-Cystinosis",
      "display_url" : "natalieswish.org\/About-Cystinos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289184722339381250",
  "text" : "RT @Matth3ous: For those interested, and to maybe find out more about it: http:\/\/t.co\/WzZYgJE8 #cystinosis http:\/\/t.co\/WzZYgJE8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cystinosis",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/WzZYgJE8",
        "expanded_url" : "http:\/\/www.natalieswish.org\/About-Cystinosis",
        "display_url" : "natalieswish.org\/About-Cystinos\u2026"
      }, {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/WzZYgJE8",
        "expanded_url" : "http:\/\/www.natalieswish.org\/About-Cystinosis",
        "display_url" : "natalieswish.org\/About-Cystinos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289174472337022976",
    "text" : "For those interested, and to maybe find out more about it: http:\/\/t.co\/WzZYgJE8 #cystinosis http:\/\/t.co\/WzZYgJE8",
    "id" : 289174472337022976,
    "created_at" : "2013-01-10 00:59:01 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 289184722339381250,
  "created_at" : "2013-01-10 01:39:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cystinosis",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289184025816469504",
  "text" : "RT @Matth3ous: I wish I could live a normal life. Damn #cystinosis.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cystinosis",
        "indices" : [ 40, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288722204462559232",
    "text" : "I wish I could live a normal life. Damn #cystinosis.",
    "id" : 288722204462559232,
    "created_at" : "2013-01-08 19:01:52 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 289184025816469504,
  "created_at" : "2013-01-10 01:36:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 16, 25 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 82, 95 ]
    }, {
      "text" : "nature",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/EpdFfv5n",
      "expanded_url" : "http:\/\/ow.ly\/gBDty",
      "display_url" : "ow.ly\/gBDty"
    } ]
  },
  "in_reply_to_status_id_str" : "289178561284276224",
  "geo" : { },
  "id_str" : "289181147118845952",
  "in_reply_to_user_id" : 12088232,
  "text" : "so precious! RT @KerriFar Sharing with a Nuthatch ~ http:\/\/t.co\/EpdFfv5n ~ #birds #birdwatching #nature",
  "id" : 289181147118845952,
  "in_reply_to_status_id" : 289178561284276224,
  "created_at" : "2013-01-10 01:25:32 +0000",
  "in_reply_to_screen_name" : "KerriFar",
  "in_reply_to_user_id_str" : "12088232",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289142451329982464",
  "text" : "@1stCitizenKane creepy...",
  "id" : 289142451329982464,
  "created_at" : "2013-01-09 22:51:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289132113217863680",
  "text" : "@ryanholt94 my DD loves pewdiepie..lol.. watches his vids all the time!",
  "id" : 289132113217863680,
  "created_at" : "2013-01-09 22:10:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "indices" : [ 3, 8 ],
      "id_str" : "355689205",
      "id" : 355689205
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EInk\/status\/289128530653089792\/photo\/1",
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/kptpfVxq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAMw3eSCEAAvoKn.jpg",
      "id_str" : "289128530661478400",
      "id" : 289128530661478400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAMw3eSCEAAvoKn.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kptpfVxq"
    } ],
    "hashtags" : [ {
      "text" : "2013CES",
      "indices" : [ 67, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289131407387799552",
  "text" : "RT @EInk: Here's the dual screen LCD and E Ink smartphone by Yota. #2013CES http:\/\/t.co\/kptpfVxq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EInk\/status\/289128530653089792\/photo\/1",
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/kptpfVxq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAMw3eSCEAAvoKn.jpg",
        "id_str" : "289128530661478400",
        "id" : 289128530661478400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAMw3eSCEAAvoKn.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kptpfVxq"
      } ],
      "hashtags" : [ {
        "text" : "2013CES",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289128530653089792",
    "text" : "Here's the dual screen LCD and E Ink smartphone by Yota. #2013CES http:\/\/t.co\/kptpfVxq",
    "id" : 289128530653089792,
    "created_at" : "2013-01-09 21:56:28 +0000",
    "user" : {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "protected" : false,
      "id_str" : "355689205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1909407234\/twitter_prof_icon_normal.png",
      "id" : 355689205,
      "verified" : false
    }
  },
  "id" : 289131407387799552,
  "created_at" : "2013-01-09 22:07:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin O'Branagan",
      "screen_name" : "DevinWrites",
      "indices" : [ 3, 15 ],
      "id_str" : "144594430",
      "id" : 144594430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/GAf7CwqU",
      "expanded_url" : "http:\/\/www.devinwrites.com\/bookgiveaways.html",
      "display_url" : "devinwrites.com\/bookgiveaways.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289095922963578880",
  "text" : "RT @DevinWrites: Every month I give away one free book of mine. Please follow this link to enter the drawing: http:\/\/t.co\/GAf7CwqU  And  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/GAf7CwqU",
        "expanded_url" : "http:\/\/www.devinwrites.com\/bookgiveaways.html",
        "display_url" : "devinwrites.com\/bookgiveaways.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289095506553094144",
    "text" : "Every month I give away one free book of mine. Please follow this link to enter the drawing: http:\/\/t.co\/GAf7CwqU  And please RT! Thanks!!",
    "id" : 289095506553094144,
    "created_at" : "2013-01-09 19:45:14 +0000",
    "user" : {
      "name" : "Devin O'Branagan",
      "screen_name" : "DevinWrites",
      "protected" : false,
      "id_str" : "144594430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1378309658\/Devin_photo_80_percent_normal.jpg",
      "id" : 144594430,
      "verified" : false
    }
  },
  "id" : 289095922963578880,
  "created_at" : "2013-01-09 19:46:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stacey Chapman",
      "screen_name" : "_StaceyChapman",
      "indices" : [ 3, 18 ],
      "id_str" : "30480699",
      "id" : 30480699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289090531630383105",
  "text" : "RT @_StaceyChapman: Sometimes we need to be silent to hear the answer. #2013",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289080673539616768",
    "text" : "Sometimes we need to be silent to hear the answer. #2013",
    "id" : 289080673539616768,
    "created_at" : "2013-01-09 18:46:18 +0000",
    "user" : {
      "name" : "Stacey Chapman",
      "screen_name" : "_StaceyChapman",
      "protected" : false,
      "id_str" : "30480699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675316603412725761\/IvWwwbZI_normal.jpg",
      "id" : 30480699,
      "verified" : false
    }
  },
  "id" : 289090531630383105,
  "created_at" : "2013-01-09 19:25:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289086926961659904",
  "geo" : { },
  "id_str" : "289089432450121728",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 awww!",
  "id" : 289089432450121728,
  "in_reply_to_status_id" : 289086926961659904,
  "created_at" : "2013-01-09 19:21:06 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/Tb4OVE3B",
      "expanded_url" : "http:\/\/www.rightwingwatch.org\/content\/barton-hate-virtue-and-were-going-be-intolerant-liberalism",
      "display_url" : "rightwingwatch.org\/content\/barton\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289086637823123457",
  "text" : "hate is a good thing? lol &gt;&gt; Barton: 'Hate is a Virtue' http:\/\/t.co\/Tb4OVE3B",
  "id" : 289086637823123457,
  "created_at" : "2013-01-09 19:10:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289074527131025408",
  "geo" : { },
  "id_str" : "289084756463865857",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie Nice! ; )",
  "id" : 289084756463865857,
  "in_reply_to_status_id" : 289074527131025408,
  "created_at" : "2013-01-09 19:02:31 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289078812900225024",
  "geo" : { },
  "id_str" : "289081699059499008",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 ugh : (",
  "id" : 289081699059499008,
  "in_reply_to_status_id" : 289078812900225024,
  "created_at" : "2013-01-09 18:50:22 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "289045743447203841",
  "geo" : { },
  "id_str" : "289047211663314944",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous yuck. hope you get back to better soon! ((hugs))",
  "id" : 289047211663314944,
  "in_reply_to_status_id" : 289045743447203841,
  "created_at" : "2013-01-09 16:33:20 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 72, 85 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289035414902288385",
  "text" : "I just bought: 'Angelfall (Penryn and the End of Days)' by Susan Ee via @amazonkindle - currently FREE",
  "id" : 289035414902288385,
  "created_at" : "2013-01-09 15:46:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DarkFuse",
      "screen_name" : "darkfuse",
      "indices" : [ 3, 12 ],
      "id_str" : "67377922",
      "id" : 67377922
    }, {
      "name" : "Nicole Cushing",
      "screen_name" : "NicoleCushing",
      "indices" : [ 52, 66 ],
      "id_str" : "102832057",
      "id" : 102832057
    }, {
      "name" : "NetGalley",
      "screen_name" : "NetGalley",
      "indices" : [ 95, 105 ],
      "id_str" : "55257327",
      "id" : 55257327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/aBaTcJ6V",
      "expanded_url" : "http:\/\/bit.ly\/WLbuT8",
      "display_url" : "bit.ly\/WLbuT8"
    } ]
  },
  "geo" : { },
  "id_str" : "288826502534004736",
  "text" : "RT @darkfuse: Book Reviewers: Children of No One by @NicoleCushing is available for request at @NetGalley http:\/\/t.co\/aBaTcJ6V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicole Cushing",
        "screen_name" : "NicoleCushing",
        "indices" : [ 38, 52 ],
        "id_str" : "102832057",
        "id" : 102832057
      }, {
        "name" : "NetGalley",
        "screen_name" : "NetGalley",
        "indices" : [ 81, 91 ],
        "id_str" : "55257327",
        "id" : 55257327
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/aBaTcJ6V",
        "expanded_url" : "http:\/\/bit.ly\/WLbuT8",
        "display_url" : "bit.ly\/WLbuT8"
      } ]
    },
    "geo" : { },
    "id_str" : "288825942774804480",
    "text" : "Book Reviewers: Children of No One by @NicoleCushing is available for request at @NetGalley http:\/\/t.co\/aBaTcJ6V",
    "id" : 288825942774804480,
    "created_at" : "2013-01-09 01:54:05 +0000",
    "user" : {
      "name" : "DarkFuse",
      "screen_name" : "darkfuse",
      "protected" : false,
      "id_str" : "67377922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459500647071502337\/_e2rmU9Y_normal.jpeg",
      "id" : 67377922,
      "verified" : false
    }
  },
  "id" : 288826502534004736,
  "created_at" : "2013-01-09 01:56:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/t2go5z36",
      "expanded_url" : "http:\/\/bookwi.se\/workaround-or-solutions-to-the-top-10-problems-with-the-kindle-fire\/",
      "display_url" : "bookwi.se\/workaround-or-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288798802314403840",
  "text" : "Workaround or Solutions to the top 10 Problems with t\u2026 http:\/\/t.co\/t2go5z36 #kindlefire",
  "id" : 288798802314403840,
  "created_at" : "2013-01-09 00:06:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Key Biscayne",
      "screen_name" : "keybiscayne",
      "indices" : [ 18, 30 ],
      "id_str" : "28193775",
      "id" : 28193775
    }, {
      "name" : "GlobalGrasshopper",
      "screen_name" : "globalgrasshopr",
      "indices" : [ 66, 82 ],
      "id_str" : "83370426",
      "id" : 83370426
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keybiscayne\/status\/288791595782926337\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/to73S0rq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAH-bSECcAADP5B.jpg",
      "id_str" : "288791595787120640",
      "id" : 288791595787120640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAH-bSECcAADP5B.jpg",
      "sizes" : [ {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/to73S0rq"
    } ],
    "hashtags" : [ {
      "text" : "sunset",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "Florida",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288792631507550208",
  "text" : "RT @CaroleODell: \"@keybiscayne: Goodnight, Sun... #sunset -pic by @globalgrasshopr http:\/\/t.co\/to73S0rq\" Wow. #Florida",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Key Biscayne",
        "screen_name" : "keybiscayne",
        "indices" : [ 1, 13 ],
        "id_str" : "28193775",
        "id" : 28193775
      }, {
        "name" : "GlobalGrasshopper",
        "screen_name" : "globalgrasshopr",
        "indices" : [ 49, 65 ],
        "id_str" : "83370426",
        "id" : 83370426
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/keybiscayne\/status\/288791595782926337\/photo\/1",
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/to73S0rq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAH-bSECcAADP5B.jpg",
        "id_str" : "288791595787120640",
        "id" : 288791595787120640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAH-bSECcAADP5B.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/to73S0rq"
      } ],
      "hashtags" : [ {
        "text" : "sunset",
        "indices" : [ 33, 40 ]
      }, {
        "text" : "Florida",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288792279961985024",
    "text" : "\"@keybiscayne: Goodnight, Sun... #sunset -pic by @globalgrasshopr http:\/\/t.co\/to73S0rq\" Wow. #Florida",
    "id" : 288792279961985024,
    "created_at" : "2013-01-08 23:40:19 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 288792631507550208,
  "created_at" : "2013-01-08 23:41:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Average Joe",
      "screen_name" : "MNRags",
      "indices" : [ 3, 10 ],
      "id_str" : "347989923",
      "id" : 347989923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "APCallBlake",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288785417317265408",
  "text" : "RT @MNRags: Good Guy Adrian Peterson- A group of friends started the Twitter hashtag #APCallBlake in an effort to have Adrian... http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "APCallBlake",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/LISe13KI",
        "expanded_url" : "http:\/\/fb.me\/1ewb6pFgD",
        "display_url" : "fb.me\/1ewb6pFgD"
      } ]
    },
    "geo" : { },
    "id_str" : "288771005227356160",
    "text" : "Good Guy Adrian Peterson- A group of friends started the Twitter hashtag #APCallBlake in an effort to have Adrian... http:\/\/t.co\/LISe13KI",
    "id" : 288771005227356160,
    "created_at" : "2013-01-08 22:15:47 +0000",
    "user" : {
      "name" : "Average Joe",
      "screen_name" : "MNRags",
      "protected" : false,
      "id_str" : "347989923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1476282806\/187722_100001432202751_7190641_n_normal.jpg",
      "id" : 347989923,
      "verified" : false
    }
  },
  "id" : 288785417317265408,
  "created_at" : "2013-01-08 23:13:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288783805085544448",
  "text" : "OMG.. person rejected my game invite! : (",
  "id" : 288783805085544448,
  "created_at" : "2013-01-08 23:06:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288781486109384704",
  "text" : "RT @Master_Synaps: We spend millions\/billions on unemployment and associated benefits, and to save money we cause more. Something doesn' ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "auspol",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288769753856749568",
    "text" : "We spend millions\/billions on unemployment and associated benefits, and to save money we cause more. Something doesn't add up. #auspol",
    "id" : 288769753856749568,
    "created_at" : "2013-01-08 22:10:49 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 288781486109384704,
  "created_at" : "2013-01-08 22:57:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    }, {
      "name" : "Jake",
      "screen_name" : "VitaminDatai",
      "indices" : [ 64, 77 ],
      "id_str" : "77880454",
      "id" : 77880454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288758743024402432",
  "geo" : { },
  "id_str" : "288763310961209344",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu DD has that one and just got Black 2 the other day @VitaminDatai",
  "id" : 288763310961209344,
  "in_reply_to_status_id" : 288758743024402432,
  "created_at" : "2013-01-08 21:45:12 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "116807098",
      "id" : 116807098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288762150267265025",
  "text" : "RT @_CabinGirl: Update from WRC: And patient #8900 is\u2026an American crow!: It is only appropriate that our 8900th patient o... http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WRCMN",
        "indices" : [ 130, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/bElk0dKW",
        "expanded_url" : "http:\/\/bit.ly\/WKg97W",
        "display_url" : "bit.ly\/WKg97W"
      } ]
    },
    "geo" : { },
    "id_str" : "288760236712525824",
    "text" : "Update from WRC: And patient #8900 is\u2026an American crow!: It is only appropriate that our 8900th patient o... http:\/\/t.co\/bElk0dKW #WRCMN",
    "id" : 288760236712525824,
    "created_at" : "2013-01-08 21:32:59 +0000",
    "user" : {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "protected" : false,
      "id_str" : "116807098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713963701\/me_and_fawnsm_normal.jpg",
      "id" : 116807098,
      "verified" : false
    }
  },
  "id" : 288762150267265025,
  "created_at" : "2013-01-08 21:40:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "indices" : [ 3, 11 ],
      "id_str" : "508402674",
      "id" : 508402674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/tto675nf",
      "expanded_url" : "http:\/\/livrada.tumblr.com\/post\/40029909895\/livradaforauthors",
      "display_url" : "livrada.tumblr.com\/post\/400299098\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288744030395830272",
  "text" : "RT @livrada: We\u2019re helping authors sell or give their e-books! Introducing our new author platform: http:\/\/t.co\/tto675nf #livradalovesau ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "livradalovesauthors",
        "indices" : [ 108, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/tto675nf",
        "expanded_url" : "http:\/\/livrada.tumblr.com\/post\/40029909895\/livradaforauthors",
        "display_url" : "livrada.tumblr.com\/post\/400299098\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288737677090639872",
    "text" : "We\u2019re helping authors sell or give their e-books! Introducing our new author platform: http:\/\/t.co\/tto675nf #livradalovesauthors",
    "id" : 288737677090639872,
    "created_at" : "2013-01-08 20:03:21 +0000",
    "user" : {
      "name" : "Livrada.com",
      "screen_name" : "livrada",
      "protected" : false,
      "id_str" : "508402674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580472619763400706\/oLAqo7Ph_normal.png",
      "id" : 508402674,
      "verified" : false
    }
  },
  "id" : 288744030395830272,
  "created_at" : "2013-01-08 20:28:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 61, 74 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288722463498567680",
  "text" : "I just bought: 'Identity (Eyes Wide Open)' by Ted Dekker via @amazonkindle - currently FREE!",
  "id" : 288722463498567680,
  "created_at" : "2013-01-08 19:02:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Forlorn Hope",
      "screen_name" : "forlornhope888",
      "indices" : [ 13, 28 ],
      "id_str" : "333745303",
      "id" : 333745303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288462781877997568",
  "geo" : { },
  "id_str" : "288464346273689600",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny @forlornhope888 compassion is God : )",
  "id" : 288464346273689600,
  "in_reply_to_status_id" : 288462781877997568,
  "created_at" : "2013-01-08 01:57:14 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "curve dust",
      "screen_name" : "seekerwisdom8",
      "indices" : [ 3, 17 ],
      "id_str" : "67054018",
      "id" : 67054018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/wQQOR7UH",
      "expanded_url" : "http:\/\/www.politicususa.com\/paul-ryan-justifies-screwing-sandy-victims-calling-flood-insurance-program-irresponsible.html",
      "display_url" : "politicususa.com\/paul-ryan-just\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "288461913451528194",
  "text" : "RT @seekerwisdom8: Paul Ryan Justifies Screwing Sandy Victims By Calling Flood Insurance Program Irresponsible http:\/\/t.co\/wQQOR7UH via  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PoliticusUSA",
        "screen_name" : "politicususa",
        "indices" : [ 117, 130 ],
        "id_str" : "14792049",
        "id" : 14792049
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/wQQOR7UH",
        "expanded_url" : "http:\/\/www.politicususa.com\/paul-ryan-justifies-screwing-sandy-victims-calling-flood-insurance-program-irresponsible.html",
        "display_url" : "politicususa.com\/paul-ryan-just\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "288455743047340032",
    "text" : "Paul Ryan Justifies Screwing Sandy Victims By Calling Flood Insurance Program Irresponsible http:\/\/t.co\/wQQOR7UH via @politicususa",
    "id" : 288455743047340032,
    "created_at" : "2013-01-08 01:23:03 +0000",
    "user" : {
      "name" : "carophi",
      "screen_name" : "caro_phill",
      "protected" : false,
      "id_str" : "564947096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799926134817308672\/aYSukjGd_normal.jpg",
      "id" : 564947096,
      "verified" : false
    }
  },
  "id" : 288461913451528194,
  "created_at" : "2013-01-08 01:47:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288459010531803139",
  "geo" : { },
  "id_str" : "288460718121033729",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny the gay agenda!! Run for your lives!!",
  "id" : 288460718121033729,
  "in_reply_to_status_id" : 288459010531803139,
  "created_at" : "2013-01-08 01:42:49 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288439478836682752",
  "geo" : { },
  "id_str" : "288442096241745922",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater ohhh.. so thats what it is! lol",
  "id" : 288442096241745922,
  "in_reply_to_status_id" : 288439478836682752,
  "created_at" : "2013-01-08 00:28:49 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/WV4FTIpt",
      "expanded_url" : "http:\/\/ebookne.ws\/XfIRQa",
      "display_url" : "ebookne.ws\/XfIRQa"
    } ]
  },
  "geo" : { },
  "id_str" : "288433943307497472",
  "text" : "RT @thDigitalReader: Shop for ebooks at the grocery store, with new txtr\/ReaderLink partnership \u2014 paidContent http:\/\/t.co\/WV4FTIpt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/WV4FTIpt",
        "expanded_url" : "http:\/\/ebookne.ws\/XfIRQa",
        "display_url" : "ebookne.ws\/XfIRQa"
      } ]
    },
    "geo" : { },
    "id_str" : "288427152746110976",
    "text" : "Shop for ebooks at the grocery store, with new txtr\/ReaderLink partnership \u2014 paidContent http:\/\/t.co\/WV4FTIpt",
    "id" : 288427152746110976,
    "created_at" : "2013-01-07 23:29:26 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 288433943307497472,
  "created_at" : "2013-01-07 23:56:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Ince",
      "screen_name" : "robinince",
      "indices" : [ 3, 13 ],
      "id_str" : "45341566",
      "id" : 45341566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288418100951523328",
  "text" : "RT @robinince: Some people say \"you're not living in the real world!\" What they mean is \"you're not living in the bitter,venal world I c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288411929171591168",
    "text" : "Some people say \"you're not living in the real world!\" What they mean is \"you're not living in the bitter,venal world I created in my head\"",
    "id" : 288411929171591168,
    "created_at" : "2013-01-07 22:28:57 +0000",
    "user" : {
      "name" : "Robin Ince",
      "screen_name" : "robinince",
      "protected" : false,
      "id_str" : "45341566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754696595988418560\/53pwcflj_normal.jpg",
      "id" : 45341566,
      "verified" : false
    }
  },
  "id" : 288418100951523328,
  "created_at" : "2013-01-07 22:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288404900688322560",
  "text" : "disappointed w the case by casecrown i got for my #kindlefire .. fits well but some skin came off tab when i popped fire in.",
  "id" : 288404900688322560,
  "created_at" : "2013-01-07 22:01:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 129, 140 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/ErrPXz7w",
      "expanded_url" : "http:\/\/bit.ly\/VtVKoG",
      "display_url" : "bit.ly\/VtVKoG"
    } ]
  },
  "geo" : { },
  "id_str" : "288403822773149696",
  "text" : "'Mama played it smart!' Honey Boo Boo's mother June reveals that her reality show earnings are held ... http:\/\/t.co\/ErrPXz7w via @MailOnline",
  "id" : 288403822773149696,
  "created_at" : "2013-01-07 21:56:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 77, 90 ],
      "id_str" : "84249568",
      "id" : 84249568
    }, {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 91, 104 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288323852432449537",
  "text" : "I just bought: 'The Philosophical Strangler (Joe's World)' by Eric Flint via @amazonkindle @bookwiseblog",
  "id" : 288323852432449537,
  "created_at" : "2013-01-07 16:38:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Dognition",
      "screen_name" : "Dognition",
      "indices" : [ 74, 84 ],
      "id_str" : "755886386",
      "id" : 755886386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mondaygiveaway",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288319198155915265",
  "text" : "RT @DuttonBooks: We'll be giving away advance copies of GENIUS OF DOGS by @Dognition today at 3pm EST. #Mondaygiveaway",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dognition",
        "screen_name" : "Dognition",
        "indices" : [ 57, 67 ],
        "id_str" : "755886386",
        "id" : 755886386
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mondaygiveaway",
        "indices" : [ 86, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288317941517254656",
    "text" : "We'll be giving away advance copies of GENIUS OF DOGS by @Dognition today at 3pm EST. #Mondaygiveaway",
    "id" : 288317941517254656,
    "created_at" : "2013-01-07 16:15:28 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 288319198155915265,
  "created_at" : "2013-01-07 16:20:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "indices" : [ 3, 17 ],
      "id_str" : "38596022",
      "id" : 38596022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288284128225402880",
  "text" : "RT @livingthepoem: First, love God. Then realize you are God. Next, love you. Finally, realize everyone is God; love all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288281702789443586",
    "text" : "First, love God. Then realize you are God. Next, love you. Finally, realize everyone is God; love all.",
    "id" : 288281702789443586,
    "created_at" : "2013-01-07 13:51:28 +0000",
    "user" : {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "protected" : false,
      "id_str" : "38596022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741293678854086656\/P_FDuZdJ_normal.jpg",
      "id" : 38596022,
      "verified" : false
    }
  },
  "id" : 288284128225402880,
  "created_at" : "2013-01-07 14:01:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebirds",
      "indices" : [ 29, 39 ]
    }, {
      "text" : "nature",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "photo",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "birds",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/WQnij6SE",
      "expanded_url" : "http:\/\/ow.ly\/gyYLz",
      "display_url" : "ow.ly\/gyYLz"
    } ]
  },
  "geo" : { },
  "id_str" : "288069766864859136",
  "text" : "RT @KerriFar: Triple Play! ~ #Bluebirds ~ http:\/\/t.co\/WQnij6SE  ~ #nature #photo #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebirds",
        "indices" : [ 15, 25 ]
      }, {
        "text" : "nature",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "photo",
        "indices" : [ 60, 66 ]
      }, {
        "text" : "birds",
        "indices" : [ 67, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/WQnij6SE",
        "expanded_url" : "http:\/\/ow.ly\/gyYLz",
        "display_url" : "ow.ly\/gyYLz"
      } ]
    },
    "geo" : { },
    "id_str" : "288068797871562752",
    "text" : "Triple Play! ~ #Bluebirds ~ http:\/\/t.co\/WQnij6SE  ~ #nature #photo #birds",
    "id" : 288068797871562752,
    "created_at" : "2013-01-06 23:45:28 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 288069766864859136,
  "created_at" : "2013-01-06 23:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288063159107993602",
  "geo" : { },
  "id_str" : "288067679460409346",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist awww.. poor baby.. lol",
  "id" : 288067679460409346,
  "in_reply_to_status_id" : 288063159107993602,
  "created_at" : "2013-01-06 23:41:01 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Joey",
      "screen_name" : "UnXiled",
      "indices" : [ 38, 46 ],
      "id_str" : "158869946",
      "id" : 158869946
    }, {
      "name" : "Anne Wheaton",
      "screen_name" : "AnneWheaton",
      "indices" : [ 47, 59 ],
      "id_str" : "341218443",
      "id" : 341218443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288046084876558336",
  "geo" : { },
  "id_str" : "288066012031631360",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 goofy is wonderful : ) @UnXiled @AnneWheaton",
  "id" : 288066012031631360,
  "in_reply_to_status_id" : 288046084876558336,
  "created_at" : "2013-01-06 23:34:23 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287960831201783808",
  "text" : "RT @bend_time: lets do a CONGRESSIONAL REALITY SHOW. put those ppl to work at low paying jobs. let em try to live on that- then watch th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287959451816833026",
    "text" : "lets do a CONGRESSIONAL REALITY SHOW. put those ppl to work at low paying jobs. let em try to live on that- then watch things change.",
    "id" : 287959451816833026,
    "created_at" : "2013-01-06 16:30:57 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 287960831201783808,
  "created_at" : "2013-01-06 16:36:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "indices" : [ 3, 16 ],
      "id_str" : "43298413",
      "id" : 43298413
    }, {
      "name" : "Josh Christie",
      "screen_name" : "jchristie",
      "indices" : [ 32, 42 ],
      "id_str" : "15186189",
      "id" : 15186189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287668102827741185",
  "text" : "RT @NathanDunbar: Hells yes. RT @jchristie: We all hate the movie covers of books, right? This is a thing we can agree on?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Christie",
        "screen_name" : "jchristie",
        "indices" : [ 14, 24 ],
        "id_str" : "15186189",
        "id" : 15186189
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287665664116797441",
    "text" : "Hells yes. RT @jchristie: We all hate the movie covers of books, right? This is a thing we can agree on?",
    "id" : 287665664116797441,
    "created_at" : "2013-01-05 21:03:33 +0000",
    "user" : {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "protected" : false,
      "id_str" : "43298413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683069342842503169\/t-eR15ya_normal.jpg",
      "id" : 43298413,
      "verified" : false
    }
  },
  "id" : 287668102827741185,
  "created_at" : "2013-01-05 21:13:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Cook",
      "screen_name" : "johalifax",
      "indices" : [ 3, 13 ],
      "id_str" : "61064326",
      "id" : 61064326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287644196859424768",
  "text" : "RT @johalifax: Our missing cat Crispin, in all his whiskery glory. Gone since Jan. 2nd. from Duncan St. 11 years old. Pls RT. http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/johalifax\/status\/287600592912801792\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/NWJtL38X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A_3DNyoCYAIk-BC.jpg",
        "id_str" : "287600592916996098",
        "id" : 287600592916996098,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_3DNyoCYAIk-BC.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/NWJtL38X"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287600592912801792",
    "text" : "Our missing cat Crispin, in all his whiskery glory. Gone since Jan. 2nd. from Duncan St. 11 years old. Pls RT. http:\/\/t.co\/NWJtL38X",
    "id" : 287600592912801792,
    "created_at" : "2013-01-05 16:44:59 +0000",
    "user" : {
      "name" : "Joanne Cook",
      "screen_name" : "johalifax",
      "protected" : false,
      "id_str" : "61064326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742912518847221760\/C_Ea_x5O_normal.jpg",
      "id" : 61064326,
      "verified" : false
    }
  },
  "id" : 287644196859424768,
  "created_at" : "2013-01-05 19:38:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287619491741986817",
  "geo" : { },
  "id_str" : "287621312027975681",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater is that really you?? you are adorable! : )",
  "id" : 287621312027975681,
  "in_reply_to_status_id" : 287619491741986817,
  "created_at" : "2013-01-05 18:07:19 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/73HFeuZJ",
      "expanded_url" : "http:\/\/amzn.to\/WZQCMT",
      "display_url" : "amzn.to\/WZQCMT"
    } ]
  },
  "geo" : { },
  "id_str" : "287398302717186048",
  "text" : "finished All Who Wander Are Lost (An Icarus Fell Novel) by Bruce Blake http:\/\/t.co\/73HFeuZJ",
  "id" : 287398302717186048,
  "created_at" : "2013-01-05 03:21:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 0, 12 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287352618202849280",
  "geo" : { },
  "id_str" : "287356627043110913",
  "in_reply_to_user_id" : 45674330,
  "text" : "@oceanshaman do you have a title? sounds interesting..",
  "id" : 287356627043110913,
  "in_reply_to_status_id" : 287352618202849280,
  "created_at" : "2013-01-05 00:35:33 +0000",
  "in_reply_to_screen_name" : "oceanshaman",
  "in_reply_to_user_id_str" : "45674330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287354937866874880",
  "geo" : { },
  "id_str" : "287356017300365312",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny lol",
  "id" : 287356017300365312,
  "in_reply_to_status_id" : 287354937866874880,
  "created_at" : "2013-01-05 00:33:07 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/Q9Du78Gn",
      "expanded_url" : "http:\/\/via.me\/-8iahotw",
      "display_url" : "via.me\/-8iahotw"
    } ]
  },
  "geo" : { },
  "id_str" : "287354617820508160",
  "text" : "Having a spot o' tea http:\/\/t.co\/Q9Du78Gn",
  "id" : 287354617820508160,
  "created_at" : "2013-01-05 00:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 40, 52 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/E0nE37xd",
      "expanded_url" : "http:\/\/www.twitlonger.com\/show\/kh87h3",
      "display_url" : "twitlonger.com\/show\/kh87h3"
    } ]
  },
  "in_reply_to_status_id_str" : "287343727532453889",
  "geo" : { },
  "id_str" : "287344956375461888",
  "in_reply_to_user_id" : 51880276,
  "text" : "i wonder what mine should say... lol RT @VirgoJohnny Attention all new followers, please read my disclaimer.... http:\/\/t.co\/E0nE37xd",
  "id" : 287344956375461888,
  "in_reply_to_status_id" : 287343727532453889,
  "created_at" : "2013-01-04 23:49:10 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287343727532453889",
  "geo" : { },
  "id_str" : "287344353905635328",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i love your disclaimer.. totally made me LOL ; )",
  "id" : 287344353905635328,
  "in_reply_to_status_id" : 287343727532453889,
  "created_at" : "2013-01-04 23:46:47 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "Eric Rumsey",
      "screen_name" : "EricRumsey",
      "indices" : [ 26, 37 ],
      "id_str" : "17898671",
      "id" : 17898671
    }, {
      "name" : "WBTV News",
      "screen_name" : "WBTV_News",
      "indices" : [ 115, 125 ],
      "id_str" : "16894445",
      "id" : 16894445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/S4phGMt2",
      "expanded_url" : "http:\/\/bit.ly\/WihFh5",
      "display_url" : "bit.ly\/WihFh5"
    } ]
  },
  "geo" : { },
  "id_str" : "287343665020555264",
  "text" : "RT @AlisynGayle: YAY! :) \u201C@ericrumsey: Obamacare to Cover Acupuncture, Alternative Medicine http:\/\/t.co\/S4phGMt2 - @WBTV_News MT @DrFerd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Rumsey",
        "screen_name" : "EricRumsey",
        "indices" : [ 9, 20 ],
        "id_str" : "17898671",
        "id" : 17898671
      }, {
        "name" : "WBTV News",
        "screen_name" : "WBTV_News",
        "indices" : [ 98, 108 ],
        "id_str" : "16894445",
        "id" : 16894445
      }, {
        "name" : "conciergedoc",
        "screen_name" : "DrFerdowsi",
        "indices" : [ 112, 123 ],
        "id_str" : "471143047",
        "id" : 471143047
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/S4phGMt2",
        "expanded_url" : "http:\/\/bit.ly\/WihFh5",
        "display_url" : "bit.ly\/WihFh5"
      } ]
    },
    "geo" : { },
    "id_str" : "287340040240123904",
    "text" : "YAY! :) \u201C@ericrumsey: Obamacare to Cover Acupuncture, Alternative Medicine http:\/\/t.co\/S4phGMt2 - @WBTV_News MT @DrFerdowsi\u201D",
    "id" : 287340040240123904,
    "created_at" : "2013-01-04 23:29:38 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 287343665020555264,
  "created_at" : "2013-01-04 23:44:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Rumsey",
      "screen_name" : "EricRumsey",
      "indices" : [ 3, 14 ],
      "id_str" : "17898671",
      "id" : 17898671
    }, {
      "name" : "WBTV News",
      "screen_name" : "WBTV_News",
      "indices" : [ 92, 102 ],
      "id_str" : "16894445",
      "id" : 16894445
    }, {
      "name" : "conciergedoc",
      "screen_name" : "DrFerdowsi",
      "indices" : [ 106, 117 ],
      "id_str" : "471143047",
      "id" : 471143047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/QqgMcQM3",
      "expanded_url" : "http:\/\/bit.ly\/WihFh5",
      "display_url" : "bit.ly\/WihFh5"
    } ]
  },
  "geo" : { },
  "id_str" : "287343502977818624",
  "text" : "RT @ericrumsey: Obamacare to Cover Acupuncture, Alternative Medicine http:\/\/t.co\/QqgMcQM3 - @WBTV_News MT @DrFerdowsi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WBTV News",
        "screen_name" : "WBTV_News",
        "indices" : [ 76, 86 ],
        "id_str" : "16894445",
        "id" : 16894445
      }, {
        "name" : "conciergedoc",
        "screen_name" : "DrFerdowsi",
        "indices" : [ 90, 101 ],
        "id_str" : "471143047",
        "id" : 471143047
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/QqgMcQM3",
        "expanded_url" : "http:\/\/bit.ly\/WihFh5",
        "display_url" : "bit.ly\/WihFh5"
      } ]
    },
    "geo" : { },
    "id_str" : "287306985928544256",
    "text" : "Obamacare to Cover Acupuncture, Alternative Medicine http:\/\/t.co\/QqgMcQM3 - @WBTV_News MT @DrFerdowsi",
    "id" : 287306985928544256,
    "created_at" : "2013-01-04 21:18:18 +0000",
    "user" : {
      "name" : "Eric Rumsey",
      "screen_name" : "EricRumsey",
      "protected" : false,
      "id_str" : "17898671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/66451356\/eric_118_gray_normal.JPG",
      "id" : 17898671,
      "verified" : false
    }
  },
  "id" : 287343502977818624,
  "created_at" : "2013-01-04 23:43:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "indices" : [ 3, 17 ],
      "id_str" : "241662602",
      "id" : 241662602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compassion",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287325986243088384",
  "text" : "RT @Master_Synaps: Punishing the unemployed, single parents, etc, does not create suitable employment. How about some #compassion in pol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compassion",
        "indices" : [ 99, 110 ]
      }, {
        "text" : "auspol",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287323865703657473",
    "text" : "Punishing the unemployed, single parents, etc, does not create suitable employment. How about some #compassion in policy? #auspol",
    "id" : 287323865703657473,
    "created_at" : "2013-01-04 22:25:22 +0000",
    "user" : {
      "name" : "Master-Synaps",
      "screen_name" : "Master_Synaps",
      "protected" : false,
      "id_str" : "241662602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3171863969\/db463120a282c9ce63e63c535f30f846_normal.jpeg",
      "id" : 241662602,
      "verified" : false
    }
  },
  "id" : 287325986243088384,
  "created_at" : "2013-01-04 22:33:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evil",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287324649296121856",
  "geo" : { },
  "id_str" : "287325630515793920",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem i left a good job becuz of corporate rules. couldnt handle it. #evil",
  "id" : 287325630515793920,
  "in_reply_to_status_id" : 287324649296121856,
  "created_at" : "2013-01-04 22:32:23 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "universe",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287319482165239808",
  "text" : "thanks to all my angels behind the scenes running around like demons getting my meds #gratitude #universe",
  "id" : 287319482165239808,
  "created_at" : "2013-01-04 22:07:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "onlinepharmacy",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/6OdsgYOe",
      "expanded_url" : "http:\/\/healthwarehouse.com",
      "display_url" : "healthwarehouse.com"
    } ]
  },
  "geo" : { },
  "id_str" : "287318574228439040",
  "text" : "...and my pills have shipped! Thank You http:\/\/t.co\/6OdsgYOe for your excellent service! : ) #effexor #onlinepharmacy",
  "id" : 287318574228439040,
  "created_at" : "2013-01-04 22:04:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Old Dog Haven",
      "screen_name" : "OldDogHaven",
      "indices" : [ 3, 15 ],
      "id_str" : "30454230",
      "id" : 30454230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287307470458724352",
  "text" : "RT @OldDogHaven: Rambo is an 11-year-old red Pharaoh Hound who has been an agility champion and his person's very best friend.   A... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/lW48XWQM",
        "expanded_url" : "http:\/\/fb.me\/1fm5IPbJc",
        "display_url" : "fb.me\/1fm5IPbJc"
      } ]
    },
    "geo" : { },
    "id_str" : "287305536205111296",
    "text" : "Rambo is an 11-year-old red Pharaoh Hound who has been an agility champion and his person's very best friend.   A... http:\/\/t.co\/lW48XWQM",
    "id" : 287305536205111296,
    "created_at" : "2013-01-04 21:12:32 +0000",
    "user" : {
      "name" : "Old Dog Haven",
      "screen_name" : "OldDogHaven",
      "protected" : false,
      "id_str" : "30454230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590689116565676033\/9ClwTfrJ_normal.png",
      "id" : 30454230,
      "verified" : false
    }
  },
  "id" : 287307470458724352,
  "created_at" : "2013-01-04 21:20:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Coultergeist",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287270299110604800",
  "text" : "RT @ZeitgeistGhost: #Coultergeist Loses It On Guns; Wants List Of Women Who Had Abortions So Mothers Know Who Would 'Murder a Child' htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Coultergeist",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/sbfQS56X",
        "expanded_url" : "http:\/\/huff.to\/UMSt6d",
        "display_url" : "huff.to\/UMSt6d"
      } ]
    },
    "geo" : { },
    "id_str" : "287263470494302208",
    "text" : "#Coultergeist Loses It On Guns; Wants List Of Women Who Had Abortions So Mothers Know Who Would 'Murder a Child' http:\/\/t.co\/sbfQS56X",
    "id" : 287263470494302208,
    "created_at" : "2013-01-04 18:25:23 +0000",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 287270299110604800,
  "created_at" : "2013-01-04 18:52:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/9V0tEIXq",
      "expanded_url" : "http:\/\/bookwi.se\/andrew-toy-thinks-you-need-to-read-more-fiction\/",
      "display_url" : "bookwi.se\/andrew-toy-thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287260345477763073",
  "text" : "RT @adamrshields: Andrew Toy Thinks You Need to Read More Fiction, and so do I -  http:\/\/t.co\/9V0tEIXq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/9V0tEIXq",
        "expanded_url" : "http:\/\/bookwi.se\/andrew-toy-thinks-you-need-to-read-more-fiction\/",
        "display_url" : "bookwi.se\/andrew-toy-thi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287255888073478145",
    "text" : "Andrew Toy Thinks You Need to Read More Fiction, and so do I -  http:\/\/t.co\/9V0tEIXq",
    "id" : 287255888073478145,
    "created_at" : "2013-01-04 17:55:15 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 287260345477763073,
  "created_at" : "2013-01-04 18:12:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/fykKVwyF",
      "expanded_url" : "http:\/\/www.theatlantic.com\/magazine\/archive\/2013\/01\/awakening\/309188\/#.UOYIDFAFKYc.twitter",
      "display_url" : "theatlantic.com\/magazine\/archi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286964507396415488",
  "text" : "Awakening - The Atlantic http:\/\/t.co\/fykKVwyF",
  "id" : 286964507396415488,
  "created_at" : "2013-01-03 22:37:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conspiracy Talk",
      "screen_name" : "WickChris",
      "indices" : [ 3, 13 ],
      "id_str" : "727403658",
      "id" : 727403658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286935199596548096",
  "text" : "RT @WickChris: \u201CWar on Drugs\u201D  \u201CWar on Terror\u201D  \u201CAGW\u201D \u201Cglobal warming\u201D \u201CFiscal Cliff\u201D It\u2019s one gigantic ponzi-scheme .",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286925129223639040",
    "text" : "\u201CWar on Drugs\u201D  \u201CWar on Terror\u201D  \u201CAGW\u201D \u201Cglobal warming\u201D \u201CFiscal Cliff\u201D It\u2019s one gigantic ponzi-scheme .",
    "id" : 286925129223639040,
    "created_at" : "2013-01-03 20:00:56 +0000",
    "user" : {
      "name" : "Conspiracy Talk",
      "screen_name" : "WickChris",
      "protected" : false,
      "id_str" : "727403658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653293055194345472\/yfIvhZG__normal.jpg",
      "id" : 727403658,
      "verified" : false
    }
  },
  "id" : 286935199596548096,
  "created_at" : "2013-01-03 20:40:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286898661940662272",
  "text" : "RT @TheGoldenMirror: Don't force your children to do what you were forced to do by your own parents. Allow them to break the chain that  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286897586810523649",
    "text" : "Don't force your children to do what you were forced to do by your own parents. Allow them to break the chain that shackles generations.",
    "id" : 286897586810523649,
    "created_at" : "2013-01-03 18:11:29 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 286898661940662272,
  "created_at" : "2013-01-03 18:15:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286897396946984960",
  "geo" : { },
  "id_str" : "286898449071362048",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny let's sit and have some cookies...",
  "id" : 286898449071362048,
  "in_reply_to_status_id" : 286897396946984960,
  "created_at" : "2013-01-03 18:14:55 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 82, 95 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/HY03Lldf",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B005MT8PQK\/ref=cm_sw_r_tw_ask_V.NtE.087G2F0",
      "display_url" : "amazon.com\/dp\/B005MT8PQK\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286871710182023169",
  "text" : "I just bought: 'Solitary: A Novel (Solitary Tales Series)' by Travis Thrasher via @amazonkindle http:\/\/t.co\/HY03Lldf",
  "id" : 286871710182023169,
  "created_at" : "2013-01-03 16:28:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewJersey",
      "indices" : [ 112, 122 ]
    }, {
      "text" : "njpoet",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "p2",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286864097541238784",
  "text" : "RT @CharlesBivona: Chris Christie held a 40 minute Press Conference to call John Boehner an asshole. WELCOME to #NewJersey. #njpoet #p2  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NewJersey",
        "indices" : [ 93, 103 ]
      }, {
        "text" : "njpoet",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "p2",
        "indices" : [ 113, 116 ]
      }, {
        "text" : "p21",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "p2b",
        "indices" : [ 122, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286856197959725056",
    "text" : "Chris Christie held a 40 minute Press Conference to call John Boehner an asshole. WELCOME to #NewJersey. #njpoet #p2 #p21 #p2b",
    "id" : 286856197959725056,
    "created_at" : "2013-01-03 15:27:01 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 286864097541238784,
  "created_at" : "2013-01-03 15:58:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286863199112945665",
  "text" : "HALLELUJAH!! DR finally faxed in my rx to healthwarehouse. thankyouthankyouthankyou",
  "id" : 286863199112945665,
  "created_at" : "2013-01-03 15:54:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/qmA39kN0",
      "expanded_url" : "http:\/\/LoveMyFire.com",
      "display_url" : "LoveMyFire.com"
    }, {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/j9DSo8Zo",
      "expanded_url" : "http:\/\/www.lovemyfire.com\/kindle-fire-giveaways.html",
      "display_url" : "lovemyfire.com\/kindle-fire-gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286813824986783744",
  "text" : "Win a $50 Amazon Gift Card! at http:\/\/t.co\/qmA39kN0 http:\/\/t.co\/j9DSo8Zo",
  "id" : 286813824986783744,
  "created_at" : "2013-01-03 12:38:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u043E\u0441\u043E\u0432 \u041D\u0438\u043A\u043E\u043B\u0430\u0439",
      "screen_name" : "allmysteryenews",
      "indices" : [ 3, 19 ],
      "id_str" : "4636186576",
      "id" : 4636186576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "constantcontact",
      "indices" : [ 47, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/IP3ltySA",
      "expanded_url" : "http:\/\/conta.cc\/VizL3T",
      "display_url" : "conta.cc\/VizL3T"
    } ]
  },
  "geo" : { },
  "id_str" : "286469475304341504",
  "text" : "RT @allmysteryenews: FREE e-books Today Only!  #constantcontact http:\/\/t.co\/IP3ltySA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.constantcontact.com\" rel=\"nofollow\"\u003EConstant Contact\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "constantcontact",
        "indices" : [ 26, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/IP3ltySA",
        "expanded_url" : "http:\/\/conta.cc\/VizL3T",
        "display_url" : "conta.cc\/VizL3T"
      } ]
    },
    "geo" : { },
    "id_str" : "286466266720522241",
    "text" : "FREE e-books Today Only!  #constantcontact http:\/\/t.co\/IP3ltySA",
    "id" : 286466266720522241,
    "created_at" : "2013-01-02 13:37:34 +0000",
    "user" : {
      "name" : "All Mystery news",
      "screen_name" : "allmysterynews",
      "protected" : false,
      "id_str" : "178117116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414092030\/logo_twitter_normal.jpg",
      "id" : 178117116,
      "verified" : false
    }
  },
  "id" : 286469475304341504,
  "created_at" : "2013-01-02 13:50:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 36, 50 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286204856140709888",
  "geo" : { },
  "id_str" : "286217098013839360",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny stalkstalkstalk .. lol @atheistlady76",
  "id" : 286217098013839360,
  "in_reply_to_status_id" : 286204856140709888,
  "created_at" : "2013-01-01 21:07:28 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286115304835260416",
  "text" : "GameStop apparently has a Fire upgrade special.. turn in old Fire for up to $100 credit on new Fire and get $25 amazon card.",
  "id" : 286115304835260416,
  "created_at" : "2013-01-01 14:22:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286114922339909633",
  "text" : "2) The Book of Not Knowing by Peter Ralston",
  "id" : 286114922339909633,
  "created_at" : "2013-01-01 14:21:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286114803892756482",
  "text" : "1) Journey to Self Realization V3 by P. Yogananda",
  "id" : 286114803892756482,
  "created_at" : "2013-01-01 14:20:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286114539479633920",
  "text" : "bought 2 books yesterday at B&amp;N...",
  "id" : 286114539479633920,
  "created_at" : "2013-01-01 14:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/eHklgjtW",
      "expanded_url" : "http:\/\/bookwi.se\/bookwi-se-stats-for-2012\/",
      "display_url" : "bookwi.se\/bookwi-se-stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286112489127702529",
  "text" : "Bookwi.se Stats for 2012 http:\/\/t.co\/eHklgjtW",
  "id" : 286112489127702529,
  "created_at" : "2013-01-01 14:11:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]