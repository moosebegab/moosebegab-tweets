Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362724326430089218",
  "text" : "didnt get my chocolate today. thought it would be cheaper at cvs. ridiculously expensive there. so.. no chocolate. bleh.",
  "id" : 362724326430089218,
  "created_at" : "2013-07-31 23:59:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/KSVl3UDv",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/6iK",
      "display_url" : "omgf.ac\/ts\/6iK"
    } ]
  },
  "geo" : { },
  "id_str" : "362718258064928768",
  "text" : "RT @OMGFacts: If we took all empty space between our atoms, the human race would be the size of a sugar cube! ---&gt; http:\/\/t.co\/KSVl3UDv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/KSVl3UDv",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/6iK",
        "display_url" : "omgf.ac\/ts\/6iK"
      } ]
    },
    "geo" : { },
    "id_str" : "362709647377301504",
    "text" : "If we took all empty space between our atoms, the human race would be the size of a sugar cube! ---&gt; http:\/\/t.co\/KSVl3UDv",
    "id" : 362709647377301504,
    "created_at" : "2013-07-31 23:01:33 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 362718258064928768,
  "created_at" : "2013-07-31 23:35:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362632797778743297",
  "geo" : { },
  "id_str" : "362716220178432001",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous yeah.. i understand you live w chronic illness. hopefully, it'll never come to that. : )",
  "id" : 362716220178432001,
  "in_reply_to_status_id" : 362632797778743297,
  "created_at" : "2013-07-31 23:27:40 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362571565205950464",
  "text" : "RT @Wolf_Mommy: Stranger rips headband off 2yo, cuffs him upside the head &amp; calls him a f*cking faggot.Ppl do nothing. http:\/\/t.co\/RviHywMv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/RviHywMvnA",
        "expanded_url" : "http:\/\/amotherthing.com\/2013\/07\/getting-political\/",
        "display_url" : "amotherthing.com\/2013\/07\/gettin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362561803626102784",
    "text" : "Stranger rips headband off 2yo, cuffs him upside the head &amp; calls him a f*cking faggot.Ppl do nothing. http:\/\/t.co\/RviHywMvnA",
    "id" : 362561803626102784,
    "created_at" : "2013-07-31 13:14:04 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 362571565205950464,
  "created_at" : "2013-07-31 13:52:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "indices" : [ 51, 67 ],
      "id_str" : "292671486",
      "id" : 292671486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362569779493605377",
  "text" : ". @FlyingFree333 so evil only comes through faith? @proudliberalmom",
  "id" : 362569779493605377,
  "created_at" : "2013-07-31 13:45:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/97yrwJaUcX",
      "expanded_url" : "http:\/\/amzn.to\/l2bqPY",
      "display_url" : "amzn.to\/l2bqPY"
    } ]
  },
  "geo" : { },
  "id_str" : "362406099648921600",
  "text" : "finished Chickens, Mules and Two Old Fools (Old Fool Series) by Victoria Twead and Victoria Twead http:\/\/t.co\/97yrwJaUcX",
  "id" : 362406099648921600,
  "created_at" : "2013-07-31 02:55:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/KKtzawXuk7",
      "expanded_url" : "http:\/\/www.amazon.com\/Peas-Beans-Sovereign-Series-ebook\/dp\/B00CS5X0DO\/ref=tmm_kin_title_0?ie=UTF8&qid=1375181266&sr=1-3",
      "display_url" : "amazon.com\/Peas-Beans-Sov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362377699618070529",
  "text" : "RT @ChickenJen: *** DAILY DEAL *** \"Peas, Beans &amp; Corn\" is only 99 cents on the Kindle! http:\/\/t.co\/KKtzawXuk7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/KKtzawXuk7",
        "expanded_url" : "http:\/\/www.amazon.com\/Peas-Beans-Sovereign-Series-ebook\/dp\/B00CS5X0DO\/ref=tmm_kin_title_0?ie=UTF8&qid=1375181266&sr=1-3",
        "display_url" : "amazon.com\/Peas-Beans-Sov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362377130425847808",
    "text" : "*** DAILY DEAL *** \"Peas, Beans &amp; Corn\" is only 99 cents on the Kindle! http:\/\/t.co\/KKtzawXuk7",
    "id" : 362377130425847808,
    "created_at" : "2013-07-31 01:00:15 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 362377699618070529,
  "created_at" : "2013-07-31 01:02:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362352250020044800",
  "geo" : { },
  "id_str" : "362358466565767168",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 i see... happiness. beautiful : )",
  "id" : 362358466565767168,
  "in_reply_to_status_id" : 362352250020044800,
  "created_at" : "2013-07-30 23:46:05 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 3, 14 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/haty0YbxiZ",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=429989370448013&set=a.259696874143931.56679.259686454144973&type=1&theater",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362342870830686210",
  "text" : "RT @Raven_Luni: Spain imposes a tax on collecting sunlight.  WHAT THE ACTUAL FUCK?!?!?!?!?!  https:\/\/t.co\/haty0YbxiZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/haty0YbxiZ",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=429989370448013&set=a.259696874143931.56679.259686454144973&type=1&theater",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362337621550178304",
    "text" : "Spain imposes a tax on collecting sunlight.  WHAT THE ACTUAL FUCK?!?!?!?!?!  https:\/\/t.co\/haty0YbxiZ",
    "id" : 362337621550178304,
    "created_at" : "2013-07-30 22:23:15 +0000",
    "user" : {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "protected" : false,
      "id_str" : "264530860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692897788099579905\/YoIQEAax_normal.jpg",
      "id" : 264530860,
      "verified" : false
    }
  },
  "id" : 362342870830686210,
  "created_at" : "2013-07-30 22:44:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362302266822234112",
  "geo" : { },
  "id_str" : "362302937566937090",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous yeah.. i wouldn't last long either. either kill myself from lack of #effexor or get eaten cuz I can't run at all.",
  "id" : 362302937566937090,
  "in_reply_to_status_id" : 362302266822234112,
  "created_at" : "2013-07-30 20:05:26 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362292705142902784",
  "geo" : { },
  "id_str" : "362293173457920002",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 eh.. this physical stuff is for the birds.",
  "id" : 362293173457920002,
  "in_reply_to_status_id" : 362292705142902784,
  "created_at" : "2013-07-30 19:26:38 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal4Obama",
      "screen_name" : "crtconsu",
      "indices" : [ 3, 12 ],
      "id_str" : "16843450",
      "id" : 16843450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362004584631246848",
  "text" : "RT @crtconsu: Bashir knocked this one out of the park. GZ crew is slandering a child that he killed. You won't see this one coming.\nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/iujHH3pNrn",
        "expanded_url" : "http:\/\/www.upworthy.com\/think-trayvons-record-said-something-about-his-character-well-get-a-load-of-this?g=2&c=utw1",
        "display_url" : "upworthy.com\/think-trayvons\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "361995365047742465",
    "text" : "Bashir knocked this one out of the park. GZ crew is slandering a child that he killed. You won't see this one coming.\nhttp:\/\/t.co\/iujHH3pNrn",
    "id" : 361995365047742465,
    "created_at" : "2013-07-29 23:43:15 +0000",
    "user" : {
      "name" : "Crystal4Obama",
      "screen_name" : "crtconsu",
      "protected" : false,
      "id_str" : "16843450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800347936051908612\/nns4O5Hj_normal.jpg",
      "id" : 16843450,
      "verified" : false
    }
  },
  "id" : 362004584631246848,
  "created_at" : "2013-07-30 00:19:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badday",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361997748444205056",
  "text" : "came home to dead bird in house earlier and also DD said friend had to euthanise her dog. #badday : (",
  "id" : 361997748444205056,
  "created_at" : "2013-07-29 23:52:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/9xefmSnArU",
      "expanded_url" : "http:\/\/www.wattpad.com\/20439708-sacred-cow-pastoral-message-about-the-food-we-eat#.UfZHo403uSo",
      "display_url" : "wattpad.com\/20439708-sacre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "361893496543657984",
  "text" : "RT @ChickenJen: read about my ethical wrestling with raising and killing my own meat http:\/\/t.co\/9xefmSnArU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/9xefmSnArU",
        "expanded_url" : "http:\/\/www.wattpad.com\/20439708-sacred-cow-pastoral-message-about-the-food-we-eat#.UfZHo403uSo",
        "display_url" : "wattpad.com\/20439708-sacre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "361882986641227776",
    "text" : "read about my ethical wrestling with raising and killing my own meat http:\/\/t.co\/9xefmSnArU",
    "id" : 361882986641227776,
    "created_at" : "2013-07-29 16:16:42 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 361893496543657984,
  "created_at" : "2013-07-29 16:58:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361864371628027904",
  "text" : "instagram doesn't like me. the app locks up after i take pic.",
  "id" : 361864371628027904,
  "created_at" : "2013-07-29 15:02:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361651962044887041",
  "text" : "i have issues. another existential crisis coming on? sigh.",
  "id" : 361651962044887041,
  "created_at" : "2013-07-29 00:58:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361620291622932480",
  "geo" : { },
  "id_str" : "361623459543003136",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni yup. only one ive been on. i hate being tied to it, tho. if im late, i tend to get sick like a hangover.",
  "id" : 361623459543003136,
  "in_reply_to_status_id" : 361620291622932480,
  "created_at" : "2013-07-28 23:05:26 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361619028873195521",
  "geo" : { },
  "id_str" : "361619834351517697",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni : ((( (effexor.. 15 years) (((hugs)))",
  "id" : 361619834351517697,
  "in_reply_to_status_id" : 361619028873195521,
  "created_at" : "2013-07-28 22:51:01 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/j4ZPRjxFoA",
      "expanded_url" : "http:\/\/wp.me\/p1VcTe-6it",
      "display_url" : "wp.me\/p1VcTe-6it"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WZpXCDItjc",
      "expanded_url" : "http:\/\/blog.press.princeton.edu\/2013\/07\/26\/win-a-copy-of-the-warbler-guide-and-a-pair-of-terra-ed-binoculars\/",
      "display_url" : "blog.press.princeton.edu\/2013\/07\/26\/win\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "361617486153658368",
  "text" : "Win a copy of The Warbler Guide &amp; a pair of Zeiss binoculars at @princetonnaturewebsite: http:\/\/t.co\/j4ZPRjxFoA http:\/\/t.co\/WZpXCDItjc",
  "id" : 361617486153658368,
  "created_at" : "2013-07-28 22:41:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Hidy",
      "screen_name" : "upyourtelesales",
      "indices" : [ 3, 19 ],
      "id_str" : "38639240",
      "id" : 38639240
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/upyourtelesales\/status\/361512602423152640\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/ohVE6E4229",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQRZy-mCUAAuSu7.jpg",
      "id_str" : "361512602427346944",
      "id" : 361512602427346944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQRZy-mCUAAuSu7.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ohVE6E4229"
    } ],
    "hashtags" : [ {
      "text" : "pressgram",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361533014519459841",
  "text" : "RT @upyourtelesales: Moose Mug #pressgram http:\/\/t.co\/ohVE6E4229",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pressgr.am\/\" rel=\"nofollow\"\u003EPressgram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/upyourtelesales\/status\/361512602423152640\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/ohVE6E4229",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQRZy-mCUAAuSu7.jpg",
        "id_str" : "361512602427346944",
        "id" : 361512602427346944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQRZy-mCUAAuSu7.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ohVE6E4229"
      } ],
      "hashtags" : [ {
        "text" : "pressgram",
        "indices" : [ 10, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "361512602423152640",
    "text" : "Moose Mug #pressgram http:\/\/t.co\/ohVE6E4229",
    "id" : 361512602423152640,
    "created_at" : "2013-07-28 15:44:55 +0000",
    "user" : {
      "name" : "Lynn Hidy",
      "screen_name" : "upyourtelesales",
      "protected" : false,
      "id_str" : "38639240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798956975186968577\/rn69xyr3_normal.jpg",
      "id" : 38639240,
      "verified" : false
    }
  },
  "id" : 361533014519459841,
  "created_at" : "2013-07-28 17:06:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/N8uFCs8Hqu",
      "expanded_url" : "http:\/\/amzn.to\/prdIl7",
      "display_url" : "amzn.to\/prdIl7"
    } ]
  },
  "geo" : { },
  "id_str" : "361328210098659328",
  "text" : "finished Demon: A Memoir by Tosca Lee http:\/\/t.co\/N8uFCs8Hqu",
  "id" : 361328210098659328,
  "created_at" : "2013-07-28 03:32:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361265514342924288",
  "geo" : { },
  "id_str" : "361266369657970688",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg glad he's ok! : )",
  "id" : 361266369657970688,
  "in_reply_to_status_id" : 361265514342924288,
  "created_at" : "2013-07-27 23:26:29 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/O9MkLANdjB",
      "expanded_url" : "http:\/\/imgur.com\/ojtui1k",
      "display_url" : "imgur.com\/ojtui1k"
    } ]
  },
  "geo" : { },
  "id_str" : "361160028725575680",
  "text" : "RT @aliceinthewater: He's making a break for it: http:\/\/t.co\/O9MkLANdjB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/O9MkLANdjB",
        "expanded_url" : "http:\/\/imgur.com\/ojtui1k",
        "display_url" : "imgur.com\/ojtui1k"
      } ]
    },
    "geo" : { },
    "id_str" : "361156922021388291",
    "text" : "He's making a break for it: http:\/\/t.co\/O9MkLANdjB",
    "id" : 361156922021388291,
    "created_at" : "2013-07-27 16:11:34 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 361160028725575680,
  "created_at" : "2013-07-27 16:23:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361141407756451843",
  "text" : "@SamsaricWarrior you can export them, then import from 2nd account. In Contacts, see More tab.",
  "id" : 361141407756451843,
  "created_at" : "2013-07-27 15:09:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 30, 44 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360796068356685825",
  "geo" : { },
  "id_str" : "360801464119066625",
  "in_reply_to_user_id" : 16901470,
  "text" : "USA needs #SinglePayer now RT @johnnie_cakes It's weird for a doctor to make you pay before he's seen you, right?",
  "id" : 360801464119066625,
  "in_reply_to_status_id" : 360796068356685825,
  "created_at" : "2013-07-26 16:39:07 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360526749873876995",
  "geo" : { },
  "id_str" : "360530460700442624",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth oh yes!",
  "id" : 360530460700442624,
  "in_reply_to_status_id" : 360526749873876995,
  "created_at" : "2013-07-25 22:42:14 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360424564351713281",
  "text" : "RT @ChrisCapparell: There is no wickedness, only sickness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360424063371444224",
    "text" : "There is no wickedness, only sickness.",
    "id" : 360424063371444224,
    "created_at" : "2013-07-25 15:39:27 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 360424564351713281,
  "created_at" : "2013-07-25 15:41:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360421899051859968",
  "text" : "RT @AnnotatedBible: How many \"Meals on Wheels\" programs could be funded by the money we send to #Egypt and the Palestinians, or the entire \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egypt",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360420545772261378",
    "text" : "How many \"Meals on Wheels\" programs could be funded by the money we send to #Egypt and the Palestinians, or the entire Middle East?",
    "id" : 360420545772261378,
    "created_at" : "2013-07-25 15:25:29 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 360421899051859968,
  "created_at" : "2013-07-25 15:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Joey",
      "screen_name" : "UnXiled",
      "indices" : [ 15, 23 ],
      "id_str" : "158869946",
      "id" : 158869946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360419670957891585",
  "geo" : { },
  "id_str" : "360421417591914498",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 @UnXiled duh.. it's july.. lol.. yup, thats my brain!",
  "id" : 360421417591914498,
  "in_reply_to_status_id" : 360419670957891585,
  "created_at" : "2013-07-25 15:28:56 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Joey",
      "screen_name" : "UnXiled",
      "indices" : [ 15, 23 ],
      "id_str" : "158869946",
      "id" : 158869946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360418663326691328",
  "geo" : { },
  "id_str" : "360419500027428864",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 @UnXiled maybe he looked like a teenager (so \"should\" be in school?) .. ppl are weird..",
  "id" : 360419500027428864,
  "in_reply_to_status_id" : 360418663326691328,
  "created_at" : "2013-07-25 15:21:19 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Joey",
      "screen_name" : "UnXiled",
      "indices" : [ 15, 23 ],
      "id_str" : "158869946",
      "id" : 158869946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "360416984384540672",
  "geo" : { },
  "id_str" : "360417714369605633",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 @UnXiled yeah.. WTH??",
  "id" : 360417714369605633,
  "in_reply_to_status_id" : 360416984384540672,
  "created_at" : "2013-07-25 15:14:14 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359750385935720448",
  "geo" : { },
  "id_str" : "359754885622796288",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields thanks!",
  "id" : 359754885622796288,
  "in_reply_to_status_id" : 359750385935720448,
  "created_at" : "2013-07-23 19:20:23 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instagram",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "vine",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359738379249782784",
  "text" : "you cannot upload photos or videos to #instagram or #vine like you could with via.me : (",
  "id" : 359738379249782784,
  "created_at" : "2013-07-23 18:14:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359735790437285888",
  "text" : "damn.. via.me will stop hosting photos august 1. i need a replacement.",
  "id" : 359735790437285888,
  "created_at" : "2013-07-23 18:04:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 45, 56 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/0U1T2OEqTk",
      "expanded_url" : "http:\/\/TheSovereignSeries.com",
      "display_url" : "TheSovereignSeries.com"
    } ]
  },
  "geo" : { },
  "id_str" : "359708153727823873",
  "text" : "hey pips, if you like small town tales.. try @ChickenJen 's http:\/\/t.co\/0U1T2OEqTk",
  "id" : 359708153727823873,
  "created_at" : "2013-07-23 16:14:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/CGA0EdUVOq",
      "expanded_url" : "http:\/\/youtu.be\/Tr0UpQXYkGs",
      "display_url" : "youtu.be\/Tr0UpQXYkGs"
    } ]
  },
  "geo" : { },
  "id_str" : "359697124377632768",
  "text" : "ummm... &gt;&gt; Jack Schaap Demonstrates How To Polish A Shaft: http:\/\/t.co\/CGA0EdUVOq",
  "id" : 359697124377632768,
  "created_at" : "2013-07-23 15:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/cEwqFdJul4",
      "expanded_url" : "http:\/\/amzn.to\/18rQatU",
      "display_url" : "amzn.to\/18rQatU"
    } ]
  },
  "geo" : { },
  "id_str" : "359507473733926913",
  "text" : "finished Hens and Chickens (Book 1 in The Sovereign Series) by Jennifer Wixson http:\/\/t.co\/cEwqFdJul4",
  "id" : 359507473733926913,
  "created_at" : "2013-07-23 02:57:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359467658183319552",
  "geo" : { },
  "id_str" : "359476773462884352",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce hehe.. yeah, you remember correctly. like a butterfly, here, there, everywhere : )",
  "id" : 359476773462884352,
  "in_reply_to_status_id" : 359467658183319552,
  "created_at" : "2013-07-23 00:55:16 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "359456069921148931",
  "geo" : { },
  "id_str" : "359457688209457153",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce im insane but i dont reg attend church (or even attend church) .. well, unless you count bible study on tue sept-jun..lol",
  "id" : 359457688209457153,
  "in_reply_to_status_id" : 359456069921148931,
  "created_at" : "2013-07-22 23:39:25 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359338899341971456",
  "text" : "so many different voices.. each with their own truth...",
  "id" : 359338899341971456,
  "created_at" : "2013-07-22 15:47:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358992896654983168",
  "text" : "99.2 so prob some virus.. ugh.",
  "id" : 358992896654983168,
  "created_at" : "2013-07-21 16:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358751701198569472",
  "text" : "sadly, i really am a helpless female. i might look fairly normal but im not all there IYKWIM...",
  "id" : 358751701198569472,
  "created_at" : "2013-07-21 00:54:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "San Diego Comic-Con",
      "screen_name" : "Comic_Con",
      "indices" : [ 18, 28 ],
      "id_str" : "16786977",
      "id" : 16786977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358727511317807104",
  "text" : "RT @neiltyson: If @Comic_Con people ruled the world, the future would be invented daily &amp; warfare would be bar-fights with toy light-sabers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "San Diego Comic-Con",
        "screen_name" : "Comic_Con",
        "indices" : [ 3, 13 ],
        "id_str" : "16786977",
        "id" : 16786977
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "358718065082515456",
    "text" : "If @Comic_Con people ruled the world, the future would be invented daily &amp; warfare would be bar-fights with toy light-sabers.",
    "id" : 358718065082515456,
    "created_at" : "2013-07-20 22:40:26 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 358727511317807104,
  "created_at" : "2013-07-20 23:17:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Carter",
      "screen_name" : "JECarter4",
      "indices" : [ 3, 13 ],
      "id_str" : "402094758",
      "id" : 402094758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdland",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/p7CJSlxYjx",
      "expanded_url" : "http:\/\/tmblr.co\/ZQ92cupdGWrf",
      "display_url" : "tmblr.co\/ZQ92cupdGWrf"
    } ]
  },
  "geo" : { },
  "id_str" : "358727151404597250",
  "text" : "RT @JECarter4: Replace \"George Zimmerman\" with \"Trayvon Martin\" in the jury instruction: http:\/\/t.co\/p7CJSlxYjx #nerdland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nerdland",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/p7CJSlxYjx",
        "expanded_url" : "http:\/\/tmblr.co\/ZQ92cupdGWrf",
        "display_url" : "tmblr.co\/ZQ92cupdGWrf"
      } ]
    },
    "geo" : { },
    "id_str" : "358603097355980800",
    "text" : "Replace \"George Zimmerman\" with \"Trayvon Martin\" in the jury instruction: http:\/\/t.co\/p7CJSlxYjx #nerdland",
    "id" : 358603097355980800,
    "created_at" : "2013-07-20 15:03:35 +0000",
    "user" : {
      "name" : "James Carter",
      "screen_name" : "JECarter4",
      "protected" : false,
      "id_str" : "402094758",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1616087875\/image_normal.jpg",
      "id" : 402094758,
      "verified" : false
    }
  },
  "id" : 358727151404597250,
  "created_at" : "2013-07-20 23:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "358313094704922624",
  "geo" : { },
  "id_str" : "358314388547055617",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 lol",
  "id" : 358314388547055617,
  "in_reply_to_status_id" : 358313094704922624,
  "created_at" : "2013-07-19 19:56:22 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 41, 52 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fridayread",
      "indices" : [ 3, 14 ]
    }, {
      "text" : "contemporary",
      "indices" : [ 91, 104 ]
    }, {
      "text" : "chicklit",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358307348596527104",
  "text" : "my #fridayread is \"Hens and Chickens\" by @ChickenJen .. started yesterday. like it so far. #contemporary #chicklit",
  "id" : 358307348596527104,
  "created_at" : "2013-07-19 19:28:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Doe, MD",
      "screen_name" : "DrJaneChi",
      "indices" : [ 0, 10 ],
      "id_str" : "214164173",
      "id" : 214164173
    }, {
      "name" : "HelloPoodle",
      "screen_name" : "HelloPoodle",
      "indices" : [ 37, 49 ],
      "id_str" : "4873061806",
      "id" : 4873061806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357981349182844928",
  "geo" : { },
  "id_str" : "358305908041859072",
  "in_reply_to_user_id" : 214164173,
  "text" : "@DrJaneChi really? that's very cool! @HelloPoodle",
  "id" : 358305908041859072,
  "in_reply_to_status_id" : 357981349182844928,
  "created_at" : "2013-07-19 19:22:40 +0000",
  "in_reply_to_screen_name" : "DrJaneChi",
  "in_reply_to_user_id_str" : "214164173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane Doe, MD",
      "screen_name" : "DrJaneChi",
      "indices" : [ 3, 13 ],
      "id_str" : "214164173",
      "id" : 214164173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HB59",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358305888731271168",
  "text" : "RT @DrJaneChi: Cardiac cells have inherent contractility. They beat in a single cell layer in a petri dish. Personhood ain't in it. #HB59",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HB59",
        "indices" : [ 117, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357981349182844928",
    "text" : "Cardiac cells have inherent contractility. They beat in a single cell layer in a petri dish. Personhood ain't in it. #HB59",
    "id" : 357981349182844928,
    "created_at" : "2013-07-18 21:52:59 +0000",
    "user" : {
      "name" : "Jane Doe, MD",
      "screen_name" : "DrJaneChi",
      "protected" : false,
      "id_str" : "214164173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549193956198998017\/1_vSTioM_normal.jpeg",
      "id" : 214164173,
      "verified" : false
    }
  },
  "id" : 358305888731271168,
  "created_at" : "2013-07-19 19:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358305496656121856",
  "text" : "there was lightning in distance and i was scared. always been afraid of lightning. and my legs were like in molasses.",
  "id" : 358305496656121856,
  "created_at" : "2013-07-19 19:21:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358305040005476353",
  "text" : "scared DD yesterday when running to house from pool, thundering. i was weezing. i have NO endurance. : (",
  "id" : 358305040005476353,
  "created_at" : "2013-07-19 19:19:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "pharmaslave",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358303283028299777",
  "text" : "guess which dumb bunny forgot her pill yesterday? #effexor #pharmaslave",
  "id" : 358303283028299777,
  "created_at" : "2013-07-19 19:12:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    }, {
      "name" : "Joey Hendriix",
      "screen_name" : "RealJoeyCiroc",
      "indices" : [ 85, 99 ],
      "id_str" : "379788947",
      "id" : 379788947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358037677590851584",
  "text" : "RT @Wolf_Mommy: Breastfeeding has nothing to do with abortion, suicide or terrorism. @RealJoeyCiroc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joey Hendriix",
        "screen_name" : "RealJoeyCiroc",
        "indices" : [ 69, 83 ],
        "id_str" : "379788947",
        "id" : 379788947
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "358035690631606273",
    "geo" : { },
    "id_str" : "358036445220438019",
    "in_reply_to_user_id" : 379788947,
    "text" : "Breastfeeding has nothing to do with abortion, suicide or terrorism. @RealJoeyCiroc",
    "id" : 358036445220438019,
    "in_reply_to_status_id" : 358035690631606273,
    "created_at" : "2013-07-19 01:31:55 +0000",
    "in_reply_to_screen_name" : "RealJoeyCiroc",
    "in_reply_to_user_id_str" : "379788947",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 358037677590851584,
  "created_at" : "2013-07-19 01:36:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357901931936628736",
  "text" : "RT @Buddhaworld: Lets be born again every day anew. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357898602900750336",
    "text" : "Lets be born again every day anew. Buddha volko",
    "id" : 357898602900750336,
    "created_at" : "2013-07-18 16:24:11 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 357901931936628736,
  "created_at" : "2013-07-18 16:37:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357856564058656768",
  "text" : "RT @BrianMerritt: I am more convinced than ever that we create rules because we lack trust.  What happens when we quit care about being use\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357854596925886464",
    "text" : "I am more convinced than ever that we create rules because we lack trust.  What happens when we quit care about being used in sharing?",
    "id" : 357854596925886464,
    "created_at" : "2013-07-18 13:29:19 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 357856564058656768,
  "created_at" : "2013-07-18 13:37:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/wdbokQRccy",
      "expanded_url" : "http:\/\/amzn.to\/17fpaNw",
      "display_url" : "amzn.to\/17fpaNw"
    } ]
  },
  "geo" : { },
  "id_str" : "357693022818930688",
  "text" : "finished JUMP by Stephen R. Stober http:\/\/t.co\/wdbokQRccy",
  "id" : 357693022818930688,
  "created_at" : "2013-07-18 02:47:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/0ar6WZKeTG",
      "expanded_url" : "http:\/\/i.imgur.com\/2iuqZxw.jpg",
      "display_url" : "i.imgur.com\/2iuqZxw.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "357662361777225730",
  "text" : "RT @aliceinthewater: If I had to see this face every day I wouldn't be able to make it in the office: http:\/\/t.co\/0ar6WZKeTG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/0ar6WZKeTG",
        "expanded_url" : "http:\/\/i.imgur.com\/2iuqZxw.jpg",
        "display_url" : "i.imgur.com\/2iuqZxw.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "357661810486284289",
    "text" : "If I had to see this face every day I wouldn't be able to make it in the office: http:\/\/t.co\/0ar6WZKeTG",
    "id" : 357661810486284289,
    "created_at" : "2013-07-18 00:43:15 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 357662361777225730,
  "created_at" : "2013-07-18 00:45:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357643323932033027",
  "text" : "@1stCitizenKane i was more referring to all the money towards wars would have funded so much scientific progress. makes me sick.",
  "id" : 357643323932033027,
  "created_at" : "2013-07-17 23:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357643116884398080",
  "text" : "@1stCitizenKane i think we do exist in a constant power struggle.. those in power find ways to keep the masses in place.",
  "id" : 357643116884398080,
  "created_at" : "2013-07-17 23:28:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357641210325774336",
  "text" : "@1stCitizenKane arent we already in hell? and if we all werent always at war, we'd have flying cars by now.",
  "id" : 357641210325774336,
  "created_at" : "2013-07-17 23:21:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alfie Kohn",
      "screen_name" : "alfiekohn",
      "indices" : [ 3, 13 ],
      "id_str" : "48203749",
      "id" : 48203749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Xrf7dEneAq",
      "expanded_url" : "http:\/\/goo.gl\/iYNps",
      "display_url" : "goo.gl\/iYNps"
    } ]
  },
  "geo" : { },
  "id_str" : "357638428181004288",
  "text" : "RT @alfiekohn: MN parents join others nationwide in refusing to subject their kids to standardized tests: http:\/\/t.co\/Xrf7dEneAq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/Xrf7dEneAq",
        "expanded_url" : "http:\/\/goo.gl\/iYNps",
        "display_url" : "goo.gl\/iYNps"
      } ]
    },
    "geo" : { },
    "id_str" : "356760068907216897",
    "text" : "MN parents join others nationwide in refusing to subject their kids to standardized tests: http:\/\/t.co\/Xrf7dEneAq",
    "id" : 356760068907216897,
    "created_at" : "2013-07-15 13:00:03 +0000",
    "user" : {
      "name" : "Alfie Kohn",
      "screen_name" : "alfiekohn",
      "protected" : false,
      "id_str" : "48203749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/268255242\/Banbury_normal.JPG",
      "id" : 48203749,
      "verified" : false
    }
  },
  "id" : 357638428181004288,
  "created_at" : "2013-07-17 23:10:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357625347765833728",
  "geo" : { },
  "id_str" : "357637897588977664",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits hehe.. clever kid!",
  "id" : 357637897588977664,
  "in_reply_to_status_id" : 357625347765833728,
  "created_at" : "2013-07-17 23:08:14 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357637726138417152",
  "text" : "@statue_dog i dont blame you, SD.. i like the quiet, too.",
  "id" : 357637726138417152,
  "created_at" : "2013-07-17 23:07:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Activist Post",
      "screen_name" : "ActivistPost",
      "indices" : [ 3, 16 ],
      "id_str" : "154532994",
      "id" : 154532994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357614172298678273",
  "text" : "RT @ActivistPost: Tragic Mistake Or Deliberate Plan? 30 Million People Injected with Mandatory Vaccination Containing Live SV40... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/zZbfPAiM2c",
        "expanded_url" : "http:\/\/fb.me\/26fEMWDvq",
        "display_url" : "fb.me\/26fEMWDvq"
      } ]
    },
    "geo" : { },
    "id_str" : "357610704968224768",
    "text" : "Tragic Mistake Or Deliberate Plan? 30 Million People Injected with Mandatory Vaccination Containing Live SV40... http:\/\/t.co\/zZbfPAiM2c",
    "id" : 357610704968224768,
    "created_at" : "2013-07-17 21:20:10 +0000",
    "user" : {
      "name" : "Activist Post",
      "screen_name" : "ActivistPost",
      "protected" : false,
      "id_str" : "154532994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709886591976628224\/6kjfjyZD_normal.jpg",
      "id" : 154532994,
      "verified" : false
    }
  },
  "id" : 357614172298678273,
  "created_at" : "2013-07-17 21:33:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357294376025722881",
  "text" : "RT @micahjmurray: So no, don\u2019t \u201Cbe like Jesus who hung out with prostitutes and drunkards\u201D. Be like Jesus who saw people as names &amp; faces &amp;\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357289850526908419",
    "text" : "So no, don\u2019t \u201Cbe like Jesus who hung out with prostitutes and drunkards\u201D. Be like Jesus who saw people as names &amp; faces &amp; stories, not sins.",
    "id" : 357289850526908419,
    "created_at" : "2013-07-17 00:05:13 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 357294376025722881,
  "created_at" : "2013-07-17 00:23:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357288905646673920",
  "text" : "RT @BrianRathbone: People sometimes ask me why I always have a goofy grin on my face. I came VERY close to death at 16; everything since ha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357288164085346304",
    "text" : "People sometimes ask me why I always have a goofy grin on my face. I came VERY close to death at 16; everything since has just been a bonus",
    "id" : 357288164085346304,
    "created_at" : "2013-07-16 23:58:31 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 357288905646673920,
  "created_at" : "2013-07-17 00:01:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357262915423830017",
  "geo" : { },
  "id_str" : "357267926681788416",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits some ppl think anyone outside of status quo is dangerous...",
  "id" : 357267926681788416,
  "in_reply_to_status_id" : 357262915423830017,
  "created_at" : "2013-07-16 22:38:06 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Appoday",
      "screen_name" : "appoday",
      "indices" : [ 35, 43 ],
      "id_str" : "480327055",
      "id" : 480327055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatsApp",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "FREE",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/8LzGJ5frDd",
      "expanded_url" : "http:\/\/bit.ly\/15Lf5IX",
      "display_url" : "bit.ly\/15Lf5IX"
    } ]
  },
  "in_reply_to_status_id_str" : "357248066274869248",
  "geo" : { },
  "id_str" : "357249042360696832",
  "in_reply_to_user_id" : 480327055,
  "text" : "doesnt work w ipodtouch4gen : ( RT @appoday Popular messenger, #WhatsApp is #FREE today! Get it while you can! http:\/\/t.co\/8LzGJ5frDd",
  "id" : 357249042360696832,
  "in_reply_to_status_id" : 357248066274869248,
  "created_at" : "2013-07-16 21:23:03 +0000",
  "in_reply_to_screen_name" : "appoday",
  "in_reply_to_user_id_str" : "480327055",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/HpJy8afw9m",
      "expanded_url" : "http:\/\/john.do\/full-time-blogger\/",
      "display_url" : "john.do\/full-time-blog\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "357195150818152449",
  "geo" : { },
  "id_str" : "357197112137621504",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray fyi - http:\/\/t.co\/HpJy8afw9m",
  "id" : 357197112137621504,
  "in_reply_to_status_id" : 357195150818152449,
  "created_at" : "2013-07-16 17:56:42 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357195473527906305",
  "text" : "@1stCitizenKane existential crisis, are we having?",
  "id" : 357195473527906305,
  "created_at" : "2013-07-16 17:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357182270437736449",
  "text" : "I need to directly tweet more. I know I RT way too much!",
  "id" : 357182270437736449,
  "created_at" : "2013-07-16 16:57:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "357169823387619328",
  "geo" : { },
  "id_str" : "357176853527674881",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist heehee : )",
  "id" : 357176853527674881,
  "in_reply_to_status_id" : 357169823387619328,
  "created_at" : "2013-07-16 16:36:12 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CREGS",
      "screen_name" : "CREGS_SF",
      "indices" : [ 3, 12 ],
      "id_str" : "23619340",
      "id" : 23619340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/3aWbnzypzy",
      "expanded_url" : "http:\/\/bit.ly\/13maV57",
      "display_url" : "bit.ly\/13maV57"
    } ]
  },
  "geo" : { },
  "id_str" : "356918836819271681",
  "text" : "RT @CREGS_SF: Texas Lawmaker Says Sex Ed Makes Teens \u2018Hot and Bothered,\u2019 Leads to Sex and Babies http:\/\/t.co\/3aWbnzypzy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/3aWbnzypzy",
        "expanded_url" : "http:\/\/bit.ly\/13maV57",
        "display_url" : "bit.ly\/13maV57"
      } ]
    },
    "geo" : { },
    "id_str" : "356862515839369217",
    "text" : "Texas Lawmaker Says Sex Ed Makes Teens \u2018Hot and Bothered,\u2019 Leads to Sex and Babies http:\/\/t.co\/3aWbnzypzy",
    "id" : 356862515839369217,
    "created_at" : "2013-07-15 19:47:08 +0000",
    "user" : {
      "name" : "CREGS",
      "screen_name" : "CREGS_SF",
      "protected" : false,
      "id_str" : "23619340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1811386195\/med_color_normal.jpg",
      "id" : 23619340,
      "verified" : false
    }
  },
  "id" : 356918836819271681,
  "created_at" : "2013-07-15 23:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cracked.com",
      "screen_name" : "cracked",
      "indices" : [ 82, 90 ],
      "id_str" : "12513472",
      "id" : 12513472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/c9gffClTBd",
      "expanded_url" : "http:\/\/www.cracked.com\/article_19042_6-terrifying-ways-crows-are-way-smarter-than-you-think.html",
      "display_url" : "cracked.com\/article_19042_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "356915283602046976",
  "text" : "6 Terrifying Ways Crows Are Way Smarter Than You Think http:\/\/t.co\/c9gffClTBd via @cracked",
  "id" : 356915283602046976,
  "created_at" : "2013-07-15 23:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "indices" : [ 3, 19 ],
      "id_str" : "179121328",
      "id" : 179121328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/gRdu0t6iNS",
      "expanded_url" : "http:\/\/bit.ly\/15zwqCj",
      "display_url" : "bit.ly\/15zwqCj"
    } ]
  },
  "geo" : { },
  "id_str" : "356912738062188544",
  "text" : "RT @thesilverspiral: http:\/\/t.co\/gRdu0t6iNS Kind human removes porcupine quills from a raven. Thank the Goddess for people like this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/gRdu0t6iNS",
        "expanded_url" : "http:\/\/bit.ly\/15zwqCj",
        "display_url" : "bit.ly\/15zwqCj"
      } ]
    },
    "geo" : { },
    "id_str" : "356911145417850880",
    "text" : "http:\/\/t.co\/gRdu0t6iNS Kind human removes porcupine quills from a raven. Thank the Goddess for people like this.",
    "id" : 356911145417850880,
    "created_at" : "2013-07-15 23:00:22 +0000",
    "user" : {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "protected" : false,
      "id_str" : "179121328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476331163322052609\/9eQZmrqN_normal.jpeg",
      "id" : 179121328,
      "verified" : false
    }
  },
  "id" : 356912738062188544,
  "created_at" : "2013-07-15 23:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356898916266016768",
  "text" : "RT @micahjmurray: If anybody else wants to join the ridonculous Facebook fun we've been having re: theology, you're welcome: https:\/\/t.co\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/trql0UQ1Qa",
        "expanded_url" : "https:\/\/www.facebook.com\/micahjmurray\/posts\/10151772172147464?comment_id=29053476&ref=notif&notif_t=like",
        "display_url" : "facebook.com\/micahjmurray\/p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "356890510624964608",
    "text" : "If anybody else wants to join the ridonculous Facebook fun we've been having re: theology, you're welcome: https:\/\/t.co\/trql0UQ1Qa",
    "id" : 356890510624964608,
    "created_at" : "2013-07-15 21:38:23 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 356898916266016768,
  "created_at" : "2013-07-15 22:11:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356891459099688961",
  "geo" : { },
  "id_str" : "356898580914647041",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray will you be blogging about it? lol",
  "id" : 356898580914647041,
  "in_reply_to_status_id" : 356891459099688961,
  "created_at" : "2013-07-15 22:10:27 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 15, 24 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356818102475964416",
  "text" : "Happy Birthday @Mortenrb .. spending it w your lovely lady i bet! : )",
  "id" : 356818102475964416,
  "created_at" : "2013-07-15 16:50:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356768649341702145",
  "geo" : { },
  "id_str" : "356771902968172544",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses omg..yes..lol",
  "id" : 356771902968172544,
  "in_reply_to_status_id" : 356768649341702145,
  "created_at" : "2013-07-15 13:47:04 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ActorBuster",
      "screen_name" : "ActorBuster",
      "indices" : [ 3, 15 ],
      "id_str" : "2588026416",
      "id" : 2588026416
    }, {
      "name" : "Cute Emergency\uD83C\uDF84",
      "screen_name" : "CuteEmergency",
      "indices" : [ 53, 67 ],
      "id_str" : "568825492",
      "id" : 568825492
    }, {
      "name" : "dvnix",
      "screen_name" : "dvnix",
      "indices" : [ 91, 97 ],
      "id_str" : "799759673603674112",
      "id" : 799759673603674112
    }, {
      "name" : "Dragon Vision Gaming",
      "screen_name" : "D_V_E",
      "indices" : [ 98, 104 ],
      "id_str" : "773651007180005376",
      "id" : 773651007180005376
    }, {
      "name" : "HoneybadgerLA",
      "screen_name" : "HoneybadgerLA",
      "indices" : [ 105, 119 ],
      "id_str" : "526101087",
      "id" : 526101087
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CuteEmergency\/status\/356590229882273793\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/HGcmeOrZa5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPLc7L7CAAAq_Z1.jpg",
      "id_str" : "356590229886468096",
      "id" : 356590229886468096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPLc7L7CAAAq_Z1.jpg",
      "sizes" : [ {
        "h" : 351,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com\/HGcmeOrZa5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356591120723087360",
  "text" : "RT @ActorBuster: OMG!! This will make you smile! RT: @CuteEmergency http:\/\/t.co\/HGcmeOrZa5 @dvnix @D_v_E @HoneybadgerLA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cute Emergency\uD83C\uDF84",
        "screen_name" : "CuteEmergency",
        "indices" : [ 36, 50 ],
        "id_str" : "568825492",
        "id" : 568825492
      }, {
        "name" : "dvnix",
        "screen_name" : "dvnix",
        "indices" : [ 74, 80 ],
        "id_str" : "799759673603674112",
        "id" : 799759673603674112
      }, {
        "name" : "Dragon Vision Gaming",
        "screen_name" : "D_V_E",
        "indices" : [ 81, 87 ],
        "id_str" : "773651007180005376",
        "id" : 773651007180005376
      }, {
        "name" : "HoneybadgerLA",
        "screen_name" : "HoneybadgerLA",
        "indices" : [ 88, 102 ],
        "id_str" : "526101087",
        "id" : 526101087
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CuteEmergency\/status\/356590229882273793\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/HGcmeOrZa5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPLc7L7CAAAq_Z1.jpg",
        "id_str" : "356590229886468096",
        "id" : 356590229886468096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPLc7L7CAAAq_Z1.jpg",
        "sizes" : [ {
          "h" : 351,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 625
        } ],
        "display_url" : "pic.twitter.com\/HGcmeOrZa5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356590600226742272",
    "text" : "OMG!! This will make you smile! RT: @CuteEmergency http:\/\/t.co\/HGcmeOrZa5 @dvnix @D_v_E @HoneybadgerLA",
    "id" : 356590600226742272,
    "created_at" : "2013-07-15 01:46:38 +0000",
    "user" : {
      "name" : "We R Gonna Fix This",
      "screen_name" : "wtb6chiny",
      "protected" : false,
      "id_str" : "204947822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787487931212718080\/lpOT5NLK_normal.jpg",
      "id" : 204947822,
      "verified" : false
    }
  },
  "id" : 356591120723087360,
  "created_at" : "2013-07-15 01:48:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356534833402494976",
  "geo" : { },
  "id_str" : "356535265583566848",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH aww..",
  "id" : 356535265583566848,
  "in_reply_to_status_id" : 356534833402494976,
  "created_at" : "2013-07-14 22:06:46 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356528304469188610",
  "geo" : { },
  "id_str" : "356529714694860800",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste cool..lol",
  "id" : 356529714694860800,
  "in_reply_to_status_id" : 356528304469188610,
  "created_at" : "2013-07-14 21:44:42 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnificent2",
      "screen_name" : "Indomitable69",
      "indices" : [ 0, 14 ],
      "id_str" : "256352051",
      "id" : 256352051
    }, {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 58, 70 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "356467312670416900",
  "geo" : { },
  "id_str" : "356528630505029632",
  "in_reply_to_user_id" : 256352051,
  "text" : "@Indomitable69 and disproportionately poor, too, i bet... @TheOracle13",
  "id" : 356528630505029632,
  "in_reply_to_status_id" : 356467312670416900,
  "created_at" : "2013-07-14 21:40:24 +0000",
  "in_reply_to_screen_name" : "Indomitable69",
  "in_reply_to_user_id_str" : "256352051",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "Gustav Mahler",
      "screen_name" : "GustavMahlerJr",
      "indices" : [ 18, 33 ],
      "id_str" : "58262071",
      "id" : 58262071
    }, {
      "name" : "Laffy",
      "screen_name" : "GottaLaff",
      "indices" : [ 35, 45 ],
      "id_str" : "15368940",
      "id" : 15368940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/nYs90SWlUO",
      "expanded_url" : "http:\/\/tinyurl.com\/qeqkofj",
      "display_url" : "tinyurl.com\/qeqkofj"
    } ]
  },
  "geo" : { },
  "id_str" : "356519676181880833",
  "text" : "RT @Jamiastar: RT @GustavMahlerJr: @GottaLaff Here is link to story, same as Zimmerman case except races reversed http:\/\/t.co\/nYs90SWlUO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gustav Mahler",
        "screen_name" : "GustavMahlerJr",
        "indices" : [ 3, 18 ],
        "id_str" : "58262071",
        "id" : 58262071
      }, {
        "name" : "Laffy",
        "screen_name" : "GottaLaff",
        "indices" : [ 20, 30 ],
        "id_str" : "15368940",
        "id" : 15368940
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/nYs90SWlUO",
        "expanded_url" : "http:\/\/tinyurl.com\/qeqkofj",
        "display_url" : "tinyurl.com\/qeqkofj"
      } ]
    },
    "geo" : { },
    "id_str" : "356517672533504000",
    "text" : "RT @GustavMahlerJr: @GottaLaff Here is link to story, same as Zimmerman case except races reversed http:\/\/t.co\/nYs90SWlUO",
    "id" : 356517672533504000,
    "created_at" : "2013-07-14 20:56:51 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 356519676181880833,
  "created_at" : "2013-07-14 21:04:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denise",
      "screen_name" : "DeelightRI",
      "indices" : [ 3, 14 ],
      "id_str" : "289044386",
      "id" : 289044386
    }, {
      "name" : "ClinicEscort",
      "screen_name" : "ClinicEscort",
      "indices" : [ 16, 29 ],
      "id_str" : "45934467",
      "id" : 45934467
    }, {
      "name" : "Lisa Amor Petrov",
      "screen_name" : "laprofe63",
      "indices" : [ 30, 40 ],
      "id_str" : "410135192",
      "id" : 410135192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356453904575238147",
  "text" : "RT @DeelightRI: @ClinicEscort @laprofe63 America is not Free till every Citizen is free. With = Justice for All. We must Unite and Demand =\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ClinicEscort",
        "screen_name" : "ClinicEscort",
        "indices" : [ 0, 13 ],
        "id_str" : "45934467",
        "id" : 45934467
      }, {
        "name" : "Lisa Amor Petrov",
        "screen_name" : "laprofe63",
        "indices" : [ 14, 24 ],
        "id_str" : "410135192",
        "id" : 410135192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "356244957092249601",
    "geo" : { },
    "id_str" : "356280288214650882",
    "in_reply_to_user_id" : 45934467,
    "text" : "@ClinicEscort @laprofe63 America is not Free till every Citizen is free. With = Justice for All. We must Unite and Demand = Justice For All.",
    "id" : 356280288214650882,
    "in_reply_to_status_id" : 356244957092249601,
    "created_at" : "2013-07-14 05:13:34 +0000",
    "in_reply_to_screen_name" : "ClinicEscort",
    "in_reply_to_user_id_str" : "45934467",
    "user" : {
      "name" : "Denise",
      "screen_name" : "DeelightRI",
      "protected" : false,
      "id_str" : "289044386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626958015955140608\/-31aWVnF_normal.jpg",
      "id" : 289044386,
      "verified" : false
    }
  },
  "id" : 356453904575238147,
  "created_at" : "2013-07-14 16:43:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356453847419461632",
  "text" : "RT @CoryBooker: We must mourn the unnecessary &amp; unjust death of a child, but to honor him we must rededicate ourselves to the very ideals t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356246695882915840",
    "text" : "We must mourn the unnecessary &amp; unjust death of a child, but to honor him we must rededicate ourselves to the very ideals that were violated",
    "id" : 356246695882915840,
    "created_at" : "2013-07-14 03:00:05 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 356453847419461632,
  "created_at" : "2013-07-14 16:43:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 0, 12 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356453716724953089",
  "text" : "@embreeology i watched entire trial on tv so i saw\/heard what jury saw\/heard.. GZ lied and assumed TM was criminal. GZ pursued w gun.",
  "id" : 356453716724953089,
  "created_at" : "2013-07-14 16:42:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 0, 12 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356452881001484288",
  "text" : "@embreeology if we are to respect the law, he must be free to live his life (even tho i think GZ lied and was guilty)",
  "id" : 356452881001484288,
  "created_at" : "2013-07-14 16:39:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zeroman",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356452256272498689",
  "text" : "RT @ZeitgeistGhost: I'm white &amp; i my soul aches over the injustice of #Zeroman getting away with murder. I can't imagine how my Black frien\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zeroman",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356442129863688193",
    "text" : "I'm white &amp; i my soul aches over the injustice of #Zeroman getting away with murder. I can't imagine how my Black friends\/followers feel ;-(",
    "id" : 356442129863688193,
    "created_at" : "2013-07-14 15:56:40 +0000",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 356452256272498689,
  "created_at" : "2013-07-14 16:36:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scandalous Hussy",
      "screen_name" : "ScandalousHussy",
      "indices" : [ 3, 19 ],
      "id_str" : "347595175",
      "id" : 347595175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356450260387762177",
  "text" : "RT @ScandalousHussy: Hearing people say Trayvon caused his own death reminds me of people who say an unwed pregnant girl \"Got herself pregn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356449483581698049",
    "text" : "Hearing people say Trayvon caused his own death reminds me of people who say an unwed pregnant girl \"Got herself pregnant.\"",
    "id" : 356449483581698049,
    "created_at" : "2013-07-14 16:25:54 +0000",
    "user" : {
      "name" : "Scandalous Hussy",
      "screen_name" : "ScandalousHussy",
      "protected" : false,
      "id_str" : "347595175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3076000400\/19dc18030f1bd8ed7eef53bd71459506_normal.jpeg",
      "id" : 347595175,
      "verified" : false
    }
  },
  "id" : 356450260387762177,
  "created_at" : "2013-07-14 16:28:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shespissed",
      "indices" : [ 110, 121 ]
    }, {
      "text" : "zimmerman",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356450067294597120",
  "text" : "i let my DD think what she wants and sometimes im surprised when we disagree on an issue. but today im proud. #shespissed #zimmerman",
  "id" : 356450067294597120,
  "created_at" : "2013-07-14 16:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Walsh",
      "screen_name" : "BradWalsh",
      "indices" : [ 3, 13 ],
      "id_str" : "15173253",
      "id" : 15173253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356424655877316608",
  "text" : "RT @BradWalsh: Exhausted by comfortably ignorant people deciding that anyone \"other\" is not worthy of freedom, equality, life. We won't sur\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356239621513945088",
    "text" : "Exhausted by comfortably ignorant people deciding that anyone \"other\" is not worthy of freedom, equality, life. We won't survive like this.",
    "id" : 356239621513945088,
    "created_at" : "2013-07-14 02:31:59 +0000",
    "user" : {
      "name" : "Brad Walsh",
      "screen_name" : "BradWalsh",
      "protected" : false,
      "id_str" : "15173253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758412235601506305\/yLpHQeTZ_normal.jpg",
      "id" : 15173253,
      "verified" : true
    }
  },
  "id" : 356424655877316608,
  "created_at" : "2013-07-14 14:47:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356239537346850819",
  "text" : "RT @VirgoJohnny: I remember when this happened. The kkk members were also acquitted (self defense claim) Greensboro massacre - https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/1EyMj4qkYu",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Greensboro_massacre",
        "display_url" : "en.wikipedia.org\/wiki\/Greensbor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "356239011553087489",
    "text" : "I remember when this happened. The kkk members were also acquitted (self defense claim) Greensboro massacre - https:\/\/t.co\/1EyMj4qkYu",
    "id" : 356239011553087489,
    "created_at" : "2013-07-14 02:29:33 +0000",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 356239537346850819,
  "created_at" : "2013-07-14 02:31:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zimmerman",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356232967166754816",
  "text" : "damn... #zimmerman trial .. really wasn't expecting that.",
  "id" : 356232967166754816,
  "created_at" : "2013-07-14 02:05:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356136847765803008",
  "text" : "RT @neiltyson: I occasionally find myself intolerant of people who are intolerant.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356135530326532096",
    "text" : "I occasionally find myself intolerant of people who are intolerant.",
    "id" : 356135530326532096,
    "created_at" : "2013-07-13 19:38:21 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 356136847765803008,
  "created_at" : "2013-07-13 19:43:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Goddess",
      "screen_name" : "drgoddess",
      "indices" : [ 3, 13 ],
      "id_str" : "19468168",
      "id" : 19468168
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZimmermanTrial",
      "indices" : [ 50, 65 ]
    }, {
      "text" : "Zimmerman",
      "indices" : [ 90, 100 ]
    }, {
      "text" : "Trayvon",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "J4TM",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "J4GZ",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "TrayvonMartin",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/5lq6OLtsPf",
      "expanded_url" : "http:\/\/drgdss.me\/15BKXzH",
      "display_url" : "drgdss.me\/15BKXzH"
    } ]
  },
  "geo" : { },
  "id_str" : "355876563406950403",
  "text" : "RT @drgoddess: \"My Closing Argument in the George #ZimmermanTrial\" http:\/\/t.co\/5lq6OLtsPf #Zimmerman #Trayvon #J4TM #J4GZ #TrayvonMartin #G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ZimmermanTrial",
        "indices" : [ 35, 50 ]
      }, {
        "text" : "Zimmerman",
        "indices" : [ 75, 85 ]
      }, {
        "text" : "Trayvon",
        "indices" : [ 86, 94 ]
      }, {
        "text" : "J4TM",
        "indices" : [ 95, 100 ]
      }, {
        "text" : "J4GZ",
        "indices" : [ 101, 106 ]
      }, {
        "text" : "TrayvonMartin",
        "indices" : [ 107, 121 ]
      }, {
        "text" : "GeorgeZimmerman",
        "indices" : [ 122, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/5lq6OLtsPf",
        "expanded_url" : "http:\/\/drgdss.me\/15BKXzH",
        "display_url" : "drgdss.me\/15BKXzH"
      } ]
    },
    "geo" : { },
    "id_str" : "355821203673448450",
    "text" : "\"My Closing Argument in the George #ZimmermanTrial\" http:\/\/t.co\/5lq6OLtsPf #Zimmerman #Trayvon #J4TM #J4GZ #TrayvonMartin #GeorgeZimmerman",
    "id" : 355821203673448450,
    "created_at" : "2013-07-12 22:49:20 +0000",
    "user" : {
      "name" : "Dr. Goddess",
      "screen_name" : "drgoddess",
      "protected" : false,
      "id_str" : "19468168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794281100457734148\/3YcIINO8_normal.jpg",
      "id" : 19468168,
      "verified" : true
    }
  },
  "id" : 355876563406950403,
  "created_at" : "2013-07-13 02:29:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355859234191183872",
  "text" : "@1stCitizenKane the ppl who are ready to hear you, will follow.",
  "id" : 355859234191183872,
  "created_at" : "2013-07-13 01:20:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355856044863406081",
  "geo" : { },
  "id_str" : "355859001650577411",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits i never liked the whole push of \"born that way\".. born or choice.. it shouldn't matter. it doesn't hurt ppl.",
  "id" : 355859001650577411,
  "in_reply_to_status_id" : 355856044863406081,
  "created_at" : "2013-07-13 01:19:32 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355857870849458176",
  "text" : "DH and I had nice afternoon w new friends. 1st friends that are ours together...lol.",
  "id" : 355857870849458176,
  "created_at" : "2013-07-13 01:15:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 0, 16 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "355688132940808195",
  "geo" : { },
  "id_str" : "355697283427344384",
  "in_reply_to_user_id" : 140060120,
  "text" : "@davidpakmanshow i love Louis's t-shirt..lol",
  "id" : 355697283427344384,
  "in_reply_to_status_id" : 355688132940808195,
  "created_at" : "2013-07-12 14:36:55 +0000",
  "in_reply_to_screen_name" : "davidpakmanshow",
  "in_reply_to_user_id_str" : "140060120",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    }, {
      "name" : "Alone n Stoned",
      "screen_name" : "alonelystoner_",
      "indices" : [ 124, 139 ],
      "id_str" : "3236421617",
      "id" : 3236421617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355693701131014146",
  "text" : "@1stCitizenKane sometimes you need a lot of crazy to shake things up. it gets ppl interested in looking beyond their circle @alonelystoner_",
  "id" : 355693701131014146,
  "created_at" : "2013-07-12 14:22:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/6qPhDkQLrr",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-jK",
      "display_url" : "wp.me\/pzgRU-jK"
    } ]
  },
  "geo" : { },
  "id_str" : "355506580462116865",
  "text" : "RT @ZachsMind: Trial By Internet (the Zimmerman Martin thing) http:\/\/t.co\/6qPhDkQLrr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/6qPhDkQLrr",
        "expanded_url" : "http:\/\/wp.me\/pzgRU-jK",
        "display_url" : "wp.me\/pzgRU-jK"
      } ]
    },
    "geo" : { },
    "id_str" : "355499488321875968",
    "text" : "Trial By Internet (the Zimmerman Martin thing) http:\/\/t.co\/6qPhDkQLrr",
    "id" : 355499488321875968,
    "created_at" : "2013-07-12 01:30:57 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 355506580462116865,
  "created_at" : "2013-07-12 01:59:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/JDn80U722O",
      "expanded_url" : "http:\/\/amzn.to\/11Ahl6x",
      "display_url" : "amzn.to\/11Ahl6x"
    } ]
  },
  "geo" : { },
  "id_str" : "355387860196655104",
  "text" : "finished The Island by Jen Minkman http:\/\/t.co\/JDn80U722O",
  "id" : 355387860196655104,
  "created_at" : "2013-07-11 18:07:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354981157525397506",
  "text" : "@1stCitizenKane true. an eye for an eye is revenge.. which gets us nowhere...",
  "id" : 354981157525397506,
  "created_at" : "2013-07-10 15:11:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LadyBella",
      "screen_name" : "LadyGuest",
      "indices" : [ 0, 10 ],
      "id_str" : "30097035",
      "id" : 30097035
    }, {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 21, 33 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354975475916996608",
  "geo" : { },
  "id_str" : "354979608778653696",
  "in_reply_to_user_id" : 30097035,
  "text" : "@LadyGuest agreed... @oceanshaman",
  "id" : 354979608778653696,
  "in_reply_to_status_id" : 354975475916996608,
  "created_at" : "2013-07-10 15:05:08 +0000",
  "in_reply_to_screen_name" : "LadyGuest",
  "in_reply_to_user_id_str" : "30097035",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 83, 98 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354976392049459200",
  "geo" : { },
  "id_str" : "354979338409615364",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis to outlaw religion is as bad as making ppl live under religion... @AnnotatedBible",
  "id" : 354979338409615364,
  "in_reply_to_status_id" : 354976392049459200,
  "created_at" : "2013-07-10 15:04:04 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/YE0at8EVEj",
      "expanded_url" : "http:\/\/amzn.to\/12kCIYa",
      "display_url" : "amzn.to\/12kCIYa"
    } ]
  },
  "geo" : { },
  "id_str" : "354797327661268992",
  "text" : "finished Hell and Beyond: A Novel by Michael Phillips http:\/\/t.co\/YE0at8EVEj",
  "id" : 354797327661268992,
  "created_at" : "2013-07-10 03:00:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354767135660195841",
  "geo" : { },
  "id_str" : "354769603722883073",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater yup.",
  "id" : 354769603722883073,
  "in_reply_to_status_id" : 354767135660195841,
  "created_at" : "2013-07-10 01:10:39 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/TJROD6e1Gd",
      "expanded_url" : "http:\/\/i.imgur.com\/Fw1w2oF.jpg",
      "display_url" : "i.imgur.com\/Fw1w2oF.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "354757899660173312",
  "text" : "RT @aliceinthewater: Oh no! It's a Canadian crime wave! http:\/\/t.co\/TJROD6e1Gd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/TJROD6e1Gd",
        "expanded_url" : "http:\/\/i.imgur.com\/Fw1w2oF.jpg",
        "display_url" : "i.imgur.com\/Fw1w2oF.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "354756204993585153",
    "text" : "Oh no! It's a Canadian crime wave! http:\/\/t.co\/TJROD6e1Gd",
    "id" : 354756204993585153,
    "created_at" : "2013-07-10 00:17:24 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 354757899660173312,
  "created_at" : "2013-07-10 00:24:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Hindy, NH Psych",
      "screen_name" : "DrCarlHindy",
      "indices" : [ 3, 15 ],
      "id_str" : "30646551",
      "id" : 30646551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/bjMJbbIkvt",
      "expanded_url" : "http:\/\/inkfish.fieldofscience.com\/2013\/07\/decapitated-worms-regrow-heads-with.html",
      "display_url" : "inkfish.fieldofscience.com\/2013\/07\/decapi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354757609384972288",
  "text" : "RT @DrCarlHindy: Decapitated Worms Regrow Heads with Memories Still Inside http:\/\/t.co\/bjMJbbIkvt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.instapaper.com\/\" rel=\"nofollow\"\u003EInstapaper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/bjMJbbIkvt",
        "expanded_url" : "http:\/\/inkfish.fieldofscience.com\/2013\/07\/decapitated-worms-regrow-heads-with.html",
        "display_url" : "inkfish.fieldofscience.com\/2013\/07\/decapi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354752028838334464",
    "text" : "Decapitated Worms Regrow Heads with Memories Still Inside http:\/\/t.co\/bjMJbbIkvt",
    "id" : 354752028838334464,
    "created_at" : "2013-07-10 00:00:49 +0000",
    "user" : {
      "name" : "Carl Hindy, NH Psych",
      "screen_name" : "DrCarlHindy",
      "protected" : false,
      "id_str" : "30646551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441370742286872576\/wI8lK-G2_normal.jpeg",
      "id" : 30646551,
      "verified" : false
    }
  },
  "id" : 354757609384972288,
  "created_at" : "2013-07-10 00:22:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie Dodds",
      "screen_name" : "CarrieDodds4",
      "indices" : [ 31, 44 ],
      "id_str" : "613053701",
      "id" : 613053701
    }, {
      "name" : "Rick Warren",
      "screen_name" : "RickWarren",
      "indices" : [ 45, 56 ],
      "id_str" : "5577902",
      "id" : 5577902
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354753658388361216",
  "geo" : { },
  "id_str" : "354755782849470464",
  "in_reply_to_user_id" : 613053701,
  "text" : "USA needs #SinglePayer now! RT @CarrieDodds4 @RickWarren Insurance should not be tied to employee benefits. Problem solved.",
  "id" : 354755782849470464,
  "in_reply_to_status_id" : 354753658388361216,
  "created_at" : "2013-07-10 00:15:44 +0000",
  "in_reply_to_screen_name" : "CarrieDodds4",
  "in_reply_to_user_id_str" : "613053701",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354746467551936512",
  "geo" : { },
  "id_str" : "354747518518706179",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist oh my..lol",
  "id" : 354747518518706179,
  "in_reply_to_status_id" : 354746467551936512,
  "created_at" : "2013-07-09 23:42:54 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Santamoniker",
      "screen_name" : "Santamoniker",
      "indices" : [ 3, 16 ],
      "id_str" : "326917598",
      "id" : 326917598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354744114673221632",
  "text" : "RT @Santamoniker: Reach for your gun. SCREAM. Pull it out of holster. SCREAM. Point it at TM heart.  SCREAM.  Murder kid.  STOP SCREAMING. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zimmermantrial",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354695441813745666",
    "text" : "Reach for your gun. SCREAM. Pull it out of holster. SCREAM. Point it at TM heart.  SCREAM.  Murder kid.  STOP SCREAMING.  #zimmermantrial",
    "id" : 354695441813745666,
    "created_at" : "2013-07-09 20:15:57 +0000",
    "user" : {
      "name" : "Santamoniker",
      "screen_name" : "Santamoniker",
      "protected" : false,
      "id_str" : "326917598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734447508705796096\/Wgvhrd7S_normal.jpg",
      "id" : 326917598,
      "verified" : false
    }
  },
  "id" : 354744114673221632,
  "created_at" : "2013-07-09 23:29:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354676549284401152",
  "geo" : { },
  "id_str" : "354677310395392000",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 no, saltines. yesterday's pack had a nice golden brown trim, not overly salty.. perfect!",
  "id" : 354677310395392000,
  "in_reply_to_status_id" : 354676549284401152,
  "created_at" : "2013-07-09 19:03:55 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354675010767560704",
  "text" : "today's pack of crackers nowhere near as tasty as yesterday's pack...",
  "id" : 354675010767560704,
  "created_at" : "2013-07-09 18:54:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scarrtx",
      "screen_name" : "drdonnaATX",
      "indices" : [ 3, 14 ],
      "id_str" : "52567202",
      "id" : 52567202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sb1",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354377667149185026",
  "text" : "RT @drdonnaATX: Slut shaming? #sb1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sb1",
        "indices" : [ 14, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354377025491959809",
    "text" : "Slut shaming? #sb1",
    "id" : 354377025491959809,
    "created_at" : "2013-07-08 23:10:41 +0000",
    "user" : {
      "name" : "scarrtx",
      "screen_name" : "drdonnaATX",
      "protected" : false,
      "id_str" : "52567202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723699701011206146\/zjBas226_normal.jpg",
      "id" : 52567202,
      "verified" : false
    }
  },
  "id" : 354377667149185026,
  "created_at" : "2013-07-08 23:13:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nerdy Wonka",
      "screen_name" : "NerdyWonka",
      "indices" : [ 3, 14 ],
      "id_str" : "325265073",
      "id" : 325265073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB1",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354376388473651202",
  "text" : "RT @NerdyWonka: Man against #SB1: \"This has nothing to do with protecting women and everything to do with controlling women.\" TRUTH.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB1",
        "indices" : [ 12, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354375724364341249",
    "text" : "Man against #SB1: \"This has nothing to do with protecting women and everything to do with controlling women.\" TRUTH.",
    "id" : 354375724364341249,
    "created_at" : "2013-07-08 23:05:31 +0000",
    "user" : {
      "name" : "Nerdy Wonka",
      "screen_name" : "NerdyWonka",
      "protected" : false,
      "id_str" : "325265073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3321150452\/91262959f936ac25c801242c6304d269_normal.jpeg",
      "id" : 325265073,
      "verified" : false
    }
  },
  "id" : 354376388473651202,
  "created_at" : "2013-07-08 23:08:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354362865823657984",
  "text" : "i really like chris serino, detective (zimmerman) he's kinda hot..lol",
  "id" : 354362865823657984,
  "created_at" : "2013-07-08 22:14:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "guilty",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354361590088335361",
  "text" : "@1stCitizenKane no.. because \"those fucking punks always get away with it\" and he followed him. that's my reason. #guilty",
  "id" : 354361590088335361,
  "created_at" : "2013-07-08 22:09:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Goddess",
      "screen_name" : "drgoddess",
      "indices" : [ 0, 10 ],
      "id_str" : "19468168",
      "id" : 19468168
    }, {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 66, 78 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354348687943667713",
  "geo" : { },
  "id_str" : "354360792289771520",
  "in_reply_to_user_id" : 19468168,
  "text" : "@drgoddess plus doesnt marijuana make you mellow? not aggressive? @oceanshaman",
  "id" : 354360792289771520,
  "in_reply_to_status_id" : 354348687943667713,
  "created_at" : "2013-07-08 22:06:11 +0000",
  "in_reply_to_screen_name" : "drgoddess",
  "in_reply_to_user_id_str" : "19468168",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victoria Dahl",
      "screen_name" : "VictoriaDahl",
      "indices" : [ 3, 16 ],
      "id_str" : "15567729",
      "id" : 15567729
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB1",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354303572747358208",
  "text" : "RT @VictoriaDahl: The way to actually reduce abortions in the US? Surprise: it's birth control, birth control, FREE birth control. #SB1 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB1",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/NZMuuFkgUb",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2012\/10\/05\/study-free-birth-control-abortion-rate_n_1942621.html",
        "display_url" : "huffingtonpost.com\/2012\/10\/05\/stu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354296262557831168",
    "text" : "The way to actually reduce abortions in the US? Surprise: it's birth control, birth control, FREE birth control. #SB1 http:\/\/t.co\/NZMuuFkgUb",
    "id" : 354296262557831168,
    "created_at" : "2013-07-08 17:49:46 +0000",
    "user" : {
      "name" : "Victoria Dahl",
      "screen_name" : "VictoriaDahl",
      "protected" : false,
      "id_str" : "15567729",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683011644994105344\/bZGzbphS_normal.jpg",
      "id" : 15567729,
      "verified" : false
    }
  },
  "id" : 354303572747358208,
  "created_at" : "2013-07-08 18:18:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/VPrpQHKeao",
      "expanded_url" : "http:\/\/via.me\/-d4pjnea",
      "display_url" : "via.me\/-d4pjnea"
    } ]
  },
  "geo" : { },
  "id_str" : "354278508157075457",
  "text" : "This pack of saltines is particularly tasty. http:\/\/t.co\/VPrpQHKeao",
  "id" : 354278508157075457,
  "created_at" : "2013-07-08 16:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1pWEZ3yuKW",
      "expanded_url" : "http:\/\/www.wattpad.com\/20439708-sacred-cow-pastoral-message-about-the-food-we-eat",
      "display_url" : "wattpad.com\/20439708-sacre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354260950393700353",
  "text" : "RT @ChickenJen: I just posted 'Sacred Cow (Pastoral Message About the Food We Eat by a Maine Farmer)' on Wattpad! http:\/\/t.co\/1pWEZ3yuKW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/1pWEZ3yuKW",
        "expanded_url" : "http:\/\/www.wattpad.com\/20439708-sacred-cow-pastoral-message-about-the-food-we-eat",
        "display_url" : "wattpad.com\/20439708-sacre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354253538551021569",
    "text" : "I just posted 'Sacred Cow (Pastoral Message About the Food We Eat by a Maine Farmer)' on Wattpad! http:\/\/t.co\/1pWEZ3yuKW",
    "id" : 354253538551021569,
    "created_at" : "2013-07-08 14:59:59 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 354260950393700353,
  "created_at" : "2013-07-08 15:29:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354044630616121345",
  "geo" : { },
  "id_str" : "354046431931277315",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 love your summer hat! : )",
  "id" : 354046431931277315,
  "in_reply_to_status_id" : 354044630616121345,
  "created_at" : "2013-07-08 01:17:01 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 0, 12 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354021121932263424",
  "geo" : { },
  "id_str" : "354022468299657220",
  "in_reply_to_user_id" : 17592150,
  "text" : "@tommysalami i can recommend frozen stiff or day one for good thriller mystery",
  "id" : 354022468299657220,
  "in_reply_to_status_id" : 354021121932263424,
  "created_at" : "2013-07-07 23:41:48 +0000",
  "in_reply_to_screen_name" : "thomaspluck",
  "in_reply_to_user_id_str" : "17592150",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354021266275049474",
  "text" : "my site's been down all day.. sigh. this always happens when i get ideas...",
  "id" : 354021266275049474,
  "created_at" : "2013-07-07 23:37:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sad",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354008683467898880",
  "text" : "what happened to amanda bynes.. i used to watch \"the amanda show\". very talented young lady. #sad",
  "id" : 354008683467898880,
  "created_at" : "2013-07-07 22:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/3zMVfmTgAU",
      "expanded_url" : "http:\/\/amzn.to\/ecRLbv",
      "display_url" : "amzn.to\/ecRLbv"
    } ]
  },
  "geo" : { },
  "id_str" : "353975401380458497",
  "text" : "finished Under the Dome by Stephen King http:\/\/t.co\/3zMVfmTgAU",
  "id" : 353975401380458497,
  "created_at" : "2013-07-07 20:34:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Kvu10a89rl",
      "expanded_url" : "http:\/\/thkpr.gs\/16gniSi",
      "display_url" : "thkpr.gs\/16gniSi"
    } ]
  },
  "geo" : { },
  "id_str" : "353912330444210177",
  "text" : "RT @Floridaline: 11-Year-Old Chilean Rape Victim\u2019s Health Is In Danger Because She Can\u2019t Get An Abortion http:\/\/t.co\/Kvu10a89rl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/Kvu10a89rl",
        "expanded_url" : "http:\/\/thkpr.gs\/16gniSi",
        "display_url" : "thkpr.gs\/16gniSi"
      } ]
    },
    "geo" : { },
    "id_str" : "353904111156068352",
    "text" : "11-Year-Old Chilean Rape Victim\u2019s Health Is In Danger Because She Can\u2019t Get An Abortion http:\/\/t.co\/Kvu10a89rl",
    "id" : 353904111156068352,
    "created_at" : "2013-07-07 15:51:29 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 353912330444210177,
  "created_at" : "2013-07-07 16:24:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Some Asshole",
      "screen_name" : "assholeofday",
      "indices" : [ 0, 13 ],
      "id_str" : "1377719425",
      "id" : 1377719425
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 121, 133 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353233441690624000",
  "geo" : { },
  "id_str" : "353906650089922561",
  "in_reply_to_user_id" : 1377719425,
  "text" : "@assholeofday been watching trial but missed SF testimony. what an awful thing for MO to say (besides wrong and untrue.) @VirgoJohnny",
  "id" : 353906650089922561,
  "in_reply_to_status_id" : 353233441690624000,
  "created_at" : "2013-07-07 16:01:35 +0000",
  "in_reply_to_screen_name" : "assholeofday",
  "in_reply_to_user_id_str" : "1377719425",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iHubHost",
      "screen_name" : "iHubHost",
      "indices" : [ 0, 9 ],
      "id_str" : "44462873",
      "id" : 44462873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353905618073026561",
  "in_reply_to_user_id" : 44462873,
  "text" : "@iHubHost fyi .. my site's been down about 45 min...",
  "id" : 353905618073026561,
  "created_at" : "2013-07-07 15:57:29 +0000",
  "in_reply_to_screen_name" : "iHubHost",
  "in_reply_to_user_id_str" : "44462873",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353883991813783555",
  "in_reply_to_user_id" : 46611987,
  "text" : "@badkarmacore hey.. the forum is down..",
  "id" : 353883991813783555,
  "created_at" : "2013-07-07 14:31:33 +0000",
  "in_reply_to_screen_name" : "totohabschned",
  "in_reply_to_user_id_str" : "46611987",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jarmstrong9808\/status\/353177570096857088\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/aH7grXjYHL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOa9IPjCQAEDHVV.jpg",
      "id_str" : "353177570105245697",
      "id" : 353177570105245697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOa9IPjCQAEDHVV.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aH7grXjYHL"
    } ],
    "hashtags" : [ {
      "text" : "Fracking",
      "indices" : [ 18, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353516531533094912",
  "text" : "RT @YourAnonNews: #Fracking is not and cannot be made safe. http:\/\/t.co\/aH7grXjYHL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jarmstrong9808\/status\/353177570096857088\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/aH7grXjYHL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOa9IPjCQAEDHVV.jpg",
        "id_str" : "353177570105245697",
        "id" : 353177570105245697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOa9IPjCQAEDHVV.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aH7grXjYHL"
      } ],
      "hashtags" : [ {
        "text" : "Fracking",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353507270530834432",
    "text" : "#Fracking is not and cannot be made safe. http:\/\/t.co\/aH7grXjYHL",
    "id" : 353507270530834432,
    "created_at" : "2013-07-06 13:34:35 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787519608794157057\/dDnFKms0_normal.jpg",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 353516531533094912,
  "created_at" : "2013-07-06 14:11:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deloris",
      "screen_name" : "DMW_JD2014",
      "indices" : [ 3, 14 ],
      "id_str" : "22694866",
      "id" : 22694866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/FuYv0c25Kh",
      "expanded_url" : "http:\/\/skeweddistribution.com\/2012\/04\/03\/the-trayvon-martin-case-why-frank-taaffe-is-as-scary-as-george-zimmerman\/",
      "display_url" : "skeweddistribution.com\/2012\/04\/03\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353514403808808961",
  "text" : "RT @DMW_JD2014: The Trayvon Martin case: Why Frank Taaffe is as scary as George Zimmerman | SkewedDistribution http:\/\/t.co\/FuYv0c25Kh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/FuYv0c25Kh",
        "expanded_url" : "http:\/\/skeweddistribution.com\/2012\/04\/03\/the-trayvon-martin-case-why-frank-taaffe-is-as-scary-as-george-zimmerman\/",
        "display_url" : "skeweddistribution.com\/2012\/04\/03\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351876988933382145",
    "text" : "The Trayvon Martin case: Why Frank Taaffe is as scary as George Zimmerman | SkewedDistribution http:\/\/t.co\/FuYv0c25Kh",
    "id" : 351876988933382145,
    "created_at" : "2013-07-02 01:36:26 +0000",
    "user" : {
      "name" : "Deloris",
      "screen_name" : "DMW_JD2014",
      "protected" : false,
      "id_str" : "22694866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454709126350635008\/mLf5e54z_normal.jpeg",
      "id" : 22694866,
      "verified" : false
    }
  },
  "id" : 353514403808808961,
  "created_at" : "2013-07-06 14:02:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353291729790709761",
  "text" : "RT @AllOnMedicare: Health insurers PROFIT by delaying and denying care -- that means more time to earn $$ on invested premiums. #SinglePaye\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 109, 121 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353291518292934656",
    "text" : "Health insurers PROFIT by delaying and denying care -- that means more time to earn $$ on invested premiums. #SinglePayer #MedicareForAll",
    "id" : 353291518292934656,
    "created_at" : "2013-07-05 23:17:16 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 353291729790709761,
  "created_at" : "2013-07-05 23:18:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 19, 31 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 115, 130 ]
    }, {
      "text" : "HCR",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "p2",
      "indices" : [ 136, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/vQMEzINIbr",
      "expanded_url" : "http:\/\/www.news-press.com\/article\/20130705\/OPINION\/307050017\/Cure-health-coverage-single-payer-system",
      "display_url" : "news-press.com\/article\/201307\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353290853818703873",
  "text" : "RT @AllOnMedicare: #SinglePayer is the cure for the insanity of our health care non-system: http:\/\/t.co\/vQMEzINIbr #MedicareForAll #HCR #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 96, 111 ]
      }, {
        "text" : "HCR",
        "indices" : [ 112, 116 ]
      }, {
        "text" : "p2",
        "indices" : [ 117, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/vQMEzINIbr",
        "expanded_url" : "http:\/\/www.news-press.com\/article\/20130705\/OPINION\/307050017\/Cure-health-coverage-single-payer-system",
        "display_url" : "news-press.com\/article\/201307\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "353284971462524929",
    "text" : "#SinglePayer is the cure for the insanity of our health care non-system: http:\/\/t.co\/vQMEzINIbr #MedicareForAll #HCR #p2",
    "id" : 353284971462524929,
    "created_at" : "2013-07-05 22:51:15 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 353290853818703873,
  "created_at" : "2013-07-05 23:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/A9amlOVhlG",
      "expanded_url" : "http:\/\/www.addictinginfo.org\/2013\/07\/04\/oregon-legislature-unanimously-passes-tuition-free-higher-education\/",
      "display_url" : "addictinginfo.org\/2013\/07\/04\/ore\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "353222237651873792",
  "text" : "Oregon Legislature Unanimously Passes Tuition Free Higher Education http:\/\/t.co\/A9amlOVhlG",
  "id" : 353222237651873792,
  "created_at" : "2013-07-05 18:41:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353212701410996227",
  "geo" : { },
  "id_str" : "353218356565917696",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 LOLOL ; )",
  "id" : 353218356565917696,
  "in_reply_to_status_id" : 353212701410996227,
  "created_at" : "2013-07-05 18:26:33 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "353209508354473985",
  "geo" : { },
  "id_str" : "353217769313026048",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 my whole body got hot like when im nauseous but i wasnt.. but i didnt feel \"right\" either. happened B4 1 or 2x. weird.",
  "id" : 353217769313026048,
  "in_reply_to_status_id" : 353209508354473985,
  "created_at" : "2013-07-05 18:24:13 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353208966764953600",
  "text" : "feeling off today. woke up during night w my feet hot.",
  "id" : 353208966764953600,
  "created_at" : "2013-07-05 17:49:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/z7Y02WYpJT",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/uiT",
      "display_url" : "omgf.ac\/ts\/uiT"
    } ]
  },
  "geo" : { },
  "id_str" : "353156753715769344",
  "text" : "RT @OMGFacts: Singapore has the highest ratio of millionaires in the world! Details ---&gt; http:\/\/t.co\/z7Y02WYpJT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/z7Y02WYpJT",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/uiT",
        "display_url" : "omgf.ac\/ts\/uiT"
      } ]
    },
    "geo" : { },
    "id_str" : "353137413348003843",
    "text" : "Singapore has the highest ratio of millionaires in the world! Details ---&gt; http:\/\/t.co\/z7Y02WYpJT",
    "id" : 353137413348003843,
    "created_at" : "2013-07-05 13:04:54 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 353156753715769344,
  "created_at" : "2013-07-05 14:21:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 7, 14 ]
    }, {
      "text" : "ereader",
      "indices" : [ 58, 66 ]
    }, {
      "text" : "eink",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352784048281763841",
  "text" : "PSA: a #Kindle Fire is NOT an ereader! It is a tablet. An #ereader uses #eink specifically for ease of reading. Thank you.",
  "id" : 352784048281763841,
  "created_at" : "2013-07-04 13:40:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352782914645278720",
  "text" : "RT @Matth3ous: 'Independence Day' my ass. Wake up, people. We're not free. Annuit Coeptis my ass.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352779000709525505",
    "text" : "'Independence Day' my ass. Wake up, people. We're not free. Annuit Coeptis my ass.",
    "id" : 352779000709525505,
    "created_at" : "2013-07-04 13:20:42 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 352782914645278720,
  "created_at" : "2013-07-04 13:36:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352566902456987651",
  "geo" : { },
  "id_str" : "352568583357870080",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits exactly!",
  "id" : 352568583357870080,
  "in_reply_to_status_id" : 352566902456987651,
  "created_at" : "2013-07-03 23:24:35 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morten Bj\u00F8rklund",
      "screen_name" : "Mortenrb",
      "indices" : [ 17, 26 ],
      "id_str" : "38948326",
      "id" : 38948326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352546500234051584",
  "text" : "so happy for you @Mortenrb &lt;3 .. i knew things would work out : )",
  "id" : 352546500234051584,
  "created_at" : "2013-07-03 21:56:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 3, 17 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "txlege",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352538730332045313",
  "text" : "RT @thinkprogress: It's NOT just about the 20-week abortion ban: What the media is missing about Texas' ongoing abortion battle #txlege htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "txlege",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/7CuZ6V3eOa",
        "expanded_url" : "http:\/\/thkpr.gs\/1666Xj4",
        "display_url" : "thkpr.gs\/1666Xj4"
      } ]
    },
    "geo" : { },
    "id_str" : "352497413820395520",
    "text" : "It's NOT just about the 20-week abortion ban: What the media is missing about Texas' ongoing abortion battle #txlege http:\/\/t.co\/7CuZ6V3eOa",
    "id" : 352497413820395520,
    "created_at" : "2013-07-03 18:41:47 +0000",
    "user" : {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "protected" : false,
      "id_str" : "55355654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762609394265632768\/H_UR_W7r_normal.jpg",
      "id" : 55355654,
      "verified" : true
    }
  },
  "id" : 352538730332045313,
  "created_at" : "2013-07-03 21:25:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352521212934627332",
  "text" : "RT @PNHP: Wouldn't happen under #singlepayer system, where decisions are federal. MT @TPHealth: Texas advances abortion bill http:\/\/t.co\/GX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 22, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/GXOdRPS5pP",
        "expanded_url" : "http:\/\/thkpr.gs\/12FLPC1",
        "display_url" : "thkpr.gs\/12FLPC1"
      } ]
    },
    "geo" : { },
    "id_str" : "352486337556922369",
    "text" : "Wouldn't happen under #singlepayer system, where decisions are federal. MT @TPHealth: Texas advances abortion bill http:\/\/t.co\/GXOdRPS5pP",
    "id" : 352486337556922369,
    "created_at" : "2013-07-03 17:57:46 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 352521212934627332,
  "created_at" : "2013-07-03 20:16:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron White",
      "screen_name" : "Ron_White",
      "indices" : [ 3, 13 ],
      "id_str" : "18312897",
      "id" : 18312897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352493456230322176",
  "text" : "RT @Ron_White: I think I have a cataract on my third eye",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352488613495316480",
    "text" : "I think I have a cataract on my third eye",
    "id" : 352488613495316480,
    "created_at" : "2013-07-03 18:06:49 +0000",
    "user" : {
      "name" : "Ron White",
      "screen_name" : "Ron_White",
      "protected" : false,
      "id_str" : "18312897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535163951030747136\/iEKqbSDU_normal.jpeg",
      "id" : 18312897,
      "verified" : true
    }
  },
  "id" : 352493456230322176,
  "created_at" : "2013-07-03 18:26:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Carol Oates",
      "screen_name" : "JoyceCarolOates",
      "indices" : [ 3, 19 ],
      "id_str" : "845743333",
      "id" : 845743333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352467093704290304",
  "text" : "RT @JoyceCarolOates: if my Twitter world were the actual world, very liberal\/ leftward-leaning &amp; enlightened society safe haven for animals\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352191310020616193",
    "text" : "if my Twitter world were the actual world, very liberal\/ leftward-leaning &amp; enlightened society safe haven for animals &amp; poets.  If only!",
    "id" : 352191310020616193,
    "created_at" : "2013-07-02 22:25:26 +0000",
    "user" : {
      "name" : "Joyce Carol Oates",
      "screen_name" : "JoyceCarolOates",
      "protected" : false,
      "id_str" : "845743333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2683616680\/ca8aa195d2ccc38da6800678a9d2ae8a_normal.png",
      "id" : 845743333,
      "verified" : true
    }
  },
  "id" : 352467093704290304,
  "created_at" : "2013-07-03 16:41:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Ryssdal",
      "screen_name" : "kairyssdal",
      "indices" : [ 3, 14 ],
      "id_str" : "30013010",
      "id" : 30013010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352465916702892032",
  "text" : "RT @kairyssdal: Ummm....? \"Postal Service computers photograph exterior of every piece of paper mail processed in the United States\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Htgwjr9b5p",
        "expanded_url" : "http:\/\/nyti.ms\/11gH2ci",
        "display_url" : "nyti.ms\/11gH2ci"
      } ]
    },
    "geo" : { },
    "id_str" : "352464877949960192",
    "text" : "Ummm....? \"Postal Service computers photograph exterior of every piece of paper mail processed in the United States\" http:\/\/t.co\/Htgwjr9b5p",
    "id" : 352464877949960192,
    "created_at" : "2013-07-03 16:32:30 +0000",
    "user" : {
      "name" : "Kai Ryssdal",
      "screen_name" : "kairyssdal",
      "protected" : false,
      "id_str" : "30013010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636949578483273728\/CeMflj1z_normal.jpg",
      "id" : 30013010,
      "verified" : true
    }
  },
  "id" : 352465916702892032,
  "created_at" : "2013-07-03 16:36:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zimmermantrial",
      "indices" : [ 48, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352465467601977346",
  "text" : "im sooo glad he asked her to point at wall..lol #zimmermantrial .. im neurotic about pointing unloaded guns at ppl.",
  "id" : 352465467601977346,
  "created_at" : "2013-07-03 16:34:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cranky Fat Feminist",
      "screen_name" : "crankyfatfem",
      "indices" : [ 3, 16 ],
      "id_str" : "516213890",
      "id" : 516213890
    }, {
      "name" : "Planned Parenthood",
      "screen_name" : "PPHP",
      "indices" : [ 21, 26 ],
      "id_str" : "50337129",
      "id" : 50337129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ncga",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "hb695",
      "indices" : [ 106, 112 ]
    }, {
      "text" : "ncpol",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/2rLwvglNgK",
      "expanded_url" : "http:\/\/ow.ly\/mCEHe",
      "display_url" : "ow.ly\/mCEHe"
    } ]
  },
  "geo" : { },
  "id_str" : "352449887759114240",
  "text" : "RT @crankyfatfem: RT @PPHP Uh oh, North Carolina is trying to pull a Texas: http:\/\/t.co\/2rLwvglNgK #ncga, #hb695, #ncpol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Planned Parenthood",
        "screen_name" : "PPHP",
        "indices" : [ 3, 8 ],
        "id_str" : "50337129",
        "id" : 50337129
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ncga",
        "indices" : [ 81, 86 ]
      }, {
        "text" : "hb695",
        "indices" : [ 88, 94 ]
      }, {
        "text" : "ncpol",
        "indices" : [ 96, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/2rLwvglNgK",
        "expanded_url" : "http:\/\/ow.ly\/mCEHe",
        "display_url" : "ow.ly\/mCEHe"
      } ]
    },
    "geo" : { },
    "id_str" : "352445823520473088",
    "text" : "RT @PPHP Uh oh, North Carolina is trying to pull a Texas: http:\/\/t.co\/2rLwvglNgK #ncga, #hb695, #ncpol",
    "id" : 352445823520473088,
    "created_at" : "2013-07-03 15:16:47 +0000",
    "user" : {
      "name" : "Cranky Fat Feminist",
      "screen_name" : "crankyfatfem",
      "protected" : false,
      "id_str" : "516213890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432663533709312000\/RraspAS4_normal.jpeg",
      "id" : 516213890,
      "verified" : false
    }
  },
  "id" : 352449887759114240,
  "created_at" : "2013-07-03 15:32:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 2, 14 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352431069351510016",
  "geo" : { },
  "id_str" : "352447983104696321",
  "in_reply_to_user_id" : 45674330,
  "text" : ". @oceanshaman as someone who grew up very shy and didnt fit in.. this hits home. #kindness",
  "id" : 352447983104696321,
  "in_reply_to_status_id" : 352431069351510016,
  "created_at" : "2013-07-03 15:25:22 +0000",
  "in_reply_to_screen_name" : "oceanshaman",
  "in_reply_to_user_id_str" : "45674330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/bETkK2iXGC",
      "expanded_url" : "http:\/\/bit.ly\/10zm31M",
      "display_url" : "bit.ly\/10zm31M"
    } ]
  },
  "geo" : { },
  "id_str" : "352446743788523521",
  "text" : "RT @oceanshaman: The Nice Guy: Trayvon Martin Was One Of The Few People Who Didn't Tease Rachel Jeantel (DETAILS) http:\/\/t.co\/bETkK2iXGC vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Global Grind",
        "screen_name" : "GlobalGrind",
        "indices" : [ 124, 136 ],
        "id_str" : "1496971",
        "id" : 1496971
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/bETkK2iXGC",
        "expanded_url" : "http:\/\/bit.ly\/10zm31M",
        "display_url" : "bit.ly\/10zm31M"
      } ]
    },
    "geo" : { },
    "id_str" : "352431069351510016",
    "text" : "The Nice Guy: Trayvon Martin Was One Of The Few People Who Didn't Tease Rachel Jeantel (DETAILS) http:\/\/t.co\/bETkK2iXGC via @globalgrind",
    "id" : 352431069351510016,
    "created_at" : "2013-07-03 14:18:09 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 352446743788523521,
  "created_at" : "2013-07-03 15:20:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NGs_Calibreforum",
      "screen_name" : "Calibreforum",
      "indices" : [ 12, 25 ],
      "id_str" : "57641627",
      "id" : 57641627
    }, {
      "name" : "JW Manus",
      "screen_name" : "JWManus",
      "indices" : [ 56, 64 ],
      "id_str" : "305152778",
      "id" : 305152778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "calibre",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/pVd3vfiygz",
      "expanded_url" : "http:\/\/wp.me\/p1lBQ4-OE",
      "display_url" : "wp.me\/p1lBQ4-OE"
    } ]
  },
  "in_reply_to_status_id_str" : "352435122714316804",
  "geo" : { },
  "id_str" : "352444068829204480",
  "in_reply_to_user_id" : 305152778,
  "text" : "did you let @Calibreforum know about issue? #calibre RT @JWManus Calibre and Kindle, Not a Good Match http:\/\/t.co\/pVd3vfiygz",
  "id" : 352444068829204480,
  "in_reply_to_status_id" : 352435122714316804,
  "created_at" : "2013-07-03 15:09:48 +0000",
  "in_reply_to_screen_name" : "JWManus",
  "in_reply_to_user_id_str" : "305152778",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352236072442400768",
  "geo" : { },
  "id_str" : "352439085589213186",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste not bad at all..lol. I felt like I was there. : )",
  "id" : 352439085589213186,
  "in_reply_to_status_id" : 352236072442400768,
  "created_at" : "2013-07-03 14:50:00 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "indices" : [ 3, 18 ],
      "id_str" : "46822887",
      "id" : 46822887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HB2",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352233957263294465",
  "text" : "RT @AngryBlackLady: No one should be forced to abort. No one should be forced to carry to term. It really is that simple. #HB2 #StandWithTe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HB2",
        "indices" : [ 102, 106 ]
      }, {
        "text" : "StandWithTexasWomen",
        "indices" : [ 107, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352230076043104257",
    "text" : "No one should be forced to abort. No one should be forced to carry to term. It really is that simple. #HB2 #StandWithTexasWomen",
    "id" : 352230076043104257,
    "created_at" : "2013-07-03 00:59:28 +0000",
    "user" : {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "protected" : false,
      "id_str" : "46822887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790644001330171904\/E3uUevS__normal.jpg",
      "id" : 46822887,
      "verified" : true
    }
  },
  "id" : 352233957263294465,
  "created_at" : "2013-07-03 01:14:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 22, 35 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PisseArtiste\/status\/352224439024381952\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/h5fkcIadzA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BONaQtnCcAAAtc9.jpg",
      "id_str" : "352224439032770560",
      "id" : 352224439032770560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BONaQtnCcAAAtc9.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/h5fkcIadzA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352224439024381952",
  "geo" : { },
  "id_str" : "352231568095449088",
  "in_reply_to_user_id" : 25221139,
  "text" : "sooo needed this.. RT @PisseArtiste Sunset over the marina. Pretty beautiful evening overall. http:\/\/t.co\/h5fkcIadzA",
  "id" : 352231568095449088,
  "in_reply_to_status_id" : 352224439024381952,
  "created_at" : "2013-07-03 01:05:24 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 0, 10 ],
      "id_str" : "89621202",
      "id" : 89621202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352223463374725120",
  "geo" : { },
  "id_str" : "352224194236391425",
  "in_reply_to_user_id" : 89621202,
  "text" : "@joyceetta yes.. and rachel. i wanted to hug her.",
  "id" : 352224194236391425,
  "in_reply_to_status_id" : 352223463374725120,
  "created_at" : "2013-07-03 00:36:06 +0000",
  "in_reply_to_screen_name" : "joyceetta",
  "in_reply_to_user_id_str" : "89621202",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 0, 10 ],
      "id_str" : "89621202",
      "id" : 89621202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352217156731142144",
  "geo" : { },
  "id_str" : "352222937203478530",
  "in_reply_to_user_id" : 89621202,
  "text" : "@joyceetta im just so angry i cant see straight. been reading too many pro GZ comments today... : (",
  "id" : 352222937203478530,
  "in_reply_to_status_id" : 352217156731142144,
  "created_at" : "2013-07-03 00:31:06 +0000",
  "in_reply_to_screen_name" : "joyceetta",
  "in_reply_to_user_id_str" : "89621202",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352214563866943488",
  "geo" : { },
  "id_str" : "352214936711213057",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind love it! (poor Pluto)",
  "id" : 352214936711213057,
  "in_reply_to_status_id" : 352214563866943488,
  "created_at" : "2013-07-02 23:59:19 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352214761754206208",
  "text" : "RT @ZachsMind: so. corporations are people, unborn fetuses are people. Being people don't mean what it used to mean. Kinda like Pluto not b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352214563866943488",
    "text" : "so. corporations are people, unborn fetuses are people. Being people don't mean what it used to mean. Kinda like Pluto not being a planet.",
    "id" : 352214563866943488,
    "created_at" : "2013-07-02 23:57:50 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 352214761754206208,
  "created_at" : "2013-07-02 23:58:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 65, 75 ],
      "id_str" : "89621202",
      "id" : 89621202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zimmerman",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352213543808020480",
  "geo" : { },
  "id_str" : "352214517876400128",
  "in_reply_to_user_id" : 89621202,
  "text" : "regardless of gun, he pursued an innocent, created situation. RT @joyceetta Why did #Zimmerman have a gun? he had a violent past",
  "id" : 352214517876400128,
  "in_reply_to_status_id" : 352213543808020480,
  "created_at" : "2013-07-02 23:57:39 +0000",
  "in_reply_to_screen_name" : "joyceetta",
  "in_reply_to_user_id_str" : "89621202",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kdawg",
      "screen_name" : "kdawg0113",
      "indices" : [ 3, 13 ],
      "id_str" : "56578667",
      "id" : 56578667
    }, {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 18, 34 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352213987804463104",
  "text" : "RT @kdawg0113: .  @aliceinthewater We also need to talk about the poverty shaming (both genders)  can't afford a kid, don't have sexual.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "aliceinthewater",
        "screen_name" : "aliceinthewater",
        "indices" : [ 3, 19 ],
        "id_str" : "17489079",
        "id" : 17489079
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "352212790309687296",
    "geo" : { },
    "id_str" : "352213462816010242",
    "in_reply_to_user_id" : 17489079,
    "text" : ".  @aliceinthewater We also need to talk about the poverty shaming (both genders)  can't afford a kid, don't have sexual.",
    "id" : 352213462816010242,
    "in_reply_to_status_id" : 352212790309687296,
    "created_at" : "2013-07-02 23:53:28 +0000",
    "in_reply_to_screen_name" : "aliceinthewater",
    "in_reply_to_user_id_str" : "17489079",
    "user" : {
      "name" : "kdawg",
      "screen_name" : "kdawg0113",
      "protected" : false,
      "id_str" : "56578667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656196103419875328\/hbr0z0bG_normal.jpg",
      "id" : 56578667,
      "verified" : false
    }
  },
  "id" : 352213987804463104,
  "created_at" : "2013-07-02 23:55:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352212790309687296",
  "geo" : { },
  "id_str" : "352213814885875714",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater another peeve of mine.. slut-shaming, fat-shaming...",
  "id" : 352213814885875714,
  "in_reply_to_status_id" : 352212790309687296,
  "created_at" : "2013-07-02 23:54:51 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352211602763812866",
  "text" : "instead of all this money going overseas \"rebuilding\" .. ppl could be fed and cared for. tech so much advanced!",
  "id" : 352211602763812866,
  "created_at" : "2013-07-02 23:46:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352211321946779648",
  "text" : ".. and health insurance.. omg.. what a frickin scam! they are dictators that can change the rules (what is covered) anytime. arggg",
  "id" : 352211321946779648,
  "created_at" : "2013-07-02 23:44:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheriffFruitfly",
      "screen_name" : "sherifffruitfly",
      "indices" : [ 3, 19 ],
      "id_str" : "19052381",
      "id" : 19052381
    }, {
      "name" : "ResistTrump",
      "screen_name" : "liberalandold",
      "indices" : [ 24, 38 ],
      "id_str" : "196640692",
      "id" : 196640692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zimmermantrial",
      "indices" : [ 80, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352209091390734336",
  "text" : "RT @sherifffruitfly: RT @liberalandold: There are some scary white folks on the #zimmermantrial timeline\/\/ which is why trayvon is dead",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ResistTrump",
        "screen_name" : "liberalandold",
        "indices" : [ 3, 17 ],
        "id_str" : "196640692",
        "id" : 196640692
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zimmermantrial",
        "indices" : [ 59, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352206363692249090",
    "text" : "RT @liberalandold: There are some scary white folks on the #zimmermantrial timeline\/\/ which is why trayvon is dead",
    "id" : 352206363692249090,
    "created_at" : "2013-07-02 23:25:15 +0000",
    "user" : {
      "name" : "SheriffFruitfly",
      "screen_name" : "sherifffruitfly",
      "protected" : false,
      "id_str" : "19052381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739119427564642306\/kfwtzRtA_normal.jpg",
      "id" : 19052381,
      "verified" : false
    }
  },
  "id" : 352209091390734336,
  "created_at" : "2013-07-02 23:36:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trial",
      "indices" : [ 38, 44 ]
    }, {
      "text" : "imsoangry",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352207982894919681",
  "text" : "family might remove me from tv area.. #trial #imsoangry",
  "id" : 352207982894919681,
  "created_at" : "2013-07-02 23:31:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352201791376605185",
  "text" : "RT @Floridaline: Scalia's Son Says Homosexuality Doesn't Exist, Plans to Address Group that Encourages Lifelong Abstinence for Gays http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/5K3jMo48PW",
        "expanded_url" : "http:\/\/www.rightwingwatch.org\/content\/scalias-son-says-homosexuality-doesnt-exist-plans-address-group-encourages-lifelong-abstinen",
        "display_url" : "rightwingwatch.org\/content\/scalia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352189108619186178",
    "text" : "Scalia's Son Says Homosexuality Doesn't Exist, Plans to Address Group that Encourages Lifelong Abstinence for Gays http:\/\/t.co\/5K3jMo48PW",
    "id" : 352189108619186178,
    "created_at" : "2013-07-02 22:16:41 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 352201791376605185,
  "created_at" : "2013-07-02 23:07:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 0, 10 ],
      "id_str" : "89621202",
      "id" : 89621202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "352175544873402369",
  "geo" : { },
  "id_str" : "352178538155225090",
  "in_reply_to_user_id" : 89621202,
  "text" : "@joyceetta absolutely. i am stunned at the ppl that think GZ innocent of wrongdoing.",
  "id" : 352178538155225090,
  "in_reply_to_status_id" : 352175544873402369,
  "created_at" : "2013-07-02 21:34:41 +0000",
  "in_reply_to_screen_name" : "joyceetta",
  "in_reply_to_user_id_str" : "89621202",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "indices" : [ 3, 12 ],
      "id_str" : "394134197",
      "id" : 394134197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352175732207779840",
  "text" : "RT @mfpenney: Why Have Student Loans At All? Get the Burdens of Debt off College Students' Backs -- Make Wall St. Pick Up the Tab - http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/mcdTj5e2cv",
        "expanded_url" : "http:\/\/ow.ly\/mAcW7",
        "display_url" : "ow.ly\/mAcW7"
      } ]
    },
    "geo" : { },
    "id_str" : "352171692577132544",
    "text" : "Why Have Student Loans At All? Get the Burdens of Debt off College Students' Backs -- Make Wall St. Pick Up the Tab - http:\/\/t.co\/mcdTj5e2cv",
    "id" : 352171692577132544,
    "created_at" : "2013-07-02 21:07:29 +0000",
    "user" : {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "protected" : false,
      "id_str" : "394134197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596470057\/DSCN0545_normal.jpg",
      "id" : 394134197,
      "verified" : false
    }
  },
  "id" : 352175732207779840,
  "created_at" : "2013-07-02 21:23:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ihQ9FJUopa",
      "expanded_url" : "http:\/\/shar.es\/ApoJI",
      "display_url" : "shar.es\/ApoJI"
    } ]
  },
  "geo" : { },
  "id_str" : "352170435238047745",
  "text" : "Hundreds of Geese \u2018Rounded Up\u2019 to be Killed in New York\u2019s Jamaica Bay (+Video) http:\/\/t.co\/ihQ9FJUopa",
  "id" : 352170435238047745,
  "created_at" : "2013-07-02 21:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee Foster",
      "screen_name" : "Renegadepr2000",
      "indices" : [ 3, 18 ],
      "id_str" : "16725388",
      "id" : 16725388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352154268469432320",
  "text" : "RT @Renegadepr2000: Thou shall not kill: \"Do you regret getting out the car and following Trayvon that night?\"Zimmerman:\"No sir..I feel lik\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352142559079964674",
    "text" : "Thou shall not kill: \"Do you regret getting out the car and following Trayvon that night?\"Zimmerman:\"No sir..I feel like it was God's plan.\"",
    "id" : 352142559079964674,
    "created_at" : "2013-07-02 19:11:43 +0000",
    "user" : {
      "name" : "Renee Foster",
      "screen_name" : "Renegadepr2000",
      "protected" : false,
      "id_str" : "16725388",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685111030909919232\/93n08kak_normal.jpg",
      "id" : 16725388,
      "verified" : false
    }
  },
  "id" : 352154268469432320,
  "created_at" : "2013-07-02 19:58:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Top Conservative Cat",
      "screen_name" : "TeaPartyCat",
      "indices" : [ 3, 15 ],
      "id_str" : "27754737",
      "id" : 27754737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352078682279518209",
  "text" : "RT @TeaPartyCat: Zimmerman's lawyers are determined to get Trayvon Martin convicted of \"suspicion\", because that's what this is all about. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zimmermantrial",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352076039498907649",
    "text" : "Zimmerman's lawyers are determined to get Trayvon Martin convicted of \"suspicion\", because that's what this is all about. #zimmermantrial",
    "id" : 352076039498907649,
    "created_at" : "2013-07-02 14:47:23 +0000",
    "user" : {
      "name" : "Top Conservative Cat",
      "screen_name" : "TeaPartyCat",
      "protected" : false,
      "id_str" : "27754737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000407713006\/fa28c8a5f59d5e6667c45a4269798bda_normal.jpeg",
      "id" : 27754737,
      "verified" : false
    }
  },
  "id" : 352078682279518209,
  "created_at" : "2013-07-02 14:57:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 100, 109 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/9Lraf67m1r",
      "expanded_url" : "http:\/\/www.upworthy.com\/fox-news-spends-6-minutes-describing-why-mr-rogers-was-an-evil-evil-man-5?g=2&c=ufb1",
      "display_url" : "upworthy.com\/fox-news-spend\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352077640691232768",
  "text" : "RT @atheistlady76: Fox News spends 6 minutes describing why Mr. Rogers was an \"evil, evil man\" (via @Upworthy) http:\/\/t.co\/9Lraf67m1r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Upworthy",
        "screen_name" : "Upworthy",
        "indices" : [ 81, 90 ],
        "id_str" : "524396430",
        "id" : 524396430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/9Lraf67m1r",
        "expanded_url" : "http:\/\/www.upworthy.com\/fox-news-spends-6-minutes-describing-why-mr-rogers-was-an-evil-evil-man-5?g=2&c=ufb1",
        "display_url" : "upworthy.com\/fox-news-spend\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352070336033980417",
    "text" : "Fox News spends 6 minutes describing why Mr. Rogers was an \"evil, evil man\" (via @Upworthy) http:\/\/t.co\/9Lraf67m1r",
    "id" : 352070336033980417,
    "created_at" : "2013-07-02 14:24:43 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 352077640691232768,
  "created_at" : "2013-07-02 14:53:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I voted for Hillary",
      "screen_name" : "utbrp",
      "indices" : [ 3, 9 ],
      "id_str" : "21356559",
      "id" : 21356559
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zimmerman",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "HeroComplex",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352072032537690112",
  "text" : "RT @utbrp: In #Zimmerman's head, he's really a cop who was involved in a justifiable shooting, therefore the calmness #HeroComplex",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zimmerman",
        "indices" : [ 3, 13 ]
      }, {
        "text" : "HeroComplex",
        "indices" : [ 107, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352051165430689792",
    "text" : "In #Zimmerman's head, he's really a cop who was involved in a justifiable shooting, therefore the calmness #HeroComplex",
    "id" : 352051165430689792,
    "created_at" : "2013-07-02 13:08:33 +0000",
    "user" : {
      "name" : "I voted for Hillary",
      "screen_name" : "utbrp",
      "protected" : false,
      "id_str" : "21356559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796313072885448704\/DB-K1dUr_normal.jpg",
      "id" : 21356559,
      "verified" : false
    }
  },
  "id" : 352072032537690112,
  "created_at" : "2013-07-02 14:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Freeman",
      "screen_name" : "BigDaddy978",
      "indices" : [ 3, 15 ],
      "id_str" : "24060856",
      "id" : 24060856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zimmerman",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352071805663584256",
  "text" : "RT @BigDaddy978: #Zimmerman defense analogy: Hunter stalks deer. Deer kicks hunter. Hunter kills deer. The hunter acted in self defense. #P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zimmerman",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "P2",
        "indices" : [ 120, 123 ]
      }, {
        "text" : "tcot",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352054354557149186",
    "text" : "#Zimmerman defense analogy: Hunter stalks deer. Deer kicks hunter. Hunter kills deer. The hunter acted in self defense. #P2 #tcot",
    "id" : 352054354557149186,
    "created_at" : "2013-07-02 13:21:13 +0000",
    "user" : {
      "name" : "Rich Freeman",
      "screen_name" : "BigDaddy978",
      "protected" : false,
      "id_str" : "24060856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/323854694\/DSCF0171b_normal.JPG",
      "id" : 24060856,
      "verified" : false
    }
  },
  "id" : 352071805663584256,
  "created_at" : "2013-07-02 14:30:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberley Johnson",
      "screen_name" : "AuthorKimberley",
      "indices" : [ 3, 19 ],
      "id_str" : "198357693",
      "id" : 198357693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/dO83JU1jRQ",
      "expanded_url" : "http:\/\/tinyurl.com\/q57v2va",
      "display_url" : "tinyurl.com\/q57v2va"
    } ]
  },
  "geo" : { },
  "id_str" : "351829627641139201",
  "text" : "RT @AuthorKimberley: Ohio Simultaneously Makes It Harder to  Prevent a Pregnancy and Harder to Terminate One http:\/\/t.co\/dO83JU1jRQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/dO83JU1jRQ",
        "expanded_url" : "http:\/\/tinyurl.com\/q57v2va",
        "display_url" : "tinyurl.com\/q57v2va"
      } ]
    },
    "geo" : { },
    "id_str" : "351825992635002880",
    "text" : "Ohio Simultaneously Makes It Harder to  Prevent a Pregnancy and Harder to Terminate One http:\/\/t.co\/dO83JU1jRQ",
    "id" : 351825992635002880,
    "created_at" : "2013-07-01 22:13:47 +0000",
    "user" : {
      "name" : "Kimberley Johnson",
      "screen_name" : "AuthorKimberley",
      "protected" : false,
      "id_str" : "198357693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785281972687953921\/PtDQ5_jf_normal.jpg",
      "id" : 198357693,
      "verified" : false
    }
  },
  "id" : 351829627641139201,
  "created_at" : "2013-07-01 22:28:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 52, 62 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/FB6PMJ82PL",
      "expanded_url" : "http:\/\/wp.me\/pzgRU-jy",
      "display_url" : "wp.me\/pzgRU-jy"
    } ]
  },
  "geo" : { },
  "id_str" : "351829337340772353",
  "text" : "Standing Still Part Two  http:\/\/t.co\/FB6PMJ82PL via @ZachsMind",
  "id" : 351829337340772353,
  "created_at" : "2013-07-01 22:27:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zimmerman",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "trayvon",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "J4TM",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Q1PP8RPkxR",
      "expanded_url" : "http:\/\/womenincrimeink.blogspot.com\/2013\/07\/what-exactly-is-george-zimmerman-guilty.html",
      "display_url" : "womenincrimeink.blogspot.com\/2013\/07\/what-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351828797357699072",
  "text" : "What do you think, peeps? &gt;&gt; What Exactly is George #Zimmerman Guilty of? http:\/\/t.co\/Q1PP8RPkxR #trayvon #J4TM",
  "id" : 351828797357699072,
  "created_at" : "2013-07-01 22:24:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Steve K. McCoy",
      "screen_name" : "stevekmccoy",
      "indices" : [ 87, 99 ],
      "id_str" : "11041262",
      "id" : 11041262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351826783747833857",
  "text" : "RT @micahjmurray: This is \"Reformed\" teaching? Sounds like a terrible religion!  \/\/ RT @stevekmccoy Teach your children they are broken. De\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve K. McCoy",
        "screen_name" : "stevekmccoy",
        "indices" : [ 69, 81 ],
        "id_str" : "11041262",
        "id" : 11041262
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "351773588807892992",
    "geo" : { },
    "id_str" : "351823677244968960",
    "in_reply_to_user_id" : 11041262,
    "text" : "This is \"Reformed\" teaching? Sounds like a terrible religion!  \/\/ RT @stevekmccoy Teach your children they are broken. Deeply broken.",
    "id" : 351823677244968960,
    "in_reply_to_status_id" : 351773588807892992,
    "created_at" : "2013-07-01 22:04:35 +0000",
    "in_reply_to_screen_name" : "stevekmccoy",
    "in_reply_to_user_id_str" : "11041262",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 351826783747833857,
  "created_at" : "2013-07-01 22:16:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351825214486740992",
  "text" : "((headtodesk)) i read the comments.. stupid, stupid, stupid!!",
  "id" : 351825214486740992,
  "created_at" : "2013-07-01 22:10:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "indices" : [ 3, 18 ],
      "id_str" : "24165761",
      "id" : 24165761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351820976075440129",
  "text" : "RT @MichaelSkolnik: Re: screaming for help on 911 call: Serino: That\u2019s you. Are you hearing yourself?\nZimmerman: Um, it doesn\u2019t sound like \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ZimmermanTrial",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351793265651101697",
    "text" : "Re: screaming for help on 911 call: Serino: That\u2019s you. Are you hearing yourself?\nZimmerman: Um, it doesn\u2019t sound like me. #ZimmermanTrial",
    "id" : 351793265651101697,
    "created_at" : "2013-07-01 20:03:45 +0000",
    "user" : {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "protected" : false,
      "id_str" : "24165761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738364600220045313\/L-103cVr_normal.jpg",
      "id" : 24165761,
      "verified" : true
    }
  },
  "id" : 351820976075440129,
  "created_at" : "2013-07-01 21:53:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351819518600937472",
  "text" : "RT @TimGreaton: \"Bones in the Tree\" is not just a comical dating story. It's about the lasting friendship of a woman and a squirrel. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/IaDIsK7yu3",
        "expanded_url" : "http:\/\/amzn.to\/12ZsZ7i",
        "display_url" : "amzn.to\/12ZsZ7i"
      } ]
    },
    "geo" : { },
    "id_str" : "351818548491976705",
    "text" : "\"Bones in the Tree\" is not just a comical dating story. It's about the lasting friendship of a woman and a squirrel. http:\/\/t.co\/IaDIsK7yu3",
    "id" : 351818548491976705,
    "created_at" : "2013-07-01 21:44:13 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 351819518600937472,
  "created_at" : "2013-07-01 21:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Koji Mizuno",
      "screen_name" : "Ijok1998",
      "indices" : [ 3, 12 ],
      "id_str" : "571269666",
      "id" : 571269666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zimmermantrial",
      "indices" : [ 14, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351811067652997121",
  "text" : "RT @Ijok1998: #zimmermantrial So Serino the only cop who actually questioned Police findings immediately demoted! Smh! http:\/\/t.co\/TR8iDzfs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zimmermantrial",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/TR8iDzfszw",
        "expanded_url" : "http:\/\/abcnews.go.com\/m\/story?id=17767789",
        "display_url" : "abcnews.go.com\/m\/story?id=177\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351805878799839233",
    "text" : "#zimmermantrial So Serino the only cop who actually questioned Police findings immediately demoted! Smh! http:\/\/t.co\/TR8iDzfszw",
    "id" : 351805878799839233,
    "created_at" : "2013-07-01 20:53:52 +0000",
    "user" : {
      "name" : "Koji Mizuno",
      "screen_name" : "Ijok1998",
      "protected" : false,
      "id_str" : "571269666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518955711775395840\/QdNobBuJ_normal.jpeg",
      "id" : 571269666,
      "verified" : false
    }
  },
  "id" : 351811067652997121,
  "created_at" : "2013-07-01 21:14:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Bridson",
      "screen_name" : "AtheistBridson",
      "indices" : [ 0, 15 ],
      "id_str" : "291365448",
      "id" : 291365448
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 96, 111 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351776314883198976",
  "geo" : { },
  "id_str" : "351803280294281216",
  "in_reply_to_user_id" : 291365448,
  "text" : "@AtheistBridson well, if there is no afterlife.. then comfort in this life should take priority @AnnotatedBible",
  "id" : 351803280294281216,
  "in_reply_to_status_id" : 351776314883198976,
  "created_at" : "2013-07-01 20:43:32 +0000",
  "in_reply_to_screen_name" : "AtheistBridson",
  "in_reply_to_user_id_str" : "291365448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    }, {
      "name" : "Fran Muhammad",
      "screen_name" : "DeeeVaaa",
      "indices" : [ 14, 23 ],
      "id_str" : "78989741",
      "id" : 78989741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351800525508968450",
  "text" : "RT @MWM4444: .@DeeeVaaa You are so right. If Zimmerman had been black &amp; Trayvon white, Zimmerman would have been lynched within the week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fran Muhammad",
        "screen_name" : "DeeeVaaa",
        "indices" : [ 1, 10 ],
        "id_str" : "78989741",
        "id" : 78989741
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "351795884306083841",
    "geo" : { },
    "id_str" : "351798099993305088",
    "in_reply_to_user_id" : 78989741,
    "text" : ".@DeeeVaaa You are so right. If Zimmerman had been black &amp; Trayvon white, Zimmerman would have been lynched within the week.",
    "id" : 351798099993305088,
    "in_reply_to_status_id" : 351795884306083841,
    "created_at" : "2013-07-01 20:22:57 +0000",
    "in_reply_to_screen_name" : "DeeeVaaa",
    "in_reply_to_user_id_str" : "78989741",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 351800525508968450,
  "created_at" : "2013-07-01 20:32:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HallowQueen",
      "screen_name" : "PupsherLive",
      "indices" : [ 3, 15 ],
      "id_str" : "48903336",
      "id" : 48903336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zimmertrial",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351794687029411840",
  "text" : "RT @PupsherLive: Zimmerman's claim of fear collapses: fear is not getting out of your vehicle to follow someone. #zimmertrial",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zimmertrial",
        "indices" : [ 96, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 41.9732447, -87.6520763 ]
    },
    "id_str" : "351791463853600768",
    "text" : "Zimmerman's claim of fear collapses: fear is not getting out of your vehicle to follow someone. #zimmertrial",
    "id" : 351791463853600768,
    "created_at" : "2013-07-01 19:56:35 +0000",
    "user" : {
      "name" : "HallowQueen",
      "screen_name" : "PupsherLive",
      "protected" : false,
      "id_str" : "48903336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000210840839\/93a8ba3852a8e20364957eb8b907b6b3_normal.jpeg",
      "id" : 48903336,
      "verified" : false
    }
  },
  "id" : 351794687029411840,
  "created_at" : "2013-07-01 20:09:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles M. Blow",
      "screen_name" : "CharlesMBlow",
      "indices" : [ 3, 16 ],
      "id_str" : "20772763",
      "id" : 20772763
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Trayvon",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "Zimmerman",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351793921497632768",
  "text" : "RT @CharlesMBlow: Has anyone not in a movie ever been shot to death, and before dying said: \"You got me\"? #Trayvon #Zimmerman",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Trayvon",
        "indices" : [ 88, 96 ]
      }, {
        "text" : "Zimmerman",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351779054086660096",
    "text" : "Has anyone not in a movie ever been shot to death, and before dying said: \"You got me\"? #Trayvon #Zimmerman",
    "id" : 351779054086660096,
    "created_at" : "2013-07-01 19:07:16 +0000",
    "user" : {
      "name" : "Charles M. Blow",
      "screen_name" : "CharlesMBlow",
      "protected" : false,
      "id_str" : "20772763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789611479284740096\/pWA8kAJY_normal.jpg",
      "id" : 20772763,
      "verified" : true
    }
  },
  "id" : 351793921497632768,
  "created_at" : "2013-07-01 20:06:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351777771770494976",
  "geo" : { },
  "id_str" : "351779425731354625",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 omg.. *pulling my hair out*",
  "id" : 351779425731354625,
  "in_reply_to_status_id" : 351777771770494976,
  "created_at" : "2013-07-01 19:08:45 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351776763577245696",
  "geo" : { },
  "id_str" : "351777906256646145",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist o-O .. *holds back a scream*",
  "id" : 351777906256646145,
  "in_reply_to_status_id" : 351776763577245696,
  "created_at" : "2013-07-01 19:02:43 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351774218968506368",
  "text" : "RT @SenSanders: What sense does it make, for us as a country, to have bright young people not going to college because they are worried abo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351761560810700801",
    "text" : "What sense does it make, for us as a country, to have bright young people not going to college because they are worried about the debt?",
    "id" : 351761560810700801,
    "created_at" : "2013-07-01 17:57:46 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 351774218968506368,
  "created_at" : "2013-07-01 18:48:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351771549482745856",
  "geo" : { },
  "id_str" : "351774004887040000",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible i think i can agree with that",
  "id" : 351774004887040000,
  "in_reply_to_status_id" : 351771549482745856,
  "created_at" : "2013-07-01 18:47:13 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zimmerman",
      "indices" : [ 13, 23 ]
    }, {
      "text" : "trayvon",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351744185260449795",
  "text" : "a thought if #zimmerman was screaming that way, wouldnt he have been flushed, shaking after? shown some sign of that panic? #trayvon",
  "id" : 351744185260449795,
  "created_at" : "2013-07-01 16:48:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "Go to @Esquire",
      "screen_name" : "Esquiremag",
      "indices" : [ 105, 116 ],
      "id_str" : "3174214732",
      "id" : 3174214732
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZimmermanTrial",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/h00HERiJaD",
      "expanded_url" : "http:\/\/www.esquire.com\/blogs\/politics\/trayvon-martin-trial-quote-police-interview?src=soc_twtr",
      "display_url" : "esquire.com\/blogs\/politics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351717273268002819",
  "text" : "RT @oceanshaman: A MUST READ! &gt;The Quote That Should End the Trayvon Trial http:\/\/t.co\/h00HERiJaD via @EsquireMag #ZimmermanTrial",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Go to @Esquire",
        "screen_name" : "Esquiremag",
        "indices" : [ 88, 99 ],
        "id_str" : "3174214732",
        "id" : 3174214732
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ZimmermanTrial",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/h00HERiJaD",
        "expanded_url" : "http:\/\/www.esquire.com\/blogs\/politics\/trayvon-martin-trial-quote-police-interview?src=soc_twtr",
        "display_url" : "esquire.com\/blogs\/politics\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351710912807309312",
    "text" : "A MUST READ! &gt;The Quote That Should End the Trayvon Trial http:\/\/t.co\/h00HERiJaD via @EsquireMag #ZimmermanTrial",
    "id" : 351710912807309312,
    "created_at" : "2013-07-01 14:36:30 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 351717273268002819,
  "created_at" : "2013-07-01 15:01:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]