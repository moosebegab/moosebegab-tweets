Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/EKDi8sIpIy",
      "expanded_url" : "http:\/\/amzn.to\/17rlYzY",
      "display_url" : "amzn.to\/17rlYzY"
    } ]
  },
  "geo" : { },
  "id_str" : "373991162472067072",
  "text" : "finished My Vacation in Hell by Gene Twaronite http:\/\/t.co\/EKDi8sIpIy",
  "id" : 373991162472067072,
  "created_at" : "2013-09-01 02:10:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PisseArtiste\/status\/373958749381070848\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Tbu4s22ZT5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTCRgEbCQAAzvLE.jpg",
      "id_str" : "373958749200728064",
      "id" : 373958749200728064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTCRgEbCQAAzvLE.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Tbu4s22ZT5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373961269113401344",
  "text" : "RT @PisseArtiste: Check out this fog. http:\/\/t.co\/Tbu4s22ZT5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PisseArtiste\/status\/373958749381070848\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/Tbu4s22ZT5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTCRgEbCQAAzvLE.jpg",
        "id_str" : "373958749200728064",
        "id" : 373958749200728064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTCRgEbCQAAzvLE.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Tbu4s22ZT5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373958749381070848",
    "text" : "Check out this fog. http:\/\/t.co\/Tbu4s22ZT5",
    "id" : 373958749381070848,
    "created_at" : "2013-09-01 00:01:28 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 373961269113401344,
  "created_at" : "2013-09-01 00:11:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 3, 16 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373836835559989248",
  "text" : "RT @InvisCollege: God is not almighty. God is powerless in your life without the awakening of yourself, as god...Min",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373836105730101248",
    "text" : "God is not almighty. God is powerless in your life without the awakening of yourself, as god...Min",
    "id" : 373836105730101248,
    "created_at" : "2013-08-31 15:54:07 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "protected" : false,
      "id_str" : "415556669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645216237\/invisible_college_normal.jpg",
      "id" : 415556669,
      "verified" : false
    }
  },
  "id" : 373836835559989248,
  "created_at" : "2013-08-31 15:57:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/373834508497190913\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/axaliqWIQb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BTAggTRCQAAzRv3.png",
      "id_str" : "373834508371378176",
      "id" : 373834508371378176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTAggTRCQAAzRv3.png",
      "sizes" : [ {
        "h" : 239,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/axaliqWIQb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373835412906590208",
  "text" : "RT @ChrisCapparell: What happens to the hole when the cheese is gone? Now look at it this way. http:\/\/t.co\/axaliqWIQb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/373834508497190913\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/axaliqWIQb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BTAggTRCQAAzRv3.png",
        "id_str" : "373834508371378176",
        "id" : 373834508371378176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BTAggTRCQAAzRv3.png",
        "sizes" : [ {
          "h" : 239,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 127,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/axaliqWIQb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373834508497190913",
    "text" : "What happens to the hole when the cheese is gone? Now look at it this way. http:\/\/t.co\/axaliqWIQb",
    "id" : 373834508497190913,
    "created_at" : "2013-08-31 15:47:46 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 373835412906590208,
  "created_at" : "2013-08-31 15:51:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373826566700023809",
  "text" : ". @1stCitizenKane Bingo!",
  "id" : 373826566700023809,
  "created_at" : "2013-08-31 15:16:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373823282966822912",
  "geo" : { },
  "id_str" : "373823775281651713",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 me, too.",
  "id" : 373823775281651713,
  "in_reply_to_status_id" : 373823282966822912,
  "created_at" : "2013-08-31 15:05:07 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russ Ryan",
      "screen_name" : "ItsJustADog",
      "indices" : [ 33, 45 ],
      "id_str" : "544631016",
      "id" : 544631016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/S6opkIf4lD",
      "expanded_url" : "http:\/\/maryinhb.blogspot.com\/2013\/08\/giveaway-review-its-just-dog-by-russ.html",
      "display_url" : "maryinhb.blogspot.com\/2013\/08\/giveaw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "373803684984918016",
  "text" : "win IT'S JUST A DOG by Russ Ryan @itsjustadog on BookHouds @maryinhb http:\/\/t.co\/S6opkIf4lD",
  "id" : 373803684984918016,
  "created_at" : "2013-08-31 13:45:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373615018446954496",
  "geo" : { },
  "id_str" : "373616681488117761",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia well, i do tend to give ppl benefit of doubt until proven otherwise..lol @weakSquare",
  "id" : 373616681488117761,
  "in_reply_to_status_id" : 373615018446954496,
  "created_at" : "2013-08-31 01:22:12 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "indices" : [ 3, 13 ],
      "id_str" : "20609518",
      "id" : 20609518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373613758364389376",
  "text" : "RT @DalaiLama: Instead of harboring fear and suspicion we need to think of other people not as \u2018them\u2019 but \u2018us\u2019.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363230302237245440",
    "text" : "Instead of harboring fear and suspicion we need to think of other people not as \u2018them\u2019 but \u2018us\u2019.",
    "id" : 363230302237245440,
    "created_at" : "2013-08-02 09:30:27 +0000",
    "user" : {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "protected" : false,
      "id_str" : "20609518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529214699041067008\/fqPBAr5s_normal.jpeg",
      "id" : 20609518,
      "verified" : true
    }
  },
  "id" : 373613758364389376,
  "created_at" : "2013-08-31 01:10:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "indices" : [ 3, 13 ],
      "id_str" : "20609518",
      "id" : 20609518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373613737917169664",
  "text" : "RT @DalaiLama: Wherever I go I talk to people about the need to be aware of the oneness of humanity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367217340624019457",
    "text" : "Wherever I go I talk to people about the need to be aware of the oneness of humanity.",
    "id" : 367217340624019457,
    "created_at" : "2013-08-13 09:33:31 +0000",
    "user" : {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "protected" : false,
      "id_str" : "20609518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529214699041067008\/fqPBAr5s_normal.jpeg",
      "id" : 20609518,
      "verified" : true
    }
  },
  "id" : 373613737917169664,
  "created_at" : "2013-08-31 01:10:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373579589391360000",
  "text" : "@1stCitizenKane congrats!! ((highfive))",
  "id" : 373579589391360000,
  "created_at" : "2013-08-30 22:54:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lennon and Maisy",
      "screen_name" : "lennonandmaisy",
      "indices" : [ 3, 18 ],
      "id_str" : "595174213",
      "id" : 595174213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/WkO0gDKIpr",
      "expanded_url" : "http:\/\/huff.to\/1d0vTk6",
      "display_url" : "huff.to\/1d0vTk6"
    } ]
  },
  "geo" : { },
  "id_str" : "373561815755546624",
  "text" : "RT @lennonandmaisy: Huffinton Post love!! Shocking Letter Tells Parents To 'Euthanize' Son With Autism http:\/\/t.co\/WkO0gDKIpr via @HuffPost\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Parents",
        "screen_name" : "HuffPostParents",
        "indices" : [ 110, 126 ],
        "id_str" : "16581734",
        "id" : 16581734
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love4maxwell",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/WkO0gDKIpr",
        "expanded_url" : "http:\/\/huff.to\/1d0vTk6",
        "display_url" : "huff.to\/1d0vTk6"
      } ]
    },
    "geo" : { },
    "id_str" : "369595372936499200",
    "text" : "Huffinton Post love!! Shocking Letter Tells Parents To 'Euthanize' Son With Autism http:\/\/t.co\/WkO0gDKIpr via @HuffPostParents #love4maxwell",
    "id" : 369595372936499200,
    "created_at" : "2013-08-19 23:02:58 +0000",
    "user" : {
      "name" : "Lennon and Maisy",
      "screen_name" : "lennonandmaisy",
      "protected" : false,
      "id_str" : "595174213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723298207627878400\/9n9hNzbC_normal.jpg",
      "id" : 595174213,
      "verified" : true
    }
  },
  "id" : 373561815755546624,
  "created_at" : "2013-08-30 21:44:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamez",
      "screen_name" : "bookofjamez",
      "indices" : [ 3, 15 ],
      "id_str" : "21956842",
      "id" : 21956842
    }, {
      "name" : "Angel",
      "screen_name" : "punkinsangel",
      "indices" : [ 17, 30 ],
      "id_str" : "26940346",
      "id" : 26940346
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "syria",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373511386535456768",
  "text" : "RT @bookofjamez: @punkinsangel If we can't learn to set an example at home we shouldn't try to set it abroad. #syria",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angel",
        "screen_name" : "punkinsangel",
        "indices" : [ 0, 13 ],
        "id_str" : "26940346",
        "id" : 26940346
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "syria",
        "indices" : [ 93, 99 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "373494963905908736",
    "geo" : { },
    "id_str" : "373495255418408960",
    "in_reply_to_user_id" : 26940346,
    "text" : "@punkinsangel If we can't learn to set an example at home we shouldn't try to set it abroad. #syria",
    "id" : 373495255418408960,
    "in_reply_to_status_id" : 373494963905908736,
    "created_at" : "2013-08-30 17:19:42 +0000",
    "in_reply_to_screen_name" : "punkinsangel",
    "in_reply_to_user_id_str" : "26940346",
    "user" : {
      "name" : "Jamez",
      "screen_name" : "bookofjamez",
      "protected" : false,
      "id_str" : "21956842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796332029101113345\/QlzssHuv_normal.jpg",
      "id" : 21956842,
      "verified" : false
    }
  },
  "id" : 373511386535456768,
  "created_at" : "2013-08-30 18:23:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamez",
      "screen_name" : "bookofjamez",
      "indices" : [ 3, 15 ],
      "id_str" : "21956842",
      "id" : 21956842
    }, {
      "name" : "Atrios",
      "screen_name" : "Atrios",
      "indices" : [ 23, 30 ],
      "id_str" : "15691197",
      "id" : 15691197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373511344495923200",
  "text" : "RT @bookofjamez: This \u201C@Atrios: we must kill more people to demonstrate our seriousness about how awful it is to kill people\u201D #Syria",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Atrios",
        "screen_name" : "Atrios",
        "indices" : [ 6, 13 ],
        "id_str" : "15691197",
        "id" : 15691197
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373497595487744000",
    "text" : "This \u201C@Atrios: we must kill more people to demonstrate our seriousness about how awful it is to kill people\u201D #Syria",
    "id" : 373497595487744000,
    "created_at" : "2013-08-30 17:29:00 +0000",
    "user" : {
      "name" : "Jamez",
      "screen_name" : "bookofjamez",
      "protected" : false,
      "id_str" : "21956842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796332029101113345\/QlzssHuv_normal.jpg",
      "id" : 21956842,
      "verified" : false
    }
  },
  "id" : 373511344495923200,
  "created_at" : "2013-08-30 18:23:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/ZrqwsxDhQE",
      "expanded_url" : "http:\/\/blog.pressgr.am\/soul\/",
      "display_url" : "blog.pressgr.am\/soul\/"
    } ]
  },
  "geo" : { },
  "id_str" : "373508239918264320",
  "text" : "Facebook Wants to Own Your Very Soul http:\/\/t.co\/ZrqwsxDhQE",
  "id" : 373508239918264320,
  "created_at" : "2013-08-30 18:11:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chaz",
      "screen_name" : "chaz1944",
      "indices" : [ 2, 11 ],
      "id_str" : "163813257",
      "id" : 163813257
    }, {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 12, 22 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373501011735756801",
  "geo" : { },
  "id_str" : "373502612894515200",
  "in_reply_to_user_id" : 163813257,
  "text" : ". @chaz1944 @Jamiastar @TPHealth damn straight.. it's unAmerican to be compassionate.. downright evil!",
  "id" : 373502612894515200,
  "in_reply_to_status_id" : 373501011735756801,
  "created_at" : "2013-08-30 17:48:56 +0000",
  "in_reply_to_screen_name" : "chaz1944",
  "in_reply_to_user_id_str" : "163813257",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/KW9eOF5vgD",
      "expanded_url" : "http:\/\/instagram.com\/p\/dpU0YWhH-s\/",
      "display_url" : "instagram.com\/p\/dpU0YWhH-s\/"
    } ]
  },
  "geo" : { },
  "id_str" : "373498961585131520",
  "text" : "RT @ducksandclucks: Peeping directly into my ear drum. http:\/\/t.co\/KW9eOF5vgD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/KW9eOF5vgD",
        "expanded_url" : "http:\/\/instagram.com\/p\/dpU0YWhH-s\/",
        "display_url" : "instagram.com\/p\/dpU0YWhH-s\/"
      } ]
    },
    "geo" : { },
    "id_str" : "373497544309243904",
    "text" : "Peeping directly into my ear drum. http:\/\/t.co\/KW9eOF5vgD",
    "id" : 373497544309243904,
    "created_at" : "2013-08-30 17:28:48 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 373498961585131520,
  "created_at" : "2013-08-30 17:34:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "syria",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373496753808355328",
  "text" : "RT @TheOracle13: Doesn't it matter to us that thousands of our own citizens are slaughtered by guns and poverty driven violence? #syria",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "syria",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373493879950934016",
    "text" : "Doesn't it matter to us that thousands of our own citizens are slaughtered by guns and poverty driven violence? #syria",
    "id" : 373493879950934016,
    "created_at" : "2013-08-30 17:14:14 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 373496753808355328,
  "created_at" : "2013-08-30 17:25:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373494668828233728",
  "geo" : { },
  "id_str" : "373496632970473472",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist WTF??",
  "id" : 373496632970473472,
  "in_reply_to_status_id" : 373494668828233728,
  "created_at" : "2013-08-30 17:25:11 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 0, 14 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373492366373822464",
  "geo" : { },
  "id_str" : "373495580602806272",
  "in_reply_to_user_id" : 280827427,
  "text" : "@deisidiamonia really?? WS is rather open-minded and you tell him to FO? @weakSquare",
  "id" : 373495580602806272,
  "in_reply_to_status_id" : 373492366373822464,
  "created_at" : "2013-08-30 17:21:00 +0000",
  "in_reply_to_screen_name" : "deisidiamonia",
  "in_reply_to_user_id_str" : "280827427",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamez",
      "screen_name" : "bookofjamez",
      "indices" : [ 3, 15 ],
      "id_str" : "21956842",
      "id" : 21956842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "syria",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "warisnottheanswer",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373494002302996480",
  "text" : "RT @bookofjamez: I want the US to stop policing the world and start fixing our schools, our roads, our healthcare #syria #warisnottheanswer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "syria",
        "indices" : [ 97, 103 ]
      }, {
        "text" : "warisnottheanswer",
        "indices" : [ 104, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373493329138180096",
    "text" : "I want the US to stop policing the world and start fixing our schools, our roads, our healthcare #syria #warisnottheanswer",
    "id" : 373493329138180096,
    "created_at" : "2013-08-30 17:12:03 +0000",
    "user" : {
      "name" : "Jamez",
      "screen_name" : "bookofjamez",
      "protected" : false,
      "id_str" : "21956842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796332029101113345\/QlzssHuv_normal.jpg",
      "id" : 21956842,
      "verified" : false
    }
  },
  "id" : 373494002302996480,
  "created_at" : "2013-08-30 17:14:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/fRy6MPSouR",
      "expanded_url" : "http:\/\/amzn.to\/144jk4h",
      "display_url" : "amzn.to\/144jk4h"
    } ]
  },
  "geo" : { },
  "id_str" : "373268482978484224",
  "text" : "finished Misery Loves Company by Rene Gutteridge http:\/\/t.co\/fRy6MPSouR",
  "id" : 373268482978484224,
  "created_at" : "2013-08-30 02:18:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373132950247731200",
  "text" : "@weakSquare LOL",
  "id" : 373132950247731200,
  "created_at" : "2013-08-29 17:20:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373117241601961985",
  "text" : "RT @micahjmurray: I'm also very open to the idea that my own views of truth can change, and that my own statements might be wrong. That's p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373115982954258432",
    "text" : "I'm also very open to the idea that my own views of truth can change, and that my own statements might be wrong. That's part of the process.",
    "id" : 373115982954258432,
    "created_at" : "2013-08-29 16:12:37 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 373117241601961985,
  "created_at" : "2013-08-29 16:17:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eleanor rigby",
      "screen_name" : "empathgirl",
      "indices" : [ 2, 13 ],
      "id_str" : "83488629",
      "id" : 83488629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "373102110436372480",
  "geo" : { },
  "id_str" : "373114880649203712",
  "in_reply_to_user_id" : 83488629,
  "text" : ". @empathgirl @BasedHippyGod yup. many, many poor ppl work extremely hard. hard work is not = income.",
  "id" : 373114880649203712,
  "in_reply_to_status_id" : 373102110436372480,
  "created_at" : "2013-08-29 16:08:14 +0000",
  "in_reply_to_screen_name" : "empathgirl",
  "in_reply_to_user_id_str" : "83488629",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eleanor rigby",
      "screen_name" : "empathgirl",
      "indices" : [ 3, 14 ],
      "id_str" : "83488629",
      "id" : 83488629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373114402070732802",
  "text" : "RT @empathgirl: Many rich don't \"earn\"their money.They inherit it. Many don't work \"hard\". Many of those are the ones telling to the poor t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373102110436372480",
    "text" : "Many rich don't \"earn\"their money.They inherit it. Many don't work \"hard\". Many of those are the ones telling to the poor to earn, work hard",
    "id" : 373102110436372480,
    "created_at" : "2013-08-29 15:17:29 +0000",
    "user" : {
      "name" : "eleanor rigby",
      "screen_name" : "empathgirl",
      "protected" : false,
      "id_str" : "83488629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786333852218208256\/1lP-2Tg9_normal.jpg",
      "id" : 83488629,
      "verified" : false
    }
  },
  "id" : 373114402070732802,
  "created_at" : "2013-08-29 16:06:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/fTGD7IxRdo",
      "expanded_url" : "http:\/\/huff.to\/1dpM3DR",
      "display_url" : "huff.to\/1dpM3DR"
    } ]
  },
  "geo" : { },
  "id_str" : "373101485065637889",
  "text" : "RT @HuffPostWeird: Girl calls 911 over 'MASSIVE FREAKING SPIDER,' cops use newspaper to dispatch the beast http:\/\/t.co\/fTGD7IxRdo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/fTGD7IxRdo",
        "expanded_url" : "http:\/\/huff.to\/1dpM3DR",
        "display_url" : "huff.to\/1dpM3DR"
      } ]
    },
    "geo" : { },
    "id_str" : "373100295934734336",
    "text" : "Girl calls 911 over 'MASSIVE FREAKING SPIDER,' cops use newspaper to dispatch the beast http:\/\/t.co\/fTGD7IxRdo",
    "id" : 373100295934734336,
    "created_at" : "2013-08-29 15:10:17 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 373101485065637889,
  "created_at" : "2013-08-29 15:15:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 67, 83 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/TqnNoMKwQS",
      "expanded_url" : "http:\/\/wp.me\/p3aG6D-LC",
      "display_url" : "wp.me\/p3aG6D-LC"
    } ]
  },
  "geo" : { },
  "id_str" : "373090757868937216",
  "text" : "The True Story of a Seven Year Marriage http:\/\/t.co\/TqnNoMKwQS via @wordpressdotcom",
  "id" : 373090757868937216,
  "created_at" : "2013-08-29 14:32:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372797688430862336",
  "text" : "RT @ZachsMind: If war was a solution, we'd have peace by now. We have poured trillions of dollars into military solutions. It helps keep po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372796387051589632",
    "text" : "If war was a solution, we'd have peace by now. We have poured trillions of dollars into military solutions. It helps keep populaton down 0.o",
    "id" : 372796387051589632,
    "created_at" : "2013-08-28 19:02:39 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 372797688430862336,
  "created_at" : "2013-08-28 19:07:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372796358328979457",
  "text" : "RT @ZachsMind: I am not fooled. International wars are about money and power. They have nothing to do with protecting ppl from WMD. Are you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372792763621703681",
    "text" : "I am not fooled. International wars are about money and power. They have nothing to do with protecting ppl from WMD. Are you still fooled?",
    "id" : 372792763621703681,
    "created_at" : "2013-08-28 18:48:15 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 372796358328979457,
  "created_at" : "2013-08-28 19:02:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ghosts",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372779772197085184",
  "text" : "my sister was like: \"what do you think? isnt that weird?\" then \"but i still dont believe!\" lol.. she's funny. #ghosts",
  "id" : 372779772197085184,
  "created_at" : "2013-08-28 17:56:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372779273754378240",
  "text" : "so... mommy visited my sister on monday (mom's b-day.) she moved a rooster figure from up high to the floor.",
  "id" : 372779273754378240,
  "created_at" : "2013-08-28 17:54:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372773095913693184",
  "text" : "RT @BrianMerritt: The Hidden God attracting me,\nI am an atom of the Host.    Therese of Lisieux",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372771515890405377",
    "text" : "The Hidden God attracting me,\nI am an atom of the Host.    Therese of Lisieux",
    "id" : 372771515890405377,
    "created_at" : "2013-08-28 17:23:49 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 372773095913693184,
  "created_at" : "2013-08-28 17:30:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Awesomely Luvvie",
      "screen_name" : "Luvvie",
      "indices" : [ 3, 10 ],
      "id_str" : "16254381",
      "id" : 16254381
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeKind",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372769162772238336",
  "text" : "RT @Luvvie: How many of us have failed at #BeKind? *raises hand* How many of us will keep trying to be kinder? *raises hand*",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeKind",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370248870699470850",
    "text" : "How many of us have failed at #BeKind? *raises hand* How many of us will keep trying to be kinder? *raises hand*",
    "id" : 370248870699470850,
    "created_at" : "2013-08-21 18:19:44 +0000",
    "user" : {
      "name" : "Awesomely Luvvie",
      "screen_name" : "Luvvie",
      "protected" : false,
      "id_str" : "16254381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730776548706516992\/4lu9aAYU_normal.jpg",
      "id" : 16254381,
      "verified" : true
    }
  },
  "id" : 372769162772238336,
  "created_at" : "2013-08-28 17:14:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372766210946904064",
  "text" : "#effexor as long as i have it.. fine. but a day or so w\/out it.. cannot guarantee my actions.",
  "id" : 372766210946904064,
  "created_at" : "2013-08-28 17:02:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/idXZac9bHm",
      "expanded_url" : "http:\/\/goo.gl\/UxOixc",
      "display_url" : "goo.gl\/UxOixc"
    } ]
  },
  "geo" : { },
  "id_str" : "372765672591212544",
  "text" : "RT @KerriFar: Sharing with a Nuthatch ~   http:\/\/t.co\/idXZac9bHm ~ #birds #birdwatching",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 53, 59 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/idXZac9bHm",
        "expanded_url" : "http:\/\/goo.gl\/UxOixc",
        "display_url" : "goo.gl\/UxOixc"
      } ]
    },
    "geo" : { },
    "id_str" : "372763099381899264",
    "text" : "Sharing with a Nuthatch ~   http:\/\/t.co\/idXZac9bHm ~ #birds #birdwatching",
    "id" : 372763099381899264,
    "created_at" : "2013-08-28 16:50:23 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 372765672591212544,
  "created_at" : "2013-08-28 17:00:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372758344257118208",
  "text" : "fyi: I am a drug addict.",
  "id" : 372758344257118208,
  "created_at" : "2013-08-28 16:31:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 17, 25 ]
    }, {
      "text" : "pharma",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gUP42e7kff",
      "expanded_url" : "http:\/\/tl.gd\/n_1rm5a3s",
      "display_url" : "tl.gd\/n_1rm5a3s"
    } ]
  },
  "geo" : { },
  "id_str" : "372756283516280832",
  "text" : "huh, sounds like #effexor ... creates a cycle of dependence. #pharma \"When you deplete serotonin, it takes a (cont) http:\/\/t.co\/gUP42e7kff",
  "id" : 372756283516280832,
  "created_at" : "2013-08-28 16:23:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 3, 13 ],
      "id_str" : "89621202",
      "id" : 89621202
    }, {
      "name" : "Receive Checks",
      "screen_name" : "tbithewire",
      "indices" : [ 105, 116 ],
      "id_str" : "2187174085",
      "id" : 2187174085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/dLLo70ic9D",
      "expanded_url" : "http:\/\/www.businessinsider.com\/why-miley-cyrus-we-cant-stop-is-actually-the-saddest-song-of-the-summer-2013-8",
      "display_url" : "businessinsider.com\/why-miley-cyru\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372755068837044224",
  "text" : "RT @joyceetta: Everybody Is Missing Miley Cyrus's Sad And Devastating Message http:\/\/t.co\/dLLo70ic9D via @tbithewire",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Receive Checks",
        "screen_name" : "tbithewire",
        "indices" : [ 90, 101 ],
        "id_str" : "2187174085",
        "id" : 2187174085
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/dLLo70ic9D",
        "expanded_url" : "http:\/\/www.businessinsider.com\/why-miley-cyrus-we-cant-stop-is-actually-the-saddest-song-of-the-summer-2013-8",
        "display_url" : "businessinsider.com\/why-miley-cyru\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372753754690301952",
    "text" : "Everybody Is Missing Miley Cyrus's Sad And Devastating Message http:\/\/t.co\/dLLo70ic9D via @tbithewire",
    "id" : 372753754690301952,
    "created_at" : "2013-08-28 16:13:15 +0000",
    "user" : {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "protected" : false,
      "id_str" : "89621202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676541304868888576\/h9Q1S4ek_normal.jpg",
      "id" : 89621202,
      "verified" : false
    }
  },
  "id" : 372755068837044224,
  "created_at" : "2013-08-28 16:18:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "indices" : [ 3, 16 ],
      "id_str" : "42481335",
      "id" : 42481335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372753312623235072",
  "text" : "RT @LegionAvalon: Our society is run by insane people for insane objectives.\n\n~ John Lennon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/smqueue.com\" rel=\"nofollow\"\u003Esmqueue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372720924229128193",
    "text" : "Our society is run by insane people for insane objectives.\n\n~ John Lennon",
    "id" : 372720924229128193,
    "created_at" : "2013-08-28 14:02:47 +0000",
    "user" : {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "protected" : false,
      "id_str" : "42481335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3391327613\/c795db5eaa583c2e7f3d9799771ff3c3_normal.jpeg",
      "id" : 42481335,
      "verified" : false
    }
  },
  "id" : 372753312623235072,
  "created_at" : "2013-08-28 16:11:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "BaldHiker",
      "screen_name" : "BaldHiker",
      "indices" : [ 35, 45 ],
      "id_str" : "174336609",
      "id" : 174336609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/reR8yBL3oK",
      "expanded_url" : "http:\/\/ow.ly\/olzAk",
      "display_url" : "ow.ly\/olzAk"
    } ]
  },
  "geo" : { },
  "id_str" : "372753165407383552",
  "text" : "RT @KerriFar: Oh I LOVE! --&gt; RT @baldhiker: Hello feathered friend\u2026.  http:\/\/t.co\/reR8yBL3oK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BaldHiker",
        "screen_name" : "BaldHiker",
        "indices" : [ 21, 31 ],
        "id_str" : "174336609",
        "id" : 174336609
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/reR8yBL3oK",
        "expanded_url" : "http:\/\/ow.ly\/olzAk",
        "display_url" : "ow.ly\/olzAk"
      } ]
    },
    "geo" : { },
    "id_str" : "372752813635698689",
    "text" : "Oh I LOVE! --&gt; RT @baldhiker: Hello feathered friend\u2026.  http:\/\/t.co\/reR8yBL3oK",
    "id" : 372752813635698689,
    "created_at" : "2013-08-28 16:09:30 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 372753165407383552,
  "created_at" : "2013-08-28 16:10:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372751858776829952",
  "text" : "insecurity.. that's where hate, fear, judgement stem from.",
  "id" : 372751858776829952,
  "created_at" : "2013-08-28 16:05:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "indices" : [ 3, 16 ],
      "id_str" : "42481335",
      "id" : 42481335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372749892780691458",
  "text" : "RT @LegionAvalon: The enemy is fear. \nWe think it is hate \nbut it is fear. \n\n~ Gandhi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/smqueue.com\" rel=\"nofollow\"\u003Esmqueue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372618509047451648",
    "text" : "The enemy is fear. \nWe think it is hate \nbut it is fear. \n\n~ Gandhi",
    "id" : 372618509047451648,
    "created_at" : "2013-08-28 07:15:50 +0000",
    "user" : {
      "name" : "TygerBurning",
      "screen_name" : "LegionAvalon",
      "protected" : false,
      "id_str" : "42481335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3391327613\/c795db5eaa583c2e7f3d9799771ff3c3_normal.jpeg",
      "id" : 42481335,
      "verified" : false
    }
  },
  "id" : 372749892780691458,
  "created_at" : "2013-08-28 15:57:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372746998262145025",
  "text" : "RT @TheGoldenMirror: Not feeling accepted can be a symptom of not accepting yourself. Don't seek the attention of others. Find your own app\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372746438314569728",
    "text" : "Not feeling accepted can be a symptom of not accepting yourself. Don't seek the attention of others. Find your own approval.",
    "id" : 372746438314569728,
    "created_at" : "2013-08-28 15:44:10 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 372746998262145025,
  "created_at" : "2013-08-28 15:46:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 2, 17 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372739882499584000",
  "geo" : { },
  "id_str" : "372744399672709120",
  "in_reply_to_user_id" : 18538833,
  "text" : ". @ZeitgeistGhost of course! you're forced to be born.. then you must pay your way.. for every step, every breath, every drink.",
  "id" : 372744399672709120,
  "in_reply_to_status_id" : 372739882499584000,
  "created_at" : "2013-08-28 15:36:04 +0000",
  "in_reply_to_screen_name" : "ZeitgeistGhost",
  "in_reply_to_user_id_str" : "18538833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 2, 14 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372736456504000512",
  "geo" : { },
  "id_str" : "372742006205734912",
  "in_reply_to_user_id" : 942491600,
  "text" : ". @TheBevForce one day i woke up and realized i did not have to follow \"the rules\" ...",
  "id" : 372742006205734912,
  "in_reply_to_status_id" : 372736456504000512,
  "created_at" : "2013-08-28 15:26:34 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 30, 45 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jfuZOJzaZv",
      "expanded_url" : "http:\/\/usat.ly\/18iDZxk",
      "display_url" : "usat.ly\/18iDZxk"
    } ]
  },
  "geo" : { },
  "id_str" : "372740943071305728",
  "text" : "not necessarily good news! RT @1stCitizenKane Researcher remotely controls colleague's body with brain http:\/\/t.co\/jfuZOJzaZv",
  "id" : 372740943071305728,
  "created_at" : "2013-08-28 15:22:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cassandra Fairbanks",
      "screen_name" : "CassandraRules",
      "indices" : [ 3, 18 ],
      "id_str" : "902200087",
      "id" : 902200087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoWarWithSyria",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372511767122804736",
  "text" : "RT @CassandraRules: \"Nothing will end war unless the people themselves refuse to go to war.\"\n~Einstein\n#NoWarWithSyria",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoWarWithSyria",
        "indices" : [ 83, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372127239795515392",
    "text" : "\"Nothing will end war unless the people themselves refuse to go to war.\"\n~Einstein\n#NoWarWithSyria",
    "id" : 372127239795515392,
    "created_at" : "2013-08-26 22:43:42 +0000",
    "user" : {
      "name" : "Cassandra Fairbanks",
      "screen_name" : "CassandraRules",
      "protected" : false,
      "id_str" : "902200087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791897776791687168\/J_T8HjWl_normal.jpg",
      "id" : 902200087,
      "verified" : true
    }
  },
  "id" : 372511767122804736,
  "created_at" : "2013-08-28 00:11:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372504578723307520",
  "text" : "@1stCitizenKane well, the honey bees are dying off so none of it matters anyway.",
  "id" : 372504578723307520,
  "created_at" : "2013-08-27 23:43:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heroes of Cosplay",
      "screen_name" : "HeroesofCosplay",
      "indices" : [ 9, 25 ],
      "id_str" : "1410666506",
      "id" : 1410666506
    }, {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 28, 44 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372487469331009536",
  "text" : "watching @HeroesofCosplay w @JourneyTheHedgi .. enjoying the costumes : )",
  "id" : 372487469331009536,
  "created_at" : "2013-08-27 22:35:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith M.",
      "screen_name" : "ksecus",
      "indices" : [ 3, 10 ],
      "id_str" : "22114231",
      "id" : 22114231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edshow",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372477243106136064",
  "text" : "RT @ksecus: We cut schools , food stamps, post office but magically have money for wars?  #edshow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "edshow",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372475023812210688",
    "text" : "We cut schools , food stamps, post office but magically have money for wars?  #edshow",
    "id" : 372475023812210688,
    "created_at" : "2013-08-27 21:45:40 +0000",
    "user" : {
      "name" : "Keith M.",
      "screen_name" : "ksecus",
      "protected" : false,
      "id_str" : "22114231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638152255204667392\/UL63hx9v_normal.jpg",
      "id" : 22114231,
      "verified" : false
    }
  },
  "id" : 372477243106136064,
  "created_at" : "2013-08-27 21:54:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372460673214996480",
  "geo" : { },
  "id_str" : "372472722070073344",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell i often say to DH that he was very bad in a previous life hence stuck w me..LOL",
  "id" : 372472722070073344,
  "in_reply_to_status_id" : 372460673214996480,
  "created_at" : "2013-08-27 21:36:31 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372462523359842304",
  "geo" : { },
  "id_str" : "372472241448960000",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 wowza!",
  "id" : 372472241448960000,
  "in_reply_to_status_id" : 372462523359842304,
  "created_at" : "2013-08-27 21:34:37 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 105, 114 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ApsA5kcIBA",
      "expanded_url" : "http:\/\/www.upworthy.com\/think-looks-cant-be-deceiving-take-a-peek-at-this-astonishing-guy-3?g=2&c=ufb1",
      "display_url" : "upworthy.com\/think-looks-ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372472155511853056",
  "text" : "RT @atheistlady76: He may not fit your image of a rocker, but ... well ... just listen to him play. (via @Upworthy) http:\/\/t.co\/ApsA5kcIBA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Upworthy",
        "screen_name" : "Upworthy",
        "indices" : [ 86, 95 ],
        "id_str" : "524396430",
        "id" : 524396430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/ApsA5kcIBA",
        "expanded_url" : "http:\/\/www.upworthy.com\/think-looks-cant-be-deceiving-take-a-peek-at-this-astonishing-guy-3?g=2&c=ufb1",
        "display_url" : "upworthy.com\/think-looks-ca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372462523359842304",
    "text" : "He may not fit your image of a rocker, but ... well ... just listen to him play. (via @Upworthy) http:\/\/t.co\/ApsA5kcIBA",
    "id" : 372462523359842304,
    "created_at" : "2013-08-27 20:56:00 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 372472155511853056,
  "created_at" : "2013-08-27 21:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372456412825149440",
  "text" : "in lake george last week saw the carriage horses trotting the streets. made me sad. and their tails were cut to half.. wth is up w that?",
  "id" : 372456412825149440,
  "created_at" : "2013-08-27 20:31:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Horse Fund",
      "screen_name" : "HorseFund",
      "indices" : [ 3, 13 ],
      "id_str" : "16266033",
      "id" : 16266033
    }, {
      "name" : "CASSIE ROSS",
      "screen_name" : "rosslio",
      "indices" : [ 124, 132 ],
      "id_str" : "384821735",
      "id" : 384821735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Kv4HEkchEW",
      "expanded_url" : "http:\/\/wp.me\/p6VVi-7TN",
      "display_url" : "wp.me\/p6VVi-7TN"
    } ]
  },
  "geo" : { },
  "id_str" : "372455757230247936",
  "text" : "RT @HorseFund: Jerry's death needless, preventable, intolerable...heat expo\/colic painful way to die http:\/\/t.co\/Kv4HEkchEW @rosslio @cleow\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CASSIE ROSS",
        "screen_name" : "rosslio",
        "indices" : [ 109, 117 ],
        "id_str" : "384821735",
        "id" : 384821735
      }, {
        "name" : "Christine Angelson",
        "screen_name" : "Cleowolf",
        "indices" : [ 118, 127 ],
        "id_str" : "152757329",
        "id" : 152757329
      }, {
        "name" : "Kevin Kipps",
        "screen_name" : "Kipps11",
        "indices" : [ 128, 136 ],
        "id_str" : "384150072",
        "id" : 384150072
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/Kv4HEkchEW",
        "expanded_url" : "http:\/\/wp.me\/p6VVi-7TN",
        "display_url" : "wp.me\/p6VVi-7TN"
      } ]
    },
    "geo" : { },
    "id_str" : "372442818092232704",
    "text" : "Jerry's death needless, preventable, intolerable...heat expo\/colic painful way to die http:\/\/t.co\/Kv4HEkchEW @rosslio @cleowolf @KIPPS11",
    "id" : 372442818092232704,
    "created_at" : "2013-08-27 19:37:42 +0000",
    "user" : {
      "name" : "The Horse Fund",
      "screen_name" : "HorseFund",
      "protected" : false,
      "id_str" : "16266033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1392601297\/twit-langrish-icon_normal.png",
      "id" : 16266033,
      "verified" : false
    }
  },
  "id" : 372455757230247936,
  "created_at" : "2013-08-27 20:29:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 0, 14 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372438281679405056",
  "geo" : { },
  "id_str" : "372438814452494336",
  "in_reply_to_user_id" : 260028159,
  "text" : "@LilMissCoyote heehee.. that tickles!",
  "id" : 372438814452494336,
  "in_reply_to_status_id" : 372438281679405056,
  "created_at" : "2013-08-27 19:21:47 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 30, 44 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372436562102870016",
  "geo" : { },
  "id_str" : "372437116849885184",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings ((licklick)) : ) @LilMissCoyote",
  "id" : 372437116849885184,
  "in_reply_to_status_id" : 372436562102870016,
  "created_at" : "2013-08-27 19:15:02 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 13, 27 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372435502382604288",
  "geo" : { },
  "id_str" : "372436286050553856",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings @LilMissCoyote ooohhh.. dont like seeing 2 coyotes arguing.. rather see them yipyapping, licking and playing : )",
  "id" : 372436286050553856,
  "in_reply_to_status_id" : 372435502382604288,
  "created_at" : "2013-08-27 19:11:44 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 13, 28 ],
      "id_str" : "19512493",
      "id" : 19512493
    }, {
      "name" : "Sally Bean",
      "screen_name" : "Cybersal",
      "indices" : [ 36, 45 ],
      "id_str" : "14938469",
      "id" : 14938469
    }, {
      "name" : "Marcus Payne",
      "screen_name" : "nowtro",
      "indices" : [ 50, 57 ],
      "id_str" : "61222021",
      "id" : 61222021
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nowtro\/status\/368730067209166850\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Ds6RfaYtKZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BR3-CuJCIAE7p4R.jpg",
      "id_str" : "368730067213361153",
      "id" : 368730067213361153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BR3-CuJCIAE7p4R.jpg",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/Ds6RfaYtKZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372419025223307264",
  "geo" : { },
  "id_str" : "372422640490668033",
  "in_reply_to_user_id" : 19512493,
  "text" : "so wrong. RT @RichardWiseman Wow RT @Cybersal: RT @nowtro Brilliant. A ceiling mural in a designated smoking area: http:\/\/t.co\/Ds6RfaYtKZ",
  "id" : 372422640490668033,
  "in_reply_to_status_id" : 372419025223307264,
  "created_at" : "2013-08-27 18:17:31 +0000",
  "in_reply_to_screen_name" : "RichardWiseman",
  "in_reply_to_user_id_str" : "19512493",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxim Muravlev",
      "screen_name" : "Kirsten_ish",
      "indices" : [ 2, 14 ],
      "id_str" : "179539448",
      "id" : 179539448
    }, {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 15, 26 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372414418279489536",
  "geo" : { },
  "id_str" : "372418084260151296",
  "in_reply_to_user_id" : 271583195,
  "text" : ". @Kirsten_ish @adampknave dr david samadi is an ass o-O",
  "id" : 372418084260151296,
  "in_reply_to_status_id" : 372414418279489536,
  "created_at" : "2013-08-27 17:59:25 +0000",
  "in_reply_to_screen_name" : "katannthompson",
  "in_reply_to_user_id_str" : "271583195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chubby",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372411046721384448",
  "text" : "saw pics of gals bigger than me wearing bikinis and.. damn.. they did not look bad. #chubby",
  "id" : 372411046721384448,
  "created_at" : "2013-08-27 17:31:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372410628255653888",
  "text" : "think my swimsuit is done for. time for a new one. contemplating a bikini. more comfy.",
  "id" : 372410628255653888,
  "created_at" : "2013-08-27 17:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372402783921930241",
  "geo" : { },
  "id_str" : "372403944221196289",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields think i might have seen that one around. dont have enough info for opinion but 1st thought is.. nah.",
  "id" : 372403944221196289,
  "in_reply_to_status_id" : 372402783921930241,
  "created_at" : "2013-08-27 17:03:13 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372402864536031233",
  "text" : "RT @Msunbeams: Are we still talking about Miley Cyrus? Seriously. Just so done with that conversation taking over everything else.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372402529771855872",
    "text" : "Are we still talking about Miley Cyrus? Seriously. Just so done with that conversation taking over everything else.",
    "id" : 372402529771855872,
    "created_at" : "2013-08-27 16:57:36 +0000",
    "user" : {
      "name" : "Bekka Leigh",
      "screen_name" : "_bekkaleigh",
      "protected" : false,
      "id_str" : "341002490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792140692738838528\/6SjPIATQ_normal.jpg",
      "id" : 341002490,
      "verified" : false
    }
  },
  "id" : 372402864536031233,
  "created_at" : "2013-08-27 16:58:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 2, 15 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372400603693346816",
  "geo" : { },
  "id_str" : "372402075960762369",
  "in_reply_to_user_id" : 14835882,
  "text" : ". @adamrshields some I do, some I don't..",
  "id" : 372402075960762369,
  "in_reply_to_status_id" : 372400603693346816,
  "created_at" : "2013-08-27 16:55:48 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372401134578569216",
  "text" : "@1stCitizenKane why?",
  "id" : 372401134578569216,
  "created_at" : "2013-08-27 16:52:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 2, 15 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372386587679535104",
  "geo" : { },
  "id_str" : "372387177155403777",
  "in_reply_to_user_id" : 94619438,
  "text" : ". @micahjmurray yup.. me, too.. sigh.",
  "id" : 372387177155403777,
  "in_reply_to_status_id" : 372386587679535104,
  "created_at" : "2013-08-27 15:56:36 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 32, 38 ]
    }, {
      "text" : "nature",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/01rT6RScd8",
      "expanded_url" : "http:\/\/goo.gl\/T6Phn5",
      "display_url" : "goo.gl\/T6Phn5"
    } ]
  },
  "geo" : { },
  "id_str" : "372182965792432129",
  "text" : "RT @KerriFar: Gentleness of the #birds ~ http:\/\/t.co\/01rT6RScd8 ~ #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 18, 24 ]
      }, {
        "text" : "nature",
        "indices" : [ 52, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/01rT6RScd8",
        "expanded_url" : "http:\/\/goo.gl\/T6Phn5",
        "display_url" : "goo.gl\/T6Phn5"
      } ]
    },
    "geo" : { },
    "id_str" : "372180553153675264",
    "text" : "Gentleness of the #birds ~ http:\/\/t.co\/01rT6RScd8 ~ #nature",
    "id" : 372180553153675264,
    "created_at" : "2013-08-27 02:15:33 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 372182965792432129,
  "created_at" : "2013-08-27 02:25:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372083748520464384",
  "text" : "i will never believe humans are inherently \"bad\" .. why do we cheer for the underdog? save a deer stuck on ice?",
  "id" : 372083748520464384,
  "created_at" : "2013-08-26 19:50:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hank Green",
      "screen_name" : "hankgreen",
      "indices" : [ 3, 13 ],
      "id_str" : "61592079",
      "id" : 61592079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372051730902437888",
  "text" : "RT @hankgreen: People who are just deeply wrong, despite an undying belief in their rightness, make me question my own belief in my obvious\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372030887602307072",
    "text" : "People who are just deeply wrong, despite an undying belief in their rightness, make me question my own belief in my obvious rightness.",
    "id" : 372030887602307072,
    "created_at" : "2013-08-26 16:20:50 +0000",
    "user" : {
      "name" : "Hank Green",
      "screen_name" : "hankgreen",
      "protected" : false,
      "id_str" : "61592079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668834117685874688\/nAsJZ3j7_normal.png",
      "id" : 61592079,
      "verified" : true
    }
  },
  "id" : 372051730902437888,
  "created_at" : "2013-08-26 17:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372044708693815296",
  "text" : "RT @virtusetveritas: Who the hell are we to start shaming women just because they're no longer children and are leaving their audience behi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372042739556184064",
    "text" : "Who the hell are we to start shaming women just because they're no longer children and are leaving their audience behind?",
    "id" : 372042739556184064,
    "created_at" : "2013-08-26 17:07:55 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 372044708693815296,
  "created_at" : "2013-08-26 17:15:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elen A.Arruda Queiro",
      "screen_name" : "DraElen",
      "indices" : [ 0, 8 ],
      "id_str" : "724692420009558021",
      "id" : 724692420009558021
    }, {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 53, 64 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372030156585447424",
  "text" : "@Draelen thanks.. looks like a cool game we'd enjoy! @Raven_Luni",
  "id" : 372030156585447424,
  "created_at" : "2013-08-26 16:17:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    }, {
      "name" : "Elen A.Arruda Queiro",
      "screen_name" : "DraElen",
      "indices" : [ 43, 51 ],
      "id_str" : "724692420009558021",
      "id" : 724692420009558021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "372016799467835392",
  "geo" : { },
  "id_str" : "372020187865677824",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni card game? do you have a link? @Draelen",
  "id" : 372020187865677824,
  "in_reply_to_status_id" : 372016799467835392,
  "created_at" : "2013-08-26 15:38:19 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Streetcrow",
      "screen_name" : "streetcrow",
      "indices" : [ 3, 14 ],
      "id_str" : "343008120",
      "id" : 343008120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372019735107338241",
  "text" : "RT @streetcrow: Ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruck\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371979468115435520",
    "text" : "Ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus ruckus",
    "id" : 371979468115435520,
    "created_at" : "2013-08-26 12:56:30 +0000",
    "user" : {
      "name" : "Streetcrow",
      "screen_name" : "streetcrow",
      "protected" : false,
      "id_str" : "343008120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773000449184047104\/yUDbU7tr_normal.jpg",
      "id" : 343008120,
      "verified" : false
    }
  },
  "id" : 372019735107338241,
  "created_at" : "2013-08-26 15:36:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "indices" : [ 3, 18 ],
      "id_str" : "31986700",
      "id" : 31986700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372014692597628928",
  "text" : "RT @VeryShortStory: You asked for flowers and I brought flowers. You asked for dancing and I danced. I asked for your love and you gave bac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372010823465840640",
    "text" : "You asked for flowers and I brought flowers. You asked for dancing and I danced. I asked for your love and you gave back the flowers.",
    "id" : 372010823465840640,
    "created_at" : "2013-08-26 15:01:06 +0000",
    "user" : {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "protected" : false,
      "id_str" : "31986700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/141070636\/42291_normal.jpg",
      "id" : 31986700,
      "verified" : false
    }
  },
  "id" : 372014692597628928,
  "created_at" : "2013-08-26 15:16:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372007006074183680",
  "text" : "happy birthday to my mommy in heaven! she would have been 81 today here on earth. miss you to pieces, mom! xoxoxo",
  "id" : 372007006074183680,
  "created_at" : "2013-08-26 14:45:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/IT79XPLOUB",
      "expanded_url" : "http:\/\/amzn.to\/gMzwKe",
      "display_url" : "amzn.to\/gMzwKe"
    } ]
  },
  "geo" : { },
  "id_str" : "371817314431537152",
  "text" : "finished Physics of the Impossible by Michio Kaku http:\/\/t.co\/IT79XPLOUB",
  "id" : 371817314431537152,
  "created_at" : "2013-08-26 02:12:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 60, 69 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/DCPVwdWt90",
      "expanded_url" : "http:\/\/thesunriseofmylife.blogspot.com\/2013\/08\/bluebird-curiosity.html?spref=tw",
      "display_url" : "thesunriseofmylife.blogspot.com\/2013\/08\/bluebi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371801025998376961",
  "text" : "RT @gemswinc: Bluebird Curiosity http:\/\/t.co\/DCPVwdWt90\nvia @KerriFar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KerriFar",
        "screen_name" : "KerriFar",
        "indices" : [ 46, 55 ],
        "id_str" : "12088232",
        "id" : 12088232
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/DCPVwdWt90",
        "expanded_url" : "http:\/\/thesunriseofmylife.blogspot.com\/2013\/08\/bluebird-curiosity.html?spref=tw",
        "display_url" : "thesunriseofmylife.blogspot.com\/2013\/08\/bluebi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "371800775925587968",
    "text" : "Bluebird Curiosity http:\/\/t.co\/DCPVwdWt90\nvia @KerriFar",
    "id" : 371800775925587968,
    "created_at" : "2013-08-26 01:06:27 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 371801025998376961,
  "created_at" : "2013-08-26 01:07:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371751823939346432",
  "text" : "RT @neiltyson: If you can wake up after being declared clinically dead, you're either a Zombie or Doctors don't yet know how to define death",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371745028143476736",
    "text" : "If you can wake up after being declared clinically dead, you're either a Zombie or Doctors don't yet know how to define death",
    "id" : 371745028143476736,
    "created_at" : "2013-08-25 21:24:56 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 371751823939346432,
  "created_at" : "2013-08-25 21:51:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Historical Pics",
      "screen_name" : "HistoricalPics",
      "indices" : [ 3, 18 ],
      "id_str" : "1598644159",
      "id" : 1598644159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371751317548449792",
  "text" : "RT @HistoricalPics: Women in Chicago being arrested for wearing one piece bathing suits, without covering their legs, 1922. http:\/\/t.co\/sAN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HistoricalPics\/status\/371696513271226368\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/sANNZNx9gH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSiIAmjIQAAE_bM.jpg",
        "id_str" : "371696513187332096",
        "id" : 371696513187332096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSiIAmjIQAAE_bM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sANNZNx9gH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371696513271226368",
    "text" : "Women in Chicago being arrested for wearing one piece bathing suits, without covering their legs, 1922. http:\/\/t.co\/sANNZNx9gH",
    "id" : 371696513271226368,
    "created_at" : "2013-08-25 18:12:09 +0000",
    "user" : {
      "name" : "Historical Pics",
      "screen_name" : "HistoricalPics",
      "protected" : false,
      "id_str" : "1598644159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000427629583\/884341028bb46b82f4dc8743b9ad24d7_normal.jpeg",
      "id" : 1598644159,
      "verified" : false
    }
  },
  "id" : 371751317548449792,
  "created_at" : "2013-08-25 21:49:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 2, 17 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371420012935790592",
  "geo" : { },
  "id_str" : "371426755258486784",
  "in_reply_to_user_id" : 44674382,
  "text" : ". @ChrisCapparell isnt there a list of ppl who were crazy at the time who were proven not in the future? if not, should be.",
  "id" : 371426755258486784,
  "in_reply_to_status_id" : 371420012935790592,
  "created_at" : "2013-08-25 00:20:13 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "371420012935790592",
  "geo" : { },
  "id_str" : "371425948962279424",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell lol",
  "id" : 371425948962279424,
  "in_reply_to_status_id" : 371420012935790592,
  "created_at" : "2013-08-25 00:17:01 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371356735740444672",
  "text" : "what did i miss the past week, twitter?",
  "id" : 371356735740444672,
  "created_at" : "2013-08-24 19:41:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368738553456365568",
  "text" : "good vibrations for friend's 12 yo black lab, Oliver, to be found. Disappeared the other day. Very unusual. He needs meds. Thanks, peeps.",
  "id" : 368738553456365568,
  "created_at" : "2013-08-17 14:18:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/tBwQDLRGjE",
      "expanded_url" : "http:\/\/www.thesovereignseries.com\/books",
      "display_url" : "thesovereignseries.com\/books"
    } ]
  },
  "geo" : { },
  "id_str" : "368539508351827968",
  "text" : "RT @ChickenJen: looking for a good book to read this weekend? Try the Sovereign Series http:\/\/t.co\/tBwQDLRGjE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/tBwQDLRGjE",
        "expanded_url" : "http:\/\/www.thesovereignseries.com\/books",
        "display_url" : "thesovereignseries.com\/books"
      } ]
    },
    "geo" : { },
    "id_str" : "368536046113259520",
    "text" : "looking for a good book to read this weekend? Try the Sovereign Series http:\/\/t.co\/tBwQDLRGjE",
    "id" : 368536046113259520,
    "created_at" : "2013-08-17 00:53:35 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 368539508351827968,
  "created_at" : "2013-08-17 01:07:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368537314407890944",
  "geo" : { },
  "id_str" : "368539315137044481",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray close.. i am #INFP : )",
  "id" : 368539315137044481,
  "in_reply_to_status_id" : 368537314407890944,
  "created_at" : "2013-08-17 01:06:34 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lost Pets of the HV",
      "screen_name" : "LostPetsHV",
      "indices" : [ 3, 14 ],
      "id_str" : "1115387942",
      "id" : 1115387942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368508460381376512",
  "text" : "RT @LostPetsHV: Oliver is STILL MISSING from WAPPINGERS FALLS, NY! Please continue to share this. Thank you! (Lauren, ADMIN) http:\/\/t.co\/Uh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/UhQ5tQu9rJ",
        "expanded_url" : "http:\/\/fb.me\/1I0jRMp4d",
        "display_url" : "fb.me\/1I0jRMp4d"
      } ]
    },
    "geo" : { },
    "id_str" : "368507469099577344",
    "text" : "Oliver is STILL MISSING from WAPPINGERS FALLS, NY! Please continue to share this. Thank you! (Lauren, ADMIN) http:\/\/t.co\/UhQ5tQu9rJ",
    "id" : 368507469099577344,
    "created_at" : "2013-08-16 23:00:01 +0000",
    "user" : {
      "name" : "Lost Pets of the HV",
      "screen_name" : "LostPetsHV",
      "protected" : false,
      "id_str" : "1115387942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/642547223948038144\/fjMObRsy_normal.jpg",
      "id" : 1115387942,
      "verified" : false
    }
  },
  "id" : 368508460381376512,
  "created_at" : "2013-08-16 23:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "indices" : [ 3, 14 ],
      "id_str" : "1132090693",
      "id" : 1132090693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368494108970475520",
  "text" : "RT @Globe_Pics: These new-born twins born in Spain joined hands shortly after birth. The nurses took this amazing photo http:\/\/t.co\/WmP3qGe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Globe_Pics\/status\/368492662388559875\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/WmP3qGeIjr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BR0mH8RCEAEgUPj.jpg",
        "id_str" : "368492662392754177",
        "id" : 368492662392754177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BR0mH8RCEAEgUPj.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/WmP3qGeIjr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368492662388559875",
    "text" : "These new-born twins born in Spain joined hands shortly after birth. The nurses took this amazing photo http:\/\/t.co\/WmP3qGeIjr",
    "id" : 368492662388559875,
    "created_at" : "2013-08-16 22:01:11 +0000",
    "user" : {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "protected" : false,
      "id_str" : "1132090693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538457900281126912\/tMIRoIp7_normal.jpeg",
      "id" : 1132090693,
      "verified" : false
    }
  },
  "id" : 368494108970475520,
  "created_at" : "2013-08-16 22:06:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Garcia",
      "screen_name" : "mgarcia523",
      "indices" : [ 0, 11 ],
      "id_str" : "71153272",
      "id" : 71153272
    }, {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 55, 71 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 72, 87 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368461347178024960",
  "geo" : { },
  "id_str" : "368490633444339712",
  "in_reply_to_user_id" : 71153272,
  "text" : "@mgarcia523 im always wondering about strange stuff... @shoeofallcosmos @1stCitizenKane",
  "id" : 368490633444339712,
  "in_reply_to_status_id" : 368461347178024960,
  "created_at" : "2013-08-16 21:53:07 +0000",
  "in_reply_to_screen_name" : "mgarcia523",
  "in_reply_to_user_id_str" : "71153272",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manuel Garcia",
      "screen_name" : "mgarcia523",
      "indices" : [ 3, 14 ],
      "id_str" : "71153272",
      "id" : 71153272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368489612567527424",
  "text" : "RT @mgarcia523: Damn me for having unorthodox views and not subscribing to popular dogma.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368240220577099777",
    "text" : "Damn me for having unorthodox views and not subscribing to popular dogma.",
    "id" : 368240220577099777,
    "created_at" : "2013-08-16 05:18:04 +0000",
    "user" : {
      "name" : "Manuel Garcia",
      "screen_name" : "mgarcia523",
      "protected" : false,
      "id_str" : "71153272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751607670100992000\/UB5vbDR6_normal.jpg",
      "id" : 71153272,
      "verified" : false
    }
  },
  "id" : 368489612567527424,
  "created_at" : "2013-08-16 21:49:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pancake Witch",
      "screen_name" : "TheRealKeori",
      "indices" : [ 3, 16 ],
      "id_str" : "36890099",
      "id" : 36890099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368453431314231297",
  "text" : "RT @TheRealKeori: Fuck Bloomberg and his fingerprinting of public housing residents. Fuck photo ID for EBT. It's racist and classist and it\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368450182003699714",
    "text" : "Fuck Bloomberg and his fingerprinting of public housing residents. Fuck photo ID for EBT. It's racist and classist and it needs to stop.",
    "id" : 368450182003699714,
    "created_at" : "2013-08-16 19:12:23 +0000",
    "user" : {
      "name" : "Pancake Witch",
      "screen_name" : "TheRealKeori",
      "protected" : false,
      "id_str" : "36890099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750844686382821377\/WSbk93Cx_normal.jpg",
      "id" : 36890099,
      "verified" : false
    }
  },
  "id" : 368453431314231297,
  "created_at" : "2013-08-16 19:25:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368422124345511936",
  "geo" : { },
  "id_str" : "368423186267770880",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos i think this is true for many but i do think there are those who truly believe they are standing 4 innocents.",
  "id" : 368423186267770880,
  "in_reply_to_status_id" : 368422124345511936,
  "created_at" : "2013-08-16 17:25:07 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    }, {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 101, 116 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368407557993275392",
  "geo" : { },
  "id_str" : "368419838382727168",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos morality is a weird word. what does it mean to be moral? does it ultimately matter? @1stCitizenKane",
  "id" : 368419838382727168,
  "in_reply_to_status_id" : 368407557993275392,
  "created_at" : "2013-08-16 17:11:49 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368412174189731840",
  "geo" : { },
  "id_str" : "368419405790588928",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos i get it. im trying to understand why pro-life ppl think the way they do and their definitions.",
  "id" : 368419405790588928,
  "in_reply_to_status_id" : 368412174189731840,
  "created_at" : "2013-08-16 17:10:05 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368407373301305344",
  "geo" : { },
  "id_str" : "368409128974024704",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos im not against it at all.. just curious as to how do humans define life.. are labels concrete or putty?",
  "id" : 368409128974024704,
  "in_reply_to_status_id" : 368407373301305344,
  "created_at" : "2013-08-16 16:29:15 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368407185383890944",
  "text" : ". @1stCitizenKane what is morality? who defined it? what makes one thing better than another?",
  "id" : 368407185383890944,
  "created_at" : "2013-08-16 16:21:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "curious",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368406604850270210",
  "text" : "im always interested in where the lines are.. where does one thing begin and another end.. #curious",
  "id" : 368406604850270210,
  "created_at" : "2013-08-16 16:19:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368405955412627457",
  "text" : "so they created a beating heart in a lab now.. is that considered \"playing god\"?",
  "id" : 368405955412627457,
  "created_at" : "2013-08-16 16:16:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/czPEvAK54m",
      "expanded_url" : "http:\/\/videos.huffingtonpost.com\/lab-grows-heart-tissue-that-can-beat-by-itself-517899724",
      "display_url" : "videos.huffingtonpost.com\/lab-grows-hear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "368403107769618432",
  "text" : "http:\/\/t.co\/czPEvAK54m",
  "id" : 368403107769618432,
  "created_at" : "2013-08-16 16:05:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368396953865822209",
  "text" : "dh is a productive, hard-working individual.. how he ended up w me is a puzzle. past lives karma?",
  "id" : 368396953865822209,
  "created_at" : "2013-08-16 15:40:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368379381250408448",
  "text" : "woke up from a cool dream.. a show with singing and skits.",
  "id" : 368379381250408448,
  "created_at" : "2013-08-16 14:31:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 0, 16 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368045102473568256",
  "text" : "@KevinRDaugherty any better today?",
  "id" : 368045102473568256,
  "created_at" : "2013-08-15 16:22:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367773100919648257",
  "geo" : { },
  "id_str" : "368044966074785792",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni i thought they looked a bit short.",
  "id" : 368044966074785792,
  "in_reply_to_status_id" : 367773100919648257,
  "created_at" : "2013-08-15 16:22:12 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368017860561354752",
  "text" : "RT @AllOnMedicare: The United States is a RICH country that denies health care to its people because it CAN. That's immoral. #SinglePayer #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 106, 118 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368017443769163776",
    "text" : "The United States is a RICH country that denies health care to its people because it CAN. That's immoral. #SinglePayer #MedicareForAll",
    "id" : 368017443769163776,
    "created_at" : "2013-08-15 14:32:50 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 368017860561354752,
  "created_at" : "2013-08-15 14:34:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 0, 16 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367800991183171585",
  "text" : "@KevinRDaugherty oh no.. poor cassie. hope she feels better soon.",
  "id" : 367800991183171585,
  "created_at" : "2013-08-15 00:12:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367793897923035137",
  "text" : "RT @dhammagirl: Letting go of things that no longer serve you is not the same as giving up.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367779363393404928",
    "text" : "Letting go of things that no longer serve you is not the same as giving up.",
    "id" : 367779363393404928,
    "created_at" : "2013-08-14 22:46:47 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 367793897923035137,
  "created_at" : "2013-08-14 23:44:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/9NrevxCvAa",
      "expanded_url" : "http:\/\/bit.ly\/14MhOEJ",
      "display_url" : "bit.ly\/14MhOEJ"
    } ]
  },
  "geo" : { },
  "id_str" : "367753398025588738",
  "text" : "RT @holycutenesss: Duck gets vacuumed http:\/\/t.co\/9NrevxCvAa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/9NrevxCvAa",
        "expanded_url" : "http:\/\/bit.ly\/14MhOEJ",
        "display_url" : "bit.ly\/14MhOEJ"
      } ]
    },
    "geo" : { },
    "id_str" : "367749753091526656",
    "text" : "Duck gets vacuumed http:\/\/t.co\/9NrevxCvAa",
    "id" : 367749753091526656,
    "created_at" : "2013-08-14 20:49:08 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 367753398025588738,
  "created_at" : "2013-08-14 21:03:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367718809764782080",
  "geo" : { },
  "id_str" : "367719413811662848",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible they see religion as a dysfunction, disorder, disease.. something to be \"fixed\".",
  "id" : 367719413811662848,
  "in_reply_to_status_id" : 367718809764782080,
  "created_at" : "2013-08-14 18:48:34 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367714812123287552",
  "text" : "why do people stay together when they don't get along? do they get high on the fighting?",
  "id" : 367714812123287552,
  "created_at" : "2013-08-14 18:30:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367682566221869056",
  "text" : "RT @SangyeH: We need to take the profit motive out of healthcare and prisons.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367677260469260288",
    "text" : "We need to take the profit motive out of healthcare and prisons.",
    "id" : 367677260469260288,
    "created_at" : "2013-08-14 16:01:04 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 367682566221869056,
  "created_at" : "2013-08-14 16:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367657019911585792",
  "geo" : { },
  "id_str" : "367660531319988224",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible why does good vs evil create such emotional turmoil for humans if it has no use?",
  "id" : 367660531319988224,
  "in_reply_to_status_id" : 367657019911585792,
  "created_at" : "2013-08-14 14:54:36 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "indices" : [ 3, 12 ],
      "id_str" : "394134197",
      "id" : 394134197
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mfpenney\/status\/367650177026248704\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/wy69g4Cm42",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRon41uCUAA3FhZ.jpg",
      "id_str" : "367650177030443008",
      "id" : 367650177030443008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRon41uCUAA3FhZ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/wy69g4Cm42"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367652404340064257",
  "text" : "RT @mfpenney: Parika Lake Moose - Rocky Mountain N.P. http:\/\/t.co\/wy69g4Cm42",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mfpenney\/status\/367650177026248704\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/wy69g4Cm42",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRon41uCUAA3FhZ.jpg",
        "id_str" : "367650177030443008",
        "id" : 367650177030443008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRon41uCUAA3FhZ.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/wy69g4Cm42"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367650177026248704",
    "text" : "Parika Lake Moose - Rocky Mountain N.P. http:\/\/t.co\/wy69g4Cm42",
    "id" : 367650177026248704,
    "created_at" : "2013-08-14 14:13:27 +0000",
    "user" : {
      "name" : "Mike Penney",
      "screen_name" : "mfpenney",
      "protected" : false,
      "id_str" : "394134197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1596470057\/DSCN0545_normal.jpg",
      "id" : 394134197,
      "verified" : false
    }
  },
  "id" : 367652404340064257,
  "created_at" : "2013-08-14 14:22:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367641175873703936",
  "text" : "last nights dream: my mom visited me as a ghost. was asking her about afterlife and saying how much i missed her : )",
  "id" : 367641175873703936,
  "created_at" : "2013-08-14 13:37:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367440732749316097",
  "geo" : { },
  "id_str" : "367445575634915330",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous 17yo?? wow.. my condolences. run free, Elvis &lt;3",
  "id" : 367445575634915330,
  "in_reply_to_status_id" : 367440732749316097,
  "created_at" : "2013-08-14 00:40:26 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scorpio farren",
      "screen_name" : "FarrenSquare",
      "indices" : [ 3, 16 ],
      "id_str" : "91011026",
      "id" : 91011026
    }, {
      "name" : "Maria",
      "screen_name" : "wheatandsky",
      "indices" : [ 40, 52 ],
      "id_str" : "394388277",
      "id" : 394388277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/roZRKzVEOO",
      "expanded_url" : "https:\/\/twitter.com\/wheatandsky\/status\/367098463252520961\/photo\/1",
      "display_url" : "pic.twitter.com\/roZRKzVEOO"
    } ]
  },
  "geo" : { },
  "id_str" : "367435927926214656",
  "text" : "RT @FarrenSquare: I NEED THIS GNOME. RT @wheatandsky: I found this awesome mother gnome breast feeding her twins. http:\/\/t.co\/roZRKzVEOO #N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria",
        "screen_name" : "wheatandsky",
        "indices" : [ 22, 34 ],
        "id_str" : "394388277",
        "id" : 394388277
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NIP",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/roZRKzVEOO",
        "expanded_url" : "https:\/\/twitter.com\/wheatandsky\/status\/367098463252520961\/photo\/1",
        "display_url" : "pic.twitter.com\/roZRKzVEOO"
      } ]
    },
    "in_reply_to_status_id_str" : "367098463252520961",
    "geo" : { },
    "id_str" : "367410804695392257",
    "in_reply_to_user_id" : 394388277,
    "text" : "I NEED THIS GNOME. RT @wheatandsky: I found this awesome mother gnome breast feeding her twins. http:\/\/t.co\/roZRKzVEOO #NIP",
    "id" : 367410804695392257,
    "in_reply_to_status_id" : 367098463252520961,
    "created_at" : "2013-08-13 22:22:16 +0000",
    "in_reply_to_screen_name" : "wheatandsky",
    "in_reply_to_user_id_str" : "394388277",
    "user" : {
      "name" : "scorpio farren",
      "screen_name" : "FarrenSquare",
      "protected" : false,
      "id_str" : "91011026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786783785698275328\/2r_4OU0d_normal.jpg",
      "id" : 91011026,
      "verified" : false
    }
  },
  "id" : 367435927926214656,
  "created_at" : "2013-08-14 00:02:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    }, {
      "name" : "Lyndon",
      "screen_name" : "lyndonisapillar",
      "indices" : [ 44, 60 ],
      "id_str" : "207256555",
      "id" : 207256555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367435656252772353",
  "text" : "RT @Wolf_Mommy: BECAUSE THE BABY IS HUNGRY. @lyndonisapillar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lyndon",
        "screen_name" : "lyndonisapillar",
        "indices" : [ 28, 44 ],
        "id_str" : "207256555",
        "id" : 207256555
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367435313997967360",
    "text" : "BECAUSE THE BABY IS HUNGRY. @lyndonisapillar",
    "id" : 367435313997967360,
    "created_at" : "2013-08-13 23:59:40 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 367435656252772353,
  "created_at" : "2013-08-14 00:01:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Pics with a Story",
      "screen_name" : "Picswithastory",
      "indices" : [ 21, 36 ],
      "id_str" : "1641150530",
      "id" : 1641150530
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Picswithastory\/status\/367338023622430720\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/devuEJZBKN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRkL_HrCUAA8gii.jpg",
      "id_str" : "367338023626625024",
      "id" : 367338023626625024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRkL_HrCUAA8gii.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 753,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 753,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 753,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/devuEJZBKN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367397067448000512",
  "text" : "RT @Matth3ous: :( RT @Picswithastory: http:\/\/t.co\/devuEJZBKN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pics with a Story",
        "screen_name" : "Picswithastory",
        "indices" : [ 6, 21 ],
        "id_str" : "1641150530",
        "id" : 1641150530
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Picswithastory\/status\/367338023622430720\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/devuEJZBKN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRkL_HrCUAA8gii.jpg",
        "id_str" : "367338023626625024",
        "id" : 367338023626625024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRkL_HrCUAA8gii.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/devuEJZBKN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367391591239258113",
    "text" : ":( RT @Picswithastory: http:\/\/t.co\/devuEJZBKN",
    "id" : 367391591239258113,
    "created_at" : "2013-08-13 21:05:55 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 367397067448000512,
  "created_at" : "2013-08-13 21:27:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "367356842865074176",
  "geo" : { },
  "id_str" : "367358984346271744",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses we picked some up. it's the same ingredient as benadryl.",
  "id" : 367358984346271744,
  "in_reply_to_status_id" : 367356842865074176,
  "created_at" : "2013-08-13 18:56:21 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367318173701251072",
  "text" : "im falling in love w corgis recently. have aussie butts but smaller..lol",
  "id" : 367318173701251072,
  "created_at" : "2013-08-13 16:14:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367289531646484480",
  "text" : "@1stCitizenKane hmm.. interesting.. \"raised by a television, every day is a competition\"",
  "id" : 367289531646484480,
  "created_at" : "2013-08-13 14:20:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367284882335997952",
  "text" : "RT @damienechols: You are not responsible for the happiness of others.\nSome people just don't WANT to be happy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367272765533204480",
    "text" : "You are not responsible for the happiness of others.\nSome people just don't WANT to be happy.",
    "id" : 367272765533204480,
    "created_at" : "2013-08-13 13:13:45 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 367284882335997952,
  "created_at" : "2013-08-13 14:01:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 3, 19 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/SIOUBWiOWa",
      "expanded_url" : "http:\/\/fb.me\/1uESQk0sn",
      "display_url" : "fb.me\/1uESQk0sn"
    } ]
  },
  "geo" : { },
  "id_str" : "367080075574779905",
  "text" : "RT @thebeadedpillow: Sneaking through the backyard today. Well played Ducks. Well played. http:\/\/t.co\/SIOUBWiOWa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/SIOUBWiOWa",
        "expanded_url" : "http:\/\/fb.me\/1uESQk0sn",
        "display_url" : "fb.me\/1uESQk0sn"
      } ]
    },
    "geo" : { },
    "id_str" : "367075182935932928",
    "text" : "Sneaking through the backyard today. Well played Ducks. Well played. http:\/\/t.co\/SIOUBWiOWa",
    "id" : 367075182935932928,
    "created_at" : "2013-08-13 00:08:38 +0000",
    "user" : {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "protected" : false,
      "id_str" : "36656159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550471777\/Karens_birthday_2008_normal.jpg",
      "id" : 36656159,
      "verified" : false
    }
  },
  "id" : 367080075574779905,
  "created_at" : "2013-08-13 00:28:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "Daily Kos",
      "screen_name" : "dailykos",
      "indices" : [ 114, 123 ],
      "id_str" : "20818801",
      "id" : 20818801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Q1oFEwfAou",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/08\/12\/1230681\/-Call-me-stupid-My-latest-experience-with-Insurance-in-name-only",
      "display_url" : "dailykos.com\/story\/2013\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "367044043282186240",
  "text" : "RT @AllOnMedicare: Call me stupid - My latest experience with \"Insurance in name only\" http:\/\/t.co\/Q1oFEwfAou via @dailykos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Kos",
        "screen_name" : "dailykos",
        "indices" : [ 95, 104 ],
        "id_str" : "20818801",
        "id" : 20818801
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/Q1oFEwfAou",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/08\/12\/1230681\/-Call-me-stupid-My-latest-experience-with-Insurance-in-name-only",
        "display_url" : "dailykos.com\/story\/2013\/08\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "367040714195992577",
    "text" : "Call me stupid - My latest experience with \"Insurance in name only\" http:\/\/t.co\/Q1oFEwfAou via @dailykos",
    "id" : 367040714195992577,
    "created_at" : "2013-08-12 21:51:40 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 367044043282186240,
  "created_at" : "2013-08-12 22:04:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffree Lee Norman",
      "screen_name" : "LiberalLegion",
      "indices" : [ 3, 17 ],
      "id_str" : "24716381",
      "id" : 24716381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qOcFa7vkF6",
      "expanded_url" : "http:\/\/tpt.to\/a3Lr1kr",
      "display_url" : "tpt.to\/a3Lr1kr"
    } ]
  },
  "geo" : { },
  "id_str" : "367018367829286912",
  "text" : "RT @LiberalLegion: Life-saving transplant denied and health insurance canceled over 26-cent shortfall - http:\/\/t.co\/qOcFa7vkF6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/play.google.com\/store\/apps\/details?id=com.dwdesign.tweetings\" rel=\"nofollow\"\u003ETweetings for  Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/qOcFa7vkF6",
        "expanded_url" : "http:\/\/tpt.to\/a3Lr1kr",
        "display_url" : "tpt.to\/a3Lr1kr"
      } ]
    },
    "geo" : { },
    "id_str" : "367005294582169600",
    "text" : "Life-saving transplant denied and health insurance canceled over 26-cent shortfall - http:\/\/t.co\/qOcFa7vkF6",
    "id" : 367005294582169600,
    "created_at" : "2013-08-12 19:30:55 +0000",
    "user" : {
      "name" : "Jeffree Lee Norman",
      "screen_name" : "LiberalLegion",
      "protected" : false,
      "id_str" : "24716381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796325400083369984\/sXy8Hfep_normal.jpg",
      "id" : 24716381,
      "verified" : false
    }
  },
  "id" : 367018367829286912,
  "created_at" : "2013-08-12 20:22:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 3, 15 ],
      "id_str" : "261888721",
      "id" : 261888721
    }, {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 21, 35 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366987026739888128",
  "text" : "RT @tommysalami: Hey @MikeBloomberg can we stop &amp; audit every white guy in a suit to see if they committed white collar crime?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Bloomberg",
        "screen_name" : "MikeBloomberg",
        "indices" : [ 4, 18 ],
        "id_str" : "16581604",
        "id" : 16581604
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366985870840041472",
    "text" : "Hey @MikeBloomberg can we stop &amp; audit every white guy in a suit to see if they committed white collar crime?",
    "id" : 366985870840041472,
    "created_at" : "2013-08-12 18:13:44 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 366987026739888128,
  "created_at" : "2013-08-12 18:18:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 0, 16 ],
      "id_str" : "344209049",
      "id" : 344209049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366973596653989889",
  "geo" : { },
  "id_str" : "366974206975549440",
  "in_reply_to_user_id" : 344209049,
  "text" : "@AlterEgoTrip_Se my DR pushes this at me. next appt im just saying no, not interested. period.",
  "id" : 366974206975549440,
  "in_reply_to_status_id" : 366973596653989889,
  "created_at" : "2013-08-12 17:27:23 +0000",
  "in_reply_to_screen_name" : "AlterEgoTrip_se",
  "in_reply_to_user_id_str" : "344209049",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Chase Madar",
      "screen_name" : "ChMadar",
      "indices" : [ 22, 30 ],
      "id_str" : "111631851",
      "id" : 111631851
    }, {
      "name" : "Charles P. Pierce",
      "screen_name" : "ESQPolitics",
      "indices" : [ 96, 108 ],
      "id_str" : "121489431",
      "id" : 121489431
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NJ",
      "indices" : [ 109, 112 ]
    }, {
      "text" : "njpoet",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/caSWHUKVKD",
      "expanded_url" : "http:\/\/www.esquire.com\/blogs\/politics\/Cory_Booker_Has_A_Problem?src=soc_twtr",
      "display_url" : "esquire.com\/blogs\/politics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366962298490847236",
  "text" : "RT @CharlesBivona: RT @ChMadar: Why I Wouldn't Vote For Cory Booker: http:\/\/t.co\/caSWHUKVKD via @EsqPolitics #NJ #njpoet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chase Madar",
        "screen_name" : "ChMadar",
        "indices" : [ 3, 11 ],
        "id_str" : "111631851",
        "id" : 111631851
      }, {
        "name" : "Charles P. Pierce",
        "screen_name" : "ESQPolitics",
        "indices" : [ 77, 89 ],
        "id_str" : "121489431",
        "id" : 121489431
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NJ",
        "indices" : [ 90, 93 ]
      }, {
        "text" : "njpoet",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/caSWHUKVKD",
        "expanded_url" : "http:\/\/www.esquire.com\/blogs\/politics\/Cory_Booker_Has_A_Problem?src=soc_twtr",
        "display_url" : "esquire.com\/blogs\/politics\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "366956090551844864",
    "geo" : { },
    "id_str" : "366957185667837952",
    "in_reply_to_user_id" : 111631851,
    "text" : "RT @ChMadar: Why I Wouldn't Vote For Cory Booker: http:\/\/t.co\/caSWHUKVKD via @EsqPolitics #NJ #njpoet",
    "id" : 366957185667837952,
    "in_reply_to_status_id" : 366956090551844864,
    "created_at" : "2013-08-12 16:19:45 +0000",
    "in_reply_to_screen_name" : "ChMadar",
    "in_reply_to_user_id_str" : "111631851",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 366962298490847236,
  "created_at" : "2013-08-12 16:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Bierko",
      "screen_name" : "MrCraigBierko",
      "indices" : [ 3, 17 ],
      "id_str" : "105570240",
      "id" : 105570240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366945172946288642",
  "text" : "RT @MrCraigBierko: The older I get the more impressed I am with people who summon the will to be kind despite their own feelings.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366944490046496769",
    "text" : "The older I get the more impressed I am with people who summon the will to be kind despite their own feelings.",
    "id" : 366944490046496769,
    "created_at" : "2013-08-12 15:29:18 +0000",
    "user" : {
      "name" : "Craig Bierko",
      "screen_name" : "MrCraigBierko",
      "protected" : false,
      "id_str" : "105570240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750190326929887232\/hczmuUWc_normal.jpg",
      "id" : 105570240,
      "verified" : true
    }
  },
  "id" : 366945172946288642,
  "created_at" : "2013-08-12 15:32:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healthcare-NOW!",
      "screen_name" : "HCNow",
      "indices" : [ 3, 9 ],
      "id_str" : "197524784",
      "id" : 197524784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/ldzAZni8p0",
      "expanded_url" : "http:\/\/s.shr.lc\/11Sjw3o",
      "display_url" : "s.shr.lc\/11Sjw3o"
    } ]
  },
  "geo" : { },
  "id_str" : "366944098944430080",
  "text" : "RT @HCNow: California OneCare - Montana sets up single payer. Guess what happens - http:\/\/t.co\/ldzAZni8p0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/ldzAZni8p0",
        "expanded_url" : "http:\/\/s.shr.lc\/11Sjw3o",
        "display_url" : "s.shr.lc\/11Sjw3o"
      } ]
    },
    "geo" : { },
    "id_str" : "366943607372005377",
    "text" : "California OneCare - Montana sets up single payer. Guess what happens - http:\/\/t.co\/ldzAZni8p0",
    "id" : 366943607372005377,
    "created_at" : "2013-08-12 15:25:48 +0000",
    "user" : {
      "name" : "Healthcare-NOW!",
      "screen_name" : "HCNow",
      "protected" : false,
      "id_str" : "197524784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722486189656313856\/Eo5vEDe5_normal.jpg",
      "id" : 197524784,
      "verified" : false
    }
  },
  "id" : 366944098944430080,
  "created_at" : "2013-08-12 15:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/rh0sOgfIVg",
      "expanded_url" : "http:\/\/nyti.ms\/Zf40cq",
      "display_url" : "nyti.ms\/Zf40cq"
    } ]
  },
  "geo" : { },
  "id_str" : "366943968455442432",
  "text" : "RT @nytimes: Breaking News: Stop-and-Frisk Policy in New York City Violated Rights, Judge Rules\nhttp:\/\/t.co\/rh0sOgfIVg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nytimes.com\/twitter\" rel=\"nofollow\"\u003EThe New York Times\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/rh0sOgfIVg",
        "expanded_url" : "http:\/\/nyti.ms\/Zf40cq",
        "display_url" : "nyti.ms\/Zf40cq"
      } ]
    },
    "geo" : { },
    "id_str" : "366909847347793921",
    "text" : "Breaking News: Stop-and-Frisk Policy in New York City Violated Rights, Judge Rules\nhttp:\/\/t.co\/rh0sOgfIVg",
    "id" : 366909847347793921,
    "created_at" : "2013-08-12 13:11:39 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 366943968455442432,
  "created_at" : "2013-08-12 15:27:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ARTIST ~ LIFE",
      "screen_name" : "DominicPlant",
      "indices" : [ 3, 16 ],
      "id_str" : "351615593",
      "id" : 351615593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Y37w6Nhlgh",
      "expanded_url" : "http:\/\/usnews.nbcnews.com\/_news\/2013\/08\/12\/19986524-baby-cant-be-named-messiah-judge-rules?lite",
      "display_url" : "usnews.nbcnews.com\/_news\/2013\/08\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366939652675993600",
  "text" : "RT @DominicPlant: I'm amazed the Judge is allowed bring her Religious preference in as a bias in a Law decision!!! http:\/\/t.co\/Y37w6Nhlgh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/Y37w6Nhlgh",
        "expanded_url" : "http:\/\/usnews.nbcnews.com\/_news\/2013\/08\/12\/19986524-baby-cant-be-named-messiah-judge-rules?lite",
        "display_url" : "usnews.nbcnews.com\/_news\/2013\/08\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "366938747465502720",
    "text" : "I'm amazed the Judge is allowed bring her Religious preference in as a bias in a Law decision!!! http:\/\/t.co\/Y37w6Nhlgh",
    "id" : 366938747465502720,
    "created_at" : "2013-08-12 15:06:29 +0000",
    "user" : {
      "name" : "ARTIST ~ LIFE",
      "screen_name" : "DominicPlant",
      "protected" : false,
      "id_str" : "351615593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2184523785\/OUT_normal.JPG",
      "id" : 351615593,
      "verified" : false
    }
  },
  "id" : 366939652675993600,
  "created_at" : "2013-08-12 15:10:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366903800449089536",
  "geo" : { },
  "id_str" : "366928734122545153",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous they used to. dont think they do anymore.",
  "id" : 366928734122545153,
  "in_reply_to_status_id" : 366903800449089536,
  "created_at" : "2013-08-12 14:26:42 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366732231806427136",
  "geo" : { },
  "id_str" : "366734062485909506",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott ahh, got it.",
  "id" : 366734062485909506,
  "in_reply_to_status_id" : 366732231806427136,
  "created_at" : "2013-08-12 01:33:08 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366731281788178432",
  "geo" : { },
  "id_str" : "366731749671174147",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott what did he do to the snake?",
  "id" : 366731749671174147,
  "in_reply_to_status_id" : 366731281788178432,
  "created_at" : "2013-08-12 01:23:57 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366725081008832513",
  "geo" : { },
  "id_str" : "366726643693264897",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time hmm.. yeah, that makes sense...",
  "id" : 366726643693264897,
  "in_reply_to_status_id" : 366725081008832513,
  "created_at" : "2013-08-12 01:03:39 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366724676132679681",
  "geo" : { },
  "id_str" : "366726179237011461",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny well, no matter what, eventually it comes to something from nothing (or living from non-living)",
  "id" : 366726179237011461,
  "in_reply_to_status_id" : 366724676132679681,
  "created_at" : "2013-08-12 01:01:49 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366723888421408768",
  "text" : "why do we want to make our parents proud? and.. even after they are dead?",
  "id" : 366723888421408768,
  "created_at" : "2013-08-12 00:52:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366722845390278656",
  "text" : "why do I want to be \"good\" yet cannot attain it and then feel \"guilt\"...",
  "id" : 366722845390278656,
  "created_at" : "2013-08-12 00:48:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squirrel",
      "indices" : [ 62, 71 ]
    }, {
      "text" : "nature",
      "indices" : [ 72, 79 ]
    }, {
      "text" : "animals",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "cuteness",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/5JMQBVCUpg",
      "expanded_url" : "http:\/\/ow.ly\/nP5U3",
      "display_url" : "ow.ly\/nP5U3"
    } ]
  },
  "geo" : { },
  "id_str" : "366722441122291712",
  "text" : "RT @KerriFar: What a sweet face!  ~ http:\/\/t.co\/5JMQBVCUpg  ~ #squirrel #nature #animals #cuteness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squirrel",
        "indices" : [ 48, 57 ]
      }, {
        "text" : "nature",
        "indices" : [ 58, 65 ]
      }, {
        "text" : "animals",
        "indices" : [ 66, 74 ]
      }, {
        "text" : "cuteness",
        "indices" : [ 75, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/5JMQBVCUpg",
        "expanded_url" : "http:\/\/ow.ly\/nP5U3",
        "display_url" : "ow.ly\/nP5U3"
      } ]
    },
    "geo" : { },
    "id_str" : "366722026771193856",
    "text" : "What a sweet face!  ~ http:\/\/t.co\/5JMQBVCUpg  ~ #squirrel #nature #animals #cuteness",
    "id" : 366722026771193856,
    "created_at" : "2013-08-12 00:45:19 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 366722441122291712,
  "created_at" : "2013-08-12 00:46:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366717201736138752",
  "geo" : { },
  "id_str" : "366720845437087745",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny well.. so do I..",
  "id" : 366720845437087745,
  "in_reply_to_status_id" : 366717201736138752,
  "created_at" : "2013-08-12 00:40:37 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Umstead",
      "screen_name" : "SteveUmstead",
      "indices" : [ 0, 13 ],
      "id_str" : "173669648",
      "id" : 173669648
    }, {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 38, 52 ],
      "id_str" : "244989679",
      "id" : 244989679
    }, {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "indices" : [ 56, 71 ],
      "id_str" : "48001363",
      "id" : 48001363
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ROUS",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366707055651856385",
  "geo" : { },
  "id_str" : "366708287397302273",
  "in_reply_to_user_id" : 173669648,
  "text" : "@SteveUmstead sure they do! check out @GaribaldiRous or @hippopotatomus #ROUS",
  "id" : 366708287397302273,
  "in_reply_to_status_id" : 366707055651856385,
  "created_at" : "2013-08-11 23:50:43 +0000",
  "in_reply_to_screen_name" : "SteveUmstead",
  "in_reply_to_user_id_str" : "173669648",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366692717658521603",
  "text" : "@1stCitizenKane THIS!",
  "id" : 366692717658521603,
  "created_at" : "2013-08-11 22:48:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366688909381484545",
  "text" : "@1stCitizenKane im in the former category...",
  "id" : 366688909381484545,
  "created_at" : "2013-08-11 22:33:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366688688194863104",
  "text" : "@1stCitizenKane yup.",
  "id" : 366688688194863104,
  "created_at" : "2013-08-11 22:32:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366659932382183425",
  "text" : "dont think pup feels well. came home.. not the usual excitement.. ears down.",
  "id" : 366659932382183425,
  "created_at" : "2013-08-11 20:38:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366658264781426690",
  "geo" : { },
  "id_str" : "366659285624700928",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous Sugar Daddy Junior lollipop? i loved the sugar mama's caramel covered in chocolate lollipops!",
  "id" : 366659285624700928,
  "in_reply_to_status_id" : 366658264781426690,
  "created_at" : "2013-08-11 20:36:00 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366585313411346433",
  "text" : "ppl dont know what to make of me.. neither do I...",
  "id" : 366585313411346433,
  "created_at" : "2013-08-11 15:42:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Komarek",
      "screen_name" : "DanielKomarek",
      "indices" : [ 3, 17 ],
      "id_str" : "76472749",
      "id" : 76472749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wildlife",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "photo",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/v0gapSgpah",
      "expanded_url" : "http:\/\/72dpi.com\/photo\/78292",
      "display_url" : "72dpi.com\/photo\/78292"
    } ]
  },
  "geo" : { },
  "id_str" : "366574675029012481",
  "text" : "RT @DanielKomarek: \"The Egyptian Goose\" http:\/\/t.co\/v0gapSgpah #wildlife #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wildlife",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "photo",
        "indices" : [ 54, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/v0gapSgpah",
        "expanded_url" : "http:\/\/72dpi.com\/photo\/78292",
        "display_url" : "72dpi.com\/photo\/78292"
      } ]
    },
    "geo" : { },
    "id_str" : "366571988195618816",
    "text" : "\"The Egyptian Goose\" http:\/\/t.co\/v0gapSgpah #wildlife #photo",
    "id" : 366571988195618816,
    "created_at" : "2013-08-11 14:49:07 +0000",
    "user" : {
      "name" : "Daniel Komarek",
      "screen_name" : "DanielKomarek",
      "protected" : false,
      "id_str" : "76472749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674237796840685569\/k1hxEDP__normal.jpg",
      "id" : 76472749,
      "verified" : false
    }
  },
  "id" : 366574675029012481,
  "created_at" : "2013-08-11 14:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366574605793624065",
  "text" : "RT @TimGreaton: Did you know? For over 150 years, scientists have known that fires can be extinguished with sound waves, but they still don\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366571782741819392",
    "text" : "Did you know? For over 150 years, scientists have known that fires can be extinguished with sound waves, but they still don't know how.",
    "id" : 366571782741819392,
    "created_at" : "2013-08-11 14:48:18 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 366574605793624065,
  "created_at" : "2013-08-11 14:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366571304654077952",
  "text" : "hey beautiful peeps. so much intelligence going on in my TL this am. love it!",
  "id" : 366571304654077952,
  "created_at" : "2013-08-11 14:46:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Adam R. B. Jack",
      "screen_name" : "adam_jack",
      "indices" : [ 65, 75 ],
      "id_str" : "11798892",
      "id" : 11798892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "Red_Feather_Lakes_CO",
      "indices" : [ 92, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/MIuXL3k4EB",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/4",
      "display_url" : "wildobs.com\/wo\/4"
    } ]
  },
  "geo" : { },
  "id_str" : "366383219769225216",
  "text" : "RT @wildobs: For the late crowd: Moose http:\/\/t.co\/MIuXL3k4EB by @adam_jack #EOTD #wildlife #Red_Feather_Lakes_CO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam R. B. Jack",
        "screen_name" : "adam_jack",
        "indices" : [ 52, 62 ],
        "id_str" : "11798892",
        "id" : 11798892
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 69, 78 ]
      }, {
        "text" : "Red_Feather_Lakes_CO",
        "indices" : [ 79, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/MIuXL3k4EB",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/4",
        "display_url" : "wildobs.com\/wo\/4"
      } ]
    },
    "geo" : { },
    "id_str" : "366379876875386880",
    "text" : "For the late crowd: Moose http:\/\/t.co\/MIuXL3k4EB by @adam_jack #EOTD #wildlife #Red_Feather_Lakes_CO",
    "id" : 366379876875386880,
    "created_at" : "2013-08-11 02:05:44 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 366383219769225216,
  "created_at" : "2013-08-11 02:19:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/5gW8epKI9V",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/08\/10\/justice\/california-amber-alert\/index.html?sr=sharebar_twitter",
      "display_url" : "cnn.com\/2013\/08\/10\/jus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366365391628419073",
  "text" : "Abductor of California teen killed in Idaho wilderness; captive rescued http:\/\/t.co\/5gW8epKI9V",
  "id" : 366365391628419073,
  "created_at" : "2013-08-11 01:08:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/z4vy5YtrEG",
      "expanded_url" : "http:\/\/tmblr.co\/ZsPYJwryKRyS",
      "display_url" : "tmblr.co\/ZsPYJwryKRyS"
    } ]
  },
  "geo" : { },
  "id_str" : "366352653732675584",
  "text" : "RT @Pandeism: Photo: \"Normal is an illusion. What is normal to the spider is chaos to the fly.\"\u00A0 http:\/\/t.co\/z4vy5YtrEG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/z4vy5YtrEG",
        "expanded_url" : "http:\/\/tmblr.co\/ZsPYJwryKRyS",
        "display_url" : "tmblr.co\/ZsPYJwryKRyS"
      } ]
    },
    "geo" : { },
    "id_str" : "366352061043974145",
    "text" : "Photo: \"Normal is an illusion. What is normal to the spider is chaos to the fly.\"\u00A0 http:\/\/t.co\/z4vy5YtrEG",
    "id" : 366352061043974145,
    "created_at" : "2013-08-11 00:15:12 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 366352653732675584,
  "created_at" : "2013-08-11 00:17:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "indices" : [ 0, 16 ],
      "id_str" : "292671486",
      "id" : 292671486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366347152584212481",
  "geo" : { },
  "id_str" : "366351591353229312",
  "in_reply_to_user_id" : 292671486,
  "text" : "@proudliberalmom but what an adventure to tell the grandkids!",
  "id" : 366351591353229312,
  "in_reply_to_status_id" : 366347152584212481,
  "created_at" : "2013-08-11 00:13:20 +0000",
  "in_reply_to_screen_name" : "proudliberalmom",
  "in_reply_to_user_id_str" : "292671486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 0, 9 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366345854719758337",
  "geo" : { },
  "id_str" : "366346416630673408",
  "in_reply_to_user_id" : 23538653,
  "text" : "@Fernwise took a sec to realize what you were saying...",
  "id" : 366346416630673408,
  "in_reply_to_status_id" : 366345854719758337,
  "created_at" : "2013-08-10 23:52:46 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366340445195878402",
  "text" : "@1stCitizenKane and who gets to decide who's qualified? it's an infinite loop...",
  "id" : 366340445195878402,
  "created_at" : "2013-08-10 23:29:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366340251108651009",
  "text" : "something's changed in me. a hardness that wasn't there before...",
  "id" : 366340251108651009,
  "created_at" : "2013-08-10 23:28:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366339048580726784",
  "text" : "@1stCitizenKane Bingo!!",
  "id" : 366339048580726784,
  "created_at" : "2013-08-10 23:23:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366338785358774272",
  "text" : "animals are free.. humans are not.",
  "id" : 366338785358774272,
  "created_at" : "2013-08-10 23:22:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 0, 14 ],
      "id_str" : "260028159",
      "id" : 260028159
    }, {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 84, 98 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366296943669940224",
  "geo" : { },
  "id_str" : "366297774456709121",
  "in_reply_to_user_id" : 260028159,
  "text" : "@LilMissCoyote oh my DD would love that. she loves anything with doom about it..lol @ChristianDems",
  "id" : 366297774456709121,
  "in_reply_to_status_id" : 366296943669940224,
  "created_at" : "2013-08-10 20:39:29 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 0, 14 ],
      "id_str" : "260028159",
      "id" : 260028159
    }, {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 73, 87 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366294104138719232",
  "geo" : { },
  "id_str" : "366296209360556033",
  "in_reply_to_user_id" : 260028159,
  "text" : "@LilMissCoyote as my DD likes to say \"Canadians are sooo chill.\" lol : ) @ChristianDems",
  "id" : 366296209360556033,
  "in_reply_to_status_id" : 366294104138719232,
  "created_at" : "2013-08-10 20:33:16 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366293348056694784",
  "text" : "RT @ChristianDems: Galatians 3:28 There is neither Jew nor Greek, slave nor free, male nor female, for you are all one in Christ Jesus.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366288907001794560",
    "text" : "Galatians 3:28 There is neither Jew nor Greek, slave nor free, male nor female, for you are all one in Christ Jesus.",
    "id" : 366288907001794560,
    "created_at" : "2013-08-10 20:04:15 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 366293348056694784,
  "created_at" : "2013-08-10 20:21:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#NoDAPL",
      "screen_name" : "obaa_boni",
      "indices" : [ 15, 25 ],
      "id_str" : "137175146",
      "id" : 137175146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366281964875022337",
  "geo" : { },
  "id_str" : "366284861490728961",
  "in_reply_to_user_id" : 184401626,
  "text" : "@BasedHippyGod @obaa_boni exactly.",
  "id" : 366284861490728961,
  "in_reply_to_status_id" : 366281964875022337,
  "created_at" : "2013-08-10 19:48:10 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "indices" : [ 0, 14 ],
      "id_str" : "260028159",
      "id" : 260028159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366282236523323392",
  "geo" : { },
  "id_str" : "366284715591872513",
  "in_reply_to_user_id" : 260028159,
  "text" : "@LilMissCoyote well.. it doesn't hurt so i guess that's ok then...",
  "id" : 366284715591872513,
  "in_reply_to_status_id" : 366282236523323392,
  "created_at" : "2013-08-10 19:47:36 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366282460721455105",
  "geo" : { },
  "id_str" : "366284549455495168",
  "in_reply_to_user_id" : 184401626,
  "text" : "@BasedHippyGod its been therapy to me.. and .. you're right.. any one of us could be the monster next.",
  "id" : 366284549455495168,
  "in_reply_to_status_id" : 366282460721455105,
  "created_at" : "2013-08-10 19:46:56 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366275831749804033",
  "text" : "i'm feeling ranty but i dont have brain connections to get what i want to say out...",
  "id" : 366275831749804033,
  "created_at" : "2013-08-10 19:12:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 3, 19 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366275107775201280",
  "text" : "RT @simonwoodwrites: Why is Lasik eye surgery priced per eye? Who gets one eye done?  The Cycloptic excluded of course.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366274581331312642",
    "text" : "Why is Lasik eye surgery priced per eye? Who gets one eye done?  The Cycloptic excluded of course.",
    "id" : 366274581331312642,
    "created_at" : "2013-08-10 19:07:19 +0000",
    "user" : {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "protected" : false,
      "id_str" : "30077179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786815188955570176\/XPC8uW7z_normal.jpg",
      "id" : 30077179,
      "verified" : false
    }
  },
  "id" : 366275107775201280,
  "created_at" : "2013-08-10 19:09:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366274617972768769",
  "text" : "why are intelligent ppl arguing w idiots about sex and religion?? idiots are happy when you argue w them!!",
  "id" : 366274617972768769,
  "created_at" : "2013-08-10 19:07:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0279\u01DD\u0287lA+ \uD83D\uDC38 Staryu",
      "screen_name" : "AlterEgoTrip_se",
      "indices" : [ 0, 16 ],
      "id_str" : "344209049",
      "id" : 344209049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366252562309054464",
  "geo" : { },
  "id_str" : "366253652383510528",
  "in_reply_to_user_id" : 344209049,
  "text" : "@AlterEgoTrip_Se very green! : )",
  "id" : 366253652383510528,
  "in_reply_to_status_id" : 366252562309054464,
  "created_at" : "2013-08-10 17:44:10 +0000",
  "in_reply_to_screen_name" : "AlterEgoTrip_se",
  "in_reply_to_user_id_str" : "344209049",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366251091635089409",
  "text" : "@1stCitizenKane well.. yeah..lol",
  "id" : 366251091635089409,
  "created_at" : "2013-08-10 17:33:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366234642501758976",
  "geo" : { },
  "id_str" : "366235921793810432",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses nice! i went through a red phase a some years back.",
  "id" : 366235921793810432,
  "in_reply_to_status_id" : 366234642501758976,
  "created_at" : "2013-08-10 16:33:42 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366227470766186497",
  "geo" : { },
  "id_str" : "366230886364090368",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell interesting how when something is sooo cold it burns..",
  "id" : 366230886364090368,
  "in_reply_to_status_id" : 366227470766186497,
  "created_at" : "2013-08-10 16:13:42 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366022892665839617",
  "geo" : { },
  "id_str" : "366025747816648704",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench it was like someone turned a radio on then off.. fairly quick. and it was voice like someone talking on radio.",
  "id" : 366025747816648704,
  "in_reply_to_status_id" : 366022892665839617,
  "created_at" : "2013-08-10 02:38:33 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366017719373533184",
  "text" : "just had weird exp of hearing.. like a radio station.. in my right ear.",
  "id" : 366017719373533184,
  "created_at" : "2013-08-10 02:06:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 13, 22 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ChEPrFJ1WZ",
      "expanded_url" : "http:\/\/goo.gl\/mZjtda",
      "display_url" : "goo.gl\/mZjtda"
    } ]
  },
  "in_reply_to_status_id_str" : "366004851487948800",
  "geo" : { },
  "id_str" : "366005689090453505",
  "in_reply_to_user_id" : 12088232,
  "text" : "beautiful RT @KerriFar At the top of the tree... a birdie .... as the sun sets ~ http:\/\/t.co\/ChEPrFJ1WZ  ~ #nature",
  "id" : 366005689090453505,
  "in_reply_to_status_id" : 366004851487948800,
  "created_at" : "2013-08-10 01:18:50 +0000",
  "in_reply_to_screen_name" : "KerriFar",
  "in_reply_to_user_id_str" : "12088232",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "366001822894276613",
  "geo" : { },
  "id_str" : "366002592490340352",
  "in_reply_to_user_id" : 184401626,
  "text" : "@BasedHippyGod had someone reply to me that she considered it child abuse to not vacc my DD w gardisil... o-O",
  "id" : 366002592490340352,
  "in_reply_to_status_id" : 366001822894276613,
  "created_at" : "2013-08-10 01:06:32 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365993263540350977",
  "geo" : { },
  "id_str" : "365997675834900481",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields congrats!! ((highfive))",
  "id" : 365997675834900481,
  "in_reply_to_status_id" : 365993263540350977,
  "created_at" : "2013-08-10 00:47:00 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365997514731700225",
  "text" : "RT @Jamiastar: We must stop these crazed half naked psychopaths from feeding their children in front of other people! | Blog http:\/\/t.co\/iA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/iAsIzGq1s7",
        "expanded_url" : "http:\/\/themattwalshblog.com\/2013\/08\/09\/we-must-stop-these-crazed-half-naked-psychopaths-from-feeding-their-children-in-front-of-other-people\/",
        "display_url" : "themattwalshblog.com\/2013\/08\/09\/we-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365993511725707264",
    "text" : "We must stop these crazed half naked psychopaths from feeding their children in front of other people! | Blog http:\/\/t.co\/iAsIzGq1s7",
    "id" : 365993511725707264,
    "created_at" : "2013-08-10 00:30:27 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 365997514731700225,
  "created_at" : "2013-08-10 00:46:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365935537883840513",
  "geo" : { },
  "id_str" : "365966206613716993",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny thanks for info! found the channel (43) .. didnt even know we had it..lol",
  "id" : 365966206613716993,
  "in_reply_to_status_id" : 365935537883840513,
  "created_at" : "2013-08-09 22:41:57 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365853455727861762",
  "geo" : { },
  "id_str" : "365859008059420672",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i used to watch that show...",
  "id" : 365859008059420672,
  "in_reply_to_status_id" : 365853455727861762,
  "created_at" : "2013-08-09 15:35:59 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "les cooper",
      "screen_name" : "flywildflyfree",
      "indices" : [ 20, 35 ],
      "id_str" : "23470034",
      "id" : 23470034
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/365541527352659968\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/xQLHN81gOR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRKqFRkCUAA2wiS.jpg",
      "id_str" : "365541527361048576",
      "id" : 365541527361048576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRKqFRkCUAA2wiS.jpg",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 856,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 718
      } ],
      "display_url" : "pic.twitter.com\/xQLHN81gOR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365853834683232256",
  "text" : "RT @KerriFar: :) RT @flywildflyfree: Who put the shower on http:\/\/t.co\/xQLHN81gOR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "les cooper",
        "screen_name" : "flywildflyfree",
        "indices" : [ 6, 21 ],
        "id_str" : "23470034",
        "id" : 23470034
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/365541527352659968\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/xQLHN81gOR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRKqFRkCUAA2wiS.jpg",
        "id_str" : "365541527361048576",
        "id" : 365541527361048576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRKqFRkCUAA2wiS.jpg",
        "sizes" : [ {
          "h" : 485,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 856,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 718
        } ],
        "display_url" : "pic.twitter.com\/xQLHN81gOR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365852737998565378",
    "text" : ":) RT @flywildflyfree: Who put the shower on http:\/\/t.co\/xQLHN81gOR",
    "id" : 365852737998565378,
    "created_at" : "2013-08-09 15:11:04 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 365853834683232256,
  "created_at" : "2013-08-09 15:15:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "indices" : [ 3, 18 ],
      "id_str" : "615318971",
      "id" : 615318971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365844061480947712",
  "text" : "RT @CuestionMarque: Only wealthy can afford to run for office b\/c elections are long &amp; expensive. Short PubliclyFunded elections would allo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364631662258159616",
    "text" : "Only wealthy can afford to run for office b\/c elections are long &amp; expensive. Short PubliclyFunded elections would allow rest of us to run.",
    "id" : 364631662258159616,
    "created_at" : "2013-08-06 06:18:57 +0000",
    "user" : {
      "name" : "From A Citizen",
      "screen_name" : "CuestionMarque",
      "protected" : false,
      "id_str" : "615318971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2347711009\/5slm7j57n6tf4g5d98ia_normal.jpeg",
      "id" : 615318971,
      "verified" : false
    }
  },
  "id" : 365844061480947712,
  "created_at" : "2013-08-09 14:36:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    }, {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "indices" : [ 22, 37 ],
      "id_str" : "299413847",
      "id" : 299413847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365836416334299137",
  "text" : "RT @ificouldtellu: RT @InjusticeFacts: The U.S. spends $200 billion a year on the war on terror, enough to completely wipe out world povert\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Injustice Facts",
        "screen_name" : "InjusticeFacts",
        "indices" : [ 3, 18 ],
        "id_str" : "299413847",
        "id" : 299413847
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365826210305028096",
    "text" : "RT @InjusticeFacts: The U.S. spends $200 billion a year on the war on terror, enough to completely wipe out world poverty.",
    "id" : 365826210305028096,
    "created_at" : "2013-08-09 13:25:39 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 365836416334299137,
  "created_at" : "2013-08-09 14:06:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/rQNdgVJPlu",
      "expanded_url" : "http:\/\/amzn.to\/hsqaKS",
      "display_url" : "amzn.to\/hsqaKS"
    } ]
  },
  "geo" : { },
  "id_str" : "365654624109203457",
  "text" : "finished Heart-Shaped Box by Joe Hill http:\/\/t.co\/rQNdgVJPlu",
  "id" : 365654624109203457,
  "created_at" : "2013-08-09 02:03:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365627064704966657",
  "text" : "RT @micahjmurray: All this talk of why people have kids. We didn\u2019t decide\/try to have kids; we just didn\u2019t try hard enough to not have kids\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365614848769404929",
    "text" : "All this talk of why people have kids. We didn\u2019t decide\/try to have kids; we just didn\u2019t try hard enough to not have kids. Biology happens.",
    "id" : 365614848769404929,
    "created_at" : "2013-08-08 23:25:47 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 365627064704966657,
  "created_at" : "2013-08-09 00:14:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5KZRcG2XH8",
      "expanded_url" : "http:\/\/www.openculture.com\/2013\/08\/fourteen-year-old-girls-blistering-heavy-metal-performance-of-vivaldi.html",
      "display_url" : "openculture.com\/2013\/08\/fourte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365607696948412418",
  "text" : "RT @TrishScott: Fourteen-Year-Old Girl\u2019s Blistering Heavy Metal Performance of Vivaldi http:\/\/t.co\/5KZRcG2XH8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/5KZRcG2XH8",
        "expanded_url" : "http:\/\/www.openculture.com\/2013\/08\/fourteen-year-old-girls-blistering-heavy-metal-performance-of-vivaldi.html",
        "display_url" : "openculture.com\/2013\/08\/fourte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365602788077600771",
    "text" : "Fourteen-Year-Old Girl\u2019s Blistering Heavy Metal Performance of Vivaldi http:\/\/t.co\/5KZRcG2XH8",
    "id" : 365602788077600771,
    "created_at" : "2013-08-08 22:37:51 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 365607696948412418,
  "created_at" : "2013-08-08 22:57:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365498416471613441",
  "geo" : { },
  "id_str" : "365503802293489665",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist oh my... ((hugs)) he's got issues to freak over an email like that.",
  "id" : 365503802293489665,
  "in_reply_to_status_id" : 365498416471613441,
  "created_at" : "2013-08-08 16:04:31 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365477579496505344",
  "geo" : { },
  "id_str" : "365484141162139648",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench thats what im reading..hehe. im over 50% done.",
  "id" : 365484141162139648,
  "in_reply_to_status_id" : 365477579496505344,
  "created_at" : "2013-08-08 14:46:24 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365263743040491520",
  "geo" : { },
  "id_str" : "365265609220571137",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell this is often me at bible study...",
  "id" : 365265609220571137,
  "in_reply_to_status_id" : 365263743040491520,
  "created_at" : "2013-08-08 00:18:02 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "365257857224028160",
  "geo" : { },
  "id_str" : "365259353596493826",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell heehee... finally.. i excel at something! ; )",
  "id" : 365259353596493826,
  "in_reply_to_status_id" : 365257857224028160,
  "created_at" : "2013-08-07 23:53:10 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bsonder",
      "screen_name" : "bsonder",
      "indices" : [ 3, 11 ],
      "id_str" : "21352055",
      "id" : 21352055
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bsonder\/status\/355817003187048449\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/vXptq9C4z0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPAdreBCEAAiUw3.jpg",
      "id_str" : "355817003191242752",
      "id" : 355817003191242752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPAdreBCEAAiUw3.jpg",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/vXptq9C4z0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365257077809090560",
  "text" : "RT @bsonder: omg, look at this big boy. http:\/\/t.co\/vXptq9C4z0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bsonder\/status\/355817003187048449\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/vXptq9C4z0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPAdreBCEAAiUw3.jpg",
        "id_str" : "355817003191242752",
        "id" : 355817003191242752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPAdreBCEAAiUw3.jpg",
        "sizes" : [ {
          "h" : 465,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/vXptq9C4z0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "355817003187048449",
    "text" : "omg, look at this big boy. http:\/\/t.co\/vXptq9C4z0",
    "id" : 355817003187048449,
    "created_at" : "2013-07-12 22:32:39 +0000",
    "user" : {
      "name" : "bsonder",
      "screen_name" : "bsonder",
      "protected" : false,
      "id_str" : "21352055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1419057103\/SnowLeopardAvatar_normal.jpg",
      "id" : 21352055,
      "verified" : false
    }
  },
  "id" : 365257077809090560,
  "created_at" : "2013-08-07 23:44:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zen",
      "indices" : [ 76, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365256919994208259",
  "text" : "i am nobody so im far ahead of those of you who are somebody.. so there! :P #zen",
  "id" : 365256919994208259,
  "created_at" : "2013-08-07 23:43:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "les cooper",
      "screen_name" : "flywildflyfree",
      "indices" : [ 27, 42 ],
      "id_str" : "23470034",
      "id" : 23470034
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/365179198022754304\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/iDluKgxxY0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRFgi7nCIAAHfqU.jpg",
      "id_str" : "365179198026948608",
      "id" : 365179198026948608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRFgi7nCIAAHfqU.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iDluKgxxY0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365196901416570881",
  "text" : "RT @KerriFar: How Cute! RT @flywildflyfree: My favourite one http:\/\/t.co\/iDluKgxxY0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "les cooper",
        "screen_name" : "flywildflyfree",
        "indices" : [ 13, 28 ],
        "id_str" : "23470034",
        "id" : 23470034
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/flywildflyfree\/status\/365179198022754304\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/iDluKgxxY0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRFgi7nCIAAHfqU.jpg",
        "id_str" : "365179198026948608",
        "id" : 365179198026948608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRFgi7nCIAAHfqU.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/iDluKgxxY0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365195683055144960",
    "text" : "How Cute! RT @flywildflyfree: My favourite one http:\/\/t.co\/iDluKgxxY0",
    "id" : 365195683055144960,
    "created_at" : "2013-08-07 19:40:10 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 365196901416570881,
  "created_at" : "2013-08-07 19:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365193999771910144",
  "text" : "RT @TyrusBooks: Ok, I'm going to come up with a super complicated riddle. First person to solve it will get a Kobo reader. Details coming s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "365192452501549056",
    "text" : "Ok, I'm going to come up with a super complicated riddle. First person to solve it will get a Kobo reader. Details coming soon. Who's in?",
    "id" : 365192452501549056,
    "created_at" : "2013-08-07 19:27:20 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 365193999771910144,
  "created_at" : "2013-08-07 19:33:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MhdtNKnzpW",
      "expanded_url" : "http:\/\/wp.me\/p1pu8r-64h",
      "display_url" : "wp.me\/p1pu8r-64h"
    } ]
  },
  "geo" : { },
  "id_str" : "365161453600243713",
  "text" : "RT @adamrshields: Refurbished Kindle Touch for $64 - Great Deal (until 5 PM Eastern or until Amazon sells out) http:\/\/t.co\/MhdtNKnzpW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/MhdtNKnzpW",
        "expanded_url" : "http:\/\/wp.me\/p1pu8r-64h",
        "display_url" : "wp.me\/p1pu8r-64h"
      } ]
    },
    "geo" : { },
    "id_str" : "365160407205294080",
    "text" : "Refurbished Kindle Touch for $64 - Great Deal (until 5 PM Eastern or until Amazon sells out) http:\/\/t.co\/MhdtNKnzpW",
    "id" : 365160407205294080,
    "created_at" : "2013-08-07 17:20:00 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 365161453600243713,
  "created_at" : "2013-08-07 17:24:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365161384327131136",
  "text" : "RT @bookwiseblog: Refurbished Kindle Touch for $64: Amazon is having a Gold Box Deal on a refurbished Kindle Touch\u00A0for $64. This... http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/6FzcmUscNR",
        "expanded_url" : "http:\/\/bit.ly\/14kar4e",
        "display_url" : "bit.ly\/14kar4e"
      } ]
    },
    "geo" : { },
    "id_str" : "365160589904969728",
    "text" : "Refurbished Kindle Touch for $64: Amazon is having a Gold Box Deal on a refurbished Kindle Touch\u00A0for $64. This... http:\/\/t.co\/6FzcmUscNR",
    "id" : 365160589904969728,
    "created_at" : "2013-08-07 17:20:43 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 365161384327131136,
  "created_at" : "2013-08-07 17:23:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 0, 13 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365157274819371009",
  "in_reply_to_user_id" : 361815486,
  "text" : "@bookwiseblog fyi: there's a gold box deal on kindle touch...",
  "id" : 365157274819371009,
  "created_at" : "2013-08-07 17:07:33 +0000",
  "in_reply_to_screen_name" : "bookwiseblog",
  "in_reply_to_user_id_str" : "361815486",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 52, 61 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/ELv5JXqbRn",
      "expanded_url" : "http:\/\/www.upworthy.com\/omg-best-use-of-a-billboard-i-have-ever-seen?g=2&c=ufb1",
      "display_url" : "upworthy.com\/omg-best-use-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365138587236302848",
  "text" : "OMG! Best use of a billboard I have ever seen. (via @Upworthy) http:\/\/t.co\/ELv5JXqbRn",
  "id" : 365138587236302848,
  "created_at" : "2013-08-07 15:53:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "basicmodel",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364429979813036033",
  "geo" : { },
  "id_str" : "364435289273409538",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem i keep telling DH he needs to trade in for newer model w more options.. but so far, im still here..lol. #basicmodel",
  "id" : 364435289273409538,
  "in_reply_to_status_id" : 364429979813036033,
  "created_at" : "2013-08-05 17:18:38 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364410785079902210",
  "text" : "@Lluminous_ yup. i was thinking about this the other night..lol.",
  "id" : 364410785079902210,
  "created_at" : "2013-08-05 15:41:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Xf3dmv76Oh",
      "expanded_url" : "http:\/\/www.amazon.com\/Hens-Chickens-Sovereign-Series-ebook\/dp\/B008OPDZ78\/ref=tmm_kin_title_0?ie=UTF8&qid=1375700962&sr=8-1",
      "display_url" : "amazon.com\/Hens-Chickens-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "364407252544786434",
  "text" : "RT @ChickenJen: the little book that started it all -- \"Hens &amp; Chickens\" -- is on sale at Amazon for only $2.99 http:\/\/t.co\/Xf3dmv76Oh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/Xf3dmv76Oh",
        "expanded_url" : "http:\/\/www.amazon.com\/Hens-Chickens-Sovereign-Series-ebook\/dp\/B008OPDZ78\/ref=tmm_kin_title_0?ie=UTF8&qid=1375700962&sr=8-1",
        "display_url" : "amazon.com\/Hens-Chickens-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "364404450284556288",
    "text" : "the little book that started it all -- \"Hens &amp; Chickens\" -- is on sale at Amazon for only $2.99 http:\/\/t.co\/Xf3dmv76Oh",
    "id" : 364404450284556288,
    "created_at" : "2013-08-05 15:16:05 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 364407252544786434,
  "created_at" : "2013-08-05 15:27:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Z8KPoModlw",
      "expanded_url" : "http:\/\/bit.ly\/1c3gvUD",
      "display_url" : "bit.ly\/1c3gvUD"
    } ]
  },
  "geo" : { },
  "id_str" : "364407045073534977",
  "text" : "RT @CandyTX: Candy's Raves: Book Giveaway: Collateral: A Novel by Ellen Hopkins http:\/\/t.co\/Z8KPoModlw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/Z8KPoModlw",
        "expanded_url" : "http:\/\/bit.ly\/1c3gvUD",
        "display_url" : "bit.ly\/1c3gvUD"
      } ]
    },
    "geo" : { },
    "id_str" : "364405254361595905",
    "text" : "Candy's Raves: Book Giveaway: Collateral: A Novel by Ellen Hopkins http:\/\/t.co\/Z8KPoModlw",
    "id" : 364405254361595905,
    "created_at" : "2013-08-05 15:19:17 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 364407045073534977,
  "created_at" : "2013-08-05 15:26:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364397742988468224",
  "geo" : { },
  "id_str" : "364399213745942529",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl like water off a duck's back, may it roll off you. ((hugs)) : )",
  "id" : 364399213745942529,
  "in_reply_to_status_id" : 364397742988468224,
  "created_at" : "2013-08-05 14:55:17 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364114076357898240",
  "geo" : { },
  "id_str" : "364114887632359424",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg nice view. ideally, i'd love to live on a lake. never been an ocean person.. i like the woods, serene lakes.",
  "id" : 364114887632359424,
  "in_reply_to_status_id" : 364114076357898240,
  "created_at" : "2013-08-04 20:05:28 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy",
      "screen_name" : "AmyRBromberg",
      "indices" : [ 0, 13 ],
      "id_str" : "145890580",
      "id" : 145890580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364112152627392512",
  "geo" : { },
  "id_str" : "364113326306897920",
  "in_reply_to_user_id" : 145890580,
  "text" : "@AmyRBromberg is that water in the background? is it swimmable?",
  "id" : 364113326306897920,
  "in_reply_to_status_id" : 364112152627392512,
  "created_at" : "2013-08-04 19:59:16 +0000",
  "in_reply_to_screen_name" : "AmyRBromberg",
  "in_reply_to_user_id_str" : "145890580",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364111301628264448",
  "text" : "RT @ChrisCapparell: What is Christ? You are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364071575202840576",
    "text" : "What is Christ? You are.",
    "id" : 364071575202840576,
    "created_at" : "2013-08-04 17:13:22 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 364111301628264448,
  "created_at" : "2013-08-04 19:51:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    }, {
      "name" : "Thich Nhat Hanh",
      "screen_name" : "thichnhathanh",
      "indices" : [ 21, 35 ],
      "id_str" : "17573212",
      "id" : 17573212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364111283303366656",
  "text" : "RT @ChrisCapparell: \u201C@thichnhathanh: What is God?\u201D\n\nWe are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Thich Nhat Hanh",
        "screen_name" : "thichnhathanh",
        "indices" : [ 1, 15 ],
        "id_str" : "17573212",
        "id" : 17573212
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "364070387048386560",
    "geo" : { },
    "id_str" : "364070557232275456",
    "in_reply_to_user_id" : 17573212,
    "text" : "\u201C@thichnhathanh: What is God?\u201D\n\nWe are.",
    "id" : 364070557232275456,
    "in_reply_to_status_id" : 364070387048386560,
    "created_at" : "2013-08-04 17:09:19 +0000",
    "in_reply_to_screen_name" : "thichnhathanh",
    "in_reply_to_user_id_str" : "17573212",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 364111283303366656,
  "created_at" : "2013-08-04 19:51:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "indices" : [ 3, 19 ],
      "id_str" : "292671486",
      "id" : 292671486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364082632755130368",
  "text" : "RT @proudliberalmom: Hey ppl. If u want \"welfare queens\" to be drug tested cause they r living off the dole,I want politicians tested 4 the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364079084285857792",
    "text" : "Hey ppl. If u want \"welfare queens\" to be drug tested cause they r living off the dole,I want politicians tested 4 the exact same reason #p2",
    "id" : 364079084285857792,
    "created_at" : "2013-08-04 17:43:12 +0000",
    "user" : {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "protected" : false,
      "id_str" : "292671486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742835194340605953\/oTbZt40x_normal.jpg",
      "id" : 292671486,
      "verified" : false
    }
  },
  "id" : 364082632755130368,
  "created_at" : "2013-08-04 17:57:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "364039015428657152",
  "geo" : { },
  "id_str" : "364057327080456193",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 lol.. we hung out, had coffee, looked at cars at car show. we enjoy their company, they seem to enjoy ours..lol",
  "id" : 364057327080456193,
  "in_reply_to_status_id" : 364039015428657152,
  "created_at" : "2013-08-04 16:16:45 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 117, 129 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ripmydearmother",
      "indices" : [ 17, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364055024491442176",
  "text" : "@SamsaricWarrior #ripmydearmother she made THE best sauce from scratch. : ) (in fact, i will never eat sketti again) @Silvercrone",
  "id" : 364055024491442176,
  "created_at" : "2013-08-04 16:07:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slenderman",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364054328643829760",
  "text" : "hubby's walking around house on stilts. he wants to wear them to a cosplay convention. #slenderman my bp is rising!",
  "id" : 364054328643829760,
  "created_at" : "2013-08-04 16:04:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364036804694913025",
  "text" : "we were at the saratoga spa park. we had coffee by the pool while chatting then moved on to car show (in park.) perfect weather!",
  "id" : 364036804694913025,
  "created_at" : "2013-08-04 14:55:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364036377395994625",
  "text" : "hubby and i had a pleasant afternoon w jim and karen, our new friends.. while waiting for our girls at their cosplay picnic yesterday. : )",
  "id" : 364036377395994625,
  "created_at" : "2013-08-04 14:53:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birdinthenight",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364035449636913152",
  "text" : "bird did not chirp.. just the sound of her wings in flight. #birdinthenight",
  "id" : 364035449636913152,
  "created_at" : "2013-08-04 14:49:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364035096824643584",
  "text" : "let dog out during night.. thought it was bat making circles under (low) porch roof but it was a bird! then she perched on pipe by light.",
  "id" : 364035096824643584,
  "created_at" : "2013-08-04 14:48:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363800418389725185",
  "geo" : { },
  "id_str" : "363805615300149248",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous voice recorder app on iphone?",
  "id" : 363805615300149248,
  "in_reply_to_status_id" : 363800418389725185,
  "created_at" : "2013-08-03 23:36:32 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363487014941130752",
  "geo" : { },
  "id_str" : "363776854961823744",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields a short read (novella) over 2 nights. i liked it. 3 out of 5 stars i would say.",
  "id" : 363776854961823744,
  "in_reply_to_status_id" : 363487014941130752,
  "created_at" : "2013-08-03 21:42:15 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/daaAnynWEV",
      "expanded_url" : "http:\/\/amzn.to\/MtUdxs",
      "display_url" : "amzn.to\/MtUdxs"
    } ]
  },
  "geo" : { },
  "id_str" : "363481182451011584",
  "text" : "finished Rearview (7 Hours) by Mike Dellosso http:\/\/t.co\/daaAnynWEV",
  "id" : 363481182451011584,
  "created_at" : "2013-08-03 02:07:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HotCoffee&Resistance",
      "screen_name" : "hotcoffeeandpie",
      "indices" : [ 3, 19 ],
      "id_str" : "86164231",
      "id" : 86164231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363386314005037056",
  "text" : "RT @hotcoffeeandpie: Montana Experiment Brings NHS-Style Health Care to USA; Saves State Millions, Patients Delighted http:\/\/t.co\/mFYiKH0E5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PublicOption",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/mFYiKH0E5R",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2013\/07\/31\/1227946\/-Montana-Experiment-Brings-NHS-Style-Health-Care-to-USA-Saves-State-Millions-Patients-Delighted",
        "display_url" : "dailykos.com\/story\/2013\/07\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362807662334840832",
    "text" : "Montana Experiment Brings NHS-Style Health Care to USA; Saves State Millions, Patients Delighted http:\/\/t.co\/mFYiKH0E5R #PublicOption",
    "id" : 362807662334840832,
    "created_at" : "2013-08-01 05:31:02 +0000",
    "user" : {
      "name" : "HotCoffee&Resistance",
      "screen_name" : "hotcoffeeandpie",
      "protected" : false,
      "id_str" : "86164231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796773116861091840\/S8CoYj4s_normal.jpg",
      "id" : 86164231,
      "verified" : false
    }
  },
  "id" : 363386314005037056,
  "created_at" : "2013-08-02 19:50:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF78 Amber Love \u2615",
      "screen_name" : "elizabethamber",
      "indices" : [ 3, 18 ],
      "id_str" : "14785495",
      "id" : 14785495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/T5yLPJAk8H",
      "expanded_url" : "http:\/\/fb.me\/2zHnqpqNn",
      "display_url" : "fb.me\/2zHnqpqNn"
    } ]
  },
  "geo" : { },
  "id_str" : "363385514541330432",
  "text" : "RT @elizabethamber: Meet Hilda, one of the only vintage plus size pinup girls! http:\/\/t.co\/T5yLPJAk8H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/T5yLPJAk8H",
        "expanded_url" : "http:\/\/fb.me\/2zHnqpqNn",
        "display_url" : "fb.me\/2zHnqpqNn"
      } ]
    },
    "geo" : { },
    "id_str" : "363379298981265409",
    "text" : "Meet Hilda, one of the only vintage plus size pinup girls! http:\/\/t.co\/T5yLPJAk8H",
    "id" : 363379298981265409,
    "created_at" : "2013-08-02 19:22:30 +0000",
    "user" : {
      "name" : "\uD83C\uDF78 Amber Love \u2615",
      "screen_name" : "elizabethamber",
      "protected" : false,
      "id_str" : "14785495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572423721743167488\/LgXDZuW6_normal.jpeg",
      "id" : 14785495,
      "verified" : false
    }
  },
  "id" : 363385514541330432,
  "created_at" : "2013-08-02 19:47:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363364238175121410",
  "geo" : { },
  "id_str" : "363370008602087424",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen aww.. hello chicken!",
  "id" : 363370008602087424,
  "in_reply_to_status_id" : 363364238175121410,
  "created_at" : "2013-08-02 18:45:35 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/rugQGM0774",
      "expanded_url" : "http:\/\/bit.ly\/r0lQb7",
      "display_url" : "bit.ly\/r0lQb7"
    } ]
  },
  "geo" : { },
  "id_str" : "363321711556440066",
  "text" : "RT @Lesism: \u201CSheep. Boy. Love\u201D \u2013 NOT what you may be thinking: http:\/\/t.co\/rugQGM0774",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/rugQGM0774",
        "expanded_url" : "http:\/\/bit.ly\/r0lQb7",
        "display_url" : "bit.ly\/r0lQb7"
      } ]
    },
    "geo" : { },
    "id_str" : "363320875355230208",
    "text" : "\u201CSheep. Boy. Love\u201D \u2013 NOT what you may be thinking: http:\/\/t.co\/rugQGM0774",
    "id" : 363320875355230208,
    "created_at" : "2013-08-02 15:30:21 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 363321711556440066,
  "created_at" : "2013-08-02 15:33:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gallstones",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363314512411107329",
  "text" : "drinking water w apple cider vinegar today. #gallstones",
  "id" : 363314512411107329,
  "created_at" : "2013-08-02 15:05:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woodpecker",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "birds",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "nature",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/LzXS9T3Pdo",
      "expanded_url" : "http:\/\/goo.gl\/zkBQjH",
      "display_url" : "goo.gl\/zkBQjH"
    } ]
  },
  "geo" : { },
  "id_str" : "363122586428780545",
  "text" : "RT @KerriFar: #woodpecker with a WILD head twist  - http:\/\/t.co\/LzXS9T3Pdo - #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "woodpecker",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "birds",
        "indices" : [ 63, 69 ]
      }, {
        "text" : "nature",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/LzXS9T3Pdo",
        "expanded_url" : "http:\/\/goo.gl\/zkBQjH",
        "display_url" : "goo.gl\/zkBQjH"
      } ]
    },
    "geo" : { },
    "id_str" : "363120789694218240",
    "text" : "#woodpecker with a WILD head twist  - http:\/\/t.co\/LzXS9T3Pdo - #birds #nature",
    "id" : 363120789694218240,
    "created_at" : "2013-08-02 02:15:17 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 363122586428780545,
  "created_at" : "2013-08-02 02:22:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    }, {
      "name" : "HealthWarehouse.com",
      "screen_name" : "healthwarehouse",
      "indices" : [ 56, 72 ],
      "id_str" : "3924841",
      "id" : 3924841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362957855122399233",
  "geo" : { },
  "id_str" : "363017335721820160",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal haha.. no. but my i ordered my #effexor from @healthwarehouse on wed and it will be here mon.",
  "id" : 363017335721820160,
  "in_reply_to_status_id" : 362957855122399233,
  "created_at" : "2013-08-01 19:24:12 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chartreuse",
      "screen_name" : "mizChartreuse",
      "indices" : [ 3, 17 ],
      "id_str" : "14284259",
      "id" : 14284259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362988965353099264",
  "text" : "RT @mizChartreuse: I have no desire to \"work,\" but every desire to invest properly to make $ grow, abundance easier, &amp; not be a slave to gr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362978903368798209",
    "text" : "I have no desire to \"work,\" but every desire to invest properly to make $ grow, abundance easier, &amp; not be a slave to greenbacks.",
    "id" : 362978903368798209,
    "created_at" : "2013-08-01 16:51:29 +0000",
    "user" : {
      "name" : "Chartreuse",
      "screen_name" : "mizChartreuse",
      "protected" : false,
      "id_str" : "14284259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740412912414658560\/5ipfnaUV_normal.jpg",
      "id" : 14284259,
      "verified" : false
    }
  },
  "id" : 362988965353099264,
  "created_at" : "2013-08-01 17:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 3, 9 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/gbODG1R8WC",
      "expanded_url" : "http:\/\/m.theatlanticwire.com\/national\/2013\/08\/government-knocking-doors-because-google-searches\/67864\/",
      "display_url" : "m.theatlanticwire.com\/national\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "362976834956181504",
  "text" : "RT @sacca: So. Messed. Up. Search for pressure cookers and backpacks and suddenly the Feds are at your house. http:\/\/t.co\/gbODG1R8WC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/gbODG1R8WC",
        "expanded_url" : "http:\/\/m.theatlanticwire.com\/national\/2013\/08\/government-knocking-doors-because-google-searches\/67864\/",
        "display_url" : "m.theatlanticwire.com\/national\/2013\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362971577979121664",
    "text" : "So. Messed. Up. Search for pressure cookers and backpacks and suddenly the Feds are at your house. http:\/\/t.co\/gbODG1R8WC",
    "id" : 362971577979121664,
    "created_at" : "2013-08-01 16:22:22 +0000",
    "user" : {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "protected" : false,
      "id_str" : "586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668902554957316096\/IpjBGyjC_normal.jpg",
      "id" : 586,
      "verified" : true
    }
  },
  "id" : 362976834956181504,
  "created_at" : "2013-08-01 16:43:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/NqdEPyImbv",
      "expanded_url" : "http:\/\/bit.ly\/18PjxXH",
      "display_url" : "bit.ly\/18PjxXH"
    } ]
  },
  "geo" : { },
  "id_str" : "362965318592770048",
  "text" : "RT @holycutenesss: Owl gives eskimo kisses http:\/\/t.co\/NqdEPyImbv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/NqdEPyImbv",
        "expanded_url" : "http:\/\/bit.ly\/18PjxXH",
        "display_url" : "bit.ly\/18PjxXH"
      } ]
    },
    "geo" : { },
    "id_str" : "362961405315522563",
    "text" : "Owl gives eskimo kisses http:\/\/t.co\/NqdEPyImbv",
    "id" : 362961405315522563,
    "created_at" : "2013-08-01 15:41:57 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 362965318592770048,
  "created_at" : "2013-08-01 15:57:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "362954442863157248",
  "geo" : { },
  "id_str" : "362958059053662208",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist lol.. that's what we do, too..",
  "id" : 362958059053662208,
  "in_reply_to_status_id" : 362954442863157248,
  "created_at" : "2013-08-01 15:28:39 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362957155793506306",
  "text" : "dear universe, grateful for good coffee and fast shipping this am.",
  "id" : 362957155793506306,
  "created_at" : "2013-08-01 15:25:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]