Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K.Randle, PhD, LCSW",
      "screen_name" : "DrKRandle",
      "indices" : [ 3, 13 ],
      "id_str" : "254296709",
      "id" : 254296709
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318507086822658049",
  "text" : "RT @DrKRandle: The \"Jodi Arias Essays\" page has been updated to reflect all of the in-depth analysis on the case to date #jodiarias http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/3sUZZ8jlyX",
        "expanded_url" : "http:\/\/kristinarandle.com\/blog\/jodi-arias-essays\/",
        "display_url" : "kristinarandle.com\/blog\/jodi-aria\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "318484543646605312",
    "text" : "The \"Jodi Arias Essays\" page has been updated to reflect all of the in-depth analysis on the case to date #jodiarias http:\/\/t.co\/3sUZZ8jlyX",
    "id" : 318484543646605312,
    "created_at" : "2013-03-31 22:06:47 +0000",
    "user" : {
      "name" : "K.Randle, PhD, LCSW",
      "screen_name" : "DrKRandle",
      "protected" : false,
      "id_str" : "254296709",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000532041373\/116509bdf034b4cece7c465d744292ae_normal.png",
      "id" : 254296709,
      "verified" : false
    }
  },
  "id" : 318507086822658049,
  "created_at" : "2013-03-31 23:36:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "indices" : [ 3, 18 ],
      "id_str" : "299413847",
      "id" : 299413847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318393278422732802",
  "text" : "RT @InjusticeFacts: Each year, the U.S. spends more on war and destruction than the entire planet spends on healthcare.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318005308955967488",
    "text" : "Each year, the U.S. spends more on war and destruction than the entire planet spends on healthcare.",
    "id" : 318005308955967488,
    "created_at" : "2013-03-30 14:22:28 +0000",
    "user" : {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "protected" : false,
      "id_str" : "299413847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1554067441\/injustice_normal.jpg",
      "id" : 299413847,
      "verified" : false
    }
  },
  "id" : 318393278422732802,
  "created_at" : "2013-03-31 16:04:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "indices" : [ 3, 9 ],
      "id_str" : "8943",
      "id" : 8943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318391497227661314",
  "text" : "RT @jesus: Hi.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318363395906744320",
    "text" : "Hi.",
    "id" : 318363395906744320,
    "created_at" : "2013-03-31 14:05:23 +0000",
    "user" : {
      "name" : "Jesus Christ",
      "screen_name" : "jesus",
      "protected" : false,
      "id_str" : "8943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000436609149\/959a9ed0624216336e8d253aceb89e2b_normal.jpeg",
      "id" : 8943,
      "verified" : false
    }
  },
  "id" : 318391497227661314,
  "created_at" : "2013-03-31 15:57:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318391238317441024",
  "text" : "watching #jodiarias trial has me pondering about what we are born with, free will, death penalty, life in prison. ugh, my head hurts!",
  "id" : 318391238317441024,
  "created_at" : "2013-03-31 15:56:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318390774813306880",
  "text" : "\"born this way\" .. what if you're born \"bad\"? is there free will there?",
  "id" : 318390774813306880,
  "created_at" : "2013-03-31 15:54:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen",
      "screen_name" : "KristenElaine",
      "indices" : [ 3, 17 ],
      "id_str" : "562190608",
      "id" : 562190608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318390258943287296",
  "text" : "RT @KristenElaine: If Nurmi was skinny and actually attractive then what would you have to say? Stick to his profession not his appearan ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 121, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318369711417081856",
    "text" : "If Nurmi was skinny and actually attractive then what would you have to say? Stick to his profession not his appearance. #JodiArias",
    "id" : 318369711417081856,
    "created_at" : "2013-03-31 14:30:28 +0000",
    "user" : {
      "name" : "Kristen",
      "screen_name" : "KristenElaine",
      "protected" : false,
      "id_str" : "562190608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732951717\/db0744fff4c61bb009eb267b5090a7a7_normal.jpeg",
      "id" : 562190608,
      "verified" : false
    }
  },
  "id" : 318390258943287296,
  "created_at" : "2013-03-31 15:52:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen",
      "screen_name" : "KristenElaine",
      "indices" : [ 3, 17 ],
      "id_str" : "562190608",
      "id" : 562190608
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318390231005024257",
  "text" : "RT @KristenElaine: I hate #JodiArias as much as the next person and yes her defense gets on my nerves. But stop jokin about weight so mu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 7, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318369362237079552",
    "text" : "I hate #JodiArias as much as the next person and yes her defense gets on my nerves. But stop jokin about weight so much. Nurmi is fat. And??",
    "id" : 318369362237079552,
    "created_at" : "2013-03-31 14:29:05 +0000",
    "user" : {
      "name" : "Kristen",
      "screen_name" : "KristenElaine",
      "protected" : false,
      "id_str" : "562190608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732951717\/db0744fff4c61bb009eb267b5090a7a7_normal.jpeg",
      "id" : 562190608,
      "verified" : false
    }
  },
  "id" : 318390231005024257,
  "created_at" : "2013-03-31 15:52:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 0, 15 ],
      "id_str" : "466879335",
      "id" : 466879335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318375590862389248",
  "geo" : { },
  "id_str" : "318386078727929856",
  "in_reply_to_user_id" : 466879335,
  "text" : "@ThatOtherChris im a christian mutt..lol",
  "id" : 318386078727929856,
  "in_reply_to_status_id" : 318375590862389248,
  "created_at" : "2013-03-31 15:35:31 +0000",
  "in_reply_to_screen_name" : "ThatOtherChris",
  "in_reply_to_user_id_str" : "466879335",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318382477511127041",
  "text" : "RT @CoyoteSings: my date arrives early \u2022 and taps my shoulder -- \u2022 Spring butterfly | #haiku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317829743519076354",
    "text" : "my date arrives early \u2022 and taps my shoulder -- \u2022 Spring butterfly | #haiku",
    "id" : 317829743519076354,
    "created_at" : "2013-03-30 02:44:50 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 318382477511127041,
  "created_at" : "2013-03-31 15:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/CWtU3lZQrX",
      "expanded_url" : "http:\/\/amzn.to\/VlWuP7",
      "display_url" : "amzn.to\/VlWuP7"
    } ]
  },
  "geo" : { },
  "id_str" : "318196164895834112",
  "text" : "finished Breaking Free by Chett Vosloo http:\/\/t.co\/CWtU3lZQrX",
  "id" : 318196164895834112,
  "created_at" : "2013-03-31 03:00:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K.Randle, PhD, LCSW",
      "screen_name" : "DrKRandle",
      "indices" : [ 0, 10 ],
      "id_str" : "254296709",
      "id" : 254296709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318150622396428288",
  "geo" : { },
  "id_str" : "318158338632339457",
  "in_reply_to_user_id" : 254296709,
  "text" : "@DrKRandle are ppl born w ASPD?",
  "id" : 318158338632339457,
  "in_reply_to_status_id" : 318150622396428288,
  "created_at" : "2013-03-31 00:30:33 +0000",
  "in_reply_to_screen_name" : "DrKRandle",
  "in_reply_to_user_id_str" : "254296709",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela Brockman",
      "screen_name" : "PamelafBrockman",
      "indices" : [ 3, 19 ],
      "id_str" : "19212015",
      "id" : 19212015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318129328120537088",
  "text" : "RT @PamelafBrockman: U.S. needs universal,single payer,paid-for-from-the-tax-base health care,like the rest of the developed world did i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318128127341649920",
    "text" : "U.S. needs universal,single payer,paid-for-from-the-tax-base health care,like the rest of the developed world did in the last century.",
    "id" : 318128127341649920,
    "created_at" : "2013-03-30 22:30:30 +0000",
    "user" : {
      "name" : "Pamela Brockman",
      "screen_name" : "PamelafBrockman",
      "protected" : false,
      "id_str" : "19212015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797817030485377024\/HdrUQK9y_normal.jpg",
      "id" : 19212015,
      "verified" : false
    }
  },
  "id" : 318129328120537088,
  "created_at" : "2013-03-30 22:35:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/AgCpJY0v9r",
      "expanded_url" : "http:\/\/www.youtube.com\/comment?lc=8dixZaF_PStyo1QljG5yVBROj5F7_5rCcJavD8sizDk",
      "display_url" : "youtube.com\/comment?lc=8di\u2026"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Erl4VKsBHt",
      "expanded_url" : "http:\/\/tl.gd\/n_1rjgjrv",
      "display_url" : "tl.gd\/n_1rjgjrv"
    } ]
  },
  "geo" : { },
  "id_str" : "318110308520579072",
  "text" : "#jodiarias Bob Nelson's comment re: premed spot on. http:\/\/t.co\/AgCpJY0v9r \"Arias at 2 mins 40 secs, in (cont) http:\/\/t.co\/Erl4VKsBHt",
  "id" : 318110308520579072,
  "created_at" : "2013-03-30 21:19:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Congress",
      "screen_name" : "OCongress",
      "indices" : [ 3, 13 ],
      "id_str" : "426436217",
      "id" : 426436217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318078295356866561",
  "text" : "RT @OCongress: We can figure out how to land a robot 35 million miles away on Mars; but can't figure out how to end child starvation htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OCongress\/status\/318060409049460738\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/TISiamqhih",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BGn6QcMCMAAQMvC.jpg",
        "id_str" : "318060409057849344",
        "id" : 318060409057849344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGn6QcMCMAAQMvC.jpg",
        "sizes" : [ {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TISiamqhih"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318060409049460738",
    "text" : "We can figure out how to land a robot 35 million miles away on Mars; but can't figure out how to end child starvation http:\/\/t.co\/TISiamqhih",
    "id" : 318060409049460738,
    "created_at" : "2013-03-30 18:01:25 +0000",
    "user" : {
      "name" : "Occupy Congress",
      "screen_name" : "OCongress",
      "protected" : false,
      "id_str" : "426436217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3608563172\/58809960bfbaff49e3a235ddcbbc1270_normal.jpeg",
      "id" : 426436217,
      "verified" : false
    }
  },
  "id" : 318078295356866561,
  "created_at" : "2013-03-30 19:12:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Santaguido",
      "screen_name" : "jensantaguido",
      "indices" : [ 0, 14 ],
      "id_str" : "327103187",
      "id" : 327103187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318041719067262976",
  "geo" : { },
  "id_str" : "318042713108914179",
  "in_reply_to_user_id" : 327103187,
  "text" : "@jensantaguido yup.",
  "id" : 318042713108914179,
  "in_reply_to_status_id" : 318041719067262976,
  "created_at" : "2013-03-30 16:51:06 +0000",
  "in_reply_to_screen_name" : "jensantaguido",
  "in_reply_to_user_id_str" : "327103187",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 3, 13 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    }, {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 64, 74 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/pA0VPYf9p2",
      "expanded_url" : "http:\/\/shar.es\/dtUaH",
      "display_url" : "shar.es\/dtUaH"
    } ]
  },
  "geo" : { },
  "id_str" : "318034222352826368",
  "text" : "RT @Dwayne802: Beauty in the weeds!\n http:\/\/t.co\/pA0VPYf9p2 via @sharethis #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sharethis.com\" rel=\"nofollow\"\u003EShareThis.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShareThis",
        "screen_name" : "ShareThis",
        "indices" : [ 49, 59 ],
        "id_str" : "14116807",
        "id" : 14116807
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 60, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/pA0VPYf9p2",
        "expanded_url" : "http:\/\/shar.es\/dtUaH",
        "display_url" : "shar.es\/dtUaH"
      } ]
    },
    "geo" : { },
    "id_str" : "318031428719882240",
    "text" : "Beauty in the weeds!\n http:\/\/t.co\/pA0VPYf9p2 via @sharethis #photo",
    "id" : 318031428719882240,
    "created_at" : "2013-03-30 16:06:16 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 318034222352826368,
  "created_at" : "2013-03-30 16:17:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trudy",
      "screen_name" : "thetrudz",
      "indices" : [ 3, 12 ],
      "id_str" : "32238490",
      "id" : 32238490
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdland",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318019226537443328",
  "text" : "RT @thetrudz: \"If people can work full time and still be poor, what is work? What does a job mean?\" - MHP #nerdland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nerdland",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318015509402636290",
    "text" : "\"If people can work full time and still be poor, what is work? What does a job mean?\" - MHP #nerdland",
    "id" : 318015509402636290,
    "created_at" : "2013-03-30 15:03:00 +0000",
    "user" : {
      "name" : "Trudy",
      "screen_name" : "thetrudz",
      "protected" : false,
      "id_str" : "32238490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632457470451978243\/ylFDbFgj_normal.png",
      "id" : 32238490,
      "verified" : true
    }
  },
  "id" : 318019226537443328,
  "created_at" : "2013-03-30 15:17:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dark Faerie Tales",
      "screen_name" : "DarkFaerieTales",
      "indices" : [ 3, 19 ],
      "id_str" : "23559325",
      "id" : 23559325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/RCG7ZbJtkM",
      "expanded_url" : "http:\/\/fb.me\/2yEYO0HAX",
      "display_url" : "fb.me\/2yEYO0HAX"
    } ]
  },
  "geo" : { },
  "id_str" : "318013507243229187",
  "text" : "RT @DarkFaerieTales: Help Wanted: Are you interested in reviewing for Dark Faerie Tales? | Dark Faerie Tales http:\/\/t.co\/RCG7ZbJtkM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/RCG7ZbJtkM",
        "expanded_url" : "http:\/\/fb.me\/2yEYO0HAX",
        "display_url" : "fb.me\/2yEYO0HAX"
      } ]
    },
    "geo" : { },
    "id_str" : "318012941951713281",
    "text" : "Help Wanted: Are you interested in reviewing for Dark Faerie Tales? | Dark Faerie Tales http:\/\/t.co\/RCG7ZbJtkM",
    "id" : 318012941951713281,
    "created_at" : "2013-03-30 14:52:48 +0000",
    "user" : {
      "name" : "Dark Faerie Tales",
      "screen_name" : "DarkFaerieTales",
      "protected" : false,
      "id_str" : "23559325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1493551121\/DFT_Button_normal.jpeg",
      "id" : 23559325,
      "verified" : false
    }
  },
  "id" : 318013507243229187,
  "created_at" : "2013-03-30 14:55:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/xeD7nW9kbp",
      "expanded_url" : "http:\/\/tinyurl.com\/c6k53ds",
      "display_url" : "tinyurl.com\/c6k53ds"
    } ]
  },
  "geo" : { },
  "id_str" : "318006672259944449",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields fyi: booklikes http:\/\/t.co\/xeD7nW9kbp",
  "id" : 318006672259944449,
  "created_at" : "2013-03-30 14:27:53 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316657212795781120",
  "geo" : { },
  "id_str" : "317644997757378560",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 exactly.. and he was the one that made her leave, I believe?",
  "id" : 317644997757378560,
  "in_reply_to_status_id" : 316657212795781120,
  "created_at" : "2013-03-29 14:30:43 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashamed of America",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Beth Foster",
      "screen_name" : "BeaFlannigan",
      "indices" : [ 54, 67 ],
      "id_str" : "546765261",
      "id" : 546765261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317464511244288001",
  "geo" : { },
  "id_str" : "317630507976364032",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny aww.. you just made me cry! lol ((hugs)) @BeaFlannigan",
  "id" : 317630507976364032,
  "in_reply_to_status_id" : 317464511244288001,
  "created_at" : "2013-03-29 13:33:09 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/VxCYneDQij",
      "expanded_url" : "http:\/\/tinyurl.com\/8jzyjgo",
      "display_url" : "tinyurl.com\/8jzyjgo"
    } ]
  },
  "geo" : { },
  "id_str" : "317461695347953664",
  "text" : "RT @MWM4444: No-choicers explain what penalties women who have illegal abortions shld pay: http:\/\/t.co\/VxCYneDQij (\"It should be between ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/VxCYneDQij",
        "expanded_url" : "http:\/\/tinyurl.com\/8jzyjgo",
        "display_url" : "tinyurl.com\/8jzyjgo"
      } ]
    },
    "geo" : { },
    "id_str" : "317455744935022593",
    "text" : "No-choicers explain what penalties women who have illegal abortions shld pay: http:\/\/t.co\/VxCYneDQij (\"It should be between her &amp; God.\")",
    "id" : 317455744935022593,
    "created_at" : "2013-03-29 01:58:42 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 317461695347953664,
  "created_at" : "2013-03-29 02:22:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia",
      "screen_name" : "porcelain10",
      "indices" : [ 0, 12 ],
      "id_str" : "316770960",
      "id" : 316770960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317407595419795456",
  "geo" : { },
  "id_str" : "317413513394024449",
  "in_reply_to_user_id" : 316770960,
  "text" : "@porcelain10 i think TA was virgin when he met JA.. gives partial reason for hold over him? She was def more exp. and aggresive.",
  "id" : 317413513394024449,
  "in_reply_to_status_id" : 317407595419795456,
  "created_at" : "2013-03-28 23:10:53 +0000",
  "in_reply_to_screen_name" : "porcelain10",
  "in_reply_to_user_id_str" : "316770960",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317340185203441665",
  "text" : "regardless of how much or what type of sex.. ppl should not be demeaned for such.. and it does not make you evil. #jodiarias",
  "id" : 317340185203441665,
  "created_at" : "2013-03-28 18:19:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317339669304061952",
  "text" : "@ellaray80 its sad.. shes been bamboozled by #jodiarias .. jodi being able to extract just how to act to deceive her.",
  "id" : 317339669304061952,
  "created_at" : "2013-03-28 18:17:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317335735516667905",
  "text" : "frankly, i dont doubt #jodiarias was abused as a child. her anger then turned into personality disorder. she should not be set free, tho.",
  "id" : 317335735516667905,
  "created_at" : "2013-03-28 18:01:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317328525902364674",
  "geo" : { },
  "id_str" : "317329432710897664",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 yup. i gave up watching trial on hln. i watch livestream on my laptop.",
  "id" : 317329432710897664,
  "in_reply_to_status_id" : 317328525902364674,
  "created_at" : "2013-03-28 17:36:47 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317329132025438208",
  "text" : "i gave ALV benefit of doubt until today when she said she only takes case she believes in. another one duped by #jodiarias .. sad.",
  "id" : 317329132025438208,
  "created_at" : "2013-03-28 17:35:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317324296613679106",
  "geo" : { },
  "id_str" : "317327157594558465",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 JM handled w class.. so calm.",
  "id" : 317327157594558465,
  "in_reply_to_status_id" : 317324296613679106,
  "created_at" : "2013-03-28 17:27:44 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kleun13",
      "screen_name" : "kleun13",
      "indices" : [ 0, 8 ],
      "id_str" : "284493778",
      "id" : 284493778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317314838755942400",
  "geo" : { },
  "id_str" : "317317999856070657",
  "in_reply_to_user_id" : 284493778,
  "text" : "@kleun13 wouldnt the forensic dept have come up w that w their software? #jodiarias",
  "id" : 317317999856070657,
  "in_reply_to_status_id" : 317314838755942400,
  "created_at" : "2013-03-28 16:51:21 +0000",
  "in_reply_to_screen_name" : "kleun13",
  "in_reply_to_user_id_str" : "284493778",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "possum",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/6sTs6atWAM",
      "expanded_url" : "http:\/\/www.wwlp.com\/dpps\/entertainment\/must_see_video\/pregnant-possum-hitches-ride-on-kayak-nd13_5839950",
      "display_url" : "wwlp.com\/dpps\/entertain\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317314913334861825",
  "text" : "Pregnant #possum hitches ride on kayak http:\/\/t.co\/6sTs6atWAM",
  "id" : 317314913334861825,
  "created_at" : "2013-03-28 16:39:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Insurance Slayer",
      "screen_name" : "RedTapeLass",
      "indices" : [ 3, 15 ],
      "id_str" : "190419341",
      "id" : 190419341
    }, {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 78, 90 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arizona",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/tmhnHJxape",
      "expanded_url" : "http:\/\/huff.to\/14pUWsq",
      "display_url" : "huff.to\/14pUWsq"
    } ]
  },
  "geo" : { },
  "id_str" : "317298823498199041",
  "text" : "RT @RedTapeLass: AZ Transgender Bathroom Bill OK'd http:\/\/t.co\/tmhnHJxape via @HuffPostPol #Arizona has done a lot I'm ashamed of, but t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost Politics",
        "screen_name" : "HuffPostPol",
        "indices" : [ 61, 73 ],
        "id_str" : "15458694",
        "id" : 15458694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Arizona",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/tmhnHJxape",
        "expanded_url" : "http:\/\/huff.to\/14pUWsq",
        "display_url" : "huff.to\/14pUWsq"
      } ]
    },
    "geo" : { },
    "id_str" : "317297244703424513",
    "text" : "AZ Transgender Bathroom Bill OK'd http:\/\/t.co\/tmhnHJxape via @HuffPostPol #Arizona has done a lot I'm ashamed of, but this - inhumane. Shame",
    "id" : 317297244703424513,
    "created_at" : "2013-03-28 15:28:52 +0000",
    "user" : {
      "name" : "Insurance Slayer",
      "screen_name" : "RedTapeLass",
      "protected" : false,
      "id_str" : "190419341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614850301506355202\/46JmCeLF_normal.jpg",
      "id" : 190419341,
      "verified" : false
    }
  },
  "id" : 317298823498199041,
  "created_at" : "2013-03-28 15:35:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discovery News",
      "screen_name" : "Discovery_News",
      "indices" : [ 3, 18 ],
      "id_str" : "2835656636",
      "id" : 2835656636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/fMaN5wFico",
      "expanded_url" : "http:\/\/ow.ly\/2vxKOm",
      "display_url" : "ow.ly\/2vxKOm"
    } ]
  },
  "geo" : { },
  "id_str" : "317298759702822914",
  "text" : "RT @Discovery_News: Pope Francis Breaks Rules to Bless Guide Dog http:\/\/t.co\/fMaN5wFico",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/fMaN5wFico",
        "expanded_url" : "http:\/\/ow.ly\/2vxKOm",
        "display_url" : "ow.ly\/2vxKOm"
      } ]
    },
    "geo" : { },
    "id_str" : "313370175787372544",
    "text" : "Pope Francis Breaks Rules to Bless Guide Dog http:\/\/t.co\/fMaN5wFico",
    "id" : 313370175787372544,
    "created_at" : "2013-03-17 19:24:06 +0000",
    "user" : {
      "name" : "Seeker",
      "screen_name" : "Seeker",
      "protected" : false,
      "id_str" : "16438248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789540319658475520\/EnANLPy2_normal.jpg",
      "id" : 16438248,
      "verified" : true
    }
  },
  "id" : 317298759702822914,
  "created_at" : "2013-03-28 15:34:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/rk6vpgQ1J9",
      "expanded_url" : "http:\/\/bit.ly\/kwn0328",
      "display_url" : "bit.ly\/kwn0328"
    } ]
  },
  "geo" : { },
  "id_str" : "317295600439799808",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields FYI - kindle touch http:\/\/t.co\/rk6vpgQ1J9",
  "id" : 317295600439799808,
  "created_at" : "2013-03-28 15:22:20 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 19, 27 ]
    }, {
      "text" : "science",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/WlQTl0R43a",
      "expanded_url" : "http:\/\/sphotos-a.xx.fbcdn.net\/hphotos-ash4\/488270_410946782335485_1209087469_n.jpg",
      "display_url" : "sphotos-a.xx.fbcdn.net\/hphotos-ash4\/4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317289084848570368",
  "text" : "a funny pic for my #atheist peeps http:\/\/t.co\/WlQTl0R43a #science",
  "id" : 317289084848570368,
  "created_at" : "2013-03-28 14:56:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty",
      "screen_name" : "betty3059",
      "indices" : [ 0, 10 ],
      "id_str" : "632424095",
      "id" : 632424095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317262927864410114",
  "geo" : { },
  "id_str" : "317279333309898752",
  "in_reply_to_user_id" : 632424095,
  "text" : "@betty3059 my view: she was his 1st (emotional bond), sex is new, forbidden sex (religion); she manipulated his emotions. he was nice guy.",
  "id" : 317279333309898752,
  "in_reply_to_status_id" : 317262927864410114,
  "created_at" : "2013-03-28 14:17:42 +0000",
  "in_reply_to_screen_name" : "betty3059",
  "in_reply_to_user_id_str" : "632424095",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317066641382965248",
  "text" : "RT @virtusetveritas: Y'know what, DeYoung? I am displaying courage, RIGHT NOW, for being an evangelical and disagreeing with you in public.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317062428053602304",
    "text" : "Y'know what, DeYoung? I am displaying courage, RIGHT NOW, for being an evangelical and disagreeing with you in public.",
    "id" : 317062428053602304,
    "created_at" : "2013-03-27 23:55:48 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 317066641382965248,
  "created_at" : "2013-03-28 00:12:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/2rTNaWYd99",
      "expanded_url" : "http:\/\/goo.gl\/iTNdV",
      "display_url" : "goo.gl\/iTNdV"
    } ]
  },
  "geo" : { },
  "id_str" : "317065344151851009",
  "text" : "RT @virtusetveritas: http:\/\/t.co\/2rTNaWYd99 twitter rampage commencing about this article.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/2rTNaWYd99",
        "expanded_url" : "http:\/\/goo.gl\/iTNdV",
        "display_url" : "goo.gl\/iTNdV"
      } ]
    },
    "geo" : { },
    "id_str" : "317059326294495232",
    "text" : "http:\/\/t.co\/2rTNaWYd99 twitter rampage commencing about this article.",
    "id" : 317059326294495232,
    "created_at" : "2013-03-27 23:43:28 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 317065344151851009,
  "created_at" : "2013-03-28 00:07:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317063921779503104",
  "text" : "RT @virtusetveritas: I support it because I don't think my faith or religion should be dictated to other people. Our founding documents  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317062120493678592",
    "text" : "I support it because I don't think my faith or religion should be dictated to other people. Our founding documents tried to avoid this mess.",
    "id" : 317062120493678592,
    "created_at" : "2013-03-27 23:54:34 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 317063921779503104,
  "created_at" : "2013-03-28 00:01:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317010618274156544",
  "geo" : { },
  "id_str" : "317011525686685696",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste one lady was asking about dogs and vacuum cleaners..lol",
  "id" : 317011525686685696,
  "in_reply_to_status_id" : 317010618274156544,
  "created_at" : "2013-03-27 20:33:32 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317010028714422273",
  "text" : "I'm confused.. am I For or Against DOMA?",
  "id" : 317010028714422273,
  "created_at" : "2013-03-27 20:27:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316969357295116288",
  "text" : "RT @bookwiseblog: Kindles on Planes by Next Year: I am a big fan of kindles. \u00A0I vastly prefer digital books (either audio or kin... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Bza8svTo86",
        "expanded_url" : "http:\/\/bit.ly\/11Nez9R",
        "display_url" : "bit.ly\/11Nez9R"
      } ]
    },
    "geo" : { },
    "id_str" : "316968625850425344",
    "text" : "Kindles on Planes by Next Year: I am a big fan of kindles. \u00A0I vastly prefer digital books (either audio or kin... http:\/\/t.co\/Bza8svTo86",
    "id" : 316968625850425344,
    "created_at" : "2013-03-27 17:43:04 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 316969357295116288,
  "created_at" : "2013-03-27 17:45:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 0, 15 ],
      "id_str" : "466879335",
      "id" : 466879335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316957411338485760",
  "geo" : { },
  "id_str" : "316959320766033921",
  "in_reply_to_user_id" : 466879335,
  "text" : "@ThatOtherChris Yay!! : )",
  "id" : 316959320766033921,
  "in_reply_to_status_id" : 316957411338485760,
  "created_at" : "2013-03-27 17:06:05 +0000",
  "in_reply_to_screen_name" : "ThatOtherChris",
  "in_reply_to_user_id_str" : "466879335",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 0, 15 ],
      "id_str" : "466879335",
      "id" : 466879335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316951769848619009",
  "geo" : { },
  "id_str" : "316956811288788992",
  "in_reply_to_user_id" : 466879335,
  "text" : "@ThatOtherChris 1) God is love therefore cannot hate 2) separation of church and state",
  "id" : 316956811288788992,
  "in_reply_to_status_id" : 316951769848619009,
  "created_at" : "2013-03-27 16:56:07 +0000",
  "in_reply_to_screen_name" : "ThatOtherChris",
  "in_reply_to_user_id_str" : "466879335",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/g6yhu6nUTg",
      "expanded_url" : "http:\/\/youtu.be\/eZxv5WCWivM",
      "display_url" : "youtu.be\/eZxv5WCWivM"
    } ]
  },
  "geo" : { },
  "id_str" : "316946820276305920",
  "text" : "A young man hovers over a passed-out girl and invites his \"bros\" to see what he'll do next: http:\/\/t.co\/g6yhu6nUTg",
  "id" : 316946820276305920,
  "created_at" : "2013-03-27 16:16:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashtag",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316944879878041600",
  "text" : "Is there a #hashtag for introducing ppl to each other? if not, someone come up with it, please.",
  "id" : 316944879878041600,
  "created_at" : "2013-03-27 16:08:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 0, 10 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316943422630014976",
  "geo" : { },
  "id_str" : "316944205756891137",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne802 oh yeah.. that. hehe.. been there.",
  "id" : 316944205756891137,
  "in_reply_to_status_id" : 316943422630014976,
  "created_at" : "2013-03-27 16:06:01 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 0, 10 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316940422490497024",
  "geo" : { },
  "id_str" : "316942372825079808",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne802 i had to learn to like myself first and realize its ok if someone doesnt care for me",
  "id" : 316942372825079808,
  "in_reply_to_status_id" : 316940422490497024,
  "created_at" : "2013-03-27 15:58:44 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 2, 12 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316940422490497024",
  "geo" : { },
  "id_str" : "316942088807784449",
  "in_reply_to_user_id" : 73908822,
  "text" : ". @Dwayne802 really, its only been since i hit 40's that i could let myself out of the cage, so to speak..lol",
  "id" : 316942088807784449,
  "in_reply_to_status_id" : 316940422490497024,
  "created_at" : "2013-03-27 15:57:37 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 0, 10 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316940422490497024",
  "geo" : { },
  "id_str" : "316941672242106368",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne802 BINGO!! : ) &gt;&gt; \"the key is I like me so that is what counts.\"",
  "id" : 316941672242106368,
  "in_reply_to_status_id" : 316940422490497024,
  "created_at" : "2013-03-27 15:55:57 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316941057835282432",
  "text" : "RT @LukeRomyn: Barry White is what people had before porn.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316939583801659392",
    "text" : "Barry White is what people had before porn.",
    "id" : 316939583801659392,
    "created_at" : "2013-03-27 15:47:39 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 316941057835282432,
  "created_at" : "2013-03-27 15:53:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "indices" : [ 0, 11 ],
      "id_str" : "21497211",
      "id" : 21497211
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 17, 29 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "indices" : [ 30, 42 ],
      "id_str" : "27905866",
      "id" : 27905866
    }, {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 43, 56 ],
      "id_str" : "15364301",
      "id" : 15364301
    }, {
      "name" : "Jeremy John",
      "screen_name" : "glassdimly",
      "indices" : [ 57, 68 ],
      "id_str" : "247971836",
      "id" : 247971836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316940905334583297",
  "in_reply_to_user_id" : 21497211,
  "text" : "@jedwards06 meet @ReverendSue @rev_heather @BrianMerritt @glassdimly",
  "id" : 316940905334583297,
  "created_at" : "2013-03-27 15:52:54 +0000",
  "in_reply_to_screen_name" : "jedwards06",
  "in_reply_to_user_id_str" : "21497211",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 0, 10 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316939179705630720",
  "geo" : { },
  "id_str" : "316940089466957824",
  "in_reply_to_user_id" : 73908822,
  "text" : "@Dwayne802 absolutely!",
  "id" : 316940089466957824,
  "in_reply_to_status_id" : 316939179705630720,
  "created_at" : "2013-03-27 15:49:40 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316939395431276544",
  "text" : "i should list Twitter as my address on forms.. cuz it really is like home to me. i am truly myself on here..lol",
  "id" : 316939395431276544,
  "created_at" : "2013-03-27 15:46:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316937774253088768",
  "text" : "sometimes peeps surprise me w their views.. then again im sure i often surprise ppl w my views..",
  "id" : 316937774253088768,
  "created_at" : "2013-03-27 15:40:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlekeyboard",
      "indices" : [ 23, 38 ]
    }, {
      "text" : "paperwhite",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316931363527876608",
  "text" : "I wish they would make #kindlekeyboard more like #paperwhite .. faster, book view.",
  "id" : 316931363527876608,
  "created_at" : "2013-03-27 15:15:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Downpour.com",
      "screen_name" : "downpour_com",
      "indices" : [ 3, 16 ],
      "id_str" : "612905318",
      "id" : 612905318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316928595190751232",
  "text" : "RT @downpour_com: Enter to win a pair of Skullcandy \u201CThe Fix\u201D ear buds &amp; your favorite audio books will sound better than ever &gt;  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rw9bPCPfEX",
        "expanded_url" : "http:\/\/ow.ly\/iKZkR",
        "display_url" : "ow.ly\/iKZkR"
      } ]
    },
    "geo" : { },
    "id_str" : "316928177425510401",
    "text" : "Enter to win a pair of Skullcandy \u201CThe Fix\u201D ear buds &amp; your favorite audio books will sound better than ever &gt; http:\/\/t.co\/rw9bPCPfEX",
    "id" : 316928177425510401,
    "created_at" : "2013-03-27 15:02:20 +0000",
    "user" : {
      "name" : "Downpour.com",
      "screen_name" : "downpour_com",
      "protected" : false,
      "id_str" : "612905318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556139343933222912\/mmW8HJr4_normal.jpeg",
      "id" : 612905318,
      "verified" : false
    }
  },
  "id" : 316928595190751232,
  "created_at" : "2013-03-27 15:04:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "paperwhite",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316928427796074497",
  "text" : "i know im feeling better when im back to reading my #kindle #paperwhite in bed.. yay!",
  "id" : 316928427796074497,
  "created_at" : "2013-03-27 15:03:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caroline Horn",
      "screen_name" : "CNHorn",
      "indices" : [ 8, 15 ],
      "id_str" : "199836680",
      "id" : 199836680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/r6xOYJtgdo",
      "expanded_url" : "http:\/\/cbsn.ws\/XefFg3",
      "display_url" : "cbsn.ws\/XefFg3"
    } ]
  },
  "geo" : { },
  "id_str" : "316927085409075200",
  "text" : "Darn RT @CNHorn: Gov. Christie on Prince Harry's visit to New Jersey: \"Nobody's gonna get naked.\" http:\/\/t.co\/r6xOYJtgdo",
  "id" : 316927085409075200,
  "created_at" : "2013-03-27 14:58:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "indices" : [ 3, 15 ],
      "id_str" : "25090088",
      "id" : 25090088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316923513980211200",
  "text" : "RT @BenMWallace: My coffee maker is really off on what it thinks a cup is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316922294809276416",
    "text" : "My coffee maker is really off on what it thinks a cup is.",
    "id" : 316922294809276416,
    "created_at" : "2013-03-27 14:38:57 +0000",
    "user" : {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "protected" : false,
      "id_str" : "25090088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560492072914796544\/pPK5ZIrh_normal.png",
      "id" : 25090088,
      "verified" : false
    }
  },
  "id" : 316923513980211200,
  "created_at" : "2013-03-27 14:43:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 0, 15 ],
      "id_str" : "466879335",
      "id" : 466879335
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 16, 28 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316922667800350720",
  "in_reply_to_user_id" : 466879335,
  "text" : "@ThatOtherChris @VirgoJohnny i think you two would get along. (there should be a hashtag for introducing ppl)",
  "id" : 316922667800350720,
  "created_at" : "2013-03-27 14:40:26 +0000",
  "in_reply_to_screen_name" : "ThatOtherChris",
  "in_reply_to_user_id_str" : "466879335",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "indices" : [ 3, 18 ],
      "id_str" : "466879335",
      "id" : 466879335
    }, {
      "name" : "SandyK",
      "screen_name" : "Sandylogos",
      "indices" : [ 25, 36 ],
      "id_str" : "1301736050",
      "id" : 1301736050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316724226767876097",
  "text" : "RT @ThatOtherChris: This @Sandylogos is giving me ALL the useless Christianist hate. Now she wants to marry her dog and vacuum.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SandyK",
        "screen_name" : "Sandylogos",
        "indices" : [ 5, 16 ],
        "id_str" : "1301736050",
        "id" : 1301736050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316718509705019392",
    "text" : "This @Sandylogos is giving me ALL the useless Christianist hate. Now she wants to marry her dog and vacuum.",
    "id" : 316718509705019392,
    "created_at" : "2013-03-27 01:09:11 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "ThatOtherChris",
      "protected" : false,
      "id_str" : "466879335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000251177786\/3835313b348120cb52a53973e58d692a_normal.jpeg",
      "id" : 466879335,
      "verified" : false
    }
  },
  "id" : 316724226767876097,
  "created_at" : "2013-03-27 01:31:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316693015001452544",
  "text" : "RT @Buddhaworld: Everybody is the center of the universe. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316692648104714240",
    "text" : "Everybody is the center of the universe. Buddha volko",
    "id" : 316692648104714240,
    "created_at" : "2013-03-26 23:26:25 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 316693015001452544,
  "created_at" : "2013-03-26 23:27:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Cavoukian",
      "screen_name" : "Raffi_RC",
      "indices" : [ 3, 12 ],
      "id_str" : "268416076",
      "id" : 268416076
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "girls",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "selfregard",
      "indices" : [ 96, 107 ]
    }, {
      "text" : "healthysexuality",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/YWs4wG9WWs",
      "expanded_url" : "http:\/\/evandolive.com\/2013\/03\/22\/a-letter-to-victorias-secret-from-a-father\/",
      "display_url" : "evandolive.com\/2013\/03\/22\/a-l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316691323094712320",
  "text" : "RT @Raffi_RC: A Letter to Victoria\u2019s Secret From a Father http:\/\/t.co\/YWs4wG9WWs pls RT. #girls #selfregard #healthysexuality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "girls",
        "indices" : [ 75, 81 ]
      }, {
        "text" : "selfregard",
        "indices" : [ 82, 93 ]
      }, {
        "text" : "healthysexuality",
        "indices" : [ 94, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/YWs4wG9WWs",
        "expanded_url" : "http:\/\/evandolive.com\/2013\/03\/22\/a-letter-to-victorias-secret-from-a-father\/",
        "display_url" : "evandolive.com\/2013\/03\/22\/a-l\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "316685838111088640",
    "text" : "A Letter to Victoria\u2019s Secret From a Father http:\/\/t.co\/YWs4wG9WWs pls RT. #girls #selfregard #healthysexuality",
    "id" : 316685838111088640,
    "created_at" : "2013-03-26 22:59:22 +0000",
    "user" : {
      "name" : "Raffi Cavoukian",
      "screen_name" : "Raffi_RC",
      "protected" : false,
      "id_str" : "268416076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656493750751879170\/kFkII36p_normal.jpg",
      "id" : 268416076,
      "verified" : true
    }
  },
  "id" : 316691323094712320,
  "created_at" : "2013-03-26 23:21:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316683267514462208",
  "geo" : { },
  "id_str" : "316685178254802946",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell ((fisttap)) you go, girl",
  "id" : 316685178254802946,
  "in_reply_to_status_id" : 316683267514462208,
  "created_at" : "2013-03-26 22:56:44 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 3, 16 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316684134158319618",
  "text" : "RT @JoanneMFirth: Marriage should be a bond between two loving human beings who want to share their life, dreams and futures together. T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316682451403563008",
    "text" : "Marriage should be a bond between two loving human beings who want to share their life, dreams and futures together. The good and bad of it.",
    "id" : 316682451403563008,
    "created_at" : "2013-03-26 22:45:54 +0000",
    "user" : {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "protected" : false,
      "id_str" : "133780513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781251467135029255\/diCGFaAe_normal.jpg",
      "id" : 133780513,
      "verified" : false
    }
  },
  "id" : 316684134158319618,
  "created_at" : "2013-03-26 22:52:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316677728390766592",
  "text" : "RT @TyrusBooks: Everybody's free until they try the door.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316676770055204864",
    "text" : "Everybody's free until they try the door.",
    "id" : 316676770055204864,
    "created_at" : "2013-03-26 22:23:20 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 316677728390766592,
  "created_at" : "2013-03-26 22:27:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316676999378792448",
  "text" : "RT @bookwiseblog: Kindle Touch Software Upgrade Makes it More like the Paperwhite: The Kindle Touch, a now discontinued, Kindle ... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/caFnMgc3H4",
        "expanded_url" : "http:\/\/bit.ly\/11IMnsk",
        "display_url" : "bit.ly\/11IMnsk"
      } ]
    },
    "geo" : { },
    "id_str" : "316676623061630978",
    "text" : "Kindle Touch Software Upgrade Makes it More like the Paperwhite: The Kindle Touch, a now discontinued, Kindle ... http:\/\/t.co\/caFnMgc3H4",
    "id" : 316676623061630978,
    "created_at" : "2013-03-26 22:22:45 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 316676999378792448,
  "created_at" : "2013-03-26 22:24:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316662465238810624",
  "geo" : { },
  "id_str" : "316663198080188416",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 its like she's trying to come up w questions to not let her go to cross..",
  "id" : 316663198080188416,
  "in_reply_to_status_id" : 316662465238810624,
  "created_at" : "2013-03-26 21:29:24 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yupimoneofthosenuts",
      "indices" : [ 95, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316660357370372096",
  "geo" : { },
  "id_str" : "316661917697581057",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny no you cant.. thats why im careful whom i share what i believe re certain events. #yupimoneofthosenuts",
  "id" : 316661917697581057,
  "in_reply_to_status_id" : 316660357370372096,
  "created_at" : "2013-03-26 21:24:19 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 26, 40 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/N2LDfHMfIi",
      "expanded_url" : "http:\/\/www.knowords.com",
      "display_url" : "knowords.com"
    } ]
  },
  "in_reply_to_status_id_str" : "316654950845403136",
  "geo" : { },
  "id_str" : "316656287771410432",
  "in_reply_to_user_id" : 28863804,
  "text" : "perfect for #jodiarias RT @Wylieknowords \"Narcissists Always See Eye To I. \"  N. Wylie Jones http:\/\/t.co\/N2LDfHMfIi",
  "id" : 316656287771410432,
  "in_reply_to_status_id" : 316654950845403136,
  "created_at" : "2013-03-26 21:01:56 +0000",
  "in_reply_to_screen_name" : "Wylieknowords",
  "in_reply_to_user_id_str" : "28863804",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mobileplans",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316633129643290625",
  "text" : "how much cost for 3 family members to get cell phones w unlimited data per month? #mobileplans",
  "id" : 316633129643290625,
  "created_at" : "2013-03-26 19:29:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316630471868043266",
  "geo" : { },
  "id_str" : "316631935076159488",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 this witness clearly describes JA as abuser. she just slamdunked for JM.",
  "id" : 316631935076159488,
  "in_reply_to_status_id" : 316630471868043266,
  "created_at" : "2013-03-26 19:25:10 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "larry reeves",
      "screen_name" : "larryreeves",
      "indices" : [ 0, 12 ],
      "id_str" : "15667602",
      "id" : 15667602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316627774133653505",
  "geo" : { },
  "id_str" : "316630212869771264",
  "in_reply_to_user_id" : 15667602,
  "text" : "@larryreeves : )",
  "id" : 316630212869771264,
  "in_reply_to_status_id" : 316627774133653505,
  "created_at" : "2013-03-26 19:18:20 +0000",
  "in_reply_to_screen_name" : "larryreeves",
  "in_reply_to_user_id_str" : "15667602",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316627192224305153",
  "text" : "is it possible AL feels #jodiarias guilty but knows her testimony will backfire on defense? (and she gets paid for it!)",
  "id" : 316627192224305153,
  "created_at" : "2013-03-26 19:06:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316622658735333376",
  "geo" : { },
  "id_str" : "316625608367038465",
  "in_reply_to_user_id" : 16495811,
  "text" : "@robynd323 i think AL is nail in JA's coffin.. kinda feel bad for JW..",
  "id" : 316625608367038465,
  "in_reply_to_status_id" : 316622658735333376,
  "created_at" : "2013-03-26 19:00:02 +0000",
  "in_reply_to_screen_name" : "robyns323",
  "in_reply_to_user_id_str" : "16495811",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Spaulding",
      "screen_name" : "amyspaulding",
      "indices" : [ 0, 13 ],
      "id_str" : "21965752",
      "id" : 21965752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316621924446904320",
  "geo" : { },
  "id_str" : "316623629980934144",
  "in_reply_to_user_id" : 21965752,
  "text" : "@amyspaulding see? im emotional thinker, dont like to make someone feel left out..lol",
  "id" : 316623629980934144,
  "in_reply_to_status_id" : 316621924446904320,
  "created_at" : "2013-03-26 18:52:10 +0000",
  "in_reply_to_screen_name" : "amyspaulding",
  "in_reply_to_user_id_str" : "21965752",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316622279960326144",
  "text" : "@Robert__Frank its funny cuz usually i tend to have some empathy 4 accused. in this case, im not feeling it. so im confused w JA support.",
  "id" : 316622279960326144,
  "created_at" : "2013-03-26 18:46:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ms_Snarky",
      "screen_name" : "sparkyrocks",
      "indices" : [ 0, 12 ],
      "id_str" : "18048698",
      "id" : 18048698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316615900927250433",
  "geo" : { },
  "id_str" : "316621503204564995",
  "in_reply_to_user_id" : 18048698,
  "text" : "@sparkyrocks absolutely! lol",
  "id" : 316621503204564995,
  "in_reply_to_status_id" : 316615900927250433,
  "created_at" : "2013-03-26 18:43:43 +0000",
  "in_reply_to_screen_name" : "sparkyrocks",
  "in_reply_to_user_id_str" : "18048698",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Spaulding",
      "screen_name" : "amyspaulding",
      "indices" : [ 0, 13 ],
      "id_str" : "21965752",
      "id" : 21965752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316614947058638848",
  "geo" : { },
  "id_str" : "316621340545253376",
  "in_reply_to_user_id" : 21965752,
  "text" : "@amyspaulding LOL.. sure!",
  "id" : 316621340545253376,
  "in_reply_to_status_id" : 316614947058638848,
  "created_at" : "2013-03-26 18:43:04 +0000",
  "in_reply_to_screen_name" : "amyspaulding",
  "in_reply_to_user_id_str" : "21965752",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash",
      "screen_name" : "AshyAlxandra",
      "indices" : [ 0, 13 ],
      "id_str" : "1018440002",
      "id" : 1018440002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316619644255477760",
  "geo" : { },
  "id_str" : "316620641883267075",
  "in_reply_to_user_id" : 1018440002,
  "text" : "@AshyAlxandra yup.. totally agree",
  "id" : 316620641883267075,
  "in_reply_to_status_id" : 316619644255477760,
  "created_at" : "2013-03-26 18:40:18 +0000",
  "in_reply_to_screen_name" : "AshyAlxandra",
  "in_reply_to_user_id_str" : "1018440002",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ash",
      "screen_name" : "AshyAlxandra",
      "indices" : [ 0, 13 ],
      "id_str" : "1018440002",
      "id" : 1018440002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316618769600483328",
  "geo" : { },
  "id_str" : "316619363933356033",
  "in_reply_to_user_id" : 1018440002,
  "text" : "@AshyAlxandra depends upon personality\/experience of each.. not necc age diff.",
  "id" : 316619363933356033,
  "in_reply_to_status_id" : 316618769600483328,
  "created_at" : "2013-03-26 18:35:13 +0000",
  "in_reply_to_screen_name" : "AshyAlxandra",
  "in_reply_to_user_id_str" : "1018440002",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316618817654648836",
  "text" : "@Robert__Frank sure! really anybody who thinks logically. i am very emotional thinker #INFP .. yet i see JA guilty,guilty,guilty.",
  "id" : 316618817654648836,
  "created_at" : "2013-03-26 18:33:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SharonFan1st ~May~",
      "screen_name" : "sharonfanfirst",
      "indices" : [ 3, 18 ],
      "id_str" : "408900459",
      "id" : 408900459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316617709418852352",
  "text" : "RT @sharonfanfirst: Strange how many behaviors of #JodiArias  this witness is describing w\/Jodi as the abuser, stalker, provoker &amp; n ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 30, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316616440608337921",
    "text" : "Strange how many behaviors of #JodiArias  this witness is describing w\/Jodi as the abuser, stalker, provoker &amp; not TA'a",
    "id" : 316616440608337921,
    "created_at" : "2013-03-26 18:23:36 +0000",
    "user" : {
      "name" : "SharonFan1st ~May~",
      "screen_name" : "sharonfanfirst",
      "protected" : false,
      "id_str" : "408900459",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799290464469995520\/MrCJgj2r_normal.jpg",
      "id" : 408900459,
      "verified" : false
    }
  },
  "id" : 316617709418852352,
  "created_at" : "2013-03-26 18:28:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 0, 10 ],
      "id_str" : "82447359",
      "id" : 82447359
    }, {
      "name" : "Ruthiesrollingcafe",
      "screen_name" : "Ruthiesrolling",
      "indices" : [ 70, 85 ],
      "id_str" : "336212717",
      "id" : 336212717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316614249352945664",
  "geo" : { },
  "id_str" : "316617379058700288",
  "in_reply_to_user_id" : 82447359,
  "text" : "@ScottBaio perhaps a fan just excited to see you wearing their shirt? @Ruthiesrolling",
  "id" : 316617379058700288,
  "in_reply_to_status_id" : 316614249352945664,
  "created_at" : "2013-03-26 18:27:20 +0000",
  "in_reply_to_screen_name" : "ScottBaio",
  "in_reply_to_user_id_str" : "82447359",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Hale",
      "screen_name" : "Richard_C_Hale",
      "indices" : [ 3, 18 ],
      "id_str" : "33230438",
      "id" : 33230438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316616966532108290",
  "text" : "RT @Richard_C_Hale: \"If thought bubbles appeared above my head, I'd be screwed.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316615024120586240",
    "text" : "\"If thought bubbles appeared above my head, I'd be screwed.\"",
    "id" : 316615024120586240,
    "created_at" : "2013-03-26 18:17:58 +0000",
    "user" : {
      "name" : "Richard Hale",
      "screen_name" : "Richard_C_Hale",
      "protected" : false,
      "id_str" : "33230438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/578600542924120064\/heUFS_dq_normal.jpeg",
      "id" : 33230438,
      "verified" : false
    }
  },
  "id" : 316616966532108290,
  "created_at" : "2013-03-26 18:25:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316616718728450049",
  "text" : "@JustRosey21 absolutely. in fact, she seemed to be more pursuer.. calling\/visiting\/wanting to see him. he had other things going on.",
  "id" : 316616718728450049,
  "created_at" : "2013-03-26 18:24:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shannon",
      "screen_name" : "groove2theblues",
      "indices" : [ 0, 16 ],
      "id_str" : "203804565",
      "id" : 203804565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316613565442301952",
  "geo" : { },
  "id_str" : "316615948855554048",
  "in_reply_to_user_id" : 203804565,
  "text" : "@groove2theblues yup.. they dated (bf\/gf) like 5 months? hardly worth a mention in terms of dating history.",
  "id" : 316615948855554048,
  "in_reply_to_status_id" : 316613565442301952,
  "created_at" : "2013-03-26 18:21:39 +0000",
  "in_reply_to_screen_name" : "groove2theblues",
  "in_reply_to_user_id_str" : "203804565",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316615111546654720",
  "text" : "RT @derekrootboy: God came to me in a dream to say he's cool with me making jokes about him. Thanks a lot. You've taken all the fun out  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "philosophy",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316614137553776640",
    "text" : "God came to me in a dream to say he's cool with me making jokes about him. Thanks a lot. You've taken all the fun out of it. #philosophy",
    "id" : 316614137553776640,
    "created_at" : "2013-03-26 18:14:27 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 316615111546654720,
  "created_at" : "2013-03-26 18:18:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316614531570880512",
  "text" : "any atheists watching #jodiarias trial? (i ask becuz, atheists are very logic\/proof oriented.. good 4 looking at evidence)",
  "id" : 316614531570880512,
  "created_at" : "2013-03-26 18:16:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dmmcglynn",
      "screen_name" : "dmmcglynn",
      "indices" : [ 3, 13 ],
      "id_str" : "211908135",
      "id" : 211908135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316612806000660480",
  "text" : "RT @dmmcglynn: There was no 'family' or even partnership. They weren't even dating. #JodiArias was stalking! What rules apply to that AL?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316611834713108481",
    "text" : "There was no 'family' or even partnership. They weren't even dating. #JodiArias was stalking! What rules apply to that AL?",
    "id" : 316611834713108481,
    "created_at" : "2013-03-26 18:05:18 +0000",
    "user" : {
      "name" : "dmmcglynn",
      "screen_name" : "dmmcglynn",
      "protected" : false,
      "id_str" : "211908135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773256739689000960\/O6jUPeSC_normal.jpg",
      "id" : 211908135,
      "verified" : false
    }
  },
  "id" : 316612806000660480,
  "created_at" : "2013-03-26 18:09:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316611370705645569",
  "text" : "ok.. now the \"dress alike\" thing IS getting creepy #jodiarias",
  "id" : 316611370705645569,
  "created_at" : "2013-03-26 18:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316608668768559105",
  "geo" : { },
  "id_str" : "316609774668111872",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 i cannot imagine.. ((hugs))",
  "id" : 316609774668111872,
  "in_reply_to_status_id" : 316608668768559105,
  "created_at" : "2013-03-26 17:57:07 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316601915024752641",
  "geo" : { },
  "id_str" : "316603514921046016",
  "in_reply_to_user_id" : 285647538,
  "text" : "@SingleMom2Gage which info?",
  "id" : 316603514921046016,
  "in_reply_to_status_id" : 316601915024752641,
  "created_at" : "2013-03-26 17:32:14 +0000",
  "in_reply_to_screen_name" : "ProudPatriotVet",
  "in_reply_to_user_id_str" : "285647538",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316601689803194368",
  "text" : "how can anyone believe TA abused #jodiarias? No evidence whatsoever! plus she lived distance away for most part. she would go to him!",
  "id" : 316601689803194368,
  "created_at" : "2013-03-26 17:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316600088237600768",
  "text" : "RT @richarddoetsch: Everyone should have to walk in someone else's shoes at least once a month, the effect would be amazing...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316599659692965890",
    "text" : "Everyone should have to walk in someone else's shoes at least once a month, the effect would be amazing...",
    "id" : 316599659692965890,
    "created_at" : "2013-03-26 17:16:55 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 316600088237600768,
  "created_at" : "2013-03-26 17:18:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIMENOUT",
      "screen_name" : "TIMENOUT",
      "indices" : [ 24, 33 ],
      "id_str" : "54769979",
      "id" : 54769979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/U2ky1T5M9S",
      "expanded_url" : "https:\/\/twitter.com\/TIMENOUT\/status\/316573768053047297\/photo\/1",
      "display_url" : "pic.twitter.com\/U2ky1T5M9S"
    } ]
  },
  "in_reply_to_status_id_str" : "316575571234668545",
  "geo" : { },
  "id_str" : "316593326272958464",
  "in_reply_to_user_id" : 54769979,
  "text" : "Jury, focus on THIS! RT @TIMENOUT #jodiarias Travis Alexander's Photo timeline: From 5:22:24 to 5:33:32 = 11:18 mins http:\/\/t.co\/U2ky1T5M9S",
  "id" : 316593326272958464,
  "in_reply_to_status_id" : 316575571234668545,
  "created_at" : "2013-03-26 16:51:45 +0000",
  "in_reply_to_screen_name" : "TIMENOUT",
  "in_reply_to_user_id_str" : "54769979",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 0, 15 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316589998939967489",
  "geo" : { },
  "id_str" : "316590266645626881",
  "in_reply_to_user_id" : 18538833,
  "text" : "@ZeitgeistGhost B.I.N.G.O. !!",
  "id" : 316590266645626881,
  "in_reply_to_status_id" : 316589998939967489,
  "created_at" : "2013-03-26 16:39:36 +0000",
  "in_reply_to_screen_name" : "ZeitgeistGhost",
  "in_reply_to_user_id_str" : "18538833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316590131521933312",
  "text" : "RT @JacksonPearce: I wish people would STFU about this being a states' rights issue. If that's the case, we ALL need to get remarried wh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316590018749689856",
    "text" : "I wish people would STFU about this being a states' rights issue. If that's the case, we ALL need to get remarried when we move. So. Stop.",
    "id" : 316590018749689856,
    "created_at" : "2013-03-26 16:38:37 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 316590131521933312,
  "created_at" : "2013-03-26 16:39:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Zenda",
      "screen_name" : "JenniferZenda",
      "indices" : [ 3, 17 ],
      "id_str" : "287297332",
      "id" : 287297332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316589860427288576",
  "text" : "RT @JenniferZenda: @Skeptical_Lady WTF is the rationale for that? Pot smokers are the least likely ppl to shoot ANYBODY. #unmotivated",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "unmotivated",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316583335038169090",
    "text" : "@Skeptical_Lady WTF is the rationale for that? Pot smokers are the least likely ppl to shoot ANYBODY. #unmotivated",
    "id" : 316583335038169090,
    "created_at" : "2013-03-26 16:12:03 +0000",
    "user" : {
      "name" : "Jennifer Zenda",
      "screen_name" : "JenniferZenda",
      "protected" : false,
      "id_str" : "287297332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2888489703\/7ad0db0cac4d716915df154906fa2ff4_normal.jpeg",
      "id" : 287297332,
      "verified" : false
    }
  },
  "id" : 316589860427288576,
  "created_at" : "2013-03-26 16:37:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316589527101743105",
  "text" : "RT @Squirrely007: Unmarried people have kids too. Kids don't make a marriage more or less important.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316588141853159424",
    "text" : "Unmarried people have kids too. Kids don't make a marriage more or less important.",
    "id" : 316588141853159424,
    "created_at" : "2013-03-26 16:31:09 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 316589527101743105,
  "created_at" : "2013-03-26 16:36:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 2, 17 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316588383197593600",
  "geo" : { },
  "id_str" : "316589394343645185",
  "in_reply_to_user_id" : 18538833,
  "text" : ". @ZeitgeistGhost UGH!! that is so wrong!!",
  "id" : 316589394343645185,
  "in_reply_to_status_id" : 316588383197593600,
  "created_at" : "2013-03-26 16:36:08 +0000",
  "in_reply_to_screen_name" : "ZeitgeistGhost",
  "in_reply_to_user_id_str" : "18538833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Zack Barnes",
      "screen_name" : "zbarnes",
      "indices" : [ 27, 35 ],
      "id_str" : "14547309",
      "id" : 14547309
    }, {
      "name" : "Bryon Quertermous",
      "screen_name" : "bryonq",
      "indices" : [ 40, 47 ],
      "id_str" : "15605665",
      "id" : 15605665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316584862461079553",
  "text" : "RT @TyrusBooks: Attention: @zbarnes and @bryonq are going to give away a book from their personal collection. Who else is in the giving  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zack Barnes",
        "screen_name" : "zbarnes",
        "indices" : [ 11, 19 ],
        "id_str" : "14547309",
        "id" : 14547309
      }, {
        "name" : "Bryon Quertermous",
        "screen_name" : "bryonq",
        "indices" : [ 24, 31 ],
        "id_str" : "15605665",
        "id" : 15605665
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316582263494156290",
    "text" : "Attention: @zbarnes and @bryonq are going to give away a book from their personal collection. Who else is in the giving spirit?",
    "id" : 316582263494156290,
    "created_at" : "2013-03-26 16:07:48 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 316584862461079553,
  "created_at" : "2013-03-26 16:18:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316584746085924864",
  "text" : "RT @JohnCali: The surest way to destroy our enemy is to make him our sincere friend. ~ US President Abraham Lincoln",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316582892379713536",
    "text" : "The surest way to destroy our enemy is to make him our sincere friend. ~ US President Abraham Lincoln",
    "id" : 316582892379713536,
    "created_at" : "2013-03-26 16:10:18 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 316584746085924864,
  "created_at" : "2013-03-26 16:17:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "\uFF36\uFF49\uFF52\uFF47\uFF4F",
      "screen_name" : "VirgoNation",
      "indices" : [ 17, 29 ],
      "id_str" : "271219664",
      "id" : 271219664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Virgos",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316580405908221952",
  "geo" : { },
  "id_str" : "316584587130204161",
  "in_reply_to_user_id" : 271219664,
  "text" : "@VirgoJohnny  RT @VirgoNation #Virgos are witty, fast thinkers and they can almost always crack a good joke that will get the crowd going.",
  "id" : 316584587130204161,
  "in_reply_to_status_id" : 316580405908221952,
  "created_at" : "2013-03-26 16:17:02 +0000",
  "in_reply_to_screen_name" : "VirgoNation",
  "in_reply_to_user_id_str" : "271219664",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roxana Jones",
      "screen_name" : "roxanamjones",
      "indices" : [ 3, 16 ],
      "id_str" : "269023982",
      "id" : 269023982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/BLUK1Bbeix",
      "expanded_url" : "http:\/\/ow.ly\/aGTYu",
      "display_url" : "ow.ly\/aGTYu"
    } ]
  },
  "geo" : { },
  "id_str" : "316583807912394752",
  "text" : "RT @roxanamjones: Never let your eyes determine what your heart believes. http:\/\/t.co\/BLUK1Bbeix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/BLUK1Bbeix",
        "expanded_url" : "http:\/\/ow.ly\/aGTYu",
        "display_url" : "ow.ly\/aGTYu"
      } ]
    },
    "geo" : { },
    "id_str" : "316580729037402113",
    "text" : "Never let your eyes determine what your heart believes. http:\/\/t.co\/BLUK1Bbeix",
    "id" : 316580729037402113,
    "created_at" : "2013-03-26 16:01:42 +0000",
    "user" : {
      "name" : "Roxana Jones",
      "screen_name" : "roxanamjones",
      "protected" : false,
      "id_str" : "269023982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625449714264047616\/7rrfNcTx_normal.jpg",
      "id" : 269023982,
      "verified" : false
    }
  },
  "id" : 316583807912394752,
  "created_at" : "2013-03-26 16:13:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 77, 87 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 88, 101 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "backwards",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316580977013043202",
  "text" : "i have 1210 followers yet brilliant, infinitely more interesting tweeps like @Matth3ous @Charmantides have a few 100 #backwards",
  "id" : 316580977013043202,
  "created_at" : "2013-03-26 16:02:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316577314236416000",
  "geo" : { },
  "id_str" : "316578633055600640",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous double crap!! : (( big ((hugs))",
  "id" : 316578633055600640,
  "in_reply_to_status_id" : 316577314236416000,
  "created_at" : "2013-03-26 15:53:22 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 14, 24 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoctorWho",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316552834265014275",
  "geo" : { },
  "id_str" : "316578405812424704",
  "in_reply_to_user_id" : 77106578,
  "text" : "Crap!! : ( RT @Matth3ous Well...At least #DoctorWho returns. Even though I'm in the hospital. With a stroke.",
  "id" : 316578405812424704,
  "in_reply_to_status_id" : 316552834265014275,
  "created_at" : "2013-03-26 15:52:28 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iFans.com",
      "screen_name" : "touchfans",
      "indices" : [ 3, 13 ],
      "id_str" : "18342200",
      "id" : 18342200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/SLbNFIzZH9",
      "expanded_url" : "http:\/\/www.ifans.com\/?p=78015",
      "display_url" : "ifans.com\/?p=78015"
    } ]
  },
  "geo" : { },
  "id_str" : "316577530821890049",
  "text" : "RT @touchfans: How One 17-Year-Old App Developer Became a Multi-Millionaire Overnight http:\/\/t.co\/SLbNFIzZH9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/SLbNFIzZH9",
        "expanded_url" : "http:\/\/www.ifans.com\/?p=78015",
        "display_url" : "ifans.com\/?p=78015"
      } ]
    },
    "geo" : { },
    "id_str" : "316576674814779392",
    "text" : "How One 17-Year-Old App Developer Became a Multi-Millionaire Overnight http:\/\/t.co\/SLbNFIzZH9",
    "id" : 316576674814779392,
    "created_at" : "2013-03-26 15:45:35 +0000",
    "user" : {
      "name" : "iFans.com",
      "screen_name" : "touchfans",
      "protected" : false,
      "id_str" : "18342200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2983864446\/9459b3ea5de259a4b11b82d1b599547c_normal.png",
      "id" : 18342200,
      "verified" : false
    }
  },
  "id" : 316577530821890049,
  "created_at" : "2013-03-26 15:48:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 3, 18 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316577004222820352",
  "text" : "MT @1stCitizenKane Cheese could be God with the right determination.",
  "id" : 316577004222820352,
  "created_at" : "2013-03-26 15:46:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 5, 18 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316366984134668289",
  "geo" : { },
  "id_str" : "316575253704871937",
  "in_reply_to_user_id" : 257273626,
  "text" : ". RT @Charmantides Lets call it retirement to avoid theatrics.",
  "id" : 316575253704871937,
  "in_reply_to_status_id" : 316366984134668289,
  "created_at" : "2013-03-26 15:39:56 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Book Patrol",
      "screen_name" : "bookpatrol",
      "indices" : [ 115, 126 ],
      "id_str" : "3747421",
      "id" : 3747421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316573835359035392",
  "text" : "RT @DuttonBooks: What's your literary thumbprint? A seriously unique way to pay homage to your favorite books from @BookPatrol http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Book Patrol",
        "screen_name" : "bookpatrol",
        "indices" : [ 98, 109 ],
        "id_str" : "3747421",
        "id" : 3747421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/te5rKYXofF",
        "expanded_url" : "http:\/\/ow.ly\/jqzi1",
        "display_url" : "ow.ly\/jqzi1"
      } ]
    },
    "geo" : { },
    "id_str" : "316565468917927936",
    "text" : "What's your literary thumbprint? A seriously unique way to pay homage to your favorite books from @BookPatrol http:\/\/t.co\/te5rKYXofF",
    "id" : 316565468917927936,
    "created_at" : "2013-03-26 15:01:03 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 316573835359035392,
  "created_at" : "2013-03-26 15:34:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316573220734124033",
  "text" : "@Skeptical_Lady geez...",
  "id" : 316573220734124033,
  "created_at" : "2013-03-26 15:31:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316572903929966592",
  "text" : "@1stCitizenKane even if it was.. wth can you do about it? .. nothing! so carry on and (insert vice of choice here) : )",
  "id" : 316572903929966592,
  "created_at" : "2013-03-26 15:30:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316568913959849984",
  "geo" : { },
  "id_str" : "316572409996128256",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray \"marley and me\" had DH and I bawling in the theater...",
  "id" : 316572409996128256,
  "in_reply_to_status_id" : 316568913959849984,
  "created_at" : "2013-03-26 15:28:38 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne802",
      "screen_name" : "Dwayne802",
      "indices" : [ 3, 13 ],
      "id_str" : "4783174038",
      "id" : 4783174038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316368900520546305",
  "text" : "RT @Dwayne802: Is it possible to start life all over again with nothing at all, or am I wasting my time?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315290490092265473",
    "text" : "Is it possible to start life all over again with nothing at all, or am I wasting my time?",
    "id" : 315290490092265473,
    "created_at" : "2013-03-23 02:34:45 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 316368900520546305,
  "created_at" : "2013-03-26 01:59:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316356393726775297",
  "geo" : { },
  "id_str" : "316361825253986305",
  "in_reply_to_user_id" : 257273626,
  "text" : "RT @Charmantides So two obligations to finish, one trip Id like to make. And then Im out. Nobodies fault, everyone happier. A relief.",
  "id" : 316361825253986305,
  "in_reply_to_status_id" : 316356393726775297,
  "created_at" : "2013-03-26 01:31:51 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dmmcglynn",
      "screen_name" : "dmmcglynn",
      "indices" : [ 0, 10 ],
      "id_str" : "211908135",
      "id" : 211908135
    }, {
      "name" : "Brianna Aldrich",
      "screen_name" : "BriAldrich20",
      "indices" : [ 31, 44 ],
      "id_str" : "606025994",
      "id" : 606025994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316309189066637312",
  "geo" : { },
  "id_str" : "316320270518476801",
  "in_reply_to_user_id" : 211908135,
  "text" : "@dmmcglynn thanks for info : ) @BriAldrich20",
  "id" : 316320270518476801,
  "in_reply_to_status_id" : 316309189066637312,
  "created_at" : "2013-03-25 22:46:44 +0000",
  "in_reply_to_screen_name" : "dmmcglynn",
  "in_reply_to_user_id_str" : "211908135",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316312298652327936",
  "geo" : { },
  "id_str" : "316318161148461057",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny hmm.. then where do you hide the bodies??",
  "id" : 316318161148461057,
  "in_reply_to_status_id" : 316312298652327936,
  "created_at" : "2013-03-25 22:38:21 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316314328473165824",
  "geo" : { },
  "id_str" : "316317704820768768",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i was somewhat ambidextrous very young but ultimately left-hand for writing, right for most else.",
  "id" : 316317704820768768,
  "in_reply_to_status_id" : 316314328473165824,
  "created_at" : "2013-03-25 22:36:32 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316316555933777920",
  "geo" : { },
  "id_str" : "316316899694751744",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny oh i love cheesecake.. now im thinking about cheesecake.. now i want cheesecake.. darn you!",
  "id" : 316316899694751744,
  "in_reply_to_status_id" : 316316555933777920,
  "created_at" : "2013-03-25 22:33:20 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dmmcglynn",
      "screen_name" : "dmmcglynn",
      "indices" : [ 0, 10 ],
      "id_str" : "211908135",
      "id" : 211908135
    }, {
      "name" : "Brianna Aldrich",
      "screen_name" : "BriAldrich20",
      "indices" : [ 76, 89 ],
      "id_str" : "606025994",
      "id" : 606025994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316304691518664705",
  "geo" : { },
  "id_str" : "316305896307318784",
  "in_reply_to_user_id" : 211908135,
  "text" : "@dmmcglynn im confused, too.. how many times they go back &amp; forth? ack! @BriAldrich20 #jodiarias",
  "id" : 316305896307318784,
  "in_reply_to_status_id" : 316304691518664705,
  "created_at" : "2013-03-25 21:49:37 +0000",
  "in_reply_to_screen_name" : "dmmcglynn",
  "in_reply_to_user_id_str" : "211908135",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "juanmartinez",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "jodiarias",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316253448947527680",
  "text" : "#juanmartinez wants to bring up every point for jury.. thats why it seems like he's dragging on. #jodiarias",
  "id" : 316253448947527680,
  "created_at" : "2013-03-25 18:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315905396906811393",
  "geo" : { },
  "id_str" : "315937824283189248",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle thx.. yes. i think i mostly sweated it out last night. been awhile since ive been feverish sick. ick..lol",
  "id" : 315937824283189248,
  "in_reply_to_status_id" : 315905396906811393,
  "created_at" : "2013-03-24 21:27:01 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315899559794601984",
  "text" : "everytime im ill, i hope its karma working out.. then at least its good for something.. ughhhh",
  "id" : 315899559794601984,
  "created_at" : "2013-03-24 18:54:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315864126750597120",
  "text" : "they are eating tacos in front of me.. off w their heads!",
  "id" : 315864126750597120,
  "created_at" : "2013-03-24 16:34:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Dennis",
      "screen_name" : "soshoreqt",
      "indices" : [ 58, 68 ],
      "id_str" : "38456402",
      "id" : 38456402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315860626381606912",
  "geo" : { },
  "id_str" : "315862230224740354",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny do i see a fan club in Johnny's future? hehe @soshoreqt",
  "id" : 315862230224740354,
  "in_reply_to_status_id" : 315860626381606912,
  "created_at" : "2013-03-24 16:26:38 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315861624852447232",
  "text" : "who the hell has a preview of sequel to horror movie \"in 3D\" after nightmare ends? I do.. too much #jodiarias trial maybe?",
  "id" : 315861624852447232,
  "created_at" : "2013-03-24 16:24:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoctorWho",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315585142028660736",
  "text" : "RT @Matth3ous: Cousin just asked what a Dalek is. She doesn't know what kind of can of worms she opened...#DoctorWho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoctorWho",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315584613311467520",
    "text" : "Cousin just asked what a Dalek is. She doesn't know what kind of can of worms she opened...#DoctorWho",
    "id" : 315584613311467520,
    "created_at" : "2013-03-23 22:03:29 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 315585142028660736,
  "created_at" : "2013-03-23 22:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315583930000629761",
  "text" : "the squirrel dragged the dish to. the. tree. is he hinting at breakfast in bed?",
  "id" : 315583930000629761,
  "created_at" : "2013-03-23 22:00:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315583385814855681",
  "text" : "i cannot imagine those poor souls who have consistent insomnia..",
  "id" : 315583385814855681,
  "created_at" : "2013-03-23 21:58:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315583141450510338",
  "text" : "didnt sleep last night. was awake.. even tho i took generic nyquil twice. then stomach kicked in.",
  "id" : 315583141450510338,
  "created_at" : "2013-03-23 21:57:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315579651097522176",
  "geo" : { },
  "id_str" : "315582763774377984",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny started off as cold.. turned into virus? bleh head hurts, stomach gurgling. i got it worse than DD, DH.",
  "id" : 315582763774377984,
  "in_reply_to_status_id" : 315579651097522176,
  "created_at" : "2013-03-23 21:56:08 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315546099517624321",
  "geo" : { },
  "id_str" : "315578673560420353",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle aww.. TY! ((hugs))",
  "id" : 315578673560420353,
  "in_reply_to_status_id" : 315546099517624321,
  "created_at" : "2013-03-23 21:39:53 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315574123864657920",
  "geo" : { },
  "id_str" : "315578174954151936",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny not a good day here.. im siiiiick... ((whine))",
  "id" : 315578174954151936,
  "in_reply_to_status_id" : 315574123864657920,
  "created_at" : "2013-03-23 21:37:54 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315448199294877697",
  "text" : "feel like crap today. that is all.",
  "id" : 315448199294877697,
  "created_at" : "2013-03-23 13:01:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the Buddha was right",
      "screen_name" : "jakuman",
      "indices" : [ 3, 11 ],
      "id_str" : "81728678",
      "id" : 81728678
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315246706738466817",
  "text" : "RT @jakuman: If everyone in prison for possession of a plant isn't a political prisoner then I don't even know what one is",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315245849494048768",
    "text" : "If everyone in prison for possession of a plant isn't a political prisoner then I don't even know what one is",
    "id" : 315245849494048768,
    "created_at" : "2013-03-22 23:37:22 +0000",
    "user" : {
      "name" : "the Buddha was right",
      "screen_name" : "jakuman",
      "protected" : false,
      "id_str" : "81728678",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000691069120\/66b4c716e63e0bea873f18ce25d7a061_normal.jpeg",
      "id" : 81728678,
      "verified" : false
    }
  },
  "id" : 315246706738466817,
  "created_at" : "2013-03-22 23:40:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    }, {
      "name" : "Earth Pics",
      "screen_name" : "earthposts",
      "indices" : [ 41, 52 ],
      "id_str" : "835328618",
      "id" : 835328618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/bBdERVu2xf",
      "expanded_url" : "https:\/\/twitter.com\/earthposts\/status\/315244673348292608\/photo\/1",
      "display_url" : "pic.twitter.com\/bBdERVu2xf"
    } ]
  },
  "geo" : { },
  "id_str" : "315246288130158593",
  "text" : "RT @Squirrely007: omg! that is freaky RT @earthposts This is freaky.. http:\/\/t.co\/bBdERVu2xf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Earth Pics",
        "screen_name" : "earthposts",
        "indices" : [ 23, 34 ],
        "id_str" : "835328618",
        "id" : 835328618
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/bBdERVu2xf",
        "expanded_url" : "https:\/\/twitter.com\/earthposts\/status\/315244673348292608\/photo\/1",
        "display_url" : "pic.twitter.com\/bBdERVu2xf"
      } ]
    },
    "in_reply_to_status_id_str" : "315244673348292608",
    "geo" : { },
    "id_str" : "315244861026619394",
    "in_reply_to_user_id" : 835328618,
    "text" : "omg! that is freaky RT @earthposts This is freaky.. http:\/\/t.co\/bBdERVu2xf",
    "id" : 315244861026619394,
    "in_reply_to_status_id" : 315244673348292608,
    "created_at" : "2013-03-22 23:33:26 +0000",
    "in_reply_to_screen_name" : "earthposts",
    "in_reply_to_user_id_str" : "835328618",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 315246288130158593,
  "created_at" : "2013-03-22 23:39:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Well, WTF?",
      "screen_name" : "blackenedwisdom",
      "indices" : [ 35, 51 ],
      "id_str" : "962584916",
      "id" : 962584916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315232476396154881",
  "geo" : { },
  "id_str" : "315233228975902720",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny do you take chickens? @blackenedwisdom",
  "id" : 315233228975902720,
  "in_reply_to_status_id" : 315232476396154881,
  "created_at" : "2013-03-22 22:47:13 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315232776603451394",
  "text" : "i got weird issues i guess..lol.. im glad to be where i am now.",
  "id" : 315232776603451394,
  "created_at" : "2013-03-22 22:45:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315232153480859648",
  "text" : "you know how alcoholics cant have one drink? well, im not good w anger. i cant handle it in healthy way.",
  "id" : 315232153480859648,
  "created_at" : "2013-03-22 22:42:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315231555507351552",
  "text" : "ppl tend 2 think im sweeter than i am.. well, im mostly sweet. but havent always been so nice.",
  "id" : 315231555507351552,
  "created_at" : "2013-03-22 22:40:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315230873547051008",
  "text" : "we all have our secrets.",
  "id" : 315230873547051008,
  "created_at" : "2013-03-22 22:37:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315229481222684673",
  "text" : "maybe ive been watching too much #jodiarias stuff? getting out of sorts..",
  "id" : 315229481222684673,
  "created_at" : "2013-03-22 22:32:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315227130193641472",
  "geo" : { },
  "id_str" : "315229006289043456",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny now you sound like DH.. sometimes its hard to tell.. im weird like that.",
  "id" : 315229006289043456,
  "in_reply_to_status_id" : 315227130193641472,
  "created_at" : "2013-03-22 22:30:26 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315225399602847744",
  "geo" : { },
  "id_str" : "315226790324998145",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny just block me and get it over with... humph. : (",
  "id" : 315226790324998145,
  "in_reply_to_status_id" : 315225399602847744,
  "created_at" : "2013-03-22 22:21:38 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315225399602847744",
  "geo" : { },
  "id_str" : "315226150278406145",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny geeeeeeeez.. sure do know how to make a gal feel special!!! : (((",
  "id" : 315226150278406145,
  "in_reply_to_status_id" : 315225399602847744,
  "created_at" : "2013-03-22 22:19:05 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315225745435807744",
  "text" : "ugh.. a little cold wasnt bad.. but now im feeling a bit icky.. wonky head, go away!",
  "id" : 315225745435807744,
  "created_at" : "2013-03-22 22:17:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315219728945795072",
  "geo" : { },
  "id_str" : "315225148426973184",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i think you've been nice to me a few times (alright, maybe like once.. maybe.. hmm..) :O",
  "id" : 315225148426973184,
  "in_reply_to_status_id" : 315219728945795072,
  "created_at" : "2013-03-22 22:15:06 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315154822464684032",
  "geo" : { },
  "id_str" : "315157183069290496",
  "in_reply_to_user_id" : 279024097,
  "text" : "@SuzinNEOhio @Eddieg4golf oh to know what was said on those calls from JA to TA during that trip... thx 4 link.",
  "id" : 315157183069290496,
  "in_reply_to_status_id" : 315154822464684032,
  "created_at" : "2013-03-22 17:45:02 +0000",
  "in_reply_to_screen_name" : "CatsGuardian2",
  "in_reply_to_user_id_str" : "279024097",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315155274098946049",
  "text" : "@Eddieg4golf lol.. ive only been following about last 2 weeks due to another tweep posting about it.",
  "id" : 315155274098946049,
  "created_at" : "2013-03-22 17:37:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Crossley",
      "screen_name" : "CrossleyIDGuide",
      "indices" : [ 13, 29 ],
      "id_str" : "216788760",
      "id" : 216788760
    }, {
      "name" : "Princeton Nature",
      "screen_name" : "PrincetonNature",
      "indices" : [ 84, 100 ],
      "id_str" : "1112357712",
      "id" : 1112357712
    }, {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "indices" : [ 101, 117 ],
      "id_str" : "20715956",
      "id" : 20715956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/So766oRU3t",
      "expanded_url" : "http:\/\/bit.ly\/13FlSE9",
      "display_url" : "bit.ly\/13FlSE9"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GnImn13b7h",
      "expanded_url" : "http:\/\/blog.press.princeton.edu\/win-a-crossley-id-guide-prize-pack\/",
      "display_url" : "blog.press.princeton.edu\/win-a-crossley\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "315154202705936384",
  "text" : "Enter to win @CrossleyIDGuide books &amp; Nikon binoculars: http:\/\/t.co\/So766oRU3t, @PrincetonNature @princetonupress http:\/\/t.co\/GnImn13b7h",
  "id" : 315154202705936384,
  "created_at" : "2013-03-22 17:33:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candie",
      "screen_name" : "Momma_to_6",
      "indices" : [ 0, 11 ],
      "id_str" : "1149357409",
      "id" : 1149357409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315136216502763520",
  "geo" : { },
  "id_str" : "315137803036028929",
  "in_reply_to_user_id" : 1149357409,
  "text" : "@Momma_to_6 @mandjlewis what's your take on what happened that day? (i have hard time getting past slit throat,all his blood)",
  "id" : 315137803036028929,
  "in_reply_to_status_id" : 315136216502763520,
  "created_at" : "2013-03-22 16:28:01 +0000",
  "in_reply_to_screen_name" : "Momma_to_6",
  "in_reply_to_user_id_str" : "1149357409",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315136258739429376",
  "text" : "@Eddieg4golf i would love to see this. i hope JM closes w the pics stressing the 62 secs.. #jodiarias",
  "id" : 315136258739429376,
  "created_at" : "2013-03-22 16:21:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Phillips",
      "screen_name" : "findthebrad",
      "indices" : [ 3, 15 ],
      "id_str" : "575266864",
      "id" : 575266864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315135353247899648",
  "text" : "RT @findthebrad: I wonder how many injuries have occured in past 10 days from people testing their bookshelf pegs' weight holding capabi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315133087036080128",
    "text" : "I wonder how many injuries have occured in past 10 days from people testing their bookshelf pegs' weight holding capabilities #jodiarias",
    "id" : 315133087036080128,
    "created_at" : "2013-03-22 16:09:17 +0000",
    "user" : {
      "name" : "Brad Phillips",
      "screen_name" : "findthebrad",
      "protected" : false,
      "id_str" : "575266864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571993922373574656\/uV4fz4g5_normal.jpeg",
      "id" : 575266864,
      "verified" : false
    }
  },
  "id" : 315135353247899648,
  "created_at" : "2013-03-22 16:18:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candie",
      "screen_name" : "Momma_to_6",
      "indices" : [ 12, 23 ],
      "id_str" : "1149357409",
      "id" : 1149357409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315135204673064960",
  "text" : "@mandjlewis @Momma_to_6 colored\/braided hair; rented car; turned off cell while in AZ; no trail in AZ..",
  "id" : 315135204673064960,
  "created_at" : "2013-03-22 16:17:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candie",
      "screen_name" : "Momma_to_6",
      "indices" : [ 0, 11 ],
      "id_str" : "1149357409",
      "id" : 1149357409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315124643050704896",
  "geo" : { },
  "id_str" : "315128502561157120",
  "in_reply_to_user_id" : 1149357409,
  "text" : "@Momma_to_6 @mandjlewis if not pre-med, it would have to be SD. dated pics dont substantiate that. 62 secs-alive in shower to throat cut",
  "id" : 315128502561157120,
  "in_reply_to_status_id" : 315124643050704896,
  "created_at" : "2013-03-22 15:51:04 +0000",
  "in_reply_to_screen_name" : "Momma_to_6",
  "in_reply_to_user_id_str" : "1149357409",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candie",
      "screen_name" : "Momma_to_6",
      "indices" : [ 12, 23 ],
      "id_str" : "1149357409",
      "id" : 1149357409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315127127198552066",
  "text" : "@mandjlewis @Momma_to_6 no court today. back on mon at 9:30 az time.",
  "id" : 315127127198552066,
  "created_at" : "2013-03-22 15:45:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "chrisbr40",
      "indices" : [ 0, 10 ],
      "id_str" : "540023255",
      "id" : 540023255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314882012261539840",
  "geo" : { },
  "id_str" : "315124587232899072",
  "in_reply_to_user_id" : 540023255,
  "text" : "@chrisbr40 i hope JM picks up right there and i dont miss it. i want to see where he's going w it.",
  "id" : 315124587232899072,
  "in_reply_to_status_id" : 314882012261539840,
  "created_at" : "2013-03-22 15:35:30 +0000",
  "in_reply_to_screen_name" : "chrisbr40",
  "in_reply_to_user_id_str" : "540023255",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315124369242333184",
  "text" : "@mandjlewis true.. but with JA.. there is overwhelming hardcore evidence she did it. also evidence she pre-med.",
  "id" : 315124369242333184,
  "created_at" : "2013-03-22 15:34:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Anderson",
      "screen_name" : "Ugly__Casanova",
      "indices" : [ 3, 18 ],
      "id_str" : "303581537",
      "id" : 303581537
    }, {
      "name" : "C.P. Richardson",
      "screen_name" : "themedicareguy",
      "indices" : [ 20, 35 ],
      "id_str" : "533343034",
      "id" : 533343034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314904254215254016",
  "text" : "RT @Ugly__Casanova: @themedicareguy well, if it were applied nationwide, we wouldnt need annual renewal processes. Those are prohibitive ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "C.P. Richardson",
        "screen_name" : "themedicareguy",
        "indices" : [ 0, 15 ],
        "id_str" : "533343034",
        "id" : 533343034
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "314854299559661568",
    "geo" : { },
    "id_str" : "314855202912096256",
    "in_reply_to_user_id" : 533343034,
    "text" : "@themedicareguy well, if it were applied nationwide, we wouldnt need annual renewal processes. Those are prohibitive measures. #SinglePayer",
    "id" : 314855202912096256,
    "in_reply_to_status_id" : 314854299559661568,
    "created_at" : "2013-03-21 21:45:04 +0000",
    "in_reply_to_screen_name" : "themedicareguy",
    "in_reply_to_user_id_str" : "533343034",
    "user" : {
      "name" : "Brett Anderson",
      "screen_name" : "Ugly__Casanova",
      "protected" : false,
      "id_str" : "303581537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527565409025683456\/kE4UpN2d_normal.jpeg",
      "id" : 303581537,
      "verified" : false
    }
  },
  "id" : 314904254215254016,
  "created_at" : "2013-03-22 00:59:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jaja",
      "screen_name" : "JaJasTweets",
      "indices" : [ 0, 12 ],
      "id_str" : "37002670",
      "id" : 37002670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314861070596595712",
  "geo" : { },
  "id_str" : "314863096894214146",
  "in_reply_to_user_id" : 37002670,
  "text" : "@JaJasTweets grasping for straws.. trying to show ptsd gives credibility to JA's accusations (hopefully jury sees thru it)",
  "id" : 314863096894214146,
  "in_reply_to_status_id" : 314861070596595712,
  "created_at" : "2013-03-21 22:16:26 +0000",
  "in_reply_to_screen_name" : "JaJasTweets",
  "in_reply_to_user_id_str" : "37002670",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 75, 91 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/JO6Xl8LuZz",
      "expanded_url" : "http:\/\/wp.me\/p2zLL-94",
      "display_url" : "wp.me\/p2zLL-94"
    } ]
  },
  "geo" : { },
  "id_str" : "314527266161950720",
  "text" : "She\/he thinks the world revolves around him\/her http:\/\/t.co\/JO6Xl8LuZz via @wordpressdotcom",
  "id" : 314527266161950720,
  "created_at" : "2013-03-21 00:01:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "chrisbr40",
      "indices" : [ 3, 13 ],
      "id_str" : "540023255",
      "id" : 540023255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314512539289538560",
  "text" : "RT @chrisbr40: #JodiArias spectator vomits in courtroom...this is why I love Twitter! Not gonna hear about that on HLN are you?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314511428780449794",
    "text" : "#JodiArias spectator vomits in courtroom...this is why I love Twitter! Not gonna hear about that on HLN are you?",
    "id" : 314511428780449794,
    "created_at" : "2013-03-20 22:59:02 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "chrisbr40",
      "protected" : false,
      "id_str" : "540023255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797479031465644032\/9Wu_90bg_normal.jpg",
      "id" : 540023255,
      "verified" : false
    }
  },
  "id" : 314512539289538560,
  "created_at" : "2013-03-20 23:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "FetchingFeline",
      "indices" : [ 0, 15 ],
      "id_str" : "280000773",
      "id" : 280000773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314501462711484418",
  "geo" : { },
  "id_str" : "314502628837031937",
  "in_reply_to_user_id" : 280000773,
  "text" : "@FetchingFeline just looking at the pictures with date and time, you can see there was no attack on her.",
  "id" : 314502628837031937,
  "in_reply_to_status_id" : 314501462711484418,
  "created_at" : "2013-03-20 22:24:04 +0000",
  "in_reply_to_screen_name" : "FetchingFeline",
  "in_reply_to_user_id_str" : "280000773",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "FetchingFeline",
      "indices" : [ 0, 15 ],
      "id_str" : "280000773",
      "id" : 280000773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314501069264785408",
  "geo" : { },
  "id_str" : "314502006062608385",
  "in_reply_to_user_id" : 280000773,
  "text" : "@FetchingFeline i really dont understand how the defense is able to go on and on when there's no substantiation.",
  "id" : 314502006062608385,
  "in_reply_to_status_id" : 314501069264785408,
  "created_at" : "2013-03-20 22:21:36 +0000",
  "in_reply_to_screen_name" : "FetchingFeline",
  "in_reply_to_user_id_str" : "280000773",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "FetchingFeline",
      "indices" : [ 0, 15 ],
      "id_str" : "280000773",
      "id" : 280000773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314496728076271616",
  "geo" : { },
  "id_str" : "314500263346073600",
  "in_reply_to_user_id" : 280000773,
  "text" : "@FetchingFeline agreed.. isnt she supposed to say \"allegedly\" or something? or at least \"which time \"ms arias says\" travis attacked her.",
  "id" : 314500263346073600,
  "in_reply_to_status_id" : 314496728076271616,
  "created_at" : "2013-03-20 22:14:40 +0000",
  "in_reply_to_screen_name" : "FetchingFeline",
  "in_reply_to_user_id_str" : "280000773",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314477151594348545",
  "geo" : { },
  "id_str" : "314480329496854528",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 lol.. yeah..",
  "id" : 314480329496854528,
  "in_reply_to_status_id" : 314477151594348545,
  "created_at" : "2013-03-20 20:55:27 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Crossley",
      "screen_name" : "CrossleyIDGuide",
      "indices" : [ 13, 29 ],
      "id_str" : "216788760",
      "id" : 216788760
    }, {
      "name" : "Princeton Nature",
      "screen_name" : "PrincetonNature",
      "indices" : [ 84, 100 ],
      "id_str" : "1112357712",
      "id" : 1112357712
    }, {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "indices" : [ 101, 117 ],
      "id_str" : "20715956",
      "id" : 20715956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/So766oRU3t",
      "expanded_url" : "http:\/\/bit.ly\/13FlSE9",
      "display_url" : "bit.ly\/13FlSE9"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GnImn13b7h",
      "expanded_url" : "http:\/\/blog.press.princeton.edu\/win-a-crossley-id-guide-prize-pack\/",
      "display_url" : "blog.press.princeton.edu\/win-a-crossley\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314448698455252992",
  "text" : "Enter to win @CrossleyIDGuide books &amp; Nikon binoculars: http:\/\/t.co\/So766oRU3t, @PrincetonNature @princetonupress http:\/\/t.co\/GnImn13b7h",
  "id" : 314448698455252992,
  "created_at" : "2013-03-20 18:49:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dangerous Minds",
      "screen_name" : "DangerMindsBlog",
      "indices" : [ 125, 141 ],
      "id_str" : "165952878",
      "id" : 165952878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Mw5ULSyTRM",
      "expanded_url" : "http:\/\/dangerousminds.net\/comments\/dying_vets_fuck_you_letter_to_george_bush_dick_cheney_needs_to_be_read",
      "display_url" : "dangerousminds.net\/comments\/dying\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "314415177900630017",
  "text" : "Dying vet\u2019s \u2018fuck you\u2019 letter to George Bush &amp; Dick Cheney needs to be read by every American http:\/\/t.co\/Mw5ULSyTRM via @dangermindsblog",
  "id" : 314415177900630017,
  "created_at" : "2013-03-20 16:36:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elizabeth mazzella",
      "screen_name" : "elimazzella",
      "indices" : [ 3, 15 ],
      "id_str" : "1131935143",
      "id" : 1131935143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314381447190441984",
  "text" : "RT @elimazzella: Time doesn't lie, he was alive in one pic and down 60 sec later. Surprise attack...case closed...even the devil was an  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314367068784959489",
    "text" : "Time doesn't lie, he was alive in one pic and down 60 sec later. Surprise attack...case closed...even the devil was an angel!! #JodiArias",
    "id" : 314367068784959489,
    "created_at" : "2013-03-20 13:25:24 +0000",
    "user" : {
      "name" : "elizabeth mazzella",
      "screen_name" : "elimazzella",
      "protected" : false,
      "id_str" : "1131935143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3182297857\/e71f3782a1f84704342e1ed8c31ee1cc_normal.jpeg",
      "id" : 1131935143,
      "verified" : false
    }
  },
  "id" : 314381447190441984,
  "created_at" : "2013-03-20 14:22:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314378649392513024",
  "text" : "how about putting the effort \/ money into the children.. B4 smoke \/ drink starts.",
  "id" : 314378649392513024,
  "created_at" : "2013-03-20 14:11:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314377815279689729",
  "text" : "to say stuff is bad, dont do it... well, we all know that does NOT work anyway!",
  "id" : 314377815279689729,
  "created_at" : "2013-03-20 14:08:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314377589248643072",
  "text" : "why not anti-alcohol commercials?? hmm??",
  "id" : 314377589248643072,
  "created_at" : "2013-03-20 14:07:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314377383836782592",
  "text" : "those anti-smoking commercials drive me crazy! (and i dont even smoke)",
  "id" : 314377383836782592,
  "created_at" : "2013-03-20 14:06:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dreams",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314376464277585920",
  "text" : "another common dream theme i have: driving car - having trouble reaching pedals, cant see well over dash, drive from other seat. #dreams",
  "id" : 314376464277585920,
  "created_at" : "2013-03-20 14:02:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Coble",
      "screen_name" : "KennyCoble",
      "indices" : [ 3, 14 ],
      "id_str" : "83700075",
      "id" : 83700075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314098401664970753",
  "text" : "RT @kennycoble: I don't understand how a person can walk by a bookstore and not go in. It's insanity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314093335050584065",
    "text" : "I don't understand how a person can walk by a bookstore and not go in. It's insanity.",
    "id" : 314093335050584065,
    "created_at" : "2013-03-19 19:17:41 +0000",
    "user" : {
      "name" : "Kenny Coble",
      "screen_name" : "KennyCoble",
      "protected" : false,
      "id_str" : "83700075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554723029884735488\/j73xD-XS_normal.jpeg",
      "id" : 83700075,
      "verified" : false
    }
  },
  "id" : 314098401664970753,
  "created_at" : "2013-03-19 19:37:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 0, 16 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314064207928774656",
  "geo" : { },
  "id_str" : "314064654529867776",
  "in_reply_to_user_id" : 175204121,
  "text" : "@WildlifeGadgets time for some scritches.. lol",
  "id" : 314064654529867776,
  "in_reply_to_status_id" : 314064207928774656,
  "created_at" : "2013-03-19 17:23:43 +0000",
  "in_reply_to_screen_name" : "WildlifeGadgets",
  "in_reply_to_user_id_str" : "175204121",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "dave bissett",
      "screen_name" : "dbissett",
      "indices" : [ 31, 40 ],
      "id_str" : "16086441",
      "id" : 16086441
    }, {
      "name" : "Pragmatic Preacher",
      "screen_name" : "Adamizer1",
      "indices" : [ 41, 51 ],
      "id_str" : "634116947",
      "id" : 634116947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314058927962730499",
  "geo" : { },
  "id_str" : "314063237811417090",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool good question! @dbissett @Adamizer1",
  "id" : 314063237811417090,
  "in_reply_to_status_id" : 314058927962730499,
  "created_at" : "2013-03-19 17:18:05 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 4, 18 ],
      "id_str" : "28863804",
      "id" : 28863804
    }, {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 31, 42 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/6oaqFyF7A0",
      "expanded_url" : "http:\/\/www.tyrusbooks.com\/news\/tshirts",
      "display_url" : "tyrusbooks.com\/news\/tshirts"
    } ]
  },
  "in_reply_to_status_id_str" : "314025285530050561",
  "geo" : { },
  "id_str" : "314046523396718593",
  "in_reply_to_user_id" : 67336993,
  "text" : "hey @Wylieknowords &gt;&gt; MT @TyrusBooks design new Tyrus Books t-shirts http:\/\/t.co\/6oaqFyF7A0",
  "id" : 314046523396718593,
  "in_reply_to_status_id" : 314025285530050561,
  "created_at" : "2013-03-19 16:11:40 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kleun13",
      "screen_name" : "kleun13",
      "indices" : [ 0, 8 ],
      "id_str" : "284493778",
      "id" : 284493778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314039701025746945",
  "geo" : { },
  "id_str" : "314040963427336193",
  "in_reply_to_user_id" : 284493778,
  "text" : "@kleun13 huh.. well, thats weird.. more mysteries :O",
  "id" : 314040963427336193,
  "in_reply_to_status_id" : 314039701025746945,
  "created_at" : "2013-03-19 15:49:34 +0000",
  "in_reply_to_screen_name" : "kleun13",
  "in_reply_to_user_id_str" : "284493778",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314018943318773760",
  "text" : "outside birds insisted on being fed this am..lol.. lots of chirping on the porch!",
  "id" : 314018943318773760,
  "created_at" : "2013-03-19 14:22:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313762659046674432",
  "geo" : { },
  "id_str" : "313770793366597633",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 he's giving psychologist bad name.. ugh.",
  "id" : 313770793366597633,
  "in_reply_to_status_id" : 313762659046674432,
  "created_at" : "2013-03-18 21:56:01 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/v5QwBbmfc4",
      "expanded_url" : "http:\/\/bookwi.se\/kindle-paperwhite-software-update\/",
      "display_url" : "bookwi.se\/kindle-paperwh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313697526396096512",
  "text" : "RT @adamrshields: Kindle Paperwhite Software Updates to 5.3.4 - no details other than 'general software improvements http:\/\/t.co\/v5QwBbmfc4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/v5QwBbmfc4",
        "expanded_url" : "http:\/\/bookwi.se\/kindle-paperwhite-software-update\/",
        "display_url" : "bookwi.se\/kindle-paperwh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "313687385026211840",
    "text" : "Kindle Paperwhite Software Updates to 5.3.4 - no details other than 'general software improvements http:\/\/t.co\/v5QwBbmfc4",
    "id" : 313687385026211840,
    "created_at" : "2013-03-18 16:24:35 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 313697526396096512,
  "created_at" : "2013-03-18 17:04:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Crossley",
      "screen_name" : "CrossleyIDGuide",
      "indices" : [ 13, 29 ],
      "id_str" : "216788760",
      "id" : 216788760
    }, {
      "name" : "Princeton Nature",
      "screen_name" : "PrincetonNature",
      "indices" : [ 84, 100 ],
      "id_str" : "1112357712",
      "id" : 1112357712
    }, {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "indices" : [ 101, 117 ],
      "id_str" : "20715956",
      "id" : 20715956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/So766oRU3t",
      "expanded_url" : "http:\/\/bit.ly\/13FlSE9",
      "display_url" : "bit.ly\/13FlSE9"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GnImn13b7h",
      "expanded_url" : "http:\/\/blog.press.princeton.edu\/win-a-crossley-id-guide-prize-pack\/",
      "display_url" : "blog.press.princeton.edu\/win-a-crossley\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313662059374075907",
  "text" : "Enter to win @CrossleyIDGuide books &amp; Nikon binoculars: http:\/\/t.co\/So766oRU3t, @PrincetonNature @princetonupress http:\/\/t.co\/GnImn13b7h",
  "id" : 313662059374075907,
  "created_at" : "2013-03-18 14:43:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313468577065869312",
  "geo" : { },
  "id_str" : "313469681228980224",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon ((hugs))",
  "id" : 313469681228980224,
  "in_reply_to_status_id" : 313468577065869312,
  "created_at" : "2013-03-18 01:59:30 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313449156557549568",
  "geo" : { },
  "id_str" : "313450251283468288",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny im sensing you might be... might be... oh scratch that, I lost it...",
  "id" : 313450251283468288,
  "in_reply_to_status_id" : 313449156557549568,
  "created_at" : "2013-03-18 00:42:18 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "indices" : [ 3, 13 ],
      "id_str" : "18812572",
      "id" : 18812572
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 16, 24 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313439854740512769",
  "text" : "RT @60Minutes: .@Twitter was inspired by Dorsey\u2019s childhood love of police scanners when he heard people communicating in shorts bursts. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 1, 9 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "60minutes",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313431923898863617",
    "text" : ".@Twitter was inspired by Dorsey\u2019s childhood love of police scanners when he heard people communicating in shorts bursts. #60minutes",
    "id" : 313431923898863617,
    "created_at" : "2013-03-17 23:29:28 +0000",
    "user" : {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "protected" : false,
      "id_str" : "18812572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463397772071165953\/n_-jHyIO_normal.jpeg",
      "id" : 18812572,
      "verified" : true
    }
  },
  "id" : 313439854740512769,
  "created_at" : "2013-03-18 00:00:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313420338115518466",
  "text" : "RT @MartijnLinssen: Think for yourself. Drop all of your belief, conviction, mental model - in short, everything you solemnly swear you  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313419353011933184",
    "text" : "Think for yourself. Drop all of your belief, conviction, mental model - in short, everything you solemnly swear you are. Who are you, really",
    "id" : 313419353011933184,
    "created_at" : "2013-03-17 22:39:31 +0000",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 313420338115518466,
  "created_at" : "2013-03-17 22:43:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Carol Oates",
      "screen_name" : "JoyceCarolOates",
      "indices" : [ 3, 19 ],
      "id_str" : "845743333",
      "id" : 845743333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313407531651305472",
  "text" : "RT @JoyceCarolOates: Did no one feel sorry for Schrodinger's cat?\n(I did.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313405301892194304",
    "text" : "Did no one feel sorry for Schrodinger's cat?\n(I did.)",
    "id" : 313405301892194304,
    "created_at" : "2013-03-17 21:43:41 +0000",
    "user" : {
      "name" : "Joyce Carol Oates",
      "screen_name" : "JoyceCarolOates",
      "protected" : false,
      "id_str" : "845743333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2683616680\/ca8aa195d2ccc38da6800678a9d2ae8a_normal.png",
      "id" : 845743333,
      "verified" : true
    }
  },
  "id" : 313407531651305472,
  "created_at" : "2013-03-17 21:52:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "indices" : [ 3, 19 ],
      "id_str" : "1050419874",
      "id" : 1050419874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/g61jAHxh3A",
      "expanded_url" : "http:\/\/twitpic.com\/cc8dii",
      "display_url" : "twitpic.com\/cc8dii"
    } ]
  },
  "geo" : { },
  "id_str" : "313405541638619136",
  "text" : "RT @HighlandFarmsME: clishmaclavering among the cows (or, what happens with a new bale of hay) http:\/\/t.co\/g61jAHxh3A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/g61jAHxh3A",
        "expanded_url" : "http:\/\/twitpic.com\/cc8dii",
        "display_url" : "twitpic.com\/cc8dii"
      } ]
    },
    "geo" : { },
    "id_str" : "313404254478036993",
    "text" : "clishmaclavering among the cows (or, what happens with a new bale of hay) http:\/\/t.co\/g61jAHxh3A",
    "id" : 313404254478036993,
    "created_at" : "2013-03-17 21:39:31 +0000",
    "user" : {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "protected" : false,
      "id_str" : "1050419874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3046136643\/52b682fed61ae8e3cd6692fcb7e54ab8_normal.jpeg",
      "id" : 1050419874,
      "verified" : false
    }
  },
  "id" : 313405541638619136,
  "created_at" : "2013-03-17 21:44:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIP",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313400156538163201",
  "geo" : { },
  "id_str" : "313404363479584769",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 i wont have spaghetti again til im dead. my mom #RIP made her own sauce. the only sauce i liked..lol",
  "id" : 313404363479584769,
  "in_reply_to_status_id" : 313400156538163201,
  "created_at" : "2013-03-17 21:39:57 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313396842010386433",
  "text" : "RT @OMGFacts: If you were ejected into space, you would explode before you suffocated because there is no air pressure.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313394712629370882",
    "text" : "If you were ejected into space, you would explode before you suffocated because there is no air pressure.",
    "id" : 313394712629370882,
    "created_at" : "2013-03-17 21:01:36 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 313396842010386433,
  "created_at" : "2013-03-17 21:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/lsp8pXujs2",
      "expanded_url" : "http:\/\/amzn.to\/p0vzOp",
      "display_url" : "amzn.to\/p0vzOp"
    } ]
  },
  "geo" : { },
  "id_str" : "313391068056006656",
  "text" : "finished Erasing Hell: What God Said about Eternity, and the Things We've Made Up http:\/\/t.co\/lsp8pXujs2",
  "id" : 313391068056006656,
  "created_at" : "2013-03-17 20:47:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313367646961803264",
  "text" : "it's tough to be human.. im pretty sure God understands this : )",
  "id" : 313367646961803264,
  "created_at" : "2013-03-17 19:14:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "indices" : [ 0, 12 ],
      "id_str" : "27905866",
      "id" : 27905866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313366228527898625",
  "geo" : { },
  "id_str" : "313366936367030272",
  "in_reply_to_user_id" : 27905866,
  "text" : "@rev_heather yes!",
  "id" : 313366936367030272,
  "in_reply_to_status_id" : 313366228527898625,
  "created_at" : "2013-03-17 19:11:14 +0000",
  "in_reply_to_screen_name" : "rev_heather",
  "in_reply_to_user_id_str" : "27905866",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313365282494222336",
  "text" : "@AnarchistKevin i never believed in hell as place. my curr view is we can create our own hell after death.",
  "id" : 313365282494222336,
  "created_at" : "2013-03-17 19:04:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "indices" : [ 0, 12 ],
      "id_str" : "27905866",
      "id" : 27905866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313362960435249152",
  "geo" : { },
  "id_str" : "313364397928108033",
  "in_reply_to_user_id" : 27905866,
  "text" : "@rev_heather it never jived w how i saw God. never understood need to be saved either, eventually fig. God would save all (if neccessary)",
  "id" : 313364397928108033,
  "in_reply_to_status_id" : 313362960435249152,
  "created_at" : "2013-03-17 19:01:09 +0000",
  "in_reply_to_screen_name" : "rev_heather",
  "in_reply_to_user_id_str" : "27905866",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313362245994295296",
  "text" : "i could never grasp WHY we deserve hell (according to christians.) No answer ever made any sense to me.",
  "id" : 313362245994295296,
  "created_at" : "2013-03-17 18:52:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Sibley",
      "screen_name" : "jbsibley",
      "indices" : [ 3, 12 ],
      "id_str" : "14085981",
      "id" : 14085981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/AJ3RPwKhxZ",
      "expanded_url" : "http:\/\/www.whyPETAkills.org",
      "display_url" : "whyPETAkills.org"
    } ]
  },
  "geo" : { },
  "id_str" : "313358182560964609",
  "text" : "RT @jbsibley: A big welcome to http:\/\/t.co\/AJ3RPwKhxZ, a site with a very important educational mission.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/AJ3RPwKhxZ",
        "expanded_url" : "http:\/\/www.whyPETAkills.org",
        "display_url" : "whyPETAkills.org"
      } ]
    },
    "geo" : { },
    "id_str" : "313337609550184451",
    "text" : "A big welcome to http:\/\/t.co\/AJ3RPwKhxZ, a site with a very important educational mission.",
    "id" : 313337609550184451,
    "created_at" : "2013-03-17 17:14:42 +0000",
    "user" : {
      "name" : "John Sibley",
      "screen_name" : "jbsibley",
      "protected" : false,
      "id_str" : "14085981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748878782514200576\/igw5XSkw_normal.jpg",
      "id" : 14085981,
      "verified" : false
    }
  },
  "id" : 313358182560964609,
  "created_at" : "2013-03-17 18:36:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313354480932499457",
  "text" : "RT @dhammagirl: Little do we know, that we actually \"know\" very little.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313349320336363520",
    "text" : "Little do we know, that we actually \"know\" very little.",
    "id" : 313349320336363520,
    "created_at" : "2013-03-17 18:01:14 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 313354480932499457,
  "created_at" : "2013-03-17 18:21:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313353278593323008",
  "geo" : { },
  "id_str" : "313354079554400258",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt : )",
  "id" : 313354079554400258,
  "in_reply_to_status_id" : 313353278593323008,
  "created_at" : "2013-03-17 18:20:09 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/8gYM9J8AHA",
      "expanded_url" : "http:\/\/tl.gd\/lb5pf1",
      "display_url" : "tl.gd\/lb5pf1"
    } ]
  },
  "geo" : { },
  "id_str" : "313348375779082240",
  "text" : "\"And I really can't escape the nagging feeling that it just doesn't make a lick (cont) http:\/\/t.co\/8gYM9J8AHA",
  "id" : 313348375779082240,
  "created_at" : "2013-03-17 17:57:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/cArmUj9gtr",
      "expanded_url" : "http:\/\/instagr.am\/p\/W94wfSBH5A\/",
      "display_url" : "instagr.am\/p\/W94wfSBH5A\/"
    } ]
  },
  "geo" : { },
  "id_str" : "313341438970707968",
  "text" : "RT @ducksandclucks: You sure follow Ruby everywhere, Lionel.\n\"I love her.\" http:\/\/t.co\/cArmUj9gtr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/cArmUj9gtr",
        "expanded_url" : "http:\/\/instagr.am\/p\/W94wfSBH5A\/",
        "display_url" : "instagr.am\/p\/W94wfSBH5A\/"
      } ]
    },
    "geo" : { },
    "id_str" : "313340894826868736",
    "text" : "You sure follow Ruby everywhere, Lionel.\n\"I love her.\" http:\/\/t.co\/cArmUj9gtr",
    "id" : 313340894826868736,
    "created_at" : "2013-03-17 17:27:45 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 313341438970707968,
  "created_at" : "2013-03-17 17:29:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313339717183754240",
  "geo" : { },
  "id_str" : "313340507709386752",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 muah!",
  "id" : 313340507709386752,
  "in_reply_to_status_id" : 313339717183754240,
  "created_at" : "2013-03-17 17:26:13 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313340345381421056",
  "text" : "he really feels bad for not taking hell more seriously (its ppl's destinies after all.) he doesnt want to believe but too many verses.",
  "id" : 313340345381421056,
  "created_at" : "2013-03-17 17:25:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313339650758557696",
  "text" : "speaking of hell.. im reading Francis Chan's Erasing Hell. always good to check out opposing views...",
  "id" : 313339650758557696,
  "created_at" : "2013-03-17 17:22:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313338884538912769",
  "text" : "its sunday and im bored.. does that mean im going to hell?",
  "id" : 313338884538912769,
  "created_at" : "2013-03-17 17:19:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313338520481722368",
  "text" : "RT @HeadOnAHinge: \"On Netflix, your friends from Facebook will automatically see what you watch, including your past activity.\" IS THIS  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313320541182365696",
    "text" : "\"On Netflix, your friends from Facebook will automatically see what you watch, including your past activity.\" IS THIS A FEATURE OR A THREAT",
    "id" : 313320541182365696,
    "created_at" : "2013-03-17 16:06:52 +0000",
    "user" : {
      "name" : "Star \uD83C\uDF20",
      "screen_name" : "starpopfever",
      "protected" : false,
      "id_str" : "115686771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791614618493825025\/UYFVTbsf_normal.jpg",
      "id" : 115686771,
      "verified" : false
    }
  },
  "id" : 313338520481722368,
  "created_at" : "2013-03-17 17:18:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "theodore herrera",
      "screen_name" : "therrera3501",
      "indices" : [ 99, 112 ],
      "id_str" : "462577618",
      "id" : 462577618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313331858710593537",
  "geo" : { },
  "id_str" : "313332413822541825",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i prefer sheep over goats.. quiet, ez going, just munching away. goats are too hyper! @therrera3501",
  "id" : 313332413822541825,
  "in_reply_to_status_id" : 313331858710593537,
  "created_at" : "2013-03-17 16:54:03 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313332022942769152",
  "text" : "thought about adding farina but didnt know if it would be ok for them to eat #birds",
  "id" : 313332022942769152,
  "created_at" : "2013-03-17 16:52:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313331623947022336",
  "text" : "having run out of seed, been putting out oatmeal, cheerios w some PB mixed in.",
  "id" : 313331623947022336,
  "created_at" : "2013-03-17 16:50:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TAYA Radio",
      "screen_name" : "TAYARadio",
      "indices" : [ 121, 131 ],
      "id_str" : "524794262",
      "id" : 524794262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Ifi3hWoXwl",
      "expanded_url" : "http:\/\/tayaradio.com\/blog\/index.php\/apologetics\/what-does-the-coexist-sticker-really-mean\/",
      "display_url" : "tayaradio.com\/blog\/index.php\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313320591639846912",
  "text" : "tolerance is not necc. agreeing with... &gt;&gt; What does the 'Coexist' Sticker Really Mean? http:\/\/t.co\/Ifi3hWoXwl via @tayaradio",
  "id" : 313320591639846912,
  "created_at" : "2013-03-17 16:07:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aine Belton",
      "screen_name" : "AineBelton",
      "indices" : [ 3, 14 ],
      "id_str" : "24859536",
      "id" : 24859536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aine",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313317455676194816",
  "text" : "RT @AineBelton: When you shine you may light up people's shadows. Shine anyway. ~ #Aine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Aine",
        "indices" : [ 66, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313304495046131713",
    "text" : "When you shine you may light up people's shadows. Shine anyway. ~ #Aine",
    "id" : 313304495046131713,
    "created_at" : "2013-03-17 15:03:07 +0000",
    "user" : {
      "name" : "Aine Belton",
      "screen_name" : "AineBelton",
      "protected" : false,
      "id_str" : "24859536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522994441531822080\/gWfpKN0w_normal.jpeg",
      "id" : 24859536,
      "verified" : false
    }
  },
  "id" : 313317455676194816,
  "created_at" : "2013-03-17 15:54:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/313315601743486976\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/vqLhYroSor",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFke4TjCIAAKaEn.jpg",
      "id_str" : "313315601747681280",
      "id" : 313315601747681280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFke4TjCIAAKaEn.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/vqLhYroSor"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313316497621659648",
  "text" : "RT @marseelee: Think for yourself... http:\/\/t.co\/vqLhYroSor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/313315601743486976\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/vqLhYroSor",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFke4TjCIAAKaEn.jpg",
        "id_str" : "313315601747681280",
        "id" : 313315601747681280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFke4TjCIAAKaEn.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/vqLhYroSor"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313315601743486976",
    "text" : "Think for yourself... http:\/\/t.co\/vqLhYroSor",
    "id" : 313315601743486976,
    "created_at" : "2013-03-17 15:47:15 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 313316497621659648,
  "created_at" : "2013-03-17 15:50:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan Dolby",
      "screen_name" : "rvatheist",
      "indices" : [ 0, 10 ],
      "id_str" : "2943750633",
      "id" : 2943750633
    }, {
      "name" : "Mrs RooPoo McBoobies",
      "screen_name" : "RoooPooo",
      "indices" : [ 79, 88 ],
      "id_str" : "103240343",
      "id" : 103240343
    }, {
      "name" : "theodore herrera",
      "screen_name" : "therrera3501",
      "indices" : [ 89, 102 ],
      "id_str" : "462577618",
      "id" : 462577618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313316136106217472",
  "text" : "@RVAtheist exactly! which is why i do whatever i want now.. good or otherwise. @RoooPooo @therrera3501 @Skeptical_Lady",
  "id" : 313316136106217472,
  "created_at" : "2013-03-17 15:49:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "theodore herrera",
      "screen_name" : "therrera3501",
      "indices" : [ 61, 74 ],
      "id_str" : "462577618",
      "id" : 462577618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313309075385511936",
  "geo" : { },
  "id_str" : "313309480559468545",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny checking off a label on a form? @Skeptical_Lady @therrera3501",
  "id" : 313309480559468545,
  "in_reply_to_status_id" : 313309075385511936,
  "created_at" : "2013-03-17 15:22:55 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "theodore herrera",
      "screen_name" : "therrera3501",
      "indices" : [ 104, 117 ],
      "id_str" : "462577618",
      "id" : 462577618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313306249414467584",
  "geo" : { },
  "id_str" : "313308402661093376",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny maybe, maybe not. many ppl dont think about religion, just choose a label. @Skeptical_Lady @therrera3501",
  "id" : 313308402661093376,
  "in_reply_to_status_id" : 313306249414467584,
  "created_at" : "2013-03-17 15:18:38 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313302255803707394",
  "geo" : { },
  "id_str" : "313306824801656833",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible I have big issues w that concept when ppl say he's God .. its not for us to understand (re: damning ppl, hell)",
  "id" : 313306824801656833,
  "in_reply_to_status_id" : 313302255803707394,
  "created_at" : "2013-03-17 15:12:22 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Calvinism",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313305860417937408",
  "text" : "RT @AnnotatedBible: Can you imagine teaching #Calvinism to a grieving mother \"God is burning your baby in hell forever, because He has t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Calvinism",
        "indices" : [ 25, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313305248498343937",
    "text" : "Can you imagine teaching #Calvinism to a grieving mother \"God is burning your baby in hell forever, because He has to prove His sovereignty\"",
    "id" : 313305248498343937,
    "created_at" : "2013-03-17 15:06:06 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 313305860417937408,
  "created_at" : "2013-03-17 15:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313305294950264833",
  "text" : "@Skeptical_Lady same could be said for christians.. oy vey! ; )",
  "id" : 313305294950264833,
  "created_at" : "2013-03-17 15:06:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313304917437730817",
  "text" : "@Skeptical_Lady heehee.. that vision made me LOL (true for any group, really)",
  "id" : 313304917437730817,
  "created_at" : "2013-03-17 15:04:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "theodore herrera",
      "screen_name" : "therrera3501",
      "indices" : [ 116, 129 ],
      "id_str" : "462577618",
      "id" : 462577618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313295724685164544",
  "geo" : { },
  "id_str" : "313303350185705474",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny many ppl consider themselves [a religion] by default not by a specific reasoned choice @Skeptical_Lady @therrera3501",
  "id" : 313303350185705474,
  "in_reply_to_status_id" : 313295724685164544,
  "created_at" : "2013-03-17 14:58:34 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Jeffrey Levin",
      "screen_name" : "jilevin",
      "indices" : [ 16, 24 ],
      "id_str" : "24733117",
      "id" : 24733117
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jilevin\/status\/313016697445568512\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/b92zMMrez7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFgPByRCUAAgWre.jpg",
      "id_str" : "313016697449762816",
      "id" : 313016697449762816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFgPByRCUAAgWre.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/b92zMMrez7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313032951082385408",
  "text" : "RT @SangyeH: RT @jilevin: Why is our healthcare so expensive? http:\/\/t.co\/b92zMMrez7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeffrey Levin",
        "screen_name" : "jilevin",
        "indices" : [ 3, 11 ],
        "id_str" : "24733117",
        "id" : 24733117
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jilevin\/status\/313016697445568512\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/b92zMMrez7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFgPByRCUAAgWre.jpg",
        "id_str" : "313016697449762816",
        "id" : 313016697449762816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFgPByRCUAAgWre.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/b92zMMrez7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313032508193247232",
    "text" : "RT @jilevin: Why is our healthcare so expensive? http:\/\/t.co\/b92zMMrez7",
    "id" : 313032508193247232,
    "created_at" : "2013-03-16 21:02:20 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 313032951082385408,
  "created_at" : "2013-03-16 21:04:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313018323715649536",
  "text" : "i dont like to hear about females called sluts, whores, etc.",
  "id" : 313018323715649536,
  "created_at" : "2013-03-16 20:05:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313017150275215360",
  "text" : "sex.. thats what causes all the issues.. well, ppl's perception of it.",
  "id" : 313017150275215360,
  "created_at" : "2013-03-16 20:01:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Stacey Grimm",
      "screen_name" : "taboulichic",
      "indices" : [ 32, 44 ],
      "id_str" : "145358889",
      "id" : 145358889
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FB",
      "indices" : [ 125, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313001311564091393",
  "text" : "RT @angelaharms: Teary. Sweet. \"@taboulichic: *sniffle* This is how parents should be! (Originally posted by George Takei on #FB.) http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stacey Grimm",
        "screen_name" : "taboulichic",
        "indices" : [ 15, 27 ],
        "id_str" : "145358889",
        "id" : 145358889
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/taboulichic\/status\/313000212807421952\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/mBpu638I5u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFgACQOCEAA9IeX.jpg",
        "id_str" : "313000212815810560",
        "id" : 313000212815810560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFgACQOCEAA9IeX.jpg",
        "sizes" : [ {
          "h" : 468,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/mBpu638I5u"
      } ],
      "hashtags" : [ {
        "text" : "FB",
        "indices" : [ 108, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "313000688944836609",
    "text" : "Teary. Sweet. \"@taboulichic: *sniffle* This is how parents should be! (Originally posted by George Takei on #FB.) http:\/\/t.co\/mBpu638I5u\"",
    "id" : 313000688944836609,
    "created_at" : "2013-03-16 18:55:54 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 313001311564091393,
  "created_at" : "2013-03-16 18:58:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312970091039969280",
  "text" : "RT @MWM4444: What's missing from Paul Ryan's fantasy budget? The poor, the sick, the elderly, compassion, justice, intelligence, &amp; p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 134, 137 ]
      }, {
        "text" : "tcot",
        "indices" : [ 138, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312969687149453312",
    "text" : "What's missing from Paul Ryan's fantasy budget? The poor, the sick, the elderly, compassion, justice, intelligence, &amp; patriotism. #p2 #tcot",
    "id" : 312969687149453312,
    "created_at" : "2013-03-16 16:52:42 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 312970091039969280,
  "created_at" : "2013-03-16 16:54:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sigh",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312969295627948033",
  "text" : "not a big drinker anymore.. so instead of drinking when bored, i watch lifetime movie network.. #sigh",
  "id" : 312969295627948033,
  "created_at" : "2013-03-16 16:51:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312937680394653697",
  "geo" : { },
  "id_str" : "312939650811568129",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible use #atheist to get better response : )",
  "id" : 312939650811568129,
  "in_reply_to_status_id" : 312937680394653697,
  "created_at" : "2013-03-16 14:53:21 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Sfv3A0jAph",
      "expanded_url" : "http:\/\/www.wired.com\/dangerroom\/2013\/03\/iraq-waste\/#.UUSFrQq3Hvg.twitter",
      "display_url" : "wired.com\/dangerroom\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312939087990509568",
  "text" : "RT @ezraklein: \"The legacy of all the money the U.S. wasted in Iraq might be summed up with a single quote.\" http:\/\/t.co\/Sfv3A0jAph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/Sfv3A0jAph",
        "expanded_url" : "http:\/\/www.wired.com\/dangerroom\/2013\/03\/iraq-waste\/#.UUSFrQq3Hvg.twitter",
        "display_url" : "wired.com\/dangerroom\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312937844874309633",
    "text" : "\"The legacy of all the money the U.S. wasted in Iraq might be summed up with a single quote.\" http:\/\/t.co\/Sfv3A0jAph",
    "id" : 312937844874309633,
    "created_at" : "2013-03-16 14:46:10 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 312939087990509568,
  "created_at" : "2013-03-16 14:51:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaelle faella Zamor ",
      "screen_name" : "GaelleZ",
      "indices" : [ 0, 8 ],
      "id_str" : "1319107693",
      "id" : 1319107693
    }, {
      "name" : "eric soles",
      "screen_name" : "ericsoles40",
      "indices" : [ 43, 55 ],
      "id_str" : "581819939",
      "id" : 581819939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312937810506178561",
  "geo" : { },
  "id_str" : "312938189646098432",
  "in_reply_to_user_id" : 34029244,
  "text" : "@Gaellez john goodman i think @islander613 @ericsoles40",
  "id" : 312938189646098432,
  "in_reply_to_status_id" : 312937810506178561,
  "created_at" : "2013-03-16 14:47:33 +0000",
  "in_reply_to_screen_name" : "shadow_abyss",
  "in_reply_to_user_id_str" : "34029244",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312937119070949376",
  "text" : "RT @TheEntertainer: There's WAY more to life than working a \"j.o.b.\" or chasing money...\n\nNow don't get me wrong, I LOVES me my money... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/gNapIBIi54",
        "expanded_url" : "http:\/\/fb.me\/BwZM9CI8",
        "display_url" : "fb.me\/BwZM9CI8"
      } ]
    },
    "geo" : { },
    "id_str" : "312933556362027012",
    "text" : "There's WAY more to life than working a \"j.o.b.\" or chasing money...\n\nNow don't get me wrong, I LOVES me my money... http:\/\/t.co\/gNapIBIi54",
    "id" : 312933556362027012,
    "created_at" : "2013-03-16 14:29:08 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 312937119070949376,
  "created_at" : "2013-03-16 14:43:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jehovahs",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "badidea",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312936420635467776",
  "text" : "clean cut, friendly, young man and young woman came to door to leave pamphlet. #jehovahs im so polite, i took it. #badidea",
  "id" : 312936420635467776,
  "created_at" : "2013-03-16 14:40:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justify Travis",
      "screen_name" : "JustifyTravis",
      "indices" : [ 0, 14 ],
      "id_str" : "1179162770",
      "id" : 1179162770
    }, {
      "name" : "MommieDawn",
      "screen_name" : "MommieDawn",
      "indices" : [ 121, 132 ],
      "id_str" : "15864565",
      "id" : 15864565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312604120110489601",
  "geo" : { },
  "id_str" : "312609204928143360",
  "in_reply_to_user_id" : 1179162770,
  "text" : "@JustifyTravis may 24 i think.. gun stolen may 26. i agree that text is what set her off. she knew she'd never have him. @MommieDawn",
  "id" : 312609204928143360,
  "in_reply_to_status_id" : 312604120110489601,
  "created_at" : "2013-03-15 17:00:17 +0000",
  "in_reply_to_screen_name" : "JustifyTravis",
  "in_reply_to_user_id_str" : "1179162770",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dreaminterpretation",
      "indices" : [ 94, 114 ]
    }, {
      "text" : "yesimoddduck",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312601449739730944",
  "text" : "i often have dreams where i cant get my clothes off (come off slowly, like sticking to me) .. #dreaminterpretation #yesimoddduck",
  "id" : 312601449739730944,
  "created_at" : "2013-03-15 16:29:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312584946671841282",
  "geo" : { },
  "id_str" : "312586362010337280",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny all these stupid rules are not making us safer.. just making us more obedient.. grrr...",
  "id" : 312586362010337280,
  "in_reply_to_status_id" : 312584946671841282,
  "created_at" : "2013-03-15 15:29:30 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312582287374032896",
  "text" : "@Skeptical_Lady Bingo! (fear being the operative word here)",
  "id" : 312582287374032896,
  "created_at" : "2013-03-15 15:13:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MyMick",
      "screen_name" : "MyMick",
      "indices" : [ 111, 118 ],
      "id_str" : "368247423",
      "id" : 368247423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312579365311508481",
  "text" : "@hwandnewsjunkie wasnt there duct tape found in bathroom? im thinking she used that to tape knife to her body? @MyMick",
  "id" : 312579365311508481,
  "created_at" : "2013-03-15 15:01:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MyMick",
      "screen_name" : "MyMick",
      "indices" : [ 0, 7 ],
      "id_str" : "368247423",
      "id" : 368247423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312566256404406278",
  "geo" : { },
  "id_str" : "312575146932174848",
  "in_reply_to_user_id" : 368247423,
  "text" : "@MyMick she's trying to show mixed mems from when she would visit travis (to use as defense) @hwandnewsjunkie",
  "id" : 312575146932174848,
  "in_reply_to_status_id" : 312566256404406278,
  "created_at" : "2013-03-15 14:44:57 +0000",
  "in_reply_to_screen_name" : "MyMick",
  "in_reply_to_user_id_str" : "368247423",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "indices" : [ 3, 14 ],
      "id_str" : "79711579",
      "id" : 79711579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312373373474832384",
  "text" : "RT @sparklekaz: \"Be a lamp to yourself. Be your own confidence. Hold to the truth within yourself, as to the only truth.\" Buddha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312372518667309056",
    "text" : "\"Be a lamp to yourself. Be your own confidence. Hold to the truth within yourself, as to the only truth.\" Buddha",
    "id" : 312372518667309056,
    "created_at" : "2013-03-15 01:19:46 +0000",
    "user" : {
      "name" : "SPIRITU\u2206L SEEKER",
      "screen_name" : "sparklekaz",
      "protected" : false,
      "id_str" : "79711579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458752632157270016\/4oAqleoz_normal.jpeg",
      "id" : 79711579,
      "verified" : false
    }
  },
  "id" : 312373373474832384,
  "created_at" : "2013-03-15 01:23:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312370857353809921",
  "geo" : { },
  "id_str" : "312372716676202497",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i just thought you'd enjoy how he described the bible (which he was spot on about)",
  "id" : 312372716676202497,
  "in_reply_to_status_id" : 312370857353809921,
  "created_at" : "2013-03-15 01:20:33 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312370857353809921",
  "geo" : { },
  "id_str" : "312372499742593025",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny maybe he is.. but at this point i dont know what to think anymore. the world has gotten so weird.",
  "id" : 312372499742593025,
  "in_reply_to_status_id" : 312370857353809921,
  "created_at" : "2013-03-15 01:19:42 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312366390290030592",
  "text" : "RT @JAScribbles: Here's my Amazon reviewer profile. I want to read and review two more indie or small press authors this month.  https:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/4TTQ4oY7kD",
        "expanded_url" : "https:\/\/www.amazon.com\/gp\/pdp\/profile\/AXSV2IRQX2C20?ie=UTF8&ref_=cm_aya_bb_pdp",
        "display_url" : "amazon.com\/gp\/pdp\/profile\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312363507469393920",
    "text" : "Here's my Amazon reviewer profile. I want to read and review two more indie or small press authors this month.  https:\/\/t.co\/4TTQ4oY7kD",
    "id" : 312363507469393920,
    "created_at" : "2013-03-15 00:43:58 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 312366390290030592,
  "created_at" : "2013-03-15 00:55:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/USY1ZD2Qx2",
      "expanded_url" : "http:\/\/youtu.be\/4D9j8dJ8AZI",
      "display_url" : "youtu.be\/4D9j8dJ8AZI"
    } ]
  },
  "geo" : { },
  "id_str" : "312365178350100480",
  "in_reply_to_user_id" : 51880276,
  "text" : "@virgojohnny you'll like 19:51 David Icke - The Lunatics Are Running The Asylum!!: http:\/\/t.co\/USY1ZD2Qx2",
  "id" : 312365178350100480,
  "created_at" : "2013-03-15 00:50:36 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JMW",
      "screen_name" : "JoMWy",
      "indices" : [ 0, 6 ],
      "id_str" : "217958824",
      "id" : 217958824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/VUo5yKSQLJ",
      "expanded_url" : "http:\/\/grahamwinch.files.wordpress.com\/2013\/01\/floresinvestigationreport.pdf",
      "display_url" : "grahamwinch.files.wordpress.com\/2013\/01\/flores\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "312341274923511810",
  "geo" : { },
  "id_str" : "312342360614920193",
  "in_reply_to_user_id" : 217958824,
  "text" : "@JoMWy this should help &gt;&gt; http:\/\/t.co\/VUo5yKSQLJ",
  "id" : 312342360614920193,
  "in_reply_to_status_id" : 312341274923511810,
  "created_at" : "2013-03-14 23:19:56 +0000",
  "in_reply_to_screen_name" : "JoMWy",
  "in_reply_to_user_id_str" : "217958824",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DK",
      "screen_name" : "DKaechler",
      "indices" : [ 0, 10 ],
      "id_str" : "844506270",
      "id" : 844506270
    }, {
      "name" : "Jane Velez-Mitchell",
      "screen_name" : "jvelezmitchell",
      "indices" : [ 19, 34 ],
      "id_str" : "2528614904",
      "id" : 2528614904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312337687996690434",
  "geo" : { },
  "id_str" : "312339803263881219",
  "in_reply_to_user_id" : 844506270,
  "text" : "@DKaechler agreed! @jvelezmitchell",
  "id" : 312339803263881219,
  "in_reply_to_status_id" : 312337687996690434,
  "created_at" : "2013-03-14 23:09:46 +0000",
  "in_reply_to_screen_name" : "DKaechler",
  "in_reply_to_user_id_str" : "844506270",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grandma",
      "screen_name" : "Beinhonest51",
      "indices" : [ 0, 13 ],
      "id_str" : "985984776",
      "id" : 985984776
    }, {
      "name" : "Wild About Trial",
      "screen_name" : "WildAboutTrial",
      "indices" : [ 105, 120 ],
      "id_str" : "465781550",
      "id" : 465781550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312316666979688448",
  "geo" : { },
  "id_str" : "312319892646940672",
  "in_reply_to_user_id" : 985984776,
  "text" : "@Beinhonest51 YES.. he shows all signs of being pursued, no signs of having weapons.. JA shows opposite. @WildAboutTrial",
  "id" : 312319892646940672,
  "in_reply_to_status_id" : 312316666979688448,
  "created_at" : "2013-03-14 21:50:39 +0000",
  "in_reply_to_screen_name" : "Beinhonest51",
  "in_reply_to_user_id_str" : "985984776",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312309977358409729",
  "text" : "RT @OMGFacts: Allergic reactions to nuts can be triggered by semen from someone who recently consumed brazil nuts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312307464978710528",
    "text" : "Allergic reactions to nuts can be triggered by semen from someone who recently consumed brazil nuts.",
    "id" : 312307464978710528,
    "created_at" : "2013-03-14 21:01:16 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 312309977358409729,
  "created_at" : "2013-03-14 21:11:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gangly Dwarf",
      "screen_name" : "GanglyD",
      "indices" : [ 2, 10 ],
      "id_str" : "1228770344",
      "id" : 1228770344
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312307819175092226",
  "geo" : { },
  "id_str" : "312309742028587008",
  "in_reply_to_user_id" : 1228770344,
  "text" : ". @GanglyD ..and WHY drag him to shower? for what purpose? (to clean up evidence? then that=sound of mind)",
  "id" : 312309742028587008,
  "in_reply_to_status_id" : 312307819175092226,
  "created_at" : "2013-03-14 21:10:19 +0000",
  "in_reply_to_screen_name" : "GanglyD",
  "in_reply_to_user_id_str" : "1228770344",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 106, 116 ]
    }, {
      "text" : "guilty",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312309118213951488",
  "text" : "ok, \"presuming\" SD, can we say it's rather abnormal for the overkill? TA had no weapons, used no weapons. #jodiarias #guilty",
  "id" : 312309118213951488,
  "created_at" : "2013-03-14 21:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312222823286460417",
  "geo" : { },
  "id_str" : "312233250405879809",
  "in_reply_to_user_id" : 319249117,
  "text" : "@R_Worthy yeah.. getting older.. blah.. lol",
  "id" : 312233250405879809,
  "in_reply_to_status_id" : 312222823286460417,
  "created_at" : "2013-03-14 16:06:22 +0000",
  "in_reply_to_screen_name" : "Boldtowngirl",
  "in_reply_to_user_id_str" : "319249117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312223217978859522",
  "text" : "dear universe, please dont let my sister notice the scratch! Thanks so much!!",
  "id" : 312223217978859522,
  "created_at" : "2013-03-14 15:26:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Exposing Religion",
      "screen_name" : "exposingreligio",
      "indices" : [ 0, 16 ],
      "id_str" : "1084925148",
      "id" : 1084925148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312180999406645249",
  "geo" : { },
  "id_str" : "312222906451120128",
  "in_reply_to_user_id" : 1084925148,
  "text" : "@exposingreligio like my voice because its me speaking to me...",
  "id" : 312222906451120128,
  "in_reply_to_status_id" : 312180999406645249,
  "created_at" : "2013-03-14 15:25:16 +0000",
  "in_reply_to_screen_name" : "exposingreligio",
  "in_reply_to_user_id_str" : "1084925148",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@tw1tt3rart",
      "screen_name" : "tw1tt3rart",
      "indices" : [ 3, 14 ],
      "id_str" : "80464900",
      "id" : 80464900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312174874779058178",
  "text" : "RT @tw1tt3rart: \u2595\u2594\u2594\u2594\u2594\u258F\u2508\u2595\u2594\u258F\u2508\u2508\u2571\u2594\u258F\u2508\n\u2508\u2594\u2594\u2571\u2571\u2508\u2508\u2571\u2508\u258F\u2508\u2571\u2571\u258F\u258F\u2508\n\u2508\u2595\u2594\u2595\u2508\u2508\u2508\u2594\u258F\u258F\u2571\u2571\u2508\u258F\u258F\u2508\n\u2508\u2508\u2594\u2572\u2572\u2508\u2508\u2508\u258F\u258F\u258F\u2594\u2594\u2508\u258F\u2508\n\u2595\u2594\u258F\u2508\u258F\u258F\u250F\u2513\u258F\u258F\u2594\u2594\u2594\u258F\u258F\u2508\n\u2508\u2572\u2594\u2594\u2571\u2508\u2517\u251B\u258F\u258F\u2508\u2508\u2508\u258F\u258F\u2508 Happy Pi Day #PiDa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PiDay",
        "indices" : [ 115, 121 ]
      }, {
        "text" : "TwitterArt",
        "indices" : [ 122, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "179981260171653120",
    "text" : "\u2595\u2594\u2594\u2594\u2594\u258F\u2508\u2595\u2594\u258F\u2508\u2508\u2571\u2594\u258F\u2508\n\u2508\u2594\u2594\u2571\u2571\u2508\u2508\u2571\u2508\u258F\u2508\u2571\u2571\u258F\u258F\u2508\n\u2508\u2595\u2594\u2595\u2508\u2508\u2508\u2594\u258F\u258F\u2571\u2571\u2508\u258F\u258F\u2508\n\u2508\u2508\u2594\u2572\u2572\u2508\u2508\u2508\u258F\u258F\u258F\u2594\u2594\u2508\u258F\u2508\n\u2595\u2594\u258F\u2508\u258F\u258F\u250F\u2513\u258F\u258F\u2594\u2594\u2594\u258F\u258F\u2508\n\u2508\u2572\u2594\u2594\u2571\u2508\u2517\u251B\u258F\u258F\u2508\u2508\u2508\u258F\u258F\u2508 Happy Pi Day #PiDay #TwitterArt",
    "id" : 179981260171653120,
    "created_at" : "2012-03-14 17:24:10 +0000",
    "user" : {
      "name" : "@tw1tt3rart",
      "screen_name" : "tw1tt3rart",
      "protected" : false,
      "id_str" : "80464900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000088772345\/9deb12300adb788ac2cac863c12f0113_normal.jpeg",
      "id" : 80464900,
      "verified" : false
    }
  },
  "id" : 312174874779058178,
  "created_at" : "2013-03-14 12:14:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312173582459486208",
  "text" : "RT @AnAmericanMonk: The sagely person is like water. Water benefits all things and does not compete with them. Lao Tzu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312172143846768640",
    "text" : "The sagely person is like water. Water benefits all things and does not compete with them. Lao Tzu",
    "id" : 312172143846768640,
    "created_at" : "2013-03-14 12:03:33 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 312173582459486208,
  "created_at" : "2013-03-14 12:09:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312172900461465600",
  "text" : "Happy Birthday, Albert Einstein! 1879-1955",
  "id" : 312172900461465600,
  "created_at" : "2013-03-14 12:06:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/n2amDUXZvw",
      "expanded_url" : "http:\/\/www.piday.org\/",
      "display_url" : "piday.org"
    } ]
  },
  "geo" : { },
  "id_str" : "312172025735151616",
  "text" : "Happy Pi Day! http:\/\/t.co\/n2amDUXZvw",
  "id" : 312172025735151616,
  "created_at" : "2013-03-14 12:03:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/UQt6HeFkOs",
      "expanded_url" : "http:\/\/huff.to\/14YxIWb",
      "display_url" : "huff.to\/14YxIWb"
    } ]
  },
  "geo" : { },
  "id_str" : "311997708145655809",
  "text" : "RT @HuffPostWeird: You won't believe what Ted Nugent is bragging about http:\/\/t.co\/UQt6HeFkOs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/UQt6HeFkOs",
        "expanded_url" : "http:\/\/huff.to\/14YxIWb",
        "display_url" : "huff.to\/14YxIWb"
      } ]
    },
    "geo" : { },
    "id_str" : "311989085197697025",
    "text" : "You won't believe what Ted Nugent is bragging about http:\/\/t.co\/UQt6HeFkOs",
    "id" : 311989085197697025,
    "created_at" : "2013-03-13 23:56:09 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 311997708145655809,
  "created_at" : "2013-03-14 00:30:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "Sherbear1",
      "screen_name" : "slwade1",
      "indices" : [ 89, 97 ],
      "id_str" : "42651153",
      "id" : 42651153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311992751837298688",
  "geo" : { },
  "id_str" : "311995833841221632",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool perspective, perspective, perspective (location, location, location) ; ) @slwade1",
  "id" : 311995833841221632,
  "in_reply_to_status_id" : 311992751837298688,
  "created_at" : "2013-03-14 00:22:58 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311958169079402496",
  "text" : "\"what are going to do with it? throw it at him?\" good one, JM! #jodiarias",
  "id" : 311958169079402496,
  "created_at" : "2013-03-13 21:53:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311956212155551744",
  "text" : "plus.. didnt #jodiarias earlier today say something about \"not stepping, just reaching, wasnt that high\" ?",
  "id" : 311956212155551744,
  "created_at" : "2013-03-13 21:45:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311955874266615809",
  "text" : "he's going after #jodiarias w the shelves.. yes! you cant stand on them!",
  "id" : 311955874266615809,
  "created_at" : "2013-03-13 21:44:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311951820505362432",
  "geo" : { },
  "id_str" : "311954386383433729",
  "in_reply_to_user_id" : 319249117,
  "text" : ". @R_Worthy very nearsighted, 46, i take glasses on\/off several times daily for reading, using tablet... (last few years)",
  "id" : 311954386383433729,
  "in_reply_to_status_id" : 311951820505362432,
  "created_at" : "2013-03-13 21:38:16 +0000",
  "in_reply_to_screen_name" : "Boldtowngirl",
  "in_reply_to_user_id_str" : "319249117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0633\u0645\u0631\u0627\u0646\u064A \u0645\u0632\u064A\u0648\u0646",
      "screen_name" : "kathyva1",
      "indices" : [ 3, 12 ],
      "id_str" : "702247033663574016",
      "id" : 702247033663574016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 14, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311947019918901248",
  "text" : "RT @kathyva1: #JodiArias The judge needs to take control of this trial.  There are more sidebars than trial",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311946554938376192",
    "text" : "#JodiArias The judge needs to take control of this trial.  There are more sidebars than trial",
    "id" : 311946554938376192,
    "created_at" : "2013-03-13 21:07:09 +0000",
    "user" : {
      "name" : "Kitz",
      "screen_name" : "Kitz99",
      "protected" : false,
      "id_str" : "230493818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544168615453290496\/31r7WvdB_normal.jpeg",
      "id" : 230493818,
      "verified" : false
    }
  },
  "id" : 311947019918901248,
  "created_at" : "2013-03-13 21:08:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Happy Toe",
      "screen_name" : "PnkyRght",
      "indices" : [ 0, 9 ],
      "id_str" : "616646669",
      "id" : 616646669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/VUo5yKSQLJ",
      "expanded_url" : "http:\/\/grahamwinch.files.wordpress.com\/2013\/01\/floresinvestigationreport.pdf",
      "display_url" : "grahamwinch.files.wordpress.com\/2013\/01\/flores\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "311938527187324928",
  "geo" : { },
  "id_str" : "311940370038661121",
  "in_reply_to_user_id" : 616646669,
  "text" : "@PnkyRght this helps explain &gt;&gt; http:\/\/t.co\/VUo5yKSQLJ",
  "id" : 311940370038661121,
  "in_reply_to_status_id" : 311938527187324928,
  "created_at" : "2013-03-13 20:42:34 +0000",
  "in_reply_to_screen_name" : "PnkyRght",
  "in_reply_to_user_id_str" : "616646669",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311930532541906944",
  "text" : "of course #jodiarias will not apologize or show remorse. its not in her personality type\/disorder.",
  "id" : 311930532541906944,
  "created_at" : "2013-03-13 20:03:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Happy Toe",
      "screen_name" : "PnkyRght",
      "indices" : [ 0, 9 ],
      "id_str" : "616646669",
      "id" : 616646669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311919195967344641",
  "geo" : { },
  "id_str" : "311921457951289345",
  "in_reply_to_user_id" : 616646669,
  "text" : "@PnkyRght each RM kept to themselves.. in\/out. used to TA travelling.",
  "id" : 311921457951289345,
  "in_reply_to_status_id" : 311919195967344641,
  "created_at" : "2013-03-13 19:27:25 +0000",
  "in_reply_to_screen_name" : "PnkyRght",
  "in_reply_to_user_id_str" : "616646669",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311919410598252546",
  "geo" : { },
  "id_str" : "311920881037373440",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 makes me think of Francis of Assisi.. i'll take it as a good sign : )",
  "id" : 311920881037373440,
  "in_reply_to_status_id" : 311919410598252546,
  "created_at" : "2013-03-13 19:25:07 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311914042287591424",
  "text" : "RT @tracey0529: \u201C@DoctorGooFee: #jodiarias ugh..we wait 5 days and get 62 seconds of Testimony..\u201D&lt;&lt;&lt;&lt; yup! Nice huh?!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 16, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311912469620744192",
    "text" : "\u201C@DoctorGooFee: #jodiarias ugh..we wait 5 days and get 62 seconds of Testimony..\u201D&lt;&lt;&lt;&lt; yup! Nice huh?!",
    "id" : 311912469620744192,
    "created_at" : "2013-03-13 18:51:42 +0000",
    "user" : {
      "name" : "K",
      "screen_name" : "Lpn0513",
      "protected" : false,
      "id_str" : "30980826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769994897684328454\/Ix3T6VBi_normal.jpg",
      "id" : 30980826,
      "verified" : false
    }
  },
  "id" : 311914042287591424,
  "created_at" : "2013-03-13 18:57:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311911014365028353",
  "geo" : { },
  "id_str" : "311911419803222016",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses nice job, hubby! : ) love it!",
  "id" : 311911419803222016,
  "in_reply_to_status_id" : 311911014365028353,
  "created_at" : "2013-03-13 18:47:32 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer",
      "screen_name" : "janal811",
      "indices" : [ 3, 12 ],
      "id_str" : "189631229",
      "id" : 189631229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311910814342840320",
  "text" : "RT @janal811: court out for 5 days &amp; we got a WHOLE 45 (not including sidebars) minutes before break #jodiarias @ this pace this sho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311908494242611200",
    "text" : "court out for 5 days &amp; we got a WHOLE 45 (not including sidebars) minutes before break #jodiarias @ this pace this should be over by June",
    "id" : 311908494242611200,
    "created_at" : "2013-03-13 18:35:54 +0000",
    "user" : {
      "name" : "Jennifer",
      "screen_name" : "janal811",
      "protected" : false,
      "id_str" : "189631229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573182999413440512\/7xztUs6i_normal.png",
      "id" : 189631229,
      "verified" : false
    }
  },
  "id" : 311910814342840320,
  "created_at" : "2013-03-13 18:45:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy R.",
      "screen_name" : "andyacr",
      "indices" : [ 3, 11 ],
      "id_str" : "26515055",
      "id" : 26515055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311910003193819137",
  "text" : "RT @andyacr: The court is in recess until 4:15pm eastern. #JodiArias",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 45, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311908348184363009",
    "text" : "The court is in recess until 4:15pm eastern. #JodiArias",
    "id" : 311908348184363009,
    "created_at" : "2013-03-13 18:35:19 +0000",
    "user" : {
      "name" : "Andy R.",
      "screen_name" : "andyacr",
      "protected" : false,
      "id_str" : "26515055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786867619114520581\/77jJ6sVY_normal.jpg",
      "id" : 26515055,
      "verified" : false
    }
  },
  "id" : 311910003193819137,
  "created_at" : "2013-03-13 18:41:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311909118266978304",
  "text" : "GD.. now they are in recess for 45 min due to audio problems!! #jodiarias",
  "id" : 311909118266978304,
  "created_at" : "2013-03-13 18:38:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311905204813582336",
  "text" : "RT @twitter: Guess what you can do\nView line breaks on Twitter web\nLet the fun begin.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311902625606033410",
    "text" : "Guess what you can do\nView line breaks on Twitter web\nLet the fun begin.",
    "id" : 311902625606033410,
    "created_at" : "2013-03-13 18:12:35 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767879603977191425\/29zfZY6I_normal.jpg",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 311905204813582336,
  "created_at" : "2013-03-13 18:22:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrikeDebt",
      "screen_name" : "StrikeDebt",
      "indices" : [ 3, 14 ],
      "id_str" : "598921658",
      "id" : 598921658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311904645259866112",
  "text" : "RT @StrikeDebt: Time to pull the plug on forprofit insurance #SinglePayer would save 400B dollars over Obamacare. Deficit reduction begi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 45, 57 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311843641452814336",
    "text" : "Time to pull the plug on forprofit insurance #SinglePayer would save 400B dollars over Obamacare. Deficit reduction begins with #SinglePayer",
    "id" : 311843641452814336,
    "created_at" : "2013-03-13 14:18:12 +0000",
    "user" : {
      "name" : "StrikeDebt",
      "screen_name" : "StrikeDebt",
      "protected" : false,
      "id_str" : "598921658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2487186800\/wcgxuqgrfjcvuv3e755f_normal.jpeg",
      "id" : 598921658,
      "verified" : false
    }
  },
  "id" : 311904645259866112,
  "created_at" : "2013-03-13 18:20:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StrikeDebt",
      "screen_name" : "StrikeDebt",
      "indices" : [ 3, 14 ],
      "id_str" : "598921658",
      "id" : 598921658
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311904613857128448",
  "text" : "RT @StrikeDebt: Dear Paul Ryan: Don't cut Medicare. #SinglePayer cuts 400B from nat debt. But it doesn't kick the poor, which is your re ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 36, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311844009242939393",
    "text" : "Dear Paul Ryan: Don't cut Medicare. #SinglePayer cuts 400B from nat debt. But it doesn't kick the poor, which is your real goal here innit?",
    "id" : 311844009242939393,
    "created_at" : "2013-03-13 14:19:40 +0000",
    "user" : {
      "name" : "StrikeDebt",
      "screen_name" : "StrikeDebt",
      "protected" : false,
      "id_str" : "598921658",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2487186800\/wcgxuqgrfjcvuv3e755f_normal.jpeg",
      "id" : 598921658,
      "verified" : false
    }
  },
  "id" : 311904613857128448,
  "created_at" : "2013-03-13 18:20:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Smith",
      "screen_name" : "ryansmithtv",
      "indices" : [ 109, 121 ],
      "id_str" : "41587384",
      "id" : 41587384
    }, {
      "name" : "Team HLN",
      "screen_name" : "TeamHLN",
      "indices" : [ 122, 130 ],
      "id_str" : "281590597",
      "id" : 281590597
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311904316682301440",
  "text" : "yup! RT @missvengeance13 That's it. Heading back to livestream. No commercials and no pope watch. #JodiArias @ryansmithtv @TeamHLN",
  "id" : 311904316682301440,
  "created_at" : "2013-03-13 18:19:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larissa Bolalek",
      "screen_name" : "LarissaBolalek",
      "indices" : [ 3, 18 ],
      "id_str" : "365235836",
      "id" : 365235836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311902069797814272",
  "text" : "RT @LarissaBolalek: I don't care about the pope!! Put #jodiarias back on damnit!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jodiarias",
        "indices" : [ 34, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311901615529553920",
    "text" : "I don't care about the pope!! Put #jodiarias back on damnit!!!",
    "id" : 311901615529553920,
    "created_at" : "2013-03-13 18:08:34 +0000",
    "user" : {
      "name" : "Larissa Bolalek",
      "screen_name" : "LarissaBolalek",
      "protected" : false,
      "id_str" : "365235836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851780977\/e248f138653a808582dfba4bc1c28a52_normal.jpeg",
      "id" : 365235836,
      "verified" : false
    }
  },
  "id" : 311902069797814272,
  "created_at" : "2013-03-13 18:10:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311901367235125248",
  "text" : "body slam, roll, running, grabbing gun.. its like a thriller movie the way #jodiarias describes it",
  "id" : 311901367235125248,
  "created_at" : "2013-03-13 18:07:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rania Khalek",
      "screen_name" : "RaniaKhalek",
      "indices" : [ 3, 15 ],
      "id_str" : "37501003",
      "id" : 37501003
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICYMI",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/mwV5M8GpcM",
      "expanded_url" : "http:\/\/wp.me\/p1jVkN-GI",
      "display_url" : "wp.me\/p1jVkN-GI"
    } ]
  },
  "geo" : { },
  "id_str" : "311862249004343296",
  "text" : "RT @RaniaKhalek: You Wanna Drug Test Welfare Recipients? Start with Corporate Executives: http:\/\/t.co\/mwV5M8GpcM #ICYMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICYMI",
        "indices" : [ 96, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/mwV5M8GpcM",
        "expanded_url" : "http:\/\/wp.me\/p1jVkN-GI",
        "display_url" : "wp.me\/p1jVkN-GI"
      } ]
    },
    "geo" : { },
    "id_str" : "309880788810346496",
    "text" : "You Wanna Drug Test Welfare Recipients? Start with Corporate Executives: http:\/\/t.co\/mwV5M8GpcM #ICYMI",
    "id" : 309880788810346496,
    "created_at" : "2013-03-08 04:18:32 +0000",
    "user" : {
      "name" : "Rania Khalek",
      "screen_name" : "RaniaKhalek",
      "protected" : false,
      "id_str" : "37501003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759900197388423168\/r0OzSEtV_normal.jpg",
      "id" : 37501003,
      "verified" : true
    }
  },
  "id" : 311862249004343296,
  "created_at" : "2013-03-13 15:32:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311857853101117440",
  "text" : "@LadyLavender12 ; )",
  "id" : 311857853101117440,
  "created_at" : "2013-03-13 15:14:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311645867440500736",
  "text" : "i like it when ppl wink..",
  "id" : 311645867440500736,
  "created_at" : "2013-03-13 01:12:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "indices" : [ 2, 14 ],
      "id_str" : "19791234",
      "id" : 19791234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shooshoo",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311638205487280129",
  "geo" : { },
  "id_str" : "311645467027066880",
  "in_reply_to_user_id" : 19791234,
  "text" : ". @Emperor_Bob plz.. cant someone make him go away?? #shooshoo",
  "id" : 311645467027066880,
  "in_reply_to_status_id" : 311638205487280129,
  "created_at" : "2013-03-13 01:10:44 +0000",
  "in_reply_to_screen_name" : "Emperor_Bob",
  "in_reply_to_user_id_str" : "19791234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    }, {
      "name" : ".",
      "screen_name" : "FirstWorldFacts",
      "indices" : [ 22, 38 ],
      "id_str" : "2707395157",
      "id" : 2707395157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311545859257032704",
  "text" : "RT @ificouldtellu: RT @firstworldfacts: 95% of the universe is made up of \"Dark Matter\" and no one knows what dark matter is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : ".",
        "screen_name" : "FirstWorldFacts",
        "indices" : [ 3, 19 ],
        "id_str" : "2707395157",
        "id" : 2707395157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311545033306296320",
    "text" : "RT @firstworldfacts: 95% of the universe is made up of \"Dark Matter\" and no one knows what dark matter is.",
    "id" : 311545033306296320,
    "created_at" : "2013-03-12 18:31:38 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 311545859257032704,
  "created_at" : "2013-03-12 18:34:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311539738920243202",
  "geo" : { },
  "id_str" : "311544161478254592",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 HLN says its back on wed...",
  "id" : 311544161478254592,
  "in_reply_to_status_id" : 311539738920243202,
  "created_at" : "2013-03-12 18:28:10 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "^^vallli^^64^^",
      "screen_name" : "Farrinna64",
      "indices" : [ 0, 11 ],
      "id_str" : "37856282",
      "id" : 37856282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311509805930008577",
  "geo" : { },
  "id_str" : "311517619494739968",
  "in_reply_to_user_id" : 37856282,
  "text" : "@Farrinna64 start w pics (date shows her there that day) plus her bloody palm print (she was there when he was bleeding) = facts #jodiarias",
  "id" : 311517619494739968,
  "in_reply_to_status_id" : 311509805930008577,
  "created_at" : "2013-03-12 16:42:42 +0000",
  "in_reply_to_screen_name" : "Farrinna64",
  "in_reply_to_user_id_str" : "37856282",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmonic Institute",
      "screen_name" : "caebling",
      "indices" : [ 0, 9 ],
      "id_str" : "22560761",
      "id" : 22560761
    }, {
      "name" : "marling richards",
      "screen_name" : "anthxeria",
      "indices" : [ 109, 119 ],
      "id_str" : "76950285",
      "id" : 76950285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311258656773636097",
  "geo" : { },
  "id_str" : "311267873517600768",
  "in_reply_to_user_id" : 22560761,
  "text" : "@caebling agreed. im a little uncomfortable w all the gung-ho kill mentality (reminds me of burning witches) @anthxeria",
  "id" : 311267873517600768,
  "in_reply_to_status_id" : 311258656773636097,
  "created_at" : "2013-03-12 00:10:18 +0000",
  "in_reply_to_screen_name" : "caebling",
  "in_reply_to_user_id_str" : "22560761",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/clml9KLSpt",
      "expanded_url" : "http:\/\/wp.me\/p372Ye-3V",
      "display_url" : "wp.me\/p372Ye-3V"
    } ]
  },
  "geo" : { },
  "id_str" : "311249599870402560",
  "text" : "RT @virtusetveritas: http:\/\/t.co\/clml9KLSpt how I slowly emerged from a culture hell bent on slut shaming and victim blaming.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/clml9KLSpt",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-3V",
        "display_url" : "wp.me\/p372Ye-3V"
      } ]
    },
    "geo" : { },
    "id_str" : "310110606474752000",
    "text" : "http:\/\/t.co\/clml9KLSpt how I slowly emerged from a culture hell bent on slut shaming and victim blaming.",
    "id" : 310110606474752000,
    "created_at" : "2013-03-08 19:31:44 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 311249599870402560,
  "created_at" : "2013-03-11 22:57:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/yLQminXQ1U",
      "expanded_url" : "http:\/\/wp.me\/p372Ye-4c",
      "display_url" : "wp.me\/p372Ye-4c"
    } ]
  },
  "geo" : { },
  "id_str" : "311247421936132099",
  "text" : "RT @virtusetveritas: I will not let myself be silenced by those who think the abused are just \"psychos\" http:\/\/t.co\/yLQminXQ1U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/yLQminXQ1U",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-4c",
        "display_url" : "wp.me\/p372Ye-4c"
      } ]
    },
    "geo" : { },
    "id_str" : "311195446162907136",
    "text" : "I will not let myself be silenced by those who think the abused are just \"psychos\" http:\/\/t.co\/yLQminXQ1U",
    "id" : 311195446162907136,
    "created_at" : "2013-03-11 19:22:30 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 311247421936132099,
  "created_at" : "2013-03-11 22:49:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "corvids",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/fKM51QSyaE",
      "expanded_url" : "http:\/\/youtu.be\/q_hgFLlzIZY",
      "display_url" : "youtu.be\/q_hgFLlzIZY"
    } ]
  },
  "geo" : { },
  "id_str" : "311200286054170625",
  "text" : "watch Betty create tool to get at meat.. very cool! go to 00:42:00 : http:\/\/t.co\/fKM51QSyaE #corvids",
  "id" : 311200286054170625,
  "created_at" : "2013-03-11 19:41:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team HLN",
      "screen_name" : "TeamHLN",
      "indices" : [ 3, 11 ],
      "id_str" : "281590597",
      "id" : 281590597
    }, {
      "name" : "HLN",
      "screen_name" : "HLNTV",
      "indices" : [ 98, 104 ],
      "id_str" : "26282046",
      "id" : 26282046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311189932528001024",
  "text" : "RT @TeamHLN The #JodiArias trial is not in session today, but will resume Wed. 3\/13\/13. Tune into @HLNTV for coverage of the Arias trial.",
  "id" : 311189932528001024,
  "created_at" : "2013-03-11 19:00:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Crossley",
      "screen_name" : "CrossleyIDGuide",
      "indices" : [ 13, 29 ],
      "id_str" : "216788760",
      "id" : 216788760
    }, {
      "name" : "Princeton Nature",
      "screen_name" : "PrincetonNature",
      "indices" : [ 84, 100 ],
      "id_str" : "1112357712",
      "id" : 1112357712
    }, {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "indices" : [ 101, 117 ],
      "id_str" : "20715956",
      "id" : 20715956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/So766oRU3t",
      "expanded_url" : "http:\/\/bit.ly\/13FlSE9",
      "display_url" : "bit.ly\/13FlSE9"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GnImn13b7h",
      "expanded_url" : "http:\/\/blog.press.princeton.edu\/win-a-crossley-id-guide-prize-pack\/",
      "display_url" : "blog.press.princeton.edu\/win-a-crossley\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311169038531297281",
  "text" : "Enter to win @CrossleyIDGuide books &amp; Nikon binoculars: http:\/\/t.co\/So766oRU3t, @PrincetonNature @princetonupress http:\/\/t.co\/GnImn13b7h",
  "id" : 311169038531297281,
  "created_at" : "2013-03-11 17:37:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311129165057359875",
  "geo" : { },
  "id_str" : "311168741524258816",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl oh my goodness.. how nasty! ((hugs)) to you and friend!",
  "id" : 311168741524258816,
  "in_reply_to_status_id" : 311129165057359875,
  "created_at" : "2013-03-11 17:36:23 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drew Johnson",
      "screen_name" : "Drews_Views",
      "indices" : [ 3, 15 ],
      "id_str" : "259970084",
      "id" : 259970084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311115721168023555",
  "text" : "RT @Drews_Views: The post office will throw away 51,000 taxpayer-funded kids' books in TN b\/c of a heartless new rule:\nhttp:\/\/t.co\/Eq8Bs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Books from Birth",
        "screen_name" : "TNImagination",
        "indices" : [ 125, 139 ],
        "id_str" : "106477330",
        "id" : 106477330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/Eq8BsURYAZ",
        "expanded_url" : "http:\/\/www.timesfreepress.com\/news\/2013\/mar\/10\/usps-wrong-to-destroy-childrens-books\/?opinionfreepress",
        "display_url" : "timesfreepress.com\/news\/2013\/mar\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "311112782680571904",
    "text" : "The post office will throw away 51,000 taxpayer-funded kids' books in TN b\/c of a heartless new rule:\nhttp:\/\/t.co\/Eq8BsURYAZ @TNImagination",
    "id" : 311112782680571904,
    "created_at" : "2013-03-11 13:54:02 +0000",
    "user" : {
      "name" : "Drew Johnson",
      "screen_name" : "Drews_Views",
      "protected" : false,
      "id_str" : "259970084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628981401\/5d1b465a630969d055899cab61360e0b_normal.jpeg",
      "id" : 259970084,
      "verified" : false
    }
  },
  "id" : 311115721168023555,
  "created_at" : "2013-03-11 14:05:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "indices" : [ 3, 15 ],
      "id_str" : "406759668",
      "id" : 406759668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311112481307230209",
  "text" : "RT @yoursMukund: Its all illusion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311111899444043777",
    "text" : "Its all illusion",
    "id" : 311111899444043777,
    "created_at" : "2013-03-11 13:50:31 +0000",
    "user" : {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "protected" : false,
      "id_str" : "406759668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000454898275\/fc674ec400b510e4ab53f191238a2664_normal.jpeg",
      "id" : 406759668,
      "verified" : false
    }
  },
  "id" : 311112481307230209,
  "created_at" : "2013-03-11 13:52:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311108791540252672",
  "geo" : { },
  "id_str" : "311111745030737920",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl what??",
  "id" : 311111745030737920,
  "in_reply_to_status_id" : 311108791540252672,
  "created_at" : "2013-03-11 13:49:54 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Conniff",
      "screen_name" : "FrankConniff",
      "indices" : [ 3, 16 ],
      "id_str" : "34556109",
      "id" : 34556109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310918253721575424",
  "text" : "RT @FrankConniff: Paul Ryan's health plan gives everyone the right to choose the exact kind of slow agonizing death that best suits them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310917404253364224",
    "text" : "Paul Ryan's health plan gives everyone the right to choose the exact kind of slow agonizing death that best suits them.",
    "id" : 310917404253364224,
    "created_at" : "2013-03-11 00:57:40 +0000",
    "user" : {
      "name" : "Frank Conniff",
      "screen_name" : "FrankConniff",
      "protected" : false,
      "id_str" : "34556109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765427793777815552\/v0LbA662_normal.jpg",
      "id" : 34556109,
      "verified" : false
    }
  },
  "id" : 310918253721575424,
  "created_at" : "2013-03-11 01:01:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "^^vallli^^64^^",
      "screen_name" : "Farrinna64",
      "indices" : [ 0, 11 ],
      "id_str" : "37856282",
      "id" : 37856282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310892674645372929",
  "geo" : { },
  "id_str" : "310896401024438272",
  "in_reply_to_user_id" : 37856282,
  "text" : "@Farrinna64 im not sure but i think i heard horn say its common to see some hesitation marks (but cld b wrong..been watching way too much!",
  "id" : 310896401024438272,
  "in_reply_to_status_id" : 310892674645372929,
  "created_at" : "2013-03-10 23:34:12 +0000",
  "in_reply_to_screen_name" : "Farrinna64",
  "in_reply_to_user_id_str" : "37856282",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "^^vallli^^64^^",
      "screen_name" : "Farrinna64",
      "indices" : [ 0, 11 ],
      "id_str" : "37856282",
      "id" : 37856282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310892674645372929",
  "geo" : { },
  "id_str" : "310895873238380544",
  "in_reply_to_user_id" : 37856282,
  "text" : "@Farrinna64 i guess ive watched enough crime shows.. the way he was killed was very personal. lots of rage involved.",
  "id" : 310895873238380544,
  "in_reply_to_status_id" : 310892674645372929,
  "created_at" : "2013-03-10 23:32:07 +0000",
  "in_reply_to_screen_name" : "Farrinna64",
  "in_reply_to_user_id_str" : "37856282",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310892499994554368",
  "geo" : { },
  "id_str" : "310895111691177985",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields got mine today. thought it would be another week.",
  "id" : 310895111691177985,
  "in_reply_to_status_id" : 310892499994554368,
  "created_at" : "2013-03-10 23:29:05 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310891710156795904",
  "text" : "there were NO hesitation cuts re: his cut throat.. who cuts throats? assassin or someone very, very ANGRY. #jodiarias",
  "id" : 310891710156795904,
  "created_at" : "2013-03-10 23:15:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310887210503254017",
  "text" : "makes sense to me that #jodiarias used knife 1st .. she was ANGRY w him! she wanted him to feel how she felt (stab in back,break heart)",
  "id" : 310887210503254017,
  "created_at" : "2013-03-10 22:57:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310886775436480512",
  "text" : "kevin horn says gunshot would have incapacitated him so gunshot after defense wounds yet some ppl think he was shot 1st #jodiarias",
  "id" : 310886775436480512,
  "created_at" : "2013-03-10 22:55:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310859068480815104",
  "geo" : { },
  "id_str" : "310860103173668864",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i forgive you for not tweeting me, silly child.. ; )",
  "id" : 310860103173668864,
  "in_reply_to_status_id" : 310859068480815104,
  "created_at" : "2013-03-10 21:09:58 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Crossley",
      "screen_name" : "CrossleyIDGuide",
      "indices" : [ 13, 29 ],
      "id_str" : "216788760",
      "id" : 216788760
    }, {
      "name" : "Princeton Nature",
      "screen_name" : "PrincetonNature",
      "indices" : [ 84, 100 ],
      "id_str" : "1112357712",
      "id" : 1112357712
    }, {
      "name" : "Princeton Univ Press",
      "screen_name" : "PrincetonUPress",
      "indices" : [ 101, 117 ],
      "id_str" : "20715956",
      "id" : 20715956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/So766oRU3t",
      "expanded_url" : "http:\/\/bit.ly\/13FlSE9",
      "display_url" : "bit.ly\/13FlSE9"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GnImn13b7h",
      "expanded_url" : "http:\/\/blog.press.princeton.edu\/win-a-crossley-id-guide-prize-pack\/",
      "display_url" : "blog.press.princeton.edu\/win-a-crossley\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310857371767406593",
  "text" : "Enter to win @CrossleyIDGuide books &amp; Nikon binoculars: http:\/\/t.co\/So766oRU3t, @PrincetonNature @princetonupress http:\/\/t.co\/GnImn13b7h",
  "id" : 310857371767406593,
  "created_at" : "2013-03-10 20:59:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 3, 10 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310853780554002432",
  "text" : "RT @hsofia: Just think for one little minute before we overcurriculinate (not a real word) our kids into illiteracy anymore than we alre ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310845417334120448",
    "text" : "Just think for one little minute before we overcurriculinate (not a real word) our kids into illiteracy anymore than we already have.",
    "id" : 310845417334120448,
    "created_at" : "2013-03-10 20:11:37 +0000",
    "user" : {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "protected" : false,
      "id_str" : "14372614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779574462656020484\/ZaVzAtJD_normal.jpg",
      "id" : 14372614,
      "verified" : false
    }
  },
  "id" : 310853780554002432,
  "created_at" : "2013-03-10 20:44:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 3, 10 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310853757338533888",
  "text" : "RT @hsofia: People used to learn to read w\/ just a Bible on hand and they still read and wrote 10x better than most kids today so let's  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310845240963641345",
    "text" : "People used to learn to read w\/ just a Bible on hand and they still read and wrote 10x better than most kids today so let's think abt that.",
    "id" : 310845240963641345,
    "created_at" : "2013-03-10 20:10:55 +0000",
    "user" : {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "protected" : false,
      "id_str" : "14372614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779574462656020484\/ZaVzAtJD_normal.jpg",
      "id" : 14372614,
      "verified" : false
    }
  },
  "id" : 310853757338533888,
  "created_at" : "2013-03-10 20:44:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 0, 7 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310845240963641345",
  "geo" : { },
  "id_str" : "310853698093985792",
  "in_reply_to_user_id" : 14372614,
  "text" : "@hsofia they also had more time to play and be kids..",
  "id" : 310853698093985792,
  "in_reply_to_status_id" : 310845240963641345,
  "created_at" : "2013-03-10 20:44:31 +0000",
  "in_reply_to_screen_name" : "hsofia",
  "in_reply_to_user_id_str" : "14372614",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310839500400119808",
  "text" : "by the grace of god, i was surrounded by good ppl and able to bring myself up out of that dark mire.",
  "id" : 310839500400119808,
  "created_at" : "2013-03-10 19:48:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310838916615913472",
  "text" : "as a teen, i wanted someone to save me.. save me from myself. took me a LONG time to realize i had to \"save\" myself..",
  "id" : 310838916615913472,
  "created_at" : "2013-03-10 19:45:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy James",
      "screen_name" : "amillee",
      "indices" : [ 0, 8 ],
      "id_str" : "32020761",
      "id" : 32020761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310835835861880832",
  "geo" : { },
  "id_str" : "310836752376033281",
  "in_reply_to_user_id" : 32020761,
  "text" : "@amillee i think she is aware of her difficulty w ppl (something i know of within myself)",
  "id" : 310836752376033281,
  "in_reply_to_status_id" : 310835835861880832,
  "created_at" : "2013-03-10 19:37:11 +0000",
  "in_reply_to_screen_name" : "amillee",
  "in_reply_to_user_id_str" : "32020761",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310828166572830720",
  "geo" : { },
  "id_str" : "310836032826388480",
  "in_reply_to_user_id" : 173892856,
  "text" : "real nice... o-O RT @CzarofCzarcasm The ideal weight of a Liberal - about 3 lbs, including the Urn.",
  "id" : 310836032826388480,
  "in_reply_to_status_id" : 310828166572830720,
  "created_at" : "2013-03-10 19:34:19 +0000",
  "in_reply_to_screen_name" : "JihadOnAmerica",
  "in_reply_to_user_id_str" : "173892856",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310835463315410945",
  "text" : "becuz she discovered mimi had no interest.. she could have still turned travis around (in her mind) IMHO #jodiarias",
  "id" : 310835463315410945,
  "created_at" : "2013-03-10 19:32:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310835106107518976",
  "text" : "also.. she mentions being remorseful for his death (to detective) .. (IMHO: becuz she discovered mimi had no interest in travis) #jodiarias",
  "id" : 310835106107518976,
  "created_at" : "2013-03-10 19:30:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310834521106948096",
  "text" : "interesting how she asks detective What it is about her that makes him see her as guilty #jodiarias",
  "id" : 310834521106948096,
  "created_at" : "2013-03-10 19:28:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrat2",
      "screen_name" : "martrat2",
      "indices" : [ 0, 9 ],
      "id_str" : "1137582546",
      "id" : 1137582546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310819187289370624",
  "geo" : { },
  "id_str" : "310820177061240832",
  "in_reply_to_user_id" : 1137582546,
  "text" : "@martrat2 yes.. agreed. didnt like vid saying he led her on.. blahblah. she knew status of relationship.",
  "id" : 310820177061240832,
  "in_reply_to_status_id" : 310819187289370624,
  "created_at" : "2013-03-10 18:31:19 +0000",
  "in_reply_to_screen_name" : "martrat2",
  "in_reply_to_user_id_str" : "1137582546",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mrat2",
      "screen_name" : "martrat2",
      "indices" : [ 0, 9 ],
      "id_str" : "1137582546",
      "id" : 1137582546
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310804481178742784",
  "geo" : { },
  "id_str" : "310817067345530880",
  "in_reply_to_user_id" : 1137582546,
  "text" : "@martrat2 \"he was still alive\" haunting.. i do disagree w video stressing she gave up everything for him (in her mind, tho, yes)",
  "id" : 310817067345530880,
  "in_reply_to_status_id" : 310804481178742784,
  "created_at" : "2013-03-10 18:18:58 +0000",
  "in_reply_to_screen_name" : "martrat2",
  "in_reply_to_user_id_str" : "1137582546",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Bertram",
      "screen_name" : "GpkGary",
      "indices" : [ 0, 8 ],
      "id_str" : "1230484940",
      "id" : 1230484940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310802112181313537",
  "geo" : { },
  "id_str" : "310812230910349314",
  "in_reply_to_user_id" : 1230484940,
  "text" : "@GpkGary huh.. still why pick it up while chase or carrying body? Michael Melendez testified camera up about 2-3 feet for 1 of the pics.",
  "id" : 310812230910349314,
  "in_reply_to_status_id" : 310802112181313537,
  "created_at" : "2013-03-10 17:59:45 +0000",
  "in_reply_to_screen_name" : "GpkGary",
  "in_reply_to_user_id_str" : "1230484940",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathpenalty",
      "indices" : [ 30, 43 ]
    }, {
      "text" : "jodiarias",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310803583325065218",
  "text" : "she's guilty but i am against #deathpenalty #jodiarias",
  "id" : 310803583325065218,
  "created_at" : "2013-03-10 17:25:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paperwhite",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310802143995117569",
  "geo" : { },
  "id_str" : "310802874101821441",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist love my kindle #paperwhite .. also have kindle 3g\/wifi",
  "id" : 310802874101821441,
  "in_reply_to_status_id" : 310802143995117569,
  "created_at" : "2013-03-10 17:22:34 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310801962125885441",
  "text" : "i wish they could do hypnotherapy on her to get the story of sequence of events #jodiarias",
  "id" : 310801962125885441,
  "created_at" : "2013-03-10 17:18:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310801697083641856",
  "text" : "how\/why does she get the camera back around her neck after dropping it (which she says begins fight for life) #jodiarias",
  "id" : 310801697083641856,
  "created_at" : "2013-03-10 17:17:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/MpngNfYmYD",
      "expanded_url" : "http:\/\/amzn.to\/ZALDjz",
      "display_url" : "amzn.to\/ZALDjz"
    } ]
  },
  "geo" : { },
  "id_str" : "310601022345195520",
  "text" : "finished Flashy Fiction and Other Insane Tales 2 by Sean Hayden and Jen Wylie http:\/\/t.co\/MpngNfYmYD",
  "id" : 310601022345195520,
  "created_at" : "2013-03-10 04:00:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310575186263035904",
  "text" : "i hate Dr. Pol .. animals die. ugh. (hubby started watching recently)",
  "id" : 310575186263035904,
  "created_at" : "2013-03-10 02:17:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310574847442956288",
  "text" : "RT @nakedpastor: People are weird. I should know because I've been living inside one for many years.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310572060432797696",
    "text" : "People are weird. I should know because I've been living inside one for many years.",
    "id" : 310572060432797696,
    "created_at" : "2013-03-10 02:05:24 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 310574847442956288,
  "created_at" : "2013-03-10 02:16:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "peterjames48",
      "screen_name" : "peterjames48",
      "indices" : [ 3, 16 ],
      "id_str" : "25146223",
      "id" : 25146223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310564634358861824",
  "text" : "RT @peterjames48: Screw it, I'm springing sideways.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310489900040474624",
    "text" : "Screw it, I'm springing sideways.",
    "id" : 310489900040474624,
    "created_at" : "2013-03-09 20:38:55 +0000",
    "user" : {
      "name" : "peterjames48",
      "screen_name" : "peterjames48",
      "protected" : false,
      "id_str" : "25146223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537816920645722112\/-mqSLIXC_normal.jpeg",
      "id" : 25146223,
      "verified" : false
    }
  },
  "id" : 310564634358861824,
  "created_at" : "2013-03-10 01:35:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "somanyquestions",
      "indices" : [ 25, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310440349225086976",
  "text" : "we live in the x-files.. #somanyquestions",
  "id" : 310440349225086976,
  "created_at" : "2013-03-09 17:22:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trace Ahlers",
      "screen_name" : "baristaman",
      "indices" : [ 3, 14 ],
      "id_str" : "23476134",
      "id" : 23476134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DST",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310412299590594560",
  "text" : "RT @baristaman: Changing all of my clocks twice every year is getting very expensive. #DST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DST",
        "indices" : [ 70, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310411087654842368",
    "text" : "Changing all of my clocks twice every year is getting very expensive. #DST",
    "id" : 310411087654842368,
    "created_at" : "2013-03-09 15:25:45 +0000",
    "user" : {
      "name" : "Trace Ahlers",
      "screen_name" : "baristaman",
      "protected" : false,
      "id_str" : "23476134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2908853683\/d29591a855ca5e7ad7b9c5ceaa9dc6eb_normal.png",
      "id" : 23476134,
      "verified" : false
    }
  },
  "id" : 310412299590594560,
  "created_at" : "2013-03-09 15:30:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ETZRlthPa6",
      "expanded_url" : "http:\/\/youtu.be\/Z8MxOfIWlFc",
      "display_url" : "youtu.be\/Z8MxOfIWlFc"
    } ]
  },
  "geo" : { },
  "id_str" : "310396831056146433",
  "text" : "good account of how it may have happened \n- Jodi Arias Killing Timeline http:\/\/t.co\/ETZRlthPa6 #jodiarias",
  "id" : 310396831056146433,
  "created_at" : "2013-03-09 14:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audio Go",
      "screen_name" : "AudioGo",
      "indices" : [ 7, 15 ],
      "id_str" : "3317905519",
      "id" : 3317905519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/WiETJLbhAR",
      "expanded_url" : "http:\/\/via.me\/-abn6w9m",
      "display_url" : "via.me\/-abn6w9m"
    } ]
  },
  "geo" : { },
  "id_str" : "310087481183846401",
  "text" : "Thanks @AudioGO ! I won \"Ed Reardon's Week\" - a BBC comedy http:\/\/t.co\/WiETJLbhAR",
  "id" : 310087481183846401,
  "created_at" : "2013-03-08 17:59:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betsy Dewey",
      "screen_name" : "BetsyDeweyTX",
      "indices" : [ 3, 16 ],
      "id_str" : "302720798",
      "id" : 302720798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310077456449155072",
  "text" : "RT @BetsyDeweyTX: This poor guy literally left to rot in NM prison solitary for two years awaiting DWI trial. How is this possible? http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/J03wtXjdoq",
        "expanded_url" : "http:\/\/abcnews.go.com\/m\/story?id=18677197",
        "display_url" : "abcnews.go.com\/m\/story?id=186\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "310077075572809728",
    "text" : "This poor guy literally left to rot in NM prison solitary for two years awaiting DWI trial. How is this possible? http:\/\/t.co\/J03wtXjdoq",
    "id" : 310077075572809728,
    "created_at" : "2013-03-08 17:18:30 +0000",
    "user" : {
      "name" : "Betsy Dewey",
      "screen_name" : "BetsyDeweyTX",
      "protected" : false,
      "id_str" : "302720798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3198644348\/e84631196962da998e22f720ca7d3a6f_normal.jpeg",
      "id" : 302720798,
      "verified" : false
    }
  },
  "id" : 310077456449155072,
  "created_at" : "2013-03-08 17:20:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/bf6Mj0avxY",
      "expanded_url" : "http:\/\/via.me\/-abls5u0",
      "display_url" : "via.me\/-abls5u0"
    } ]
  },
  "geo" : { },
  "id_str" : "310070121441939457",
  "text" : "Squirrel eating seed he spilled on steps yesterday that is now under snow http:\/\/t.co\/bf6Mj0avxY",
  "id" : 310070121441939457,
  "created_at" : "2013-03-08 16:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    }, {
      "name" : "Denise Lescano",
      "screen_name" : "DeniseLescano",
      "indices" : [ 49, 63 ],
      "id_str" : "59031792",
      "id" : 59031792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310054613673967617",
  "text" : "RT @morsemusings: Form forever changing. &gt; RT @DeniseLescano There is no such thing as death - there is ONLY birth &amp; rebirth - th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Denise Lescano",
        "screen_name" : "DeniseLescano",
        "indices" : [ 31, 45 ],
        "id_str" : "59031792",
        "id" : 59031792
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "310053337024307200",
    "geo" : { },
    "id_str" : "310054228225843200",
    "in_reply_to_user_id" : 59031792,
    "text" : "Form forever changing. &gt; RT @DeniseLescano There is no such thing as death - there is ONLY birth &amp; rebirth - there is only life.",
    "id" : 310054228225843200,
    "in_reply_to_status_id" : 310053337024307200,
    "created_at" : "2013-03-08 15:47:43 +0000",
    "in_reply_to_screen_name" : "DeniseLescano",
    "in_reply_to_user_id_str" : "59031792",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 310054613673967617,
  "created_at" : "2013-03-08 15:49:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310051983333662723",
  "geo" : { },
  "id_str" : "310053288005480448",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 thanks, doll. i was like.. \"i have to wait until wed?\" even hubby is watching w me. he says she is scary.",
  "id" : 310053288005480448,
  "in_reply_to_status_id" : 310051983333662723,
  "created_at" : "2013-03-08 15:43:59 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 3, 16 ],
      "id_str" : "946353775",
      "id" : 946353775
    }, {
      "name" : "Kitty Boodles",
      "screen_name" : "kittyboodles",
      "indices" : [ 19, 32 ],
      "id_str" : "56892702",
      "id" : 56892702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JodiArias",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/DPxpVFF5I5",
      "expanded_url" : "http:\/\/www.superiorcourt.maricopa.gov\/docket\/calendar\/calList.asp?ID=3604&startdate=3\/8\/2013&length=7",
      "display_url" : "superiorcourt.maricopa.gov\/docket\/calenda\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310051784917913600",
  "text" : "RT @MimiMadeira1: \"@kittyboodles: #JodiArias - Court Calender changed - Court now Tue 3\/12  Wed 3\/13  Thu 3\/14\nhttp:\/\/t.co\/DPxpVFF5I5\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kitty Boodles",
        "screen_name" : "kittyboodles",
        "indices" : [ 1, 14 ],
        "id_str" : "56892702",
        "id" : 56892702
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JodiArias",
        "indices" : [ 16, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/DPxpVFF5I5",
        "expanded_url" : "http:\/\/www.superiorcourt.maricopa.gov\/docket\/calendar\/calList.asp?ID=3604&startdate=3\/8\/2013&length=7",
        "display_url" : "superiorcourt.maricopa.gov\/docket\/calenda\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "310051513919737856",
    "text" : "\"@kittyboodles: #JodiArias - Court Calender changed - Court now Tue 3\/12  Wed 3\/13  Thu 3\/14\nhttp:\/\/t.co\/DPxpVFF5I5\"",
    "id" : 310051513919737856,
    "created_at" : "2013-03-08 15:36:56 +0000",
    "user" : {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "protected" : false,
      "id_str" : "946353775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761260545123098625\/DPofHF1j_normal.jpg",
      "id" : 946353775,
      "verified" : false
    }
  },
  "id" : 310051784917913600,
  "created_at" : "2013-03-08 15:38:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310050728112701441",
  "geo" : { },
  "id_str" : "310051202127761408",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 to clarify, so they'll be back next tues instead of wed?",
  "id" : 310051202127761408,
  "in_reply_to_status_id" : 310050728112701441,
  "created_at" : "2013-03-08 15:35:41 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rita Toews",
      "screen_name" : "ebookweek",
      "indices" : [ 3, 13 ],
      "id_str" : "116555630",
      "id" : 116555630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebookweek",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/jPKyoraYaC",
      "expanded_url" : "https:\/\/www.facebook.com\/pages\/E-Ink\/101803536579485?id=101803536579485&sk=app_311884432248556",
      "display_url" : "facebook.com\/pages\/E-Ink\/10\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310045784202702848",
  "text" : "RT @ebookweek: Enter to win an e-reader for Read an E-book Week   https:\/\/t.co\/jPKyoraYaC  #ebookweek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebookweek",
        "indices" : [ 76, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/jPKyoraYaC",
        "expanded_url" : "https:\/\/www.facebook.com\/pages\/E-Ink\/101803536579485?id=101803536579485&sk=app_311884432248556",
        "display_url" : "facebook.com\/pages\/E-Ink\/10\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "310040782272860161",
    "text" : "Enter to win an e-reader for Read an E-book Week   https:\/\/t.co\/jPKyoraYaC  #ebookweek",
    "id" : 310040782272860161,
    "created_at" : "2013-03-08 14:54:17 +0000",
    "user" : {
      "name" : "Rita Toews",
      "screen_name" : "ebookweek",
      "protected" : false,
      "id_str" : "116555630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1249933705\/readerandbooks_normal.jpg",
      "id" : 116555630,
      "verified" : false
    }
  },
  "id" : 310045784202702848,
  "created_at" : "2013-03-08 15:14:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 19, 26 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/1SUgExJOol",
      "expanded_url" : "http:\/\/bit.ly\/AmITvG",
      "display_url" : "bit.ly\/AmITvG"
    } ]
  },
  "in_reply_to_status_id_str" : "310042574704476160",
  "geo" : { },
  "id_str" : "310045273156112385",
  "in_reply_to_user_id" : 12023102,
  "text" : "posse butt! : ) RT @screek I broke one of my main rules! \"Walking Away (Opossum)\" http:\/\/t.co\/1SUgExJOol",
  "id" : 310045273156112385,
  "in_reply_to_status_id" : 310042574704476160,
  "created_at" : "2013-03-08 15:12:08 +0000",
  "in_reply_to_screen_name" : "screek",
  "in_reply_to_user_id_str" : "12023102",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309985324023566336",
  "geo" : { },
  "id_str" : "310044393333723136",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields i think amazon will get a lot of flack about today's \"kid's\" daily deal. reading reviews.. it's def more adult.",
  "id" : 310044393333723136,
  "in_reply_to_status_id" : 309985324023566336,
  "created_at" : "2013-03-08 15:08:38 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/hphPuNzQPF",
      "expanded_url" : "http:\/\/amzn.to\/dF51dA",
      "display_url" : "amzn.to\/dF51dA"
    } ]
  },
  "geo" : { },
  "id_str" : "309867754788360192",
  "text" : "finished The Orthodox Heretic: And Other Impossible Tales by Peter Rollins http:\/\/t.co\/hphPuNzQPF",
  "id" : 309867754788360192,
  "created_at" : "2013-03-08 03:26:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "johnqpubliq",
      "screen_name" : "johnqpubliq",
      "indices" : [ 85, 97 ],
      "id_str" : "34769848",
      "id" : 34769848
    }, {
      "name" : "Melissa ",
      "screen_name" : "Mel_In_Canada",
      "indices" : [ 98, 112 ],
      "id_str" : "2834719337",
      "id" : 2834719337
    }, {
      "name" : "Jeffy B",
      "screen_name" : "jeffyb75",
      "indices" : [ 113, 122 ],
      "id_str" : "152643260",
      "id" : 152643260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309800296178130944",
  "geo" : { },
  "id_str" : "309801489990291457",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool i would say no proof but there are various experiences to suggest it @johnqpubliq @Mel_in_Canada @jeffyb75",
  "id" : 309801489990291457,
  "in_reply_to_status_id" : 309800296178130944,
  "created_at" : "2013-03-07 23:03:25 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/N6lvd6zu8U",
      "expanded_url" : "http:\/\/shar.es\/jS8Ou",
      "display_url" : "shar.es\/jS8Ou"
    } ]
  },
  "geo" : { },
  "id_str" : "309793838044676096",
  "text" : "A Christianity to make Satan proud http:\/\/t.co\/N6lvd6zu8U",
  "id" : 309793838044676096,
  "created_at" : "2013-03-07 22:33:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe O'Neill",
      "screen_name" : "KidsAreHeroes",
      "indices" : [ 3, 17 ],
      "id_str" : "18345963",
      "id" : 18345963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/jGjzzrsAOX",
      "expanded_url" : "http:\/\/instagr.am\/p\/WkZFJtpd4p\/",
      "display_url" : "instagr.am\/p\/WkZFJtpd4p\/"
    } ]
  },
  "geo" : { },
  "id_str" : "309753914868240384",
  "text" : "RT @KidsAreHeroes: BEST. . .OFFICE. . .MATE. . .EVER!! http:\/\/t.co\/jGjzzrsAOX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/jGjzzrsAOX",
        "expanded_url" : "http:\/\/instagr.am\/p\/WkZFJtpd4p\/",
        "display_url" : "instagr.am\/p\/WkZFJtpd4p\/"
      } ]
    },
    "geo" : { },
    "id_str" : "309752955467350016",
    "text" : "BEST. . .OFFICE. . .MATE. . .EVER!! http:\/\/t.co\/jGjzzrsAOX",
    "id" : 309752955467350016,
    "created_at" : "2013-03-07 19:50:34 +0000",
    "user" : {
      "name" : "Gabe O'Neill",
      "screen_name" : "KidsAreHeroes",
      "protected" : false,
      "id_str" : "18345963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595297716810440704\/dwL2J49R_normal.jpg",
      "id" : 18345963,
      "verified" : false
    }
  },
  "id" : 309753914868240384,
  "created_at" : "2013-03-07 19:54:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309747999045726209",
  "text" : "all this old boyfriend stuff is conjecture, speculation.. no proof. where are the character witnesses?? hmm.. #jodiarias",
  "id" : 309747999045726209,
  "created_at" : "2013-03-07 19:30:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309740548837752832",
  "geo" : { },
  "id_str" : "309741410423283712",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses adorable!",
  "id" : 309741410423283712,
  "in_reply_to_status_id" : 309740548837752832,
  "created_at" : "2013-03-07 19:04:41 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "indices" : [ 3, 14 ],
      "id_str" : "21497211",
      "id" : 21497211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/g1CR5HShEY",
      "expanded_url" : "http:\/\/bit.ly\/15AhWD8",
      "display_url" : "bit.ly\/15AhWD8"
    } ]
  },
  "geo" : { },
  "id_str" : "309740441648123904",
  "text" : "RT @jedwards06: Just watched the greatest flash mob ever. Big Bang Theory cast and crew. Awesome. http:\/\/t.co\/g1CR5HShEY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/g1CR5HShEY",
        "expanded_url" : "http:\/\/bit.ly\/15AhWD8",
        "display_url" : "bit.ly\/15AhWD8"
      } ]
    },
    "geo" : { },
    "id_str" : "309739091157729280",
    "text" : "Just watched the greatest flash mob ever. Big Bang Theory cast and crew. Awesome. http:\/\/t.co\/g1CR5HShEY",
    "id" : 309739091157729280,
    "created_at" : "2013-03-07 18:55:28 +0000",
    "user" : {
      "name" : "Jonathon Edwards",
      "screen_name" : "jedwards06",
      "protected" : true,
      "id_str" : "21497211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000439787062\/5787c041baa171cae2de77bcf3d3a28e_normal.png",
      "id" : 21497211,
      "verified" : false
    }
  },
  "id" : 309740441648123904,
  "created_at" : "2013-03-07 19:00:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "empty cages",
      "screen_name" : "emptycages",
      "indices" : [ 3, 14 ],
      "id_str" : "20556692",
      "id" : 20556692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309735946574778370",
  "text" : "RT @emptycages: Every time we receive a complaint about a raccoon, opossum or other animal living his or her life in a urban backyard ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/emptycages\/status\/309725676087427072\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/eOYQF8hHQo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BExd3IWCQAAf8P7.jpg",
        "id_str" : "309725676095815680",
        "id" : 309725676095815680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BExd3IWCQAAf8P7.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/eOYQF8hHQo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309725676087427072",
    "text" : "Every time we receive a complaint about a raccoon, opossum or other animal living his or her life in a urban backyard http:\/\/t.co\/eOYQF8hHQo",
    "id" : 309725676087427072,
    "created_at" : "2013-03-07 18:02:10 +0000",
    "user" : {
      "name" : "empty cages",
      "screen_name" : "emptycages",
      "protected" : false,
      "id_str" : "20556692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/111357640\/eccbirdicon_normal.jpg",
      "id" : 20556692,
      "verified" : false
    }
  },
  "id" : 309735946574778370,
  "created_at" : "2013-03-07 18:42:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309720764721029120",
  "text" : "usually i tend to feel some compassion for defendant .. but #jodiarias .. i feel blank. i think cuz i cant find her perception.",
  "id" : 309720764721029120,
  "created_at" : "2013-03-07 17:42:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "indices" : [ 3, 19 ],
      "id_str" : "105926473",
      "id" : 105926473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/l0eqJ2QXv4",
      "expanded_url" : "http:\/\/tinyurl.com\/ap2543q",
      "display_url" : "tinyurl.com\/ap2543q"
    } ]
  },
  "geo" : { },
  "id_str" : "309714997527838720",
  "text" : "RT @consciousbridge: The Health Care Debate--Free Market Choices vs. Basic Human Right? http:\/\/t.co\/l0eqJ2QXv4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/l0eqJ2QXv4",
        "expanded_url" : "http:\/\/tinyurl.com\/ap2543q",
        "display_url" : "tinyurl.com\/ap2543q"
      } ]
    },
    "geo" : { },
    "id_str" : "309703621715562497",
    "text" : "The Health Care Debate--Free Market Choices vs. Basic Human Right? http:\/\/t.co\/l0eqJ2QXv4",
    "id" : 309703621715562497,
    "created_at" : "2013-03-07 16:34:32 +0000",
    "user" : {
      "name" : "Mark Gilbert",
      "screen_name" : "consciousbridge",
      "protected" : false,
      "id_str" : "105926473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1200394907\/172_normal.JPG",
      "id" : 105926473,
      "verified" : false
    }
  },
  "id" : 309714997527838720,
  "created_at" : "2013-03-07 17:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Martinez Diaz",
      "screen_name" : "josefmtz",
      "indices" : [ 3, 12 ],
      "id_str" : "122210008",
      "id" : 122210008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/umZh71ZwF6",
      "expanded_url" : "http:\/\/www.fair.org\/blog\/2013\/03\/06\/ap-chavez-wasted-his-money-on-healthcare-when-he-could-have-built-gigantic-skyscrapers\/",
      "display_url" : "fair.org\/blog\/2013\/03\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309714427047989248",
  "text" : "RT @josefmtz: AP: Chavez Wasted His Money on Healthcare When He Could Have Built Gigantic Skyscrapers http:\/\/t.co\/umZh71ZwF6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/umZh71ZwF6",
        "expanded_url" : "http:\/\/www.fair.org\/blog\/2013\/03\/06\/ap-chavez-wasted-his-money-on-healthcare-when-he-could-have-built-gigantic-skyscrapers\/",
        "display_url" : "fair.org\/blog\/2013\/03\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "309467603276005376",
    "text" : "AP: Chavez Wasted His Money on Healthcare When He Could Have Built Gigantic Skyscrapers http:\/\/t.co\/umZh71ZwF6",
    "id" : 309467603276005376,
    "created_at" : "2013-03-07 00:56:40 +0000",
    "user" : {
      "name" : "Jose Martinez Diaz",
      "screen_name" : "josefmtz",
      "protected" : false,
      "id_str" : "122210008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747260091\/yo_2_normal.jpg",
      "id" : 122210008,
      "verified" : false
    }
  },
  "id" : 309714427047989248,
  "created_at" : "2013-03-07 17:17:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309708698517905408",
  "geo" : { },
  "id_str" : "309713937891483650",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits YES!!",
  "id" : 309713937891483650,
  "in_reply_to_status_id" : 309708698517905408,
  "created_at" : "2013-03-07 17:15:31 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Weinman",
      "screen_name" : "sarahw",
      "indices" : [ 3, 10 ],
      "id_str" : "286703",
      "id" : 286703
    }, {
      "name" : "Annie Lowrey",
      "screen_name" : "AnnieLowrey",
      "indices" : [ 29, 41 ],
      "id_str" : "37281592",
      "id" : 37281592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309712594145533953",
  "text" : "RT @sarahw: What the EFF. RT @AnnieLowrey Homeless mother who enrolled her son in the wrong school district gets 12 years. http:\/\/t.co\/M ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twhirl.org\" rel=\"nofollow\"\u003ESeesmic twhirl\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Annie Lowrey",
        "screen_name" : "AnnieLowrey",
        "indices" : [ 17, 29 ],
        "id_str" : "37281592",
        "id" : 37281592
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/MU02eKDLgk",
        "expanded_url" : "http:\/\/bit.ly\/xyVlnl",
        "display_url" : "bit.ly\/xyVlnl"
      } ]
    },
    "geo" : { },
    "id_str" : "309710266663313409",
    "text" : "What the EFF. RT @AnnieLowrey Homeless mother who enrolled her son in the wrong school district gets 12 years. http:\/\/t.co\/MU02eKDLgk",
    "id" : 309710266663313409,
    "created_at" : "2013-03-07 17:00:56 +0000",
    "user" : {
      "name" : "Sarah Weinman",
      "screen_name" : "sarahw",
      "protected" : false,
      "id_str" : "286703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776458540932227072\/LrzxgXLG_normal.jpg",
      "id" : 286703,
      "verified" : true
    }
  },
  "id" : 309712594145533953,
  "created_at" : "2013-03-07 17:10:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Paul Turner",
      "screen_name" : "JesusNeedsNewPR",
      "indices" : [ 3, 19 ],
      "id_str" : "727580030084251648",
      "id" : 727580030084251648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Y87rSwz3q9",
      "expanded_url" : "http:\/\/www.matthewpaulturner.com\/blog\/2013\/3\/7\/about-rob-bells-new-book-my-thoughts-so-far",
      "display_url" : "matthewpaulturner.com\/blog\/2013\/3\/7\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309697232268058624",
  "text" : "RT @JesusNeedsNewPR: Rob Bell's new book! My thoughts so far... http:\/\/t.co\/Y87rSwz3q9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/Y87rSwz3q9",
        "expanded_url" : "http:\/\/www.matthewpaulturner.com\/blog\/2013\/3\/7\/about-rob-bells-new-book-my-thoughts-so-far",
        "display_url" : "matthewpaulturner.com\/blog\/2013\/3\/7\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "309690662150873088",
    "text" : "Rob Bell's new book! My thoughts so far... http:\/\/t.co\/Y87rSwz3q9",
    "id" : 309690662150873088,
    "created_at" : "2013-03-07 15:43:02 +0000",
    "user" : {
      "name" : "Matthew Paul Turner",
      "screen_name" : "HeyMPT",
      "protected" : false,
      "id_str" : "10206812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749619882552098816\/HgjwUHtr_normal.jpg",
      "id" : 10206812,
      "verified" : false
    }
  },
  "id" : 309697232268058624,
  "created_at" : "2013-03-07 16:09:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healthcare-NOW!",
      "screen_name" : "HCNow",
      "indices" : [ 3, 9 ],
      "id_str" : "197524784",
      "id" : 197524784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/TffHXFMtJU",
      "expanded_url" : "http:\/\/www.healthcare-now.org\/single-payer-would-save-pa-17-billion-annually",
      "display_url" : "healthcare-now.org\/single-payer-w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309688890229395457",
  "text" : "RT @HCNow: Single-Payer Would Save PA $17 Billion Annually - http:\/\/t.co\/TffHXFMtJU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/TffHXFMtJU",
        "expanded_url" : "http:\/\/www.healthcare-now.org\/single-payer-would-save-pa-17-billion-annually",
        "display_url" : "healthcare-now.org\/single-payer-w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "309686762895179776",
    "text" : "Single-Payer Would Save PA $17 Billion Annually - http:\/\/t.co\/TffHXFMtJU",
    "id" : 309686762895179776,
    "created_at" : "2013-03-07 15:27:32 +0000",
    "user" : {
      "name" : "Healthcare-NOW!",
      "screen_name" : "HCNow",
      "protected" : false,
      "id_str" : "197524784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722486189656313856\/Eo5vEDe5_normal.jpg",
      "id" : 197524784,
      "verified" : false
    }
  },
  "id" : 309688890229395457,
  "created_at" : "2013-03-07 15:35:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309430157943386113",
  "text" : "she over-killed... she cant get around that. #jodiarias",
  "id" : 309430157943386113,
  "created_at" : "2013-03-06 22:27:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309399415653822464",
  "text" : "RT @derekrootboy: Hey, you. Yes you. The one who is reading this tweet. I need you to know that The Truman Show is real. And YOU are Tru ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309394528194920448",
    "text" : "Hey, you. Yes you. The one who is reading this tweet. I need you to know that The Truman Show is real. And YOU are Truman! I gotta go now :)",
    "id" : 309394528194920448,
    "created_at" : "2013-03-06 20:06:18 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 309399415653822464,
  "created_at" : "2013-03-06 20:25:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/1h7Q0bn5Ep",
      "expanded_url" : "http:\/\/amzn.to\/RveYrS",
      "display_url" : "amzn.to\/RveYrS"
    } ]
  },
  "geo" : { },
  "id_str" : "309376383593902082",
  "text" : "finished BLUFF by Lenore Skomal http:\/\/t.co\/1h7Q0bn5Ep",
  "id" : 309376383593902082,
  "created_at" : "2013-03-06 18:54:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309360621747580928",
  "text" : "@AnarchistKevin that poor chicken told him off!",
  "id" : 309360621747580928,
  "created_at" : "2013-03-06 17:51:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309352499071037440",
  "geo" : { },
  "id_str" : "309354838309875713",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy glad the police were decent to you",
  "id" : 309354838309875713,
  "in_reply_to_status_id" : 309352499071037440,
  "created_at" : "2013-03-06 17:28:35 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309352472256839680",
  "text" : "@Skeptical_Lady oh my, you poor thing. bad enough to be sick but additionally have strangers around... blah.",
  "id" : 309352472256839680,
  "created_at" : "2013-03-06 17:19:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309352256090828800",
  "text" : "@Skeptical_Lady very wise : )",
  "id" : 309352256090828800,
  "created_at" : "2013-03-06 17:18:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bean",
      "screen_name" : "IMBeanz",
      "indices" : [ 3, 11 ],
      "id_str" : "205562164",
      "id" : 205562164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309329988556038144",
  "text" : "RT @IMBeanz: Maybe all the broken people are really not broken and all the normal people are the ones who are really broken but they jus ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309325800421851138",
    "text" : "Maybe all the broken people are really not broken and all the normal people are the ones who are really broken but they just don\u2019t know it.",
    "id" : 309325800421851138,
    "created_at" : "2013-03-06 15:33:12 +0000",
    "user" : {
      "name" : "Bean",
      "screen_name" : "IMBeanz",
      "protected" : false,
      "id_str" : "205562164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572561066527363073\/iMcuBrfX_normal.jpeg",
      "id" : 205562164,
      "verified" : false
    }
  },
  "id" : 309329988556038144,
  "created_at" : "2013-03-06 15:49:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "petpeeve",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309329905986985984",
  "text" : "i do not like it when they put movie covers on books. #petpeeve",
  "id" : 309329905986985984,
  "created_at" : "2013-03-06 15:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/iuy42dgdRi",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/03\/04\/health\/surrogacy-kelley-legal-battle\/index.html",
      "display_url" : "cnn.com\/2013\/03\/04\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309302721062764545",
  "text" : "Surrogate offered $10,000 to abort baby -  http:\/\/t.co\/iuy42dgdRi",
  "id" : 309302721062764545,
  "created_at" : "2013-03-06 14:01:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Reddin",
      "screen_name" : "HomelessHeretic",
      "indices" : [ 3, 19 ],
      "id_str" : "22151795",
      "id" : 22151795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309123286837649408",
  "text" : "RT @HomelessHeretic: People can help people far greater than any legislation ever will.  Unfortunately, Americans tend to believe the di ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 132, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309121479499464705",
    "text" : "People can help people far greater than any legislation ever will.  Unfortunately, Americans tend to believe the direct opposite.   #fb",
    "id" : 309121479499464705,
    "created_at" : "2013-03-06 02:01:18 +0000",
    "user" : {
      "name" : "Aaron Reddin",
      "screen_name" : "HomelessHeretic",
      "protected" : false,
      "id_str" : "22151795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/706125177323532288\/hFehuqxe_normal.jpg",
      "id" : 22151795,
      "verified" : false
    }
  },
  "id" : 309123286837649408,
  "created_at" : "2013-03-06 02:08:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309103228157579264",
  "geo" : { },
  "id_str" : "309115185275219968",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool all the wars have held us back.. could have had electronic eyes and flying cars by now...",
  "id" : 309115185275219968,
  "in_reply_to_status_id" : 309103228157579264,
  "created_at" : "2013-03-06 01:36:17 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309103876290785280",
  "geo" : { },
  "id_str" : "309114218093899777",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool absolutely, TAF.. nothing wrong w that! @IAAtruth",
  "id" : 309114218093899777,
  "in_reply_to_status_id" : 309103876290785280,
  "created_at" : "2013-03-06 01:32:27 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309044741889196034",
  "text" : "we're doing math on the #jodiarias trial!",
  "id" : 309044741889196034,
  "created_at" : "2013-03-05 20:56:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "indices" : [ 0, 16 ],
      "id_str" : "362487813",
      "id" : 362487813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309040714208129025",
  "geo" : { },
  "id_str" : "309043890487435264",
  "in_reply_to_user_id" : 362487813,
  "text" : "@MysteriousPress woohoo! thank you! will send dm : )",
  "id" : 309043890487435264,
  "in_reply_to_status_id" : 309040714208129025,
  "created_at" : "2013-03-05 20:52:59 +0000",
  "in_reply_to_screen_name" : "MysteriousPress",
  "in_reply_to_user_id_str" : "362487813",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Drunk Bitch ",
      "screen_name" : "DrunkenbitchXO",
      "indices" : [ 3, 18 ],
      "id_str" : "1107725406",
      "id" : 1107725406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309043248960266240",
  "text" : "RT @DrunkenbitchXO: Oh, if guns were illegal no one would have one? Please, tell me more about how nobody can buy drugs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309030863214108673",
    "text" : "Oh, if guns were illegal no one would have one? Please, tell me more about how nobody can buy drugs.",
    "id" : 309030863214108673,
    "created_at" : "2013-03-05 20:01:13 +0000",
    "user" : {
      "name" : "Drunk Bitch ",
      "screen_name" : "DrunkenbitchXO",
      "protected" : false,
      "id_str" : "1107725406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3138855212\/429032ffa1bbcc0680e20ce2b265415a_normal.jpeg",
      "id" : 1107725406,
      "verified" : false
    }
  },
  "id" : 309043248960266240,
  "created_at" : "2013-03-05 20:50:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309027695663124480",
  "text" : "paul ryan is a twat. he needs to go away!",
  "id" : 309027695663124480,
  "created_at" : "2013-03-05 19:48:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309017624606564353",
  "geo" : { },
  "id_str" : "309027329794011136",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 exactly.. my brain is like.. what? lol",
  "id" : 309027329794011136,
  "in_reply_to_status_id" : 309017624606564353,
  "created_at" : "2013-03-05 19:47:11 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "CaptivatingNews",
      "screen_name" : "CaptivatingNews",
      "indices" : [ 18, 34 ],
      "id_str" : "292374563",
      "id" : 292374563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/BvX77qbu2U",
      "expanded_url" : "http:\/\/tinyurl.com\/ao5cg5v",
      "display_url" : "tinyurl.com\/ao5cg5v"
    } ]
  },
  "geo" : { },
  "id_str" : "309026830659248128",
  "text" : "RT @Jamiastar: RT @CaptivatingNews: Paul Ryan Looks to Break an Old Promise With a New Plan to Mess With Medicare http:\/\/t.co\/BvX77qbu2U ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CaptivatingNews",
        "screen_name" : "CaptivatingNews",
        "indices" : [ 3, 19 ],
        "id_str" : "292374563",
        "id" : 292374563
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 123, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/BvX77qbu2U",
        "expanded_url" : "http:\/\/tinyurl.com\/ao5cg5v",
        "display_url" : "tinyurl.com\/ao5cg5v"
      } ]
    },
    "geo" : { },
    "id_str" : "309021205514551296",
    "text" : "RT @CaptivatingNews: Paul Ryan Looks to Break an Old Promise With a New Plan to Mess With Medicare http:\/\/t.co\/BvX77qbu2U  #p2",
    "id" : 309021205514551296,
    "created_at" : "2013-03-05 19:22:51 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 309026830659248128,
  "created_at" : "2013-03-05 19:45:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 29, 42 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/DuGlQKzJGV",
      "expanded_url" : "http:\/\/www.vice.com\/read\/new-york-cops-will-arrest-you-for-carrying-condoms?utm_source=vicetwitterus",
      "display_url" : "vice.com\/read\/new-york-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "309005550421680128",
  "geo" : { },
  "id_str" : "309011750861303808",
  "in_reply_to_user_id" : 279390084,
  "text" : "omg... this is ridiculous RT @YourAnonNews The NYPD will arrest you for carrying condoms http:\/\/t.co\/DuGlQKzJGV",
  "id" : 309011750861303808,
  "in_reply_to_status_id" : 309005550421680128,
  "created_at" : "2013-03-05 18:45:17 +0000",
  "in_reply_to_screen_name" : "YourAnonNews",
  "in_reply_to_user_id_str" : "279390084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "indices" : [ 3, 15 ],
      "id_str" : "19791234",
      "id" : 19791234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/jvc5J2kUEB",
      "expanded_url" : "http:\/\/owl.li\/imuXq",
      "display_url" : "owl.li\/imuXq"
    } ]
  },
  "geo" : { },
  "id_str" : "309011040623030275",
  "text" : "RT @Emperor_Bob: No Baby Formula for Poor Kids? Sequester Cuts Are Tragic Blow to the Poor | Alternet http:\/\/t.co\/jvc5J2kUEB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/jvc5J2kUEB",
        "expanded_url" : "http:\/\/owl.li\/imuXq",
        "display_url" : "owl.li\/imuXq"
      } ]
    },
    "geo" : { },
    "id_str" : "309010465688809472",
    "text" : "No Baby Formula for Poor Kids? Sequester Cuts Are Tragic Blow to the Poor | Alternet http:\/\/t.co\/jvc5J2kUEB",
    "id" : 309010465688809472,
    "created_at" : "2013-03-05 18:40:10 +0000",
    "user" : {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "protected" : false,
      "id_str" : "19791234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3352084632\/6ebf06ce559f48c77c691cb928fc62ab_normal.png",
      "id" : 19791234,
      "verified" : false
    }
  },
  "id" : 309011040623030275,
  "created_at" : "2013-03-05 18:42:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309010914059902977",
  "text" : "perhaps.. if she did not slit his throat, she might have had a chance of success w deceit.. maybe #jodiarias",
  "id" : 309010914059902977,
  "created_at" : "2013-03-05 18:41:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jodiarias",
      "indices" : [ 47, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309009712337268736",
  "text" : "she's all over the place. this trial is crazy. #jodiarias",
  "id" : 309009712337268736,
  "created_at" : "2013-03-05 18:37:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "indices" : [ 3, 19 ],
      "id_str" : "362487813",
      "id" : 362487813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theboyfriend",
      "indices" : [ 64, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309004705252638720",
  "text" : "RT @MysteriousPress: 2 hours left! Reply, RT or use the hashtag #theboyfriend to enter to win a copy of THE BOYFRIEND by Thomas Perry!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "theboyfriend",
        "indices" : [ 43, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309001949339058176",
    "text" : "2 hours left! Reply, RT or use the hashtag #theboyfriend to enter to win a copy of THE BOYFRIEND by Thomas Perry!",
    "id" : 309001949339058176,
    "created_at" : "2013-03-05 18:06:20 +0000",
    "user" : {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "protected" : false,
      "id_str" : "362487813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1514323844\/mysterious_normal.jpg",
      "id" : 362487813,
      "verified" : false
    }
  },
  "id" : 309004705252638720,
  "created_at" : "2013-03-05 18:17:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308994411306557441",
  "text" : "My MIL at bible study today \"and if I have a faith that can move mountains, but have not love, I am nothing.\" 1Cor 13:2 NIV",
  "id" : 308994411306557441,
  "created_at" : "2013-03-05 17:36:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308774243322195968",
  "text" : "RT @JAScribbles: It's a bad idea to sit on your Kindle. Weird things happen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308773920289484800",
    "text" : "It's a bad idea to sit on your Kindle. Weird things happen.",
    "id" : 308773920289484800,
    "created_at" : "2013-03-05 03:00:13 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 308774243322195968,
  "created_at" : "2013-03-05 03:01:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 3, 18 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LoveHonorTruth\/status\/308767748408897538\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/zX6nZMkHea",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEj2oZqCcAAbrw4.jpg",
      "id_str" : "308767748417286144",
      "id" : 308767748417286144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEj2oZqCcAAbrw4.jpg",
      "sizes" : [ {
        "h" : 737,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 557,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 794
      } ],
      "display_url" : "pic.twitter.com\/zX6nZMkHea"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308768606412480513",
  "text" : "RT @LoveHonorTruth: Wrong on so many levels. I can't address it in 140 characters. http:\/\/t.co\/zX6nZMkHea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LoveHonorTruth\/status\/308767748408897538\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/zX6nZMkHea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BEj2oZqCcAAbrw4.jpg",
        "id_str" : "308767748417286144",
        "id" : 308767748417286144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEj2oZqCcAAbrw4.jpg",
        "sizes" : [ {
          "h" : 737,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 557,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 794
        } ],
        "display_url" : "pic.twitter.com\/zX6nZMkHea"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308767748408897538",
    "text" : "Wrong on so many levels. I can't address it in 140 characters. http:\/\/t.co\/zX6nZMkHea",
    "id" : 308767748408897538,
    "created_at" : "2013-03-05 02:35:42 +0000",
    "user" : {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "protected" : false,
      "id_str" : "167958125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525129289336107008\/HMsrT9oV_normal.jpeg",
      "id" : 167958125,
      "verified" : false
    }
  },
  "id" : 308768606412480513,
  "created_at" : "2013-03-05 02:39:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308767748408897538",
  "geo" : { },
  "id_str" : "308768564159078400",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth WTF??",
  "id" : 308768564159078400,
  "in_reply_to_status_id" : 308767748408897538,
  "created_at" : "2013-03-05 02:38:56 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308759390574497792",
  "text" : "RT @petersonguides: Audubon Magazine is giving away 5 signed copies of Kenn Kaufman's \"Field Guide to Advanced Birding.\" All you have... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/lfGUsMca4V",
        "expanded_url" : "http:\/\/fb.me\/1PApK5VCv",
        "display_url" : "fb.me\/1PApK5VCv"
      } ]
    },
    "geo" : { },
    "id_str" : "308758783428001793",
    "text" : "Audubon Magazine is giving away 5 signed copies of Kenn Kaufman's \"Field Guide to Advanced Birding.\" All you have... http:\/\/t.co\/lfGUsMca4V",
    "id" : 308758783428001793,
    "created_at" : "2013-03-05 02:00:05 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 308759390574497792,
  "created_at" : "2013-03-05 02:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308754103583006720",
  "text" : "@LadyLavender12 im quite familiar w that one myself..lol",
  "id" : 308754103583006720,
  "created_at" : "2013-03-05 01:41:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308753840516251648",
  "text" : "@LadyLavender12 oh no.. havent taken it but just seems like bad stuff.",
  "id" : 308753840516251648,
  "created_at" : "2013-03-05 01:40:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tsem Tulku Rinpoche",
      "screen_name" : "tsemtulku",
      "indices" : [ 3, 13 ],
      "id_str" : "23065876",
      "id" : 23065876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hindu",
      "indices" : [ 118, 124 ]
    }, {
      "text" : "buddhism",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308738652647858176",
  "text" : "RT @tsemtulku: Would you like to win a sacred Manjushri statue? I will post on my blog very soon how you can win one. #hindu #buddhism # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hindu",
        "indices" : [ 103, 109 ]
      }, {
        "text" : "buddhism",
        "indices" : [ 110, 119 ]
      }, {
        "text" : "metaphysical",
        "indices" : [ 120, 133 ]
      }, {
        "text" : "yoga",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308735935850360835",
    "text" : "Would you like to win a sacred Manjushri statue? I will post on my blog very soon how you can win one. #hindu #buddhism #metaphysical #yoga",
    "id" : 308735935850360835,
    "created_at" : "2013-03-05 00:29:17 +0000",
    "user" : {
      "name" : "Tsem Tulku Rinpoche",
      "screen_name" : "tsemtulku",
      "protected" : false,
      "id_str" : "23065876",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1165356530\/aaaaa_normal.jpg",
      "id" : 23065876,
      "verified" : false
    }
  },
  "id" : 308738652647858176,
  "created_at" : "2013-03-05 00:40:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308736126494052352",
  "text" : "i could be so wrong about many things.. that scares me...",
  "id" : 308736126494052352,
  "created_at" : "2013-03-05 00:30:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308699465659863040",
  "geo" : { },
  "id_str" : "308714345993494529",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny omg.. the mistress KNEW he was trying to kill his wife.. ugh!",
  "id" : 308714345993494529,
  "in_reply_to_status_id" : 308699465659863040,
  "created_at" : "2013-03-04 23:03:30 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 4, 17 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/wGqsCCixCX",
      "expanded_url" : "http:\/\/ebookweek.com",
      "display_url" : "ebookweek.com"
    } ]
  },
  "geo" : { },
  "id_str" : "308696467575562240",
  "text" : "fyi @adamrshields its ebook week 3\/3 to 3\/9 http:\/\/t.co\/wGqsCCixCX",
  "id" : 308696467575562240,
  "created_at" : "2013-03-04 21:52:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 39, 49 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaway",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "muoskypen",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/KOHXHAd55b",
      "expanded_url" : "http:\/\/makeuseof.com\/tag\/livescribe-sky-wi-fi-smartpen-review-and-giveaway-twitter-exclusive",
      "display_url" : "makeuseof.com\/tag\/livescribe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308692160474136577",
  "text" : "Retweet this and join the #giveaway at @makeuseof to win a FREE Livescribe Sky Wi-Fi Smartpen! #muoskypen http:\/\/t.co\/KOHXHAd55b",
  "id" : 308692160474136577,
  "created_at" : "2013-03-04 21:35:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S.E.B. MD",
      "screen_name" : "ircrc",
      "indices" : [ 3, 9 ],
      "id_str" : "19193740",
      "id" : 19193740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INLegis",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "Indiana",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "StopPlayingDoctor",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/8dpGMnY5yu",
      "expanded_url" : "http:\/\/twitpic.com\/c6uk2j",
      "display_url" : "twitpic.com\/c6uk2j"
    } ]
  },
  "geo" : { },
  "id_str" : "308689317751042050",
  "text" : "RT @ircrc: \"I'm not a doctor, but I play one in the legislature.\" #INLegis #Indiana #StopPlayingDoctor http:\/\/t.co\/8dpGMnY5yu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "INLegis",
        "indices" : [ 55, 63 ]
      }, {
        "text" : "Indiana",
        "indices" : [ 64, 72 ]
      }, {
        "text" : "StopPlayingDoctor",
        "indices" : [ 73, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/8dpGMnY5yu",
        "expanded_url" : "http:\/\/twitpic.com\/c6uk2j",
        "display_url" : "twitpic.com\/c6uk2j"
      } ]
    },
    "geo" : { },
    "id_str" : "306177977236987904",
    "text" : "\"I'm not a doctor, but I play one in the legislature.\" #INLegis #Indiana #StopPlayingDoctor http:\/\/t.co\/8dpGMnY5yu",
    "id" : 306177977236987904,
    "created_at" : "2013-02-25 23:04:52 +0000",
    "user" : {
      "name" : "S.E.B. MD",
      "screen_name" : "ircrc",
      "protected" : false,
      "id_str" : "19193740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478680934577762304\/uY1fyoeF_normal.jpeg",
      "id" : 19193740,
      "verified" : false
    }
  },
  "id" : 308689317751042050,
  "created_at" : "2013-03-04 21:24:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308687229302210561",
  "geo" : { },
  "id_str" : "308688074869723136",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 yeah.. im wondering WTH...",
  "id" : 308688074869723136,
  "in_reply_to_status_id" : 308687229302210561,
  "created_at" : "2013-03-04 21:19:06 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308676232655028224",
  "geo" : { },
  "id_str" : "308680454389772290",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl how did i miss you having surgery? glad you are recovering! ((hugs))",
  "id" : 308680454389772290,
  "in_reply_to_status_id" : 308676232655028224,
  "created_at" : "2013-03-04 20:48:49 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/bW2Mmo2Tjy",
      "expanded_url" : "http:\/\/youtu.be\/S6ZsXrzF8Cc",
      "display_url" : "youtu.be\/S6ZsXrzF8Cc"
    } ]
  },
  "geo" : { },
  "id_str" : "308676181597761537",
  "text" : "Tax the Rich: An animated fairy tale: http:\/\/t.co\/bW2Mmo2Tjy",
  "id" : 308676181597761537,
  "created_at" : "2013-03-04 20:31:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MILITARYMonday",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/v0djtGcT6N",
      "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2005\/08\/mother-of-all-wars.html",
      "display_url" : "midnightfire.blogspot.no\/2005\/08\/mother\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308659497998622722",
  "text" : "RT @HoodedMan: Ten years on, the case for invading Iraq remains totally invalid  http:\/\/t.co\/v0djtGcT6N Jeb Bush Tony Blair #MILITARYMonday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MILITARYMonday",
        "indices" : [ 109, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/v0djtGcT6N",
        "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2005\/08\/mother-of-all-wars.html",
        "display_url" : "midnightfire.blogspot.no\/2005\/08\/mother\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308656689475891200",
    "text" : "Ten years on, the case for invading Iraq remains totally invalid  http:\/\/t.co\/v0djtGcT6N Jeb Bush Tony Blair #MILITARYMonday",
    "id" : 308656689475891200,
    "created_at" : "2013-03-04 19:14:23 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 308659497998622722,
  "created_at" : "2013-03-04 19:25:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "",
      "screen_name" : "gxldsxul",
      "indices" : [ 45, 54 ],
      "id_str" : "1115747234",
      "id" : 1115747234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308574662487580672",
  "geo" : { },
  "id_str" : "308657647396200448",
  "in_reply_to_user_id" : 1115747234,
  "text" : "precisely why they are so interesting : ) RT @gxldsxul humans are weird",
  "id" : 308657647396200448,
  "in_reply_to_status_id" : 308574662487580672,
  "created_at" : "2013-03-04 19:18:12 +0000",
  "in_reply_to_screen_name" : "gxldsxul",
  "in_reply_to_user_id_str" : "1115747234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 3, 17 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/johnnie_cakes\/status\/308640707680288768\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/abCLCy0hNK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEiDFqDCQAAh14U.jpg",
      "id_str" : "308640707684483072",
      "id" : 308640707684483072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEiDFqDCQAAh14U.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/abCLCy0hNK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308656885433761794",
  "text" : "RT @johnnie_cakes: The turtles agree. http:\/\/t.co\/abCLCy0hNK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/johnnie_cakes\/status\/308640707680288768\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/abCLCy0hNK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BEiDFqDCQAAh14U.jpg",
        "id_str" : "308640707684483072",
        "id" : 308640707684483072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEiDFqDCQAAh14U.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/abCLCy0hNK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308640707680288768",
    "text" : "The turtles agree. http:\/\/t.co\/abCLCy0hNK",
    "id" : 308640707680288768,
    "created_at" : "2013-03-04 18:10:53 +0000",
    "user" : {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "protected" : false,
      "id_str" : "16901470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765066200657166336\/h3XngAjO_normal.jpg",
      "id" : 16901470,
      "verified" : false
    }
  },
  "id" : 308656885433761794,
  "created_at" : "2013-03-04 19:15:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 0, 14 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308647409989324800",
  "geo" : { },
  "id_str" : "308647811489071104",
  "in_reply_to_user_id" : 265007259,
  "text" : "@atheistlady76 *sigh* : (",
  "id" : 308647811489071104,
  "in_reply_to_status_id" : 308647409989324800,
  "created_at" : "2013-03-04 18:39:07 +0000",
  "in_reply_to_screen_name" : "atheistlady76",
  "in_reply_to_user_id_str" : "265007259",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/hHvwsXPqFt",
      "expanded_url" : "http:\/\/www.care2.com\/causes\/go-to-jail-for-free-health-care-5-desperate-people-who-tried.html#bbtw=784760127",
      "display_url" : "care2.com\/causes\/go-to-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308594075559403521",
  "text" : "RT @DarciaHelle: Go to Jail for Free Health Care? 5 Desperate People Who Tried http:\/\/t.co\/hHvwsXPqFt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/hHvwsXPqFt",
        "expanded_url" : "http:\/\/www.care2.com\/causes\/go-to-jail-for-free-health-care-5-desperate-people-who-tried.html#bbtw=784760127",
        "display_url" : "care2.com\/causes\/go-to-j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308589942831992833",
    "text" : "Go to Jail for Free Health Care? 5 Desperate People Who Tried http:\/\/t.co\/hHvwsXPqFt",
    "id" : 308589942831992833,
    "created_at" : "2013-03-04 14:49:10 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 308594075559403521,
  "created_at" : "2013-03-04 15:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308590525831839744",
  "geo" : { },
  "id_str" : "308593632267603969",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny need to show this to my DR..lol who tells me i need to lose weight and exercise! ugh",
  "id" : 308593632267603969,
  "in_reply_to_status_id" : 308590525831839744,
  "created_at" : "2013-03-04 15:03:49 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mondaygiveaway",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/gmYs0vrrcR",
      "expanded_url" : "http:\/\/www.beeridgway.com",
      "display_url" : "beeridgway.com"
    } ]
  },
  "geo" : { },
  "id_str" : "308590334043115520",
  "text" : "RT @DuttonBooks: It's #Mondaygiveaway of books day!  Here's a sneak peek of what we'll be giving away at 3pm EST: http:\/\/t.co\/gmYs0vrrcR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bee Ridgway",
        "screen_name" : "BeeRidgway",
        "indices" : [ 120, 131 ],
        "id_str" : "751911422",
        "id" : 751911422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mondaygiveaway",
        "indices" : [ 5, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/gmYs0vrrcR",
        "expanded_url" : "http:\/\/www.beeridgway.com",
        "display_url" : "beeridgway.com"
      } ]
    },
    "geo" : { },
    "id_str" : "308585795932024832",
    "text" : "It's #Mondaygiveaway of books day!  Here's a sneak peek of what we'll be giving away at 3pm EST: http:\/\/t.co\/gmYs0vrrcR @beeridgway",
    "id" : 308585795932024832,
    "created_at" : "2013-03-04 14:32:41 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 308590334043115520,
  "created_at" : "2013-03-04 14:50:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308363181091344384",
  "geo" : { },
  "id_str" : "308368583556206592",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt truth",
  "id" : 308368583556206592,
  "in_reply_to_status_id" : 308363181091344384,
  "created_at" : "2013-03-04 00:09:34 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "indices" : [ 66, 71 ],
      "id_str" : "355689205",
      "id" : 355689205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/pMPcgLU3pS",
      "expanded_url" : "http:\/\/www.facebook.com\/pages\/wf\/101803536579485?sk=app_311884432248556&app_data%5Bsocial_referrer%5D=393cb108c728328c98079fee1bbb2cca",
      "display_url" : "facebook.com\/pages\/wf\/10180\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308342622148251648",
  "text" : "I just entered to win an eReader or eBook! http:\/\/t.co\/pMPcgLU3pS @eink",
  "id" : 308342622148251648,
  "created_at" : "2013-03-03 22:26:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308244206604939266",
  "text" : "RT @neiltyson: Security signs that begin with \"For your protection...\" essentially end with \"...we will restrict freedoms &amp; invade p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308241021194612738",
    "text" : "Security signs that begin with \"For your protection...\" essentially end with \"...we will restrict freedoms &amp; invade privacy\"",
    "id" : 308241021194612738,
    "created_at" : "2013-03-03 15:42:40 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 308244206604939266,
  "created_at" : "2013-03-03 15:55:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/wrpe0hPlbu",
      "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
      "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308240042709635073",
  "text" : "RT @PeggySueCusses: They make great end of school year gifts for all your kid's teachers. http:\/\/t.co\/wrpe0hPlbu TOTES",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/wrpe0hPlbu",
        "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
        "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308239635086188546",
    "text" : "They make great end of school year gifts for all your kid's teachers. http:\/\/t.co\/wrpe0hPlbu TOTES",
    "id" : 308239635086188546,
    "created_at" : "2013-03-03 15:37:10 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 308240042709635073,
  "created_at" : "2013-03-03 15:38:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Angel Witch",
      "screen_name" : "carribeth",
      "indices" : [ 3, 13 ],
      "id_str" : "41803502",
      "id" : 41803502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Peace",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308239982856921089",
  "text" : "RT @carribeth: Everybody has a different flight path, there's not only one way. Let's chill and just support each other &lt;3  #Peace",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Peace",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308226961321390081",
    "text" : "Everybody has a different flight path, there's not only one way. Let's chill and just support each other &lt;3  #Peace",
    "id" : 308226961321390081,
    "created_at" : "2013-03-03 14:46:48 +0000",
    "user" : {
      "name" : "The Angel Witch",
      "screen_name" : "carribeth",
      "protected" : false,
      "id_str" : "41803502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779516772777127937\/4DvKHSbz_normal.jpg",
      "id" : 41803502,
      "verified" : false
    }
  },
  "id" : 308239982856921089,
  "created_at" : "2013-03-03 15:38:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Allan",
      "screen_name" : "singularityspnt",
      "indices" : [ 3, 19 ],
      "id_str" : "289405704",
      "id" : 289405704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAmWhatIAm",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308239824723251201",
  "text" : "RT @singularityspnt: People call me a bit of a freak because of some of the things I write. \"Thank you,\" I say. #IAmWhatIAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAmWhatIAm",
        "indices" : [ 91, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308228111386951680",
    "text" : "People call me a bit of a freak because of some of the things I write. \"Thank you,\" I say. #IAmWhatIAm",
    "id" : 308228111386951680,
    "created_at" : "2013-03-03 14:51:23 +0000",
    "user" : {
      "name" : "Shaun Allan",
      "screen_name" : "singularityspnt",
      "protected" : false,
      "id_str" : "289405704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665668168472518656\/5flwubW3_normal.jpg",
      "id" : 289405704,
      "verified" : false
    }
  },
  "id" : 308239824723251201,
  "created_at" : "2013-03-03 15:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308239228263858177",
  "text" : "@Skeptical_Lady religion has no claim to morality. reason? that combined w heart.",
  "id" : 308239228263858177,
  "created_at" : "2013-03-03 15:35:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liveandletlive",
      "indices" : [ 38, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308238512082259968",
  "text" : "@Skeptical_Lady i totally accept this #liveandletlive",
  "id" : 308238512082259968,
  "created_at" : "2013-03-03 15:32:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spring",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308235917636800512",
  "text" : "@Skeptical_Lady we have a regular cardinal in our yard. im waiting for my bluebird to return knocking on our bedroom window! : ) #spring",
  "id" : 308235917636800512,
  "created_at" : "2013-03-03 15:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308033103543296001",
  "geo" : { },
  "id_str" : "308035789445537793",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 cool.. thanks : )",
  "id" : 308035789445537793,
  "in_reply_to_status_id" : 308033103543296001,
  "created_at" : "2013-03-03 02:07:09 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308030394689802240",
  "geo" : { },
  "id_str" : "308031065346437120",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 umm.. no... it can go in the mouth?",
  "id" : 308031065346437120,
  "in_reply_to_status_id" : 308030394689802240,
  "created_at" : "2013-03-03 01:48:23 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    }, {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 96, 109 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/9L5cBexLGT",
      "expanded_url" : "http:\/\/www.naturalnews.com\/039317_lavender_antibiotics-resistant_bacteria_staph_infection.html",
      "display_url" : "naturalnews.com\/039317_lavende\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "308027483716980736",
  "text" : "RT @HealthRanger: Lavender kills antibiotic-resistant staph bacteria http:\/\/t.co\/9L5cBexLGT via @HealthRanger",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthRanger",
        "screen_name" : "HealthRanger",
        "indices" : [ 78, 91 ],
        "id_str" : "15843059",
        "id" : 15843059
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/9L5cBexLGT",
        "expanded_url" : "http:\/\/www.naturalnews.com\/039317_lavender_antibiotics-resistant_bacteria_staph_infection.html",
        "display_url" : "naturalnews.com\/039317_lavende\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "308025961927041024",
    "text" : "Lavender kills antibiotic-resistant staph bacteria http:\/\/t.co\/9L5cBexLGT via @HealthRanger",
    "id" : 308025961927041024,
    "created_at" : "2013-03-03 01:28:06 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 308027483716980736,
  "created_at" : "2013-03-03 01:34:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 0, 14 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308025979685707776",
  "geo" : { },
  "id_str" : "308027432055742464",
  "in_reply_to_user_id" : 16494321,
  "text" : "@BrianRathbone hehe",
  "id" : 308027432055742464,
  "in_reply_to_status_id" : 308025979685707776,
  "created_at" : "2013-03-03 01:33:57 +0000",
  "in_reply_to_screen_name" : "BrianRathbone",
  "in_reply_to_user_id_str" : "16494321",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308024407249547266",
  "geo" : { },
  "id_str" : "308025330663313408",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater oops.. had to back and look..lol. what a sweet kitty : )",
  "id" : 308025330663313408,
  "in_reply_to_status_id" : 308024407249547266,
  "created_at" : "2013-03-03 01:25:36 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308023816309841921",
  "geo" : { },
  "id_str" : "308024420897800192",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater nice legs! ; ) what's the book?",
  "id" : 308024420897800192,
  "in_reply_to_status_id" : 308023816309841921,
  "created_at" : "2013-03-03 01:21:59 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308017849480392705",
  "text" : "@LadyLavender12 so wonderful to surprise someone and they're sooo happy : ))",
  "id" : 308017849480392705,
  "created_at" : "2013-03-03 00:55:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 35, 49 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308010808728760321",
  "geo" : { },
  "id_str" : "308013661295869952",
  "in_reply_to_user_id" : 16494321,
  "text" : "Dragons always get a bad rap... RT @BrianRathbone LOST: Dragon. If found, run!",
  "id" : 308013661295869952,
  "in_reply_to_status_id" : 308010808728760321,
  "created_at" : "2013-03-03 00:39:14 +0000",
  "in_reply_to_screen_name" : "BrianRathbone",
  "in_reply_to_user_id_str" : "16494321",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308001671080992768",
  "text" : "damn.. tooth is sore again...",
  "id" : 308001671080992768,
  "created_at" : "2013-03-02 23:51:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen Laker",
      "screen_name" : "glenlaker",
      "indices" : [ 0, 10 ],
      "id_str" : "137705299",
      "id" : 137705299
    }, {
      "name" : "Iron Atheist",
      "screen_name" : "IronAtheist",
      "indices" : [ 110, 122 ],
      "id_str" : "2704847293",
      "id" : 2704847293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307765636795334658",
  "geo" : { },
  "id_str" : "308000972460945409",
  "in_reply_to_user_id" : 137705299,
  "text" : "@glenlaker god forgives.. if you forgive, because you are god -well, thats my humble non-provable opinion ; ) @IronAtheist",
  "id" : 308000972460945409,
  "in_reply_to_status_id" : 307765636795334658,
  "created_at" : "2013-03-02 23:48:48 +0000",
  "in_reply_to_screen_name" : "glenlaker",
  "in_reply_to_user_id_str" : "137705299",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307998441039069186",
  "text" : "RT @Wylieknowords: 4,500 Americans died in the BushWar in Iraq. Thanks Mr Bush &amp; Cheney. Now the country is falling apart and Iran i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307995561078951936",
    "text" : "4,500 Americans died in the BushWar in Iraq. Thanks Mr Bush &amp; Cheney. Now the country is falling apart and Iran is happy. Died for nothing.",
    "id" : 307995561078951936,
    "created_at" : "2013-03-02 23:27:18 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 307998441039069186,
  "created_at" : "2013-03-02 23:38:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 3, 18 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307979168530976768",
  "text" : "RT @HuffingtonPost: 10 ducks escorted by 4 humans for 1 mile through downtown Washington? Quacktacular. (And adorable.) http:\/\/t.co\/Eg3d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/Eg3dPdoPM7",
        "expanded_url" : "http:\/\/huff.to\/146IUjc",
        "display_url" : "huff.to\/146IUjc"
      } ]
    },
    "geo" : { },
    "id_str" : "307971609212354560",
    "text" : "10 ducks escorted by 4 humans for 1 mile through downtown Washington? Quacktacular. (And adorable.) http:\/\/t.co\/Eg3dPdoPM7",
    "id" : 307971609212354560,
    "created_at" : "2013-03-02 21:52:08 +0000",
    "user" : {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "protected" : false,
      "id_str" : "14511951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720642862551928832\/I58EQMCH_normal.jpg",
      "id" : 14511951,
      "verified" : true
    }
  },
  "id" : 307979168530976768,
  "created_at" : "2013-03-02 22:22:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/XwOOYYRd",
      "expanded_url" : "http:\/\/youtu.be\/dJIWobQh9WI",
      "display_url" : "youtu.be\/dJIWobQh9WI"
    } ]
  },
  "geo" : { },
  "id_str" : "307978996912619520",
  "text" : "RT @ificouldtellu: How the universe appeared from nothing http:\/\/t.co\/XwOOYYRd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/XwOOYYRd",
        "expanded_url" : "http:\/\/youtu.be\/dJIWobQh9WI",
        "display_url" : "youtu.be\/dJIWobQh9WI"
      } ]
    },
    "geo" : { },
    "id_str" : "307975850802950144",
    "text" : "How the universe appeared from nothing http:\/\/t.co\/XwOOYYRd",
    "id" : 307975850802950144,
    "created_at" : "2013-03-02 22:08:59 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 307978996912619520,
  "created_at" : "2013-03-02 22:21:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fml",
      "indices" : [ 49, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307969453314953216",
  "text" : "banks suck @BeaEdyson $72 fee for a $4 overdraft #fml",
  "id" : 307969453314953216,
  "created_at" : "2013-03-02 21:43:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 0, 12 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 28, 37 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307964434867953664",
  "geo" : { },
  "id_str" : "307965302900158465",
  "in_reply_to_user_id" : 45674330,
  "text" : "@oceanshaman wow! gorgeous! @KerriFar",
  "id" : 307965302900158465,
  "in_reply_to_status_id" : 307964434867953664,
  "created_at" : "2013-03-02 21:27:04 +0000",
  "in_reply_to_screen_name" : "oceanshaman",
  "in_reply_to_user_id_str" : "45674330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "indices" : [ 0, 10 ],
      "id_str" : "41457590",
      "id" : 41457590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307962359014637570",
  "geo" : { },
  "id_str" : "307963376158523392",
  "in_reply_to_user_id" : 41457590,
  "text" : "@38harmony hello sweet babies, muah!",
  "id" : 307963376158523392,
  "in_reply_to_status_id" : 307962359014637570,
  "created_at" : "2013-03-02 21:19:25 +0000",
  "in_reply_to_screen_name" : "38harmony",
  "in_reply_to_user_id_str" : "41457590",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307957608881483776",
  "geo" : { },
  "id_str" : "307962747231039488",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses grilled Chicken Fajitas? im there!",
  "id" : 307962747231039488,
  "in_reply_to_status_id" : 307957608881483776,
  "created_at" : "2013-03-02 21:16:55 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 0, 9 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 16, 31 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307960290602016768",
  "geo" : { },
  "id_str" : "307962150197026816",
  "in_reply_to_user_id" : 12088232,
  "text" : "@KerriFar maybe @ducksandclucks knows?",
  "id" : 307962150197026816,
  "in_reply_to_status_id" : 307960290602016768,
  "created_at" : "2013-03-02 21:14:32 +0000",
  "in_reply_to_screen_name" : "KerriFar",
  "in_reply_to_user_id_str" : "12088232",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freeman",
      "screen_name" : "Bez___",
      "indices" : [ 0, 7 ],
      "id_str" : "276178942",
      "id" : 276178942
    }, {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 84, 99 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "\u2551\u2588\u2551\u258C\u2551\u2588\u2551\u258C\u2502\u2551\u258C\u2551\u258C\u2588\u2551",
      "screen_name" : "User_Unlisted",
      "indices" : [ 100, 114 ],
      "id_str" : "425683868",
      "id" : 425683868
    }, {
      "name" : "(((MiniMik\u2122)))",
      "screen_name" : "marioPS",
      "indices" : [ 115, 123 ],
      "id_str" : "14968443",
      "id" : 14968443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307890714862301185",
  "geo" : { },
  "id_str" : "307899664198430721",
  "in_reply_to_user_id" : 276178942,
  "text" : "@Bez___ awesomely cool.. \"observer collapsed the wave function simply by observing\" @TheAtheistFool @User_Unlisted @marioPS",
  "id" : 307899664198430721,
  "in_reply_to_status_id" : 307890714862301185,
  "created_at" : "2013-03-02 17:06:15 +0000",
  "in_reply_to_screen_name" : "Bez___",
  "in_reply_to_user_id_str" : "276178942",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdland",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/J3mA5jx5J4",
      "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2013\/02\/forced-imposed.html",
      "display_url" : "midnightfire.blogspot.no\/2013\/02\/forced\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307896027992715264",
  "text" : "RT @HoodedMan: School is tiring, draining to the bone even when it is not apparent http:\/\/t.co\/J3mA5jx5J4 #nerdland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nerdland",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/J3mA5jx5J4",
        "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2013\/02\/forced-imposed.html",
        "display_url" : "midnightfire.blogspot.no\/2013\/02\/forced\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "307895758584172544",
    "text" : "School is tiring, draining to the bone even when it is not apparent http:\/\/t.co\/J3mA5jx5J4 #nerdland",
    "id" : 307895758584172544,
    "created_at" : "2013-03-02 16:50:43 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 307896027992715264,
  "created_at" : "2013-03-02 16:51:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307893045188247552",
  "geo" : { },
  "id_str" : "307893715781967872",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny did i tell you i love your \"disclaimer\" you post every now and then.. always makes me chuckle : )",
  "id" : 307893715781967872,
  "in_reply_to_status_id" : 307893045188247552,
  "created_at" : "2013-03-02 16:42:36 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307890786098348033",
  "geo" : { },
  "id_str" : "307891874109194242",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 oh dear..lol",
  "id" : 307891874109194242,
  "in_reply_to_status_id" : 307890786098348033,
  "created_at" : "2013-03-02 16:35:17 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307891699630346241",
  "text" : "@Skeptical_Lady lol.. nice!",
  "id" : 307891699630346241,
  "created_at" : "2013-03-02 16:34:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307888961664200705",
  "geo" : { },
  "id_str" : "307890056406896640",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 lol.. ((hugs)) .. (and sometimes my hormones get the better of me)",
  "id" : 307890056406896640,
  "in_reply_to_status_id" : 307888961664200705,
  "created_at" : "2013-03-02 16:28:04 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307882656979369984",
  "geo" : { },
  "id_str" : "307888364198187008",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 either having a breakdown or a breakthrough... bleh",
  "id" : 307888364198187008,
  "in_reply_to_status_id" : 307882656979369984,
  "created_at" : "2013-03-02 16:21:20 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freeman",
      "screen_name" : "Bez___",
      "indices" : [ 0, 7 ],
      "id_str" : "276178942",
      "id" : 276178942
    }, {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 33, 48 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "\u2551\u2588\u2551\u258C\u2551\u2588\u2551\u258C\u2502\u2551\u258C\u2551\u258C\u2588\u2551",
      "screen_name" : "User_Unlisted",
      "indices" : [ 49, 63 ],
      "id_str" : "425683868",
      "id" : 425683868
    }, {
      "name" : "(((MiniMik\u2122)))",
      "screen_name" : "marioPS",
      "indices" : [ 64, 72 ],
      "id_str" : "14968443",
      "id" : 14968443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307738628048691200",
  "geo" : { },
  "id_str" : "307888031518564352",
  "in_reply_to_user_id" : 276178942,
  "text" : "@Bez___ which i find very cool.. @TheAtheistFool @User_Unlisted @marioPS",
  "id" : 307888031518564352,
  "in_reply_to_status_id" : 307738628048691200,
  "created_at" : "2013-03-02 16:20:01 +0000",
  "in_reply_to_screen_name" : "Bez___",
  "in_reply_to_user_id_str" : "276178942",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307884963678801921",
  "text" : "@Skeptical_Lady wth? drive thru confession booth or what.. crazy",
  "id" : 307884963678801921,
  "created_at" : "2013-03-02 16:07:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "indices" : [ 3, 15 ],
      "id_str" : "406759668",
      "id" : 406759668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307882648079044608",
  "text" : "RT @yoursMukund: Nothing really matters.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307882239717429249",
    "text" : "Nothing really matters.",
    "id" : 307882239717429249,
    "created_at" : "2013-03-02 15:57:00 +0000",
    "user" : {
      "name" : "Moving Forward",
      "screen_name" : "yoursMukund",
      "protected" : false,
      "id_str" : "406759668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000454898275\/fc674ec400b510e4ab53f191238a2664_normal.jpeg",
      "id" : 406759668,
      "verified" : false
    }
  },
  "id" : 307882648079044608,
  "created_at" : "2013-03-02 15:58:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307882544215511040",
  "text" : "@Skeptical_Lady my personality type is INFP .. everything about me is based on emotions, how i feel.. cant change it, its who I am.",
  "id" : 307882544215511040,
  "created_at" : "2013-03-02 15:58:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307880159934025729",
  "text" : "i should have never married. unfortunately, hubby is stuck w me as i have nowhere to go...",
  "id" : 307880159934025729,
  "created_at" : "2013-03-02 15:48:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307872338207199232",
  "geo" : { },
  "id_str" : "307873601082757120",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields you are awesome.. lol",
  "id" : 307873601082757120,
  "in_reply_to_status_id" : 307872338207199232,
  "created_at" : "2013-03-02 15:22:41 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/pPVKXRCll0",
      "expanded_url" : "http:\/\/www.bradleymanning.org\/learn-more\/collateral-murder-video",
      "display_url" : "bradleymanning.org\/learn-more\/col\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307873325827366912",
  "text" : "Americans shooting and killing 11 individuals who do not return fire  http:\/\/t.co\/pPVKXRCll0",
  "id" : 307873325827366912,
  "created_at" : "2013-03-02 15:21:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RuPaul",
      "screen_name" : "RuPaul",
      "indices" : [ 3, 10 ],
      "id_str" : "82455213",
      "id" : 82455213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307870712348168192",
  "text" : "RT @RuPaul: Neo: Why do my eyes hurt? \nMorpheus: You've never used them before. \n~The Matrix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307869607115497472",
    "text" : "Neo: Why do my eyes hurt? \nMorpheus: You've never used them before. \n~The Matrix",
    "id" : 307869607115497472,
    "created_at" : "2013-03-02 15:06:48 +0000",
    "user" : {
      "name" : "RuPaul",
      "screen_name" : "RuPaul",
      "protected" : false,
      "id_str" : "82455213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726455309426794496\/vRaae9eR_normal.jpg",
      "id" : 82455213,
      "verified" : true
    }
  },
  "id" : 307870712348168192,
  "created_at" : "2013-03-02 15:11:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307870562175315968",
  "text" : "flipped up the bedroom shade this am to see a squirrel on the roof : )",
  "id" : 307870562175315968,
  "created_at" : "2013-03-02 15:10:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307869839740006401",
  "geo" : { },
  "id_str" : "307870270801199104",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields LOL.. cute!",
  "id" : 307870270801199104,
  "in_reply_to_status_id" : 307869839740006401,
  "created_at" : "2013-03-02 15:09:27 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/2PXpjrf61x",
      "expanded_url" : "http:\/\/wapo.st\/Z4PHa9",
      "display_url" : "wapo.st\/Z4PHa9"
    } ]
  },
  "geo" : { },
  "id_str" : "307869861885923328",
  "text" : "RT @ezraklein: An average ER visit costs more than an average month\u2019s rent http:\/\/t.co\/2PXpjrf61x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/2PXpjrf61x",
        "expanded_url" : "http:\/\/wapo.st\/Z4PHa9",
        "display_url" : "wapo.st\/Z4PHa9"
      } ]
    },
    "geo" : { },
    "id_str" : "307866557470629889",
    "text" : "An average ER visit costs more than an average month\u2019s rent http:\/\/t.co\/2PXpjrf61x",
    "id" : 307866557470629889,
    "created_at" : "2013-03-02 14:54:41 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 307869861885923328,
  "created_at" : "2013-03-02 15:07:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/cQz58OVhmS",
      "expanded_url" : "http:\/\/rosemaryfarm.org\/all\/a-short-auction-and-a-handsome-stranger\/",
      "display_url" : "rosemaryfarm.org\/all\/a-short-au\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307864341720477697",
  "text" : "A short auction and a handsome stranger http:\/\/t.co\/cQz58OVhmS",
  "id" : 307864341720477697,
  "created_at" : "2013-03-02 14:45:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Another Human",
      "screen_name" : "TheAtheistFool",
      "indices" : [ 0, 15 ],
      "id_str" : "550304910",
      "id" : 550304910
    }, {
      "name" : "Freeman",
      "screen_name" : "Bez___",
      "indices" : [ 65, 72 ],
      "id_str" : "276178942",
      "id" : 276178942
    }, {
      "name" : "\u2551\u2588\u2551\u258C\u2551\u2588\u2551\u258C\u2502\u2551\u258C\u2551\u258C\u2588\u2551",
      "screen_name" : "User_Unlisted",
      "indices" : [ 73, 87 ],
      "id_str" : "425683868",
      "id" : 425683868
    }, {
      "name" : "(((MiniMik\u2122)))",
      "screen_name" : "marioPS",
      "indices" : [ 88, 96 ],
      "id_str" : "14968443",
      "id" : 14968443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307648239690211329",
  "geo" : { },
  "id_str" : "307649202811445248",
  "in_reply_to_user_id" : 550304910,
  "text" : "@TheAtheistFool then how the hell can we have negative numbers?? @Bez___ @User_Unlisted @marioPS",
  "id" : 307649202811445248,
  "in_reply_to_status_id" : 307648239690211329,
  "created_at" : "2013-03-02 00:31:00 +0000",
  "in_reply_to_screen_name" : "TheAtheistFool",
  "in_reply_to_user_id_str" : "550304910",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/Qu9rtbur4u",
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/307590358886408192",
      "display_url" : "twitter.com\/moosebegab\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "307586769199697920",
  "geo" : { },
  "id_str" : "307592665896210432",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 https:\/\/t.co\/Qu9rtbur4u",
  "id" : 307592665896210432,
  "in_reply_to_status_id" : 307586769199697920,
  "created_at" : "2013-03-01 20:46:21 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/holycutenesss\/status\/307591220811661313\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/z6ldNt1O1f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BETIle0CAAAUw_L.jpg",
      "id_str" : "307591220820049920",
      "id" : 307591220820049920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BETIle0CAAAUw_L.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/z6ldNt1O1f"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/lYrkeNWdAC",
      "expanded_url" : "http:\/\/bit.ly\/WtzQas",
      "display_url" : "bit.ly\/WtzQas"
    } ]
  },
  "geo" : { },
  "id_str" : "307591649884778497",
  "text" : "RT @holycutenesss: Duck family gets escorted to pond http:\/\/t.co\/lYrkeNWdAC http:\/\/t.co\/z6ldNt1O1f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/holycutenesss\/status\/307591220811661313\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/z6ldNt1O1f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BETIle0CAAAUw_L.jpg",
        "id_str" : "307591220820049920",
        "id" : 307591220820049920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BETIle0CAAAUw_L.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/z6ldNt1O1f"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/lYrkeNWdAC",
        "expanded_url" : "http:\/\/bit.ly\/WtzQas",
        "display_url" : "bit.ly\/WtzQas"
      } ]
    },
    "geo" : { },
    "id_str" : "307591220811661313",
    "text" : "Duck family gets escorted to pond http:\/\/t.co\/lYrkeNWdAC http:\/\/t.co\/z6ldNt1O1f",
    "id" : 307591220811661313,
    "created_at" : "2013-03-01 20:40:36 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 307591649884778497,
  "created_at" : "2013-03-01 20:42:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/photo-editor++\/id528349318?mt=8&uo=4\" rel=\"nofollow\"\u003EPhoto Editor++ on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/307590358886408192\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/ugHgg35YZr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BETHzT4CYAEuyEM.jpg",
      "id_str" : "307590358890602497",
      "id" : 307590358890602497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BETHzT4CYAEuyEM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/ugHgg35YZr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/kbnq3gQTR3",
      "expanded_url" : "http:\/\/www.zentertain.net\/redirect\/photo-editor-deluxe",
      "display_url" : "zentertain.net\/redirect\/photo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 41.77256, -73.686813 ]
  },
  "id_str" : "307590358886408192",
  "text" : "Check out my photo! http:\/\/t.co\/kbnq3gQTR3 http:\/\/t.co\/ugHgg35YZr",
  "id" : 307590358886408192,
  "created_at" : "2013-03-01 20:37:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mimi Madeira",
      "screen_name" : "MimiMadeira1",
      "indices" : [ 0, 13 ],
      "id_str" : "946353775",
      "id" : 946353775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307586769199697920",
  "geo" : { },
  "id_str" : "307587384361504768",
  "in_reply_to_user_id" : 946353775,
  "text" : "@MimiMadeira1 the painting behind my chair? sure, i can take a pic. it belonged to my parents.",
  "id" : 307587384361504768,
  "in_reply_to_status_id" : 307586769199697920,
  "created_at" : "2013-03-01 20:25:21 +0000",
  "in_reply_to_screen_name" : "MimiMadeira1",
  "in_reply_to_user_id_str" : "946353775",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307586973504258048",
  "text" : "it helps to think of big angel just wrapping feathery soft wings around me.. protecting, soothing, comforting.",
  "id" : 307586973504258048,
  "created_at" : "2013-03-01 20:23:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "delayedgriefsyndrome",
      "indices" : [ 0, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307586501099794432",
  "text" : "#delayedgriefsyndrome you dont grieve at the time of incident but it pops up out of blue later",
  "id" : 307586501099794432,
  "created_at" : "2013-03-01 20:21:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307585876546945025",
  "text" : "i think im missing my mother. looking up ppl from past just reminds me...",
  "id" : 307585876546945025,
  "created_at" : "2013-03-01 20:19:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307584032819003392",
  "geo" : { },
  "id_str" : "307585405514035200",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy you are very kind, thank you. been a looong time since that pesky low self-esteem raised its head...",
  "id" : 307585405514035200,
  "in_reply_to_status_id" : 307584032819003392,
  "created_at" : "2013-03-01 20:17:29 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307583529779359744",
  "text" : "feeling sad. most ppl i knew as a kid went to college, got good jobs or did something w life. not me. im a leech. cant survive on my own.",
  "id" : 307583529779359744,
  "created_at" : "2013-03-01 20:10:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DCProfessor",
      "screen_name" : "DCProfessor1",
      "indices" : [ 3, 16 ],
      "id_str" : "565405613",
      "id" : 565405613
    }, {
      "name" : "Democracy Now!",
      "screen_name" : "democracynow",
      "indices" : [ 18, 31 ],
      "id_str" : "16935292",
      "id" : 16935292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307516102374735874",
  "text" : "RT @DCProfessor1: @democracynow When 9 yr Max reported his father raped him the Judge gave sole custody to his rapist http:\/\/t.co\/VnSxe8 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Democracy Now!",
        "screen_name" : "democracynow",
        "indices" : [ 0, 13 ],
        "id_str" : "16935292",
        "id" : 16935292
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kidsforcash",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/VnSxe8psCP",
        "expanded_url" : "http:\/\/wtim.es\/12gjTXw",
        "display_url" : "wtim.es\/12gjTXw"
      } ]
    },
    "in_reply_to_status_id_str" : "307510599674384385",
    "geo" : { },
    "id_str" : "307510716305395713",
    "in_reply_to_user_id" : 16935292,
    "text" : "@democracynow When 9 yr Max reported his father raped him the Judge gave sole custody to his rapist http:\/\/t.co\/VnSxe8psCP  #kidsforcash",
    "id" : 307510716305395713,
    "in_reply_to_status_id" : 307510599674384385,
    "created_at" : "2013-03-01 15:20:42 +0000",
    "in_reply_to_screen_name" : "democracynow",
    "in_reply_to_user_id_str" : "16935292",
    "user" : {
      "name" : "DCProfessor",
      "screen_name" : "DCProfessor1",
      "protected" : false,
      "id_str" : "565405613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3671937735\/7821baf7754a9b3a8ea3bd8b9ee85edf_normal.jpeg",
      "id" : 565405613,
      "verified" : false
    }
  },
  "id" : 307516102374735874,
  "created_at" : "2013-03-01 15:42:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GMO",
      "indices" : [ 40, 44 ]
    }, {
      "text" : "thriller",
      "indices" : [ 64, 73 ]
    }, {
      "text" : "Free",
      "indices" : [ 121, 126 ]
    }, {
      "text" : "eBook",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/4EYp2qVSPH",
      "expanded_url" : "http:\/\/bit.ly\/MPjsKO",
      "display_url" : "bit.ly\/MPjsKO"
    } ]
  },
  "geo" : { },
  "id_str" : "307506734937821186",
  "text" : "RT @KreelanWarrior: Who's really behind #GMO's? Find out in the #thriller SEASON OF THE HARVEST - http:\/\/t.co\/4EYp2qVSPH #Free #eBook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GMO",
        "indices" : [ 20, 24 ]
      }, {
        "text" : "thriller",
        "indices" : [ 44, 53 ]
      }, {
        "text" : "Free",
        "indices" : [ 101, 106 ]
      }, {
        "text" : "eBook",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/4EYp2qVSPH",
        "expanded_url" : "http:\/\/bit.ly\/MPjsKO",
        "display_url" : "bit.ly\/MPjsKO"
      } ]
    },
    "geo" : { },
    "id_str" : "307506437326786561",
    "text" : "Who's really behind #GMO's? Find out in the #thriller SEASON OF THE HARVEST - http:\/\/t.co\/4EYp2qVSPH #Free #eBook",
    "id" : 307506437326786561,
    "created_at" : "2013-03-01 15:03:42 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 307506734937821186,
  "created_at" : "2013-03-01 15:04:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307506490724462592",
  "text" : "i love to watch the birds and squirrels come get the seed and peanut butter. gives me joy to see them happy.",
  "id" : 307506490724462592,
  "created_at" : "2013-03-01 15:03:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307505917145001986",
  "text" : "RT @TheGoldenMirror: Peace of mind is found when you stop judging yourself and stop judging others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307505337848709120",
    "text" : "Peace of mind is found when you stop judging yourself and stop judging others.",
    "id" : 307505337848709120,
    "created_at" : "2013-03-01 14:59:20 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 307505917145001986,
  "created_at" : "2013-03-01 15:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Maxwell",
      "screen_name" : "aDancingDonkey",
      "indices" : [ 4, 19 ],
      "id_str" : "423145788",
      "id" : 423145788
    }, {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 23, 33 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/JvnXcNmRKG",
      "expanded_url" : "http:\/\/www.hoofwraps.com",
      "display_url" : "hoofwraps.com"
    } ]
  },
  "in_reply_to_status_id_str" : "307498418970980355",
  "geo" : { },
  "id_str" : "307500977999712256",
  "in_reply_to_user_id" : 29738127,
  "text" : "hey @aDancingDonkey MT @petsalive horse people... Check out this product: http:\/\/t.co\/JvnXcNmRKG  - they sent us samples and WE LOVE!",
  "id" : 307500977999712256,
  "in_reply_to_status_id" : 307498418970980355,
  "created_at" : "2013-03-01 14:42:00 +0000",
  "in_reply_to_screen_name" : "petsalive",
  "in_reply_to_user_id_str" : "29738127",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307489719040737280",
  "text" : "@LadyLavender12 i have ipod touch (4thgen) -goes in car w me for music but also play apps and keep some contacts on it. LOVE having camera!",
  "id" : 307489719040737280,
  "created_at" : "2013-03-01 13:57:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]