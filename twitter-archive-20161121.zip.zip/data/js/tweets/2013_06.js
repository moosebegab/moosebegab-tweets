Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 0, 13 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351500589223522306",
  "geo" : { },
  "id_str" : "351502566519087105",
  "in_reply_to_user_id" : 17374293,
  "text" : "@JeremyCShipp that would make a great tv show",
  "id" : 351502566519087105,
  "in_reply_to_status_id" : 351500589223522306,
  "created_at" : "2013-07-01 00:48:37 +0000",
  "in_reply_to_screen_name" : "JeremyCShipp",
  "in_reply_to_user_id_str" : "17374293",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351502329092128769",
  "text" : "RT @JeremyCShipp: What if every coconut was filled with a different diorama based on a scene from somebody's life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351500589223522306",
    "text" : "What if every coconut was filled with a different diorama based on a scene from somebody's life.",
    "id" : 351500589223522306,
    "created_at" : "2013-07-01 00:40:45 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 351502329092128769,
  "created_at" : "2013-07-01 00:47:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Campbell",
      "screen_name" : "Timoshi",
      "indices" : [ 0, 8 ],
      "id_str" : "19772557",
      "id" : 19772557
    }, {
      "name" : "Kindle Free Books",
      "screen_name" : "iReaderReview",
      "indices" : [ 83, 97 ],
      "id_str" : "23625793",
      "id" : 23625793
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eink",
      "indices" : [ 20, 25 ]
    }, {
      "text" : "kindle",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351478166696640514",
  "geo" : { },
  "id_str" : "351495607023697921",
  "in_reply_to_user_id" : 19772557,
  "text" : "@Timoshi i like the #eink on my #kindle paperwhite; i use my ipod for music, apps. @iReaderReview",
  "id" : 351495607023697921,
  "in_reply_to_status_id" : 351478166696640514,
  "created_at" : "2013-07-01 00:20:57 +0000",
  "in_reply_to_screen_name" : "Timoshi",
  "in_reply_to_user_id_str" : "19772557",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 0, 15 ],
      "id_str" : "44674382",
      "id" : 44674382
    }, {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 25, 38 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351386574732275713",
  "geo" : { },
  "id_str" : "351387698042384386",
  "in_reply_to_user_id" : 44674382,
  "text" : "@ChrisCapparell clarify? @InvisCollege",
  "id" : 351387698042384386,
  "in_reply_to_status_id" : 351386574732275713,
  "created_at" : "2013-06-30 17:12:10 +0000",
  "in_reply_to_screen_name" : "ChrisCapparell",
  "in_reply_to_user_id_str" : "44674382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 2, 15 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351370430638080000",
  "geo" : { },
  "id_str" : "351384560006733824",
  "in_reply_to_user_id" : 415556669,
  "text" : ". @InvisCollege it's like trying to herd cats.. LOL",
  "id" : 351384560006733824,
  "in_reply_to_status_id" : 351370430638080000,
  "created_at" : "2013-06-30 16:59:42 +0000",
  "in_reply_to_screen_name" : "InvisCollege",
  "in_reply_to_user_id_str" : "415556669",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mickO",
      "screen_name" : "MickOweis",
      "indices" : [ 3, 13 ],
      "id_str" : "295102174",
      "id" : 295102174
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MickOweis\/status\/351367607254925312\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/DHQFY5Tp6P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOBO-ihCQAAXu6X.jpg",
      "id_str" : "351367607259119616",
      "id" : 351367607259119616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOBO-ihCQAAXu6X.jpg",
      "sizes" : [ {
        "h" : 637,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DHQFY5Tp6P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351367780513234945",
  "text" : "RT @MickOweis: A baby Tasmanian Devil http:\/\/t.co\/DHQFY5Tp6P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MickOweis\/status\/351367607254925312\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/DHQFY5Tp6P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOBO-ihCQAAXu6X.jpg",
        "id_str" : "351367607259119616",
        "id" : 351367607259119616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOBO-ihCQAAXu6X.jpg",
        "sizes" : [ {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DHQFY5Tp6P"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351367607254925312",
    "text" : "A baby Tasmanian Devil http:\/\/t.co\/DHQFY5Tp6P",
    "id" : 351367607254925312,
    "created_at" : "2013-06-30 15:52:20 +0000",
    "user" : {
      "name" : "mickO",
      "screen_name" : "MickOweis",
      "protected" : false,
      "id_str" : "295102174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703334766016266240\/w7SebAkY_normal.jpg",
      "id" : 295102174,
      "verified" : false
    }
  },
  "id" : 351367780513234945,
  "created_at" : "2013-06-30 15:53:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 3, 15 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tommysalami\/status\/351330567964463105\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/NDQ1wNntCn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOAtSkaCEAIZRdv.jpg",
      "id_str" : "351330567968657410",
      "id" : 351330567968657410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOAtSkaCEAIZRdv.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NDQ1wNntCn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351354509148172288",
  "text" : "RT @tommysalami: What. I'm not fluffy and warm as a towel? http:\/\/t.co\/NDQ1wNntCn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tommysalami\/status\/351330567964463105\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/NDQ1wNntCn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOAtSkaCEAIZRdv.jpg",
        "id_str" : "351330567968657410",
        "id" : 351330567968657410,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOAtSkaCEAIZRdv.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NDQ1wNntCn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351330567964463105",
    "text" : "What. I'm not fluffy and warm as a towel? http:\/\/t.co\/NDQ1wNntCn",
    "id" : 351330567964463105,
    "created_at" : "2013-06-30 13:25:09 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 351354509148172288,
  "created_at" : "2013-06-30 15:00:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351351347477610497",
  "text" : "RT @ChrisCapparell: Perceive your own misperception, and then the source of misperception. This is to locate the splinter (the log in your \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351347727029911552",
    "text" : "Perceive your own misperception, and then the source of misperception. This is to locate the splinter (the log in your eye).",
    "id" : 351347727029911552,
    "created_at" : "2013-06-30 14:33:20 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 351351347477610497,
  "created_at" : "2013-06-30 14:47:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deborah",
      "screen_name" : "DebErupts",
      "indices" : [ 3, 13 ],
      "id_str" : "131643073",
      "id" : 131643073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351081651117363200",
  "text" : "RT @DebErupts: Religious Employers Can Deny Workers Birth Control. Health insurance should not be linked to employment. http:\/\/t.co\/uBEjRge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/uBEjRgevxm",
        "expanded_url" : "http:\/\/thkpr.gs\/12qGBKs",
        "display_url" : "thkpr.gs\/12qGBKs"
      } ]
    },
    "geo" : { },
    "id_str" : "351025651815432192",
    "text" : "Religious Employers Can Deny Workers Birth Control. Health insurance should not be linked to employment. http:\/\/t.co\/uBEjRgevxm #singlepayer",
    "id" : 351025651815432192,
    "created_at" : "2013-06-29 17:13:31 +0000",
    "user" : {
      "name" : "Deborah",
      "screen_name" : "DebErupts",
      "protected" : false,
      "id_str" : "131643073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798007621395451904\/mKZ10nmQ_normal.jpg",
      "id" : 131643073,
      "verified" : false
    }
  },
  "id" : 351081651117363200,
  "created_at" : "2013-06-29 20:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NichtMeineF\u00FChrer",
      "screen_name" : "TheRiverWanders",
      "indices" : [ 3, 19 ],
      "id_str" : "16502238",
      "id" : 16502238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WTF",
      "indices" : [ 107, 111 ]
    }, {
      "text" : "p2",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/iJCIkWMOKv",
      "expanded_url" : "http:\/\/tmblr.co\/ZfejjxoUknhL",
      "display_url" : "tmblr.co\/ZfejjxoUknhL"
    } ]
  },
  "geo" : { },
  "id_str" : "351080503354470400",
  "text" : "RT @TheRiverWanders: Man rapes 6yo daughter, goes to prison, JUDGE LETS HIM HAVE SOLE CUSTODY 6 YRS LATER. #WTF #p2 http:\/\/t.co\/iJCIkWMOKv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WTF",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "p2",
        "indices" : [ 91, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/iJCIkWMOKv",
        "expanded_url" : "http:\/\/tmblr.co\/ZfejjxoUknhL",
        "display_url" : "tmblr.co\/ZfejjxoUknhL"
      } ]
    },
    "geo" : { },
    "id_str" : "351073275415248896",
    "text" : "Man rapes 6yo daughter, goes to prison, JUDGE LETS HIM HAVE SOLE CUSTODY 6 YRS LATER. #WTF #p2 http:\/\/t.co\/iJCIkWMOKv",
    "id" : 351073275415248896,
    "created_at" : "2013-06-29 20:22:46 +0000",
    "user" : {
      "name" : "NichtMeineF\u00FChrer",
      "screen_name" : "TheRiverWanders",
      "protected" : false,
      "id_str" : "16502238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797496566953033728\/lgNZlXjR_normal.jpg",
      "id" : 16502238,
      "verified" : false
    }
  },
  "id" : 351080503354470400,
  "created_at" : "2013-06-29 20:51:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy's Wisecracks",
      "screen_name" : "WillysWisecrack",
      "indices" : [ 3, 19 ],
      "id_str" : "866500945",
      "id" : 866500945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351075785865572352",
  "text" : "RT @WillysWisecrack: Oh, money can't buy you happiness? Well poverty can't buy you anything.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351069097389326337",
    "text" : "Oh, money can't buy you happiness? Well poverty can't buy you anything.",
    "id" : 351069097389326337,
    "created_at" : "2013-06-29 20:06:10 +0000",
    "user" : {
      "name" : "Willy's Wisecracks",
      "screen_name" : "WillysWisecrack",
      "protected" : false,
      "id_str" : "866500945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2690934718\/49f427acc1e251294884d16ea27b63e6_normal.jpeg",
      "id" : 866500945,
      "verified" : false
    }
  },
  "id" : 351075785865572352,
  "created_at" : "2013-06-29 20:32:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. Kei",
      "screen_name" : "kujakupoet",
      "indices" : [ 3, 14 ],
      "id_str" : "30552169",
      "id" : 30552169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351075350450667521",
  "text" : "RT @kujakupoet: What the Night Sky Would Look Like If the Other Planets Were as Close as the Moon - Rebecca J. Rosen - The Atlantic http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/UjSXyN0WW5",
        "expanded_url" : "http:\/\/www.theatlantic.com\/technology\/archive\/2013\/06\/what-the-night-sky-would-look-like-if-the-other-planets-were-as-close-as-the-moon\/277247\/",
        "display_url" : "theatlantic.com\/technology\/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351072654616313857",
    "text" : "What the Night Sky Would Look Like If the Other Planets Were as Close as the Moon - Rebecca J. Rosen - The Atlantic http:\/\/t.co\/UjSXyN0WW5",
    "id" : 351072654616313857,
    "created_at" : "2013-06-29 20:20:18 +0000",
    "user" : {
      "name" : "M. Kei",
      "screen_name" : "kujakupoet",
      "protected" : false,
      "id_str" : "30552169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797617696737259520\/ukuYvtn7_normal.jpg",
      "id" : 30552169,
      "verified" : false
    }
  },
  "id" : 351075350450667521,
  "created_at" : "2013-06-29 20:31:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351074563385344001",
  "text" : "sometimes i'll eat.. then feel like i didn't.. like a blood sugar drop.. (after burger and pasta salad?) weird.",
  "id" : 351074563385344001,
  "created_at" : "2013-06-29 20:27:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351056284025495553",
  "text" : "RT @micahjmurray: \"Sex outside of Marriage is bad, sex inside marriage is just as bad if it is not used for producing children.\" #EpicBlogC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EpicBlogComment",
        "indices" : [ 111, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351055359458295809",
    "text" : "\"Sex outside of Marriage is bad, sex inside marriage is just as bad if it is not used for producing children.\" #EpicBlogComment",
    "id" : 351055359458295809,
    "created_at" : "2013-06-29 19:11:34 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 351056284025495553,
  "created_at" : "2013-06-29 19:15:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/8besS6O1cm",
      "expanded_url" : "http:\/\/redemptionpictures.com\/2013\/06\/27\/sex-robot\/#comment-946461981",
      "display_url" : "redemptionpictures.com\/2013\/06\/27\/sex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "351056237644890114",
  "text" : "RT @micahjmurray: This internet comment wins the day for Most Epic Crash and Burn Ever: http:\/\/t.co\/8besS6O1cm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/8besS6O1cm",
        "expanded_url" : "http:\/\/redemptionpictures.com\/2013\/06\/27\/sex-robot\/#comment-946461981",
        "display_url" : "redemptionpictures.com\/2013\/06\/27\/sex\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "351054979815055360",
    "text" : "This internet comment wins the day for Most Epic Crash and Burn Ever: http:\/\/t.co\/8besS6O1cm",
    "id" : 351054979815055360,
    "created_at" : "2013-06-29 19:10:04 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 351056237644890114,
  "created_at" : "2013-06-29 19:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Real Time",
      "screen_name" : "RealTimers",
      "indices" : [ 3, 14 ],
      "id_str" : "455288410",
      "id" : 455288410
    }, {
      "name" : "Bill Maher",
      "screen_name" : "billmaher",
      "indices" : [ 121, 131 ],
      "id_str" : "19697415",
      "id" : 19697415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351021762714152960",
  "text" : "RT @RealTimers: \"Scalia calling black people voting an 'entitlement' is more racist than anything Paula Deen ever said.\" @billmaher #RealTi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Maher",
        "screen_name" : "billmaher",
        "indices" : [ 105, 115 ],
        "id_str" : "19697415",
        "id" : 19697415
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RealTime",
        "indices" : [ 116, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350802472324968448",
    "text" : "\"Scalia calling black people voting an 'entitlement' is more racist than anything Paula Deen ever said.\" @billmaher #RealTime",
    "id" : 350802472324968448,
    "created_at" : "2013-06-29 02:26:41 +0000",
    "user" : {
      "name" : "Real Time",
      "screen_name" : "RealTimers",
      "protected" : false,
      "id_str" : "455288410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677985594568413184\/g-VDzo4D_normal.jpg",
      "id" : 455288410,
      "verified" : true
    }
  },
  "id" : 351021762714152960,
  "created_at" : "2013-06-29 16:58:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloPoodle",
      "screen_name" : "HelloPoodle",
      "indices" : [ 0, 12 ],
      "id_str" : "4873061806",
      "id" : 4873061806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351017231238443010",
  "text" : "@HelloPoodle i just dont understand the pro zimmerman ppl. Z stalked and pursued T while T was walking home! ugh...",
  "id" : 351017231238443010,
  "created_at" : "2013-06-29 16:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351013143520100353",
  "geo" : { },
  "id_str" : "351014748093038594",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste comment shows personal insecurity...",
  "id" : 351014748093038594,
  "in_reply_to_status_id" : 351013143520100353,
  "created_at" : "2013-06-29 16:30:12 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350966006149156864",
  "geo" : { },
  "id_str" : "350993022885961728",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl that means im gonna be here a loooong time... sigh..",
  "id" : 350993022885961728,
  "in_reply_to_status_id" : 350966006149156864,
  "created_at" : "2013-06-29 15:03:52 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Amin",
      "screen_name" : "aminart",
      "indices" : [ 20, 28 ],
      "id_str" : "91067167",
      "id" : 91067167
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/aminart\/status\/350715056469704704\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/wgKJtVZLfX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN39fFaCAAAUvPw.jpg",
      "id_str" : "350715056473899008",
      "id" : 350715056473899008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN39fFaCAAAUvPw.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wgKJtVZLfX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350989828952817664",
  "text" : "RT @KerriFar: :) RT @aminart: Birds kiss too http:\/\/t.co\/wgKJtVZLfX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amin",
        "screen_name" : "aminart",
        "indices" : [ 6, 14 ],
        "id_str" : "91067167",
        "id" : 91067167
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/aminart\/status\/350715056469704704\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/wgKJtVZLfX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BN39fFaCAAAUvPw.jpg",
        "id_str" : "350715056473899008",
        "id" : 350715056473899008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN39fFaCAAAUvPw.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wgKJtVZLfX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350987213430980608",
    "text" : ":) RT @aminart: Birds kiss too http:\/\/t.co\/wgKJtVZLfX",
    "id" : 350987213430980608,
    "created_at" : "2013-06-29 14:40:47 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 350989828952817664,
  "created_at" : "2013-06-29 14:51:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350802296529092609",
  "geo" : { },
  "id_str" : "350804951435444224",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist I kinda like this even tho I'm a theist. But ppl have more control than they know : )",
  "id" : 350804951435444224,
  "in_reply_to_status_id" : 350802296529092609,
  "created_at" : "2013-06-29 02:36:32 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350804280384565251",
  "text" : "RT @aliceinthewater: I don't understand why people are making fun of Rachel Jeantel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350802327730524161",
    "text" : "I don't understand why people are making fun of Rachel Jeantel",
    "id" : 350802327730524161,
    "created_at" : "2013-06-29 02:26:07 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 350804280384565251,
  "created_at" : "2013-06-29 02:33:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Petty Lupone",
      "screen_name" : "Thinking_Helps",
      "indices" : [ 33, 48 ],
      "id_str" : "50799216",
      "id" : 50799216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/kQdUczcxP0",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=467X_mlibuw",
      "display_url" : "youtube.com\/watch?v=467X_m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "350771619909746691",
  "geo" : { },
  "id_str" : "350780178189914112",
  "in_reply_to_user_id" : 50799216,
  "text" : "wow... http:\/\/t.co\/kQdUczcxP0 RT @Thinking_Helps \"It was all God's plan...\"- George Zimmerman 7\/18\/12 #Hannity",
  "id" : 350780178189914112,
  "in_reply_to_status_id" : 350771619909746691,
  "created_at" : "2013-06-29 00:58:06 +0000",
  "in_reply_to_screen_name" : "Thinking_Helps",
  "in_reply_to_user_id_str" : "50799216",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morning No",
      "screen_name" : "jesseltaylor",
      "indices" : [ 3, 16 ],
      "id_str" : "14455321",
      "id" : 14455321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350778096003198976",
  "text" : "RT @jesseltaylor: Zimmerman's entire defense is that black people are per se threatening and hostile, and chasing them with a gun is reason\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350595015145308162",
    "text" : "Zimmerman's entire defense is that black people are per se threatening and hostile, and chasing them with a gun is reasonable.",
    "id" : 350595015145308162,
    "created_at" : "2013-06-28 12:42:20 +0000",
    "user" : {
      "name" : "Morning No",
      "screen_name" : "jesseltaylor",
      "protected" : false,
      "id_str" : "14455321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770937056075714565\/IyleQAFf_normal.jpg",
      "id" : 14455321,
      "verified" : false
    }
  },
  "id" : 350778096003198976,
  "created_at" : "2013-06-29 00:49:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 34, 43 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "birding",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/doaaPDH4JB",
      "expanded_url" : "http:\/\/bit.ly\/10pTCDr",
      "display_url" : "bit.ly\/10pTCDr"
    } ]
  },
  "geo" : { },
  "id_str" : "350766509905281025",
  "text" : "RT @KerriFar: Wonderful post!! RT @gemswinc: Love In The Afternoon http:\/\/t.co\/doaaPDH4JB   New Post ~ Wood Ducks #birds #birding",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cindy",
        "screen_name" : "gemswinc",
        "indices" : [ 20, 29 ],
        "id_str" : "13112692",
        "id" : 13112692
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 100, 106 ]
      }, {
        "text" : "birding",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/doaaPDH4JB",
        "expanded_url" : "http:\/\/bit.ly\/10pTCDr",
        "display_url" : "bit.ly\/10pTCDr"
      } ]
    },
    "geo" : { },
    "id_str" : "350765769702907906",
    "text" : "Wonderful post!! RT @gemswinc: Love In The Afternoon http:\/\/t.co\/doaaPDH4JB   New Post ~ Wood Ducks #birds #birding",
    "id" : 350765769702907906,
    "created_at" : "2013-06-29 00:00:51 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 350766509905281025,
  "created_at" : "2013-06-29 00:03:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "indices" : [ 3, 14 ],
      "id_str" : "105134401",
      "id" : 105134401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350765806134628353",
  "text" : "RT @TimGreaton: As Karen shut the door, she heard an acorn ping off the glass. Damn that squirrel. \"Bones in the Tree\" http:\/\/t.co\/5g0Pok7n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/5g0Pok7nM0",
        "expanded_url" : "http:\/\/goo.gl\/0ZjIN",
        "display_url" : "goo.gl\/0ZjIN"
      } ]
    },
    "geo" : { },
    "id_str" : "350765237198258177",
    "text" : "As Karen shut the door, she heard an acorn ping off the glass. Damn that squirrel. \"Bones in the Tree\" http:\/\/t.co\/5g0Pok7nM0",
    "id" : 350765237198258177,
    "created_at" : "2013-06-28 23:58:44 +0000",
    "user" : {
      "name" : "Tim Greaton",
      "screen_name" : "TimGreaton",
      "protected" : false,
      "id_str" : "105134401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715215268591624194\/1qc9EaQj_normal.jpg",
      "id" : 105134401,
      "verified" : false
    }
  },
  "id" : 350765806134628353,
  "created_at" : "2013-06-29 00:00:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Joeandrasi93\/status\/350758300276641792\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/LKP83T2ffO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN4k0NKCUAALVJ5.jpg",
      "id_str" : "350758300285030400",
      "id" : 350758300285030400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN4k0NKCUAALVJ5.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/LKP83T2ffO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350760449979072512",
  "text" : "RT @Joeandrasi93: Sunset through the trees in the backyard...interesting effect...\n~JJA http:\/\/t.co\/LKP83T2ffO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joeandrasi93\/status\/350758300276641792\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/LKP83T2ffO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BN4k0NKCUAALVJ5.jpg",
        "id_str" : "350758300285030400",
        "id" : 350758300285030400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN4k0NKCUAALVJ5.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/LKP83T2ffO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350758300276641792",
    "text" : "Sunset through the trees in the backyard...interesting effect...\n~JJA http:\/\/t.co\/LKP83T2ffO",
    "id" : 350758300276641792,
    "created_at" : "2013-06-28 23:31:10 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 350760449979072512,
  "created_at" : "2013-06-28 23:39:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 2, 12 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350722522486018048",
  "geo" : { },
  "id_str" : "350723066151710720",
  "in_reply_to_user_id" : 16181537,
  "text" : ". @ZachsMind yup.. your mind\/thoughts\/beliefs can affect your body...",
  "id" : 350723066151710720,
  "in_reply_to_status_id" : 350722522486018048,
  "created_at" : "2013-06-28 21:11:09 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Darling",
      "screen_name" : "dandarling",
      "indices" : [ 10, 21 ],
      "id_str" : "102852362",
      "id" : 102852362
    }, {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 22, 35 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350706483350081536",
  "geo" : { },
  "id_str" : "350710410816651264",
  "in_reply_to_user_id" : 102852362,
  "text" : "agree! RT @dandarling @adamrshields your blog is a must follow for #kindle owners",
  "id" : 350710410816651264,
  "in_reply_to_status_id" : 350706483350081536,
  "created_at" : "2013-06-28 20:20:52 +0000",
  "in_reply_to_screen_name" : "dandarling",
  "in_reply_to_user_id_str" : "102852362",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScottishHighland",
      "indices" : [ 106, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350682937991245824",
  "text" : "RT @ChickenJen: calving season has begun here at the farm; visit our FB page to see some cool pics of our #ScottishHighland cows https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScottishHighland",
        "indices" : [ 90, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/BZtDcEUB9T",
        "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
        "display_url" : "facebook.com\/HighlandFarmsO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350679346295484416",
    "text" : "calving season has begun here at the farm; visit our FB page to see some cool pics of our #ScottishHighland cows https:\/\/t.co\/BZtDcEUB9T",
    "id" : 350679346295484416,
    "created_at" : "2013-06-28 18:17:26 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 350682937991245824,
  "created_at" : "2013-06-28 18:31:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Joeandrasi93\/status\/350679724797857792\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/00NMr1EZKJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BN3dWgsCEAAvhd9.jpg",
      "id_str" : "350679724806246400",
      "id" : 350679724806246400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN3dWgsCEAAvhd9.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/00NMr1EZKJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350682465872003073",
  "text" : "RT @Joeandrasi93: Sunset throught the trees in the backyard...\n~JJA http:\/\/t.co\/00NMr1EZKJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joeandrasi93\/status\/350679724797857792\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/00NMr1EZKJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BN3dWgsCEAAvhd9.jpg",
        "id_str" : "350679724806246400",
        "id" : 350679724806246400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BN3dWgsCEAAvhd9.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/00NMr1EZKJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350679724797857792",
    "text" : "Sunset throught the trees in the backyard...\n~JJA http:\/\/t.co\/00NMr1EZKJ",
    "id" : 350679724797857792,
    "created_at" : "2013-06-28 18:18:56 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 350682465872003073,
  "created_at" : "2013-06-28 18:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350679724797857792",
  "geo" : { },
  "id_str" : "350682433974308865",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 awesome!",
  "id" : 350682433974308865,
  "in_reply_to_status_id" : 350679724797857792,
  "created_at" : "2013-06-28 18:29:42 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kyle",
      "screen_name" : "kyleaustin_",
      "indices" : [ 0, 12 ],
      "id_str" : "62174534",
      "id" : 62174534
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 68, 82 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350671566469742592",
  "geo" : { },
  "id_str" : "350675467226972160",
  "in_reply_to_user_id" : 62174534,
  "text" : "@KyleAustin_ aww.. it was their way of saying you're a good egg : ) @allthewayleft",
  "id" : 350675467226972160,
  "in_reply_to_status_id" : 350671566469742592,
  "created_at" : "2013-06-28 18:02:01 +0000",
  "in_reply_to_screen_name" : "kyleaustin_",
  "in_reply_to_user_id_str" : "62174534",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350660706384879618",
  "geo" : { },
  "id_str" : "350664133835890689",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem ((eyesgoglassyandstartsdrooling))",
  "id" : 350664133835890689,
  "in_reply_to_status_id" : 350660706384879618,
  "created_at" : "2013-06-28 17:16:59 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    }, {
      "name" : "Nicole G. Cloutier",
      "screen_name" : "Lindygeek",
      "indices" : [ 125, 135 ],
      "id_str" : "76247667",
      "id" : 76247667
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WalkingWhileBlack",
      "indices" : [ 106, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350660395867975682",
  "text" : "RT @ZeitgeistGhost: I see no other way to look at it, Z was the aggressor and was after a kid, cuz he was #WalkingWhileBlack @Lindygeek @ha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicole G. Cloutier",
        "screen_name" : "Lindygeek",
        "indices" : [ 105, 115 ],
        "id_str" : "76247667",
        "id" : 76247667
      }, {
        "name" : "Resistance",
        "screen_name" : "happyloner",
        "indices" : [ 116, 127 ],
        "id_str" : "26822709",
        "id" : 26822709
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WalkingWhileBlack",
        "indices" : [ 86, 104 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "350658380106444801",
    "geo" : { },
    "id_str" : "350659108409589760",
    "in_reply_to_user_id" : 76247667,
    "text" : "I see no other way to look at it, Z was the aggressor and was after a kid, cuz he was #WalkingWhileBlack @Lindygeek @happyloner",
    "id" : 350659108409589760,
    "in_reply_to_status_id" : 350658380106444801,
    "created_at" : "2013-06-28 16:57:01 +0000",
    "in_reply_to_screen_name" : "Lindygeek",
    "in_reply_to_user_id_str" : "76247667",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 350660395867975682,
  "created_at" : "2013-06-28 17:02:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chice2501",
      "screen_name" : "OmniPada",
      "indices" : [ 0, 9 ],
      "id_str" : "2559589411",
      "id" : 2559589411
    }, {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 45, 56 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350653457541234688",
  "text" : "@OmniPada she is wonderful, isn't she? &lt;3 @dhammagirl",
  "id" : 350653457541234688,
  "created_at" : "2013-06-28 16:34:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn Abraham \u2730",
      "screen_name" : "Dawn_Abraham",
      "indices" : [ 46, 59 ],
      "id_str" : "15912508",
      "id" : 15912508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350650600737865728",
  "geo" : { },
  "id_str" : "350652171148206081",
  "in_reply_to_user_id" : 15912508,
  "text" : "TBH, i have no idea. prob mixed signals... RT @Dawn_Abraham Your LIFE is your message, What message are YOU sending out to the world? \u30C4",
  "id" : 350652171148206081,
  "in_reply_to_status_id" : 350650600737865728,
  "created_at" : "2013-06-28 16:29:27 +0000",
  "in_reply_to_screen_name" : "Dawn_Abraham",
  "in_reply_to_user_id_str" : "15912508",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "indices" : [ 3, 15 ],
      "id_str" : "106841792",
      "id" : 106841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350641679331627010",
  "text" : "RT @TheDailyHug: Be patient. Remind yourself how valuable it is when others are patient with you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350641293753450496",
    "text" : "Be patient. Remind yourself how valuable it is when others are patient with you.",
    "id" : 350641293753450496,
    "created_at" : "2013-06-28 15:46:13 +0000",
    "user" : {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "protected" : false,
      "id_str" : "106841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644519554\/roundOwlLARGE_normal.png",
      "id" : 106841792,
      "verified" : false
    }
  },
  "id" : 350641679331627010,
  "created_at" : "2013-06-28 15:47:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350641108289720321",
  "text" : "RT @mindymayhem: \"At every single point in time, George Zimmerman was persuing Trayvon Martin with a loaded gun with a bullet in the chambe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350141923882840064",
    "text" : "\"At every single point in time, George Zimmerman was persuing Trayvon Martin with a loaded gun with a bullet in the chamber.\"  Exactly.",
    "id" : 350141923882840064,
    "created_at" : "2013-06-27 06:41:54 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 350641108289720321,
  "created_at" : "2013-06-28 15:45:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 3, 12 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350640517018681344",
  "text" : "RT @Teawench: This bra is really uncomfortable. Why haven't we banned these things?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350638820724715521",
    "text" : "This bra is really uncomfortable. Why haven't we banned these things?",
    "id" : 350638820724715521,
    "created_at" : "2013-06-28 15:36:24 +0000",
    "user" : {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "protected" : false,
      "id_str" : "14986977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2242418648\/lanoire_blond_256x256_normal.jpg",
      "id" : 14986977,
      "verified" : false
    }
  },
  "id" : 350640517018681344,
  "created_at" : "2013-06-28 15:43:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 2, 9 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350624971996921858",
  "geo" : { },
  "id_str" : "350630765492572160",
  "in_reply_to_user_id" : 13118692,
  "text" : ". @moosep o-O well, at least the office called you... need #SinglePayer now!",
  "id" : 350630765492572160,
  "in_reply_to_status_id" : 350624971996921858,
  "created_at" : "2013-06-28 15:04:23 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "indices" : [ 3, 11 ],
      "id_str" : "8192222",
      "id" : 8192222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/JFavhERnZp",
      "expanded_url" : "http:\/\/bit.ly\/150CTYT",
      "display_url" : "bit.ly\/150CTYT"
    } ]
  },
  "geo" : { },
  "id_str" : "350419491685019649",
  "text" : "RT @Jezebel: Why is Rachel Jeantel being treated like she's the one on trial? http:\/\/t.co\/JFavhERnZp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/JFavhERnZp",
        "expanded_url" : "http:\/\/bit.ly\/150CTYT",
        "display_url" : "bit.ly\/150CTYT"
      } ]
    },
    "geo" : { },
    "id_str" : "350399566455128064",
    "text" : "Why is Rachel Jeantel being treated like she's the one on trial? http:\/\/t.co\/JFavhERnZp",
    "id" : 350399566455128064,
    "created_at" : "2013-06-27 23:45:41 +0000",
    "user" : {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "protected" : false,
      "id_str" : "8192222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590580350532845568\/rLGWqV5a_normal.png",
      "id" : 8192222,
      "verified" : true
    }
  },
  "id" : 350419491685019649,
  "created_at" : "2013-06-28 01:04:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350416976155394048",
  "geo" : { },
  "id_str" : "350418804297306113",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth aww.. welcome, wee one.",
  "id" : 350418804297306113,
  "in_reply_to_status_id" : 350416976155394048,
  "created_at" : "2013-06-28 01:02:08 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I voted for Hillary",
      "screen_name" : "utbrp",
      "indices" : [ 3, 9 ],
      "id_str" : "21356559",
      "id" : 21356559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/rXhSWT0wlL",
      "expanded_url" : "http:\/\/www.rolereboot.org\/culture-and-politics\/details\/2013-06-a-letter-to-rachel-jeantel-the-prosecutions-key-witn?fb_action_ids=10200894296572610&fb_action_types=og.likes&fb_aggregation_id=288381481237582#.UczTyS5qOut.twitter",
      "display_url" : "rolereboot.org\/culture-and-po\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "350418145737052160",
  "text" : "RT @utbrp: Hear Hear..A Letter To Rachel Jeantel, The Prosecution's Key Witness In The George Zimmerman Trial: http:\/\/t.co\/rXhSWT0wlL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/rXhSWT0wlL",
        "expanded_url" : "http:\/\/www.rolereboot.org\/culture-and-politics\/details\/2013-06-a-letter-to-rachel-jeantel-the-prosecutions-key-witn?fb_action_ids=10200894296572610&fb_action_types=og.likes&fb_aggregation_id=288381481237582#.UczTyS5qOut.twitter",
        "display_url" : "rolereboot.org\/culture-and-po\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "350405407577088001",
    "text" : "Hear Hear..A Letter To Rachel Jeantel, The Prosecution's Key Witness In The George Zimmerman Trial: http:\/\/t.co\/rXhSWT0wlL",
    "id" : 350405407577088001,
    "created_at" : "2013-06-28 00:08:54 +0000",
    "user" : {
      "name" : "I voted for Hillary",
      "screen_name" : "utbrp",
      "protected" : false,
      "id_str" : "21356559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796313072885448704\/DB-K1dUr_normal.jpg",
      "id" : 21356559,
      "verified" : false
    }
  },
  "id" : 350418145737052160,
  "created_at" : "2013-06-28 00:59:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thatisall",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350395603185971200",
  "text" : "announcement: i have not been fed dinner yet. #thatisall",
  "id" : 350395603185971200,
  "created_at" : "2013-06-27 23:29:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/NSjldAWZpo",
      "expanded_url" : "http:\/\/huff.to\/1aj2Sib",
      "display_url" : "huff.to\/1aj2Sib"
    } ]
  },
  "geo" : { },
  "id_str" : "350380810051915777",
  "text" : "RT @HuffPostWeird: Tapir Penis: All length, no skill, yet completely humbling (VIDEO) http:\/\/t.co\/NSjldAWZpo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/NSjldAWZpo",
        "expanded_url" : "http:\/\/huff.to\/1aj2Sib",
        "display_url" : "huff.to\/1aj2Sib"
      } ]
    },
    "geo" : { },
    "id_str" : "350378058374594560",
    "text" : "Tapir Penis: All length, no skill, yet completely humbling (VIDEO) http:\/\/t.co\/NSjldAWZpo",
    "id" : 350378058374594560,
    "created_at" : "2013-06-27 22:20:13 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 350380810051915777,
  "created_at" : "2013-06-27 22:31:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350368723011502080",
  "text" : "RT @Wolf_Mommy: But breastfeeding has NOTHING to do with flaunting sexuality or being sexy, or letting others know you're sexy. IT'S FEEDIN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350368472842252288",
    "text" : "But breastfeeding has NOTHING to do with flaunting sexuality or being sexy, or letting others know you're sexy. IT'S FEEDING A BABY.",
    "id" : 350368472842252288,
    "created_at" : "2013-06-27 21:42:08 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 350368723011502080,
  "created_at" : "2013-06-27 21:43:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BluZeeWHOAman",
      "screen_name" : "BluZee1",
      "indices" : [ 3, 11 ],
      "id_str" : "499778198",
      "id" : 499778198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350353067566309377",
  "text" : "RT @BluZee1: GOP invades women's lives and uteri across US. Poorly written OH law requires Sonogram &amp; 24-hr wait to get IUD\/bc.Check ur sta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350344020716814337",
    "text" : "GOP invades women's lives and uteri across US. Poorly written OH law requires Sonogram &amp; 24-hr wait to get IUD\/bc.Check ur state&amp;PROTEST",
    "id" : 350344020716814337,
    "created_at" : "2013-06-27 20:04:58 +0000",
    "user" : {
      "name" : "BluZeeWHOAman",
      "screen_name" : "BluZee1",
      "protected" : false,
      "id_str" : "499778198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757361763956367360\/WAKw8jRN_normal.jpg",
      "id" : 499778198,
      "verified" : false
    }
  },
  "id" : 350353067566309377,
  "created_at" : "2013-06-27 20:40:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CFBlaw",
      "screen_name" : "CFB_law",
      "indices" : [ 0, 8 ],
      "id_str" : "405522537",
      "id" : 405522537
    }, {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 31, 42 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350056766349901824",
  "geo" : { },
  "id_str" : "350332979484176384",
  "in_reply_to_user_id" : 405522537,
  "text" : "@CFB_law awww.. precious babe! @Wolf_Mommy",
  "id" : 350332979484176384,
  "in_reply_to_status_id" : 350056766349901824,
  "created_at" : "2013-06-27 19:21:05 +0000",
  "in_reply_to_screen_name" : "CFB_law",
  "in_reply_to_user_id_str" : "405522537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350318591767359488",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny she's an idiot and I do not like her one bit (hey, that kinda rhymes..lol)",
  "id" : 350318591767359488,
  "created_at" : "2013-06-27 18:23:55 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RachelJeantel",
      "indices" : [ 7, 21 ]
    }, {
      "text" : "ZimmermanTrial",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "Trayvon",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "Zimmerman",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350316921104764928",
  "text" : "I hope #RachelJeantel sees or knows she's got a lot of support out here #ZimmermanTrial #Trayvon #Zimmerman",
  "id" : 350316921104764928,
  "created_at" : "2013-06-27 18:17:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0425\u043E\u0440\u043E\u0431\u043E\u0432 \u0410\u043D\u0442\u043E\u043D",
      "screen_name" : "BenHoward87",
      "indices" : [ 3, 15 ],
      "id_str" : "2668736498",
      "id" : 2668736498
    }, {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 95, 108 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350314854013349888",
  "text" : "RT @BenHoward87: \"Sex is a lot like a bacon cheeseburger.\" - Wildly out of context quotes from @micahjmurray",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Micah J. Murray",
        "screen_name" : "micahjmurray",
        "indices" : [ 78, 91 ],
        "id_str" : "94619438",
        "id" : 94619438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350308128170049537",
    "text" : "\"Sex is a lot like a bacon cheeseburger.\" - Wildly out of context quotes from @micahjmurray",
    "id" : 350308128170049537,
    "created_at" : "2013-06-27 17:42:20 +0000",
    "user" : {
      "name" : "Benjamin Howard",
      "screen_name" : "BenHowardOPT",
      "protected" : false,
      "id_str" : "528817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704693542719913985\/x_PfY3SS_normal.jpg",
      "id" : 528817286,
      "verified" : false
    }
  },
  "id" : 350314854013349888,
  "created_at" : "2013-06-27 18:09:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Spike Lou",
      "screen_name" : "IamSPiKELoU",
      "indices" : [ 3, 15 ],
      "id_str" : "24267487",
      "id" : 24267487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350313840799514624",
  "text" : "RT @IamSPiKELoU: Zimmerman trial should have been as simple as this:police said dont follow you did, he was unarmed you shot and killed him\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "guilty",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350284808238276609",
    "text" : "Zimmerman trial should have been as simple as this:police said dont follow you did, he was unarmed you shot and killed him. #guilty",
    "id" : 350284808238276609,
    "created_at" : "2013-06-27 16:09:40 +0000",
    "user" : {
      "name" : "Uncle Spike Lou",
      "screen_name" : "IamSPiKELoU",
      "protected" : false,
      "id_str" : "24267487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797160179276140544\/PfjYSJS7_normal.jpg",
      "id" : 24267487,
      "verified" : false
    }
  },
  "id" : 350313840799514624,
  "created_at" : "2013-06-27 18:05:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    }, {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 84, 97 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/dKWuI9p5l9",
      "expanded_url" : "http:\/\/buff.ly\/1502hhi",
      "display_url" : "buff.ly\/1502hhi"
    } ]
  },
  "geo" : { },
  "id_str" : "350312365599895553",
  "text" : "RT @rachelheldevans: YES! \"Wires are for robots.\" Great post on love &amp; sex from @micahjmurray : http:\/\/t.co\/dKWuI9p5l9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Micah J. Murray",
        "screen_name" : "micahjmurray",
        "indices" : [ 63, 76 ],
        "id_str" : "94619438",
        "id" : 94619438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/dKWuI9p5l9",
        "expanded_url" : "http:\/\/buff.ly\/1502hhi",
        "display_url" : "buff.ly\/1502hhi"
      } ]
    },
    "geo" : { },
    "id_str" : "350310390586015745",
    "text" : "YES! \"Wires are for robots.\" Great post on love &amp; sex from @micahjmurray : http:\/\/t.co\/dKWuI9p5l9",
    "id" : 350310390586015745,
    "created_at" : "2013-06-27 17:51:20 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 350312365599895553,
  "created_at" : "2013-06-27 17:59:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350301640500314115",
  "geo" : { },
  "id_str" : "350302751185567744",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl Nice! : )",
  "id" : 350302751185567744,
  "in_reply_to_status_id" : 350301640500314115,
  "created_at" : "2013-06-27 17:20:58 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 2, 16 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/K3oq0dqVId",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2013\/06\/26\/rick-perry-special-session_n_3505786.html",
      "display_url" : "huffingtonpost.com\/2013\/06\/26\/ric\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "350295729077620736",
  "geo" : { },
  "id_str" : "350298488954826752",
  "in_reply_to_user_id" : 45254966,
  "text" : ". @CharlesBivona .. and he wants to \"protect women\" http:\/\/t.co\/K3oq0dqVId .. that man makes my skin crawl.",
  "id" : 350298488954826752,
  "in_reply_to_status_id" : 350295729077620736,
  "created_at" : "2013-06-27 17:04:02 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Boykin",
      "screen_name" : "keithboykin",
      "indices" : [ 3, 15 ],
      "id_str" : "21728303",
      "id" : 21728303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350282233489268737",
  "text" : "RT @keithboykin: When you follow a pedestrian in a car and then get out of your vehicle and chase them with a loaded gun, you're the aggres\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350277882267959296",
    "text" : "When you follow a pedestrian in a car and then get out of your vehicle and chase them with a loaded gun, you're the aggressor.",
    "id" : 350277882267959296,
    "created_at" : "2013-06-27 15:42:09 +0000",
    "user" : {
      "name" : "Keith Boykin",
      "screen_name" : "keithboykin",
      "protected" : false,
      "id_str" : "21728303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797096359807553537\/2zUaGk4y_normal.jpg",
      "id" : 21728303,
      "verified" : false
    }
  },
  "id" : 350282233489268737,
  "created_at" : "2013-06-27 15:59:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bird",
      "indices" : [ 37, 42 ]
    }, {
      "text" : "bluebirds",
      "indices" : [ 76, 86 ]
    }, {
      "text" : "nature",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/EXVz2oX784",
      "expanded_url" : "http:\/\/ow.ly\/mqhOC",
      "display_url" : "ow.ly\/mqhOC"
    } ]
  },
  "geo" : { },
  "id_str" : "350281489814007808",
  "text" : "RT @KerriFar: A \"Triple Play\" in the #bird world ~ http:\/\/t.co\/EXVz2oX784 ~ #bluebirds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bird",
        "indices" : [ 23, 28 ]
      }, {
        "text" : "bluebirds",
        "indices" : [ 62, 72 ]
      }, {
        "text" : "nature",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/EXVz2oX784",
        "expanded_url" : "http:\/\/ow.ly\/mqhOC",
        "display_url" : "ow.ly\/mqhOC"
      } ]
    },
    "geo" : { },
    "id_str" : "350279195332575233",
    "text" : "A \"Triple Play\" in the #bird world ~ http:\/\/t.co\/EXVz2oX784 ~ #bluebirds #nature",
    "id" : 350279195332575233,
    "created_at" : "2013-06-27 15:47:22 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 350281489814007808,
  "created_at" : "2013-06-27 15:56:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jay smooth",
      "screen_name" : "jsmooth995",
      "indices" : [ 3, 14 ],
      "id_str" : "817113",
      "id" : 817113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350271995012849667",
  "text" : "RT @jsmooth995: Is this not over yet?? As far as I'm concerned Rachel Jeantel is practically on Wendy Davis status at this point. #StandWit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StandWithRachel",
        "indices" : [ 114, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350268173662167042",
    "text" : "Is this not over yet?? As far as I'm concerned Rachel Jeantel is practically on Wendy Davis status at this point. #StandWithRachel",
    "id" : 350268173662167042,
    "created_at" : "2013-06-27 15:03:34 +0000",
    "user" : {
      "name" : "jay smooth",
      "screen_name" : "jsmooth995",
      "protected" : false,
      "id_str" : "817113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783012124490604545\/RO_l3vA9_normal.jpg",
      "id" : 817113,
      "verified" : false
    }
  },
  "id" : 350271995012849667,
  "created_at" : "2013-06-27 15:18:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 2, 15 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350268594174705664",
  "geo" : { },
  "id_str" : "350271689222926336",
  "in_reply_to_user_id" : 25221139,
  "text" : ". @PisseArtiste that could feed a lot of people...",
  "id" : 350271689222926336,
  "in_reply_to_status_id" : 350268594174705664,
  "created_at" : "2013-06-27 15:17:33 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 19, 28 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350271554149560320",
  "text" : "RT @PisseArtiste: \u201C@OMGFacts: It costs 2.41 cents to mint a penny. In 2011, the US lost over $60 million making pennies\u201D Also why Canada sc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OMG Facts",
        "screen_name" : "OMGFacts",
        "indices" : [ 1, 10 ],
        "id_str" : "77888423",
        "id" : 77888423
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "350260579014946817",
    "geo" : { },
    "id_str" : "350268594174705664",
    "in_reply_to_user_id" : 77888423,
    "text" : "\u201C@OMGFacts: It costs 2.41 cents to mint a penny. In 2011, the US lost over $60 million making pennies\u201D Also why Canada scrapped them.",
    "id" : 350268594174705664,
    "in_reply_to_status_id" : 350260579014946817,
    "created_at" : "2013-06-27 15:05:15 +0000",
    "in_reply_to_screen_name" : "OMGFacts",
    "in_reply_to_user_id_str" : "77888423",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 350271554149560320,
  "created_at" : "2013-06-27 15:17:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "indices" : [ 3, 18 ],
      "id_str" : "24165761",
      "id" : 24165761
    }, {
      "name" : "Rachel",
      "screen_name" : "RachelSamara",
      "indices" : [ 33, 46 ],
      "id_str" : "23378739",
      "id" : 23378739
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/7NUheb9lck",
      "expanded_url" : "http:\/\/bit.ly\/11PEcpv",
      "display_url" : "bit.ly\/11PEcpv"
    } ]
  },
  "geo" : { },
  "id_str" : "350261817836175361",
  "text" : "RT @MichaelSkolnik: MUST READ by @RachelSamara: What White People Don't Understand About Rachel Jeantel... http:\/\/t.co\/7NUheb9lck #Zimmerma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachel",
        "screen_name" : "RachelSamara",
        "indices" : [ 13, 26 ],
        "id_str" : "23378739",
        "id" : 23378739
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ZimmermanTrial",
        "indices" : [ 110, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/7NUheb9lck",
        "expanded_url" : "http:\/\/bit.ly\/11PEcpv",
        "display_url" : "bit.ly\/11PEcpv"
      } ]
    },
    "geo" : { },
    "id_str" : "350241864030490624",
    "text" : "MUST READ by @RachelSamara: What White People Don't Understand About Rachel Jeantel... http:\/\/t.co\/7NUheb9lck #ZimmermanTrial",
    "id" : 350241864030490624,
    "created_at" : "2013-06-27 13:19:02 +0000",
    "user" : {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "protected" : false,
      "id_str" : "24165761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738364600220045313\/L-103cVr_normal.jpg",
      "id" : 24165761,
      "verified" : true
    }
  },
  "id" : 350261817836175361,
  "created_at" : "2013-06-27 14:38:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350258552734089218",
  "text" : "RT @Takye_King: Forget race. This guy followed a kid, disobeyed instructions, confronted him, attacked him, and ultimately killed him #zimm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zimmermantrial",
        "indices" : [ 118, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350250864449040384",
    "text" : "Forget race. This guy followed a kid, disobeyed instructions, confronted him, attacked him, and ultimately killed him #zimmermantrial",
    "id" : 350250864449040384,
    "created_at" : "2013-06-27 13:54:48 +0000",
    "user" : {
      "name" : "Ramadan Season",
      "screen_name" : "BallOut300_600",
      "protected" : false,
      "id_str" : "456371392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752500794423848960\/7kdaHgtn_normal.jpg",
      "id" : 456371392,
      "verified" : false
    }
  },
  "id" : 350258552734089218,
  "created_at" : "2013-06-27 14:25:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 0, 14 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350051435091730432",
  "geo" : { },
  "id_str" : "350054170868457473",
  "in_reply_to_user_id" : 1067293117,
  "text" : "@AllOnMedicare Absolutely!",
  "id" : 350054170868457473,
  "in_reply_to_status_id" : 350051435091730432,
  "created_at" : "2013-06-27 00:53:12 +0000",
  "in_reply_to_screen_name" : "AllOnMedicare",
  "in_reply_to_user_id_str" : "1067293117",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350054031156195328",
  "text" : "RT @AllOnMedicare: #SinglePayer is about freedom from fear -- fear of sickness, fear of bankruptcy, fear of pain, fear of insecurity. #Medi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 115, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350051435091730432",
    "text" : "#SinglePayer is about freedom from fear -- fear of sickness, fear of bankruptcy, fear of pain, fear of insecurity. #MedicareForAll",
    "id" : 350051435091730432,
    "created_at" : "2013-06-27 00:42:20 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 350054031156195328,
  "created_at" : "2013-06-27 00:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snow White",
      "screen_name" : "HalfSanePrness",
      "indices" : [ 0, 15 ],
      "id_str" : "400415766",
      "id" : 400415766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350044148302221312",
  "geo" : { },
  "id_str" : "350049536175112192",
  "in_reply_to_user_id" : 400415766,
  "text" : "@HalfSanePrness if its locked account, it wont let you. You can hit reply then copy and paste what you want to RT, tho.",
  "id" : 350049536175112192,
  "in_reply_to_status_id" : 350044148302221312,
  "created_at" : "2013-06-27 00:34:47 +0000",
  "in_reply_to_screen_name" : "HalfSanePrness",
  "in_reply_to_user_id_str" : "400415766",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    }, {
      "name" : "Matt",
      "screen_name" : "HoustonHomo",
      "indices" : [ 15, 27 ],
      "id_str" : "15023042",
      "id" : 15023042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350041167695577088",
  "geo" : { },
  "id_str" : "350042050915348480",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes @HoustonHomo cheers! : )",
  "id" : 350042050915348480,
  "in_reply_to_status_id" : 350041167695577088,
  "created_at" : "2013-06-27 00:05:03 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Machine Gun Belly",
      "screen_name" : "SonnyBlowdro",
      "indices" : [ 3, 16 ],
      "id_str" : "267834856",
      "id" : 267834856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350011539396378624",
  "text" : "RT @SonnyBlowdro: THANK YOU!!!!!  RT @TeddyAlmondy: Ppl can say what they want about Rachel Jeantel, but she's not on trial for murder.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350009805160722434",
    "text" : "THANK YOU!!!!!  RT @TeddyAlmondy: Ppl can say what they want about Rachel Jeantel, but she's not on trial for murder.",
    "id" : 350009805160722434,
    "created_at" : "2013-06-26 21:56:55 +0000",
    "user" : {
      "name" : "Machine Gun Belly",
      "screen_name" : "SonnyBlowdro",
      "protected" : false,
      "id_str" : "267834856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648632560050794496\/ULB9q8WB_normal.png",
      "id" : 267834856,
      "verified" : false
    }
  },
  "id" : 350011539396378624,
  "created_at" : "2013-06-26 22:03:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maddi",
      "screen_name" : "maddimasino",
      "indices" : [ 3, 15 ],
      "id_str" : "22880889",
      "id" : 22880889
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB5",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350003400433344513",
  "text" : "RT @maddimasino: Rick Perry should have to filibuster the ruling in order to get a second special session. #SB5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB5",
        "indices" : [ 90, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350002028967231489",
    "text" : "Rick Perry should have to filibuster the ruling in order to get a second special session. #SB5",
    "id" : 350002028967231489,
    "created_at" : "2013-06-26 21:26:01 +0000",
    "user" : {
      "name" : "maddi",
      "screen_name" : "maddimasino",
      "protected" : false,
      "id_str" : "22880889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750908027276976128\/Ii4Plwg9_normal.jpg",
      "id" : 22880889,
      "verified" : false
    }
  },
  "id" : 350003400433344513,
  "created_at" : "2013-06-26 21:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ziggy Daddy\u2122",
      "screen_name" : "Ziggy_Daddy",
      "indices" : [ 3, 15 ],
      "id_str" : "21691269",
      "id" : 21691269
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TrayvonMartin",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349972749294374912",
  "text" : "RT @Ziggy_Daddy: I keep coming back to the fact that #TrayvonMartin was 17, Black, unarmed and just walking home, breaking no law. #Zimmerm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TrayvonMartin",
        "indices" : [ 36, 50 ]
      }, {
        "text" : "Zimmerman",
        "indices" : [ 114, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349969938833879040",
    "text" : "I keep coming back to the fact that #TrayvonMartin was 17, Black, unarmed and just walking home, breaking no law. #Zimmerman",
    "id" : 349969938833879040,
    "created_at" : "2013-06-26 19:18:30 +0000",
    "user" : {
      "name" : "Ziggy Daddy\u2122",
      "screen_name" : "Ziggy_Daddy",
      "protected" : false,
      "id_str" : "21691269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791470850755092481\/gy6YlnCY_normal.jpg",
      "id" : 21691269,
      "verified" : false
    }
  },
  "id" : 349972749294374912,
  "created_at" : "2013-06-26 19:29:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349970187287670784",
  "text" : "RT @MWM4444: Google the word \"gay.\" It will make you smile.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349967358900707329",
    "text" : "Google the word \"gay.\" It will make you smile.",
    "id" : 349967358900707329,
    "created_at" : "2013-06-26 19:08:15 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 349970187287670784,
  "created_at" : "2013-06-26 19:19:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349969584889139202",
  "text" : "RT @PisseArtiste: I'm pretty sure that no \"neighbourhood watch\" training includes confronting someone. Especially if not in midst of a crim\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349969298871160834",
    "text" : "I'm pretty sure that no \"neighbourhood watch\" training includes confronting someone. Especially if not in midst of a criminal act.",
    "id" : 349969298871160834,
    "created_at" : "2013-06-26 19:15:57 +0000",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 349969584889139202,
  "created_at" : "2013-06-26 19:17:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ILoveMyTroops Too!",
      "screen_name" : "ilovemytroops",
      "indices" : [ 3, 17 ],
      "id_str" : "63355112",
      "id" : 63355112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349963321568534528",
  "text" : "RT @ilovemytroops: Bottomline: Zimmerman made a choice \"this guy looks suspicious\", not b\/c he was breaking into something but simply b\/c h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349953346959978496",
    "text" : "Bottomline: Zimmerman made a choice \"this guy looks suspicious\", not b\/c he was breaking into something but simply b\/c he was WALKING",
    "id" : 349953346959978496,
    "created_at" : "2013-06-26 18:12:34 +0000",
    "user" : {
      "name" : "Tamra M Cronin",
      "screen_name" : "tamranyc",
      "protected" : false,
      "id_str" : "18236427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797214889819242502\/BjXlftVP_normal.jpg",
      "id" : 18236427,
      "verified" : false
    }
  },
  "id" : 349963321568534528,
  "created_at" : "2013-06-26 18:52:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349951524987863040",
  "text" : "RT @micahjmurray: Hey gay people... I'm a Christian and I love you. No disclaimers. Just wanted to get that out there. May the voices of lo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349951217205657602",
    "text" : "Hey gay people... I'm a Christian and I love you. No disclaimers. Just wanted to get that out there. May the voices of love be louder today.",
    "id" : 349951217205657602,
    "created_at" : "2013-06-26 18:04:06 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 349951524987863040,
  "created_at" : "2013-06-26 18:05:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebird",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "birds",
      "indices" : [ 65, 71 ]
    }, {
      "text" : "nature",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/PUyWbToryT",
      "expanded_url" : "http:\/\/ow.ly\/mpC7x",
      "display_url" : "ow.ly\/mpC7x"
    } ]
  },
  "geo" : { },
  "id_str" : "349949481174827009",
  "text" : "RT @KerriFar: #Bluebird with a berry ~ http:\/\/t.co\/PUyWbToryT  ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebird",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "birds",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "nature",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/PUyWbToryT",
        "expanded_url" : "http:\/\/ow.ly\/mpC7x",
        "display_url" : "ow.ly\/mpC7x"
      } ]
    },
    "geo" : { },
    "id_str" : "349941703819534336",
    "text" : "#Bluebird with a berry ~ http:\/\/t.co\/PUyWbToryT  ~ #birds #nature",
    "id" : 349941703819534336,
    "created_at" : "2013-06-26 17:26:18 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 349949481174827009,
  "created_at" : "2013-06-26 17:57:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 3, 15 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349924794956906496",
  "text" : "RT @tommysalami: \"Something about the demeanor of prison officials that tells you they know there's something wrong about executions.\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/fkIRvi6SyS",
        "expanded_url" : "http:\/\/www.opednews.com\/articles\/1\/Why-I-Watch-People-Die-by-Barry-Graham-130214-761.html",
        "display_url" : "opednews.com\/articles\/1\/Why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349924580527312898",
    "text" : "\"Something about the demeanor of prison officials that tells you they know there's something wrong about executions.\" http:\/\/t.co\/fkIRvi6SyS",
    "id" : 349924580527312898,
    "created_at" : "2013-06-26 16:18:15 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 349924794956906496,
  "created_at" : "2013-06-26 16:19:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349923978254614528",
  "text" : "RT @angelaharms: I love you people. I'm so glad you're here.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349922869435834368",
    "text" : "I love you people. I'm so glad you're here.",
    "id" : 349922869435834368,
    "created_at" : "2013-06-26 16:11:27 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 349923978254614528,
  "created_at" : "2013-06-26 16:15:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Hoffman",
      "screen_name" : "matthoffman",
      "indices" : [ 3, 15 ],
      "id_str" : "7219932",
      "id" : 7219932
    }, {
      "name" : "Aetna",
      "screen_name" : "AetnaHelp",
      "indices" : [ 17, 27 ],
      "id_str" : "488810967",
      "id" : 488810967
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349916319707185152",
  "text" : "RT @matthoffman: @AetnaHelp I've never in 15+ years had a 45+ day waiting period on a subscription refil #wtf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aetna",
        "screen_name" : "AetnaHelp",
        "indices" : [ 0, 10 ],
        "id_str" : "488810967",
        "id" : 488810967
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wtf",
        "indices" : [ 88, 92 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "344831511075373056",
    "geo" : { },
    "id_str" : "347235568914137088",
    "in_reply_to_user_id" : 488810967,
    "text" : "@AetnaHelp I've never in 15+ years had a 45+ day waiting period on a subscription refil #wtf",
    "id" : 347235568914137088,
    "in_reply_to_status_id" : 344831511075373056,
    "created_at" : "2013-06-19 06:13:05 +0000",
    "in_reply_to_screen_name" : "AetnaHelp",
    "in_reply_to_user_id_str" : "488810967",
    "user" : {
      "name" : "Matt Hoffman",
      "screen_name" : "matthoffman",
      "protected" : false,
      "id_str" : "7219932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/323845414\/matt_twitter_normal.jpg",
      "id" : 7219932,
      "verified" : false
    }
  },
  "id" : 349916319707185152,
  "created_at" : "2013-06-26 15:45:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joyce bugg",
      "screen_name" : "joyceetta",
      "indices" : [ 26, 36 ],
      "id_str" : "89621202",
      "id" : 89621202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/1ptRxvAkfb",
      "expanded_url" : "http:\/\/huff.to\/1cejbtj",
      "display_url" : "huff.to\/1cejbtj"
    } ]
  },
  "in_reply_to_status_id_str" : "349697533724987392",
  "geo" : { },
  "id_str" : "349699042667802626",
  "in_reply_to_user_id" : 89621202,
  "text" : "need #SinglePayer now! RT @joyceetta Trickery in Missouri Shows How Insurers Enhance Their Profits http:\/\/t.co\/1ptRxvAkfb",
  "id" : 349699042667802626,
  "in_reply_to_status_id" : 349697533724987392,
  "created_at" : "2013-06-26 01:22:03 +0000",
  "in_reply_to_screen_name" : "joyceetta",
  "in_reply_to_user_id_str" : "89621202",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betsy Dewey",
      "screen_name" : "BetsyDeweyTX",
      "indices" : [ 3, 16 ],
      "id_str" : "302720798",
      "id" : 302720798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/lWiPMEoEMQ",
      "expanded_url" : "http:\/\/www.theblaze.com\/stories\/2013\/06\/25\/heartbreaking-suicide-note-from-30-year-old-iraq-veteran-to-his-family-i-am-free\/?utm_source=twitter&utm_medium=story&utm_campaign=Share%20Buttons",
      "display_url" : "theblaze.com\/stories\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349694830093414400",
  "text" : "RT @BetsyDeweyTX: Good read: Suicide Note From 30-Year-Old Iraq Veteran to His Family: \u2018I Am Free\u2019 http:\/\/t.co\/lWiPMEoEMQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/lWiPMEoEMQ",
        "expanded_url" : "http:\/\/www.theblaze.com\/stories\/2013\/06\/25\/heartbreaking-suicide-note-from-30-year-old-iraq-veteran-to-his-family-i-am-free\/?utm_source=twitter&utm_medium=story&utm_campaign=Share%20Buttons",
        "display_url" : "theblaze.com\/stories\/2013\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349692065308876800",
    "text" : "Good read: Suicide Note From 30-Year-Old Iraq Veteran to His Family: \u2018I Am Free\u2019 http:\/\/t.co\/lWiPMEoEMQ",
    "id" : 349692065308876800,
    "created_at" : "2013-06-26 00:54:19 +0000",
    "user" : {
      "name" : "Betsy Dewey",
      "screen_name" : "BetsyDeweyTX",
      "protected" : false,
      "id_str" : "302720798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3198644348\/e84631196962da998e22f720ca7d3a6f_normal.jpeg",
      "id" : 302720798,
      "verified" : false
    }
  },
  "id" : 349694830093414400,
  "created_at" : "2013-06-26 01:05:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Roberts",
      "screen_name" : "nycjim",
      "indices" : [ 3, 10 ],
      "id_str" : "14940354",
      "id" : 14940354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/wUkxpe0oEV",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/thetexastribune?v=2Q8Hr0O20LY&feature=share",
      "display_url" : "youtube.com\/user\/thetexast\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349687544088248322",
  "text" : "RT @nycjim: Still standing: Sen. Wendy Davis continues filibuster against Texas abortion bill. Livestream here:  http:\/\/t.co\/wUkxpe0oEV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/wUkxpe0oEV",
        "expanded_url" : "http:\/\/www.youtube.com\/user\/thetexastribune?v=2Q8Hr0O20LY&feature=share",
        "display_url" : "youtube.com\/user\/thetexast\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349683649853136896",
    "text" : "Still standing: Sen. Wendy Davis continues filibuster against Texas abortion bill. Livestream here:  http:\/\/t.co\/wUkxpe0oEV",
    "id" : 349683649853136896,
    "created_at" : "2013-06-26 00:20:53 +0000",
    "user" : {
      "name" : "Jim Roberts",
      "screen_name" : "nycjim",
      "protected" : false,
      "id_str" : "14940354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3002160609\/84b88a8e6a4fff0cd9b5fb0075bf9fc5_normal.png",
      "id" : 14940354,
      "verified" : true
    }
  },
  "id" : 349687544088248322,
  "created_at" : "2013-06-26 00:36:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taegan Goddard",
      "screen_name" : "politicalwire",
      "indices" : [ 3, 17 ],
      "id_str" : "16250929",
      "id" : 16250929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349687264990859264",
  "text" : "RT @politicalwire: Texas senators now voting on point of order to end filibuster because Sen. Wendy Davis had assistance putting on a back \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349684508414578688",
    "text" : "Texas senators now voting on point of order to end filibuster because Sen. Wendy Davis had assistance putting on a back brace",
    "id" : 349684508414578688,
    "created_at" : "2013-06-26 00:24:18 +0000",
    "user" : {
      "name" : "Taegan Goddard",
      "screen_name" : "politicalwire",
      "protected" : false,
      "id_str" : "16250929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/949739970\/goddard-b_w-snapshot-sm_normal.jpeg",
      "id" : 16250929,
      "verified" : true
    }
  },
  "id" : 349687264990859264,
  "created_at" : "2013-06-26 00:35:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "indices" : [ 3, 15 ],
      "id_str" : "25090088",
      "id" : 25090088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/8DiaMg4TGt",
      "expanded_url" : "http:\/\/io9.com\/what-the-hell-is-going-on-with-these-deer-574312387",
      "display_url" : "io9.com\/what-the-hell-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349620954894303234",
  "text" : "RT @BenMWallace: Thank God they're not sheep. I'd have passed out. http:\/\/t.co\/8DiaMg4TGt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/8DiaMg4TGt",
        "expanded_url" : "http:\/\/io9.com\/what-the-hell-is-going-on-with-these-deer-574312387",
        "display_url" : "io9.com\/what-the-hell-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349617992499335168",
    "text" : "Thank God they're not sheep. I'd have passed out. http:\/\/t.co\/8DiaMg4TGt",
    "id" : 349617992499335168,
    "created_at" : "2013-06-25 19:59:59 +0000",
    "user" : {
      "name" : "Benjamin Wallace",
      "screen_name" : "BenMWallace",
      "protected" : false,
      "id_str" : "25090088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560492072914796544\/pPK5ZIrh_normal.png",
      "id" : 25090088,
      "verified" : false
    }
  },
  "id" : 349620954894303234,
  "created_at" : "2013-06-25 20:11:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Fried",
      "screen_name" : "Robert_Fried",
      "indices" : [ 3, 16 ],
      "id_str" : "33042135",
      "id" : 33042135
    }, {
      "name" : "Customer Service",
      "screen_name" : "Cignaquestions",
      "indices" : [ 18, 33 ],
      "id_str" : "60664714",
      "id" : 60664714
    }, {
      "name" : "Cigna",
      "screen_name" : "Cigna",
      "indices" : [ 34, 40 ],
      "id_str" : "37687077",
      "id" : 37687077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349589330374832128",
  "text" : "RT @Robert_Fried: @Cignaquestions @Cigna Widow declines details. Pt was in CO &amp; CO law requires insurers to cover hospice. How could u say \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Customer Service",
        "screen_name" : "Cignaquestions",
        "indices" : [ 0, 15 ],
        "id_str" : "60664714",
        "id" : 60664714
      }, {
        "name" : "Cigna",
        "screen_name" : "Cigna",
        "indices" : [ 16, 22 ],
        "id_str" : "37687077",
        "id" : 37687077
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "348263624600588288",
    "geo" : { },
    "id_str" : "349366241040936960",
    "in_reply_to_user_id" : 60664714,
    "text" : "@Cignaquestions @Cigna Widow declines details. Pt was in CO &amp; CO law requires insurers to cover hospice. How could u say there's no benefit",
    "id" : 349366241040936960,
    "in_reply_to_status_id" : 348263624600588288,
    "created_at" : "2013-06-25 03:19:37 +0000",
    "in_reply_to_screen_name" : "Cignaquestions",
    "in_reply_to_user_id_str" : "60664714",
    "user" : {
      "name" : "Robert Fried",
      "screen_name" : "Robert_Fried",
      "protected" : false,
      "id_str" : "33042135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/183845552\/bfphoto_normal.JPG",
      "id" : 33042135,
      "verified" : false
    }
  },
  "id" : 349589330374832128,
  "created_at" : "2013-06-25 18:06:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/3d9CcN92mr",
      "expanded_url" : "http:\/\/www.pnhp.org\/news\/2013\/june\/swiss-support-single-payer",
      "display_url" : "pnhp.org\/news\/2013\/june\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349586647811227649",
  "text" : "RT @PNHP: Swiss voters back move from mandate-system to #SinglePayer. Is the US next? http:\/\/t.co\/3d9CcN92mr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 46, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/3d9CcN92mr",
        "expanded_url" : "http:\/\/www.pnhp.org\/news\/2013\/june\/swiss-support-single-payer",
        "display_url" : "pnhp.org\/news\/2013\/june\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349582566631800835",
    "text" : "Swiss voters back move from mandate-system to #SinglePayer. Is the US next? http:\/\/t.co\/3d9CcN92mr",
    "id" : 349582566631800835,
    "created_at" : "2013-06-25 17:39:13 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 349586647811227649,
  "created_at" : "2013-06-25 17:55:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "indices" : [ 3, 11 ],
      "id_str" : "124176955",
      "id" : 124176955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/e6DkKYIscx",
      "expanded_url" : "http:\/\/www.g5e.com\/sale",
      "display_url" : "g5e.com\/sale"
    } ]
  },
  "geo" : { },
  "id_str" : "349549901203513346",
  "text" : "RT @G5games: Now you can collect your FREE gift Epic Adventures: La Jangada on Kindle and Nook as well! Learn more! (http:\/\/t.co\/e6DkKYIscx)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/e6DkKYIscx",
        "expanded_url" : "http:\/\/www.g5e.com\/sale",
        "display_url" : "g5e.com\/sale"
      } ]
    },
    "geo" : { },
    "id_str" : "349543788814938114",
    "text" : "Now you can collect your FREE gift Epic Adventures: La Jangada on Kindle and Nook as well! Learn more! (http:\/\/t.co\/e6DkKYIscx)",
    "id" : 349543788814938114,
    "created_at" : "2013-06-25 15:05:08 +0000",
    "user" : {
      "name" : "G5 Entertainment",
      "screen_name" : "G5games",
      "protected" : false,
      "id_str" : "124176955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554687863338438656\/TlbHHhe4_normal.png",
      "id" : 124176955,
      "verified" : false
    }
  },
  "id" : 349549901203513346,
  "created_at" : "2013-06-25 15:29:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349539004452052992",
  "text" : "RT @BrianMerritt: So now that we are assured by our powerful patrons that our freedom for privacy, assembly, press and voting access are li\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349538186101407745",
    "text" : "So now that we are assured by our powerful patrons that our freedom for privacy, assembly, press and voting access are limited what next?",
    "id" : 349538186101407745,
    "created_at" : "2013-06-25 14:42:52 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 349539004452052992,
  "created_at" : "2013-06-25 14:46:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349534337106067457",
  "text" : "RT @OMGFacts: Scientists believe the Challenger astronauts didn't die from the explosion, but from hitting the water! Details ---&gt; http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/Rno4dbtkHR",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/iPc",
        "display_url" : "omgf.ac\/ts\/iPc"
      } ]
    },
    "geo" : { },
    "id_str" : "349528475935326208",
    "text" : "Scientists believe the Challenger astronauts didn't die from the explosion, but from hitting the water! Details ---&gt; http:\/\/t.co\/Rno4dbtkHR",
    "id" : 349528475935326208,
    "created_at" : "2013-06-25 14:04:17 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 349534337106067457,
  "created_at" : "2013-06-25 14:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Desmond",
      "screen_name" : "dennisdesmond19",
      "indices" : [ 3, 19 ],
      "id_str" : "612329499",
      "id" : 612329499
    }, {
      "name" : "PoliticusUSA",
      "screen_name" : "politicususa",
      "indices" : [ 104, 117 ],
      "id_str" : "14792049",
      "id" : 14792049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/OLGEMVsOaS",
      "expanded_url" : "http:\/\/www.politicususa.com\/2013\/06\/24\/wolf-sheeps-clothing-paul-ryan-sell-caring-poverty.html",
      "display_url" : "politicususa.com\/2013\/06\/24\/wol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349526811144749056",
  "text" : "RT @dennisdesmond19: Paul Ryan Tries to Sell Himself as Caring about Poverty http:\/\/t.co\/OLGEMVsOaS via @politicususa He's Focused on Makin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PoliticusUSA",
        "screen_name" : "politicususa",
        "indices" : [ 83, 96 ],
        "id_str" : "14792049",
        "id" : 14792049
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/OLGEMVsOaS",
        "expanded_url" : "http:\/\/www.politicususa.com\/2013\/06\/24\/wolf-sheeps-clothing-paul-ryan-sell-caring-poverty.html",
        "display_url" : "politicususa.com\/2013\/06\/24\/wol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "349511139467603968",
    "text" : "Paul Ryan Tries to Sell Himself as Caring about Poverty http:\/\/t.co\/OLGEMVsOaS via @politicususa He's Focused on Making MORE Poverty...",
    "id" : 349511139467603968,
    "created_at" : "2013-06-25 12:55:23 +0000",
    "user" : {
      "name" : "Dennis Desmond",
      "screen_name" : "dennisdesmond19",
      "protected" : false,
      "id_str" : "612329499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709072105250230274\/RvzuAZJg_normal.jpg",
      "id" : 612329499,
      "verified" : false
    }
  },
  "id" : 349526811144749056,
  "created_at" : "2013-06-25 13:57:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349348216908689410",
  "geo" : { },
  "id_str" : "349524044523114497",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 i enjoyed it. could have been written better..",
  "id" : 349524044523114497,
  "in_reply_to_status_id" : 349348216908689410,
  "created_at" : "2013-06-25 13:46:40 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/sdA1hch8a6",
      "expanded_url" : "http:\/\/amzn.to\/10PpbJ3",
      "display_url" : "amzn.to\/10PpbJ3"
    } ]
  },
  "geo" : { },
  "id_str" : "349347923697483778",
  "text" : "finished The Afterlife and Times of Herbert S. Cooper by M.D. Cain http:\/\/t.co\/sdA1hch8a6",
  "id" : 349347923697483778,
  "created_at" : "2013-06-25 02:06:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Nasty Assassin \u2620\uFE0F",
      "screen_name" : "AssassinGrl",
      "indices" : [ 18, 30 ],
      "id_str" : "41749124",
      "id" : 41749124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349327542471233536",
  "geo" : { },
  "id_str" : "349328004687724545",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind bravo! @AssassinGrl",
  "id" : 349328004687724545,
  "in_reply_to_status_id" : 349327542471233536,
  "created_at" : "2013-06-25 00:47:41 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Nasty Assassin \u2620\uFE0F",
      "screen_name" : "AssassinGrl",
      "indices" : [ 36, 48 ],
      "id_str" : "41749124",
      "id" : 41749124
    }, {
      "name" : "News Of Rice Lake",
      "screen_name" : "NewsOfRiceLake",
      "indices" : [ 49, 64 ],
      "id_str" : "450107255",
      "id" : 450107255
    }, {
      "name" : "Liberalviewer1",
      "screen_name" : "Liberalviewer1",
      "indices" : [ 65, 80 ],
      "id_str" : "18643191",
      "id" : 18643191
    }, {
      "name" : "Ken Schaefer",
      "screen_name" : "ricelaker",
      "indices" : [ 81, 91 ],
      "id_str" : "22595217",
      "id" : 22595217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349323015282114560",
  "geo" : { },
  "id_str" : "349326135403884545",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind referring to me, eh? ; ) @AssassinGrl @NewsOfRiceLake @Liberalviewer1 @ricelaker",
  "id" : 349326135403884545,
  "in_reply_to_status_id" : 349323015282114560,
  "created_at" : "2013-06-25 00:40:15 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 3, 17 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349324758954950658",
  "text" : "RT @marwilliamson: The world is in trouble. God sent help. God sent you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346788969364721665",
    "text" : "The world is in trouble. God sent help. God sent you.",
    "id" : 346788969364721665,
    "created_at" : "2013-06-18 00:38:27 +0000",
    "user" : {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "protected" : false,
      "id_str" : "21522338",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507257000367882240\/cWcbBvzD_normal.jpeg",
      "id" : 21522338,
      "verified" : true
    }
  },
  "id" : 349324758954950658,
  "created_at" : "2013-06-25 00:34:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salon",
      "screen_name" : "Salon",
      "indices" : [ 3, 9 ],
      "id_str" : "16955991",
      "id" : 16955991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349299301664559105",
  "text" : "RT @Salon: Ridiculous: Christian private school won't let a 12-year-old girl play football because of \"lusting\" male teammates http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/dkMR8Xr2Fn",
        "expanded_url" : "http:\/\/slnm.us\/0pbC9F5",
        "display_url" : "slnm.us\/0pbC9F5"
      } ]
    },
    "geo" : { },
    "id_str" : "349283385149104131",
    "text" : "Ridiculous: Christian private school won't let a 12-year-old girl play football because of \"lusting\" male teammates http:\/\/t.co\/dkMR8Xr2Fn",
    "id" : 349283385149104131,
    "created_at" : "2013-06-24 21:50:23 +0000",
    "user" : {
      "name" : "Salon",
      "screen_name" : "Salon",
      "protected" : false,
      "id_str" : "16955991",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793144947444707328\/obBB1x2a_normal.jpg",
      "id" : 16955991,
      "verified" : true
    }
  },
  "id" : 349299301664559105,
  "created_at" : "2013-06-24 22:53:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Go to @Esquire",
      "screen_name" : "Esquiremag",
      "indices" : [ 71, 82 ],
      "id_str" : "3174214732",
      "id" : 3174214732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/nyOtFmtSrX",
      "expanded_url" : "http:\/\/www.esquire.com\/blogs\/politics\/trayvon-martin-trial-quote-police-interview?src=soc_twtr",
      "display_url" : "esquire.com\/blogs\/politics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349298992510795777",
  "text" : "The Quote That Should End the Trayvon Trial http:\/\/t.co\/nyOtFmtSrX via @EsquireMag",
  "id" : 349298992510795777,
  "created_at" : "2013-06-24 22:52:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349269655933816834",
  "text" : "RT @bookwiseblog: Free Audiobook \u2013 Whodunnit? Murder in Mystery Manor: Whodunnit? Murder in Mystery Manor by Anthony Zuiker\n7 ho... http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/LUwBZr0rOS",
        "expanded_url" : "http:\/\/bit.ly\/15zPwad",
        "display_url" : "bit.ly\/15zPwad"
      } ]
    },
    "geo" : { },
    "id_str" : "349268839617409028",
    "text" : "Free Audiobook \u2013 Whodunnit? Murder in Mystery Manor: Whodunnit? Murder in Mystery Manor by Anthony Zuiker\n7 ho... http:\/\/t.co\/LUwBZr0rOS",
    "id" : 349268839617409028,
    "created_at" : "2013-06-24 20:52:35 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 349269655933816834,
  "created_at" : "2013-06-24 20:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/6WxmEp0ORP",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/06\/24\/opinion\/drexler-four-day-workweek\/index.html?sr=sharebar_twitter",
      "display_url" : "cnn.com\/2013\/06\/24\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "349262914680664064",
  "text" : "Why four-day workweeks are best http:\/\/t.co\/6WxmEp0ORP",
  "id" : 349262914680664064,
  "created_at" : "2013-06-24 20:29:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349254480023404545",
  "text" : "@Smart_BMW yup @Llimoner_",
  "id" : 349254480023404545,
  "created_at" : "2013-06-24 19:55:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC New York",
      "screen_name" : "NBCNewYork",
      "indices" : [ 3, 14 ],
      "id_str" : "15864446",
      "id" : 15864446
    }, {
      "name" : "Brian Thompson",
      "screen_name" : "brian4NY",
      "indices" : [ 81, 90 ],
      "id_str" : "22000141",
      "id" : 22000141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NBC4NY",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349253856988905474",
  "text" : "RT @NBCNewYork: NJ couple gets ticket after bird feeders attract other wildlife. @Brian4NY has the story on #NBC4NY at 6. http:\/\/t.co\/fv6UD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Thompson",
        "screen_name" : "brian4NY",
        "indices" : [ 65, 74 ],
        "id_str" : "22000141",
        "id" : 22000141
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NBC4NY",
        "indices" : [ 92, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/fv6UDYAMzk",
        "expanded_url" : "http:\/\/bit.ly\/19lNOkf",
        "display_url" : "bit.ly\/19lNOkf"
      } ]
    },
    "geo" : { },
    "id_str" : "349251658670276609",
    "text" : "NJ couple gets ticket after bird feeders attract other wildlife. @Brian4NY has the story on #NBC4NY at 6. http:\/\/t.co\/fv6UDYAMzk",
    "id" : 349251658670276609,
    "created_at" : "2013-06-24 19:44:18 +0000",
    "user" : {
      "name" : "NBC New York",
      "screen_name" : "NBCNewYork",
      "protected" : false,
      "id_str" : "15864446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767715187491217408\/rEi3ozQZ_normal.jpg",
      "id" : 15864446,
      "verified" : true
    }
  },
  "id" : 349253856988905474,
  "created_at" : "2013-06-24 19:53:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349249198409007106",
  "geo" : { },
  "id_str" : "349251125041569792",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench awww.. hope SP is ok. what a good egg. : )",
  "id" : 349251125041569792,
  "in_reply_to_status_id" : 349249198409007106,
  "created_at" : "2013-06-24 19:42:11 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imslow",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349244206117699587",
  "geo" : { },
  "id_str" : "349247576601661440",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos ooooohhhhhhh... LOL  #imslow",
  "id" : 349247576601661440,
  "in_reply_to_status_id" : 349244206117699587,
  "created_at" : "2013-06-24 19:28:05 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349227905051672577",
  "geo" : { },
  "id_str" : "349229188865212416",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos does dd resemble something else? i picked it up from online peeps.. dh, dd, ds.. hubby, dau, son.",
  "id" : 349229188865212416,
  "in_reply_to_status_id" : 349227905051672577,
  "created_at" : "2013-06-24 18:15:01 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    }, {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 17, 27 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    }, {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 59, 75 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349215872713359363",
  "geo" : { },
  "id_str" : "349216683329724416",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos @CubeMelon DD= Dear Daughter : ) &gt;&gt; @JourneyTheHedgi",
  "id" : 349216683329724416,
  "in_reply_to_status_id" : 349215872713359363,
  "created_at" : "2013-06-24 17:25:20 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Inman",
      "screen_name" : "Oatmeal",
      "indices" : [ 96, 104 ],
      "id_str" : "4519121",
      "id" : 4519121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/MPdtGV4OYz",
      "expanded_url" : "http:\/\/theoatmeal.com\/comics\/wwz",
      "display_url" : "theoatmeal.com\/comics\/wwz"
    } ]
  },
  "geo" : { },
  "id_str" : "349213886932717568",
  "text" : "What the World War Z movie has in common with the book - The Oatmeal http:\/\/t.co\/MPdtGV4OYz via @Oatmeal",
  "id" : 349213886932717568,
  "created_at" : "2013-06-24 17:14:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "plantchats",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349204603784531968",
  "geo" : { },
  "id_str" : "349207065941647360",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen reading that made me LOL.. \"hmm.. should we blossom yet?\" #plantchats",
  "id" : 349207065941647360,
  "in_reply_to_status_id" : 349204603784531968,
  "created_at" : "2013-06-24 16:47:07 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 4, 14 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    }, {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 15, 31 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349206316658601984",
  "text" : "hey @CubeMelon @shoeofallcosmos my DD 18yo added you to AC. 279320161560",
  "id" : 349206316658601984,
  "created_at" : "2013-06-24 16:44:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348993297471139840",
  "text" : "i think dh and i made new friends w another couple..lol",
  "id" : 348993297471139840,
  "created_at" : "2013-06-24 02:37:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    }, {
      "name" : "Vine App",
      "screen_name" : "vineapp",
      "indices" : [ 49, 57 ],
      "id_str" : "2817472030",
      "id" : 2817472030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348834772019191809",
  "geo" : { },
  "id_str" : "348835662931316736",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen awwwww... : ) (that would be a great @vineapp moment..lol)",
  "id" : 348835662931316736,
  "in_reply_to_status_id" : 348834772019191809,
  "created_at" : "2013-06-23 16:11:17 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348813762909843456",
  "geo" : { },
  "id_str" : "348814455007760384",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 omg.. that man ruffles my feathers. no compassion at all.",
  "id" : 348814455007760384,
  "in_reply_to_status_id" : 348813762909843456,
  "created_at" : "2013-06-23 14:47:01 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amsterdamred",
      "screen_name" : "amsterdamred",
      "indices" : [ 0, 13 ],
      "id_str" : "14529776",
      "id" : 14529776
    }, {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 14, 24 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348782468041670656",
  "geo" : { },
  "id_str" : "348813485787992065",
  "in_reply_to_user_id" : 14529776,
  "text" : "@amsterdamred @bend_time it still irks me about real cold medicine.. signing for it. the new stuff doesnt work.",
  "id" : 348813485787992065,
  "in_reply_to_status_id" : 348782468041670656,
  "created_at" : "2013-06-23 14:43:10 +0000",
  "in_reply_to_screen_name" : "amsterdamred",
  "in_reply_to_user_id_str" : "14529776",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amsterdamred",
      "screen_name" : "amsterdamred",
      "indices" : [ 3, 16 ],
      "id_str" : "14529776",
      "id" : 14529776
    }, {
      "name" : "Target",
      "screen_name" : "Target",
      "indices" : [ 27, 34 ],
      "id_str" : "89084561",
      "id" : 89084561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348813071080366081",
  "text" : "RT @amsterdamred: I was in @Target The cashier wouldn't let me a 52 yo buy a pack of lighters without showing my ID which he scanned. Can b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Target",
        "screen_name" : "Target",
        "indices" : [ 9, 16 ],
        "id_str" : "89084561",
        "id" : 89084561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348782468041670656",
    "text" : "I was in @Target The cashier wouldn't let me a 52 yo buy a pack of lighters without showing my ID which he scanned. Can buy Gun anywhere????",
    "id" : 348782468041670656,
    "created_at" : "2013-06-23 12:39:55 +0000",
    "user" : {
      "name" : "amsterdamred",
      "screen_name" : "amsterdamred",
      "protected" : false,
      "id_str" : "14529776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000382994634\/c27ff2d2ded3bc6801d483611e75f1a9_normal.jpeg",
      "id" : 14529776,
      "verified" : false
    }
  },
  "id" : 348813071080366081,
  "created_at" : "2013-06-23 14:41:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348804806766387200",
  "geo" : { },
  "id_str" : "348811923153879040",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits LOLOL ; )",
  "id" : 348811923153879040,
  "in_reply_to_status_id" : 348804806766387200,
  "created_at" : "2013-06-23 14:36:57 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348810166361276417",
  "text" : "dd, 18yo and still a baby. too much excitement yesterday. spent O\/N at new friend's house. now doesn't feel good. : (",
  "id" : 348810166361276417,
  "created_at" : "2013-06-23 14:29:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348624523618291713",
  "text" : "@statue_dog thats a good sign.. I'll take it! : )",
  "id" : 348624523618291713,
  "created_at" : "2013-06-23 02:12:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348621653770649600",
  "text" : "RT @_NealeDWalsch: There is a solution to all of this--and it is around the next corner. A few years from now, you will wonder why you worr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348621440779698176",
    "text" : "There is a solution to all of this--and it is around the next corner. A few years from now, you will wonder why you worried so much.",
    "id" : 348621440779698176,
    "created_at" : "2013-06-23 02:00:03 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 348621653770649600,
  "created_at" : "2013-06-23 02:00:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348620710350049280",
  "text" : "@statue_dog poor wallace!",
  "id" : 348620710350049280,
  "created_at" : "2013-06-23 01:57:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 3, 16 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348613806857007104",
  "text" : "RT @damienechols: People will try to talk you out of what the universe has put in your heart.\nDo not listen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348612699648827392",
    "text" : "People will try to talk you out of what the universe has put in your heart.\nDo not listen.",
    "id" : 348612699648827392,
    "created_at" : "2013-06-23 01:25:19 +0000",
    "user" : {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "protected" : false,
      "id_str" : "358311362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/609108059672207360\/Sjt-098M_normal.jpg",
      "id" : 358311362,
      "verified" : true
    }
  },
  "id" : 348613806857007104,
  "created_at" : "2013-06-23 01:29:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348613478828871681",
  "text" : "not a bad day at all. went to nephew's grad then travelled a bit for a separate grad party. got fed and met some nice ppl. : )",
  "id" : 348613478828871681,
  "created_at" : "2013-06-23 01:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348431854891847680",
  "text" : "hubby still does not understand women and time... o-O",
  "id" : 348431854891847680,
  "created_at" : "2013-06-22 13:26:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIANA LYNN BLOKZYL",
      "screen_name" : "NANDEE218",
      "indices" : [ 3, 13 ],
      "id_str" : "34824802",
      "id" : 34824802
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NANDEE218\/status\/348245136037269505\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/e2OCL8KIvS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BNU3GyyCUAA727-.jpg",
      "id_str" : "348245136041463808",
      "id" : 348245136041463808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNU3GyyCUAA727-.jpg",
      "sizes" : [ {
        "h" : 840,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/e2OCL8KIvS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348253206830252032",
  "text" : "RT @NANDEE218: WTF Iowa Governor will decide case by case if a woman can get an abortion. http:\/\/t.co\/e2OCL8KIvS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NANDEE218\/status\/348245136037269505\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/e2OCL8KIvS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BNU3GyyCUAA727-.jpg",
        "id_str" : "348245136041463808",
        "id" : 348245136041463808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BNU3GyyCUAA727-.jpg",
        "sizes" : [ {
          "h" : 840,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/e2OCL8KIvS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348245136037269505",
    "text" : "WTF Iowa Governor will decide case by case if a woman can get an abortion. http:\/\/t.co\/e2OCL8KIvS",
    "id" : 348245136037269505,
    "created_at" : "2013-06-22 01:04:45 +0000",
    "user" : {
      "name" : "DIANA LYNN BLOKZYL",
      "screen_name" : "NANDEE218",
      "protected" : false,
      "id_str" : "34824802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747292427052953602\/8pbYxTtM_normal.jpg",
      "id" : 34824802,
      "verified" : false
    }
  },
  "id" : 348253206830252032,
  "created_at" : "2013-06-22 01:36:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MKW",
      "screen_name" : "rugcernie",
      "indices" : [ 0, 10 ],
      "id_str" : "80196269",
      "id" : 80196269
    }, {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 122, 136 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348222814383386625",
  "geo" : { },
  "id_str" : "348237561556250624",
  "in_reply_to_user_id" : 80196269,
  "text" : "@rugcernie i didnt mean to.. degrade?.. your comment, just adding my take. myself, dont feel health ins can work for all. @AllOnMedicare",
  "id" : 348237561556250624,
  "in_reply_to_status_id" : 348222814383386625,
  "created_at" : "2013-06-22 00:34:39 +0000",
  "in_reply_to_screen_name" : "rugcernie",
  "in_reply_to_user_id_str" : "80196269",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MKW",
      "screen_name" : "rugcernie",
      "indices" : [ 29, 39 ],
      "id_str" : "80196269",
      "id" : 80196269
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348203660347572224",
  "geo" : { },
  "id_str" : "348211076392960001",
  "in_reply_to_user_id" : 80196269,
  "text" : "access to HC #SinglePayer RT @rugcernie Very thankful to have health insurance today -- everybody should have it.",
  "id" : 348211076392960001,
  "in_reply_to_status_id" : 348203660347572224,
  "created_at" : "2013-06-21 22:49:24 +0000",
  "in_reply_to_screen_name" : "rugcernie",
  "in_reply_to_user_id_str" : "80196269",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348207458503753728",
  "geo" : { },
  "id_str" : "348210379576446976",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields dh is def a beer snob. he loves his Guinness..lol",
  "id" : 348210379576446976,
  "in_reply_to_status_id" : 348207458503753728,
  "created_at" : "2013-06-21 22:46:38 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348189535013847040",
  "text" : "RT @CoyoteSings: In elections, there should be a None of the Above choice, and if NOTA wins, we should have to do the election over. #justs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "justsaying",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "348189071438409728",
    "text" : "In elections, there should be a None of the Above choice, and if NOTA wins, we should have to do the election over. #justsaying...",
    "id" : 348189071438409728,
    "created_at" : "2013-06-21 21:21:58 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 348189535013847040,
  "created_at" : "2013-06-21 21:23:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Matthew Paul Turner",
      "screen_name" : "JesusNeedsNewPR",
      "indices" : [ 43, 59 ],
      "id_str" : "727580030084251648",
      "id" : 727580030084251648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/40OdsLxyAd",
      "expanded_url" : "http:\/\/instagram.com\/p\/a1MuWNB4SG\/",
      "display_url" : "instagram.com\/p\/a1MuWNB4SG\/"
    } ]
  },
  "geo" : { },
  "id_str" : "348148991713742852",
  "text" : "RT @micahjmurray: HOW IS THIS REAL?? \/\/ MT @JesusNeedsNewPR: \"Let's lift up our voices and sing about Hell.\" http:\/\/t.co\/40OdsLxyAd\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Paul Turner",
        "screen_name" : "JesusNeedsNewPR",
        "indices" : [ 25, 41 ],
        "id_str" : "727580030084251648",
        "id" : 727580030084251648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/40OdsLxyAd",
        "expanded_url" : "http:\/\/instagram.com\/p\/a1MuWNB4SG\/",
        "display_url" : "instagram.com\/p\/a1MuWNB4SG\/"
      } ]
    },
    "geo" : { },
    "id_str" : "348148337733681153",
    "text" : "HOW IS THIS REAL?? \/\/ MT @JesusNeedsNewPR: \"Let's lift up our voices and sing about Hell.\" http:\/\/t.co\/40OdsLxyAd\u201D",
    "id" : 348148337733681153,
    "created_at" : "2013-06-21 18:40:06 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 348148991713742852,
  "created_at" : "2013-06-21 18:42:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "indices" : [ 3, 15 ],
      "id_str" : "18761076",
      "id" : 18761076
    }, {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 75, 88 ],
      "id_str" : "14124789",
      "id" : 14124789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348148789850284032",
  "text" : "RT @PocketGamer: Fancy 1 of 6 early access codes to Dark Manor on iOS from @bigfishgames? RT this and make sure you're following us - http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Big Fish Games",
        "screen_name" : "bigfishgames",
        "indices" : [ 58, 71 ],
        "id_str" : "14124789",
        "id" : 14124789
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/SJGpHaGWs4",
        "expanded_url" : "http:\/\/youtu.be\/iySqG1f6PR0",
        "display_url" : "youtu.be\/iySqG1f6PR0"
      } ]
    },
    "geo" : { },
    "id_str" : "348101117827235840",
    "text" : "Fancy 1 of 6 early access codes to Dark Manor on iOS from @bigfishgames? RT this and make sure you're following us - http:\/\/t.co\/SJGpHaGWs4",
    "id" : 348101117827235840,
    "created_at" : "2013-06-21 15:32:28 +0000",
    "user" : {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "protected" : false,
      "id_str" : "18761076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479184281449660417\/JEbx7R5G_normal.jpeg",
      "id" : 18761076,
      "verified" : false
    }
  },
  "id" : 348148789850284032,
  "created_at" : "2013-06-21 18:41:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/bqPtHnLTeN",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/3Kg",
      "display_url" : "omgf.ac\/ts\/3Kg"
    } ]
  },
  "geo" : { },
  "id_str" : "348117495477059586",
  "text" : "RT @OMGFacts: Our universe could be inside a larger universe! Details ---&gt; http:\/\/t.co\/bqPtHnLTeN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/bqPtHnLTeN",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/3Kg",
        "display_url" : "omgf.ac\/ts\/3Kg"
      } ]
    },
    "geo" : { },
    "id_str" : "348117083722244096",
    "text" : "Our universe could be inside a larger universe! Details ---&gt; http:\/\/t.co\/bqPtHnLTeN",
    "id" : 348117083722244096,
    "created_at" : "2013-06-21 16:35:55 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 348117495477059586,
  "created_at" : "2013-06-21 16:37:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348116829388013568",
  "geo" : { },
  "id_str" : "348117157151928321",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields me, too!",
  "id" : 348117157151928321,
  "in_reply_to_status_id" : 348116829388013568,
  "created_at" : "2013-06-21 16:36:12 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348114411531169792",
  "text" : "@1stCitizenKane are you high?? lol ; )",
  "id" : 348114411531169792,
  "created_at" : "2013-06-21 16:25:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/zyJCrExlbQ",
      "expanded_url" : "http:\/\/getapp.cc\/app\/345752934",
      "display_url" : "getapp.cc\/app\/345752934"
    } ]
  },
  "geo" : { },
  "id_str" : "348077525597036544",
  "text" : "RT @AppAdvice: Retweet now for a chance to win feature-rich iPhone camera app Camera Plus Pro (http:\/\/t.co\/zyJCrExlbQ)!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/zyJCrExlbQ",
        "expanded_url" : "http:\/\/getapp.cc\/app\/345752934",
        "display_url" : "getapp.cc\/app\/345752934"
      } ]
    },
    "geo" : { },
    "id_str" : "348076971718234112",
    "text" : "Retweet now for a chance to win feature-rich iPhone camera app Camera Plus Pro (http:\/\/t.co\/zyJCrExlbQ)!",
    "id" : 348076971718234112,
    "created_at" : "2013-06-21 13:56:31 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 348077525597036544,
  "created_at" : "2013-06-21 13:58:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    }, {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 65, 77 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/5XkjqjfSDK",
      "expanded_url" : "http:\/\/buff.ly\/1c3Fxh1",
      "display_url" : "buff.ly\/1c3Fxh1"
    } ]
  },
  "geo" : { },
  "id_str" : "348074958838181888",
  "text" : "RT @rachelheldevans: Lifeway treats female pastors like porn (by @nakedpastor) http:\/\/t.co\/5XkjqjfSDK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Hayward",
        "screen_name" : "nakedpastor",
        "indices" : [ 44, 56 ],
        "id_str" : "35213582",
        "id" : 35213582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/5XkjqjfSDK",
        "expanded_url" : "http:\/\/buff.ly\/1c3Fxh1",
        "display_url" : "buff.ly\/1c3Fxh1"
      } ]
    },
    "geo" : { },
    "id_str" : "348072750700699648",
    "text" : "Lifeway treats female pastors like porn (by @nakedpastor) http:\/\/t.co\/5XkjqjfSDK",
    "id" : 348072750700699648,
    "created_at" : "2013-06-21 13:39:45 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 348074958838181888,
  "created_at" : "2013-06-21 13:48:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348071202897678336",
  "geo" : { },
  "id_str" : "348071736077594624",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits now this is my kinda tweet.. love it! : )",
  "id" : 348071736077594624,
  "in_reply_to_status_id" : 348071202897678336,
  "created_at" : "2013-06-21 13:35:43 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348071262897197057",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny just stopping by your timeline to say hello and throw flowers at you... :D",
  "id" : 348071262897197057,
  "created_at" : "2013-06-21 13:33:50 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348067540355936258",
  "geo" : { },
  "id_str" : "348070558975545345",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time oh yes. our ac has very recently developed this symptom as well. quite annoying.",
  "id" : 348070558975545345,
  "in_reply_to_status_id" : 348067540355936258,
  "created_at" : "2013-06-21 13:31:02 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348067726591406080",
  "geo" : { },
  "id_str" : "348070253844119552",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist omg.. i'd want to smack her.",
  "id" : 348070253844119552,
  "in_reply_to_status_id" : 348067726591406080,
  "created_at" : "2013-06-21 13:29:50 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "348053205919338497",
  "text" : "RT @nakedpastor: HEHEHE Two frogs and one little insect. \"Still Alive Between Theism and Atheism\". Is this you? It's me! http:\/\/t.co\/BtRtBZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/BtRtBZjVu5",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/nakedpastor\/2013\/06\/still-alive-between-theism-and-atheism\/",
        "display_url" : "patheos.com\/blogs\/nakedpas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "348049468781907968",
    "text" : "HEHEHE Two frogs and one little insect. \"Still Alive Between Theism and Atheism\". Is this you? It's me! http:\/\/t.co\/BtRtBZjVu5",
    "id" : 348049468781907968,
    "created_at" : "2013-06-21 12:07:14 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 348053205919338497,
  "created_at" : "2013-06-21 12:22:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/9I7k2Zf26U",
      "expanded_url" : "http:\/\/amzn.to\/hui627",
      "display_url" : "amzn.to\/hui627"
    } ]
  },
  "geo" : { },
  "id_str" : "347894809102532609",
  "text" : "finished Implant by Jeffrey Anderson and Michael Wallace http:\/\/t.co\/9I7k2Zf26U",
  "id" : 347894809102532609,
  "created_at" : "2013-06-21 01:52:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347746842320175104",
  "geo" : { },
  "id_str" : "347833070747017216",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 is wallace eating? kitty smooches!",
  "id" : 347833070747017216,
  "in_reply_to_status_id" : 347746842320175104,
  "created_at" : "2013-06-20 21:47:21 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347826770478784512",
  "geo" : { },
  "id_str" : "347831081040486401",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses dh took pity on me and just got me my chocolate peanut butter : D",
  "id" : 347831081040486401,
  "in_reply_to_status_id" : 347826770478784512,
  "created_at" : "2013-06-20 21:39:26 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 0, 12 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 13, 25 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347406834161819648",
  "geo" : { },
  "id_str" : "347788828293087233",
  "in_reply_to_user_id" : 229428507,
  "text" : "@Floridaline @VirgoJohnny sigghh ((headtodesk))",
  "id" : 347788828293087233,
  "in_reply_to_status_id" : 347406834161819648,
  "created_at" : "2013-06-20 18:51:32 +0000",
  "in_reply_to_screen_name" : "Floridaline",
  "in_reply_to_user_id_str" : "229428507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "indices" : [ 3, 13 ],
      "id_str" : "15395727",
      "id" : 15395727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/wR0jK4dq8L",
      "expanded_url" : "http:\/\/getapp.cc\/app\/605486166",
      "display_url" : "getapp.cc\/app\/605486166"
    } ]
  },
  "geo" : { },
  "id_str" : "347776829412745217",
  "text" : "RT @AppAdvice: Retweet now for a chance to win universal app iKnowBirdSongs (http:\/\/t.co\/wR0jK4dq8L) and become a bird song expert!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/wR0jK4dq8L",
        "expanded_url" : "http:\/\/getapp.cc\/app\/605486166",
        "display_url" : "getapp.cc\/app\/605486166"
      } ]
    },
    "geo" : { },
    "id_str" : "347771651645132800",
    "text" : "Retweet now for a chance to win universal app iKnowBirdSongs (http:\/\/t.co\/wR0jK4dq8L) and become a bird song expert!",
    "id" : 347771651645132800,
    "created_at" : "2013-06-20 17:43:17 +0000",
    "user" : {
      "name" : "AppAdvice.com",
      "screen_name" : "AppAdvice",
      "protected" : false,
      "id_str" : "15395727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586243861485191168\/7BwTcomF_normal.png",
      "id" : 15395727,
      "verified" : true
    }
  },
  "id" : 347776829412745217,
  "created_at" : "2013-06-20 18:03:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347768144993062913",
  "text" : "RT @Buddhaworld: Dont look for answers, because there are none. Just be, just become, just go. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347766611513589760",
    "text" : "Dont look for answers, because there are none. Just be, just become, just go. Buddha volko",
    "id" : 347766611513589760,
    "created_at" : "2013-06-20 17:23:16 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 347768144993062913,
  "created_at" : "2013-06-20 17:29:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347761734112669696",
  "text" : "stuff has got to happen for other stuff to happen.. so.. we are right on schedule. do not worry, precious ones.",
  "id" : 347761734112669696,
  "created_at" : "2013-06-20 17:03:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "taschekats",
      "screen_name" : "taschekats",
      "indices" : [ 3, 14 ],
      "id_str" : "74211986",
      "id" : 74211986
    }, {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 123, 128 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "summer",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/zuUd1VtP48",
      "expanded_url" : "http:\/\/etsy.me\/ZmBUNk",
      "display_url" : "etsy.me\/ZmBUNk"
    } ]
  },
  "geo" : { },
  "id_str" : "347745966167830528",
  "text" : "RT @taschekats: Cotton sundress with fuschia pink tulips on a pink background fashion for women http:\/\/t.co\/zuUd1VtP48 via @Etsy #summer #g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Etsy",
        "screen_name" : "Etsy",
        "indices" : [ 107, 112 ],
        "id_str" : "11522502",
        "id" : 11522502
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "summer",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "gardening",
        "indices" : [ 121, 131 ]
      }, {
        "text" : "twikle",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/zuUd1VtP48",
        "expanded_url" : "http:\/\/etsy.me\/ZmBUNk",
        "display_url" : "etsy.me\/ZmBUNk"
      } ]
    },
    "geo" : { },
    "id_str" : "347744837208002560",
    "text" : "Cotton sundress with fuschia pink tulips on a pink background fashion for women http:\/\/t.co\/zuUd1VtP48 via @Etsy #summer #gardening #twikle",
    "id" : 347744837208002560,
    "created_at" : "2013-06-20 15:56:44 +0000",
    "user" : {
      "name" : "taschekats",
      "screen_name" : "taschekats",
      "protected" : false,
      "id_str" : "74211986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476766776236056577\/BuettfNu_normal.jpeg",
      "id" : 74211986,
      "verified" : false
    }
  },
  "id" : 347745966167830528,
  "created_at" : "2013-06-20 16:01:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347744186155540482",
  "geo" : { },
  "id_str" : "347745086039273473",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits ppl get this righteous attitude \"when we were kids...\" blahblahblah. well, the world was different!",
  "id" : 347745086039273473,
  "in_reply_to_status_id" : 347744186155540482,
  "created_at" : "2013-06-20 15:57:43 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347741077094166528",
  "text" : "the world is ever changing.. we must change with it. ppl seem to think they can keep things the same (\"it used to be...\")",
  "id" : 347741077094166528,
  "created_at" : "2013-06-20 15:41:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347739620160716801",
  "text" : "how can we ever find ourselves when we are constantly changing? .. we can't.",
  "id" : 347739620160716801,
  "created_at" : "2013-06-20 15:36:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SamF",
      "screen_name" : "virtusetveritas",
      "indices" : [ 3, 19 ],
      "id_str" : "3000311524",
      "id" : 3000311524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/9npafAaEhY",
      "expanded_url" : "http:\/\/wp.me\/p372Ye-8W",
      "display_url" : "wp.me\/p372Ye-8W"
    } ]
  },
  "geo" : { },
  "id_str" : "347739259240841219",
  "text" : "RT @virtusetveritas: Ovulation, Zygotes, and Implantations, oh my! How the Pill *actually* works http:\/\/t.co\/9npafAaEhY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/9npafAaEhY",
        "expanded_url" : "http:\/\/wp.me\/p372Ye-8W",
        "display_url" : "wp.me\/p372Ye-8W"
      } ]
    },
    "geo" : { },
    "id_str" : "347737853943492611",
    "text" : "Ovulation, Zygotes, and Implantations, oh my! How the Pill *actually* works http:\/\/t.co\/9npafAaEhY",
    "id" : 347737853943492611,
    "created_at" : "2013-06-20 15:28:59 +0000",
    "user" : {
      "name" : "Samantha Field",
      "screen_name" : "samanthapfield",
      "protected" : false,
      "id_str" : "189759304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685304167343079424\/nPXaHsll_normal.jpg",
      "id" : 189759304,
      "verified" : false
    }
  },
  "id" : 347739259240841219,
  "created_at" : "2013-06-20 15:34:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347737770778820610",
  "text" : "RT @derekrootboy: Despite the fact Michael Hastings untimely death MAY be an accident, a coincidence, safest thing to do is ask questions c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347736465180090369",
    "text" : "Despite the fact Michael Hastings untimely death MAY be an accident, a coincidence, safest thing to do is ask questions cowards hacks won't.",
    "id" : 347736465180090369,
    "created_at" : "2013-06-20 15:23:28 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 347737770778820610,
  "created_at" : "2013-06-20 15:28:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MealsOnWheels",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/oa2eNAeuDr",
      "expanded_url" : "http:\/\/ow.ly\/mbvIM",
      "display_url" : "ow.ly\/mbvIM"
    } ]
  },
  "geo" : { },
  "id_str" : "347736952856002560",
  "text" : "RT @SenSanders: Four million seniors live on less than $11,000 a year. http:\/\/t.co\/oa2eNAeuDr #MealsOnWheels",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MealsOnWheels",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/oa2eNAeuDr",
        "expanded_url" : "http:\/\/ow.ly\/mbvIM",
        "display_url" : "ow.ly\/mbvIM"
      } ]
    },
    "geo" : { },
    "id_str" : "347372201361686528",
    "text" : "Four million seniors live on less than $11,000 a year. http:\/\/t.co\/oa2eNAeuDr #MealsOnWheels",
    "id" : 347372201361686528,
    "created_at" : "2013-06-19 15:16:01 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 347736952856002560,
  "created_at" : "2013-06-20 15:25:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347734087211036674",
  "text" : "@Skeptical_Lady wisdom : )",
  "id" : 347734087211036674,
  "created_at" : "2013-06-20 15:14:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/22kZZUlZXm",
      "expanded_url" : "http:\/\/vimeo.com\/49005698",
      "display_url" : "vimeo.com\/49005698"
    } ]
  },
  "geo" : { },
  "id_str" : "347733643717918720",
  "text" : "RT @SenSanders: Today, virtually no piece of legislation can get passed unless it has the ok from corporate America. http:\/\/t.co\/22kZZUlZXm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/22kZZUlZXm",
        "expanded_url" : "http:\/\/vimeo.com\/49005698",
        "display_url" : "vimeo.com\/49005698"
      } ]
    },
    "geo" : { },
    "id_str" : "347715198355914755",
    "text" : "Today, virtually no piece of legislation can get passed unless it has the ok from corporate America. http:\/\/t.co\/22kZZUlZXm",
    "id" : 347715198355914755,
    "created_at" : "2013-06-20 13:58:58 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 347733643717918720,
  "created_at" : "2013-06-20 15:12:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Woodward",
      "screen_name" : "xaipe3",
      "indices" : [ 3, 10 ],
      "id_str" : "131519765",
      "id" : 131519765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347732821151989760",
  "text" : "RT @xaipe3: Until we get the profit out of healthcare we will continue to have problems. Single Payer!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "347701675747840000",
    "text" : "Until we get the profit out of healthcare we will continue to have problems. Single Payer!",
    "id" : 347701675747840000,
    "created_at" : "2013-06-20 13:05:14 +0000",
    "user" : {
      "name" : "Lesley Woodward",
      "screen_name" : "xaipe3",
      "protected" : false,
      "id_str" : "131519765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755350631\/c8efdbb24174aea2a73b7ef216a37609_normal.png",
      "id" : 131519765,
      "verified" : false
    }
  },
  "id" : 347732821151989760,
  "created_at" : "2013-06-20 15:08:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Religion",
      "screen_name" : "HuffPostRelig",
      "indices" : [ 3, 17 ],
      "id_str" : "117189136",
      "id" : 117189136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/0MoPoCNARr",
      "expanded_url" : "http:\/\/huff.to\/19UZSIu",
      "display_url" : "huff.to\/19UZSIu"
    } ]
  },
  "geo" : { },
  "id_str" : "347730911523110912",
  "text" : "RT @HuffPostRelig: This seems un-American.. Atheist seeking US citizenship told to join church or be denied  http:\/\/t.co\/0MoPoCNARr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/0MoPoCNARr",
        "expanded_url" : "http:\/\/huff.to\/19UZSIu",
        "display_url" : "huff.to\/19UZSIu"
      } ]
    },
    "geo" : { },
    "id_str" : "347727079246266370",
    "text" : "This seems un-American.. Atheist seeking US citizenship told to join church or be denied  http:\/\/t.co\/0MoPoCNARr",
    "id" : 347727079246266370,
    "created_at" : "2013-06-20 14:46:10 +0000",
    "user" : {
      "name" : "HuffPost Religion",
      "screen_name" : "HuffPostRelig",
      "protected" : false,
      "id_str" : "117189136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1184014153\/religion_tw_normal.png",
      "id" : 117189136,
      "verified" : true
    }
  },
  "id" : 347730911523110912,
  "created_at" : "2013-06-20 15:01:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347514122189017090",
  "text" : "the dog gets very adamant about licking dh's foot every evening. it's like a drug to her.",
  "id" : 347514122189017090,
  "created_at" : "2013-06-20 00:39:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Bolick",
      "screen_name" : "scottbolick",
      "indices" : [ 3, 15 ],
      "id_str" : "16091839",
      "id" : 16091839
    }, {
      "name" : "Aetna",
      "screen_name" : "Aetna",
      "indices" : [ 17, 23 ],
      "id_str" : "16188518",
      "id" : 16188518
    }, {
      "name" : "Brittany Lothe",
      "screen_name" : "brittanylothe",
      "indices" : [ 34, 48 ],
      "id_str" : "57501560",
      "id" : 57501560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347111251610058753",
  "text" : "RT @scottbolick: @Aetna Home with @brittanylothe and our preemie son on 9 medications, oxygen, &amp; feeding tube. ZERO authorized in home nurs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aetna",
        "screen_name" : "Aetna",
        "indices" : [ 0, 6 ],
        "id_str" : "16188518",
        "id" : 16188518
      }, {
        "name" : "Brittany Lothe",
        "screen_name" : "brittanylothe",
        "indices" : [ 17, 31 ],
        "id_str" : "57501560",
        "id" : 57501560
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344596697286074369",
    "in_reply_to_user_id" : 16188518,
    "text" : "@Aetna Home with @brittanylothe and our preemie son on 9 medications, oxygen, &amp; feeding tube. ZERO authorized in home nursing...ridiculous!",
    "id" : 344596697286074369,
    "created_at" : "2013-06-11 23:27:09 +0000",
    "in_reply_to_screen_name" : "Aetna",
    "in_reply_to_user_id_str" : "16188518",
    "user" : {
      "name" : "Scott Bolick",
      "screen_name" : "scottbolick",
      "protected" : false,
      "id_str" : "16091839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465229497206591488\/PTceFWj6_normal.jpeg",
      "id" : 16091839,
      "verified" : false
    }
  },
  "id" : 347111251610058753,
  "created_at" : "2013-06-18 21:59:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/bP8XMRV7Q0",
      "expanded_url" : "http:\/\/wp.me\/p39Y4h-1A",
      "display_url" : "wp.me\/p39Y4h-1A"
    } ]
  },
  "geo" : { },
  "id_str" : "347110829390446594",
  "text" : "We need #SinglePayer now! &gt;&gt; The Circles For My Child's Survival http:\/\/t.co\/bP8XMRV7Q0",
  "id" : 347110829390446594,
  "created_at" : "2013-06-18 21:57:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347082478906916864",
  "text" : "dead possum in my yard. makes me very sad. : ((",
  "id" : 347082478906916864,
  "created_at" : "2013-06-18 20:04:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "indices" : [ 3, 16 ],
      "id_str" : "361815486",
      "id" : 361815486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347067168199942144",
  "text" : "RT @bookwiseblog: $0.99 Kindle Books from HarperCollins: HarperCollins is having a ebook sale. \u00A0This appears to be across all eb... http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/HuiM6JpSxr",
        "expanded_url" : "http:\/\/bit.ly\/19O6Mzp",
        "display_url" : "bit.ly\/19O6Mzp"
      } ]
    },
    "geo" : { },
    "id_str" : "347064565684658177",
    "text" : "$0.99 Kindle Books from HarperCollins: HarperCollins is having a ebook sale. \u00A0This appears to be across all eb... http:\/\/t.co\/HuiM6JpSxr",
    "id" : 347064565684658177,
    "created_at" : "2013-06-18 18:53:35 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "bookwiseblog",
      "protected" : false,
      "id_str" : "361815486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619981138\/680mlvg5f1m1e3tyd6v4_normal.jpeg",
      "id" : 361815486,
      "verified" : false
    }
  },
  "id" : 347067168199942144,
  "created_at" : "2013-06-18 19:03:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jfN7KOq8Zu",
      "expanded_url" : "http:\/\/shine.yahoo.com\/love-sex\/im-overweight-boyfriends-not-big-freaking-deal-134800157.html",
      "display_url" : "shine.yahoo.com\/love-sex\/im-ov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "347066533756940289",
  "text" : "RT @Squirrely007: you go girl! **I'm Overweight and My Boyfriend's Not. Big Freaking Deal | Love + Sex - Yahoo! Shine http:\/\/t.co\/jfN7KOq8Zu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/jfN7KOq8Zu",
        "expanded_url" : "http:\/\/shine.yahoo.com\/love-sex\/im-overweight-boyfriends-not-big-freaking-deal-134800157.html",
        "display_url" : "shine.yahoo.com\/love-sex\/im-ov\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347064889006772226",
    "text" : "you go girl! **I'm Overweight and My Boyfriend's Not. Big Freaking Deal | Love + Sex - Yahoo! Shine http:\/\/t.co\/jfN7KOq8Zu",
    "id" : 347064889006772226,
    "created_at" : "2013-06-18 18:54:52 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 347066533756940289,
  "created_at" : "2013-06-18 19:01:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/cHZMK0jz8c",
      "expanded_url" : "http:\/\/what-if.xkcd.com\/",
      "display_url" : "what-if.xkcd.com"
    } ]
  },
  "geo" : { },
  "id_str" : "347063194126262273",
  "text" : "RT @MWM4444: From today's http:\/\/t.co\/cHZMK0jz8c: Liquid tungsten is so hot, if you dropped it into a lava flow, the lava would freeze the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/cHZMK0jz8c",
        "expanded_url" : "http:\/\/what-if.xkcd.com\/",
        "display_url" : "what-if.xkcd.com"
      } ]
    },
    "geo" : { },
    "id_str" : "347055155121897472",
    "text" : "From today's http:\/\/t.co\/cHZMK0jz8c: Liquid tungsten is so hot, if you dropped it into a lava flow, the lava would freeze the tungsten.",
    "id" : 347055155121897472,
    "created_at" : "2013-06-18 18:16:11 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 347063194126262273,
  "created_at" : "2013-06-18 18:48:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347045482087989248",
  "text" : "RT @MWM4444: Michael Burgess, R-TX, is sure we must ban abortion because boy fetuses masturbate. There's no other interpretation. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/PDq7gODnXR",
        "expanded_url" : "http:\/\/thinkprogress.org\/politics\/2013\/06\/18\/2171931\/fetus-masturbate-burgess\/",
        "display_url" : "thinkprogress.org\/politics\/2013\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "347042806348529664",
    "text" : "Michael Burgess, R-TX, is sure we must ban abortion because boy fetuses masturbate. There's no other interpretation. http:\/\/t.co\/PDq7gODnXR",
    "id" : 347042806348529664,
    "created_at" : "2013-06-18 17:27:07 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 347045482087989248,
  "created_at" : "2013-06-18 17:37:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 2, 15 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347036431824322560",
  "geo" : { },
  "id_str" : "347037011644932096",
  "in_reply_to_user_id" : 20987411,
  "text" : ". @SisterSadist perfect line for me. maybe i should use in my sig or blog.. hmm...",
  "id" : 347037011644932096,
  "in_reply_to_status_id" : 347036431824322560,
  "created_at" : "2013-06-18 17:04:05 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "347028164662394880",
  "text" : "last day of bible study, forgot my pill this am, dd being a PITA.. i am GRUMPY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",
  "id" : 347028164662394880,
  "created_at" : "2013-06-18 16:28:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    }, {
      "name" : "WTCommunities",
      "screen_name" : "WTCommunities",
      "indices" : [ 110, 124 ],
      "id_str" : "2484742950",
      "id" : 2484742950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/D6eNRWhg5m",
      "expanded_url" : "http:\/\/wtim.es\/16cqtvY",
      "display_url" : "wtim.es\/16cqtvY"
    } ]
  },
  "geo" : { },
  "id_str" : "346786767099281408",
  "text" : "RT @AllOnMedicare: Single payer health care in America and why it isn't Socialism: http:\/\/t.co\/D6eNRWhg5m via @wtcommunities",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WTCommunities",
        "screen_name" : "WTCommunities",
        "indices" : [ 91, 105 ],
        "id_str" : "2484742950",
        "id" : 2484742950
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/D6eNRWhg5m",
        "expanded_url" : "http:\/\/wtim.es\/16cqtvY",
        "display_url" : "wtim.es\/16cqtvY"
      } ]
    },
    "geo" : { },
    "id_str" : "346784194027999233",
    "text" : "Single payer health care in America and why it isn't Socialism: http:\/\/t.co\/D6eNRWhg5m via @wtcommunities",
    "id" : 346784194027999233,
    "created_at" : "2013-06-18 00:19:29 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 346786767099281408,
  "created_at" : "2013-06-18 00:29:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Van Praagh",
      "screen_name" : "JamesVanPraagh",
      "indices" : [ 3, 18 ],
      "id_str" : "36117734",
      "id" : 36117734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346782857332654080",
  "text" : "RT @JamesVanPraagh: Follow your intuition. The universe will lead you to the next step if you keep your eyes open and follow your feelings.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inspiration",
        "indices" : [ 120, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346754299386294272",
    "text" : "Follow your intuition. The universe will lead you to the next step if you keep your eyes open and follow your feelings. #inspiration",
    "id" : 346754299386294272,
    "created_at" : "2013-06-17 22:20:42 +0000",
    "user" : {
      "name" : "James Van Praagh",
      "screen_name" : "JamesVanPraagh",
      "protected" : false,
      "id_str" : "36117734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531912694501097472\/0GFqd6F6_normal.jpeg",
      "id" : 36117734,
      "verified" : false
    }
  },
  "id" : 346782857332654080,
  "created_at" : "2013-06-18 00:14:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PaxilWithdrawal",
      "screen_name" : "PaxilWithdrawal",
      "indices" : [ 3, 19 ],
      "id_str" : "472334076",
      "id" : 472334076
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FTC",
      "indices" : [ 21, 25 ]
    }, {
      "text" : "pharmaceutical",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346768726617636864",
  "text" : "RT @PaxilWithdrawal: #FTC report on \"Pay for Delay\" methods that #pharmaceutical companies use to delay generics. (2010 PDF) http:\/\/t.co\/9F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FTC",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "pharmaceutical",
        "indices" : [ 44, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/9Fl9Gk7aoC",
        "expanded_url" : "http:\/\/www.ftc.gov\/os\/2010\/01\/100112payfordelayrpt.pdf",
        "display_url" : "ftc.gov\/os\/2010\/01\/100\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "346767697155092481",
    "text" : "#FTC report on \"Pay for Delay\" methods that #pharmaceutical companies use to delay generics. (2010 PDF) http:\/\/t.co\/9Fl9Gk7aoC",
    "id" : 346767697155092481,
    "created_at" : "2013-06-17 23:13:56 +0000",
    "user" : {
      "name" : "PaxilWithdrawal",
      "screen_name" : "PaxilWithdrawal",
      "protected" : false,
      "id_str" : "472334076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2873847089\/c2907c08ac13c4cd202d51fd37773a65_normal.png",
      "id" : 472334076,
      "verified" : false
    }
  },
  "id" : 346768726617636864,
  "created_at" : "2013-06-17 23:18:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346762596743008256",
  "geo" : { },
  "id_str" : "346763371095408640",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen dh got scotch in him.. i should have him say it w accent..lol",
  "id" : 346763371095408640,
  "in_reply_to_status_id" : 346762596743008256,
  "created_at" : "2013-06-17 22:56:44 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "guilty",
      "indices" : [ 56, 63 ]
    }, {
      "text" : "naughty",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "lackofrespect",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346762360993763328",
  "text" : "oh now im feeling bad about messing w the bird house... #guilty #naughty #lackofrespect",
  "id" : 346762360993763328,
  "created_at" : "2013-06-17 22:52:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346749854199975936",
  "geo" : { },
  "id_str" : "346761905462980609",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen hairy coos.. always makes me laugh! : )",
  "id" : 346761905462980609,
  "in_reply_to_status_id" : 346749854199975936,
  "created_at" : "2013-06-17 22:50:55 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScottishHighland",
      "indices" : [ 79, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/BZtDcEUB9T",
      "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
      "display_url" : "facebook.com\/HighlandFarmsO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "346761734595411968",
  "text" : "RT @ChickenJen: you can follow our farm adventures here (we raise hairy coos ~ #ScottishHighland cattle) https:\/\/t.co\/BZtDcEUB9T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScottishHighland",
        "indices" : [ 63, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/BZtDcEUB9T",
        "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
        "display_url" : "facebook.com\/HighlandFarmsO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "346749854199975936",
    "text" : "you can follow our farm adventures here (we raise hairy coos ~ #ScottishHighland cattle) https:\/\/t.co\/BZtDcEUB9T",
    "id" : 346749854199975936,
    "created_at" : "2013-06-17 22:03:02 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 346761734595411968,
  "created_at" : "2013-06-17 22:50:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 37, 43 ]
    }, {
      "text" : "nature",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/veNFEhY6CR",
      "expanded_url" : "http:\/\/ow.ly\/m5YWw",
      "display_url" : "ow.ly\/m5YWw"
    } ]
  },
  "geo" : { },
  "id_str" : "346761432630706176",
  "text" : "RT @KerriFar: I find such JOY in the #birds ~ http:\/\/t.co\/veNFEhY6CR  ~ #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 23, 29 ]
      }, {
        "text" : "nature",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/veNFEhY6CR",
        "expanded_url" : "http:\/\/ow.ly\/m5YWw",
        "display_url" : "ow.ly\/m5YWw"
      } ]
    },
    "geo" : { },
    "id_str" : "346753661763985409",
    "text" : "I find such JOY in the #birds ~ http:\/\/t.co\/veNFEhY6CR  ~ #nature",
    "id" : 346753661763985409,
    "created_at" : "2013-06-17 22:18:09 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 346761432630706176,
  "created_at" : "2013-06-17 22:49:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "MyBrownNewfies",
      "indices" : [ 3, 18 ],
      "id_str" : "213161870",
      "id" : 213161870
    }, {
      "name" : "Kim Clune",
      "screen_name" : "ThisOneWildLife",
      "indices" : [ 84, 100 ],
      "id_str" : "145043112",
      "id" : 145043112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/U1AIm9lPws",
      "expanded_url" : "http:\/\/goo.gl\/2CWEu",
      "display_url" : "goo.gl\/2CWEu"
    } ]
  },
  "geo" : { },
  "id_str" : "346760145981804544",
  "text" : "RT @MyBrownNewfies: Save a Snapper: Rescue Road Turtles! http:\/\/t.co\/U1AIm9lPws via @ThisOneWildLife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kim Clune",
        "screen_name" : "ThisOneWildLife",
        "indices" : [ 64, 80 ],
        "id_str" : "145043112",
        "id" : 145043112
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/U1AIm9lPws",
        "expanded_url" : "http:\/\/goo.gl\/2CWEu",
        "display_url" : "goo.gl\/2CWEu"
      } ]
    },
    "geo" : { },
    "id_str" : "346756732116160513",
    "text" : "Save a Snapper: Rescue Road Turtles! http:\/\/t.co\/U1AIm9lPws via @ThisOneWildLife",
    "id" : 346756732116160513,
    "created_at" : "2013-06-17 22:30:22 +0000",
    "user" : {
      "name" : "Jen",
      "screen_name" : "MyBrownNewfies",
      "protected" : false,
      "id_str" : "213161870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000365475755\/208bcb9c6985d9a32fff83387a4379a9_normal.jpeg",
      "id" : 213161870,
      "verified" : false
    }
  },
  "id" : 346760145981804544,
  "created_at" : "2013-06-17 22:43:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "Sarah",
      "screen_name" : "sarahcasm",
      "indices" : [ 43, 53 ],
      "id_str" : "36848279",
      "id" : 36848279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346727558823436288",
  "geo" : { },
  "id_str" : "346731149952970754",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits sounds like a wise, old soul : ) @sarahcasm",
  "id" : 346731149952970754,
  "in_reply_to_status_id" : 346727558823436288,
  "created_at" : "2013-06-17 20:48:42 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346730730254114818",
  "text" : "RT @CoyotesWisdom: Repeat these magic words: \"I QUIT.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346729680751177728",
    "text" : "Repeat these magic words: \"I QUIT.\"",
    "id" : 346729680751177728,
    "created_at" : "2013-06-17 20:42:52 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 346730730254114818,
  "created_at" : "2013-06-17 20:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Earth Pics",
      "screen_name" : "Earth_Pics",
      "indices" : [ 40, 51 ],
      "id_str" : "555928038",
      "id" : 555928038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/8YLMzt7phi",
      "expanded_url" : "https:\/\/twitter.com\/Earth_Pics\/status\/346692552759586816\/photo\/1",
      "display_url" : "pic.twitter.com\/8YLMzt7phi"
    } ]
  },
  "geo" : { },
  "id_str" : "346703443496407044",
  "text" : "RT @Silvercrone: Spooky cool&gt;&gt; RT @Earth_Pics Shadow art http:\/\/t.co\/8YLMzt7phi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/itunes.apple.com\/us\/app\/twittelator-free\/id510364502?mt=8&uo=4\" rel=\"nofollow\"\u003ETwittelator Free on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Earth Pics",
        "screen_name" : "Earth_Pics",
        "indices" : [ 23, 34 ],
        "id_str" : "555928038",
        "id" : 555928038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/8YLMzt7phi",
        "expanded_url" : "https:\/\/twitter.com\/Earth_Pics\/status\/346692552759586816\/photo\/1",
        "display_url" : "pic.twitter.com\/8YLMzt7phi"
      } ]
    },
    "in_reply_to_status_id_str" : "346692552759586816",
    "geo" : { },
    "id_str" : "346702673988419584",
    "in_reply_to_user_id" : 555928038,
    "text" : "Spooky cool&gt;&gt; RT @Earth_Pics Shadow art http:\/\/t.co\/8YLMzt7phi",
    "id" : 346702673988419584,
    "in_reply_to_status_id" : 346692552759586816,
    "created_at" : "2013-06-17 18:55:33 +0000",
    "in_reply_to_screen_name" : "Earth_Pics",
    "in_reply_to_user_id_str" : "555928038",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 346703443496407044,
  "created_at" : "2013-06-17 18:58:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346701783428657152",
  "text" : "dear universe, thank you for hubs finding his hat. im waiting patiently for IPA that i like. love, gabrielle",
  "id" : 346701783428657152,
  "created_at" : "2013-06-17 18:52:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 2, 12 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Jennifer",
      "screen_name" : "JennTaylor914",
      "indices" : [ 56, 70 ],
      "id_str" : "53554147",
      "id" : 53554147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346696041724264448",
  "geo" : { },
  "id_str" : "346700742679207936",
  "in_reply_to_user_id" : 16181537,
  "text" : ". @ZachsMind having a bank account is a form of slavery @JennTaylor914",
  "id" : 346700742679207936,
  "in_reply_to_status_id" : 346696041724264448,
  "created_at" : "2013-06-17 18:47:53 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imverybad",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346699569050046464",
  "text" : "oops.. i pissed off mommy bird. i wanted to hear the babies. #imverybad",
  "id" : 346699569050046464,
  "created_at" : "2013-06-17 18:43:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346692777637208064",
  "text" : "DD does not like when i sing \"someday my prince will come\" .. LOL well, homestly, she doesnt like me singing - period.",
  "id" : 346692777637208064,
  "created_at" : "2013-06-17 18:16:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346692262270480384",
  "text" : "RT @thDigitalReader: If I went mad, would anyone notice?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346688308702756864",
    "text" : "If I went mad, would anyone notice?",
    "id" : 346688308702756864,
    "created_at" : "2013-06-17 17:58:28 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 346692262270480384,
  "created_at" : "2013-06-17 18:14:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chiller TV",
      "screen_name" : "ChillerTV",
      "indices" : [ 3, 13 ],
      "id_str" : "40085270",
      "id" : 40085270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/b6uTmpeOPV",
      "expanded_url" : "http:\/\/ow.ly\/m6N6l",
      "display_url" : "ow.ly\/m6N6l"
    } ]
  },
  "geo" : { },
  "id_str" : "346655480535449600",
  "text" : "RT @ChillerTV: \"Dead Like Me\" marathon, on Chiller AS WE SPEAK and continuing all afternoon! http:\/\/t.co\/b6uTmpeOPV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/b6uTmpeOPV",
        "expanded_url" : "http:\/\/ow.ly\/m6N6l",
        "display_url" : "ow.ly\/m6N6l"
      } ]
    },
    "geo" : { },
    "id_str" : "346654420848758786",
    "text" : "\"Dead Like Me\" marathon, on Chiller AS WE SPEAK and continuing all afternoon! http:\/\/t.co\/b6uTmpeOPV",
    "id" : 346654420848758786,
    "created_at" : "2013-06-17 15:43:49 +0000",
    "user" : {
      "name" : "Chiller TV",
      "screen_name" : "ChillerTV",
      "protected" : false,
      "id_str" : "40085270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697116869241647104\/_DvGYAFp_normal.jpg",
      "id" : 40085270,
      "verified" : true
    }
  },
  "id" : 346655480535449600,
  "created_at" : "2013-06-17 15:48:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healthcare Activists",
      "screen_name" : "singlepayer",
      "indices" : [ 3, 15 ],
      "id_str" : "15883275",
      "id" : 15883275
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 62, 70 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/0KfPq5IOER",
      "expanded_url" : "http:\/\/nyti.ms\/ZPO5Wt",
      "display_url" : "nyti.ms\/ZPO5Wt"
    } ]
  },
  "geo" : { },
  "id_str" : "346643197822382082",
  "text" : "RT @singlepayer: What Sweden Can Tell Us About Obamacare, via @nytimes #singlepayer http:\/\/t.co\/0KfPq5IOER",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 45, 53 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 54, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/0KfPq5IOER",
        "expanded_url" : "http:\/\/nyti.ms\/ZPO5Wt",
        "display_url" : "nyti.ms\/ZPO5Wt"
      } ]
    },
    "geo" : { },
    "id_str" : "346640782813446145",
    "text" : "What Sweden Can Tell Us About Obamacare, via @nytimes #singlepayer http:\/\/t.co\/0KfPq5IOER",
    "id" : 346640782813446145,
    "created_at" : "2013-06-17 14:49:37 +0000",
    "user" : {
      "name" : "Healthcare Activists",
      "screen_name" : "singlepayer",
      "protected" : false,
      "id_str" : "15883275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616256834878377984\/k6U1OHi-_normal.jpg",
      "id" : 15883275,
      "verified" : false
    }
  },
  "id" : 346643197822382082,
  "created_at" : "2013-06-17 14:59:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346642266410074112",
  "text" : "banks are evil",
  "id" : 346642266410074112,
  "created_at" : "2013-06-17 14:55:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 2, 15 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Syed ali abbas abedi",
      "screen_name" : "abbas_abedi",
      "indices" : [ 57, 69 ],
      "id_str" : "2993483142",
      "id" : 2993483142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346625801992687617",
  "geo" : { },
  "id_str" : "346640332651364353",
  "in_reply_to_user_id" : 15588657,
  "text" : ". @DeepakChopra we are all figments of God's imagination @Abbas_Abedi",
  "id" : 346640332651364353,
  "in_reply_to_status_id" : 346625801992687617,
  "created_at" : "2013-06-17 14:47:50 +0000",
  "in_reply_to_screen_name" : "DeepakChopra",
  "in_reply_to_user_id_str" : "15588657",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ODS",
      "screen_name" : "TheLogicalOne70",
      "indices" : [ 2, 18 ],
      "id_str" : "46848957",
      "id" : 46848957
    }, {
      "name" : "LBC 97.3",
      "screen_name" : "LBC973",
      "indices" : [ 19, 26 ],
      "id_str" : "2242781292",
      "id" : 2242781292
    }, {
      "name" : "Julia Hartley-Brewer",
      "screen_name" : "JuliaHB1",
      "indices" : [ 27, 36 ],
      "id_str" : "459390022",
      "id" : 459390022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346627908426678273",
  "geo" : { },
  "id_str" : "346638423035084801",
  "in_reply_to_user_id" : 46848957,
  "text" : ". @TheLogicalOne70 @lbc973 @JuliaHB1 and why.. since it's that person's choice. (body belongs to corporate?)",
  "id" : 346638423035084801,
  "in_reply_to_status_id" : 346627908426678273,
  "created_at" : "2013-06-17 14:40:14 +0000",
  "in_reply_to_screen_name" : "TheLogicalOne70",
  "in_reply_to_user_id_str" : "46848957",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/aTXK2SGrOz",
      "expanded_url" : "http:\/\/wapo.st\/11sXAbR",
      "display_url" : "wapo.st\/11sXAbR"
    } ]
  },
  "geo" : { },
  "id_str" : "346635899741814785",
  "text" : "RT @ezraklein: READ: The Supreme Court rules against big pharma http:\/\/t.co\/aTXK2SGrOz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/aTXK2SGrOz",
        "expanded_url" : "http:\/\/wapo.st\/11sXAbR",
        "display_url" : "wapo.st\/11sXAbR"
      } ]
    },
    "geo" : { },
    "id_str" : "346634842366152705",
    "text" : "READ: The Supreme Court rules against big pharma http:\/\/t.co\/aTXK2SGrOz",
    "id" : 346634842366152705,
    "created_at" : "2013-06-17 14:26:01 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 346635899741814785,
  "created_at" : "2013-06-17 14:30:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 14, 23 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebirds",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "nature",
      "indices" : [ 76, 83 ]
    }, {
      "text" : "birds",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/uepPd1NURi",
      "expanded_url" : "http:\/\/ow.ly\/m4NKJ",
      "display_url" : "ow.ly\/m4NKJ"
    } ]
  },
  "in_reply_to_status_id_str" : "346420846455296000",
  "geo" : { },
  "id_str" : "346427262796718080",
  "in_reply_to_user_id" : 12088232,
  "text" : "beautiful! RT @KerriFar 1 , 2 , 3 , #Bluebirds ~ http:\/\/t.co\/uepPd1NURi   ~ #nature #birds",
  "id" : 346427262796718080,
  "in_reply_to_status_id" : 346420846455296000,
  "created_at" : "2013-06-17 00:41:10 +0000",
  "in_reply_to_screen_name" : "KerriFar",
  "in_reply_to_user_id_str" : "12088232",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Positively Wyrde",
      "screen_name" : "Wyrde",
      "indices" : [ 3, 9 ],
      "id_str" : "67295881",
      "id" : 67295881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crow",
      "indices" : [ 63, 68 ]
    }, {
      "text" : "micropoetry",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346406636937687044",
  "text" : "RT @Wyrde: .\nThe crow is\na handful of truths\nfeathered black.\n\n#crow #micropoetry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "crow",
        "indices" : [ 52, 57 ]
      }, {
        "text" : "micropoetry",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346393247989526528",
    "text" : ".\nThe crow is\na handful of truths\nfeathered black.\n\n#crow #micropoetry",
    "id" : 346393247989526528,
    "created_at" : "2013-06-16 22:26:00 +0000",
    "user" : {
      "name" : "Positively Wyrde",
      "screen_name" : "Wyrde",
      "protected" : false,
      "id_str" : "67295881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/372101436\/BEye_normal.jpg",
      "id" : 67295881,
      "verified" : false
    }
  },
  "id" : 346406636937687044,
  "created_at" : "2013-06-16 23:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/346402888463052800\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Q6DRDAQTW7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM6rl3xCcAEk18d.jpg",
      "id_str" : "346402888467247105",
      "id" : 346402888467247105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM6rl3xCcAEk18d.jpg",
      "sizes" : [ {
        "h" : 856,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 856,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Q6DRDAQTW7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346405920890290176",
  "text" : "RT @marseelee: If bees go extinct, this is what your supermarket will look like... http:\/\/t.co\/Q6DRDAQTW7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marseelee\/status\/346402888463052800\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/Q6DRDAQTW7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BM6rl3xCcAEk18d.jpg",
        "id_str" : "346402888467247105",
        "id" : 346402888467247105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM6rl3xCcAEk18d.jpg",
        "sizes" : [ {
          "h" : 856,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 856,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Q6DRDAQTW7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346402888463052800",
    "text" : "If bees go extinct, this is what your supermarket will look like... http:\/\/t.co\/Q6DRDAQTW7",
    "id" : 346402888463052800,
    "created_at" : "2013-06-16 23:04:19 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 346405920890290176,
  "created_at" : "2013-06-16 23:16:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tao Are You",
      "screen_name" : "taoareyou",
      "indices" : [ 3, 13 ],
      "id_str" : "21570364",
      "id" : 21570364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346370634319794176",
  "text" : "RT @taoareyou: No one can tell you the path of Tao, because each of us has their own.  To find your way, just don't over think it. Let go a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346368499905601538",
    "text" : "No one can tell you the path of Tao, because each of us has their own.  To find your way, just don't over think it. Let go and it's there.",
    "id" : 346368499905601538,
    "created_at" : "2013-06-16 20:47:40 +0000",
    "user" : {
      "name" : "Tao Are You",
      "screen_name" : "taoareyou",
      "protected" : false,
      "id_str" : "21570364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576616090299559936\/eSoOq1Nj_normal.jpeg",
      "id" : 21570364,
      "verified" : false
    }
  },
  "id" : 346370634319794176,
  "created_at" : "2013-06-16 20:56:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346366335586033665",
  "text" : "vicious headache.. not sure why.",
  "id" : 346366335586033665,
  "created_at" : "2013-06-16 20:39:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science WTF",
      "screen_name" : "ScienceWTF",
      "indices" : [ 3, 14 ],
      "id_str" : "631980118",
      "id" : 631980118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346366105155149825",
  "text" : "RT @ScienceWTF: The largest and closest full Moon of 2013 will occur on June 23rd. It won't be this close until August 2014.\nSHARE: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScienceWTF\/status\/345753336269635585\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/pmcmuM2cV2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMxc09TCAAIbIxt.jpg",
        "id_str" : "345753336278024194",
        "id" : 345753336278024194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMxc09TCAAIbIxt.jpg",
        "sizes" : [ {
          "h" : 582,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 495
        } ],
        "display_url" : "pic.twitter.com\/pmcmuM2cV2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345753336269635585",
    "text" : "The largest and closest full Moon of 2013 will occur on June 23rd. It won't be this close until August 2014.\nSHARE: http:\/\/t.co\/pmcmuM2cV2",
    "id" : 345753336269635585,
    "created_at" : "2013-06-15 04:03:13 +0000",
    "user" : {
      "name" : "Science WTF",
      "screen_name" : "ScienceWTF",
      "protected" : false,
      "id_str" : "631980118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3508328861\/cbe82f7f9ea0de65f0661dd291696198_normal.jpeg",
      "id" : 631980118,
      "verified" : false
    }
  },
  "id" : 346366105155149825,
  "created_at" : "2013-06-16 20:38:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346365029488148482",
  "geo" : { },
  "id_str" : "346365977803497473",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ive got too many.. but i play very few. what kind do you like?",
  "id" : 346365977803497473,
  "in_reply_to_status_id" : 346365029488148482,
  "created_at" : "2013-06-16 20:37:38 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ConservatismShrugged",
      "screen_name" : "shoelessjoe255",
      "indices" : [ 2, 17 ],
      "id_str" : "398546283",
      "id" : 398546283
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 18, 30 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346360355871666177",
  "geo" : { },
  "id_str" : "346364149254737920",
  "in_reply_to_user_id" : 398546283,
  "text" : ". @shoelessjoe255 @VirgoJohnny \"Acceptance of EVERYTHING.\" i think that's buddhist concept.",
  "id" : 346364149254737920,
  "in_reply_to_status_id" : 346360355871666177,
  "created_at" : "2013-06-16 20:30:22 +0000",
  "in_reply_to_screen_name" : "shoelessjoe255",
  "in_reply_to_user_id_str" : "398546283",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Aid",
      "screen_name" : "wildlifeaid",
      "indices" : [ 0, 12 ],
      "id_str" : "35003814",
      "id" : 35003814
    }, {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 85, 95 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346229868616359936",
  "geo" : { },
  "id_str" : "346339173868896256",
  "in_reply_to_user_id" : 35003814,
  "text" : "@wildlifeaid has curled ears, all alone in the world (learned from Wild Heart Ranch) @Jamiastar",
  "id" : 346339173868896256,
  "in_reply_to_status_id" : 346229868616359936,
  "created_at" : "2013-06-16 18:51:08 +0000",
  "in_reply_to_screen_name" : "wildlifeaid",
  "in_reply_to_user_id_str" : "35003814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346337820450897920",
  "text" : "@statue_dog not seeing a lot of happy in those eyes..lol. *scritches behind the ears",
  "id" : 346337820450897920,
  "created_at" : "2013-06-16 18:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346336389899624448",
  "text" : "and i saved a giant bumble bee from the pool.",
  "id" : 346336389899624448,
  "created_at" : "2013-06-16 18:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346336269334372352",
  "text" : "saw our stray cat on walk today.. of course did not have my ipod touch w me to take pic. he was sitting on stone wall.",
  "id" : 346336269334372352,
  "created_at" : "2013-06-16 18:39:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346334649292845057",
  "text" : "@statue_dog im sad wallace isnt eating but glad you got a nice chew.",
  "id" : 346334649292845057,
  "created_at" : "2013-06-16 18:33:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 3, 19 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346325767065579520",
  "text" : "RT @shoeofallcosmos: It's the last obstacle in obtaining the SBA loan... If we can raise $15,000 somehow, we'd be off the ground in no time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346325614048980992",
    "text" : "It's the last obstacle in obtaining the SBA loan... If we can raise $15,000 somehow, we'd be off the ground in no time.",
    "id" : 346325614048980992,
    "created_at" : "2013-06-16 17:57:15 +0000",
    "user" : {
      "name" : "\uD83D\uDC51Hillary\uD83D\uDC51",
      "screen_name" : "trustsuperjail",
      "protected" : false,
      "id_str" : "14364749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755988613427437568\/6rMS9eol_normal.jpg",
      "id" : 14364749,
      "verified" : false
    }
  },
  "id" : 346325767065579520,
  "created_at" : "2013-06-16 17:57:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 3, 19 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346325412223270912",
  "text" : "RT @shoeofallcosmos: We need $15,000 in cash collateral for the bank to loan us the $35,000. Nobody I know has that kind of money, and Kick\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346324702815481856",
    "text" : "We need $15,000 in cash collateral for the bank to loan us the $35,000. Nobody I know has that kind of money, and Kickstarter is for art.",
    "id" : 346324702815481856,
    "created_at" : "2013-06-16 17:53:38 +0000",
    "user" : {
      "name" : "\uD83D\uDC51Hillary\uD83D\uDC51",
      "screen_name" : "trustsuperjail",
      "protected" : false,
      "id_str" : "14364749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755988613427437568\/6rMS9eol_normal.jpg",
      "id" : 14364749,
      "verified" : false
    }
  },
  "id" : 346325412223270912,
  "created_at" : "2013-06-16 17:56:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346322897230508034",
  "geo" : { },
  "id_str" : "346323120216494080",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits ((fistpumps)) : )",
  "id" : 346323120216494080,
  "in_reply_to_status_id" : 346322897230508034,
  "created_at" : "2013-06-16 17:47:20 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346322246702362624",
  "text" : "i could clean house while DH,DD away but my idea of cleaning is throwing out and im not allowed.",
  "id" : 346322246702362624,
  "created_at" : "2013-06-16 17:43:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "indices" : [ 3, 19 ],
      "id_str" : "292671486",
      "id" : 292671486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346319589732388864",
  "text" : "RT @proudliberalmom: I will forever miss you Daddy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346318673872564225",
    "text" : "I will forever miss you Daddy.",
    "id" : 346318673872564225,
    "created_at" : "2013-06-16 17:29:40 +0000",
    "user" : {
      "name" : "& then there's Maude",
      "screen_name" : "proudliberalmom",
      "protected" : false,
      "id_str" : "292671486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742835194340605953\/oTbZt40x_normal.jpg",
      "id" : 292671486,
      "verified" : false
    }
  },
  "id" : 346319589732388864,
  "created_at" : "2013-06-16 17:33:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Landherr",
      "screen_name" : "danteshepherd",
      "indices" : [ 3, 17 ],
      "id_str" : "15221364",
      "id" : 15221364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346304025685274624",
  "text" : "RT @danteshepherd: Maybe if we don't teach to the test in high school, students could get well-rounded there, and then specialize in colleg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346303343536242688",
    "text" : "Maybe if we don't teach to the test in high school, students could get well-rounded there, and then specialize in college. Like supposed to.",
    "id" : 346303343536242688,
    "created_at" : "2013-06-16 16:28:45 +0000",
    "user" : {
      "name" : "Lucas Landherr",
      "screen_name" : "danteshepherd",
      "protected" : false,
      "id_str" : "15221364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793601733167644672\/3_5bAala_normal.jpg",
      "id" : 15221364,
      "verified" : false
    }
  },
  "id" : 346304025685274624,
  "created_at" : "2013-06-16 16:31:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saint",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346303726551724032",
  "text" : "DH has been both mom and dad to DD. he's essentially raised 2 children. he will get very nice mansion on other side. : ) #saint",
  "id" : 346303726551724032,
  "created_at" : "2013-06-16 16:30:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346290629216718848",
  "geo" : { },
  "id_str" : "346299116168544256",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible i love the questions you ask. shaking things up. seeing from a different perspective. makes us think. : )",
  "id" : 346299116168544256,
  "in_reply_to_status_id" : 346290629216718848,
  "created_at" : "2013-06-16 16:11:57 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "God",
      "indices" : [ 18, 22 ]
    }, {
      "text" : "CosmicConsciousness",
      "indices" : [ 51, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346298122235944960",
  "text" : "RT @DeepakChopra: #God is the intoxication of love #CosmicConsciousness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "God",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "CosmicConsciousness",
        "indices" : [ 33, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "346293107509321729",
    "text" : "#God is the intoxication of love #CosmicConsciousness",
    "id" : 346293107509321729,
    "created_at" : "2013-06-16 15:48:05 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 346298122235944960,
  "created_at" : "2013-06-16 16:08:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346287980480192514",
  "geo" : { },
  "id_str" : "346297891645689857",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits yup...",
  "id" : 346297891645689857,
  "in_reply_to_status_id" : 346287980480192514,
  "created_at" : "2013-06-16 16:07:05 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shewantsdaddy",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346295782019854337",
  "text" : "just me and the dog today. the dog is moping. #shewantsdaddy",
  "id" : 346295782019854337,
  "created_at" : "2013-06-16 15:58:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 13, 28 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SkypilotOfHope\/status\/346062212445659136\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/pZw9bIo0Co",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BM11v6tCYAEWBEt.jpg",
      "id_str" : "346062212449853441",
      "id" : 346062212449853441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BM11v6tCYAEWBEt.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 1836
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pZw9bIo0Co"
    } ],
    "hashtags" : [ {
      "text" : "JustChill",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346062212445659136",
  "geo" : { },
  "id_str" : "346071897026482176",
  "in_reply_to_user_id" : 140291463,
  "text" : "wisdom... RT @SkypilotOfHope \"Relax, everyone,\" says Luke. #JustChill http:\/\/t.co\/pZw9bIo0Co",
  "id" : 346071897026482176,
  "in_reply_to_status_id" : 346062212445659136,
  "created_at" : "2013-06-16 01:09:04 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/QeqPjO0JRh",
      "expanded_url" : "http:\/\/www.albanycomicbookshow.com\/",
      "display_url" : "albanycomicbookshow.com"
    } ]
  },
  "geo" : { },
  "id_str" : "346047187291082752",
  "text" : "DH and DD tomorrow &gt;&gt; http:\/\/t.co\/QeqPjO0JRh DD gets dressed up.",
  "id" : 346047187291082752,
  "created_at" : "2013-06-15 23:30:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "346025765130883073",
  "text" : "DD is playing awfully sad Naruto video game.. his parents dying.. omg..",
  "id" : 346025765130883073,
  "created_at" : "2013-06-15 22:05:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345942507722510336",
  "geo" : { },
  "id_str" : "345944935930929152",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater LOLOL.. love that expression :D",
  "id" : 345944935930929152,
  "in_reply_to_status_id" : 345942507722510336,
  "created_at" : "2013-06-15 16:44:34 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Peterson",
      "screen_name" : "doghauler",
      "indices" : [ 0, 10 ],
      "id_str" : "19422439",
      "id" : 19422439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345930718091833344",
  "geo" : { },
  "id_str" : "345931312609251328",
  "in_reply_to_user_id" : 19422439,
  "text" : "@doghauler aww.. sweet",
  "id" : 345931312609251328,
  "in_reply_to_status_id" : 345930718091833344,
  "created_at" : "2013-06-15 15:50:26 +0000",
  "in_reply_to_screen_name" : "doghauler",
  "in_reply_to_user_id_str" : "19422439",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JaccTrippa",
      "screen_name" : "JaccTrippa",
      "indices" : [ 0, 11 ],
      "id_str" : "2511524274",
      "id" : 2511524274
    }, {
      "name" : "Harpy",
      "screen_name" : "harpyqueen",
      "indices" : [ 47, 58 ],
      "id_str" : "155371642",
      "id" : 155371642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345780873704116224",
  "geo" : { },
  "id_str" : "345930993393360896",
  "in_reply_to_user_id" : 70442983,
  "text" : "@JaccTrippa already been doing that since 1985 @harpyqueen",
  "id" : 345930993393360896,
  "in_reply_to_status_id" : 345780873704116224,
  "created_at" : "2013-06-15 15:49:10 +0000",
  "in_reply_to_screen_name" : "Exodus_1831",
  "in_reply_to_user_id_str" : "70442983",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345928160963096579",
  "geo" : { },
  "id_str" : "345928637016584192",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 very cool...lol",
  "id" : 345928637016584192,
  "in_reply_to_status_id" : 345928160963096579,
  "created_at" : "2013-06-15 15:39:48 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bluebirds",
      "indices" : [ 29, 39 ]
    }, {
      "text" : "photo",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "birds",
      "indices" : [ 82, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/zC7rPs04KM",
      "expanded_url" : "http:\/\/bit.ly\/13tpmYp",
      "display_url" : "bit.ly\/13tpmYp"
    } ]
  },
  "geo" : { },
  "id_str" : "345922795529711616",
  "text" : "RT @MartinBelan: 5 Fledgling #Bluebirds on a Branch http:\/\/t.co\/zC7rPs04KM #photo #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bluebirds",
        "indices" : [ 12, 22 ]
      }, {
        "text" : "photo",
        "indices" : [ 58, 64 ]
      }, {
        "text" : "birds",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/zC7rPs04KM",
        "expanded_url" : "http:\/\/bit.ly\/13tpmYp",
        "display_url" : "bit.ly\/13tpmYp"
      } ]
    },
    "geo" : { },
    "id_str" : "345919279474024449",
    "text" : "5 Fledgling #Bluebirds on a Branch http:\/\/t.co\/zC7rPs04KM #photo #birds",
    "id" : 345919279474024449,
    "created_at" : "2013-06-15 15:02:37 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 345922795529711616,
  "created_at" : "2013-06-15 15:16:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theendishere",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345907287568822273",
  "text" : "we are all going down together whether you like it or not #theendishere",
  "id" : 345907287568822273,
  "created_at" : "2013-06-15 14:14:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mohan pande",
      "screen_name" : "DoctorMP",
      "indices" : [ 3, 12 ],
      "id_str" : "60193717",
      "id" : 60193717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345906348380274689",
  "text" : "RT @DoctorMP: I am so clever that sometimes I don't understand a single word of what I am saying.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345903387734327296",
    "text" : "I am so clever that sometimes I don't understand a single word of what I am saying.",
    "id" : 345903387734327296,
    "created_at" : "2013-06-15 13:59:28 +0000",
    "user" : {
      "name" : "mohan pande",
      "screen_name" : "DoctorMP",
      "protected" : false,
      "id_str" : "60193717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459189041506680832\/GETk_w-p_normal.jpeg",
      "id" : 60193717,
      "verified" : false
    }
  },
  "id" : 345906348380274689,
  "created_at" : "2013-06-15 14:11:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345723839461859332",
  "text" : "boss's son gave DH a fancy beer for picking him up on a friday night. sweet kid. : )",
  "id" : 345723839461859332,
  "created_at" : "2013-06-15 02:06:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RC deWinter",
      "screen_name" : "RCdeWinter",
      "indices" : [ 3, 14 ],
      "id_str" : "41207820",
      "id" : 41207820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RCdeWinter\/status\/344964297564225536\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ioGyHifi4f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMmPM3DCAAEW0-i.jpg",
      "id_str" : "344964297568419841",
      "id" : 344964297568419841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMmPM3DCAAEW0-i.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 506
      } ],
      "display_url" : "pic.twitter.com\/ioGyHifi4f"
    } ],
    "hashtags" : [ {
      "text" : "StopTheWOW",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345722074490351616",
  "text" : "RT @RCdeWinter: Oh, goody, let's persecute women who suffer miscarriages! WTF is WRONG with these people? #StopTheWOW http:\/\/t.co\/ioGyHifi4f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RCdeWinter\/status\/344964297564225536\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ioGyHifi4f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMmPM3DCAAEW0-i.jpg",
        "id_str" : "344964297568419841",
        "id" : 344964297568419841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMmPM3DCAAEW0-i.jpg",
        "sizes" : [ {
          "h" : 322,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 506
        } ],
        "display_url" : "pic.twitter.com\/ioGyHifi4f"
      } ],
      "hashtags" : [ {
        "text" : "StopTheWOW",
        "indices" : [ 90, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345696556852330501",
    "text" : "Oh, goody, let's persecute women who suffer miscarriages! WTF is WRONG with these people? #StopTheWOW http:\/\/t.co\/ioGyHifi4f",
    "id" : 345696556852330501,
    "created_at" : "2013-06-15 00:17:36 +0000",
    "user" : {
      "name" : "RC deWinter",
      "screen_name" : "RCdeWinter",
      "protected" : false,
      "id_str" : "41207820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784598106772037632\/hxSylEn7_normal.jpg",
      "id" : 41207820,
      "verified" : false
    }
  },
  "id" : 345722074490351616,
  "created_at" : "2013-06-15 01:59:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345703704885878786",
  "geo" : { },
  "id_str" : "345704251462397952",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 sweet dreams, precious kitty",
  "id" : 345704251462397952,
  "in_reply_to_status_id" : 345703704885878786,
  "created_at" : "2013-06-15 00:48:11 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345694142271205376",
  "geo" : { },
  "id_str" : "345703527248711680",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth nice job!",
  "id" : 345703527248711680,
  "in_reply_to_status_id" : 345694142271205376,
  "created_at" : "2013-06-15 00:45:18 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345694374866321408",
  "geo" : { },
  "id_str" : "345703288030756864",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth ohh cute room!",
  "id" : 345703288030756864,
  "in_reply_to_status_id" : 345694374866321408,
  "created_at" : "2013-06-15 00:44:21 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345694805629739008",
  "geo" : { },
  "id_str" : "345703103187791874",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits good to know. except im allergic. exchange for vicodin?",
  "id" : 345703103187791874,
  "in_reply_to_status_id" : 345694805629739008,
  "created_at" : "2013-06-15 00:43:37 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "germansheperd",
      "indices" : [ 58, 72 ]
    }, {
      "text" : "rochester",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "NY",
      "indices" : [ 84, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/1PrDLlt5jW",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2013\/06\/city-council-president-fights-city-to-get-owners-dog-back\/",
      "display_url" : "lifewithdogs.tv\/2013\/06\/city-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345697351513538560",
  "text" : "City took his dog and gave it away http:\/\/t.co\/1PrDLlt5jW #germansheperd #rochester #NY",
  "id" : 345697351513538560,
  "created_at" : "2013-06-15 00:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345685651972321280",
  "geo" : { },
  "id_str" : "345693224448434176",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time awwww! : )",
  "id" : 345693224448434176,
  "in_reply_to_status_id" : 345685651972321280,
  "created_at" : "2013-06-15 00:04:22 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345668112366047232",
  "text" : "2 teen girls and 1 dog upstairs videochatting w teen boy .. : O",
  "id" : 345668112366047232,
  "created_at" : "2013-06-14 22:24:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345621606741180416",
  "text" : "RT @richarddoetsch: Would you spend $200,000 without a guarantee, warranty, or chance for a refund? Hello college education!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345612807439536128",
    "text" : "Would you spend $200,000 without a guarantee, warranty, or chance for a refund? Hello college education!",
    "id" : 345612807439536128,
    "created_at" : "2013-06-14 18:44:49 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 345621606741180416,
  "created_at" : "2013-06-14 19:19:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345621537489051648",
  "text" : "@Skeptical_Lady LOLOL",
  "id" : 345621537489051648,
  "created_at" : "2013-06-14 19:19:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.amazon.com\" rel=\"nofollow\"\u003EAmazon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 82, 93 ],
      "id_str" : "38417795",
      "id" : 38417795
    }, {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "indices" : [ 106, 111 ],
      "id_str" : "355689205",
      "id" : 355689205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/khw9ruD5mZ",
      "expanded_url" : "http:\/\/www.amazon.com\/dp\/B008OPDZ78\/ref=cm_sw_r_tw_ask_x0piF.1BGV1M6",
      "display_url" : "amazon.com\/dp\/B008OPDZ78\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345596824993796096",
  "text" : "I just won: Hens and Chickens (Book 1 in The Sovereign Series) by Jennifer Wixson @chickenjen - Thanks to @eink : ) http:\/\/t.co\/khw9ruD5mZ",
  "id" : 345596824993796096,
  "created_at" : "2013-06-14 17:41:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345587125770653698",
  "text" : "@SamsaricWarrior that's deep...",
  "id" : 345587125770653698,
  "created_at" : "2013-06-14 17:02:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345585758096211968",
  "geo" : { },
  "id_str" : "345586153363234816",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth LOLOL",
  "id" : 345586153363234816,
  "in_reply_to_status_id" : 345585758096211968,
  "created_at" : "2013-06-14 16:58:54 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345584096912752641",
  "text" : "do not be afraid, my lovelies.",
  "id" : 345584096912752641,
  "created_at" : "2013-06-14 16:50:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345582605208522752",
  "text" : "RT @stream_enterer: Four galloping horses in four different directions. And silence.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345575206762467328",
    "text" : "Four galloping horses in four different directions. And silence.",
    "id" : 345575206762467328,
    "created_at" : "2013-06-14 16:15:24 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 345582605208522752,
  "created_at" : "2013-06-14 16:44:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345582342594785280",
  "text" : ". @1stCitizenKane are there no movie writers anymore? it seems movies lately are rip offs of books...",
  "id" : 345582342594785280,
  "created_at" : "2013-06-14 16:43:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345581084693651459",
  "text" : "@1stCitizenKane aliens have been taking bets and are waiting anxiously...",
  "id" : 345581084693651459,
  "created_at" : "2013-06-14 16:38:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bacon",
      "screen_name" : "Baconmints",
      "indices" : [ 3, 14 ],
      "id_str" : "52878253",
      "id" : 52878253
    }, {
      "name" : "NewWisGov",
      "screen_name" : "NewWisGov",
      "indices" : [ 45, 55 ],
      "id_str" : "1245361106",
      "id" : 1245361106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wiunion",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "p2",
      "indices" : [ 37, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345345716429918208",
  "text" : "RT @Baconmints: Disgusting. #wiunion #p2 \/RT @NewWisGov: This angry Wisconsin man says forcing ultrasounds on women is NOT debatable: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NewWisGov",
        "screen_name" : "NewWisGov",
        "indices" : [ 29, 39 ],
        "id_str" : "1245361106",
        "id" : 1245361106
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wiunion",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "p2",
        "indices" : [ 21, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/phfjPudO4v",
        "expanded_url" : "http:\/\/youtu.be\/2iRmaT9KIl4",
        "display_url" : "youtu.be\/2iRmaT9KIl4"
      } ]
    },
    "geo" : { },
    "id_str" : "344947712556417024",
    "text" : "Disgusting. #wiunion #p2 \/RT @NewWisGov: This angry Wisconsin man says forcing ultrasounds on women is NOT debatable: http:\/\/t.co\/phfjPudO4v",
    "id" : 344947712556417024,
    "created_at" : "2013-06-12 22:41:58 +0000",
    "user" : {
      "name" : "Bacon",
      "screen_name" : "Baconmints",
      "protected" : false,
      "id_str" : "52878253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799277595418394624\/w34rpivk_normal.jpg",
      "id" : 52878253,
      "verified" : false
    }
  },
  "id" : 345345716429918208,
  "created_at" : "2013-06-14 01:03:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345342338299740161",
  "text" : "RT @CrystalLewis: I'm always blown away by how desperately we wish for divine retribution. It says more about us than it does about God. #T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThereIsNoHell",
        "indices" : [ 119, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345340928615145472",
    "text" : "I'm always blown away by how desperately we wish for divine retribution. It says more about us than it does about God. #ThereIsNoHell",
    "id" : 345340928615145472,
    "created_at" : "2013-06-14 00:44:28 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 345342338299740161,
  "created_at" : "2013-06-14 00:50:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345327835189227521",
  "text" : "@statue_dog aww.. poor lil dear *gentle kitty scritches*",
  "id" : 345327835189227521,
  "created_at" : "2013-06-13 23:52:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yesilikethewoowoo",
      "indices" : [ 73, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/MkqBY01nU7",
      "expanded_url" : "http:\/\/www.peterheck.com\/speaking\/vnewager",
      "display_url" : "peterheck.com\/speaking\/vnewa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345292474647973888",
  "text" : "guess im a new ager? lol \"How do you define God?\" http:\/\/t.co\/MkqBY01nU7 #yesilikethewoowoo",
  "id" : 345292474647973888,
  "created_at" : "2013-06-13 21:31:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/1oyPsVzFFi",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/friendlyatheist\/2013\/06\/12\/faculty-speaker-at-public-school-graduation-we-dont-need-more-women-as-ceos\/",
      "display_url" : "patheos.com\/blogs\/friendly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345290527765307393",
  "text" : "Faculty Speaker at Public School Graduation: \u2018We Don\u2019t Need More Women as CEOs\u2019 http:\/\/t.co\/1oyPsVzFFi",
  "id" : 345290527765307393,
  "created_at" : "2013-06-13 21:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345243673975476224",
  "geo" : { },
  "id_str" : "345244669489344512",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen my DD, 18yo, still worships the ground her daddy walks on. She tells ppl \"he knows everything\" .. lol",
  "id" : 345244669489344512,
  "in_reply_to_status_id" : 345243673975476224,
  "created_at" : "2013-06-13 18:21:58 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345243706217082881",
  "text" : "RT @JALpalyul: Everything that you have ever experienced is completely relative, completely artificially constructed and totally experienti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345242936386138112",
    "text" : "Everything that you have ever experienced is completely relative, completely artificially constructed and totally experiential.",
    "id" : 345242936386138112,
    "created_at" : "2013-06-13 18:15:04 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 345243706217082881,
  "created_at" : "2013-06-13 18:18:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScottishHighland",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/BZtDcEUB9T",
      "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
      "display_url" : "facebook.com\/HighlandFarmsO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "345217503103950849",
  "text" : "RT @ChickenJen: follow our adventures on the farm in central Maine https:\/\/t.co\/BZtDcEUB9T we raise #ScottishHighland cattle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScottishHighland",
        "indices" : [ 84, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/BZtDcEUB9T",
        "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
        "display_url" : "facebook.com\/HighlandFarmsO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "345216711890440192",
    "text" : "follow our adventures on the farm in central Maine https:\/\/t.co\/BZtDcEUB9T we raise #ScottishHighland cattle",
    "id" : 345216711890440192,
    "created_at" : "2013-06-13 16:30:52 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 345217503103950849,
  "created_at" : "2013-06-13 16:34:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345216726645997569",
  "text" : "RT @ChrisCapparell: This is disturbing. Clearly there is something horribly wrong with the education system if it invokes this. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisCapparell\/status\/345216559888879617\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/yzj3QoPSx8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMp0oddCUAE9nXy.png",
        "id_str" : "345216559897268225",
        "id" : 345216559897268225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMp0oddCUAE9nXy.png",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 592
        } ],
        "display_url" : "pic.twitter.com\/yzj3QoPSx8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345216559888879617",
    "text" : "This is disturbing. Clearly there is something horribly wrong with the education system if it invokes this. http:\/\/t.co\/yzj3QoPSx8",
    "id" : 345216559888879617,
    "created_at" : "2013-06-13 16:30:16 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 345216726645997569,
  "created_at" : "2013-06-13 16:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "indices" : [ 3, 8 ],
      "id_str" : "355689205",
      "id" : 355689205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eBooks",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/8pB8ztBpKd",
      "expanded_url" : "http:\/\/buzz.mw\/-tJ8_y",
      "display_url" : "buzz.mw\/-tJ8_y"
    } ]
  },
  "geo" : { },
  "id_str" : "345211819767496705",
  "text" : "RT @EInk: It\u2019s almost Friday! Drawings for free #eBooks happen every Friday at noon ET. Enter to win here:    http:\/\/t.co\/8pB8ztBpKd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.meltwaterbuzz.com\" rel=\"nofollow\"\u003EMeltwater Buzz\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eBooks",
        "indices" : [ 38, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/8pB8ztBpKd",
        "expanded_url" : "http:\/\/buzz.mw\/-tJ8_y",
        "display_url" : "buzz.mw\/-tJ8_y"
      } ]
    },
    "geo" : { },
    "id_str" : "345210473773404160",
    "text" : "It\u2019s almost Friday! Drawings for free #eBooks happen every Friday at noon ET. Enter to win here:    http:\/\/t.co\/8pB8ztBpKd",
    "id" : 345210473773404160,
    "created_at" : "2013-06-13 16:06:05 +0000",
    "user" : {
      "name" : "E Ink",
      "screen_name" : "EInk",
      "protected" : false,
      "id_str" : "355689205",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1909407234\/twitter_prof_icon_normal.png",
      "id" : 355689205,
      "verified" : false
    }
  },
  "id" : 345211819767496705,
  "created_at" : "2013-06-13 16:11:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345196626782060545",
  "geo" : { },
  "id_str" : "345197580717785089",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom agreed.",
  "id" : 345197580717785089,
  "in_reply_to_status_id" : 345196626782060545,
  "created_at" : "2013-06-13 15:14:51 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345196388235218944",
  "geo" : { },
  "id_str" : "345197465424764928",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom ahhh, i see. i didnt take it to mean such but to live life w\/out fear. follow your dreams, etc.",
  "id" : 345197465424764928,
  "in_reply_to_status_id" : 345196388235218944,
  "created_at" : "2013-06-13 15:14:23 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345188469334749185",
  "geo" : { },
  "id_str" : "345194743694761984",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom ??",
  "id" : 345194743694761984,
  "in_reply_to_status_id" : 345188469334749185,
  "created_at" : "2013-06-13 15:03:34 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345194048157532160",
  "text" : "@1stCitizenKane no problem.. just teleport there!",
  "id" : 345194048157532160,
  "created_at" : "2013-06-13 15:00:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Steve LeGendre",
      "screen_name" : "windowsot",
      "indices" : [ 3, 13 ],
      "id_str" : "24274908",
      "id" : 24274908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345193488310222848",
  "text" : "RT @windowsot: My view is, rather than being followed and following, we walk along the stream side by side exchanging thoughts and ideas.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344496991730012161",
    "text" : "My view is, rather than being followed and following, we walk along the stream side by side exchanging thoughts and ideas.",
    "id" : 344496991730012161,
    "created_at" : "2013-06-11 16:50:57 +0000",
    "user" : {
      "name" : "Rob Steve LeGendre",
      "screen_name" : "windowsot",
      "protected" : false,
      "id_str" : "24274908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000717433867\/a26ebe785a236f0d882cd6951df54b9a_normal.jpeg",
      "id" : 24274908,
      "verified" : false
    }
  },
  "id" : 345193488310222848,
  "created_at" : "2013-06-13 14:58:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "indices" : [ 3, 17 ],
      "id_str" : "265007259",
      "id" : 265007259
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/345191770197471235\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/kefrK7G8n5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMpeFgpCMAEEelu.png",
      "id_str" : "345191770201665537",
      "id" : 345191770201665537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMpeFgpCMAEEelu.png",
      "sizes" : [ {
        "h" : 647,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/kefrK7G8n5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345192088498995200",
  "text" : "RT @atheistlady76: Vagina http:\/\/t.co\/kefrK7G8n5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/atheistlady76\/status\/345191770197471235\/photo\/1",
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/kefrK7G8n5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMpeFgpCMAEEelu.png",
        "id_str" : "345191770201665537",
        "id" : 345191770201665537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMpeFgpCMAEEelu.png",
        "sizes" : [ {
          "h" : 647,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/kefrK7G8n5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345191770197471235",
    "text" : "Vagina http:\/\/t.co\/kefrK7G8n5",
    "id" : 345191770197471235,
    "created_at" : "2013-06-13 14:51:46 +0000",
    "user" : {
      "name" : "Just Call Me Jess",
      "screen_name" : "atheistlady76",
      "protected" : false,
      "id_str" : "265007259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797172650669916160\/SwWa9T5B_normal.jpg",
      "id" : 265007259,
      "verified" : false
    }
  },
  "id" : 345192088498995200,
  "created_at" : "2013-06-13 14:53:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345181542588493827",
  "geo" : { },
  "id_str" : "345184028380499968",
  "in_reply_to_user_id" : 260028159,
  "text" : "@CoyotesWisdom in the post says its mystery becuz we are to pay max attention to THIS life. i liked that.",
  "id" : 345184028380499968,
  "in_reply_to_status_id" : 345181542588493827,
  "created_at" : "2013-06-13 14:21:00 +0000",
  "in_reply_to_screen_name" : "LilMissCoyote",
  "in_reply_to_user_id_str" : "260028159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hell",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/1wtLeHNTi8",
      "expanded_url" : "http:\/\/wp.me\/p17ivu-3Ug",
      "display_url" : "wp.me\/p17ivu-3Ug"
    } ]
  },
  "geo" : { },
  "id_str" : "345178576007622656",
  "text" : "Using the Bible as proof of what happens after we die is like using a telescope to row a canoe. http:\/\/t.co\/1wtLeHNTi8 #Hell",
  "id" : 345178576007622656,
  "created_at" : "2013-06-13 13:59:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Alviani",
      "screen_name" : "jalviani",
      "indices" : [ 3, 12 ],
      "id_str" : "133860535",
      "id" : 133860535
    }, {
      "name" : "Aetna",
      "screen_name" : "Aetna",
      "indices" : [ 30, 36 ],
      "id_str" : "16188518",
      "id" : 16188518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345169632363151361",
  "text" : "RT @jalviani: I'm amazed that @Aetna can override a decision from my doctor for a prescription and make it so that I have to pay full price.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aetna",
        "screen_name" : "Aetna",
        "indices" : [ 16, 22 ],
        "id_str" : "16188518",
        "id" : 16188518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345160083304488960",
    "text" : "I'm amazed that @Aetna can override a decision from my doctor for a prescription and make it so that I have to pay full price.",
    "id" : 345160083304488960,
    "created_at" : "2013-06-13 12:45:51 +0000",
    "user" : {
      "name" : "Joseph Alviani",
      "screen_name" : "jalviani",
      "protected" : false,
      "id_str" : "133860535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775700191894798340\/ZHzSR6aZ_normal.jpg",
      "id" : 133860535,
      "verified" : false
    }
  },
  "id" : 345169632363151361,
  "created_at" : "2013-06-13 13:23:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "...",
      "screen_name" : "mywits_end",
      "indices" : [ 3, 14 ],
      "id_str" : "467890062",
      "id" : 467890062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HealthCare",
      "indices" : [ 61, 72 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345169301587755009",
  "text" : "RT @mywits_end: The idea that people can argue for essential #HealthCare to be a commodity will always disgust and confuse me. #SinglePayer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HealthCare",
        "indices" : [ 45, 56 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344982074396143616",
    "text" : "The idea that people can argue for essential #HealthCare to be a commodity will always disgust and confuse me. #SinglePayer",
    "id" : 344982074396143616,
    "created_at" : "2013-06-13 00:58:30 +0000",
    "user" : {
      "name" : "...",
      "screen_name" : "mywits_end",
      "protected" : false,
      "id_str" : "467890062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3699820317\/1bb38d527de292edbb7fb15eb29fa36b_normal.jpeg",
      "id" : 467890062,
      "verified" : false
    }
  },
  "id" : 345169301587755009,
  "created_at" : "2013-06-13 13:22:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Bukowski Quotes",
      "screen_name" : "bukquotes",
      "indices" : [ 28, 38 ],
      "id_str" : "2649350370",
      "id" : 2649350370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "345151777286524928",
  "text" : "RT @TrishScott: Exactly. RT @bukquotes: \"Security? You could get security in jail.\" ~ Charles Bukowski",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bukowski Quotes",
        "screen_name" : "bukquotes",
        "indices" : [ 12, 22 ],
        "id_str" : "2649350370",
        "id" : 2649350370
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "345149812452257792",
    "text" : "Exactly. RT @bukquotes: \"Security? You could get security in jail.\" ~ Charles Bukowski",
    "id" : 345149812452257792,
    "created_at" : "2013-06-13 12:05:02 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 345151777286524928,
  "created_at" : "2013-06-13 12:12:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344992813408215041",
  "geo" : { },
  "id_str" : "345000225884213248",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 me,too",
  "id" : 345000225884213248,
  "in_reply_to_status_id" : 344992813408215041,
  "created_at" : "2013-06-13 02:10:38 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/3w53TclpZt",
      "expanded_url" : "https:\/\/www.facebook.com\/TheChristianLeft\/posts\/582076708481137",
      "display_url" : "facebook.com\/TheChristianLe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344963408665403392",
  "text" : "\"i dont mind straight people as long as they act gay in public\" https:\/\/t.co\/3w53TclpZt",
  "id" : 344963408665403392,
  "created_at" : "2013-06-12 23:44:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smartypants",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344954614426238976",
  "text" : "@1stCitizenKane i flunked my way thru school.. so naturally, i dont like you... #smartypants",
  "id" : 344954614426238976,
  "created_at" : "2013-06-12 23:09:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/IZ4sBRPfk7",
      "expanded_url" : "http:\/\/amazoncruelty.com\/",
      "display_url" : "amazoncruelty.com"
    } ]
  },
  "geo" : { },
  "id_str" : "344950604428357632",
  "text" : "RT @ducksandclucks: Please take 1 minute to sign this petition, for the ducks. http:\/\/t.co\/IZ4sBRPfk7 You don't have to view the video. Jus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/IZ4sBRPfk7",
        "expanded_url" : "http:\/\/amazoncruelty.com\/",
        "display_url" : "amazoncruelty.com"
      } ]
    },
    "geo" : { },
    "id_str" : "344938255894077440",
    "text" : "Please take 1 minute to sign this petition, for the ducks. http:\/\/t.co\/IZ4sBRPfk7 You don't have to view the video. Just sign. Thank you.",
    "id" : 344938255894077440,
    "created_at" : "2013-06-12 22:04:23 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 344950604428357632,
  "created_at" : "2013-06-12 22:53:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8RzpuiYMAs",
      "expanded_url" : "http:\/\/youtu.be\/73_ds1xQmD4",
      "display_url" : "youtu.be\/73_ds1xQmD4"
    } ]
  },
  "geo" : { },
  "id_str" : "344949795137388544",
  "text" : "20something asks \"Why is America the greatest country in the world?\" http:\/\/t.co\/8RzpuiYMAs",
  "id" : 344949795137388544,
  "created_at" : "2013-06-12 22:50:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344947720143904768",
  "text" : "RT @SangyeH: No money for food stamps, HeadStart, veterans or infrastructure. But LOTS of money for drones &amp; massive surveillance. #priorit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "priorities",
        "indices" : [ 122, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344944839919562752",
    "text" : "No money for food stamps, HeadStart, veterans or infrastructure. But LOTS of money for drones &amp; massive surveillance. #priorities",
    "id" : 344944839919562752,
    "created_at" : "2013-06-12 22:30:33 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 344947720143904768,
  "created_at" : "2013-06-12 22:41:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 28, 35 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 12, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344924786654330880",
  "geo" : { },
  "id_str" : "344925728602730496",
  "in_reply_to_user_id" : 13118692,
  "text" : "why we need #SinglePayer MT @moosep stopped by drug store to pick up prescription but insurance co needs to approve before it can be filled",
  "id" : 344925728602730496,
  "in_reply_to_status_id" : 344924786654330880,
  "created_at" : "2013-06-12 21:14:36 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Rodrigues",
      "screen_name" : "annihilist",
      "indices" : [ 0, 11 ],
      "id_str" : "20016044",
      "id" : 20016044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344899105400688640",
  "geo" : { },
  "id_str" : "344899907984965633",
  "in_reply_to_user_id" : 20016044,
  "text" : "@annihilist good question. myself, dont believe in typical heaven\/hell.",
  "id" : 344899907984965633,
  "in_reply_to_status_id" : 344899105400688640,
  "created_at" : "2013-06-12 19:32:00 +0000",
  "in_reply_to_screen_name" : "annihilist",
  "in_reply_to_user_id_str" : "20016044",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344898950102409216",
  "text" : "DD playing some Naruto game and Sasuke has turned evil.. omg.. this is incredibly sad.",
  "id" : 344898950102409216,
  "created_at" : "2013-06-12 19:28:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344875159716519936",
  "text" : "DD finished exams today. its officially summer now.",
  "id" : 344875159716519936,
  "created_at" : "2013-06-12 17:53:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344857999870947329",
  "geo" : { },
  "id_str" : "344864947009884161",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist what was before there was something is what we are made of.",
  "id" : 344864947009884161,
  "in_reply_to_status_id" : 344857999870947329,
  "created_at" : "2013-06-12 17:13:05 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344847358904913920",
  "geo" : { },
  "id_str" : "344852561054011392",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist god loves us cuz we are god : )",
  "id" : 344852561054011392,
  "in_reply_to_status_id" : 344847358904913920,
  "created_at" : "2013-06-12 16:23:52 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344852062548406272",
  "text" : "RT @wow_trees: Why do female nipples have to be covered up hut not male nipples?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344849181921382400",
    "text" : "Why do female nipples have to be covered up hut not male nipples?",
    "id" : 344849181921382400,
    "created_at" : "2013-06-12 16:10:26 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 344852062548406272,
  "created_at" : "2013-06-12 16:21:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344830422741565440",
  "text" : "the problem is that the answers to my questions are over my head!",
  "id" : 344830422741565440,
  "created_at" : "2013-06-12 14:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Captain FuckKnuckle",
      "screen_name" : "Cavictaler",
      "indices" : [ 0, 11 ],
      "id_str" : "266275672",
      "id" : 266275672
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 116, 131 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344823873809809408",
  "geo" : { },
  "id_str" : "344830045413584896",
  "in_reply_to_user_id" : 266275672,
  "text" : "@Cavictaler watching wormhole w morgan freeman discussing time; exp on each side of real or illusion.. fascinating. @AnnotatedBible",
  "id" : 344830045413584896,
  "in_reply_to_status_id" : 344823873809809408,
  "created_at" : "2013-06-12 14:54:24 +0000",
  "in_reply_to_screen_name" : "Cavictaler",
  "in_reply_to_user_id_str" : "266275672",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Vita Bella",
      "screen_name" : "BeyondMeds",
      "indices" : [ 49, 60 ],
      "id_str" : "307559685",
      "id" : 307559685
    }, {
      "name" : "nellalou",
      "screen_name" : "NellaLou",
      "indices" : [ 108, 117 ],
      "id_str" : "68864556",
      "id" : 68864556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/LAUFcTRjaM",
      "expanded_url" : "http:\/\/www.paulgraham.com\/say.html",
      "display_url" : "paulgraham.com\/say.html"
    } ]
  },
  "geo" : { },
  "id_str" : "344825838929330176",
  "text" : "RT @TrishScott: Longish read. Read it anyway. RT @BeyondMeds: What you can't say http:\/\/t.co\/LAUFcTRjaM via @NellaLou",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vita Bella",
        "screen_name" : "BeyondMeds",
        "indices" : [ 33, 44 ],
        "id_str" : "307559685",
        "id" : 307559685
      }, {
        "name" : "nellalou",
        "screen_name" : "NellaLou",
        "indices" : [ 92, 101 ],
        "id_str" : "68864556",
        "id" : 68864556
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/LAUFcTRjaM",
        "expanded_url" : "http:\/\/www.paulgraham.com\/say.html",
        "display_url" : "paulgraham.com\/say.html"
      } ]
    },
    "geo" : { },
    "id_str" : "344816431805898753",
    "text" : "Longish read. Read it anyway. RT @BeyondMeds: What you can't say http:\/\/t.co\/LAUFcTRjaM via @NellaLou",
    "id" : 344816431805898753,
    "created_at" : "2013-06-12 14:00:18 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 344825838929330176,
  "created_at" : "2013-06-12 14:37:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344817325490454528",
  "geo" : { },
  "id_str" : "344825039201390592",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time Disgusting!!",
  "id" : 344825039201390592,
  "in_reply_to_status_id" : 344817325490454528,
  "created_at" : "2013-06-12 14:34:30 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/DmdzXTTAEi",
      "expanded_url" : "http:\/\/amzn.to\/zXTmEe",
      "display_url" : "amzn.to\/zXTmEe"
    } ]
  },
  "geo" : { },
  "id_str" : "344646926706278400",
  "text" : "finished Ishmael Toffee by Roger Smith http:\/\/t.co\/DmdzXTTAEi",
  "id" : 344646926706278400,
  "created_at" : "2013-06-12 02:46:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DIANA LYNN BLOKZYL",
      "screen_name" : "NANDEE218",
      "indices" : [ 78, 88 ],
      "id_str" : "34824802",
      "id" : 34824802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344607875978625026",
  "geo" : { },
  "id_str" : "344624302211096577",
  "in_reply_to_user_id" : 924134156,
  "text" : "@Ben_AntiChrist i think there's a lot more peeps like that than you know! : ) @NANDEE218",
  "id" : 344624302211096577,
  "in_reply_to_status_id" : 344607875978625026,
  "created_at" : "2013-06-12 01:16:51 +0000",
  "in_reply_to_screen_name" : "BetrayerofCode",
  "in_reply_to_user_id_str" : "924134156",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/4tmO5CSOxn",
      "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2013\/02\/beg-steal-or-borrow.html",
      "display_url" : "midnightfire.blogspot.no\/2013\/02\/beg-st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344608895265812480",
  "text" : "RT @HoodedMan: Beg, steal or borrow http:\/\/t.co\/4tmO5CSOxn The law is made by the rich and powerful to benefit the rich and the powerful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/4tmO5CSOxn",
        "expanded_url" : "http:\/\/midnightfire.blogspot.no\/2013\/02\/beg-steal-or-borrow.html",
        "display_url" : "midnightfire.blogspot.no\/2013\/02\/beg-st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344607390152396800",
    "text" : "Beg, steal or borrow http:\/\/t.co\/4tmO5CSOxn The law is made by the rich and powerful to benefit the rich and the powerful.",
    "id" : 344607390152396800,
    "created_at" : "2013-06-12 00:09:38 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 344608895265812480,
  "created_at" : "2013-06-12 00:15:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God",
      "screen_name" : "TheTweetOfGod",
      "indices" : [ 0, 14 ],
      "id_str" : "204832963",
      "id" : 204832963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344600453910237185",
  "geo" : { },
  "id_str" : "344605533115908096",
  "in_reply_to_user_id" : 204832963,
  "text" : "@TheTweetOfGod forgive them for they are just afraid and unsure...",
  "id" : 344605533115908096,
  "in_reply_to_status_id" : 344600453910237185,
  "created_at" : "2013-06-12 00:02:16 +0000",
  "in_reply_to_screen_name" : "TheTweetOfGod",
  "in_reply_to_user_id_str" : "204832963",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344605117879824385",
  "text" : "RT @HoodedMan: Humanity remains on track for collective suicide",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344602364822573056",
    "text" : "Humanity remains on track for collective suicide",
    "id" : 344602364822573056,
    "created_at" : "2013-06-11 23:49:40 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 344605117879824385,
  "created_at" : "2013-06-12 00:00:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344603437964595202",
  "geo" : { },
  "id_str" : "344604619437121538",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos LOL",
  "id" : 344604619437121538,
  "in_reply_to_status_id" : 344603437964595202,
  "created_at" : "2013-06-11 23:58:38 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344603725651922944",
  "text" : "@Llimoner_ this is interesting question.. when i was younger, i wanted someone to save me when i felt so desperate.",
  "id" : 344603725651922944,
  "created_at" : "2013-06-11 23:55:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344542906004160512",
  "text" : "RT @CoyoteSings: It's not just the economy. It's the whole political system. If your operating system is corrupt, no files run properly, do\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344542194809581568",
    "text" : "It's not just the economy. It's the whole political system. If your operating system is corrupt, no files run properly, do they?",
    "id" : 344542194809581568,
    "created_at" : "2013-06-11 19:50:35 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 344542906004160512,
  "created_at" : "2013-06-11 19:53:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344536417935970304",
  "geo" : { },
  "id_str" : "344538517914923008",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings the train is gonna crash, then change will come.",
  "id" : 344538517914923008,
  "in_reply_to_status_id" : 344536417935970304,
  "created_at" : "2013-06-11 19:35:58 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "Huge Dough",
      "screen_name" : "thekarelshow",
      "indices" : [ 42, 55 ],
      "id_str" : "2497092385",
      "id" : 2497092385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344535170310893568",
  "geo" : { },
  "id_str" : "344535990519619584",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings so the train is gonna crash? @thekarelshow",
  "id" : 344535990519619584,
  "in_reply_to_status_id" : 344535170310893568,
  "created_at" : "2013-06-11 19:25:55 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344525805692522496",
  "text" : "i dont think much of spelling bees. spelling has nothing to do w intelligence.",
  "id" : 344525805692522496,
  "created_at" : "2013-06-11 18:45:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    }, {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 42, 58 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344489174428180481",
  "geo" : { },
  "id_str" : "344504533696778240",
  "in_reply_to_user_id" : 93747129,
  "text" : "@CubeMelon never mind.. she found it..lol @JourneyTheHedgi",
  "id" : 344504533696778240,
  "in_reply_to_status_id" : 344489174428180481,
  "created_at" : "2013-06-11 17:20:56 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 24, 29 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Za04am7xWg",
      "expanded_url" : "http:\/\/www.facebook.com\/quietfurybooks",
      "display_url" : "facebook.com\/quietfurybooks"
    } ]
  },
  "geo" : { },
  "id_str" : "344493156655566848",
  "text" : "RT @DarciaHelle: Want a #free #audiobook? Pop over to my Facebook page, where I'm giving one away! http:\/\/t.co\/Za04am7xWg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 7, 12 ]
      }, {
        "text" : "audiobook",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/Za04am7xWg",
        "expanded_url" : "http:\/\/www.facebook.com\/quietfurybooks",
        "display_url" : "facebook.com\/quietfurybooks"
      } ]
    },
    "geo" : { },
    "id_str" : "344493018348396545",
    "text" : "Want a #free #audiobook? Pop over to my Facebook page, where I'm giving one away! http:\/\/t.co\/Za04am7xWg",
    "id" : 344493018348396545,
    "created_at" : "2013-06-11 16:35:10 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 344493156655566848,
  "created_at" : "2013-06-11 16:35:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    }, {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 53, 69 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343419713184993282",
  "geo" : { },
  "id_str" : "344489174428180481",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon where do you find friend code on new leaf @JourneyTheHedgi cannot find hers.",
  "id" : 344489174428180481,
  "in_reply_to_status_id" : 343419713184993282,
  "created_at" : "2013-06-11 16:19:54 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 2, 11 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344431390059802624",
  "geo" : { },
  "id_str" : "344443516128227328",
  "in_reply_to_user_id" : 184401626,
  "text" : ". @AniKnits BAAAADDD!!!",
  "id" : 344443516128227328,
  "in_reply_to_status_id" : 344431390059802624,
  "created_at" : "2013-06-11 13:18:28 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/pPs5CpIWwQ",
      "expanded_url" : "http:\/\/thedailycorgi.blogspot.com\/2013\/06\/butt-cam-corgi-tent-waddle.html?spref=tw",
      "display_url" : "thedailycorgi.blogspot.com\/2013\/06\/butt-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344254669670981632",
  "text" : "Adorable!! &gt;&gt; The Daily Corgi: Butt Cam: Corgi Tent Waddle! http:\/\/t.co\/pPs5CpIWwQ",
  "id" : 344254669670981632,
  "created_at" : "2013-06-11 00:48:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344247974597120000",
  "geo" : { },
  "id_str" : "344251566817157121",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth aww.. how can you not smile back at her? *smooches*",
  "id" : 344251566817157121,
  "in_reply_to_status_id" : 344247974597120000,
  "created_at" : "2013-06-11 00:35:44 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344221094049370112",
  "geo" : { },
  "id_str" : "344221929089167360",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce cute... except for the sluts part.. but cute..lol",
  "id" : 344221929089167360,
  "in_reply_to_status_id" : 344221094049370112,
  "created_at" : "2013-06-10 22:37:57 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Byrne",
      "screen_name" : "mcbyrne",
      "indices" : [ 3, 11 ],
      "id_str" : "14372270",
      "id" : 14372270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344217344228335616",
  "text" : "RT @mcbyrne: People with power in society prey on people's economic insecurity and fear of being an outcast.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344215635116572672",
    "text" : "People with power in society prey on people's economic insecurity and fear of being an outcast.",
    "id" : 344215635116572672,
    "created_at" : "2013-06-10 22:12:57 +0000",
    "user" : {
      "name" : "Melissa Byrne",
      "screen_name" : "mcbyrne",
      "protected" : false,
      "id_str" : "14372270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/640377859819859968\/nZVTJnT3_normal.jpg",
      "id" : 14372270,
      "verified" : false
    }
  },
  "id" : 344217344228335616,
  "created_at" : "2013-06-10 22:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344216044824584192",
  "geo" : { },
  "id_str" : "344217248157806592",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth very pretty. love that shade of red.",
  "id" : 344217248157806592,
  "in_reply_to_status_id" : 344216044824584192,
  "created_at" : "2013-06-10 22:19:21 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344196643266101249",
  "geo" : { },
  "id_str" : "344198182449840128",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth thanks : )",
  "id" : 344198182449840128,
  "in_reply_to_status_id" : 344196643266101249,
  "created_at" : "2013-06-10 21:03:36 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Rr7ZtXXrUI",
      "expanded_url" : "https:\/\/www.facebook.com\/russell.campbell.73\/posts\/514886971893653",
      "display_url" : "facebook.com\/russell.campbe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344196301979795457",
  "text" : "dh wrote a beautiful tribute on FB about the fish.. now im getting teary-eyed again. https:\/\/t.co\/Rr7ZtXXrUI",
  "id" : 344196301979795457,
  "created_at" : "2013-06-10 20:56:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/alyLI57YIZ",
      "expanded_url" : "http:\/\/ow.ly\/i\/2iiYT",
      "display_url" : "ow.ly\/i\/2iiYT"
    } ]
  },
  "geo" : { },
  "id_str" : "344168965364404224",
  "text" : "HonkHonkHonk! RT @VTLeads Can we get a \"honk honk?\" http:\/\/t.co\/alyLI57YIZ #singlepayer",
  "id" : 344168965364404224,
  "created_at" : "2013-06-10 19:07:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344168393131298816",
  "text" : "RT @davidpakmanshow: If the US cut its military by a huuuuuuge 75%...it would still have the biggest military in the world. Oh. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/q2sJh1GRpo",
        "expanded_url" : "http:\/\/ow.ly\/lNaVN",
        "display_url" : "ow.ly\/lNaVN"
      } ]
    },
    "geo" : { },
    "id_str" : "344167976968273920",
    "text" : "If the US cut its military by a huuuuuuge 75%...it would still have the biggest military in the world. Oh. http:\/\/t.co\/q2sJh1GRpo",
    "id" : 344167976968273920,
    "created_at" : "2013-06-10 19:03:34 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 344168393131298816,
  "created_at" : "2013-06-10 19:05:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Dave Goldberg",
      "screen_name" : "askaphysicist",
      "indices" : [ 102, 116 ],
      "id_str" : "163283608",
      "id" : 163283608
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344167978071375872",
  "text" : "RT @DuttonBooks: Follow us &amp; RT to enter to #win a copy of THE UNIVERSE IN THE REARVIEW MIRROR by @askaphysicist! US only.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave Goldberg",
        "screen_name" : "askaphysicist",
        "indices" : [ 85, 99 ],
        "id_str" : "163283608",
        "id" : 163283608
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 31, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344167786643345409",
    "text" : "Follow us &amp; RT to enter to #win a copy of THE UNIVERSE IN THE REARVIEW MIRROR by @askaphysicist! US only.",
    "id" : 344167786643345409,
    "created_at" : "2013-06-10 19:02:49 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 344167978071375872,
  "created_at" : "2013-06-10 19:03:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Save Outside the Box",
      "screen_name" : "JoelLarsgaard",
      "indices" : [ 3, 17 ],
      "id_str" : "1157919656",
      "id" : 1157919656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreedomPop",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jIaKAMJHOe",
      "expanded_url" : "http:\/\/www.saveoutsidethebox.com\/free-cell-phone-service-from-freedom-pop-is-legit\/",
      "display_url" : "saveoutsidethebox.com\/free-cell-phon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344157165621215232",
  "text" : "RT @JoelLarsgaard: Free cell phone service is on the way from #FreedomPop. Check out the details here: http:\/\/t.co\/jIaKAMJHOe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreedomPop",
        "indices" : [ 43, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/jIaKAMJHOe",
        "expanded_url" : "http:\/\/www.saveoutsidethebox.com\/free-cell-phone-service-from-freedom-pop-is-legit\/",
        "display_url" : "saveoutsidethebox.com\/free-cell-phon\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "344105905115234304",
    "text" : "Free cell phone service is on the way from #FreedomPop. Check out the details here: http:\/\/t.co\/jIaKAMJHOe",
    "id" : 344105905115234304,
    "created_at" : "2013-06-10 14:56:55 +0000",
    "user" : {
      "name" : "Save Outside the Box",
      "screen_name" : "JoelLarsgaard",
      "protected" : false,
      "id_str" : "1157919656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000022040600\/1e8c885e585f366a30b8460be33bca7d_normal.jpeg",
      "id" : 1157919656,
      "verified" : false
    }
  },
  "id" : 344157165621215232,
  "created_at" : "2013-06-10 18:20:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344147872180224000",
  "text" : "i believe in the afterlife.. but it's not stagnant, heaven or hell.. similar ppl group together. we continue growing, learning.",
  "id" : 344147872180224000,
  "created_at" : "2013-06-10 17:43:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344144046794616832",
  "text" : "RT @gemswinc: Or next you'll be buying bottled air..Resist corporate takeover of food, air &amp; water",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344143319510683648",
    "text" : "Or next you'll be buying bottled air..Resist corporate takeover of food, air &amp; water",
    "id" : 344143319510683648,
    "created_at" : "2013-06-10 17:25:35 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 344144046794616832,
  "created_at" : "2013-06-10 17:28:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nakia",
      "screen_name" : "KiaJD",
      "indices" : [ 3, 9 ],
      "id_str" : "16180686",
      "id" : 16180686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344143938552217600",
  "text" : "RT @KiaJD: When you slut-shame another woman you don't elevate yourself in comparison to her, you contribute to a culture and system that h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344100259934388224",
    "text" : "When you slut-shame another woman you don't elevate yourself in comparison to her, you contribute to a culture and system that hurts us all.",
    "id" : 344100259934388224,
    "created_at" : "2013-06-10 14:34:29 +0000",
    "user" : {
      "name" : "Nakia",
      "screen_name" : "KiaJD",
      "protected" : false,
      "id_str" : "16180686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794299407214804992\/5r5sJm_o_normal.jpg",
      "id" : 16180686,
      "verified" : false
    }
  },
  "id" : 344143938552217600,
  "created_at" : "2013-06-10 17:28:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344142462278828033",
  "text" : "RT @AllOnMedicare: Aetna, Cigna, WellPoint, and UnitedHealthCare don't care if you live or die. They only care about $. Let's replace them \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344141915660353536",
    "text" : "Aetna, Cigna, WellPoint, and UnitedHealthCare don't care if you live or die. They only care about $. Let's replace them with #SinglePayer",
    "id" : 344141915660353536,
    "created_at" : "2013-06-10 17:20:01 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 344142462278828033,
  "created_at" : "2013-06-10 17:22:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedicareForAll",
      "indices" : [ 32, 47 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/to8I40Lmyj",
      "expanded_url" : "http:\/\/medicareforall.health.gov.au\/",
      "display_url" : "medicareforall.health.gov.au"
    } ]
  },
  "geo" : { },
  "id_str" : "344140307488714752",
  "text" : "RT @AllOnMedicare: This is what #MedicareForAll looks like...in Australia. http:\/\/t.co\/to8I40Lmyj #SinglePayer NOW!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedicareForAll",
        "indices" : [ 13, 28 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 79, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/to8I40Lmyj",
        "expanded_url" : "http:\/\/medicareforall.health.gov.au\/",
        "display_url" : "medicareforall.health.gov.au"
      } ]
    },
    "geo" : { },
    "id_str" : "344134222371508224",
    "text" : "This is what #MedicareForAll looks like...in Australia. http:\/\/t.co\/to8I40Lmyj #SinglePayer NOW!",
    "id" : 344134222371508224,
    "created_at" : "2013-06-10 16:49:26 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 344140307488714752,
  "created_at" : "2013-06-10 17:13:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheism",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "god",
      "indices" : [ 62, 66 ]
    }, {
      "text" : "belief",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "LOL",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/WgRtq5T8CA",
      "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=483304071739578&set=a.148116611924994.33707.136531246416864&type=1",
      "display_url" : "facebook.com\/photo.php?fbid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344126725183119360",
  "text" : "believe or not.. no problem  https:\/\/t.co\/WgRtq5T8CA #atheism #god #belief #LOL",
  "id" : 344126725183119360,
  "created_at" : "2013-06-10 16:19:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/wcMPnPwvnT",
      "expanded_url" : "https:\/\/www.facebook.com\/NealeDonaldWalsch\/posts\/10151440269777344",
      "display_url" : "facebook.com\/NealeDonaldWal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "344119668438618114",
  "text" : "\"there is nowhere in anything that God is not\" https:\/\/t.co\/wcMPnPwvnT",
  "id" : 344119668438618114,
  "created_at" : "2013-06-10 15:51:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cichlid",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/EJ7uLVQk5T",
      "expanded_url" : "http:\/\/via.me\/-cp2hdsm",
      "display_url" : "via.me\/-cp2hdsm"
    } ]
  },
  "geo" : { },
  "id_str" : "344116549847764992",
  "text" : "RIP Sparkles. We love you. Thanks for being our fish. #cichlid http:\/\/t.co\/EJ7uLVQk5T",
  "id" : 344116549847764992,
  "created_at" : "2013-06-10 15:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 0, 15 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344096841492754432",
  "geo" : { },
  "id_str" : "344097743595266049",
  "in_reply_to_user_id" : 104029814,
  "text" : "@stream_enterer i do this all the time (well, not necc in the bath..lol)",
  "id" : 344097743595266049,
  "in_reply_to_status_id" : 344096841492754432,
  "created_at" : "2013-06-10 14:24:29 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "God",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344097100730077184",
  "text" : "RT @DeepakChopra: Evolution created brains for survival not for accessing truth which can only be glimpsed through transcendence #God #Cosm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "God",
        "indices" : [ 111, 115 ]
      }, {
        "text" : "CosmicConsciousness",
        "indices" : [ 116, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "344077875504373761",
    "text" : "Evolution created brains for survival not for accessing truth which can only be glimpsed through transcendence #God #CosmicConsciousness",
    "id" : 344077875504373761,
    "created_at" : "2013-06-10 13:05:32 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 344097100730077184,
  "created_at" : "2013-06-10 14:21:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SisterSadist",
      "screen_name" : "SisterSadist",
      "indices" : [ 0, 13 ],
      "id_str" : "2500340330",
      "id" : 2500340330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344082761176461312",
  "geo" : { },
  "id_str" : "344096151034793984",
  "in_reply_to_user_id" : 20987411,
  "text" : "@SisterSadist LOL",
  "id" : 344096151034793984,
  "in_reply_to_status_id" : 344082761176461312,
  "created_at" : "2013-06-10 14:18:10 +0000",
  "in_reply_to_screen_name" : "WrathOfCam",
  "in_reply_to_user_id_str" : "20987411",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344093356416188417",
  "text" : "pens for a gym test... o-O",
  "id" : 344093356416188417,
  "created_at" : "2013-06-10 14:07:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344092710396907520",
  "text" : "our bathroom is so empty now...",
  "id" : 344092710396907520,
  "created_at" : "2013-06-10 14:04:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/DYWAO1rfVw",
      "expanded_url" : "http:\/\/amzn.to\/uP0bRr",
      "display_url" : "amzn.to\/uP0bRr"
    } ]
  },
  "geo" : { },
  "id_str" : "343915715910316032",
  "text" : "finished Half Way Home by Hugh Howey http:\/\/t.co\/DYWAO1rfVw",
  "id" : 343915715910316032,
  "created_at" : "2013-06-10 02:21:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343880053056208896",
  "text" : "RT @AnAmericanMonk: Listen with the ears of tolerance see through the eyes of compassion speak with the language of love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343879310442106880",
    "text" : "Listen with the ears of tolerance see through the eyes of compassion speak with the language of love.",
    "id" : 343879310442106880,
    "created_at" : "2013-06-09 23:56:31 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 343880053056208896,
  "created_at" : "2013-06-09 23:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343858542714961920",
  "text" : "why does it hurt?",
  "id" : 343858542714961920,
  "created_at" : "2013-06-09 22:33:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343856585778552832",
  "text" : "@ScottyDigit very interesting...",
  "id" : 343856585778552832,
  "created_at" : "2013-06-09 22:26:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life Facts",
      "screen_name" : "LifeFacts",
      "indices" : [ 3, 13 ],
      "id_str" : "136627335",
      "id" : 136627335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343854654855192576",
  "text" : "RT @LifeFacts: Maybe sometimes you have to lose who you were to find out who you are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343819843507740672",
    "text" : "Maybe sometimes you have to lose who you were to find out who you are.",
    "id" : 343819843507740672,
    "created_at" : "2013-06-09 20:00:13 +0000",
    "user" : {
      "name" : "Life Facts",
      "screen_name" : "LifeFacts",
      "protected" : false,
      "id_str" : "136627335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703241452499943424\/zxb4iBDf_normal.jpg",
      "id" : 136627335,
      "verified" : false
    }
  },
  "id" : 343854654855192576,
  "created_at" : "2013-06-09 22:18:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shoeofallcosmos",
      "screen_name" : "shoeofallcosmos",
      "indices" : [ 0, 16 ],
      "id_str" : "2546424236",
      "id" : 2546424236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343816242458681345",
  "geo" : { },
  "id_str" : "343816772723539968",
  "in_reply_to_user_id" : 14364749,
  "text" : "@shoeofallcosmos my dd pre-ordered it. supposed to come this week. she's driving me crazy!",
  "id" : 343816772723539968,
  "in_reply_to_status_id" : 343816242458681345,
  "created_at" : "2013-06-09 19:48:01 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Smith",
      "screen_name" : "Noahpinion",
      "indices" : [ 3, 14 ],
      "id_str" : "281877818",
      "id" : 281877818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343815722931191809",
  "text" : "RT @Noahpinion: Remember, childhood is an 18-year-long Stanford Prison Experiment, and parents are just the randomly assigned guards.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343815173523529728",
    "text" : "Remember, childhood is an 18-year-long Stanford Prison Experiment, and parents are just the randomly assigned guards.",
    "id" : 343815173523529728,
    "created_at" : "2013-06-09 19:41:39 +0000",
    "user" : {
      "name" : "Noah Smith",
      "screen_name" : "Noahpinion",
      "protected" : false,
      "id_str" : "281877818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796212808853516288\/SLiJsIhW_normal.jpg",
      "id" : 281877818,
      "verified" : false
    }
  },
  "id" : 343815722931191809,
  "created_at" : "2013-06-09 19:43:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Gaughran",
      "screen_name" : "DavidGaughran",
      "indices" : [ 3, 17 ],
      "id_str" : "287409342",
      "id" : 287409342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/6BwSHtEqXT",
      "expanded_url" : "http:\/\/bit.ly\/14MB2Dx",
      "display_url" : "bit.ly\/14MB2Dx"
    } ]
  },
  "geo" : { },
  "id_str" : "343814946859139073",
  "text" : "RT @DavidGaughran: This is so cool: Ireland\u2019s New Stamp Features a 224 Word Short Story http:\/\/t.co\/6BwSHtEqXT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/6BwSHtEqXT",
        "expanded_url" : "http:\/\/bit.ly\/14MB2Dx",
        "display_url" : "bit.ly\/14MB2Dx"
      } ]
    },
    "geo" : { },
    "id_str" : "343812074834640897",
    "text" : "This is so cool: Ireland\u2019s New Stamp Features a 224 Word Short Story http:\/\/t.co\/6BwSHtEqXT",
    "id" : 343812074834640897,
    "created_at" : "2013-06-09 19:29:21 +0000",
    "user" : {
      "name" : "David Gaughran",
      "screen_name" : "DavidGaughran",
      "protected" : false,
      "id_str" : "287409342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1324091580\/dave3_normal.jpg",
      "id" : 287409342,
      "verified" : false
    }
  },
  "id" : 343814946859139073,
  "created_at" : "2013-06-09 19:40:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/hb9ptrMj7g",
      "expanded_url" : "http:\/\/wildlifegadgetman.com\/?page_id=100",
      "display_url" : "wildlifegadgetman.com\/?page_id=100"
    } ]
  },
  "geo" : { },
  "id_str" : "343810817667522560",
  "text" : "watching this mama bird nesting cheers me up a lil bit &gt;&gt; http:\/\/t.co\/hb9ptrMj7g",
  "id" : 343810817667522560,
  "created_at" : "2013-06-09 19:24:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tux Penguin",
      "screen_name" : "thetuxpenguin",
      "indices" : [ 0, 14 ],
      "id_str" : "416762535",
      "id" : 416762535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343804276419731456",
  "geo" : { },
  "id_str" : "343807324114259968",
  "in_reply_to_user_id" : 416762535,
  "text" : "@thetuxpenguin ((smack))",
  "id" : 343807324114259968,
  "in_reply_to_status_id" : 343804276419731456,
  "created_at" : "2013-06-09 19:10:28 +0000",
  "in_reply_to_screen_name" : "thetuxpenguin",
  "in_reply_to_user_id_str" : "416762535",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343802694462496768",
  "text" : "he was a good fish and we loved him.",
  "id" : 343802694462496768,
  "created_at" : "2013-06-09 18:52:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ripdearcichlidfish",
      "indices" : [ 12, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343800706865721344",
  "text" : "he is gone. #ripdearcichlidfish &lt;3",
  "id" : 343800706865721344,
  "created_at" : "2013-06-09 18:44:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    }, {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "indices" : [ 122, 138 ],
      "id_str" : "1050419874",
      "id" : 1050419874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/BZtDcEUB9T",
      "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
      "display_url" : "facebook.com\/HighlandFarmsO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343795200939917313",
  "text" : "RT @ChickenJen: you can follow our farm adventures here https:\/\/t.co\/BZtDcEUB9T We love our Scottish Highland hairy coos! @HighlandFarmsME",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HighlandFarmsofTroy",
        "screen_name" : "HighlandFarmsME",
        "indices" : [ 106, 122 ],
        "id_str" : "1050419874",
        "id" : 1050419874
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/BZtDcEUB9T",
        "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
        "display_url" : "facebook.com\/HighlandFarmsO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343794823385448448",
    "text" : "you can follow our farm adventures here https:\/\/t.co\/BZtDcEUB9T We love our Scottish Highland hairy coos! @HighlandFarmsME",
    "id" : 343794823385448448,
    "created_at" : "2013-06-09 18:20:47 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 343795200939917313,
  "created_at" : "2013-06-09 18:22:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343790048791130113",
  "text" : "i have to say.. i follow the most interesting peeps. yay, me! : )",
  "id" : 343790048791130113,
  "created_at" : "2013-06-09 18:01:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pipi",
      "screen_name" : "pipideux",
      "indices" : [ 3, 12 ],
      "id_str" : "1044767810",
      "id" : 1044767810
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343789833522655233",
  "text" : "RT @pipideux: \u201CBirds born in a cage think flying is an illness.\u201D\n\u2014 Alejandro Jodorowsky",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343787156373909507",
    "text" : "\u201CBirds born in a cage think flying is an illness.\u201D\n\u2014 Alejandro Jodorowsky",
    "id" : 343787156373909507,
    "created_at" : "2013-06-09 17:50:19 +0000",
    "user" : {
      "name" : "Pipi",
      "screen_name" : "pipideux",
      "protected" : false,
      "id_str" : "1044767810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495564198471274496\/hJlsoodA_normal.jpeg",
      "id" : 1044767810,
      "verified" : false
    }
  },
  "id" : 343789833522655233,
  "created_at" : "2013-06-09 18:00:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343786158498656256",
  "geo" : { },
  "id_str" : "343788071856259073",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible yeah.. i dont get the \"all or nothing\" argument. its many bks written over long period. myth, stories, truth mixed. y not?",
  "id" : 343788071856259073,
  "in_reply_to_status_id" : 343786158498656256,
  "created_at" : "2013-06-09 17:53:58 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343767886189432832",
  "text" : "RT @MWM4444: Overheard on a jet: A: \"Gay marriage is unnatural.\" B: \"You're flying at 2X the speed of sound in a metal tube fueled by liqui\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343767077858971648",
    "text" : "Overheard on a jet: A: \"Gay marriage is unnatural.\" B: \"You're flying at 2X the speed of sound in a metal tube fueled by liquid dinosaurs!\"",
    "id" : 343767077858971648,
    "created_at" : "2013-06-09 16:30:32 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 343767886189432832,
  "created_at" : "2013-06-09 16:33:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343767145576022016",
  "text" : "RT @AnnotatedBible: Thought:\n\nIf the universe developed and evolved to the point where we have consciousness \/ mind. Why assume the univers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343765403572506626",
    "text" : "Thought:\n\nIf the universe developed and evolved to the point where we have consciousness \/ mind. Why assume the universe itself does not?",
    "id" : 343765403572506626,
    "created_at" : "2013-06-09 16:23:53 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 343767145576022016,
  "created_at" : "2013-06-09 16:30:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "sos",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "areyounext",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343756109741441024",
  "text" : "RT @Selaniest: I think we can honestly say the US gov is at war with us. #tcot #sos #areyounext",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 58, 63 ]
      }, {
        "text" : "sos",
        "indices" : [ 64, 68 ]
      }, {
        "text" : "areyounext",
        "indices" : [ 69, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343755575580053504",
    "text" : "I think we can honestly say the US gov is at war with us. #tcot #sos #areyounext",
    "id" : 343755575580053504,
    "created_at" : "2013-06-09 15:44:50 +0000",
    "user" : {
      "name" : "The Great Unwashed",
      "screen_name" : "UnwashedThe",
      "protected" : false,
      "id_str" : "233971651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672923186632216576\/tRMQmyrX_normal.jpg",
      "id" : 233971651,
      "verified" : false
    }
  },
  "id" : 343756109741441024,
  "created_at" : "2013-06-09 15:46:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343747929464516608",
  "text" : "RT @TheGoldenMirror: You can't make others see the truth. You can only seek it yourself and be a beacon to others, but it's up to them to n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343746643386060800",
    "text" : "You can't make others see the truth. You can only seek it yourself and be a beacon to others, but it's up to them to notice it or not.",
    "id" : 343746643386060800,
    "created_at" : "2013-06-09 15:09:20 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 343747929464516608,
  "created_at" : "2013-06-09 15:14:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343747742239170561",
  "text" : "RT @DharmaTalks: What is awakening? It lies in our realization of the divine presence in our neighbors, in our antagonists and in all of us",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343746948290977792",
    "text" : "What is awakening? It lies in our realization of the divine presence in our neighbors, in our antagonists and in all of us",
    "id" : 343746948290977792,
    "created_at" : "2013-06-09 15:10:33 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 343747742239170561,
  "created_at" : "2013-06-09 15:13:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343747602522705920",
  "text" : "well, the sun is out, so there's that...",
  "id" : 343747602522705920,
  "created_at" : "2013-06-09 15:13:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "indices" : [ 3, 13 ],
      "id_str" : "606549103",
      "id" : 606549103
    }, {
      "name" : "Rachel Amphlett",
      "screen_name" : "RachelAmphlett",
      "indices" : [ 104, 119 ],
      "id_str" : "769112568",
      "id" : 769112568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/uyqMYJaoQb",
      "expanded_url" : "http:\/\/www.e-thriller.com",
      "display_url" : "e-thriller.com"
    } ]
  },
  "geo" : { },
  "id_str" : "343744038018613248",
  "text" : "RT @ethriller: http:\/\/t.co\/uyqMYJaoQb announces its Thrillers Of The Month for June; inc. White Gold by @RachelAmphlett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachel Amphlett",
        "screen_name" : "RachelAmphlett",
        "indices" : [ 89, 104 ],
        "id_str" : "769112568",
        "id" : 769112568
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/uyqMYJaoQb",
        "expanded_url" : "http:\/\/www.e-thriller.com",
        "display_url" : "e-thriller.com"
      } ]
    },
    "geo" : { },
    "id_str" : "343651124504576001",
    "text" : "http:\/\/t.co\/uyqMYJaoQb announces its Thrillers Of The Month for June; inc. White Gold by @RachelAmphlett",
    "id" : 343651124504576001,
    "created_at" : "2013-06-09 08:49:47 +0000",
    "user" : {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "protected" : false,
      "id_str" : "606549103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2437765921\/ai9fug2o1ypcz1lpcfed_normal.png",
      "id" : 606549103,
      "verified" : false
    }
  },
  "id" : 343744038018613248,
  "created_at" : "2013-06-09 14:58:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "indices" : [ 3, 13 ],
      "id_str" : "606549103",
      "id" : 606549103
    }, {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "indices" : [ 15, 25 ],
      "id_str" : "606549103",
      "id" : 606549103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343742920324681728",
  "text" : "RT @ethriller: @ethriller now requesting books for review - email your thriller description to mike@e-thriller.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ethriller",
        "screen_name" : "ethriller",
        "indices" : [ 0, 10 ],
        "id_str" : "606549103",
        "id" : 606549103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343415215238549504",
    "in_reply_to_user_id" : 606549103,
    "text" : "@ethriller now requesting books for review - email your thriller description to mike@e-thriller.com",
    "id" : 343415215238549504,
    "created_at" : "2013-06-08 17:12:22 +0000",
    "in_reply_to_screen_name" : "ethriller",
    "in_reply_to_user_id_str" : "606549103",
    "user" : {
      "name" : "ethriller",
      "screen_name" : "ethriller",
      "protected" : false,
      "id_str" : "606549103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2437765921\/ai9fug2o1ypcz1lpcfed_normal.png",
      "id" : 606549103,
      "verified" : false
    }
  },
  "id" : 343742920324681728,
  "created_at" : "2013-06-09 14:54:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "indices" : [ 3, 15 ],
      "id_str" : "35213582",
      "id" : 35213582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343541275095609344",
  "text" : "RT @nakedpastor: No woman should have to die for witholding sex or for $150.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343539912290734080",
    "text" : "No woman should have to die for witholding sex or for $150.",
    "id" : 343539912290734080,
    "created_at" : "2013-06-09 01:27:52 +0000",
    "user" : {
      "name" : "David Hayward",
      "screen_name" : "nakedpastor",
      "protected" : false,
      "id_str" : "35213582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789292266368208901\/ozHV38ac_normal.jpg",
      "id" : 35213582,
      "verified" : false
    }
  },
  "id" : 343541275095609344,
  "created_at" : "2013-06-09 01:33:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    }, {
      "name" : "Christian_Salafia",
      "screen_name" : "csalafia",
      "indices" : [ 100, 109 ],
      "id_str" : "15808595",
      "id" : 15808595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/5nVyJmSzMx",
      "expanded_url" : "http:\/\/homebrewedtheology.com\/10-things-the-bible-doesnt-say.php",
      "display_url" : "homebrewedtheology.com\/10-things-the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343539728370515968",
  "text" : "RT @CrystalLewis: I'm thrilled to be mentioned in the #2 slot: \"10 Things The Bible Doesn't Say\" by @csalafia -- http:\/\/t.co\/5nVyJmSzMx #th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christian_Salafia",
        "screen_name" : "csalafia",
        "indices" : [ 82, 91 ],
        "id_str" : "15808595",
        "id" : 15808595
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "theology",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/5nVyJmSzMx",
        "expanded_url" : "http:\/\/homebrewedtheology.com\/10-things-the-bible-doesnt-say.php",
        "display_url" : "homebrewedtheology.com\/10-things-the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343536381236236288",
    "text" : "I'm thrilled to be mentioned in the #2 slot: \"10 Things The Bible Doesn't Say\" by @csalafia -- http:\/\/t.co\/5nVyJmSzMx #theology",
    "id" : 343536381236236288,
    "created_at" : "2013-06-09 01:13:50 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 343539728370515968,
  "created_at" : "2013-06-09 01:27:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "indices" : [ 3, 14 ],
      "id_str" : "511243584",
      "id" : 511243584
    }, {
      "name" : "WMTW TV",
      "screen_name" : "WMTWTV",
      "indices" : [ 105, 112 ],
      "id_str" : "23085284",
      "id" : 23085284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/mw1KlLE7tW",
      "expanded_url" : "http:\/\/www.wmtw.com\/news\/maine\/-moose-calf-rescued-by-warden-service\/-\/8792012\/20483408\/-\/dbdjlcz\/-\/index.html",
      "display_url" : "wmtw.com\/news\/maine\/-mo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343525693528875010",
  "text" : "RT @becwaddell: Moose calf rescued by Warden Service | Local News - WMTW Home http:\/\/t.co\/mw1KlLE7tW via @WMTWTV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WMTW TV",
        "screen_name" : "WMTWTV",
        "indices" : [ 89, 96 ],
        "id_str" : "23085284",
        "id" : 23085284
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/mw1KlLE7tW",
        "expanded_url" : "http:\/\/www.wmtw.com\/news\/maine\/-moose-calf-rescued-by-warden-service\/-\/8792012\/20483408\/-\/dbdjlcz\/-\/index.html",
        "display_url" : "wmtw.com\/news\/maine\/-mo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343525180347383809",
    "text" : "Moose calf rescued by Warden Service | Local News - WMTW Home http:\/\/t.co\/mw1KlLE7tW via @WMTWTV",
    "id" : 343525180347383809,
    "created_at" : "2013-06-09 00:29:20 +0000",
    "user" : {
      "name" : "Bec",
      "screen_name" : "becwaddell",
      "protected" : false,
      "id_str" : "511243584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604077917094596608\/YsEVFvZs_normal.jpg",
      "id" : 511243584,
      "verified" : false
    }
  },
  "id" : 343525693528875010,
  "created_at" : "2013-06-09 00:31:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343516802954964996",
  "text" : "RT @TheChristianLft: This. This! THIS!\n\nPut this in front of everybody you can. So simple. So true.\nAND a really great read. http:\/\/t.co\/KY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/KYcv4miFGS",
        "expanded_url" : "http:\/\/fb.me\/2Qv99yZUE",
        "display_url" : "fb.me\/2Qv99yZUE"
      } ]
    },
    "geo" : { },
    "id_str" : "343516274074206208",
    "text" : "This. This! THIS!\n\nPut this in front of everybody you can. So simple. So true.\nAND a really great read. http:\/\/t.co\/KYcv4miFGS",
    "id" : 343516274074206208,
    "created_at" : "2013-06-08 23:53:56 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 343516802954964996,
  "created_at" : "2013-06-08 23:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 59, 74 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 75, 89 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "Stuart Paynter",
      "screen_name" : "hitchismygod",
      "indices" : [ 90, 103 ],
      "id_str" : "617511920",
      "id" : 617511920
    }, {
      "name" : "Seth Callahan",
      "screen_name" : "S8th",
      "indices" : [ 104, 109 ],
      "id_str" : "191835548",
      "id" : 191835548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343511641918427136",
  "geo" : { },
  "id_str" : "343514019388350465",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis ahh.. yes, thats my view spirits w bodies @AnnotatedBible @hungryatheist @hitchismygod @S8th",
  "id" : 343514019388350465,
  "in_reply_to_status_id" : 343511641918427136,
  "created_at" : "2013-06-08 23:44:59 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 29, 44 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 45, 59 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "Stuart Paynter",
      "screen_name" : "hitchismygod",
      "indices" : [ 60, 73 ],
      "id_str" : "617511920",
      "id" : 617511920
    }, {
      "name" : "Seth Callahan",
      "screen_name" : "S8th",
      "indices" : [ 74, 79 ],
      "id_str" : "191835548",
      "id" : 191835548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343511557126361088",
  "geo" : { },
  "id_str" : "343513349071437825",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis ok, got it. @AnnotatedBible @hungryatheist @hitchismygod @S8th",
  "id" : 343513349071437825,
  "in_reply_to_status_id" : 343511557126361088,
  "created_at" : "2013-06-08 23:42:19 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343507886267326464",
  "geo" : { },
  "id_str" : "343510815569219584",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses oh dear...",
  "id" : 343510815569219584,
  "in_reply_to_status_id" : 343507886267326464,
  "created_at" : "2013-06-08 23:32:15 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 0, 16 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 53, 68 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 69, 83 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "Stuart Paynter",
      "screen_name" : "hitchismygod",
      "indices" : [ 84, 97 ],
      "id_str" : "617511920",
      "id" : 617511920
    }, {
      "name" : "Seth Callahan",
      "screen_name" : "S8th",
      "indices" : [ 98, 103 ],
      "id_str" : "191835548",
      "id" : 191835548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343483658885287936",
  "geo" : { },
  "id_str" : "343494927113670656",
  "in_reply_to_user_id" : 1067008352,
  "text" : "@CounterApologis really? not sure i understand that. @AnnotatedBible @hungryatheist @hitchismygod @S8th",
  "id" : 343494927113670656,
  "in_reply_to_status_id" : 343483658885287936,
  "created_at" : "2013-06-08 22:29:07 +0000",
  "in_reply_to_screen_name" : "CounterApologis",
  "in_reply_to_user_id_str" : "1067008352",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343492229819686912",
  "geo" : { },
  "id_str" : "343492614647066624",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist hmmm...",
  "id" : 343492614647066624,
  "in_reply_to_status_id" : 343492229819686912,
  "created_at" : "2013-06-08 22:19:55 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343489960625713152",
  "geo" : { },
  "id_str" : "343491996708651008",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist just because it cannot move or speak does not mean a rock has no intellect :P",
  "id" : 343491996708651008,
  "in_reply_to_status_id" : 343489960625713152,
  "created_at" : "2013-06-08 22:17:28 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/vdWHIQWJyI",
      "expanded_url" : "http:\/\/www.thesovereignseries.com\/",
      "display_url" : "thesovereignseries.com"
    } ]
  },
  "geo" : { },
  "id_str" : "343489231781498881",
  "text" : "RT @ChickenJen: Spoiler Alert: I like to make people happy, so all my books have happy endings. http:\/\/t.co\/vdWHIQWJyI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/vdWHIQWJyI",
        "expanded_url" : "http:\/\/www.thesovereignseries.com\/",
        "display_url" : "thesovereignseries.com"
      } ]
    },
    "geo" : { },
    "id_str" : "343488902163734528",
    "text" : "Spoiler Alert: I like to make people happy, so all my books have happy endings. http:\/\/t.co\/vdWHIQWJyI",
    "id" : 343488902163734528,
    "created_at" : "2013-06-08 22:05:10 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 343489231781498881,
  "created_at" : "2013-06-08 22:06:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343485350418726912",
  "geo" : { },
  "id_str" : "343489088034316288",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist there, there.. don't cry. it's ok.",
  "id" : 343489088034316288,
  "in_reply_to_status_id" : 343485350418726912,
  "created_at" : "2013-06-08 22:05:54 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343485301496356864",
  "text" : "RT @BrianRathbone: Found: Dragon. Answers to   Run! Run for your life  . Not very good with children or cats or dogs or horses...Free to a \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343485174970998784",
    "text" : "Found: Dragon. Answers to   Run! Run for your life  . Not very good with children or cats or dogs or horses...Free to a good home.",
    "id" : 343485174970998784,
    "created_at" : "2013-06-08 21:50:22 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 343485301496356864,
  "created_at" : "2013-06-08 21:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343483711200829440",
  "geo" : { },
  "id_str" : "343485138954485760",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist LOL",
  "id" : 343485138954485760,
  "in_reply_to_status_id" : 343483711200829440,
  "created_at" : "2013-06-08 21:50:13 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343484901913399297",
  "text" : "RT @HoodedMan: \u00ABLife is like going to the dentist. You're doomed if you go, doomed if you don't\u00BB - Carolyn Cassady",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343484657901400065",
    "text" : "\u00ABLife is like going to the dentist. You're doomed if you go, doomed if you don't\u00BB - Carolyn Cassady",
    "id" : 343484657901400065,
    "created_at" : "2013-06-08 21:48:18 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 343484901913399297,
  "created_at" : "2013-06-08 21:49:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343472134733062144",
  "geo" : { },
  "id_str" : "343472612007104512",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny how can a human being be \"illegal\"? geesh...",
  "id" : 343472612007104512,
  "in_reply_to_status_id" : 343472134733062144,
  "created_at" : "2013-06-08 21:00:26 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343470238202990593",
  "geo" : { },
  "id_str" : "343472164139307008",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist ignoring the world has worked for me so far ; )",
  "id" : 343472164139307008,
  "in_reply_to_status_id" : 343470238202990593,
  "created_at" : "2013-06-08 20:58:39 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343462878667481088",
  "geo" : { },
  "id_str" : "343463415643242497",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem LOLOL.. love it!",
  "id" : 343463415643242497,
  "in_reply_to_status_id" : 343462878667481088,
  "created_at" : "2013-06-08 20:23:54 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343458110855315456",
  "geo" : { },
  "id_str" : "343461581012738049",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen lovely!",
  "id" : 343461581012738049,
  "in_reply_to_status_id" : 343458110855315456,
  "created_at" : "2013-06-08 20:16:36 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neville A. Daniels",
      "screen_name" : "nevilleadaniels",
      "indices" : [ 78, 94 ],
      "id_str" : "23446496",
      "id" : 23446496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343442385352663040",
  "text" : "@fraudummkopf throw a penny.. either God or Nothing. either way, same dilemma @nevilleadaniels",
  "id" : 343442385352663040,
  "created_at" : "2013-06-08 19:00:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/WZlbcyLOsS",
      "expanded_url" : "http:\/\/www.16personalities.com\/infp-personality",
      "display_url" : "16personalities.com\/infp-personali\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343433439778852865",
  "text" : "#INFP personality http:\/\/t.co\/WZlbcyLOsS - tend to see things and actions from the idealistic perspective, rather than the prism of logic",
  "id" : 343433439778852865,
  "created_at" : "2013-06-08 18:24:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Journey",
      "screen_name" : "JourneyTheHedgi",
      "indices" : [ 4, 20 ],
      "id_str" : "1137858745",
      "id" : 1137858745
    }, {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 33, 43 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "animalcrossing",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343419713184993282",
  "geo" : { },
  "id_str" : "343423877835259904",
  "in_reply_to_user_id" : 16639123,
  "text" : "hey @JourneyTheHedgi &gt;&gt; RT @CubeMelon add my friend code 4167 5040 8010 #animalcrossing",
  "id" : 343423877835259904,
  "in_reply_to_status_id" : 343419713184993282,
  "created_at" : "2013-06-08 17:46:47 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 45, 60 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 61, 77 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    }, {
      "name" : "Stuart Paynter",
      "screen_name" : "hitchismygod",
      "indices" : [ 78, 91 ],
      "id_str" : "617511920",
      "id" : 617511920
    }, {
      "name" : "Seth Callahan",
      "screen_name" : "S8th",
      "indices" : [ 92, 97 ],
      "id_str" : "191835548",
      "id" : 191835548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343414139940642816",
  "geo" : { },
  "id_str" : "343415320297492480",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist what if we are in the matrix? @AnnotatedBible @CounterApologis @hitchismygod @S8th",
  "id" : 343415320297492480,
  "in_reply_to_status_id" : 343414139940642816,
  "created_at" : "2013-06-08 17:12:47 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oshum",
      "indices" : [ 74, 80 ]
    }, {
      "text" : "ramblings",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343414706310090752",
  "text" : "RT @oshum: Wake up and smell the ... No, not the coffee ... the illusion. #oshum #ramblings",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oshum",
        "indices" : [ 63, 69 ]
      }, {
        "text" : "ramblings",
        "indices" : [ 70, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343411320080719872",
    "text" : "Wake up and smell the ... No, not the coffee ... the illusion. #oshum #ramblings",
    "id" : 343411320080719872,
    "created_at" : "2013-06-08 16:56:53 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 343414706310090752,
  "created_at" : "2013-06-08 17:10:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oshum",
      "indices" : [ 113, 119 ]
    }, {
      "text" : "fundamentaltruth",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343408396936032256",
  "text" : "RT @oshum: The Body is ..... Spirit with clothes on ..... a living Soul. We don't have a Soul .... we ARE Souls. #oshum #fundamentaltruth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oshum",
        "indices" : [ 102, 108 ]
      }, {
        "text" : "fundamentaltruth",
        "indices" : [ 109, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343406817990303744",
    "text" : "The Body is ..... Spirit with clothes on ..... a living Soul. We don't have a Soul .... we ARE Souls. #oshum #fundamentaltruth",
    "id" : 343406817990303744,
    "created_at" : "2013-06-08 16:39:00 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 343408396936032256,
  "created_at" : "2013-06-08 16:45:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343400100636262400",
  "text" : "RT @MWM4444: What you feed, grows. What you ignore, withers from neglect. Talk about your blessings more than your problems.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343399244855668736",
    "text" : "What you feed, grows. What you ignore, withers from neglect. Talk about your blessings more than your problems.",
    "id" : 343399244855668736,
    "created_at" : "2013-06-08 16:08:54 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 343400100636262400,
  "created_at" : "2013-06-08 16:12:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343398275052888064",
  "text" : "ohh.. idea! perhaps those seeking house\/senate offices should be req'd to do community service first!",
  "id" : 343398275052888064,
  "created_at" : "2013-06-08 16:05:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343397507184881664",
  "text" : "don't put me in a box. i don't like it when you put me in a box. it makes me cranky. : )",
  "id" : 343397507184881664,
  "created_at" : "2013-06-08 16:02:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 0, 12 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 76, 91 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343396975686864897",
  "text" : "@embreeology all of life is perception and perspective processed via brain  @AnnotatedBible",
  "id" : 343396975686864897,
  "created_at" : "2013-06-08 15:59:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 16, 28 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343382513412083712",
  "geo" : { },
  "id_str" : "343390715398729728",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible @embreeology if there is no intentionality, shouldnt each thought bring a specific response?",
  "id" : 343390715398729728,
  "in_reply_to_status_id" : 343382513412083712,
  "created_at" : "2013-06-08 15:35:01 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 0, 12 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 61, 76 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343387971510226944",
  "text" : "@embreeology this convo is good.. not sure why I zinged..lol @AnnotatedBible",
  "id" : 343387971510226944,
  "created_at" : "2013-06-08 15:24:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343384531052670976",
  "geo" : { },
  "id_str" : "343386888096317440",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields im sensitive to smells anyway.. anytime dh cleans, im gagging, opening doors..lol",
  "id" : 343386888096317440,
  "in_reply_to_status_id" : 343384531052670976,
  "created_at" : "2013-06-08 15:19:48 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343386379289497602",
  "text" : "@Skeptical_Lady YES!!",
  "id" : 343386379289497602,
  "created_at" : "2013-06-08 15:17:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/UHIx6RucXV",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/94K",
      "display_url" : "omgf.ac\/ts\/94K"
    } ]
  },
  "geo" : { },
  "id_str" : "343384222049902593",
  "text" : "RT @OMGFacts: There's a man whose brain sees numbers with shapes, colors and feels! More info ---&gt; http:\/\/t.co\/UHIx6RucXV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/UHIx6RucXV",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/94K",
        "display_url" : "omgf.ac\/ts\/94K"
      } ]
    },
    "geo" : { },
    "id_str" : "343382674607591425",
    "text" : "There's a man whose brain sees numbers with shapes, colors and feels! More info ---&gt; http:\/\/t.co\/UHIx6RucXV",
    "id" : 343382674607591425,
    "created_at" : "2013-06-08 15:03:04 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 343384222049902593,
  "created_at" : "2013-06-08 15:09:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "embreeology",
      "screen_name" : "embreeology",
      "indices" : [ 26, 38 ],
      "id_str" : "2186936772",
      "id" : 2186936772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343382816194703361",
  "geo" : { },
  "id_str" : "343384005628018688",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible zing! lol @embreeology",
  "id" : 343384005628018688,
  "in_reply_to_status_id" : 343382816194703361,
  "created_at" : "2013-06-08 15:08:21 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343383481465860096",
  "text" : "dh has incense burning.. im choking to death. dh says id make a bad hippie.",
  "id" : 343383481465860096,
  "created_at" : "2013-06-08 15:06:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ewrWqJnL1l",
      "expanded_url" : "http:\/\/amzn.to\/11bxGaU",
      "display_url" : "amzn.to\/11bxGaU"
    } ]
  },
  "geo" : { },
  "id_str" : "343197094896615424",
  "text" : "finished The Body Departed by J.R. Rain http:\/\/t.co\/ewrWqJnL1l",
  "id" : 343197094896615424,
  "created_at" : "2013-06-08 02:45:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gardasil",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "MichaelDouglas",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/AZ5EWGQzfG",
      "expanded_url" : "http:\/\/tl.gd\/m0e3l1",
      "display_url" : "tl.gd\/m0e3l1"
    } ]
  },
  "geo" : { },
  "id_str" : "343172389762375680",
  "text" : "RT @drbloem: News of #Gardasil vaccine killing 26 ppl came out in April. Props to Merck, this #MichaelDouglas (cont) http:\/\/t.co\/AZ5EWGQzfG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getfalcon.pro\" rel=\"nofollow\"\u003EFalcon-Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gardasil",
        "indices" : [ 8, 17 ]
      }, {
        "text" : "MichaelDouglas",
        "indices" : [ 81, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/AZ5EWGQzfG",
        "expanded_url" : "http:\/\/tl.gd\/m0e3l1",
        "display_url" : "tl.gd\/m0e3l1"
      } ]
    },
    "geo" : { },
    "id_str" : "343169630413680640",
    "text" : "News of #Gardasil vaccine killing 26 ppl came out in April. Props to Merck, this #MichaelDouglas (cont) http:\/\/t.co\/AZ5EWGQzfG",
    "id" : 343169630413680640,
    "created_at" : "2013-06-08 00:56:30 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 343172389762375680,
  "created_at" : "2013-06-08 01:07:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343149114952912896",
  "geo" : { },
  "id_str" : "343149858540105729",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist all that's unseen is potential or possibility. btw, what are Hungry Points? Can i buy cookies w them?",
  "id" : 343149858540105729,
  "in_reply_to_status_id" : 343149114952912896,
  "created_at" : "2013-06-07 23:37:56 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "indices" : [ 3, 18 ],
      "id_str" : "123647589",
      "id" : 123647589
    }, {
      "name" : "Jim Nichols",
      "screen_name" : "BiboJim",
      "indices" : [ 65, 73 ],
      "id_str" : "14380009",
      "id" : 14380009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343148356576608256",
  "text" : "RT @petersonguides: Jim to the rescue :) That's a tiny Turkey MT @BiboJim rescued a baby Turkey today, couldn't get back over the tracks ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Nichols",
        "screen_name" : "BiboJim",
        "indices" : [ 45, 53 ],
        "id_str" : "14380009",
        "id" : 14380009
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/i0CKhZAuOX",
        "expanded_url" : "https:\/\/www.facebook.com\/photo.php?fbid=4922341703409&l=6e6814e80e",
        "display_url" : "facebook.com\/photo.php?fbid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343147950584786944",
    "text" : "Jim to the rescue :) That's a tiny Turkey MT @BiboJim rescued a baby Turkey today, couldn't get back over the tracks https:\/\/t.co\/i0CKhZAuOX",
    "id" : 343147950584786944,
    "created_at" : "2013-06-07 23:30:21 +0000",
    "user" : {
      "name" : "Peterson Guides",
      "screen_name" : "petersonguides",
      "protected" : false,
      "id_str" : "123647589",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601489764974465026\/7y6OBC9I_normal.png",
      "id" : 123647589,
      "verified" : false
    }
  },
  "id" : 343148356576608256,
  "created_at" : "2013-06-07 23:31:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343137945676566528",
  "geo" : { },
  "id_str" : "343140322005630976",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen awwww...lol",
  "id" : 343140322005630976,
  "in_reply_to_status_id" : 343137945676566528,
  "created_at" : "2013-06-07 23:00:02 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343125559213178881",
  "text" : "We are all just figments of God's imagination.",
  "id" : 343125559213178881,
  "created_at" : "2013-06-07 22:01:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    }, {
      "name" : "Fox News Health",
      "screen_name" : "foxnewshealth",
      "indices" : [ 95, 109 ],
      "id_str" : "262326533",
      "id" : 262326533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/bFqbqZQX8t",
      "expanded_url" : "http:\/\/fxn.ws\/13hksw9",
      "display_url" : "fxn.ws\/13hksw9"
    } ]
  },
  "geo" : { },
  "id_str" : "343123387272531968",
  "text" : "RT @Squirrely007: Soy sauce overdose sends man into coma | Fox News http:\/\/t.co\/bFqbqZQX8t via @foxnewshealth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fox News Health",
        "screen_name" : "foxnewshealth",
        "indices" : [ 77, 91 ],
        "id_str" : "262326533",
        "id" : 262326533
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/bFqbqZQX8t",
        "expanded_url" : "http:\/\/fxn.ws\/13hksw9",
        "display_url" : "fxn.ws\/13hksw9"
      } ]
    },
    "geo" : { },
    "id_str" : "343119242952048641",
    "text" : "Soy sauce overdose sends man into coma | Fox News http:\/\/t.co\/bFqbqZQX8t via @foxnewshealth",
    "id" : 343119242952048641,
    "created_at" : "2013-06-07 21:36:17 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 343123387272531968,
  "created_at" : "2013-06-07 21:52:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "JP Stevens",
      "screen_name" : "jp4reason",
      "indices" : [ 56, 66 ],
      "id_str" : "253629620",
      "id" : 253629620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343121486745329665",
  "geo" : { },
  "id_str" : "343122102666280960",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind flaw? nah.. it's what makes life interesting @jp4reason",
  "id" : 343122102666280960,
  "in_reply_to_status_id" : 343121486745329665,
  "created_at" : "2013-06-07 21:47:38 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 37, 51 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/RPBR809Y1h",
      "expanded_url" : "http:\/\/huff.to\/1bdKEKY",
      "display_url" : "huff.to\/1bdKEKY"
    } ]
  },
  "in_reply_to_status_id_str" : "343117960015142912",
  "geo" : { },
  "id_str" : "343120754214313985",
  "in_reply_to_user_id" : 125567504,
  "text" : "has to be erotic? plain won't do? RT @HuffPostWeird Erotic breast massages may prevent cancer http:\/\/t.co\/RPBR809Y1h",
  "id" : 343120754214313985,
  "in_reply_to_status_id" : 343117960015142912,
  "created_at" : "2013-06-07 21:42:17 +0000",
  "in_reply_to_screen_name" : "HuffPostWeird",
  "in_reply_to_user_id_str" : "125567504",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Nancy Castillo",
      "screen_name" : "ZenBirdfeeder",
      "indices" : [ 23, 37 ],
      "id_str" : "26091734",
      "id" : 26091734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343114132884701185",
  "text" : "RT @KerriFar: LOVE! RT @zenbirdfeeder: Close Bird Encounters Week: I Just Want Some Privacy, Please!: \"I love my bathtime\u2026 http:\/\/t.co\/O1ST\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nancy Castillo",
        "screen_name" : "ZenBirdfeeder",
        "indices" : [ 9, 23 ],
        "id_str" : "26091734",
        "id" : 26091734
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/O1STm4zvhs",
        "expanded_url" : "http:\/\/goo.gl\/fb\/mplFb",
        "display_url" : "goo.gl\/fb\/mplFb"
      } ]
    },
    "geo" : { },
    "id_str" : "343112823989223424",
    "text" : "LOVE! RT @zenbirdfeeder: Close Bird Encounters Week: I Just Want Some Privacy, Please!: \"I love my bathtime\u2026 http:\/\/t.co\/O1STm4zvhs #birds",
    "id" : 343112823989223424,
    "created_at" : "2013-06-07 21:10:46 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 343114132884701185,
  "created_at" : "2013-06-07 21:15:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343102737224970242",
  "geo" : { },
  "id_str" : "343103748199047169",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny Guilty!!",
  "id" : 343103748199047169,
  "in_reply_to_status_id" : 343102737224970242,
  "created_at" : "2013-06-07 20:34:42 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343100627255193601",
  "text" : "@1stCitizenKane just by having laws, we are not free...",
  "id" : 343100627255193601,
  "created_at" : "2013-06-07 20:22:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343090693415260160",
  "geo" : { },
  "id_str" : "343092343764832256",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i do agree w 1st sentence...",
  "id" : 343092343764832256,
  "in_reply_to_status_id" : 343090693415260160,
  "created_at" : "2013-06-07 19:49:23 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343090626511912960",
  "geo" : { },
  "id_str" : "343092170049331202",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny bellydancing and yoga are also devils work ((jinglejingle)) ((ohm))",
  "id" : 343092170049331202,
  "in_reply_to_status_id" : 343090626511912960,
  "created_at" : "2013-06-07 19:48:42 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 9, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343089989778829313",
  "text" : "i have a #kindlefire but find it difficult to get non-audible books on it.. plus the organization is crappy.",
  "id" : 343089989778829313,
  "created_at" : "2013-06-07 19:40:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 0, 7 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "kindle",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343089417390530560",
  "in_reply_to_user_id" : 20793816,
  "text" : "@amazon should make an #audiobook only gadget.. like a #kindle but audio.",
  "id" : 343089417390530560,
  "created_at" : "2013-06-07 19:37:46 +0000",
  "in_reply_to_screen_name" : "amazon",
  "in_reply_to_user_id_str" : "20793816",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "RT",
      "screen_name" : "RT_com",
      "indices" : [ 16, 23 ],
      "id_str" : "64643056",
      "id" : 64643056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343086879765311488",
  "text" : "RT @Jamiastar: \/@RT_com No matter what you do, it is impossible to have 100% security if you are alive on this planet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RT",
        "screen_name" : "RT_com",
        "indices" : [ 1, 8 ],
        "id_str" : "64643056",
        "id" : 64643056
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "343067057887256576",
    "geo" : { },
    "id_str" : "343083121836687360",
    "in_reply_to_user_id" : 64643056,
    "text" : "\/@RT_com No matter what you do, it is impossible to have 100% security if you are alive on this planet.",
    "id" : 343083121836687360,
    "in_reply_to_status_id" : 343067057887256576,
    "created_at" : "2013-06-07 19:12:45 +0000",
    "in_reply_to_screen_name" : "RT_com",
    "in_reply_to_user_id_str" : "64643056",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 343086879765311488,
  "created_at" : "2013-06-07 19:27:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343079566190968832",
  "text" : "i have a compulsion to save bugs.. you know, free them.",
  "id" : 343079566190968832,
  "created_at" : "2013-06-07 18:58:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343076461948841984",
  "text" : "this is the year USA falls apart. i gots my popcorn ready!",
  "id" : 343076461948841984,
  "created_at" : "2013-06-07 18:46:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Hope",
      "screen_name" : "Brianhopecomedy",
      "indices" : [ 3, 19 ],
      "id_str" : "25673455",
      "id" : 25673455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343074035913068544",
  "text" : "RT @Brianhopecomedy: My wife asked me to make up a salad for when she gets home so I did but I think I put too much mascara on the croutons.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343072431189143552",
    "text" : "My wife asked me to make up a salad for when she gets home so I did but I think I put too much mascara on the croutons.",
    "id" : 343072431189143552,
    "created_at" : "2013-06-07 18:30:16 +0000",
    "user" : {
      "name" : "Brian Hope",
      "screen_name" : "Brianhopecomedy",
      "protected" : false,
      "id_str" : "25673455",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556078220584701952\/Zsdzm0ba_normal.jpeg",
      "id" : 25673455,
      "verified" : false
    }
  },
  "id" : 343074035913068544,
  "created_at" : "2013-06-07 18:36:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/gFM1c71UuR",
      "expanded_url" : "http:\/\/wapo.st\/114wG9Q",
      "display_url" : "wapo.st\/114wG9Q"
    } ]
  },
  "geo" : { },
  "id_str" : "343063213094617089",
  "text" : "RT @ezraklein: Obamacare leaves millions uninsured. Here\u2019s who they are. http:\/\/t.co\/gFM1c71UuR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/gFM1c71UuR",
        "expanded_url" : "http:\/\/wapo.st\/114wG9Q",
        "display_url" : "wapo.st\/114wG9Q"
      } ]
    },
    "geo" : { },
    "id_str" : "343062086248697857",
    "text" : "Obamacare leaves millions uninsured. Here\u2019s who they are. http:\/\/t.co\/gFM1c71UuR",
    "id" : 343062086248697857,
    "created_at" : "2013-06-07 17:49:09 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 343063213094617089,
  "created_at" : "2013-06-07 17:53:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Fulton",
      "screen_name" : "dbfulton",
      "indices" : [ 3, 12 ],
      "id_str" : "15755105",
      "id" : 15755105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343046828780044288",
  "text" : "RT @dbfulton: Mississippi aims to curb teen pregnancy with umbilical blood law - apparently hasn't heard of contraception. http:\/\/t.co\/8zFt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/8zFtr0DXJk",
        "expanded_url" : "http:\/\/www.reuters.com\/article\/2013\/06\/07\/us-usa-mississippi-babies-idUSBRE9560SL20130607",
        "display_url" : "reuters.com\/article\/2013\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343037621028675584",
    "text" : "Mississippi aims to curb teen pregnancy with umbilical blood law - apparently hasn't heard of contraception. http:\/\/t.co\/8zFtr0DXJk",
    "id" : 343037621028675584,
    "created_at" : "2013-06-07 16:11:56 +0000",
    "user" : {
      "name" : "Bruce Fulton",
      "screen_name" : "dbfulton",
      "protected" : false,
      "id_str" : "15755105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000665576832\/fdd4926d5ec4097a04db0f10be1d84de_normal.jpeg",
      "id" : 15755105,
      "verified" : false
    }
  },
  "id" : 343046828780044288,
  "created_at" : "2013-06-07 16:48:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Say Now",
      "screen_name" : "JustSayNow",
      "indices" : [ 3, 14 ],
      "id_str" : "166285648",
      "id" : 166285648
    }, {
      "name" : "Just Say Now",
      "screen_name" : "JustSayNow",
      "indices" : [ 102, 113 ],
      "id_str" : "166285648",
      "id" : 166285648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/6hNhcSFSgJ",
      "expanded_url" : "http:\/\/bit.ly\/14FDQlJ",
      "display_url" : "bit.ly\/14FDQlJ"
    } ]
  },
  "geo" : { },
  "id_str" : "343040357686198272",
  "text" : "RT @JustSayNow: Poll: New Yorkers Overwhelmingly Support Medical Marijuana http:\/\/t.co\/6hNhcSFSgJ via @JustSayNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Just Say Now",
        "screen_name" : "JustSayNow",
        "indices" : [ 86, 97 ],
        "id_str" : "166285648",
        "id" : 166285648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/6hNhcSFSgJ",
        "expanded_url" : "http:\/\/bit.ly\/14FDQlJ",
        "display_url" : "bit.ly\/14FDQlJ"
      } ]
    },
    "geo" : { },
    "id_str" : "343032374319280128",
    "text" : "Poll: New Yorkers Overwhelmingly Support Medical Marijuana http:\/\/t.co\/6hNhcSFSgJ via @JustSayNow",
    "id" : 343032374319280128,
    "created_at" : "2013-06-07 15:51:05 +0000",
    "user" : {
      "name" : "Just Say Now",
      "screen_name" : "JustSayNow",
      "protected" : false,
      "id_str" : "166285648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484419053482541056\/J79_yvhi_normal.png",
      "id" : 166285648,
      "verified" : false
    }
  },
  "id" : 343040357686198272,
  "created_at" : "2013-06-07 16:22:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343039338772316163",
  "text" : "RT @wow_trees: God took acid once and he thought he was Me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343037675512684544",
    "text" : "God took acid once and he thought he was Me.",
    "id" : 343037675512684544,
    "created_at" : "2013-06-07 16:12:09 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 343039338772316163,
  "created_at" : "2013-06-07 16:18:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343031731068223489",
  "text" : "RT @JeremyCShipp: That awkward moment when you\u2019re talking gibberish to a baby and you accidentally speak the words of darkness and summon a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343030922347700224",
    "text" : "That awkward moment when you\u2019re talking gibberish to a baby and you accidentally speak the words of darkness and summon a demon.",
    "id" : 343030922347700224,
    "created_at" : "2013-06-07 15:45:19 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 343031731068223489,
  "created_at" : "2013-06-07 15:48:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guile Of The gods\u2122",
      "screen_name" : "GuileOfTheGods",
      "indices" : [ 3, 18 ],
      "id_str" : "614688032",
      "id" : 614688032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zimmerman",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343027670621224962",
  "text" : "RT @GuileOfTheGods: Audio expert claims #Zimmerman is NOT the one screaming for help in 911 call. Wait, you mean the racist child murderer \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zimmerman",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343019677942964225",
    "text" : "Audio expert claims #Zimmerman is NOT the one screaming for help in 911 call. Wait, you mean the racist child murderer is also a liar???",
    "id" : 343019677942964225,
    "created_at" : "2013-06-07 15:00:38 +0000",
    "user" : {
      "name" : "Guile Of The gods\u2122",
      "screen_name" : "GuileOfTheGods",
      "protected" : false,
      "id_str" : "614688032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781456164760522753\/xFME2awE_normal.jpg",
      "id" : 614688032,
      "verified" : false
    }
  },
  "id" : 343027670621224962,
  "created_at" : "2013-06-07 15:32:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 0, 12 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 13, 25 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342959123706548224",
  "geo" : { },
  "id_str" : "343027399753089026",
  "in_reply_to_user_id" : 229428507,
  "text" : "@Floridaline @VirgoJohnny he is a lunatic twat",
  "id" : 343027399753089026,
  "in_reply_to_status_id" : 342959123706548224,
  "created_at" : "2013-06-07 15:31:19 +0000",
  "in_reply_to_screen_name" : "Floridaline",
  "in_reply_to_user_id_str" : "229428507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343027132500418561",
  "text" : "RT @micahjmurray: You can have your religion that refuses cake to \u201Csinners\u201D. I want the one that hangs out with them, loves them, breaks br\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343026255786016770",
    "text" : "You can have your religion that refuses cake to \u201Csinners\u201D. I want the one that hangs out with them, loves them, breaks bread with them.",
    "id" : 343026255786016770,
    "created_at" : "2013-06-07 15:26:47 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 343027132500418561,
  "created_at" : "2013-06-07 15:30:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "indices" : [ 3, 15 ],
      "id_str" : "106841792",
      "id" : 106841792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343026815071289347",
  "text" : "RT @TheDailyHug: When you smile to just one person, you change everything for the better. \nImagine if you smiled all day...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343025656638087168",
    "text" : "When you smile to just one person, you change everything for the better. \nImagine if you smiled all day...",
    "id" : 343025656638087168,
    "created_at" : "2013-06-07 15:24:24 +0000",
    "user" : {
      "name" : "The Daily Hug",
      "screen_name" : "TheDailyHug",
      "protected" : false,
      "id_str" : "106841792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/644519554\/roundOwlLARGE_normal.png",
      "id" : 106841792,
      "verified" : false
    }
  },
  "id" : 343026815071289347,
  "created_at" : "2013-06-07 15:29:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343025972674719744",
  "text" : "@BibleAlsoSays he doesnt care if you believe. has no effect one way or other. OTOH, there are ppl who think it matters.",
  "id" : 343025972674719744,
  "created_at" : "2013-06-07 15:25:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlterNet",
      "screen_name" : "AlterNet",
      "indices" : [ 3, 12 ],
      "id_str" : "18851248",
      "id" : 18851248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/tSUoJ9KB6M",
      "expanded_url" : "http:\/\/www.alternet.org\/philly-closes-23-public-schools-generously-builds-400-million-prison-where-kids-can-hang-instead",
      "display_url" : "alternet.org\/philly-closes-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343025280505491456",
  "text" : "RT @AlterNet: Philly Closes 23 Public Schools, Generously Builds $400 Million Prison Where Kids Can Hang Instead http:\/\/t.co\/tSUoJ9KB6M by \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kristen Gwynne",
        "screen_name" : "kristengwynne",
        "indices" : [ 125, 139 ],
        "id_str" : "334326837",
        "id" : 334326837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/tSUoJ9KB6M",
        "expanded_url" : "http:\/\/www.alternet.org\/philly-closes-23-public-schools-generously-builds-400-million-prison-where-kids-can-hang-instead",
        "display_url" : "alternet.org\/philly-closes-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343022229304524800",
    "text" : "Philly Closes 23 Public Schools, Generously Builds $400 Million Prison Where Kids Can Hang Instead http:\/\/t.co\/tSUoJ9KB6M by @kristengwynne",
    "id" : 343022229304524800,
    "created_at" : "2013-06-07 15:10:47 +0000",
    "user" : {
      "name" : "AlterNet",
      "screen_name" : "AlterNet",
      "protected" : false,
      "id_str" : "18851248",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552238151398195201\/GyFRvFHw_normal.png",
      "id" : 18851248,
      "verified" : true
    }
  },
  "id" : 343025280505491456,
  "created_at" : "2013-06-07 15:22:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CN James",
      "screen_name" : "CNJamesWriter",
      "indices" : [ 3, 17 ],
      "id_str" : "273710178",
      "id" : 273710178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Ys0PhOtTkC",
      "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2013\/06\/130606140844.htm#.UbH4sasUqrg.twitter",
      "display_url" : "sciencedaily.com\/releases\/2013\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343024430412341248",
  "text" : "RT @CNJamesWriter: Quantum teleportation between atomic systems over long distances: http:\/\/t.co\/Ys0PhOtTkC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/Ys0PhOtTkC",
        "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2013\/06\/130606140844.htm#.UbH4sasUqrg.twitter",
        "display_url" : "sciencedaily.com\/releases\/2013\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343023101468102657",
    "text" : "Quantum teleportation between atomic systems over long distances: http:\/\/t.co\/Ys0PhOtTkC",
    "id" : 343023101468102657,
    "created_at" : "2013-06-07 15:14:15 +0000",
    "user" : {
      "name" : "CN James",
      "screen_name" : "CNJamesWriter",
      "protected" : false,
      "id_str" : "273710178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/560589733793767424\/b4qrYp_B_normal.jpeg",
      "id" : 273710178,
      "verified" : false
    }
  },
  "id" : 343024430412341248,
  "created_at" : "2013-06-07 15:19:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343024354168291328",
  "text" : "@BibleAlsoSays he doesn't...",
  "id" : 343024354168291328,
  "created_at" : "2013-06-07 15:19:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Healthcare-NOW!",
      "screen_name" : "HCNow",
      "indices" : [ 26, 32 ],
      "id_str" : "197524784",
      "id" : 197524784
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/SMr3xawbws",
      "expanded_url" : "http:\/\/www.healthcare-now.org\/30-million-to-remain-uninsured-under-obamacare",
      "display_url" : "healthcare-now.org\/30-million-to-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "343015605777100800",
  "geo" : { },
  "id_str" : "343022605072228352",
  "in_reply_to_user_id" : 197524784,
  "text" : "need #SinglePayer now! RT @HCNow 30 Million to Remain Uninsured Under Obamacare - http:\/\/t.co\/SMr3xawbws",
  "id" : 343022605072228352,
  "in_reply_to_status_id" : 343015605777100800,
  "created_at" : "2013-06-07 15:12:16 +0000",
  "in_reply_to_screen_name" : "HCNow",
  "in_reply_to_user_id_str" : "197524784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343020516086538240",
  "text" : ". @1stCitizenKane yeah.. where is that line between?",
  "id" : 343020516086538240,
  "created_at" : "2013-06-07 15:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343020108400193536",
  "text" : "cranky today.. maybe some ranting on the way? maybe.",
  "id" : 343020108400193536,
  "created_at" : "2013-06-07 15:02:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray",
      "screen_name" : "RaymondSultan",
      "indices" : [ 3, 17 ],
      "id_str" : "84361938",
      "id" : 84361938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343019287369355264",
  "text" : "RT @RaymondSultan: don't start day by reading comments. don't start day by reading comments. don't start day by reading comments. don't sta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343005204913987584",
    "text" : "don't start day by reading comments. don't start day by reading comments. don't start day by reading comments. don't start day by reading co",
    "id" : 343005204913987584,
    "created_at" : "2013-06-07 14:03:08 +0000",
    "user" : {
      "name" : "Ray",
      "screen_name" : "RaymondSultan",
      "protected" : false,
      "id_str" : "84361938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529000536146591744\/1KdVa0D6_normal.jpeg",
      "id" : 84361938,
      "verified" : true
    }
  },
  "id" : 343019287369355264,
  "created_at" : "2013-06-07 14:59:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343019127369252864",
  "text" : "RT @taraburner: Someone will always be prettier. Someone will always be smarter. Someone will always be younger. But they will never be YOU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "343009958960459776",
    "text" : "Someone will always be prettier. Someone will always be smarter. Someone will always be younger. But they will never be YOU  ~Nikki Woods",
    "id" : 343009958960459776,
    "created_at" : "2013-06-07 14:22:01 +0000",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 343019127369252864,
  "created_at" : "2013-06-07 14:58:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CosmicConsciousness",
      "indices" : [ 18, 38 ]
    }, {
      "text" : "God",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "Atheism",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ohhhA3MdD5",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=w1ku2O_E4MM",
      "display_url" : "youtube.com\/watch?v=w1ku2O\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "343019003435954177",
  "text" : "RT @DeepakChopra: #CosmicConsciousness conceives spacetime , enters it &amp; becomes the universe #God #Atheism http:\/\/t.co\/ohhhA3MdD5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CosmicConsciousness",
        "indices" : [ 0, 20 ]
      }, {
        "text" : "God",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "Atheism",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ohhhA3MdD5",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=w1ku2O_E4MM",
        "display_url" : "youtube.com\/watch?v=w1ku2O\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "343010315010719744",
    "text" : "#CosmicConsciousness conceives spacetime , enters it &amp; becomes the universe #God #Atheism http:\/\/t.co\/ohhhA3MdD5",
    "id" : 343010315010719744,
    "created_at" : "2013-06-07 14:23:26 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 343019003435954177,
  "created_at" : "2013-06-07 14:57:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/buaKUro5ZT",
      "expanded_url" : "http:\/\/amzn.to\/15Q3kQp",
      "display_url" : "amzn.to\/15Q3kQp"
    } ]
  },
  "geo" : { },
  "id_str" : "342818482225807360",
  "text" : "finished Plato Blinked by Heather Pioro http:\/\/t.co\/buaKUro5ZT",
  "id" : 342818482225807360,
  "created_at" : "2013-06-07 01:41:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elsa Joy Bailey",
      "screen_name" : "iamwun",
      "indices" : [ 3, 10 ],
      "id_str" : "32729111",
      "id" : 32729111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342790424223682560",
  "text" : "RT @iamwun: Be willing to be a Beginner every single Morning.   ~Meister Eckhart",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342788622434570241",
    "text" : "Be willing to be a Beginner every single Morning.   ~Meister Eckhart",
    "id" : 342788622434570241,
    "created_at" : "2013-06-06 23:42:30 +0000",
    "user" : {
      "name" : "Elsa Joy Bailey",
      "screen_name" : "iamwun",
      "protected" : false,
      "id_str" : "32729111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421678021\/rose4_normal.PNG",
      "id" : 32729111,
      "verified" : false
    }
  },
  "id" : 342790424223682560,
  "created_at" : "2013-06-06 23:49:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TN Democratic Party",
      "screen_name" : "tndp",
      "indices" : [ 3, 8 ],
      "id_str" : "19916171",
      "id" : 19916171
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342784285180301312",
  "text" : "RT @tndp: GOP Rep. Stephen Fincher On A Mission From God--Starve The Poor While Personally Pocketing Millions In Farm Subsidies http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/SJPJzk1ghm",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/rickungar\/2013\/05\/22\/gop-congressman-stephen-fincher-on-a-mission-from-god-starve-the-poor-while-personally-pocketing-millions-in-farm-subsidies\/",
        "display_url" : "forbes.com\/sites\/rickunga\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337282180608827392",
    "text" : "GOP Rep. Stephen Fincher On A Mission From God--Starve The Poor While Personally Pocketing Millions In Farm Subsidies http:\/\/t.co\/SJPJzk1ghm",
    "id" : 337282180608827392,
    "created_at" : "2013-05-22 19:01:52 +0000",
    "user" : {
      "name" : "TN Democratic Party",
      "screen_name" : "tndp",
      "protected" : false,
      "id_str" : "19916171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/408079677\/tndp-logo-vert-sq_normal.png",
      "id" : 19916171,
      "verified" : true
    }
  },
  "id" : 342784285180301312,
  "created_at" : "2013-06-06 23:25:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342781225880141824",
  "text" : "RT @BrianRathbone: Hell hath no fury like a dragon scorned.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342781072788049920",
    "text" : "Hell hath no fury like a dragon scorned.",
    "id" : 342781072788049920,
    "created_at" : "2013-06-06 23:12:30 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 342781225880141824,
  "created_at" : "2013-06-06 23:13:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 79, 94 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 95, 109 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342684630681534465",
  "geo" : { },
  "id_str" : "342778483912634368",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce my entire personality is \"not sure\" .. ppl hate shopping w me ; ) @BlkGodlessDick @allthewayleft",
  "id" : 342778483912634368,
  "in_reply_to_status_id" : 342684630681534465,
  "created_at" : "2013-06-06 23:02:13 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 72, 84 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 85, 100 ],
      "id_str" : "454581448",
      "id" : 454581448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342759442691002368",
  "geo" : { },
  "id_str" : "342778192597233665",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft my heart is what told me eternal hell did not make sense @TheBevForce @BlkGodlessDick",
  "id" : 342778192597233665,
  "in_reply_to_status_id" : 342759442691002368,
  "created_at" : "2013-06-06 23:01:04 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 0, 10 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342762539379212288",
  "geo" : { },
  "id_str" : "342763154767482880",
  "in_reply_to_user_id" : 15572724,
  "text" : "@ShhDragon smooches beautiful Saki!",
  "id" : 342763154767482880,
  "in_reply_to_status_id" : 342762539379212288,
  "created_at" : "2013-06-06 22:01:18 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342758734415663104",
  "geo" : { },
  "id_str" : "342760284127105024",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl i see you! lol : )",
  "id" : 342760284127105024,
  "in_reply_to_status_id" : 342758734415663104,
  "created_at" : "2013-06-06 21:49:54 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "naturalnews",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/EyEEmUAnq8",
      "expanded_url" : "http:\/\/ow.ly\/lMTaV",
      "display_url" : "ow.ly\/lMTaV"
    } ]
  },
  "geo" : { },
  "id_str" : "342759238449377280",
  "text" : "RT @HealthRanger: Weather weapons have existed for over 15 years, testified U.S. Secretary of Defense. http:\/\/t.co\/EyEEmUAnq8 #naturalnews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "naturalnews",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/EyEEmUAnq8",
        "expanded_url" : "http:\/\/ow.ly\/lMTaV",
        "display_url" : "ow.ly\/lMTaV"
      } ]
    },
    "geo" : { },
    "id_str" : "342757592914870272",
    "text" : "Weather weapons have existed for over 15 years, testified U.S. Secretary of Defense. http:\/\/t.co\/EyEEmUAnq8 #naturalnews",
    "id" : 342757592914870272,
    "created_at" : "2013-06-06 21:39:12 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 342759238449377280,
  "created_at" : "2013-06-06 21:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342756863949017089",
  "text" : "RT @richarddoetsch: Who ever decided what 'normal' is... ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342756271990136832",
    "text" : "Who ever decided what 'normal' is... ?",
    "id" : 342756271990136832,
    "created_at" : "2013-06-06 21:33:58 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 342756863949017089,
  "created_at" : "2013-06-06 21:36:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342754269742645248",
  "text" : "Intent of #Obamacare is good.. but we need #SinglePayer",
  "id" : 342754269742645248,
  "created_at" : "2013-06-06 21:26:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 69, 84 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 85, 99 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342743413885632513",
  "geo" : { },
  "id_str" : "342751190238507008",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce no idea how to answer except its what my heart tells me @BlkGodlessDick @allthewayleft",
  "id" : 342751190238507008,
  "in_reply_to_status_id" : 342743413885632513,
  "created_at" : "2013-06-06 21:13:46 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "io9",
      "screen_name" : "io9",
      "indices" : [ 3, 7 ],
      "id_str" : "13215132",
      "id" : 13215132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/QP7kF7UsOf",
      "expanded_url" : "http:\/\/on.io9.com\/Pxw3P8z",
      "display_url" : "on.io9.com\/Pxw3P8z"
    } ]
  },
  "geo" : { },
  "id_str" : "342750666294427648",
  "text" : "RT @io9: Ask a physicist a good question . . . and win a book! http:\/\/t.co\/QP7kF7UsOf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/QP7kF7UsOf",
        "expanded_url" : "http:\/\/on.io9.com\/Pxw3P8z",
        "display_url" : "on.io9.com\/Pxw3P8z"
      } ]
    },
    "geo" : { },
    "id_str" : "342715445981356032",
    "text" : "Ask a physicist a good question . . . and win a book! http:\/\/t.co\/QP7kF7UsOf",
    "id" : 342715445981356032,
    "created_at" : "2013-06-06 18:51:44 +0000",
    "user" : {
      "name" : "io9",
      "screen_name" : "io9",
      "protected" : false,
      "id_str" : "13215132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987478150\/f20258fd958408104e415fbc7b57b0bc_normal.png",
      "id" : 13215132,
      "verified" : true
    }
  },
  "id" : 342750666294427648,
  "created_at" : "2013-06-06 21:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NORML",
      "screen_name" : "NORML",
      "indices" : [ 3, 9 ],
      "id_str" : "16668573",
      "id" : 16668573
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NORML",
      "indices" : [ 11, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/cn57CfxoUi",
      "expanded_url" : "http:\/\/tinyurl.com\/lqxm5uo",
      "display_url" : "tinyurl.com\/lqxm5uo"
    } ]
  },
  "geo" : { },
  "id_str" : "342749491230818306",
  "text" : "RT @NORML: #NORML  It's Official: Vermont Becomes 17th State To End Criminal Sanctions For Marijuana http:\/\/t.co\/cn57CfxoUi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blog.norml.org\" rel=\"nofollow\"\u003ENORMLblog\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NORML",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/cn57CfxoUi",
        "expanded_url" : "http:\/\/tinyurl.com\/lqxm5uo",
        "display_url" : "tinyurl.com\/lqxm5uo"
      } ]
    },
    "geo" : { },
    "id_str" : "342739594778923008",
    "text" : "#NORML  It's Official: Vermont Becomes 17th State To End Criminal Sanctions For Marijuana http:\/\/t.co\/cn57CfxoUi",
    "id" : 342739594778923008,
    "created_at" : "2013-06-06 20:27:41 +0000",
    "user" : {
      "name" : "NORML",
      "screen_name" : "NORML",
      "protected" : false,
      "id_str" : "16668573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658666517995778048\/C4-qlh8T_normal.jpg",
      "id" : 16668573,
      "verified" : true
    }
  },
  "id" : 342749491230818306,
  "created_at" : "2013-06-06 21:07:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cain S. LaTrans",
      "screen_name" : "snkscoyote",
      "indices" : [ 3, 14 ],
      "id_str" : "74831215",
      "id" : 74831215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/hdPtti70hp",
      "expanded_url" : "http:\/\/fb.me\/289fmEzGc",
      "display_url" : "fb.me\/289fmEzGc"
    } ]
  },
  "geo" : { },
  "id_str" : "342726042575831040",
  "text" : "RT @snkscoyote: Texas Says It's OK to Shoot an Escort If She Won't Have Sex With You http:\/\/t.co\/hdPtti70hp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/hdPtti70hp",
        "expanded_url" : "http:\/\/fb.me\/289fmEzGc",
        "display_url" : "fb.me\/289fmEzGc"
      } ]
    },
    "geo" : { },
    "id_str" : "342723142294323201",
    "text" : "Texas Says It's OK to Shoot an Escort If She Won't Have Sex With You http:\/\/t.co\/hdPtti70hp",
    "id" : 342723142294323201,
    "created_at" : "2013-06-06 19:22:19 +0000",
    "user" : {
      "name" : "Cain S. LaTrans",
      "screen_name" : "snkscoyote",
      "protected" : false,
      "id_str" : "74831215",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366316318\/coyote_normal.jpg",
      "id" : 74831215,
      "verified" : false
    }
  },
  "id" : 342726042575831040,
  "created_at" : "2013-06-06 19:33:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.wildfireapp.com\/?utm_source=Twitter&utm_medium=Tweet&utm_campaign=via%2BWildfire%2BSuite\" rel=\"nofollow\"\u003EWildfire Suite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/2rDQVaK1Te",
      "expanded_url" : "http:\/\/wfi.re\/upqeu",
      "display_url" : "wfi.re\/upqeu"
    } ]
  },
  "geo" : { },
  "id_str" : "342711529105391617",
  "text" : "I entered the Erin Healy's \"Afloat\" Giveaway for a chance to win an iPad Mini!: http:\/\/t.co\/2rDQVaK1Te",
  "id" : 342711529105391617,
  "created_at" : "2013-06-06 18:36:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 3, 16 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Min",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342707262873272321",
  "text" : "RT @InvisCollege: Heaven is in the heart and hell in the head and free will is the vehicle that can take you to either. #Min",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Min",
        "indices" : [ 102, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342686646694731776",
    "text" : "Heaven is in the heart and hell in the head and free will is the vehicle that can take you to either. #Min",
    "id" : 342686646694731776,
    "created_at" : "2013-06-06 16:57:18 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "protected" : false,
      "id_str" : "415556669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645216237\/invisible_college_normal.jpg",
      "id" : 415556669,
      "verified" : false
    }
  },
  "id" : 342707262873272321,
  "created_at" : "2013-06-06 18:19:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kasey Kimbrough",
      "screen_name" : "unicornus_rex",
      "indices" : [ 3, 17 ],
      "id_str" : "258097478",
      "id" : 258097478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342707141783715840",
  "text" : "RT @unicornus_rex: Hey Aetna, all of a sudden requiring my prescription to have a 90 day refill when I just got it refilled for 30 a month \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342680188557066241",
    "text" : "Hey Aetna, all of a sudden requiring my prescription to have a 90 day refill when I just got it refilled for 30 a month ago and now I'm out?",
    "id" : 342680188557066241,
    "created_at" : "2013-06-06 16:31:38 +0000",
    "user" : {
      "name" : "Kasey Kimbrough",
      "screen_name" : "unicornus_rex",
      "protected" : false,
      "id_str" : "258097478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716092570355556354\/ItNaDsIM_normal.jpg",
      "id" : 258097478,
      "verified" : false
    }
  },
  "id" : 342707141783715840,
  "created_at" : "2013-06-06 18:18:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342706607840444416",
  "text" : "@Llimoner_ true.. and reality is even real..",
  "id" : 342706607840444416,
  "created_at" : "2013-06-06 18:16:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Moi",
      "screen_name" : "TheAtheistSpark",
      "indices" : [ 96, 112 ],
      "id_str" : "1335164970",
      "id" : 1335164970
    }, {
      "name" : "(V)nemoni)(s",
      "screen_name" : "MnemoniXs",
      "indices" : [ 113, 123 ],
      "id_str" : "45928833",
      "id" : 45928833
    }, {
      "name" : "hamdi \u015Fen",
      "screen_name" : "Atheist_Viking",
      "indices" : [ 124, 139 ],
      "id_str" : "403251396",
      "id" : 403251396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342706258291351553",
  "text" : "@TheBevForcebirds \"birds don't leave a happy nest\" lol..never heard it put that way. i like it! @TheAtheistSpark @MnemoniXs @Atheist_Viking",
  "id" : 342706258291351553,
  "created_at" : "2013-06-06 18:15:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342681904153243648",
  "geo" : { },
  "id_str" : "342698390766878723",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow its nice to have someone that shares so much history...",
  "id" : 342698390766878723,
  "in_reply_to_status_id" : 342681904153243648,
  "created_at" : "2013-06-06 17:43:58 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342681904153243648",
  "geo" : { },
  "id_str" : "342698202673319937",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow im very blessed to have found DH at a young age. he's been a saint to put up w me!",
  "id" : 342698202673319937,
  "in_reply_to_status_id" : 342681904153243648,
  "created_at" : "2013-06-06 17:43:13 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 28, 43 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 44, 58 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342684630681534465",
  "geo" : { },
  "id_str" : "342697794672410625",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce yes, I do..lol @BlkGodlessDick @allthewayleft",
  "id" : 342697794672410625,
  "in_reply_to_status_id" : 342684630681534465,
  "created_at" : "2013-06-06 17:41:35 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 104, 119 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 120, 134 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342682246077091841",
  "geo" : { },
  "id_str" : "342683608538038273",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce i have faith that The Universe knows what it is doing and no matter what, it's all ok. : ) @BlkGodlessDick @allthewayleft",
  "id" : 342683608538038273,
  "in_reply_to_status_id" : 342682246077091841,
  "created_at" : "2013-06-06 16:45:13 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 69, 84 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 85, 99 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342680682855817216",
  "geo" : { },
  "id_str" : "342681220230025216",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce depth of what then? how would an atheist define a soul? @BlkGodlessDick @allthewayleft",
  "id" : 342681220230025216,
  "in_reply_to_status_id" : 342680682855817216,
  "created_at" : "2013-06-06 16:35:44 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 78, 93 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 94, 108 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342679211418472448",
  "geo" : { },
  "id_str" : "342680777156349953",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce absolutely, i could be wrong about everything i believe or think @BlkGodlessDick @allthewayleft",
  "id" : 342680777156349953,
  "in_reply_to_status_id" : 342679211418472448,
  "created_at" : "2013-06-06 16:33:58 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 59, 74 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 75, 89 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342678918991581184",
  "geo" : { },
  "id_str" : "342679969199181824",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce hmm.. i'll have to ponder on that statement.. @BlkGodlessDick @allthewayleft",
  "id" : 342679969199181824,
  "in_reply_to_status_id" : 342678918991581184,
  "created_at" : "2013-06-06 16:30:46 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 83, 95 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 96, 110 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342678572667920384",
  "geo" : { },
  "id_str" : "342679563601584128",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick how can something be deep if there's no soul to have depth..lol :P @TheBevForce @allthewayleft",
  "id" : 342679563601584128,
  "in_reply_to_status_id" : 342678572667920384,
  "created_at" : "2013-06-06 16:29:09 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 108, 123 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 124, 138 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342678150184071171",
  "geo" : { },
  "id_str" : "342679160608653312",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce they are my truths.. for now. they are flexible and can change when i assimilate new concepts. @BlkGodlessDick @allthewayleft",
  "id" : 342679160608653312,
  "in_reply_to_status_id" : 342678150184071171,
  "created_at" : "2013-06-06 16:27:33 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 81, 96 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 97, 111 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342677762412261376",
  "geo" : { },
  "id_str" : "342678673410891776",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce another thing i live by.. \"dont throw the baby out w the bathwater\" @BlkGodlessDick @allthewayleft",
  "id" : 342678673410891776,
  "in_reply_to_status_id" : 342677762412261376,
  "created_at" : "2013-06-06 16:25:37 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 37, 52 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 53, 67 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342675886539169792",
  "geo" : { },
  "id_str" : "342676743850713088",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce so am I arrogant, then? @BlkGodlessDick @allthewayleft",
  "id" : 342676743850713088,
  "in_reply_to_status_id" : 342675886539169792,
  "created_at" : "2013-06-06 16:17:57 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 45, 60 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 61, 75 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342674435330953216",
  "geo" : { },
  "id_str" : "342676522055905280",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce what am i picking and choosing? @BlkGodlessDick @allthewayleft",
  "id" : 342676522055905280,
  "in_reply_to_status_id" : 342674435330953216,
  "created_at" : "2013-06-06 16:17:04 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 50, 65 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 66, 80 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342674091741949952",
  "geo" : { },
  "id_str" : "342676238386737153",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce you cant use reason to get into war? @BlkGodlessDick @allthewayleft",
  "id" : 342676238386737153,
  "in_reply_to_status_id" : 342674091741949952,
  "created_at" : "2013-06-06 16:15:56 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 85, 100 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 101, 115 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342674091741949952",
  "geo" : { },
  "id_str" : "342675882156105729",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce you are lumping many things together.. religion and faith are not same. @BlkGodlessDick @allthewayleft",
  "id" : 342675882156105729,
  "in_reply_to_status_id" : 342674091741949952,
  "created_at" : "2013-06-06 16:14:31 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 100, 115 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 116, 130 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342673294505410561",
  "geo" : { },
  "id_str" : "342675516693807105",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce some ppl do use faith arrogantly, some use as umbrella and some use as vehicle to help @BlkGodlessDick @allthewayleft",
  "id" : 342675516693807105,
  "in_reply_to_status_id" : 342673294505410561,
  "created_at" : "2013-06-06 16:13:04 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 53, 68 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 69, 83 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342673294505410561",
  "geo" : { },
  "id_str" : "342675021652701185",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce depends on the person holding the faith @BlkGodlessDick @allthewayleft",
  "id" : 342675021652701185,
  "in_reply_to_status_id" : 342673294505410561,
  "created_at" : "2013-06-06 16:11:06 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 3, 12 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342674352753475584",
  "text" : "RT @FearDept: So far this week we've secured your DNA, Verizon phone records, Google accounts and laptop data. And it's only Thurs. #SCOTUS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 118, 125 ]
      }, {
        "text" : "NSA",
        "indices" : [ 126, 130 ]
      }, {
        "text" : "FBI",
        "indices" : [ 131, 135 ]
      }, {
        "text" : "DHS",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342617659231330306",
    "text" : "So far this week we've secured your DNA, Verizon phone records, Google accounts and laptop data. And it's only Thurs. #SCOTUS #NSA #FBI #DHS",
    "id" : 342617659231330306,
    "created_at" : "2013-06-06 12:23:10 +0000",
    "user" : {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "protected" : false,
      "id_str" : "141834186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453113104939761664\/9ZqHHvvA_normal.png",
      "id" : 141834186,
      "verified" : false
    }
  },
  "id" : 342674352753475584,
  "created_at" : "2013-06-06 16:08:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 58, 73 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 74, 88 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342671136619905027",
  "geo" : { },
  "id_str" : "342672590881583104",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce ndes\/ghosts\/quantumphysics\/energy\/vibrations @BlkGodlessDick @allthewayleft",
  "id" : 342672590881583104,
  "in_reply_to_status_id" : 342671136619905027,
  "created_at" : "2013-06-06 16:01:26 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 44, 59 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 60, 74 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342668634600128512",
  "geo" : { },
  "id_str" : "342671411124514816",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce war is all about power, too... @BlkGodlessDick @allthewayleft",
  "id" : 342671411124514816,
  "in_reply_to_status_id" : 342668634600128512,
  "created_at" : "2013-06-06 15:56:45 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 101, 113 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 114, 128 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342666874175229952",
  "geo" : { },
  "id_str" : "342667550947155968",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick no, i mean in their afterlife. my belief is whats in our heart creates our afterlife @TheBevForce @allthewayleft",
  "id" : 342667550947155968,
  "in_reply_to_status_id" : 342666874175229952,
  "created_at" : "2013-06-06 15:41:25 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 97, 109 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 110, 124 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342665038047371266",
  "geo" : { },
  "id_str" : "342666110426021889",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick eternal hell, no.. but i do think unhappy ppl can create their own hell of sorts @TheBevForce @allthewayleft",
  "id" : 342666110426021889,
  "in_reply_to_status_id" : 342665038047371266,
  "created_at" : "2013-06-06 15:35:41 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 76, 88 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 89, 103 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342665038047371266",
  "geo" : { },
  "id_str" : "342665802715119616",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick i think sin as a word was distorted to mean more than it is @TheBevForce @allthewayleft",
  "id" : 342665802715119616,
  "in_reply_to_status_id" : 342665038047371266,
  "created_at" : "2013-06-06 15:34:28 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 101, 113 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 114, 128 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wholeotherdiscussion",
      "indices" : [ 79, 100 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342663968994770945",
  "geo" : { },
  "id_str" : "342665179655450624",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick this part gets sticky w me cuz im not thrilled w vacc or chemo #wholeotherdiscussion @TheBevForce @allthewayleft",
  "id" : 342665179655450624,
  "in_reply_to_status_id" : 342663968994770945,
  "created_at" : "2013-06-06 15:31:59 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 49, 61 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 62, 76 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342659410499350528",
  "geo" : { },
  "id_str" : "342664128327999488",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick agreed w no sin, no eternal hell @TheBevForce @allthewayleft",
  "id" : 342664128327999488,
  "in_reply_to_status_id" : 342659410499350528,
  "created_at" : "2013-06-06 15:27:49 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 85, 97 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 98, 112 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342658770599571456",
  "geo" : { },
  "id_str" : "342662737450659840",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick agreed.. practice as you will as long as does not infringe on others @TheBevForce @allthewayleft",
  "id" : 342662737450659840,
  "in_reply_to_status_id" : 342658770599571456,
  "created_at" : "2013-06-06 15:22:17 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 3, 17 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alaska",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/dg0x4BGREX",
      "expanded_url" : "http:\/\/alaskanatureimages.zenfolio.com\/p449995941\/e6f3a406b",
      "display_url" : "alaskanatureimages.zenfolio.com\/p449995941\/e6f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342660922764050434",
  "text" : "RT @Alaskachic907: Alaska Nature Images | Alaskan Moose | Mama is resting while one baby is up and about. http:\/\/t.co\/dg0x4BGREX #alaska #n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "alaska",
        "indices" : [ 110, 117 ]
      }, {
        "text" : "nature",
        "indices" : [ 118, 125 ]
      }, {
        "text" : "photography",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/dg0x4BGREX",
        "expanded_url" : "http:\/\/alaskanatureimages.zenfolio.com\/p449995941\/e6f3a406b",
        "display_url" : "alaskanatureimages.zenfolio.com\/p449995941\/e6f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342660115394072577",
    "text" : "Alaska Nature Images | Alaskan Moose | Mama is resting while one baby is up and about. http:\/\/t.co\/dg0x4BGREX #alaska #nature #photography",
    "id" : 342660115394072577,
    "created_at" : "2013-06-06 15:11:52 +0000",
    "user" : {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "protected" : false,
      "id_str" : "80073299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760585201395245056\/PApWQ2Xd_normal.jpg",
      "id" : 80073299,
      "verified" : false
    }
  },
  "id" : 342660922764050434,
  "created_at" : "2013-06-06 15:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 3, 17 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "alaska",
      "indices" : [ 123, 130 ]
    }, {
      "text" : "nature",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/dMCjsxQlpb",
      "expanded_url" : "http:\/\/alaskanatureimages.zenfolio.com\/p811402874\/e672940ba",
      "display_url" : "alaskanatureimages.zenfolio.com\/p811402874\/e67\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342660346743488513",
  "text" : "RT @Alaskachic907: Alaska Nature Images | Snowshoe Bunny | Every morning he shows up for breakfast. http:\/\/t.co\/dMCjsxQlpb #alaska #nature \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "alaska",
        "indices" : [ 104, 111 ]
      }, {
        "text" : "nature",
        "indices" : [ 112, 119 ]
      }, {
        "text" : "photography",
        "indices" : [ 120, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/dMCjsxQlpb",
        "expanded_url" : "http:\/\/alaskanatureimages.zenfolio.com\/p811402874\/e672940ba",
        "display_url" : "alaskanatureimages.zenfolio.com\/p811402874\/e67\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342659870157332480",
    "text" : "Alaska Nature Images | Snowshoe Bunny | Every morning he shows up for breakfast. http:\/\/t.co\/dMCjsxQlpb #alaska #nature #photography",
    "id" : 342659870157332480,
    "created_at" : "2013-06-06 15:10:54 +0000",
    "user" : {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "protected" : false,
      "id_str" : "80073299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760585201395245056\/PApWQ2Xd_normal.jpg",
      "id" : 80073299,
      "verified" : false
    }
  },
  "id" : 342660346743488513,
  "created_at" : "2013-06-06 15:12:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "marijuana",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342659109851652097",
  "text" : "i dont get how a plant can be illegal... #marijuana",
  "id" : 342659109851652097,
  "created_at" : "2013-06-06 15:07:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342658320416522240",
  "text" : "RT @ChickenJen: tick-tick-tick ~ Only 9 more days to sign up to win one of 15 copies of my new chick lit novel, \"Peas, Beans &amp; Corn\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/BYwNf4Uypy",
        "expanded_url" : "http:\/\/www.goodreads.com\/book\/show\/17825310-peas-beans-corn",
        "display_url" : "goodreads.com\/book\/show\/1782\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342657606017482753",
    "text" : "tick-tick-tick ~ Only 9 more days to sign up to win one of 15 copies of my new chick lit novel, \"Peas, Beans &amp; Corn\" http:\/\/t.co\/BYwNf4Uypy",
    "id" : 342657606017482753,
    "created_at" : "2013-06-06 15:01:54 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 342658320416522240,
  "created_at" : "2013-06-06 15:04:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Pam Liquored Up",
      "screen_name" : "Clear_Liqueur",
      "indices" : [ 3, 17 ],
      "id_str" : "48220779",
      "id" : 48220779
    }, {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "indices" : [ 42, 53 ],
      "id_str" : "1132090693",
      "id" : 1132090693
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/342385669307527168\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/j0cgXepQoN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMBl88OCcAAXtfg.png",
      "id_str" : "342385669311721472",
      "id" : 342385669311721472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMBl88OCcAAXtfg.png",
      "sizes" : [ {
        "h" : 391,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/j0cgXepQoN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342655109869731840",
  "text" : "RT @Clear_Liqueur: I feel so dumb now. RT @Globe_Pics: Mind = Blown http:\/\/t.co\/j0cgXepQoN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Globe Pics",
        "screen_name" : "Globe_Pics",
        "indices" : [ 23, 34 ],
        "id_str" : "1132090693",
        "id" : 1132090693
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/342385669307527168\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/j0cgXepQoN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BMBl88OCcAAXtfg.png",
        "id_str" : "342385669311721472",
        "id" : 342385669311721472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMBl88OCcAAXtfg.png",
        "sizes" : [ {
          "h" : 391,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/j0cgXepQoN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342638357953773570",
    "text" : "I feel so dumb now. RT @Globe_Pics: Mind = Blown http:\/\/t.co\/j0cgXepQoN",
    "id" : 342638357953773570,
    "created_at" : "2013-06-06 13:45:25 +0000",
    "user" : {
      "name" : "Dr. Pam Liquored Up",
      "screen_name" : "Clear_Liqueur",
      "protected" : false,
      "id_str" : "48220779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468597422868811776\/SQTHxSws_normal.jpeg",
      "id" : 48220779,
      "verified" : false
    }
  },
  "id" : 342655109869731840,
  "created_at" : "2013-06-06 14:51:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 0, 16 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342652960632877056",
  "geo" : { },
  "id_str" : "342654776644886528",
  "in_reply_to_user_id" : 175204121,
  "text" : "@WildlifeGadgets what a fluffball.. so sweet i could pop in my mouth! lol",
  "id" : 342654776644886528,
  "in_reply_to_status_id" : 342652960632877056,
  "created_at" : "2013-06-06 14:50:39 +0000",
  "in_reply_to_screen_name" : "WildlifeGadgets",
  "in_reply_to_user_id_str" : "175204121",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackbirdCam",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ejbTGAoqyy",
      "expanded_url" : "http:\/\/wildlifegadgetman.com\/?page_id=100",
      "display_url" : "wildlifegadgetman.com\/?page_id=100"
    } ]
  },
  "geo" : { },
  "id_str" : "342654285701595136",
  "text" : "RT @WildlifeGadgets: Blackbird sitting tight on her nest. Think we still have 3 eggs. http:\/\/t.co\/ejbTGAoqyy #BlackbirdCam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackbirdCam",
        "indices" : [ 88, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/ejbTGAoqyy",
        "expanded_url" : "http:\/\/wildlifegadgetman.com\/?page_id=100",
        "display_url" : "wildlifegadgetman.com\/?page_id=100"
      } ]
    },
    "geo" : { },
    "id_str" : "342652960632877056",
    "text" : "Blackbird sitting tight on her nest. Think we still have 3 eggs. http:\/\/t.co\/ejbTGAoqyy #BlackbirdCam",
    "id" : 342652960632877056,
    "created_at" : "2013-06-06 14:43:26 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 342654285701595136,
  "created_at" : "2013-06-06 14:48:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342653840572702720",
  "text" : "@Skeptical_Lady LOLOL ; )",
  "id" : 342653840572702720,
  "created_at" : "2013-06-06 14:46:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342653326036463616",
  "text" : "@Skeptical_Lady do i think its same as a born infant? no.",
  "id" : 342653326036463616,
  "created_at" : "2013-06-06 14:44:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342653128241463296",
  "text" : "@Skeptical_Lady i disagree. an egg by itself doesnt grow (unless manipulated? cloning?) but egg combined w sperm then starts process.",
  "id" : 342653128241463296,
  "created_at" : "2013-06-06 14:44:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prochoice",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342652012158124032",
  "text" : "@Skeptical_Lady addendum to my prev tweet.. until it leaves mom's body, though, it's mom's choice #prochoice",
  "id" : 342652012158124032,
  "created_at" : "2013-06-06 14:39:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342651625602686976",
  "text" : "@Skeptical_Lady technically human life begins at conception (has inner components (egg &amp; sperm) to grow into baby...",
  "id" : 342651625602686976,
  "created_at" : "2013-06-06 14:38:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342648207358193665",
  "geo" : { },
  "id_str" : "342648646472450049",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny cool! hehe",
  "id" : 342648646472450049,
  "in_reply_to_status_id" : 342648207358193665,
  "created_at" : "2013-06-06 14:26:18 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/3kxho54qGk",
      "expanded_url" : "https:\/\/www.facebook.com\/NealeDonaldWalsch\/posts\/10151434268452344",
      "display_url" : "facebook.com\/NealeDonaldWal\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rH2zWhNyiQ",
      "expanded_url" : "http:\/\/tl.gd\/n_1rkm9r0",
      "display_url" : "tl.gd\/n_1rkm9r0"
    } ]
  },
  "geo" : { },
  "id_str" : "342647044038602752",
  "text" : "\"...God shows up in our lives in exactly the way that He knows we will 'get' Him.\" https:\/\/t.co\/3kxho54qGk I (cont) http:\/\/t.co\/rH2zWhNyiQ",
  "id" : 342647044038602752,
  "created_at" : "2013-06-06 14:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/UxL4YU0Lfa",
      "expanded_url" : "http:\/\/tinyurl.com\/k94vwwx",
      "display_url" : "tinyurl.com\/k94vwwx"
    } ]
  },
  "geo" : { },
  "id_str" : "342640791069536256",
  "text" : "RT @JohnCali: Why Do We Need Forgiveness? by John Cali http:\/\/t.co\/UxL4YU0Lfa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/leenk.me\/\" rel=\"nofollow\"\u003Eleenk.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/UxL4YU0Lfa",
        "expanded_url" : "http:\/\/tinyurl.com\/k94vwwx",
        "display_url" : "tinyurl.com\/k94vwwx"
      } ]
    },
    "geo" : { },
    "id_str" : "342638503810723840",
    "text" : "Why Do We Need Forgiveness? by John Cali http:\/\/t.co\/UxL4YU0Lfa",
    "id" : 342638503810723840,
    "created_at" : "2013-06-06 13:45:59 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 342640791069536256,
  "created_at" : "2013-06-06 13:55:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chice2501",
      "screen_name" : "OmniPada",
      "indices" : [ 0, 9 ],
      "id_str" : "2559589411",
      "id" : 2559589411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342638255717625856",
  "text" : "@OmniPada hmm.. now this is a different look at love..",
  "id" : 342638255717625856,
  "created_at" : "2013-06-06 13:45:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unroll.Me",
      "screen_name" : "Unrollme",
      "indices" : [ 12, 21 ],
      "id_str" : "339769044",
      "id" : 339769044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Ahdotm3h2a",
      "expanded_url" : "http:\/\/unrl.me\/14YMDSC",
      "display_url" : "unrl.me\/14YMDSC"
    } ]
  },
  "geo" : { },
  "id_str" : "342633744919822336",
  "text" : "This month, @Unrollme combined 356 emails for me into daily digests! Life is busy. Your inbox shouldn't be. http:\/\/t.co\/Ahdotm3h2a",
  "id" : 342633744919822336,
  "created_at" : "2013-06-06 13:27:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 0, 16 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342626221693206528",
  "geo" : { },
  "id_str" : "342631681246773248",
  "in_reply_to_user_id" : 36656159,
  "text" : "@thebeadedpillow congrats! we will be 25 in sept. amazing how time flies..lol",
  "id" : 342631681246773248,
  "in_reply_to_status_id" : 342626221693206528,
  "created_at" : "2013-06-06 13:18:53 +0000",
  "in_reply_to_screen_name" : "thebeadedpillow",
  "in_reply_to_user_id_str" : "36656159",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342627679830425600",
  "geo" : { },
  "id_str" : "342630970287063041",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ive had that happen often. i'll check and see it RT'd. weird.",
  "id" : 342630970287063041,
  "in_reply_to_status_id" : 342627679830425600,
  "created_at" : "2013-06-06 13:16:03 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342589151176163328",
  "geo" : { },
  "id_str" : "342629504218451968",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce in a way the idea of \"alien life\" is silly.. look at all the alien life on our planet! we got some weird, neat stuff here.",
  "id" : 342629504218451968,
  "in_reply_to_status_id" : 342589151176163328,
  "created_at" : "2013-06-06 13:10:14 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 39, 53 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 54, 69 ],
      "id_str" : "454581448",
      "id" : 454581448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342425924395999232",
  "geo" : { },
  "id_str" : "342627021811232770",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce history shows what a lie? @allthewayleft @BlkGodlessDick",
  "id" : 342627021811232770,
  "in_reply_to_status_id" : 342425924395999232,
  "created_at" : "2013-06-06 13:00:22 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 84, 99 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 100, 114 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342425632304660481",
  "geo" : { },
  "id_str" : "342626780403884032",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce bible is many books written over long period of time.. ALL fabricated? @BlkGodlessDick @allthewayleft",
  "id" : 342626780403884032,
  "in_reply_to_status_id" : 342425632304660481,
  "created_at" : "2013-06-06 12:59:24 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342413334987026432",
  "text" : "RT @howtobesick: This a.m.'s new post if you missed it. Is Free Will an Illusion? A Guest Post by Joan Tollifson | Psychology Today http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/O1guK9SIsb",
        "expanded_url" : "http:\/\/www.psychologytoday.com\/blog\/turning-straw-gold\/201306\/is-free-will-illusion-guest-post-joan-tollifson",
        "display_url" : "psychologytoday.com\/blog\/turning-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342404207313305600",
    "text" : "This a.m.'s new post if you missed it. Is Free Will an Illusion? A Guest Post by Joan Tollifson | Psychology Today http:\/\/t.co\/O1guK9SIsb",
    "id" : 342404207313305600,
    "created_at" : "2013-06-05 22:14:59 +0000",
    "user" : {
      "name" : "Toni Bernhard",
      "screen_name" : "toni_bernhard",
      "protected" : false,
      "id_str" : "169982819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759869867449196544\/dEV7yImo_normal.jpg",
      "id" : 169982819,
      "verified" : false
    }
  },
  "id" : 342413334987026432,
  "created_at" : "2013-06-05 22:51:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Captain Clarion",
      "screen_name" : "citizensrock",
      "indices" : [ 3, 16 ],
      "id_str" : "271030180",
      "id" : 271030180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342388872245813248",
  "text" : "RT @citizensrock: IN WHAT UNIVERSE is it necessary to publicly trade the health care of Americans as though it were the same as pork bellie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342067693668675584",
    "text" : "IN WHAT UNIVERSE is it necessary to publicly trade the health care of Americans as though it were the same as pork bellies and tinker toys?",
    "id" : 342067693668675584,
    "created_at" : "2013-06-04 23:57:48 +0000",
    "user" : {
      "name" : "Captain Clarion",
      "screen_name" : "citizensrock",
      "protected" : false,
      "id_str" : "271030180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500767478197153792\/necyH3Wl_normal.png",
      "id" : 271030180,
      "verified" : false
    }
  },
  "id" : 342388872245813248,
  "created_at" : "2013-06-05 21:14:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "indices" : [ 3, 19 ],
      "id_str" : "36656159",
      "id" : 36656159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342386883105538048",
  "text" : "RT @thebeadedpillow: Mr. and Mrs. Duck moved in under the pine before the neighbor could get the rest of the wood chips down. I was... http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/b65Qg6WFqp",
        "expanded_url" : "http:\/\/fb.me\/KOdH6DhQ",
        "display_url" : "fb.me\/KOdH6DhQ"
      } ]
    },
    "geo" : { },
    "id_str" : "342383490106548224",
    "text" : "Mr. and Mrs. Duck moved in under the pine before the neighbor could get the rest of the wood chips down. I was... http:\/\/t.co\/b65Qg6WFqp",
    "id" : 342383490106548224,
    "created_at" : "2013-06-05 20:52:39 +0000",
    "user" : {
      "name" : "Karen",
      "screen_name" : "thebeadedpillow",
      "protected" : false,
      "id_str" : "36656159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550471777\/Karens_birthday_2008_normal.jpg",
      "id" : 36656159,
      "verified" : false
    }
  },
  "id" : 342386883105538048,
  "created_at" : "2013-06-05 21:06:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342385885578403840",
  "geo" : { },
  "id_str" : "342386357630541824",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny that's so manly! (gruntgruntgrunt)",
  "id" : 342386357630541824,
  "in_reply_to_status_id" : 342385885578403840,
  "created_at" : "2013-06-05 21:04:03 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 9, 17 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/IvQ2iytwZD",
      "expanded_url" : "http:\/\/bit.ly\/6DriLY",
      "display_url" : "bit.ly\/6DriLY"
    } ]
  },
  "in_reply_to_status_id_str" : "342356634238070785",
  "geo" : { },
  "id_str" : "342357062648471552",
  "in_reply_to_user_id" : 15628274,
  "text" : "NOOO! RT @drbloem Merck Wants More Women to Receive the HPV Vaccine http:\/\/t.co\/IvQ2iytwZD #health",
  "id" : 342357062648471552,
  "in_reply_to_status_id" : 342356634238070785,
  "created_at" : "2013-06-05 19:07:39 +0000",
  "in_reply_to_screen_name" : "drbloem",
  "in_reply_to_user_id_str" : "15628274",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 74, 88 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 89, 104 ],
      "id_str" : "454581448",
      "id" : 454581448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342304298379657216",
  "geo" : { },
  "id_str" : "342309486746296320",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce always been fascinated w \"is there god?\"; ghosts; NDE's, etc @allthewayleft @BlkGodlessDick",
  "id" : 342309486746296320,
  "in_reply_to_status_id" : 342304298379657216,
  "created_at" : "2013-06-05 15:58:36 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 86, 100 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 101, 116 ],
      "id_str" : "454581448",
      "id" : 454581448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342304298379657216",
  "geo" : { },
  "id_str" : "342308844690632704",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce lol.. i confuse myself a lot! i guess i was born w propensity to believe @allthewayleft @BlkGodlessDick",
  "id" : 342308844690632704,
  "in_reply_to_status_id" : 342304298379657216,
  "created_at" : "2013-06-05 15:56:03 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 63, 78 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 79, 93 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342303832761577475",
  "geo" : { },
  "id_str" : "342307962573971456",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce i see shades of grey as opposed to black or white @BlkGodlessDick @allthewayleft",
  "id" : 342307962573971456,
  "in_reply_to_status_id" : 342303832761577475,
  "created_at" : "2013-06-05 15:52:32 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LitJuke",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/EtFAwL8tsx",
      "expanded_url" : "http:\/\/j.mp\/11hwwLl",
      "display_url" : "j.mp\/11hwwLl"
    } ]
  },
  "geo" : { },
  "id_str" : "342292751280390147",
  "text" : "RT @brainpicker: \"Every living thing is, from the cosmic perspective, incredibly lucky simply to be alive.\" #LitJuke http:\/\/t.co\/EtFAwL8tsx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LitJuke",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/EtFAwL8tsx",
        "expanded_url" : "http:\/\/j.mp\/11hwwLl",
        "display_url" : "j.mp\/11hwwLl"
      } ]
    },
    "geo" : { },
    "id_str" : "342285214615207937",
    "text" : "\"Every living thing is, from the cosmic perspective, incredibly lucky simply to be alive.\" #LitJuke http:\/\/t.co\/EtFAwL8tsx",
    "id" : 342285214615207937,
    "created_at" : "2013-06-05 14:22:09 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577255253852065794\/qGnSwsBR_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 342292751280390147,
  "created_at" : "2013-06-05 14:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Lohenry",
      "screen_name" : "toddlohenry",
      "indices" : [ 3, 15 ],
      "id_str" : "2921886434",
      "id" : 2921886434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Wy6E6VSAZu",
      "expanded_url" : "http:\/\/bit.ly\/15FfT0R",
      "display_url" : "bit.ly\/15FfT0R"
    } ]
  },
  "geo" : { },
  "id_str" : "342291803518681088",
  "text" : "RT @toddlohenry: How would you answer the question \"Who is God?\" http:\/\/t.co\/Wy6E6VSAZu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/Wy6E6VSAZu",
        "expanded_url" : "http:\/\/bit.ly\/15FfT0R",
        "display_url" : "bit.ly\/15FfT0R"
      } ]
    },
    "geo" : { },
    "id_str" : "342036200598675458",
    "text" : "How would you answer the question \"Who is God?\" http:\/\/t.co\/Wy6E6VSAZu",
    "id" : 342036200598675458,
    "created_at" : "2013-06-04 21:52:39 +0000",
    "user" : {
      "name" : "Bright Shiny Objects",
      "screen_name" : "brightshinyobje",
      "protected" : false,
      "id_str" : "18427567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583260267632443392\/TqdDmqDt_normal.jpg",
      "id" : 18427567,
      "verified" : false
    }
  },
  "id" : 342291803518681088,
  "created_at" : "2013-06-05 14:48:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/f7TdbUp2bT",
      "expanded_url" : "http:\/\/tinyurl.com\/bm7c73r",
      "display_url" : "tinyurl.com\/bm7c73r"
    } ]
  },
  "geo" : { },
  "id_str" : "342289044924936195",
  "text" : "RT @Soulseedzforall: Be kind. It\u2019s not easy, but it is worth the effort. http:\/\/t.co\/f7TdbUp2bT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/f7TdbUp2bT",
        "expanded_url" : "http:\/\/tinyurl.com\/bm7c73r",
        "display_url" : "tinyurl.com\/bm7c73r"
      } ]
    },
    "geo" : { },
    "id_str" : "342288713906278402",
    "text" : "Be kind. It\u2019s not easy, but it is worth the effort. http:\/\/t.co\/f7TdbUp2bT",
    "id" : 342288713906278402,
    "created_at" : "2013-06-05 14:36:03 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 342289044924936195,
  "created_at" : "2013-06-05 14:37:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342287119487750144",
  "geo" : { },
  "id_str" : "342287915809927168",
  "in_reply_to_user_id" : 246103,
  "text" : "@JeffreyGuterman our fast paced society is geared toward attaining things, forgetting the journey. Happiness is the trip, not destination.",
  "id" : 342287915809927168,
  "in_reply_to_status_id" : 342287119487750144,
  "created_at" : "2013-06-05 14:32:53 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "indices" : [ 3, 18 ],
      "id_str" : "233966512",
      "id" : 233966512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/vA4XUW2DQt",
      "expanded_url" : "http:\/\/twitpic.com\/cnslif",
      "display_url" : "twitpic.com\/cnslif"
    } ]
  },
  "geo" : { },
  "id_str" : "342286963484794880",
  "text" : "RT @authorkingsley: http:\/\/t.co\/vA4XUW2DQt Get a free reader review copy of my forthcoming novel well in advance of publication http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/vA4XUW2DQt",
        "expanded_url" : "http:\/\/twitpic.com\/cnslif",
        "display_url" : "twitpic.com\/cnslif"
      }, {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/M2yQ3fN2y9",
        "expanded_url" : "http:\/\/bit.ly\/106GGxv",
        "display_url" : "bit.ly\/106GGxv"
      } ]
    },
    "geo" : { },
    "id_str" : "342286753266278400",
    "text" : "http:\/\/t.co\/vA4XUW2DQt Get a free reader review copy of my forthcoming novel well in advance of publication http:\/\/t.co\/M2yQ3fN2y9 Please RT",
    "id" : 342286753266278400,
    "created_at" : "2013-06-05 14:28:16 +0000",
    "user" : {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "protected" : false,
      "id_str" : "233966512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1206687416\/ian-spinaker-90ppi-smallest_normal.JPG",
      "id" : 233966512,
      "verified" : false
    }
  },
  "id" : 342286963484794880,
  "created_at" : "2013-06-05 14:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342286533132435457",
  "text" : "@Skeptical_Lady yes.. we are all one. no peace until humanity gets that (might be awhile.. humans can be stubborn..lol)",
  "id" : 342286533132435457,
  "created_at" : "2013-06-05 14:27:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342286026254995456",
  "text" : "humans cannot agree on anything",
  "id" : 342286026254995456,
  "created_at" : "2013-06-05 14:25:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 11, 27 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342283224791257088",
  "geo" : { },
  "id_str" : "342284777103179780",
  "in_reply_to_user_id" : 246103,
  "text" : "beautiful! @JeffreyGuterman \"All the more reason to appreciate each moment of consciousness we have as a true gift,\"",
  "id" : 342284777103179780,
  "in_reply_to_status_id" : 342283224791257088,
  "created_at" : "2013-06-05 14:20:24 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/x9PClGlzhI",
      "expanded_url" : "http:\/\/www.newyorker.com\/online\/blogs\/comment\/2013\/06\/the-truth-about-pope-francis-and-atheists.html",
      "display_url" : "newyorker.com\/online\/blogs\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342284172280336385",
  "text" : "\u201Cfaithfulness to one\u2019s own conscience\u201D takes precedence over \u201Cthe Church\u2019s preaching.\u201D Hellbound After All? http:\/\/t.co\/x9PClGlzhI?",
  "id" : 342284172280336385,
  "created_at" : "2013-06-05 14:18:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    }, {
      "name" : "HighlandFarmsofTroy",
      "screen_name" : "HighlandFarmsME",
      "indices" : [ 36, 52 ],
      "id_str" : "1050419874",
      "id" : 1050419874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/BZtDcEUB9T",
      "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
      "display_url" : "facebook.com\/HighlandFarmsO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342279461972082688",
  "text" : "RT @ChickenJen: Meet our hairy coos @HighlandFarmsME https:\/\/t.co\/BZtDcEUB9T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HighlandFarmsofTroy",
        "screen_name" : "HighlandFarmsME",
        "indices" : [ 20, 36 ],
        "id_str" : "1050419874",
        "id" : 1050419874
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/BZtDcEUB9T",
        "expanded_url" : "https:\/\/www.facebook.com\/HighlandFarmsOfTroy",
        "display_url" : "facebook.com\/HighlandFarmsO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342274714036756483",
    "text" : "Meet our hairy coos @HighlandFarmsME https:\/\/t.co\/BZtDcEUB9T",
    "id" : 342274714036756483,
    "created_at" : "2013-06-05 13:40:25 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 342279461972082688,
  "created_at" : "2013-06-05 13:59:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 15, 27 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 28, 43 ],
      "id_str" : "454581448",
      "id" : 454581448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342271850740584449",
  "geo" : { },
  "id_str" : "342273663296479233",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft @TheBevForce @BlkGodlessDick im not out to convert anyone, just expressing my personal views which prob wont make sense...",
  "id" : 342273663296479233,
  "in_reply_to_status_id" : 342271850740584449,
  "created_at" : "2013-06-05 13:36:15 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 56, 68 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 69, 84 ],
      "id_str" : "454581448",
      "id" : 454581448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342271850740584449",
  "geo" : { },
  "id_str" : "342272962092756993",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft God=love, we have eternal,evolving souls @TheBevForce @BlkGodlessDick",
  "id" : 342272962092756993,
  "in_reply_to_status_id" : 342271850740584449,
  "created_at" : "2013-06-05 13:33:27 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 36, 51 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 52, 66 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342271595466850307",
  "geo" : { },
  "id_str" : "342272037487783936",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce makes more sense to me @BlkGodlessDick @allthewayleft",
  "id" : 342272037487783936,
  "in_reply_to_status_id" : 342271595466850307,
  "created_at" : "2013-06-05 13:29:47 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 37, 52 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 53, 65 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342270572459343872",
  "geo" : { },
  "id_str" : "342271579633369088",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft something like that.. @BlkGodlessDick @TheBevForce",
  "id" : 342271579633369088,
  "in_reply_to_status_id" : 342270572459343872,
  "created_at" : "2013-06-05 13:27:58 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 41, 56 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 57, 71 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342270676394205184",
  "geo" : { },
  "id_str" : "342271367649038336",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce i think truth was distorted @BlkGodlessDick @allthewayleft",
  "id" : 342271367649038336,
  "in_reply_to_status_id" : 342270676394205184,
  "created_at" : "2013-06-05 13:27:07 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 52, 66 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342122823155855362",
  "geo" : { },
  "id_str" : "342269306966507521",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce my view evolves. all about perception. @allthewayleft",
  "id" : 342269306966507521,
  "in_reply_to_status_id" : 342122823155855362,
  "created_at" : "2013-06-05 13:18:56 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 60, 74 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 75, 87 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342102415732002818",
  "geo" : { },
  "id_str" : "342268736100765696",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick bible was written by men and used for power @allthewayleft @TheBevForce",
  "id" : 342268736100765696,
  "in_reply_to_status_id" : 342102415732002818,
  "created_at" : "2013-06-05 13:16:40 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 44, 59 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 60, 72 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342100448645369857",
  "geo" : { },
  "id_str" : "342268137313538048",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft we are all part of the whole @BlkGodlessDick @TheBevForce",
  "id" : 342268137313538048,
  "in_reply_to_status_id" : 342100448645369857,
  "created_at" : "2013-06-05 13:14:17 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 64, 78 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 79, 91 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342081245527814144",
  "geo" : { },
  "id_str" : "342087656051732480",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick just God.. original source..pure consciousness. @allthewayleft @TheBevForce",
  "id" : 342087656051732480,
  "in_reply_to_status_id" : 342081245527814144,
  "created_at" : "2013-06-05 01:17:07 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "indices" : [ 3, 13 ],
      "id_str" : "536104771",
      "id" : 536104771
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LonerW0lf\/status\/342069941920489472\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/QXaQUMF8Gq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BL9GzMDCYAEzUpE.jpg",
      "id_str" : "342069941924683777",
      "id" : 342069941924683777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL9GzMDCYAEzUpE.jpg",
      "sizes" : [ {
        "h" : 403,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/QXaQUMF8Gq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342075663198588928",
  "text" : "RT @LonerW0lf: For every introverted feeler out there (and the occasional good tempered thinker) \n ~ \u263D http:\/\/t.co\/QXaQUMF8Gq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LonerW0lf\/status\/342069941920489472\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/QXaQUMF8Gq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BL9GzMDCYAEzUpE.jpg",
        "id_str" : "342069941924683777",
        "id" : 342069941924683777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BL9GzMDCYAEzUpE.jpg",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/QXaQUMF8Gq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342069941920489472",
    "text" : "For every introverted feeler out there (and the occasional good tempered thinker) \n ~ \u263D http:\/\/t.co\/QXaQUMF8Gq",
    "id" : 342069941920489472,
    "created_at" : "2013-06-05 00:06:44 +0000",
    "user" : {
      "name" : "LonerWolf",
      "screen_name" : "LonerW0lf",
      "protected" : false,
      "id_str" : "536104771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776397232455061504\/lKsVf5C5_normal.jpg",
      "id" : 536104771,
      "verified" : false
    }
  },
  "id" : 342075663198588928,
  "created_at" : "2013-06-05 00:29:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TreeHugger.com",
      "screen_name" : "TreeHugger",
      "indices" : [ 129, 140 ],
      "id_str" : "14634720",
      "id" : 14634720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/2CSwtRl71j",
      "expanded_url" : "http:\/\/www.treehugger.com\/natural-sciences\/researcher-decodes-praire-dog-language-discovers-theyve-been-calling-people-fat.html",
      "display_url" : "treehugger.com\/natural-scienc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342060910384402432",
  "text" : "Researcher decodes prairie dog language, discovers they've been talking about us (Video) : TreeHugger http:\/\/t.co\/2CSwtRl71j via @TreeHugger",
  "id" : 342060910384402432,
  "created_at" : "2013-06-04 23:30:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 108, 120 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 121, 135 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342056382603862017",
  "geo" : { },
  "id_str" : "342057897175429121",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 its a lifelong search for meaning of life. my subconscious takes notes and gives me the summary @TheBevForce @allthewayleft",
  "id" : 342057897175429121,
  "in_reply_to_status_id" : 342056382603862017,
  "created_at" : "2013-06-04 23:18:52 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 105, 117 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 118, 132 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342054911606919171",
  "geo" : { },
  "id_str" : "342055912632107010",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 you mean lack of evidence? i cannot ignore the strong feeling there is more than what we see @TheBevForce @allthewayleft",
  "id" : 342055912632107010,
  "in_reply_to_status_id" : 342054911606919171,
  "created_at" : "2013-06-04 23:10:59 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 31, 45 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 46, 58 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342053083200753664",
  "geo" : { },
  "id_str" : "342054962479640576",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 no specific reason @allthewayleft @TheBevForce",
  "id" : 342054962479640576,
  "in_reply_to_status_id" : 342053083200753664,
  "created_at" : "2013-06-04 23:07:12 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 86, 98 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 99, 113 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INFP",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342052631256109056",
  "geo" : { },
  "id_str" : "342054034833817604",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 iam #INFP (personality type) everything translates via  feeling for me..  @TheBevForce @allthewayleft",
  "id" : 342054034833817604,
  "in_reply_to_status_id" : 342052631256109056,
  "created_at" : "2013-06-04 23:03:31 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 55, 67 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 68, 82 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342052179764445187",
  "geo" : { },
  "id_str" : "342053434146574336",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 cool beans! my DD grad next year from MHS. @TheBevForce @allthewayleft",
  "id" : 342053434146574336,
  "in_reply_to_status_id" : 342052179764445187,
  "created_at" : "2013-06-04 23:01:08 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 29, 40 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 41, 53 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342052756556763136",
  "geo" : { },
  "id_str" : "342053154227093505",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft of everything @swalter718 @TheBevForce",
  "id" : 342053154227093505,
  "in_reply_to_status_id" : 342052756556763136,
  "created_at" : "2013-06-04 23:00:01 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 91, 102 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 103, 115 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342051690448564224",
  "geo" : { },
  "id_str" : "342052941693321216",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft we are all secondary source. i think Jesus existed.. a very \"evolved\" soul. @swalter718 @TheBevForce",
  "id" : 342052941693321216,
  "in_reply_to_status_id" : 342051690448564224,
  "created_at" : "2013-06-04 22:59:10 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 79, 90 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 91, 103 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342051930236932096",
  "geo" : { },
  "id_str" : "342052401609596928",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft math is very logical was my point. im not good w logic so much. @swalter718 @TheBevForce",
  "id" : 342052401609596928,
  "in_reply_to_status_id" : 342051930236932096,
  "created_at" : "2013-06-04 22:57:02 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 71, 83 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 84, 98 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342051304601960448",
  "geo" : { },
  "id_str" : "342051988801998849",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 it makes sense to me. there has to be an original source.. @TheBevForce @allthewayleft",
  "id" : 342051988801998849,
  "in_reply_to_status_id" : 342051304601960448,
  "created_at" : "2013-06-04 22:55:23 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 35, 47 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 48, 62 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342050970412408832",
  "geo" : { },
  "id_str" : "342051371136208896",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 math was my weakness.. @TheBevForce @allthewayleft",
  "id" : 342051371136208896,
  "in_reply_to_status_id" : 342050970412408832,
  "created_at" : "2013-06-04 22:52:56 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 80, 92 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 93, 107 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342049913527472129",
  "geo" : { },
  "id_str" : "342051004025565184",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 i believe there is a God (original source) .. i am barely christian @TheBevForce @allthewayleft",
  "id" : 342051004025565184,
  "in_reply_to_status_id" : 342049913527472129,
  "created_at" : "2013-06-04 22:51:29 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Walter",
      "screen_name" : "swalter718",
      "indices" : [ 0, 11 ],
      "id_str" : "19160340",
      "id" : 19160340
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 50, 62 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 63, 77 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342049913527472129",
  "geo" : { },
  "id_str" : "342050524876648449",
  "in_reply_to_user_id" : 19160340,
  "text" : "@swalter718 hmm.. well, i did barely graduate HS. @TheBevForce @allthewayleft",
  "id" : 342050524876648449,
  "in_reply_to_status_id" : 342049913527472129,
  "created_at" : "2013-06-04 22:49:34 +0000",
  "in_reply_to_screen_name" : "swalter718",
  "in_reply_to_user_id_str" : "19160340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 81, 93 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342048881409929218",
  "geo" : { },
  "id_str" : "342050035833376771",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft lol.. when i was young, DH came home to find JW in the house..lol @TheBevForce",
  "id" : 342050035833376771,
  "in_reply_to_status_id" : 342048881409929218,
  "created_at" : "2013-06-04 22:47:38 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blk~n~Infinite",
      "screen_name" : "BlkGodlessDick",
      "indices" : [ 0, 15 ],
      "id_str" : "454581448",
      "id" : 454581448
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 27, 41 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 42, 54 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342049175061536768",
  "geo" : { },
  "id_str" : "342049481388326912",
  "in_reply_to_user_id" : 454581448,
  "text" : "@BlkGodlessDick umm.. no.. @allthewayleft @TheBevForce",
  "id" : 342049481388326912,
  "in_reply_to_status_id" : 342049175061536768,
  "created_at" : "2013-06-04 22:45:25 +0000",
  "in_reply_to_screen_name" : "BlkGodlessDick",
  "in_reply_to_user_id_str" : "454581448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 55, 67 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342040323469484032",
  "geo" : { },
  "id_str" : "342048485278887936",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft lol.. have no use for such a bridge ; ) @TheBevForce",
  "id" : 342048485278887936,
  "in_reply_to_status_id" : 342040323469484032,
  "created_at" : "2013-06-04 22:41:28 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 65, 79 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342042977692180480",
  "geo" : { },
  "id_str" : "342048172073435136",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce cuz its in there sphere.. path of least resistance. @allthewayleft",
  "id" : 342048172073435136,
  "in_reply_to_status_id" : 342042977692180480,
  "created_at" : "2013-06-04 22:40:13 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 122, 134 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342045026148290562",
  "geo" : { },
  "id_str" : "342047339487305728",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft just God. he can be found via many, many paths. God is more abstract to me at this point. Original source. @TheBevForce",
  "id" : 342047339487305728,
  "in_reply_to_status_id" : 342045026148290562,
  "created_at" : "2013-06-04 22:36:55 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 0, 14 ],
      "id_str" : "345207173",
      "id" : 345207173
    }, {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 78, 90 ],
      "id_str" : "942491600",
      "id" : 942491600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342031038031216642",
  "geo" : { },
  "id_str" : "342037879452745728",
  "in_reply_to_user_id" : 345207173,
  "text" : "@allthewayleft its my own personal view from my life experience. no evidence. @TheBevForce",
  "id" : 342037879452745728,
  "in_reply_to_status_id" : 342031038031216642,
  "created_at" : "2013-06-04 21:59:19 +0000",
  "in_reply_to_screen_name" : "allthewayleft",
  "in_reply_to_user_id_str" : "345207173",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drama",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/HWlxx9vJ5h",
      "expanded_url" : "http:\/\/tinyurl.com\/8njgjr9",
      "display_url" : "tinyurl.com\/8njgjr9"
    } ]
  },
  "geo" : { },
  "id_str" : "342029085519785984",
  "text" : "RT @Soulseedzforall: Just because someone invites you to #drama, does not mean you have to RSVP. http:\/\/t.co\/HWlxx9vJ5h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "drama",
        "indices" : [ 36, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/HWlxx9vJ5h",
        "expanded_url" : "http:\/\/tinyurl.com\/8njgjr9",
        "display_url" : "tinyurl.com\/8njgjr9"
      } ]
    },
    "geo" : { },
    "id_str" : "342027402991517696",
    "text" : "Just because someone invites you to #drama, does not mean you have to RSVP. http:\/\/t.co\/HWlxx9vJ5h",
    "id" : 342027402991517696,
    "created_at" : "2013-06-04 21:17:42 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 342029085519785984,
  "created_at" : "2013-06-04 21:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "indices" : [ 3, 18 ],
      "id_str" : "44674382",
      "id" : 44674382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342028619234816002",
  "text" : "RT @ChrisCapparell: \"I am sad,\" they say. \"I am afraid,\" says another. Who stops to listen, is enacting the I AM, saying, \"I am strong,\" by\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "342018716663443456",
    "text" : "\"I am sad,\" they say. \"I am afraid,\" says another. Who stops to listen, is enacting the I AM, saying, \"I am strong,\" by helping the weak.",
    "id" : 342018716663443456,
    "created_at" : "2013-06-04 20:43:11 +0000",
    "user" : {
      "name" : "Little Christ-Bearer",
      "screen_name" : "ChrisCapparell",
      "protected" : false,
      "id_str" : "44674382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635948050633072642\/MFT0yTTa_normal.jpg",
      "id" : 44674382,
      "verified" : false
    }
  },
  "id" : 342028619234816002,
  "created_at" : "2013-06-04 21:22:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/KP73QSzZYc",
      "expanded_url" : "http:\/\/www.wattpad.com\/story\/6071239-peas-beans-&-corn-book-2-in-the-sovereign-series",
      "display_url" : "wattpad.com\/story\/6071239-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "342028297712058369",
  "text" : "RT @ChickenJen: Chapter One of \"Peas, Beans &amp; Corn\" is now available for a FREE download on your mobile device here http:\/\/t.co\/KP73QSzZYc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/KP73QSzZYc",
        "expanded_url" : "http:\/\/www.wattpad.com\/story\/6071239-peas-beans-&-corn-book-2-in-the-sovereign-series",
        "display_url" : "wattpad.com\/story\/6071239-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "342021714319900674",
    "text" : "Chapter One of \"Peas, Beans &amp; Corn\" is now available for a FREE download on your mobile device here http:\/\/t.co\/KP73QSzZYc",
    "id" : 342021714319900674,
    "created_at" : "2013-06-04 20:55:05 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 342028297712058369,
  "created_at" : "2013-06-04 21:21:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 30, 40 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    }, {
      "name" : "YeenStink",
      "screen_name" : "Bo0tleg",
      "indices" : [ 45, 53 ],
      "id_str" : "412834095",
      "id" : 412834095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOA",
      "indices" : [ 15, 19 ]
    }, {
      "text" : "karma",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342022149470552064",
  "geo" : { },
  "id_str" : "342028002978308096",
  "in_reply_to_user_id" : 412834095,
  "text" : "\"X\" begets \"X\" #LOA #karma RT @CubeMelon: RT @Bo0tleg Kindness begets kindness",
  "id" : 342028002978308096,
  "in_reply_to_status_id" : 342022149470552064,
  "created_at" : "2013-06-04 21:20:05 +0000",
  "in_reply_to_screen_name" : "Bo0tleg",
  "in_reply_to_user_id_str" : "412834095",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Benevolent Force",
      "screen_name" : "TheBevForce",
      "indices" : [ 0, 12 ],
      "id_str" : "942491600",
      "id" : 942491600
    }, {
      "name" : "theyfeltawall",
      "screen_name" : "allthewayleft",
      "indices" : [ 124, 138 ],
      "id_str" : "345207173",
      "id" : 345207173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341980681385172993",
  "geo" : { },
  "id_str" : "342027194165506048",
  "in_reply_to_user_id" : 942491600,
  "text" : "@TheBevForce i have no bones w atheists but I do when you tell me that. my household was religion neutral. i chose to seek. @allthewayleft",
  "id" : 342027194165506048,
  "in_reply_to_status_id" : 341980681385172993,
  "created_at" : "2013-06-04 21:16:52 +0000",
  "in_reply_to_screen_name" : "TheBevForce",
  "in_reply_to_user_id_str" : "942491600",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "342026364834172929",
  "text" : "\"The Great Divorce\" by C.S. Lewis is... awesome! ...mind-blowing! saw yet another perspective.. love it!",
  "id" : 342026364834172929,
  "created_at" : "2013-06-04 21:13:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 0, 12 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341669804706508801",
  "geo" : { },
  "id_str" : "341689480903815170",
  "in_reply_to_user_id" : 40560386,
  "text" : "@Buddhaworld you were listed 2x so i picked one. hope it was right one : )",
  "id" : 341689480903815170,
  "in_reply_to_status_id" : 341669804706508801,
  "created_at" : "2013-06-03 22:54:55 +0000",
  "in_reply_to_screen_name" : "Buddhaworld",
  "in_reply_to_user_id_str" : "40560386",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u15E9\u144C\u144ETi  C\u157C\u1587i\u1515T-i\u144EE \u2615",
      "screen_name" : "eppylover",
      "indices" : [ 3, 13 ],
      "id_str" : "54640029",
      "id" : 54640029
    }, {
      "name" : "Truthglow",
      "screen_name" : "truthglow",
      "indices" : [ 15, 25 ],
      "id_str" : "143115107",
      "id" : 143115107
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341619419430129664",
  "text" : "RT @eppylover: @truthglow Actually, I see #Obamacare as a step toward the eventual implementation of universal healthcare. It's GOT to happ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Truthglow",
        "screen_name" : "truthglow",
        "indices" : [ 0, 10 ],
        "id_str" : "143115107",
        "id" : 143115107
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 27, 37 ]
      }, {
        "text" : "singlepayer",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "341593516931166208",
    "geo" : { },
    "id_str" : "341595330351099905",
    "in_reply_to_user_id" : 143115107,
    "text" : "@truthglow Actually, I see #Obamacare as a step toward the eventual implementation of universal healthcare. It's GOT to happen. #singlepayer",
    "id" : 341595330351099905,
    "in_reply_to_status_id" : 341593516931166208,
    "created_at" : "2013-06-03 16:40:47 +0000",
    "in_reply_to_screen_name" : "truthglow",
    "in_reply_to_user_id_str" : "143115107",
    "user" : {
      "name" : "\u15E9\u144C\u144ETi  C\u157C\u1587i\u1515T-i\u144EE \u2615",
      "screen_name" : "eppylover",
      "protected" : false,
      "id_str" : "54640029",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796281558340603904\/Z_GDzNCW_normal.jpg",
      "id" : 54640029,
      "verified" : false
    }
  },
  "id" : 341619419430129664,
  "created_at" : "2013-06-03 18:16:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/H3S8tIz3sb",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/06\/03\/opinion\/ghitis-facebook-friend-dies\/index.html?sr=sharebar_twitter",
      "display_url" : "cnn.com\/2013\/06\/03\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341595087731560448",
  "text" : "\"Online we can develop a kind of intimacy that eluded us in the nonvirtual world.\" When a Facebook friend dies http:\/\/t.co\/H3S8tIz3sb",
  "id" : 341595087731560448,
  "created_at" : "2013-06-03 16:39:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341593192619188226",
  "geo" : { },
  "id_str" : "341593582924337154",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh no : (",
  "id" : 341593582924337154,
  "in_reply_to_status_id" : 341593192619188226,
  "created_at" : "2013-06-03 16:33:51 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindblowing",
      "screen_name" : "MindBlowing",
      "indices" : [ 3, 15 ],
      "id_str" : "488908367",
      "id" : 488908367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341579887305433089",
  "text" : "RT @MindBlowing: If you type \"illuminati\" backwards, followed by '.com' it takes you to the U.S. government's national security site.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.grabinbox.com\" rel=\"nofollow\"\u003EGrabInbox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341576541861474304",
    "text" : "If you type \"illuminati\" backwards, followed by '.com' it takes you to the U.S. government's national security site.",
    "id" : 341576541861474304,
    "created_at" : "2013-06-03 15:26:08 +0000",
    "user" : {
      "name" : "Mindblowing",
      "screen_name" : "MindBlowing",
      "protected" : false,
      "id_str" : "488908367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631327981999292416\/5FmHe2JF_normal.jpg",
      "id" : 488908367,
      "verified" : false
    }
  },
  "id" : 341579887305433089,
  "created_at" : "2013-06-03 15:39:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindblowing",
      "screen_name" : "MindBlowing",
      "indices" : [ 0, 12 ],
      "id_str" : "488908367",
      "id" : 488908367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341576541861474304",
  "geo" : { },
  "id_str" : "341579860621271040",
  "in_reply_to_user_id" : 488908367,
  "text" : "@MindBlowing wow.. that's really wierd! @Llimoner_",
  "id" : 341579860621271040,
  "in_reply_to_status_id" : 341576541861474304,
  "created_at" : "2013-06-03 15:39:19 +0000",
  "in_reply_to_screen_name" : "MindBlowing",
  "in_reply_to_user_id_str" : "488908367",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341345480460079104",
  "geo" : { },
  "id_str" : "341348685151625216",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth rub the belleh!! : )",
  "id" : 341348685151625216,
  "in_reply_to_status_id" : 341345480460079104,
  "created_at" : "2013-06-03 00:20:43 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341311845304512512",
  "text" : "RT @AllOnMedicare: The forms, phone calls and bureaucracy of private insurance exist so private insurance can exist. They do not need to ex\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341302780843151360",
    "text" : "The forms, phone calls and bureaucracy of private insurance exist so private insurance can exist. They do not need to exist. #SinglePayer",
    "id" : 341302780843151360,
    "created_at" : "2013-06-02 21:18:18 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 341311845304512512,
  "created_at" : "2013-06-02 21:54:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capt. S.J.Singh",
      "screen_name" : "surinderJsingh",
      "indices" : [ 3, 18 ],
      "id_str" : "49132710",
      "id" : 49132710
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341290079156846593",
  "text" : "RT @surinderJsingh: After freeing the mind from \u201Cthis is right and this not right\u201D, you would acquire an equal indifference to... http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/JZZUGftugd",
        "expanded_url" : "http:\/\/fb.me\/BGWUUkoo",
        "display_url" : "fb.me\/BGWUUkoo"
      } ]
    },
    "geo" : { },
    "id_str" : "341288924678868993",
    "text" : "After freeing the mind from \u201Cthis is right and this not right\u201D, you would acquire an equal indifference to... http:\/\/t.co\/JZZUGftugd",
    "id" : 341288924678868993,
    "created_at" : "2013-06-02 20:23:15 +0000",
    "user" : {
      "name" : "Capt. S.J.Singh",
      "screen_name" : "surinderJsingh",
      "protected" : false,
      "id_str" : "49132710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769362831758196736\/2oHXmCvi_normal.jpg",
      "id" : 49132710,
      "verified" : false
    }
  },
  "id" : 341290079156846593,
  "created_at" : "2013-06-02 20:27:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341289682157580288",
  "text" : "RT @AllOnMedicare: Private, big-profit insurance means a redistribution of wealth upwards towards insurance company executives. #SinglePaye\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 109, 121 ]
      }, {
        "text" : "p2",
        "indices" : [ 127, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341284936713641985",
    "text" : "Private, big-profit insurance means a redistribution of wealth upwards towards insurance company executives. #SinglePayer NOW! #p2",
    "id" : 341284936713641985,
    "created_at" : "2013-06-02 20:07:24 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 341289682157580288,
  "created_at" : "2013-06-02 20:26:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "indices" : [ 3, 19 ],
      "id_str" : "175204121",
      "id" : 175204121
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/341179913254096896\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/6Kbyb6Akgm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLwdUs-CYAAq9Mq.jpg",
      "id_str" : "341179913279266816",
      "id" : 341179913279266816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLwdUs-CYAAq9Mq.jpg",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6Kbyb6Akgm"
    } ],
    "hashtags" : [ {
      "text" : "gbb13",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341286603311951873",
  "text" : "RT @WildlifeGadgets: Never seen one of these before today. Looks so cuddly! A male Muslin Moth #gbb13 http:\/\/t.co\/6Kbyb6Akgm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WildlifeGadgets\/status\/341179913254096896\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/6Kbyb6Akgm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BLwdUs-CYAAq9Mq.jpg",
        "id_str" : "341179913279266816",
        "id" : 341179913279266816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLwdUs-CYAAq9Mq.jpg",
        "sizes" : [ {
          "h" : 702,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 823,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6Kbyb6Akgm"
      } ],
      "hashtags" : [ {
        "text" : "gbb13",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "341274185018003456",
    "text" : "Never seen one of these before today. Looks so cuddly! A male Muslin Moth #gbb13 http:\/\/t.co\/6Kbyb6Akgm",
    "id" : 341274185018003456,
    "created_at" : "2013-06-02 19:24:40 +0000",
    "user" : {
      "name" : "Wildlife Gadget Man",
      "screen_name" : "WildlifeGadgets",
      "protected" : false,
      "id_str" : "175204121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753213557060362240\/B1Sx5d_-_normal.jpg",
      "id" : 175204121,
      "verified" : false
    }
  },
  "id" : 341286603311951873,
  "created_at" : "2013-06-02 20:14:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 0, 12 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 85, 97 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341189691137208323",
  "geo" : { },
  "id_str" : "341224489004195840",
  "in_reply_to_user_id" : 229428507,
  "text" : "@Floridaline now that is a cool fact. i wonder what it would look like, feel like... @VirgoJohnny",
  "id" : 341224489004195840,
  "in_reply_to_status_id" : 341189691137208323,
  "created_at" : "2013-06-02 16:07:12 +0000",
  "in_reply_to_screen_name" : "Floridaline",
  "in_reply_to_user_id_str" : "229428507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/HAazFfahl3",
      "expanded_url" : "http:\/\/1.usa.gov\/10BjVGV",
      "display_url" : "1.usa.gov\/10BjVGV"
    } ]
  },
  "geo" : { },
  "id_str" : "341224229846523904",
  "text" : "RT @Floridaline: Matter within a neutron star is so dense a teaspoonful would weigh about a billion tons on Earth. http:\/\/t.co\/HAazFfahl3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/chrome.google.com\/webstore\/detail\/tweet-this-page\/ppilhaolhbpfembaoedfdbkegfedfgip\" rel=\"nofollow\"\u003ETweet-this-page\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/HAazFfahl3",
        "expanded_url" : "http:\/\/1.usa.gov\/10BjVGV",
        "display_url" : "1.usa.gov\/10BjVGV"
      } ]
    },
    "geo" : { },
    "id_str" : "341189691137208323",
    "text" : "Matter within a neutron star is so dense a teaspoonful would weigh about a billion tons on Earth. http:\/\/t.co\/HAazFfahl3",
    "id" : 341189691137208323,
    "created_at" : "2013-06-02 13:48:56 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 341224229846523904,
  "created_at" : "2013-06-02 16:06:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 95, 110 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341222548618498048",
  "geo" : { },
  "id_str" : "341223176631640064",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist ppl do that with all of life.. pick and choose what they accept into their life @AnnotatedBible",
  "id" : 341223176631640064,
  "in_reply_to_status_id" : 341222548618498048,
  "created_at" : "2013-06-02 16:01:59 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/AQCEVc2Fhp",
      "expanded_url" : "http:\/\/fb.me\/C9k6MLRT",
      "display_url" : "fb.me\/C9k6MLRT"
    } ]
  },
  "geo" : { },
  "id_str" : "341199881895022592",
  "text" : "RT @howtobesick: Canada goose and goslings http:\/\/t.co\/AQCEVc2Fhp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/AQCEVc2Fhp",
        "expanded_url" : "http:\/\/fb.me\/C9k6MLRT",
        "display_url" : "fb.me\/C9k6MLRT"
      } ]
    },
    "geo" : { },
    "id_str" : "341198256140861441",
    "text" : "Canada goose and goslings http:\/\/t.co\/AQCEVc2Fhp",
    "id" : 341198256140861441,
    "created_at" : "2013-06-02 14:22:58 +0000",
    "user" : {
      "name" : "Toni Bernhard",
      "screen_name" : "toni_bernhard",
      "protected" : false,
      "id_str" : "169982819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759869867449196544\/dEV7yImo_normal.jpg",
      "id" : 169982819,
      "verified" : false
    }
  },
  "id" : 341199881895022592,
  "created_at" : "2013-06-02 14:29:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341188593789837312",
  "geo" : { },
  "id_str" : "341196766529605632",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny well then..lol",
  "id" : 341196766529605632,
  "in_reply_to_status_id" : 341188593789837312,
  "created_at" : "2013-06-02 14:17:02 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/tvYu1xON6j",
      "expanded_url" : "http:\/\/amzn.to\/iS7QG4",
      "display_url" : "amzn.to\/iS7QG4"
    } ]
  },
  "geo" : { },
  "id_str" : "341033530693926912",
  "text" : "finished What the Dead Fear by Lea Ryan http:\/\/t.co\/tvYu1xON6j",
  "id" : 341033530693926912,
  "created_at" : "2013-06-02 03:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340978460275126274",
  "geo" : { },
  "id_str" : "340984478459641856",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time who's that mysterious beauty? ; )",
  "id" : 340984478459641856,
  "in_reply_to_status_id" : 340978460275126274,
  "created_at" : "2013-06-02 00:13:29 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340979555693105152",
  "geo" : { },
  "id_str" : "340984033066504192",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste wow...",
  "id" : 340984033066504192,
  "in_reply_to_status_id" : 340979555693105152,
  "created_at" : "2013-06-02 00:11:43 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "A.R.Karthick",
      "screen_name" : "arkarthick",
      "indices" : [ 28, 39 ],
      "id_str" : "15063178",
      "id" : 15063178
    }, {
      "name" : "Perspective Pics",
      "screen_name" : "Perspective_Pic",
      "indices" : [ 117, 133 ],
      "id_str" : "743200357430464512",
      "id" : 743200357430464512
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Perspective_pic\/status\/339483426862297088\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/d8S9Y95Ce6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLYWYMnCcAEToj8.jpg",
      "id_str" : "339483426870685697",
      "id" : 339483426870685697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLYWYMnCcAEToj8.jpg",
      "sizes" : [ {
        "h" : 579,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 579,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d8S9Y95Ce6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340969882986360833",
  "text" : "RT @KerriFar: LOVE this! RT @arkarthick: Sometimes, you just have to break the rules :) http:\/\/t.co\/d8S9Y95Ce6 | via @Perspective_pic RT @s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "A.R.Karthick",
        "screen_name" : "arkarthick",
        "indices" : [ 14, 25 ],
        "id_str" : "15063178",
        "id" : 15063178
      }, {
        "name" : "Perspective Pics",
        "screen_name" : "Perspective_Pic",
        "indices" : [ 103, 119 ],
        "id_str" : "743200357430464512",
        "id" : 743200357430464512
      }, {
        "name" : "fransiska damayanti",
        "screen_name" : "sien1975",
        "indices" : [ 123, 132 ],
        "id_str" : "160793314",
        "id" : 160793314
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Perspective_pic\/status\/339483426862297088\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/d8S9Y95Ce6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BLYWYMnCcAEToj8.jpg",
        "id_str" : "339483426870685697",
        "id" : 339483426870685697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLYWYMnCcAEToj8.jpg",
        "sizes" : [ {
          "h" : 579,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/d8S9Y95Ce6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340961875871268864",
    "text" : "LOVE this! RT @arkarthick: Sometimes, you just have to break the rules :) http:\/\/t.co\/d8S9Y95Ce6 | via @Perspective_pic RT @sien1975",
    "id" : 340961875871268864,
    "created_at" : "2013-06-01 22:43:40 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 340969882986360833,
  "created_at" : "2013-06-01 23:15:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OkTay Hacker",
      "screen_name" : "_Bruce_Lee",
      "indices" : [ 3, 14 ],
      "id_str" : "2857652085",
      "id" : 2857652085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340968919047225344",
  "text" : "RT @_Bruce_Lee: Certain people represent the \"you should\" - you SHOULD be this; you SHOULD change that. It's the crystallized SHOULD versus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340966473470197761",
    "text" : "Certain people represent the \"you should\" - you SHOULD be this; you SHOULD change that. It's the crystallized SHOULD versus what really IS.",
    "id" : 340966473470197761,
    "created_at" : "2013-06-01 23:01:56 +0000",
    "user" : {
      "name" : "Bruce Lee Tweets",
      "screen_name" : "BruceLeeTweets",
      "protected" : false,
      "id_str" : "348083461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762544718404263936\/pxHLbaTG_normal.jpg",
      "id" : 348083461,
      "verified" : false
    }
  },
  "id" : 340968919047225344,
  "created_at" : "2013-06-01 23:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340959827041853440",
  "text" : "RT @CoyoteSings: Looking for God is like looking for a star without any hint of what it might look like, or where it might be in the night \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "zen",
        "indices" : [ 127, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340954470353608704",
    "text" : "Looking for God is like looking for a star without any hint of what it might look like, or where it might be in the night sky. #zen",
    "id" : 340954470353608704,
    "created_at" : "2013-06-01 22:14:15 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 340959827041853440,
  "created_at" : "2013-06-01 22:35:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340947263293632512",
  "text" : "RT @CoyoteSings: We all act like lawyers trying to defend what we believe, instead of detectives looking for the clues of a hard to believe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340946829921374208",
    "text" : "We all act like lawyers trying to defend what we believe, instead of detectives looking for the clues of a hard to believe God.",
    "id" : 340946829921374208,
    "created_at" : "2013-06-01 21:43:53 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 340947263293632512,
  "created_at" : "2013-06-01 21:45:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340945165600555008",
  "text" : "@mattylong28 its not good to focus on hate anyway.",
  "id" : 340945165600555008,
  "created_at" : "2013-06-01 21:37:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340936189475430400",
  "geo" : { },
  "id_str" : "340943625632497664",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses he likes them standing up..lol.. adorable boy!",
  "id" : 340943625632497664,
  "in_reply_to_status_id" : 340936189475430400,
  "created_at" : "2013-06-01 21:31:09 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/4hEtfwojpd",
      "expanded_url" : "http:\/\/youtu.be\/fRNNzMZgrzs",
      "display_url" : "youtu.be\/fRNNzMZgrzs"
    } ]
  },
  "geo" : { },
  "id_str" : "340943428219183104",
  "text" : "RT @PeggySueCusses: Luiz Antonio: Why He Doesn't Want to Eat Octopus - Translated into English: http:\/\/t.co\/4hEtfwojpd super sweet boy YOU \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/4hEtfwojpd",
        "expanded_url" : "http:\/\/youtu.be\/fRNNzMZgrzs",
        "display_url" : "youtu.be\/fRNNzMZgrzs"
      } ]
    },
    "geo" : { },
    "id_str" : "340936189475430400",
    "text" : "Luiz Antonio: Why He Doesn't Want to Eat Octopus - Translated into English: http:\/\/t.co\/4hEtfwojpd super sweet boy YOU NEED TO SEE THIS",
    "id" : 340936189475430400,
    "created_at" : "2013-06-01 21:01:36 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 340943428219183104,
  "created_at" : "2013-06-01 21:30:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "indices" : [ 3, 19 ],
      "id_str" : "478216296",
      "id" : 478216296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340921367522320386",
  "text" : "RT @JesusWithIssues: I'm just going to start freebasing glory. I don't know what that means but it's got to be better than baking it into b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340918913749643264",
    "text" : "I'm just going to start freebasing glory. I don't know what that means but it's got to be better than baking it into brownies. Glory!",
    "id" : 340918913749643264,
    "created_at" : "2013-06-01 19:52:57 +0000",
    "user" : {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "protected" : false,
      "id_str" : "478216296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2229020646\/jesus_leopard_normal.jpg",
      "id" : 478216296,
      "verified" : false
    }
  },
  "id" : 340921367522320386,
  "created_at" : "2013-06-01 20:02:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 60, 75 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Cinnanun",
      "screen_name" : "notcreative388",
      "indices" : [ 76, 91 ],
      "id_str" : "272659909",
      "id" : 272659909
    }, {
      "name" : "OldSparky",
      "screen_name" : "EunoiaEuphoria",
      "indices" : [ 92, 107 ],
      "id_str" : "191414539",
      "id" : 191414539
    }, {
      "name" : "wesFargo",
      "screen_name" : "null_space",
      "indices" : [ 108, 119 ],
      "id_str" : "35664601",
      "id" : 35664601
    }, {
      "name" : "8-bit Atheist",
      "screen_name" : "8bitAtheist",
      "indices" : [ 120, 132 ],
      "id_str" : "3205504493",
      "id" : 3205504493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340909982738440193",
  "geo" : { },
  "id_str" : "340911058405453824",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist u mean me personally? i think Jesus existed. @AnnotatedBible @notcreative388 @EunoiaEuphoria @null_space @8bitAtheist",
  "id" : 340911058405453824,
  "in_reply_to_status_id" : 340909982738440193,
  "created_at" : "2013-06-01 19:21:44 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hungry Atheist",
      "screen_name" : "hungryatheist",
      "indices" : [ 0, 14 ],
      "id_str" : "1139919829",
      "id" : 1139919829
    }, {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 58, 73 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Cinnanun",
      "screen_name" : "notcreative388",
      "indices" : [ 74, 89 ],
      "id_str" : "272659909",
      "id" : 272659909
    }, {
      "name" : "OldSparky",
      "screen_name" : "EunoiaEuphoria",
      "indices" : [ 90, 105 ],
      "id_str" : "191414539",
      "id" : 191414539
    }, {
      "name" : "wesFargo",
      "screen_name" : "null_space",
      "indices" : [ 106, 117 ],
      "id_str" : "35664601",
      "id" : 35664601
    }, {
      "name" : "8-bit Atheist",
      "screen_name" : "8bitAtheist",
      "indices" : [ 118, 130 ],
      "id_str" : "3205504493",
      "id" : 3205504493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340885666974019586",
  "geo" : { },
  "id_str" : "340909650641842176",
  "in_reply_to_user_id" : 1139919829,
  "text" : "@hungryatheist afterlife is just reflection of who we are @AnnotatedBible @notcreative388 @EunoiaEuphoria @null_space @8bitAtheist",
  "id" : 340909650641842176,
  "in_reply_to_status_id" : 340885666974019586,
  "created_at" : "2013-06-01 19:16:09 +0000",
  "in_reply_to_screen_name" : "hungryatheist",
  "in_reply_to_user_id_str" : "1139919829",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]