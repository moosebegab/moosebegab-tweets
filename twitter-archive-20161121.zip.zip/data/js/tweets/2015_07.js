Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellie and Edmond\u00A9",
      "screen_name" : "EllieandEdmond",
      "indices" : [ 3, 18 ],
      "id_str" : "322763918",
      "id" : 322763918
    }, {
      "name" : "Poets Love Birds",
      "screen_name" : "PoetsLoveBirds",
      "indices" : [ 20, 35 ],
      "id_str" : "818814906",
      "id" : 818814906
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EllieandEdmond\/status\/627301303161626624\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/3KIrmXeUIa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLSfNPzWcAAyZFP.jpg",
      "id_str" : "627301298040369152",
      "id" : 627301298040369152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLSfNPzWcAAyZFP.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3KIrmXeUIa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627305451072409600",
  "text" : "RT @EllieandEdmond: @PoetsLoveBirds We are... We found this little bit today. http:\/\/t.co\/3KIrmXeUIa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Poets Love Birds",
        "screen_name" : "PoetsLoveBirds",
        "indices" : [ 0, 15 ],
        "id_str" : "818814906",
        "id" : 818814906
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EllieandEdmond\/status\/627301303161626624\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/3KIrmXeUIa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLSfNPzWcAAyZFP.jpg",
        "id_str" : "627301298040369152",
        "id" : 627301298040369152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLSfNPzWcAAyZFP.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3KIrmXeUIa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "627300481195446272",
    "geo" : { },
    "id_str" : "627301303161626624",
    "in_reply_to_user_id" : 818814906,
    "text" : "@PoetsLoveBirds We are... We found this little bit today. http:\/\/t.co\/3KIrmXeUIa",
    "id" : 627301303161626624,
    "in_reply_to_status_id" : 627300481195446272,
    "created_at" : "2015-08-01 02:14:20 +0000",
    "in_reply_to_screen_name" : "PoetsLoveBirds",
    "in_reply_to_user_id_str" : "818814906",
    "user" : {
      "name" : "Ellie and Edmond\u00A9",
      "screen_name" : "EllieandEdmond",
      "protected" : false,
      "id_str" : "322763918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793491793761427456\/wq9Pefua_normal.jpg",
      "id" : 322763918,
      "verified" : false
    }
  },
  "id" : 627305451072409600,
  "created_at" : "2015-08-01 02:30:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627293348433428480",
  "geo" : { },
  "id_str" : "627298922160082944",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH hope tomorrow's a better day for you, ani-la.",
  "id" : 627298922160082944,
  "in_reply_to_status_id" : 627293348433428480,
  "created_at" : "2015-08-01 02:04:52 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "teamStripe",
      "screen_name" : "teamStripe",
      "indices" : [ 13, 24 ],
      "id_str" : "2938475619",
      "id" : 2938475619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627290624123895808",
  "geo" : { },
  "id_str" : "627291447805517824",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley @TeamStripe oh my... :D",
  "id" : 627291447805517824,
  "in_reply_to_status_id" : 627290624123895808,
  "created_at" : "2015-08-01 01:35:10 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wes Hohenstein",
      "screen_name" : "WeatherWes",
      "indices" : [ 3, 14 ],
      "id_str" : "19739695",
      "id" : 19739695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627282605864566784",
  "text" : "RT @WeatherWes: SPACE STATION flying overhead tonight starting at 9:24p. Little white dot crossing the sky for 6 min from SW to NE. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialnewsdesk.com\" rel=\"nofollow\"\u003ESocialNewsDesk\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WeatherWes\/status\/627258649799299072\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/yBjkvhktVy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLR4axUVEAEkdUl.png",
        "id_str" : "627258649421877249",
        "id" : 627258649421877249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLR4axUVEAEkdUl.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/yBjkvhktVy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627258649799299072",
    "text" : "SPACE STATION flying overhead tonight starting at 9:24p. Little white dot crossing the sky for 6 min from SW to NE. http:\/\/t.co\/yBjkvhktVy",
    "id" : 627258649799299072,
    "created_at" : "2015-07-31 23:24:50 +0000",
    "user" : {
      "name" : "Wes Hohenstein",
      "screen_name" : "WeatherWes",
      "protected" : false,
      "id_str" : "19739695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703381110617726976\/cZyhNXI6_normal.jpg",
      "id" : 19739695,
      "verified" : true
    }
  },
  "id" : 627282605864566784,
  "created_at" : "2015-08-01 01:00:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren \uD83C\uDF83\uD83C\uDF41\uD83C\uDF42\uD83D\uDD78\uD83D\uDD77\uD83D\uDC7B",
      "screen_name" : "LaurenDeStefano",
      "indices" : [ 3, 19 ],
      "id_str" : "16144298",
      "id" : 16144298
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LaurenDeStefano\/status\/627149146923921408\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/iBGML2VjJh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLQU04SWIAAfBX9.jpg",
      "id_str" : "627149146806427648",
      "id" : 627149146806427648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLQU04SWIAAfBX9.jpg",
      "sizes" : [ {
        "h" : 1113,
        "resize" : "fit",
        "w" : 835
      }, {
        "h" : 1113,
        "resize" : "fit",
        "w" : 835
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iBGML2VjJh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627261156563009536",
  "text" : "RT @LaurenDeStefano: RT by 8\/7 to win this $50 B&amp;N gift card. I'd hurry because Cecil is eyeing it pretty hard. http:\/\/t.co\/iBGML2VjJh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaurenDeStefano\/status\/627149146923921408\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/iBGML2VjJh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLQU04SWIAAfBX9.jpg",
        "id_str" : "627149146806427648",
        "id" : 627149146806427648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLQU04SWIAAfBX9.jpg",
        "sizes" : [ {
          "h" : 1113,
          "resize" : "fit",
          "w" : 835
        }, {
          "h" : 1113,
          "resize" : "fit",
          "w" : 835
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iBGML2VjJh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627149146923921408",
    "text" : "RT by 8\/7 to win this $50 B&amp;N gift card. I'd hurry because Cecil is eyeing it pretty hard. http:\/\/t.co\/iBGML2VjJh",
    "id" : 627149146923921408,
    "created_at" : "2015-07-31 16:09:43 +0000",
    "user" : {
      "name" : "Lauren \uD83C\uDF83\uD83C\uDF41\uD83C\uDF42\uD83D\uDD78\uD83D\uDD77\uD83D\uDC7B",
      "screen_name" : "LaurenDeStefano",
      "protected" : false,
      "id_str" : "16144298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768823537083813888\/OS1PMYSx_normal.jpg",
      "id" : 16144298,
      "verified" : true
    }
  },
  "id" : 627261156563009536,
  "created_at" : "2015-07-31 23:34:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Cumbria",
      "screen_name" : "BBC_Cumbria",
      "indices" : [ 3, 15 ],
      "id_str" : "21860391",
      "id" : 21860391
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BBC_Cumbria\/status\/627076818756046849\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/NjPQwWiv97",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLPTCcdWgAEJKet.jpg",
      "id_str" : "627076812087132161",
      "id" : 627076812087132161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLPTCcdWgAEJKet.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 473
      } ],
      "display_url" : "pic.twitter.com\/NjPQwWiv97"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627166676379942912",
  "text" : "RT @BBC_Cumbria: Rebellious sheep spotted at Ullswater by Jennifer Walker. http:\/\/t.co\/NjPQwWiv97",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BBC_Cumbria\/status\/627076818756046849\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/NjPQwWiv97",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLPTCcdWgAEJKet.jpg",
        "id_str" : "627076812087132161",
        "id" : 627076812087132161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLPTCcdWgAEJKet.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 473
        } ],
        "display_url" : "pic.twitter.com\/NjPQwWiv97"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627076818756046849",
    "text" : "Rebellious sheep spotted at Ullswater by Jennifer Walker. http:\/\/t.co\/NjPQwWiv97",
    "id" : 627076818756046849,
    "created_at" : "2015-07-31 11:22:18 +0000",
    "user" : {
      "name" : "BBC Cumbria",
      "screen_name" : "BBC_Cumbria",
      "protected" : false,
      "id_str" : "21860391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637212040529084417\/fZxjjR0S_normal.jpg",
      "id" : 21860391,
      "verified" : true
    }
  },
  "id" : 627166676379942912,
  "created_at" : "2015-07-31 17:19:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Varla",
      "screen_name" : "GelasticGoGo",
      "indices" : [ 3, 16 ],
      "id_str" : "2970132749",
      "id" : 2970132749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627166506175057920",
  "text" : "RT @GelasticGoGo: Telling someone with anxiety that things aren't really that scary is like telling someone with asthma that breathing isn'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626330021402054657",
    "text" : "Telling someone with anxiety that things aren't really that scary is like telling someone with asthma that breathing isn't really that hard.",
    "id" : 626330021402054657,
    "created_at" : "2015-07-29 09:54:48 +0000",
    "user" : {
      "name" : "Varla",
      "screen_name" : "GelasticGoGo",
      "protected" : false,
      "id_str" : "2970132749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661113053287743488\/pWhAywz8_normal.jpg",
      "id" : 2970132749,
      "verified" : false
    }
  },
  "id" : 627166506175057920,
  "created_at" : "2015-07-31 17:18:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "indices" : [ 3, 16 ],
      "id_str" : "2238041838",
      "id" : 2238041838
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/627130709820473344\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/nnafY69K1q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLQDxRnWIAAli_K.jpg",
      "id_str" : "627130393188245504",
      "id" : 627130393188245504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLQDxRnWIAAli_K.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nnafY69K1q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627165508702498817",
  "text" : "RT @1CatShepherd: Oh suffering succotash another lamby kiss http:\/\/t.co\/nnafY69K1q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/1CatShepherd\/status\/627130709820473344\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/nnafY69K1q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLQDxRnWIAAli_K.jpg",
        "id_str" : "627130393188245504",
        "id" : 627130393188245504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLQDxRnWIAAli_K.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nnafY69K1q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627130709820473344",
    "text" : "Oh suffering succotash another lamby kiss http:\/\/t.co\/nnafY69K1q",
    "id" : 627130709820473344,
    "created_at" : "2015-07-31 14:56:27 +0000",
    "user" : {
      "name" : "Cat Shepherd",
      "screen_name" : "1CatShepherd",
      "protected" : false,
      "id_str" : "2238041838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000851412380\/5493a261c3fb708d615720168caa53b2_normal.png",
      "id" : 2238041838,
      "verified" : false
    }
  },
  "id" : 627165508702498817,
  "created_at" : "2015-07-31 17:14:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaylyn Ettinger",
      "screen_name" : "JaylynEttinger",
      "indices" : [ 3, 18 ],
      "id_str" : "393171004",
      "id" : 393171004
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JaylynEttinger\/status\/626980498456354816\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/9pgcJuE8W6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLN7cMRWEAAGrfk.jpg",
      "id_str" : "626980497395159040",
      "id" : 626980497395159040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLN7cMRWEAAGrfk.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/9pgcJuE8W6"
    } ],
    "hashtags" : [ {
      "text" : "highlandcattle",
      "indices" : [ 32, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627121025864585216",
  "text" : "RT @JaylynEttinger: Milk faces. #highlandcattle http:\/\/t.co\/9pgcJuE8W6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JaylynEttinger\/status\/626980498456354816\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/9pgcJuE8W6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLN7cMRWEAAGrfk.jpg",
        "id_str" : "626980497395159040",
        "id" : 626980497395159040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLN7cMRWEAAGrfk.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/9pgcJuE8W6"
      } ],
      "hashtags" : [ {
        "text" : "highlandcattle",
        "indices" : [ 12, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626980498456354816",
    "text" : "Milk faces. #highlandcattle http:\/\/t.co\/9pgcJuE8W6",
    "id" : 626980498456354816,
    "created_at" : "2015-07-31 04:59:34 +0000",
    "user" : {
      "name" : "Jaylyn Ettinger",
      "screen_name" : "JaylynEttinger",
      "protected" : false,
      "id_str" : "393171004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659842808619008002\/ije1xcE2_normal.jpg",
      "id" : 393171004,
      "verified" : false
    }
  },
  "id" : 627121025864585216,
  "created_at" : "2015-07-31 14:17:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626926087323389952",
  "text" : "RT @Library4birds: I call this the 'I've been shelving books for 8 hours' face. I have sung the ABC song approx 500 million times. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/626923919333789696\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/RZBze1iWKe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLNH-24UcAAwKtY.jpg",
        "id_str" : "626923918343827456",
        "id" : 626923918343827456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLNH-24UcAAwKtY.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/RZBze1iWKe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626923919333789696",
    "text" : "I call this the 'I've been shelving books for 8 hours' face. I have sung the ABC song approx 500 million times. http:\/\/t.co\/RZBze1iWKe",
    "id" : 626923919333789696,
    "created_at" : "2015-07-31 01:14:44 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 626926087323389952,
  "created_at" : "2015-07-31 01:23:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PhoenixRising",
      "screen_name" : "nicratwoman",
      "indices" : [ 3, 15 ],
      "id_str" : "483345369",
      "id" : 483345369
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nicratwoman\/status\/626903178383073280\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QxTc0AvZdv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLM1HlMUkAAN8kV.jpg",
      "id_str" : "626903177493778432",
      "id" : 626903177493778432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLM1HlMUkAAN8kV.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QxTc0AvZdv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626904137251332096",
  "text" : "RT @nicratwoman: \u201CA bend in the road is not the end of the road\u2026Unless you fail to make the turn.\u201D \n\u2015 Helen Keller http:\/\/t.co\/QxTc0AvZdv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nicratwoman\/status\/626903178383073280\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/QxTc0AvZdv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLM1HlMUkAAN8kV.jpg",
        "id_str" : "626903177493778432",
        "id" : 626903177493778432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLM1HlMUkAAN8kV.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QxTc0AvZdv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626903178383073280",
    "text" : "\u201CA bend in the road is not the end of the road\u2026Unless you fail to make the turn.\u201D \n\u2015 Helen Keller http:\/\/t.co\/QxTc0AvZdv",
    "id" : 626903178383073280,
    "created_at" : "2015-07-30 23:52:19 +0000",
    "user" : {
      "name" : "PhoenixRising",
      "screen_name" : "nicratwoman",
      "protected" : false,
      "id_str" : "483345369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429467389269250048\/Nj8BiX9f_normal.jpeg",
      "id" : 483345369,
      "verified" : false
    }
  },
  "id" : 626904137251332096,
  "created_at" : "2015-07-30 23:56:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anarcho-Emergency",
      "screen_name" : "anarchoanimal",
      "indices" : [ 3, 17 ],
      "id_str" : "3228467263",
      "id" : 3228467263
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/anarchoanimal\/status\/626869923411832835\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/8CttlliVYE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLMW34lWEAA2XRW.jpg",
      "id_str" : "626869922472267776",
      "id" : 626869922472267776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLMW34lWEAA2XRW.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 350
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 350
      } ],
      "display_url" : "pic.twitter.com\/8CttlliVYE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626882766962053120",
  "text" : "RT @anarchoanimal: http:\/\/t.co\/8CttlliVYE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/anarchoanimal\/status\/626869923411832835\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/8CttlliVYE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLMW34lWEAA2XRW.jpg",
        "id_str" : "626869922472267776",
        "id" : 626869922472267776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLMW34lWEAA2XRW.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/8CttlliVYE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626869923411832835",
    "text" : "http:\/\/t.co\/8CttlliVYE",
    "id" : 626869923411832835,
    "created_at" : "2015-07-30 21:40:11 +0000",
    "user" : {
      "name" : "Anarcho-Emergency",
      "screen_name" : "anarchoanimal",
      "protected" : false,
      "id_str" : "3228467263",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625432851039715328\/aimo6KdF_normal.jpg",
      "id" : 3228467263,
      "verified" : false
    }
  },
  "id" : 626882766962053120,
  "created_at" : "2015-07-30 22:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Delaware State Fair",
      "screen_name" : "DelStateFair",
      "indices" : [ 41, 54 ],
      "id_str" : "64173297",
      "id" : 64173297
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/626881208094330882\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/sbg9VdeJ9F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLMhICwVAAAWT9p.jpg",
      "id_str" : "626881195196874752",
      "id" : 626881195196874752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLMhICwVAAAWT9p.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/sbg9VdeJ9F"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/626881208094330882\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/sbg9VdeJ9F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLMhIErUEAAYWNG.jpg",
      "id_str" : "626881195712712704",
      "id" : 626881195712712704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLMhIErUEAAYWNG.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sbg9VdeJ9F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626882667187949568",
  "text" : "RT @ErinEFarley: Cross stitch to die for @DelStateFair. I missed taking photos of some stunning ones. http:\/\/t.co\/sbg9VdeJ9F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Delaware State Fair",
        "screen_name" : "DelStateFair",
        "indices" : [ 24, 37 ],
        "id_str" : "64173297",
        "id" : 64173297
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/626881208094330882\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/sbg9VdeJ9F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLMhICwVAAAWT9p.jpg",
        "id_str" : "626881195196874752",
        "id" : 626881195196874752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLMhICwVAAAWT9p.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sbg9VdeJ9F"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/626881208094330882\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/sbg9VdeJ9F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLMhIErUEAAYWNG.jpg",
        "id_str" : "626881195712712704",
        "id" : 626881195712712704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLMhIErUEAAYWNG.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/sbg9VdeJ9F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "626880776781467648",
    "geo" : { },
    "id_str" : "626881208094330882",
    "in_reply_to_user_id" : 1305052615,
    "text" : "Cross stitch to die for @DelStateFair. I missed taking photos of some stunning ones. http:\/\/t.co\/sbg9VdeJ9F",
    "id" : 626881208094330882,
    "in_reply_to_status_id" : 626880776781467648,
    "created_at" : "2015-07-30 22:25:01 +0000",
    "in_reply_to_screen_name" : "ErinEFarley",
    "in_reply_to_user_id_str" : "1305052615",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 626882667187949568,
  "created_at" : "2015-07-30 22:30:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 83, 88 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626862601918619650",
  "text" : "DD has been downstairs drawing on her laptop for a few hours today.. I'll take it! #sick #thyroid",
  "id" : 626862601918619650,
  "created_at" : "2015-07-30 21:11:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenSanders\/status\/626751768140083204\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/77lyLaqRy7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLKrO3yVAAAyPmT.jpg",
      "id_str" : "626751570139480064",
      "id" : 626751570139480064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLKrO3yVAAAyPmT.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/77lyLaqRy7"
    } ],
    "hashtags" : [ {
      "text" : "Medicare4All",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626861952749408257",
  "text" : "RT @SenSanders: Health care is a right for all people not a privilege. -Sen. Sanders #Medicare4All http:\/\/t.co\/77lyLaqRy7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSanders\/status\/626751768140083204\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/77lyLaqRy7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLKrO3yVAAAyPmT.jpg",
        "id_str" : "626751570139480064",
        "id" : 626751570139480064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLKrO3yVAAAyPmT.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/77lyLaqRy7"
      } ],
      "hashtags" : [ {
        "text" : "Medicare4All",
        "indices" : [ 69, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626751768140083204",
    "text" : "Health care is a right for all people not a privilege. -Sen. Sanders #Medicare4All http:\/\/t.co\/77lyLaqRy7",
    "id" : 626751768140083204,
    "created_at" : "2015-07-30 13:50:40 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 626861952749408257,
  "created_at" : "2015-07-30 21:08:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "indices" : [ 3, 15 ],
      "id_str" : "629225037",
      "id" : 629225037
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/626836861286248448\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/pjTL6GWvlw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLL4ymyWIAAZlsB.jpg",
      "id_str" : "626836846446780416",
      "id" : 626836846446780416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLL4ymyWIAAZlsB.jpg",
      "sizes" : [ {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pjTL6GWvlw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626837939578867712",
  "text" : "RT @AndyBoxHill: Golden hour. Amazing light as the sun is going down. Looks fantastic. \uD83D\uDE0A http:\/\/t.co\/pjTL6GWvlw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/626836861286248448\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/pjTL6GWvlw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLL4ymyWIAAZlsB.jpg",
        "id_str" : "626836846446780416",
        "id" : 626836846446780416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLL4ymyWIAAZlsB.jpg",
        "sizes" : [ {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 741,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 741,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pjTL6GWvlw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626836861286248448",
    "text" : "Golden hour. Amazing light as the sun is going down. Looks fantastic. \uD83D\uDE0A http:\/\/t.co\/pjTL6GWvlw",
    "id" : 626836861286248448,
    "created_at" : "2015-07-30 19:28:48 +0000",
    "user" : {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "protected" : false,
      "id_str" : "629225037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543479254550593536\/nw_rTozc_normal.jpeg",
      "id" : 629225037,
      "verified" : false
    }
  },
  "id" : 626837939578867712,
  "created_at" : "2015-07-30 19:33:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626830549869441024",
  "geo" : { },
  "id_str" : "626835156846911489",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides asking for a friend working on a paper.. not for you with the secret lab, right? ; )",
  "id" : 626835156846911489,
  "in_reply_to_status_id" : 626830549869441024,
  "created_at" : "2015-07-30 19:22:02 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Opera",
      "screen_name" : "opera",
      "indices" : [ 6, 12 ],
      "id_str" : "1541461",
      "id" : 1541461
    }, {
      "name" : "Windows Central",
      "screen_name" : "windowscentral",
      "indices" : [ 17, 32 ],
      "id_str" : "14208474",
      "id" : 14208474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OperaFTW",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "Windows10",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Mrrq7kJFQm",
      "expanded_url" : "https:\/\/wn.nr\/vNXTj",
      "display_url" : "wn.nr\/vNXTj"
    } ]
  },
  "geo" : { },
  "id_str" : "626828556618723328",
  "text" : "Enter @Opera and @WindowsCentral #OperaFTW giveaway for a chance to win some new #Windows10 devices! https:\/\/t.co\/Mrrq7kJFQm",
  "id" : 626828556618723328,
  "created_at" : "2015-07-30 18:55:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626794089258872832",
  "text" : "ohh.. yeah.. it was about spreadsheets. im U\/L to google sheets from OpenOfficeCalc to get them to print landscape on 1 pg. weird, huh?",
  "id" : 626794089258872832,
  "created_at" : "2015-07-30 16:38:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/zSV94WSstS",
      "expanded_url" : "http:\/\/bit.ly\/1IeCeTA",
      "display_url" : "bit.ly\/1IeCeTA"
    } ]
  },
  "geo" : { },
  "id_str" : "626793133251166208",
  "text" : "RT @jonlieffmd: Living creatures communicate, but it has been surprising to find individual cells do as well. http:\/\/t.co\/zSV94WSstS http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jonlieffmd\/status\/626792066593488896\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/DTwVAWqNAG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLLQEEiW8AAg0NU.png",
        "id_str" : "626792066513825792",
        "id" : 626792066513825792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLLQEEiW8AAg0NU.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/DTwVAWqNAG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/zSV94WSstS",
        "expanded_url" : "http:\/\/bit.ly\/1IeCeTA",
        "display_url" : "bit.ly\/1IeCeTA"
      } ]
    },
    "geo" : { },
    "id_str" : "626792066593488896",
    "text" : "Living creatures communicate, but it has been surprising to find individual cells do as well. http:\/\/t.co\/zSV94WSstS http:\/\/t.co\/DTwVAWqNAG",
    "id" : 626792066593488896,
    "created_at" : "2015-07-30 16:30:48 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 626793133251166208,
  "created_at" : "2015-07-30 16:35:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626792827104706561",
  "text" : "I came here to tell you something.. and now I forgot what it was.. o-O",
  "id" : 626792827104706561,
  "created_at" : "2015-07-30 16:33:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626770992237514752",
  "geo" : { },
  "id_str" : "626775139934453761",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe : ((",
  "id" : 626775139934453761,
  "in_reply_to_status_id" : 626770992237514752,
  "created_at" : "2015-07-30 15:23:32 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626767874288427008",
  "geo" : { },
  "id_str" : "626771493507211264",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides wow, thats cool! : )",
  "id" : 626771493507211264,
  "in_reply_to_status_id" : 626767874288427008,
  "created_at" : "2015-07-30 15:09:03 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626761776391176194",
  "geo" : { },
  "id_str" : "626771305837129728",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields well you're good at reminding me and I appreciate that. sometimes I get pulled too far into the dark..lol.",
  "id" : 626771305837129728,
  "in_reply_to_status_id" : 626761776391176194,
  "created_at" : "2015-07-30 15:08:18 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/izpHRIVH0n",
      "expanded_url" : "http:\/\/tmblr.co\/Zp3-jx1qqOEdv",
      "display_url" : "tmblr.co\/Zp3-jx1qqOEdv"
    } ]
  },
  "geo" : { },
  "id_str" : "626767559761764352",
  "text" : "Photo: thebuddhistspoonie: I hope this changes your life like it has mine. http:\/\/t.co\/izpHRIVH0n",
  "id" : 626767559761764352,
  "created_at" : "2015-07-30 14:53:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626758529605632000",
  "geo" : { },
  "id_str" : "626761461789016064",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields the post about it was funny. I prob should have added a comment to it. thx 4 keeping me straight. : )",
  "id" : 626761461789016064,
  "in_reply_to_status_id" : 626758529605632000,
  "created_at" : "2015-07-30 14:29:11 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/e2bfxcrhAc",
      "expanded_url" : "https:\/\/shar.es\/1sT697",
      "display_url" : "shar.es\/1sT697"
    } ]
  },
  "geo" : { },
  "id_str" : "626756351167983616",
  "text" : "Charisma Mag: Donald Trump Is The New Word of God https:\/\/t.co\/e2bfxcrhAc",
  "id" : 626756351167983616,
  "created_at" : "2015-07-30 14:08:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626753232182751232",
  "text" : "very proud of my spreadsheet work. did not get response I was looking for when showing DH, DD. blah.",
  "id" : 626753232182751232,
  "created_at" : "2015-07-30 13:56:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626582101337448448",
  "geo" : { },
  "id_str" : "626585880162140160",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms I know I loved yr tweets about compassion and empathy. &lt;3",
  "id" : 626585880162140160,
  "in_reply_to_status_id" : 626582101337448448,
  "created_at" : "2015-07-30 02:51:29 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626582101337448448",
  "geo" : { },
  "id_str" : "626585135580848129",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms hmm.. maybe. I could check my twitter archive..lol.",
  "id" : 626585135580848129,
  "in_reply_to_status_id" : 626582101337448448,
  "created_at" : "2015-07-30 02:48:32 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626486947192676352",
  "geo" : { },
  "id_str" : "626583558602248192",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe I feel ya.. DD is same way.",
  "id" : 626583558602248192,
  "in_reply_to_status_id" : 626486947192676352,
  "created_at" : "2015-07-30 02:42:16 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626572530745245697",
  "geo" : { },
  "id_str" : "626581663909285888",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms hope treatments work for you ((hugs))",
  "id" : 626581663909285888,
  "in_reply_to_status_id" : 626572530745245697,
  "created_at" : "2015-07-30 02:34:44 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spreadsheets",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626436999768055808",
  "text" : "im kind of enjoying fooling around w #spreadsheets brings back the days when working w database.",
  "id" : 626436999768055808,
  "created_at" : "2015-07-29 16:59:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Hart",
      "screen_name" : "AuthorJoeHart",
      "indices" : [ 3, 17 ],
      "id_str" : "431098635",
      "id" : 431098635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626408394136666112",
  "text" : "RT @AuthorJoeHart: Life is hard. Doesn't matter who you are. Always be kind as a first resort, not a last.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625815456243290112",
    "text" : "Life is hard. Doesn't matter who you are. Always be kind as a first resort, not a last.",
    "id" : 625815456243290112,
    "created_at" : "2015-07-27 23:50:06 +0000",
    "user" : {
      "name" : "Joe Hart",
      "screen_name" : "AuthorJoeHart",
      "protected" : false,
      "id_str" : "431098635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780864133969293312\/hhOf02AN_normal.jpg",
      "id" : 431098635,
      "verified" : false
    }
  },
  "id" : 626408394136666112,
  "created_at" : "2015-07-29 15:06:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/7pw4Dv1Mqx",
      "expanded_url" : "https:\/\/twitter.com\/stanford\/status\/626159315867561986",
      "display_url" : "twitter.com\/stanford\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626407672737333248",
  "text" : "RT @AlisynGayle: Ya think? Any chance they make more $ from selling deadly drugs than they pay out in lawsuits? https:\/\/t.co\/7pw4Dv1Mqx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/7pw4Dv1Mqx",
        "expanded_url" : "https:\/\/twitter.com\/stanford\/status\/626159315867561986",
        "display_url" : "twitter.com\/stanford\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626251030553067520",
    "text" : "Ya think? Any chance they make more $ from selling deadly drugs than they pay out in lawsuits? https:\/\/t.co\/7pw4Dv1Mqx",
    "id" : 626251030553067520,
    "created_at" : "2015-07-29 04:40:55 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 626407672737333248,
  "created_at" : "2015-07-29 15:03:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626234725707837441",
  "geo" : { },
  "id_str" : "626405041117773824",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time the same.. shes taking 1\/2 levo for now maybe that will help. the 25mg might have been too high for her to adjust. thx 4 asking!",
  "id" : 626405041117773824,
  "in_reply_to_status_id" : 626234725707837441,
  "created_at" : "2015-07-29 14:52:54 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andy gill",
      "screen_name" : "itsandygill",
      "indices" : [ 3, 15 ],
      "id_str" : "235706649",
      "id" : 235706649
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/itsandygill\/status\/626208322761306112\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/z3ZiNei9eh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLC9Jq8WwAEBk8v.png",
      "id_str" : "626208322048409601",
      "id" : 626208322048409601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLC9Jq8WwAEBk8v.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 1865
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z3ZiNei9eh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/nM7ItwWjUY",
      "expanded_url" : "http:\/\/andygill.org\/is-premarital-sex-sinful\/",
      "display_url" : "andygill.org\/is-premarital-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626211442149228544",
  "text" : "RT @itsandygill: IS PREMARITAL SEX SINFUL...? | http:\/\/t.co\/nM7ItwWjUY http:\/\/t.co\/z3ZiNei9eh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/itsandygill\/status\/626208322761306112\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/z3ZiNei9eh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLC9Jq8WwAEBk8v.png",
        "id_str" : "626208322048409601",
        "id" : 626208322048409601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLC9Jq8WwAEBk8v.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 1865
        }, {
          "h" : 155,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/z3ZiNei9eh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/nM7ItwWjUY",
        "expanded_url" : "http:\/\/andygill.org\/is-premarital-sex-sinful\/",
        "display_url" : "andygill.org\/is-premarital-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "626208322761306112",
    "text" : "IS PREMARITAL SEX SINFUL...? | http:\/\/t.co\/nM7ItwWjUY http:\/\/t.co\/z3ZiNei9eh",
    "id" : 626208322761306112,
    "created_at" : "2015-07-29 01:51:13 +0000",
    "user" : {
      "name" : "andy gill",
      "screen_name" : "itsandygill",
      "protected" : false,
      "id_str" : "235706649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772098500318363648\/QaO430H8_normal.jpg",
      "id" : 235706649,
      "verified" : false
    }
  },
  "id" : 626211442149228544,
  "created_at" : "2015-07-29 02:03:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626205101905022976",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley omgness.. I love it so adorable!",
  "id" : 626205101905022976,
  "created_at" : "2015-07-29 01:38:25 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JohnBlueTruffleMedia",
      "screen_name" : "TruffleMedia",
      "indices" : [ 3, 16 ],
      "id_str" : "988911",
      "id" : 988911
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 32, 44 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Michele Walfred",
      "screen_name" : "MWalfred",
      "indices" : [ 99, 108 ],
      "id_str" : "2192473280",
      "id" : 2192473280
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TruffleMedia\/status\/626188992808157184\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/TJo3wewWvM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLCrgtuUwAA-g-9.png",
      "id_str" : "626188926722555904",
      "id" : 626188926722555904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLCrgtuUwAA-g-9.png",
      "sizes" : [ {
        "h" : 361,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TJo3wewWvM"
    } ],
    "hashtags" : [ {
      "text" : "agchat",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626204932274847744",
  "text" : "RT @TruffleMedia: LOL, love the @ErinEFarley knit character animals on your Twitter banner #agchat @MWalfred http:\/\/t.co\/TJo3wewWvM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 14, 26 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      }, {
        "name" : "Michele Walfred",
        "screen_name" : "MWalfred",
        "indices" : [ 81, 90 ],
        "id_str" : "2192473280",
        "id" : 2192473280
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TruffleMedia\/status\/626188992808157184\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/TJo3wewWvM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLCrgtuUwAA-g-9.png",
        "id_str" : "626188926722555904",
        "id" : 626188926722555904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLCrgtuUwAA-g-9.png",
        "sizes" : [ {
          "h" : 361,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 120,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 1210
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TJo3wewWvM"
      } ],
      "hashtags" : [ {
        "text" : "agchat",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "626187878360580096",
    "geo" : { },
    "id_str" : "626188992808157184",
    "in_reply_to_user_id" : 2192473280,
    "text" : "LOL, love the @ErinEFarley knit character animals on your Twitter banner #agchat @MWalfred http:\/\/t.co\/TJo3wewWvM",
    "id" : 626188992808157184,
    "in_reply_to_status_id" : 626187878360580096,
    "created_at" : "2015-07-29 00:34:24 +0000",
    "in_reply_to_screen_name" : "MWalfred",
    "in_reply_to_user_id_str" : "2192473280",
    "user" : {
      "name" : "JohnBlueTruffleMedia",
      "screen_name" : "TruffleMedia",
      "protected" : false,
      "id_str" : "988911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660999908204351488\/wrS1VNMe_normal.jpg",
      "id" : 988911,
      "verified" : false
    }
  },
  "id" : 626204932274847744,
  "created_at" : "2015-07-29 01:37:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626156578597675008",
  "geo" : { },
  "id_str" : "626159571690737665",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides thanks for your assistance, kind sir. (this didnt work.. but you helped me figure it out a little bit..lol)",
  "id" : 626159571690737665,
  "in_reply_to_status_id" : 626156578597675008,
  "created_at" : "2015-07-28 22:37:30 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626156032809635840",
  "geo" : { },
  "id_str" : "626156961801875457",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides why cant i order it to center heading and all data below within table without highlighting cell range. its 2015 go#ammit!!",
  "id" : 626156961801875457,
  "in_reply_to_status_id" : 626156032809635840,
  "created_at" : "2015-07-28 22:27:07 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626155801883869184",
  "geo" : { },
  "id_str" : "626156256189935616",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides ahh.. yes.. i found that but it only centered the heading not the data below (which are dates)",
  "id" : 626156256189935616,
  "in_reply_to_status_id" : 626155801883869184,
  "created_at" : "2015-07-28 22:24:19 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626139219388403712",
  "geo" : { },
  "id_str" : "626155726558363649",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides the thing is.. there was stuff above the.. table?? (name, birth date..) and that got centered, too.",
  "id" : 626155726558363649,
  "in_reply_to_status_id" : 626139219388403712,
  "created_at" : "2015-07-28 22:22:13 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626139219388403712",
  "geo" : { },
  "id_str" : "626155292124938240",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides my right click doesnt bring up properties.. but I was able to do it by highlighting column and click center alignment.",
  "id" : 626155292124938240,
  "in_reply_to_status_id" : 626139219388403712,
  "created_at" : "2015-07-28 22:20:29 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626131075417403392",
  "geo" : { },
  "id_str" : "626139843622514689",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre glad the rest of day looks excellent. : )",
  "id" : 626139843622514689,
  "in_reply_to_status_id" : 626131075417403392,
  "created_at" : "2015-07-28 21:19:06 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spreadsheet",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626139009824223232",
  "text" : "I want all the data in a column to be centered.. cant seem to figure it out.. #spreadsheet",
  "id" : 626139009824223232,
  "created_at" : "2015-07-28 21:15:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626115312866492416",
  "text" : "aha.. i figured how how to edit column heading in spreadsheet!",
  "id" : 626115312866492416,
  "created_at" : "2015-07-28 19:41:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VisitScotland",
      "screen_name" : "VisitScotland",
      "indices" : [ 3, 17 ],
      "id_str" : "16557472",
      "id" : 16557472
    }, {
      "name" : "James Roddie",
      "screen_name" : "jroddiephoto",
      "indices" : [ 63, 76 ],
      "id_str" : "2923239983",
      "id" : 2923239983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jroddiephoto\/status\/625766316792786944\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/MwHGwP9WvH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK8rJgfWcAAxlf-.jpg",
      "id_str" : "625766315568033792",
      "id" : 625766315568033792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK8rJgfWcAAxlf-.jpg",
      "sizes" : [ {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 740,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 631,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MwHGwP9WvH"
    } ],
    "hashtags" : [ {
      "text" : "Scotland",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "Cairngorms",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626107912671248384",
  "text" : "RT @VisitScotland: Raining in #Scotland? Just shake it off! MT @jroddiephoto A mountain hare in the #Cairngorms http:\/\/t.co\/MwHGwP9WvH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.falcon.io\" rel=\"nofollow\"\u003EFalcon Social Media Management \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Roddie",
        "screen_name" : "jroddiephoto",
        "indices" : [ 44, 57 ],
        "id_str" : "2923239983",
        "id" : 2923239983
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jroddiephoto\/status\/625766316792786944\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/MwHGwP9WvH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK8rJgfWcAAxlf-.jpg",
        "id_str" : "625766315568033792",
        "id" : 625766315568033792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK8rJgfWcAAxlf-.jpg",
        "sizes" : [ {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 740,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 631,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/MwHGwP9WvH"
      } ],
      "hashtags" : [ {
        "text" : "Scotland",
        "indices" : [ 11, 20 ]
      }, {
        "text" : "Cairngorms",
        "indices" : [ 81, 92 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "625766316792786944",
    "geo" : { },
    "id_str" : "626034120662102016",
    "in_reply_to_user_id" : 2923239983,
    "text" : "Raining in #Scotland? Just shake it off! MT @jroddiephoto A mountain hare in the #Cairngorms http:\/\/t.co\/MwHGwP9WvH",
    "id" : 626034120662102016,
    "in_reply_to_status_id" : 625766316792786944,
    "created_at" : "2015-07-28 14:19:00 +0000",
    "in_reply_to_screen_name" : "jroddiephoto",
    "in_reply_to_user_id_str" : "2923239983",
    "user" : {
      "name" : "VisitScotland",
      "screen_name" : "VisitScotland",
      "protected" : false,
      "id_str" : "16557472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793752584100188161\/cPit4jb5_normal.jpg",
      "id" : 16557472,
      "verified" : true
    }
  },
  "id" : 626107912671248384,
  "created_at" : "2015-07-28 19:12:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626106007341543424",
  "text" : "trying to customize spreadsheet template. um.. yeah. ((pullshair))",
  "id" : 626106007341543424,
  "created_at" : "2015-07-28 19:04:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Denham Photo",
      "screen_name" : "Jim_Denham",
      "indices" : [ 3, 14 ],
      "id_str" : "19791945",
      "id" : 19791945
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Jim_Denham\/status\/625852840376967168\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/NckEW1xpLj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK951x5UcAA800Z.jpg",
      "id_str" : "625852838061568000",
      "id" : 625852838061568000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK951x5UcAA800Z.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1638,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 819,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NckEW1xpLj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625853829020549120",
  "text" : "RT @Jim_Denham: A peek at the pier! http:\/\/t.co\/NckEW1xpLj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Jim_Denham\/status\/625852840376967168\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/NckEW1xpLj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK951x5UcAA800Z.jpg",
        "id_str" : "625852838061568000",
        "id" : 625852838061568000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK951x5UcAA800Z.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1638,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NckEW1xpLj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625852840376967168",
    "text" : "A peek at the pier! http:\/\/t.co\/NckEW1xpLj",
    "id" : 625852840376967168,
    "created_at" : "2015-07-28 02:18:39 +0000",
    "user" : {
      "name" : "Jim Denham Photo",
      "screen_name" : "Jim_Denham",
      "protected" : false,
      "id_str" : "19791945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907137892253696\/ALOyEhOY_normal.jpg",
      "id" : 19791945,
      "verified" : false
    }
  },
  "id" : 625853829020549120,
  "created_at" : "2015-07-28 02:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625853248503717889",
  "text" : "RT @ZachsMind: or maybe there is no point. so if there's no point, we make some points of our own along the way. So there's a point anyway.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625851479706853377",
    "text" : "or maybe there is no point. so if there's no point, we make some points of our own along the way. So there's a point anyway.",
    "id" : 625851479706853377,
    "created_at" : "2015-07-28 02:13:15 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 625853248503717889,
  "created_at" : "2015-07-28 02:20:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625848948599713792",
  "geo" : { },
  "id_str" : "625851901633015808",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe awwww!",
  "id" : 625851901633015808,
  "in_reply_to_status_id" : 625848948599713792,
  "created_at" : "2015-07-28 02:14:55 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625810677752573953",
  "geo" : { },
  "id_str" : "625815848381480960",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe we have a stray\/feral for many years. he still hisses but he lets me get close to put out food.",
  "id" : 625815848381480960,
  "in_reply_to_status_id" : 625810677752573953,
  "created_at" : "2015-07-27 23:51:40 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/PprTaVycwz",
      "expanded_url" : "http:\/\/wp.rxisk.org\/dress-syndrome-no-way-to-treat-a-lady\/",
      "display_url" : "wp.rxisk.org\/dress-syndrome\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625804336426315776",
  "text" : "DRESS Syndrome: No Way to Treat a Lady http:\/\/t.co\/PprTaVycwz",
  "id" : 625804336426315776,
  "created_at" : "2015-07-27 23:05:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "effexor",
      "indices" : [ 6, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/weDxtI8WAo",
      "expanded_url" : "https:\/\/twitter.com\/RxISK\/status\/623897011645853696",
      "display_url" : "twitter.com\/RxISK\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625795609124020224",
  "text" : "im on #effexor .. a few hours late and I start withdrawal. its awful. https:\/\/t.co\/weDxtI8WAo",
  "id" : 625795609124020224,
  "created_at" : "2015-07-27 22:31:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul(Atreides)Wood",
      "screen_name" : "SuperRetroid",
      "indices" : [ 3, 16 ],
      "id_str" : "154545301",
      "id" : 154545301
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SuperRetroid\/status\/625653804759937024\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/NkQhIaTslS",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CK7Ey0SWUAABRuW.png",
      "id_str" : "625653775559184384",
      "id" : 625653775559184384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CK7Ey0SWUAABRuW.png",
      "sizes" : [ {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 385
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 385
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 385
      } ],
      "display_url" : "pic.twitter.com\/NkQhIaTslS"
    } ],
    "hashtags" : [ {
      "text" : "cats",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625793469882179584",
  "text" : "RT @SuperRetroid: NO. I AM BREAD. I DON'T HAVE TIME FOR YOU. GO AWAY. #cats http:\/\/t.co\/NkQhIaTslS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SuperRetroid\/status\/625653804759937024\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/NkQhIaTslS",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CK7Ey0SWUAABRuW.png",
        "id_str" : "625653775559184384",
        "id" : 625653775559184384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CK7Ey0SWUAABRuW.png",
        "sizes" : [ {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 385
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 385
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 385
        } ],
        "display_url" : "pic.twitter.com\/NkQhIaTslS"
      } ],
      "hashtags" : [ {
        "text" : "cats",
        "indices" : [ 52, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625653804759937024",
    "text" : "NO. I AM BREAD. I DON'T HAVE TIME FOR YOU. GO AWAY. #cats http:\/\/t.co\/NkQhIaTslS",
    "id" : 625653804759937024,
    "created_at" : "2015-07-27 13:07:45 +0000",
    "user" : {
      "name" : "Paul(Atreides)Wood",
      "screen_name" : "SuperRetroid",
      "protected" : false,
      "id_str" : "154545301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784816200425480192\/X9Q3Bju0_normal.jpg",
      "id" : 154545301,
      "verified" : false
    }
  },
  "id" : 625793469882179584,
  "created_at" : "2015-07-27 22:22:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toto Habschned",
      "screen_name" : "totohabschned",
      "indices" : [ 0, 14 ],
      "id_str" : "46611987",
      "id" : 46611987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625732255491747840",
  "geo" : { },
  "id_str" : "625740601879851008",
  "in_reply_to_user_id" : 46611987,
  "text" : "@totohabschned lab results, weight, dr visits, meds she takes. i'd love to be able to graph results so I can look for patterns.",
  "id" : 625740601879851008,
  "in_reply_to_status_id" : 625732255491747840,
  "created_at" : "2015-07-27 18:52:39 +0000",
  "in_reply_to_screen_name" : "totohabschned",
  "in_reply_to_user_id_str" : "46611987",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phr",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625712894852861952",
  "text" : "i think i'll be stuck using spreadsheet templates to track DD's health (visits, meds, labs) as I cant find appropriate #phr software.",
  "id" : 625712894852861952,
  "created_at" : "2015-07-27 17:02:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625689312290582528",
  "text" : "RT @Buddhaworld: First realise your own confusion and helplessness, that u r nothing but a piece of revolving nature,let go of all illusion\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625616054786617344",
    "text" : "First realise your own confusion and helplessness, that u r nothing but a piece of revolving nature,let go of all illusion, thats buddhahood",
    "id" : 625616054786617344,
    "created_at" : "2015-07-27 10:37:45 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 625689312290582528,
  "created_at" : "2015-07-27 15:28:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOX8 WGHP",
      "screen_name" : "myfox8",
      "indices" : [ 3, 10 ],
      "id_str" : "5751952",
      "id" : 5751952
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/myfox8\/status\/625655923114033154\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EFFXbYtBop",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK7GJ_JUkAAGXMT.jpg",
      "id_str" : "625655273122729984",
      "id" : 625655273122729984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK7GJ_JUkAAGXMT.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/EFFXbYtBop"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/yc51depqFo",
      "expanded_url" : "http:\/\/link.myfox8.com\/1D5zBY6",
      "display_url" : "link.myfox8.com\/1D5zBY6"
    } ]
  },
  "geo" : { },
  "id_str" : "625688328894029825",
  "text" : "RT @myfox8: The carcass of a rarely seen deep-sea beaked whale was found washed up on a beach. http:\/\/t.co\/yc51depqFo http:\/\/t.co\/EFFXbYtBop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/myfox8\/status\/625655923114033154\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/EFFXbYtBop",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK7GJ_JUkAAGXMT.jpg",
        "id_str" : "625655273122729984",
        "id" : 625655273122729984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK7GJ_JUkAAGXMT.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/EFFXbYtBop"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/yc51depqFo",
        "expanded_url" : "http:\/\/link.myfox8.com\/1D5zBY6",
        "display_url" : "link.myfox8.com\/1D5zBY6"
      } ]
    },
    "geo" : { },
    "id_str" : "625655923114033154",
    "text" : "The carcass of a rarely seen deep-sea beaked whale was found washed up on a beach. http:\/\/t.co\/yc51depqFo http:\/\/t.co\/EFFXbYtBop",
    "id" : 625655923114033154,
    "created_at" : "2015-07-27 13:16:10 +0000",
    "user" : {
      "name" : "FOX8 WGHP",
      "screen_name" : "myfox8",
      "protected" : false,
      "id_str" : "5751952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471020349362958336\/CFoW_Z6w_normal.jpeg",
      "id" : 5751952,
      "verified" : true
    }
  },
  "id" : 625688328894029825,
  "created_at" : "2015-07-27 15:24:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "indices" : [ 3, 15 ],
      "id_str" : "17592150",
      "id" : 17592150
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/thomaspluck\/status\/625465992504852480\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/KUvPVtOBPL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK4aAD6W8AAz5tf.jpg",
      "id_str" : "625465986603479040",
      "id" : 625465986603479040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK4aAD6W8AAz5tf.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 780,
        "resize" : "fit",
        "w" : 1040
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KUvPVtOBPL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625472432560828416",
  "text" : "RT @thomaspluck: \"Thank you for washing my towels.\" -Charlie http:\/\/t.co\/KUvPVtOBPL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thomaspluck\/status\/625465992504852480\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/KUvPVtOBPL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK4aAD6W8AAz5tf.jpg",
        "id_str" : "625465986603479040",
        "id" : 625465986603479040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK4aAD6W8AAz5tf.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 780,
          "resize" : "fit",
          "w" : 1040
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KUvPVtOBPL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625465992504852480",
    "text" : "\"Thank you for washing my towels.\" -Charlie http:\/\/t.co\/KUvPVtOBPL",
    "id" : 625465992504852480,
    "created_at" : "2015-07-27 00:41:27 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 625472432560828416,
  "created_at" : "2015-07-27 01:07:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/bBKEzvIQ9S",
      "expanded_url" : "http:\/\/goo.gl\/fb\/ujCXPO",
      "display_url" : "goo.gl\/fb\/ujCXPO"
    } ]
  },
  "geo" : { },
  "id_str" : "625472105472241664",
  "text" : "RT @Mahala: The Latest and Greatest from Frog Pond Holler http:\/\/t.co\/bBKEzvIQ9S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/bBKEzvIQ9S",
        "expanded_url" : "http:\/\/goo.gl\/fb\/ujCXPO",
        "display_url" : "goo.gl\/fb\/ujCXPO"
      } ]
    },
    "geo" : { },
    "id_str" : "625358067585187840",
    "text" : "The Latest and Greatest from Frog Pond Holler http:\/\/t.co\/bBKEzvIQ9S",
    "id" : 625358067585187840,
    "created_at" : "2015-07-26 17:32:36 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 625472105472241664,
  "created_at" : "2015-07-27 01:05:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Bible",
      "screen_name" : "AnimalBibIe",
      "indices" : [ 3, 15 ],
      "id_str" : "141695305",
      "id" : 141695305
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AnimalBibIe\/status\/617502357585326081\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ZwJYp2BQnv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJHPHdqWsAAW-Q5.jpg",
      "id_str" : "617502351054778368",
      "id" : 617502351054778368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJHPHdqWsAAW-Q5.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZwJYp2BQnv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625448643257061380",
  "text" : "RT @AnimalBibIe: so I can\u2019t do my math homework cause my duck fell asleep on my calculator. http:\/\/t.co\/ZwJYp2BQnv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AnimalBibIe\/status\/617502357585326081\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/ZwJYp2BQnv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJHPHdqWsAAW-Q5.jpg",
        "id_str" : "617502351054778368",
        "id" : 617502351054778368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJHPHdqWsAAW-Q5.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZwJYp2BQnv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "617502357585326081",
    "text" : "so I can\u2019t do my math homework cause my duck fell asleep on my calculator. http:\/\/t.co\/ZwJYp2BQnv",
    "id" : 617502357585326081,
    "created_at" : "2015-07-05 01:16:49 +0000",
    "user" : {
      "name" : "Animal Bible",
      "screen_name" : "AnimalBibIe",
      "protected" : false,
      "id_str" : "141695305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765643646758641665\/CghmZbOw_normal.jpg",
      "id" : 141695305,
      "verified" : false
    }
  },
  "id" : 625448643257061380,
  "created_at" : "2015-07-26 23:32:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Burns",
      "screen_name" : "alexburnsNYT",
      "indices" : [ 3, 16 ],
      "id_str" : "79743108",
      "id" : 79743108
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/alexburnsNYT\/status\/625353465942949888\/photo\/1",
      "indices" : [ 128, 150 ],
      "url" : "http:\/\/t.co\/DM9MGFcDF0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK2zpu2UYAAeREy.jpg",
      "id_str" : "625353452806234112",
      "id" : 625353452806234112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK2zpu2UYAAeREy.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DM9MGFcDF0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/qG0lO4l9bS",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/07\/27\/nyregion\/a-manhattan-project-veteran-reflects-on-his-atomic-bomb-work.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
      "display_url" : "nytimes.com\/2015\/07\/27\/nyr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625448611954958337",
  "text" : "RT @alexburnsNYT: Meet the 93y\/o NY veteran &amp; physicist who worked on the Manhattan Project &gt;&gt; http:\/\/t.co\/qG0lO4l9bS http:\/\/t.co\/DM9MGFcDF0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/alexburnsNYT\/status\/625353465942949888\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/DM9MGFcDF0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK2zpu2UYAAeREy.jpg",
        "id_str" : "625353452806234112",
        "id" : 625353452806234112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK2zpu2UYAAeREy.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DM9MGFcDF0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/qG0lO4l9bS",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/07\/27\/nyregion\/a-manhattan-project-veteran-reflects-on-his-atomic-bomb-work.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
        "display_url" : "nytimes.com\/2015\/07\/27\/nyr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625353465942949888",
    "text" : "Meet the 93y\/o NY veteran &amp; physicist who worked on the Manhattan Project &gt;&gt; http:\/\/t.co\/qG0lO4l9bS http:\/\/t.co\/DM9MGFcDF0",
    "id" : 625353465942949888,
    "created_at" : "2015-07-26 17:14:19 +0000",
    "user" : {
      "name" : "Alex Burns",
      "screen_name" : "alexburnsNYT",
      "protected" : false,
      "id_str" : "79743108",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785092034919030784\/q0kXRmfP_normal.jpg",
      "id" : 79743108,
      "verified" : true
    }
  },
  "id" : 625448611954958337,
  "created_at" : "2015-07-26 23:32:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625448241165934592",
  "text" : "RT @Charmantides: Why we adding salt to caramel and toffee all of a sudden? Wasn't sugar enough?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625367200589828096",
    "text" : "Why we adding salt to caramel and toffee all of a sudden? Wasn't sugar enough?",
    "id" : 625367200589828096,
    "created_at" : "2015-07-26 18:08:54 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 625448241165934592,
  "created_at" : "2015-07-26 23:30:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625446215279362048",
  "text" : "RT @SangyeH: I went to the memorial service for a friend's mom today. The word everyone used to describe her: compassionate. The only legac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625443477967515648",
    "text" : "I went to the memorial service for a friend's mom today. The word everyone used to describe her: compassionate. The only legacy worth having",
    "id" : 625443477967515648,
    "created_at" : "2015-07-26 23:11:59 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 625446215279362048,
  "created_at" : "2015-07-26 23:22:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/RwOalULrZS",
      "expanded_url" : "https:\/\/instagram.com\/p\/5nccKUOqeP\/",
      "display_url" : "instagram.com\/p\/5nccKUOqeP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "625446121897332740",
  "text" : "RT @wilw: I wish this character was a real person, because I love the way he thinks. https:\/\/t.co\/RwOalULrZS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/RwOalULrZS",
        "expanded_url" : "https:\/\/instagram.com\/p\/5nccKUOqeP\/",
        "display_url" : "instagram.com\/p\/5nccKUOqeP\/"
      } ]
    },
    "geo" : { },
    "id_str" : "625434266726477825",
    "text" : "I wish this character was a real person, because I love the way he thinks. https:\/\/t.co\/RwOalULrZS",
    "id" : 625434266726477825,
    "created_at" : "2015-07-26 22:35:23 +0000",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793503013851631616\/55p1uw70_normal.jpg",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 625446121897332740,
  "created_at" : "2015-07-26 23:22:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/625373249019494400\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/cIvhenmoLA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK3Fp8FWUAAT0jE.jpg",
      "id_str" : "625373247568236544",
      "id" : 625373247568236544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK3Fp8FWUAAT0jE.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1728,
        "resize" : "fit",
        "w" : 2304
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cIvhenmoLA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625374400544681984",
  "text" : "RT @wildwitchyju: Something strange and very lovely having the parakeets visit the garden. http:\/\/t.co\/cIvhenmoLA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/625373249019494400\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/cIvhenmoLA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK3Fp8FWUAAT0jE.jpg",
        "id_str" : "625373247568236544",
        "id" : 625373247568236544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK3Fp8FWUAAT0jE.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1728,
          "resize" : "fit",
          "w" : 2304
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cIvhenmoLA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625373249019494400",
    "text" : "Something strange and very lovely having the parakeets visit the garden. http:\/\/t.co\/cIvhenmoLA",
    "id" : 625373249019494400,
    "created_at" : "2015-07-26 18:32:56 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 625374400544681984,
  "created_at" : "2015-07-26 18:37:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/4DWj9WSIhd",
      "expanded_url" : "http:\/\/www.therebelgod.com\/2015\/07\/why-i-reject-biblical-infallibility.html",
      "display_url" : "therebelgod.com\/2015\/07\/why-i-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625141342755274752",
  "text" : "Why I Reject Biblical Infallibility - Why I Reject Biblical Infallibility http:\/\/t.co\/4DWj9WSIhd",
  "id" : 625141342755274752,
  "created_at" : "2015-07-26 03:11:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    }, {
      "name" : "Disclose.tv",
      "screen_name" : "DiscloseTV",
      "indices" : [ 122, 133 ],
      "id_str" : "15392486",
      "id" : 15392486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625107227309903872",
  "text" : "RT @Buddhaworld: CAMPING is now child abuse? Michigan government seizes kids to punish family for off-grid camping trip!  @DiscloseTV) http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Disclose.tv",
        "screen_name" : "DiscloseTV",
        "indices" : [ 105, 116 ],
        "id_str" : "15392486",
        "id" : 15392486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/AF7153nmQH",
        "expanded_url" : "http:\/\/www.disclose.tv\/news\/camping_is_now_child_abuse_michigan_government_seizes_kids_to_punish_family_for_offgrid_camping_trip\/120098",
        "display_url" : "disclose.tv\/news\/camping_i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618401826413649920",
    "text" : "CAMPING is now child abuse? Michigan government seizes kids to punish family for off-grid camping trip!  @DiscloseTV) http:\/\/t.co\/AF7153nmQH",
    "id" : 618401826413649920,
    "created_at" : "2015-07-07 12:50:59 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 625107227309903872,
  "created_at" : "2015-07-26 00:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625106339837136896",
  "text" : "RT @Buddhaworld: If you feed people daily with endless streams of news, you numb the attention to a point of total acceptance of any kind o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623821649234796544",
    "text" : "If you feed people daily with endless streams of news, you numb the attention to a point of total acceptance of any kind of situation. Volko",
    "id" : 623821649234796544,
    "created_at" : "2015-07-22 11:47:25 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 625106339837136896,
  "created_at" : "2015-07-26 00:52:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/YcqKDgdJ0H",
      "expanded_url" : "http:\/\/j.mp\/1fvevYt",
      "display_url" : "j.mp\/1fvevYt"
    } ]
  },
  "geo" : { },
  "id_str" : "625105757609062400",
  "text" : "RT @thDigitalReader: AlphaSmart: A History of One of Ed-Tech's Favorite (Drop-Kickable) Writing Tools http:\/\/t.co\/YcqKDgdJ0H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/YcqKDgdJ0H",
        "expanded_url" : "http:\/\/j.mp\/1fvevYt",
        "display_url" : "j.mp\/1fvevYt"
      } ]
    },
    "geo" : { },
    "id_str" : "625103903298842624",
    "text" : "AlphaSmart: A History of One of Ed-Tech's Favorite (Drop-Kickable) Writing Tools http:\/\/t.co\/YcqKDgdJ0H",
    "id" : 625103903298842624,
    "created_at" : "2015-07-26 00:42:39 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 625105757609062400,
  "created_at" : "2015-07-26 00:50:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMAgulag",
      "screen_name" : "FEMAgulag",
      "indices" : [ 3, 13 ],
      "id_str" : "2612937380",
      "id" : 2612937380
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FEMAgulag\/status\/625097672739819520\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/u41czzEatD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKzLBDQUkAA6ftZ.png",
      "id_str" : "625097667211726848",
      "id" : 625097667211726848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKzLBDQUkAA6ftZ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/u41czzEatD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625104172296368128",
  "text" : "RT @FEMAgulag: bbasap to RT http:\/\/t.co\/u41czzEatD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FEMAgulag\/status\/625097672739819520\/photo\/1",
        "indices" : [ 13, 35 ],
        "url" : "http:\/\/t.co\/u41czzEatD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKzLBDQUkAA6ftZ.png",
        "id_str" : "625097667211726848",
        "id" : 625097667211726848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKzLBDQUkAA6ftZ.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/u41czzEatD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625097672739819520",
    "text" : "bbasap to RT http:\/\/t.co\/u41czzEatD",
    "id" : 625097672739819520,
    "created_at" : "2015-07-26 00:17:53 +0000",
    "user" : {
      "name" : "FEMAgulag",
      "screen_name" : "FEMAgulag",
      "protected" : false,
      "id_str" : "2612937380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486733719684665344\/d0h-19br_normal.jpeg",
      "id" : 2612937380,
      "verified" : false
    }
  },
  "id" : 625104172296368128,
  "created_at" : "2015-07-26 00:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Pickover",
      "screen_name" : "pickover",
      "indices" : [ 3, 12 ],
      "id_str" : "16176754",
      "id" : 16176754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/9jjtFAqqDc",
      "expanded_url" : "http:\/\/nyti.ms\/1LV1Xpl",
      "display_url" : "nyti.ms\/1LV1Xpl"
    } ]
  },
  "geo" : { },
  "id_str" : "625103845765607428",
  "text" : "RT @pickover: Aliens among us. 50% of the DNA found in NYC subway system does not match ANY known organism. http:\/\/t.co\/9jjtFAqqDc  http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pickover\/status\/563766512335339520\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/bsiT1hqz4C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9Lmp8qCUAAqr_X.jpg",
        "id_str" : "563766511706198016",
        "id" : 563766511706198016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9Lmp8qCUAAqr_X.jpg",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bsiT1hqz4C"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/9jjtFAqqDc",
        "expanded_url" : "http:\/\/nyti.ms\/1LV1Xpl",
        "display_url" : "nyti.ms\/1LV1Xpl"
      } ]
    },
    "geo" : { },
    "id_str" : "625041496488677377",
    "text" : "Aliens among us. 50% of the DNA found in NYC subway system does not match ANY known organism. http:\/\/t.co\/9jjtFAqqDc  http:\/\/t.co\/bsiT1hqz4C",
    "id" : 625041496488677377,
    "created_at" : "2015-07-25 20:34:40 +0000",
    "user" : {
      "name" : "Cliff Pickover",
      "screen_name" : "pickover",
      "protected" : false,
      "id_str" : "16176754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69072946\/twitter3_normal.jpg",
      "id" : 16176754,
      "verified" : false
    }
  },
  "id" : 625103845765607428,
  "created_at" : "2015-07-26 00:42:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625102841003253760",
  "text" : "RT @TheGodLight: No one is perfect, we all make mistakes, forgive yourself for not acting better &amp; move forwards with this lesson in mind.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625094550567165953",
    "text" : "No one is perfect, we all make mistakes, forgive yourself for not acting better &amp; move forwards with this lesson in mind.",
    "id" : 625094550567165953,
    "created_at" : "2015-07-26 00:05:29 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 625102841003253760,
  "created_at" : "2015-07-26 00:38:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Haviour",
      "screen_name" : "SpinningJ",
      "indices" : [ 3, 13 ],
      "id_str" : "355648660",
      "id" : 355648660
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SpinningJ\/status\/624998946537123840\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/LTKlDzV5DH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKxxOLhW8AAJHl2.jpg",
      "id_str" : "624998936722468864",
      "id" : 624998936722468864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKxxOLhW8AAJHl2.jpg",
      "sizes" : [ {
        "h" : 1090,
        "resize" : "fit",
        "w" : 1090
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LTKlDzV5DH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625067159006408704",
  "text" : "RT @SpinningJ: Met these gorgeous beasts along the walk today. http:\/\/t.co\/LTKlDzV5DH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpinningJ\/status\/624998946537123840\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/LTKlDzV5DH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKxxOLhW8AAJHl2.jpg",
        "id_str" : "624998936722468864",
        "id" : 624998936722468864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKxxOLhW8AAJHl2.jpg",
        "sizes" : [ {
          "h" : 1090,
          "resize" : "fit",
          "w" : 1090
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LTKlDzV5DH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624998946537123840",
    "text" : "Met these gorgeous beasts along the walk today. http:\/\/t.co\/LTKlDzV5DH",
    "id" : 624998946537123840,
    "created_at" : "2015-07-25 17:45:35 +0000",
    "user" : {
      "name" : "Julie Haviour",
      "screen_name" : "SpinningJ",
      "protected" : false,
      "id_str" : "355648660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1496916965\/polonaise_20spinning_20wheel_normal.jpg",
      "id" : 355648660,
      "verified" : false
    }
  },
  "id" : 625067159006408704,
  "created_at" : "2015-07-25 22:16:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "indices" : [ 3, 19 ],
      "id_str" : "727056229",
      "id" : 727056229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/624954708764065792\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/LhSWgQXoyG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKxI-vlUYAAUX6a.jpg",
      "id_str" : "624954691059736576",
      "id" : 624954691059736576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKxI-vlUYAAUX6a.jpg",
      "sizes" : [ {
        "h" : 517,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 517
      } ],
      "display_url" : "pic.twitter.com\/LhSWgQXoyG"
    } ],
    "hashtags" : [ {
      "text" : "Catskills",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624982822625931265",
  "text" : "RT @CatskillCritter: The misty, mysterious woods this morning. #Catskills http:\/\/t.co\/LhSWgQXoyG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CatskillCritter\/status\/624954708764065792\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/LhSWgQXoyG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKxI-vlUYAAUX6a.jpg",
        "id_str" : "624954691059736576",
        "id" : 624954691059736576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKxI-vlUYAAUX6a.jpg",
        "sizes" : [ {
          "h" : 517,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 517
        } ],
        "display_url" : "pic.twitter.com\/LhSWgQXoyG"
      } ],
      "hashtags" : [ {
        "text" : "Catskills",
        "indices" : [ 42, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624954708764065792",
    "text" : "The misty, mysterious woods this morning. #Catskills http:\/\/t.co\/LhSWgQXoyG",
    "id" : 624954708764065792,
    "created_at" : "2015-07-25 14:49:48 +0000",
    "user" : {
      "name" : "Leslie T. Sharpe",
      "screen_name" : "CatskillCritter",
      "protected" : false,
      "id_str" : "727056229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3406966060\/89cc70419d3706d1cce2d6a75ebcadd7_normal.jpeg",
      "id" : 727056229,
      "verified" : false
    }
  },
  "id" : 624982822625931265,
  "created_at" : "2015-07-25 16:41:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/QPWyL8v6Q2",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/624809224753807360",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624976493727383553",
  "text" : "nice! https:\/\/t.co\/QPWyL8v6Q2",
  "id" : 624976493727383553,
  "created_at" : "2015-07-25 16:16:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624976269936066560",
  "text" : "RT @dhammagirl: We all have a part to play in this precious human life. \n\nWe own none of it, Fame or Shame.\n\nWe're all just walking one ano\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ONE",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624882094402076672",
    "text" : "We all have a part to play in this precious human life. \n\nWe own none of it, Fame or Shame.\n\nWe're all just walking one another home.\n\n#ONE",
    "id" : 624882094402076672,
    "created_at" : "2015-07-25 10:01:15 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 624976269936066560,
  "created_at" : "2015-07-25 16:15:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/6N0m49ekPE",
      "expanded_url" : "https:\/\/twitter.com\/dwaynereaves\/status\/624928589398548480",
      "display_url" : "twitter.com\/dwaynereaves\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624976046878773248",
  "text" : "gorgeous, Dwayne! nice shot! https:\/\/t.co\/6N0m49ekPE",
  "id" : 624976046878773248,
  "created_at" : "2015-07-25 16:14:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624975221636886529",
  "text" : "its 2015 why is it so hard to find a personal medical database??",
  "id" : 624975221636886529,
  "created_at" : "2015-07-25 16:11:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "sick",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/Dh4amAAfX1",
      "expanded_url" : "https:\/\/twitter.com\/JawSurgeryPain\/status\/624773910966370304",
      "display_url" : "twitter.com\/JawSurgeryPain\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624777119235751936",
  "text" : "Advocating for my DD #thyroid #hashimotos #sick  https:\/\/t.co\/Dh4amAAfX1",
  "id" : 624777119235751936,
  "created_at" : "2015-07-25 03:04:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ThatWorstMan\/status\/624759451422056448\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/AkbureVjnH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKuXaFPUYAAbhaw.jpg",
      "id_str" : "624759447659765760",
      "id" : 624759447659765760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKuXaFPUYAAbhaw.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/AkbureVjnH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624776321974038528",
  "text" : "RT @ThatWorstMan: Genuinely surprised to see \"cactus\" as one of the top three choices... http:\/\/t.co\/AkbureVjnH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ThatWorstMan\/status\/624759451422056448\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/AkbureVjnH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKuXaFPUYAAbhaw.jpg",
        "id_str" : "624759447659765760",
        "id" : 624759447659765760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKuXaFPUYAAbhaw.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/AkbureVjnH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624759451422056448",
    "text" : "Genuinely surprised to see \"cactus\" as one of the top three choices... http:\/\/t.co\/AkbureVjnH",
    "id" : 624759451422056448,
    "created_at" : "2015-07-25 01:53:55 +0000",
    "user" : {
      "name" : "Kisses for Banjo",
      "screen_name" : "prosperdave",
      "protected" : false,
      "id_str" : "277341967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800746770196086784\/Z3inqgb3_normal.jpg",
      "id" : 277341967,
      "verified" : false
    }
  },
  "id" : 624776321974038528,
  "created_at" : "2015-07-25 03:00:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624775977076457472",
  "text" : "RT @ZachsMind: so long as human beings continue to think in terms of us vs them, we will continue to completely fail each other as a civili\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624774729564446720",
    "text" : "so long as human beings continue to think in terms of us vs them, we will continue to completely fail each other as a civilization.",
    "id" : 624774729564446720,
    "created_at" : "2015-07-25 02:54:37 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 624775977076457472,
  "created_at" : "2015-07-25 02:59:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "indices" : [ 3, 16 ],
      "id_str" : "44163738",
      "id" : 44163738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624768273440219137",
  "text" : "RT @ralphmacchio: Look who joined me on a walk thru Washington Square Park today. Flew on and off my shoulders 4 times.\u2026 https:\/\/t.co\/qzXJ6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/qzXJ6HVwPF",
        "expanded_url" : "https:\/\/instagram.com\/p\/5iqJdYweh3\/",
        "display_url" : "instagram.com\/p\/5iqJdYweh3\/"
      } ]
    },
    "geo" : { },
    "id_str" : "624760723059666944",
    "text" : "Look who joined me on a walk thru Washington Square Park today. Flew on and off my shoulders 4 times.\u2026 https:\/\/t.co\/qzXJ6HVwPF",
    "id" : 624760723059666944,
    "created_at" : "2015-07-25 01:58:58 +0000",
    "user" : {
      "name" : "Ralph Macchio",
      "screen_name" : "ralphmacchio",
      "protected" : false,
      "id_str" : "44163738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535851580667346944\/DCmtbKbq_normal.jpeg",
      "id" : 44163738,
      "verified" : true
    }
  },
  "id" : 624768273440219137,
  "created_at" : "2015-07-25 02:28:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "indices" : [ 3, 19 ],
      "id_str" : "2258357868",
      "id" : 2258357868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624767444947726336",
  "text" : "RT @AWorldOutOfMind: I remember my terror of hell as a child. You Christians really know how to abuse children, let me tell you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624758114114531328",
    "text" : "I remember my terror of hell as a child. You Christians really know how to abuse children, let me tell you.",
    "id" : 624758114114531328,
    "created_at" : "2015-07-25 01:48:36 +0000",
    "user" : {
      "name" : "Saint Brian",
      "screen_name" : "AWorldOutOfMind",
      "protected" : false,
      "id_str" : "2258357868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/414949487119831040\/6aQcyWSS_normal.jpeg",
      "id" : 2258357868,
      "verified" : false
    }
  },
  "id" : 624767444947726336,
  "created_at" : "2015-07-25 02:25:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/yEKF9NlhS0",
      "expanded_url" : "https:\/\/twitter.com\/Raven_Luni\/status\/624698636807610368",
      "display_url" : "twitter.com\/Raven_Luni\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624699364301213697",
  "text" : "Me, too!!! https:\/\/t.co\/yEKF9NlhS0",
  "id" : 624699364301213697,
  "created_at" : "2015-07-24 21:55:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624683527230083073",
  "text" : "RT @adampknave: Why do they all specify \"LIVE nude dancers\"? Was there a rash of posed nude corpses in strip clubs at some point?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624680632459735040",
    "text" : "Why do they all specify \"LIVE nude dancers\"? Was there a rash of posed nude corpses in strip clubs at some point?",
    "id" : 624680632459735040,
    "created_at" : "2015-07-24 20:40:43 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 624683527230083073,
  "created_at" : "2015-07-24 20:52:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624643173843894274",
  "text" : "argggg.. i can see why people get testy re: medical care.. trying to gather records, get appts set up.. ugh.",
  "id" : 624643173843894274,
  "created_at" : "2015-07-24 18:11:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624642848659533824",
  "text" : "thyroid ultrasound done 6\/30. follow up 7\/20. no U\/S found. will call when found. 7\/24 on hold 20 min. \"call tomorrow\" comp, fax down.",
  "id" : 624642848659533824,
  "created_at" : "2015-07-24 18:10:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colorlines.com",
      "screen_name" : "Colorlines",
      "indices" : [ 108, 119 ],
      "id_str" : "22986148",
      "id" : 22986148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/NWe22x54ls",
      "expanded_url" : "http:\/\/www.colorlines.com\/articles\/actor-jesse-williams-breaks-down-sandra-bland-and-racist-hypocrisy-24-tweets",
      "display_url" : "colorlines.com\/articles\/actor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624615761072369664",
  "text" : "Actor Jesse Williams Breaks Down Sandra Bland and Racist Hypocrisy in 24 Tweets  http:\/\/t.co\/NWe22x54ls via @Colorlines",
  "id" : 624615761072369664,
  "created_at" : "2015-07-24 16:22:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 3, 15 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/624227730205319168\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/knO4V1ONhu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKmz0BUWcAAznds.jpg",
      "id_str" : "624227729655885824",
      "id" : 624227729655885824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKmz0BUWcAAznds.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/knO4V1ONhu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/lo4BKbDZSX",
      "expanded_url" : "http:\/\/huff.to\/1CScNvd",
      "display_url" : "huff.to\/1CScNvd"
    } ]
  },
  "geo" : { },
  "id_str" : "624576812102873088",
  "text" : "RT @HuffPostPol: The transcript of Sandra Bland's arrest is as revealing as the video http:\/\/t.co\/lo4BKbDZSX http:\/\/t.co\/knO4V1ONhu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/624227730205319168\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/knO4V1ONhu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKmz0BUWcAAznds.jpg",
        "id_str" : "624227729655885824",
        "id" : 624227729655885824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKmz0BUWcAAznds.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/knO4V1ONhu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/lo4BKbDZSX",
        "expanded_url" : "http:\/\/huff.to\/1CScNvd",
        "display_url" : "huff.to\/1CScNvd"
      } ]
    },
    "geo" : { },
    "id_str" : "624393838203944960",
    "text" : "The transcript of Sandra Bland's arrest is as revealing as the video http:\/\/t.co\/lo4BKbDZSX http:\/\/t.co\/knO4V1ONhu",
    "id" : 624393838203944960,
    "created_at" : "2015-07-24 01:41:06 +0000",
    "user" : {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "protected" : false,
      "id_str" : "15458694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696718733721542656\/2lsNdbhH_normal.png",
      "id" : 15458694,
      "verified" : true
    }
  },
  "id" : 624576812102873088,
  "created_at" : "2015-07-24 13:48:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ava DuVernay",
      "screen_name" : "AVAETC",
      "indices" : [ 3, 10 ],
      "id_str" : "14982804",
      "id" : 14982804
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandraBland",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624392003799908352",
  "text" : "RT @AVAETC: \"Why are you arresting me?\" Because you know your rights. Because I can. Because no one'll believe you. #SandraBland\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SandraBland",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/tjiMPSIPja",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/189cab41-5424-4aff-9712-6392432b48b8",
        "display_url" : "amp.twimg.com\/v\/189cab41-542\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623675423344300032",
    "text" : "\"Why are you arresting me?\" Because you know your rights. Because I can. Because no one'll believe you. #SandraBland\nhttps:\/\/t.co\/tjiMPSIPja",
    "id" : 623675423344300032,
    "created_at" : "2015-07-22 02:06:22 +0000",
    "user" : {
      "name" : "Ava DuVernay",
      "screen_name" : "AVAETC",
      "protected" : false,
      "id_str" : "14982804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790384816008998912\/qZGmnEk2_normal.jpg",
      "id" : 14982804,
      "verified" : true
    }
  },
  "id" : 624392003799908352,
  "created_at" : "2015-07-24 01:33:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/RadieenBEz",
      "expanded_url" : "https:\/\/twitter.com\/deray\/status\/624307174890536961",
      "display_url" : "twitter.com\/deray\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624371834570604544",
  "text" : "((swearing))  https:\/\/t.co\/RadieenBEz",
  "id" : 624371834570604544,
  "created_at" : "2015-07-24 00:13:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u00DCtPAUL",
      "screen_name" : "paulroot72",
      "indices" : [ 3, 14 ],
      "id_str" : "709982247",
      "id" : 709982247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandraBland",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624371049287798784",
  "text" : "RT @paulroot72: I'm so mad about #SandraBland I want to know what really happened to her bc it sure as hell aint what the police are trying\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SandraBland",
        "indices" : [ 17, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624366806753505281",
    "text" : "I'm so mad about #SandraBland I want to know what really happened to her bc it sure as hell aint what the police are trying to say happened",
    "id" : 624366806753505281,
    "created_at" : "2015-07-23 23:53:41 +0000",
    "user" : {
      "name" : "R\u00DCtPAUL",
      "screen_name" : "paulroot72",
      "protected" : false,
      "id_str" : "709982247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716500802613944320\/_i7V-2kj_normal.jpg",
      "id" : 709982247,
      "verified" : false
    }
  },
  "id" : 624371049287798784,
  "created_at" : "2015-07-24 00:10:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624368539667968002",
  "text" : "RT @ZachsMind: the ppl we have placed in positions of power to run our country and protect us..\n\njust who exactly are they working for now?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624364959653216256",
    "text" : "the ppl we have placed in positions of power to run our country and protect us..\n\njust who exactly are they working for now? do we know?",
    "id" : 624364959653216256,
    "created_at" : "2015-07-23 23:46:21 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 624368539667968002,
  "created_at" : "2015-07-24 00:00:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "feedly",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/hzLUDGFwAv",
      "expanded_url" : "http:\/\/christianity-without-the-religion.blogspot.com\/2015\/07\/the-problem-of-hell-brad-jersak_22.html",
      "display_url" : "\u2026ity-without-the-religion.blogspot.com\/2015\/07\/the-pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624336686605017088",
  "text" : "The Problem of Hell - Brad Jersak http:\/\/t.co\/hzLUDGFwAv #religion #feedly",
  "id" : 624336686605017088,
  "created_at" : "2015-07-23 21:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624294616024662016",
  "text" : "RT @dhammagirl: Today, \n\nFirst, do no harm....\n\nCarry on. \u263A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624176937850830848",
    "text" : "Today, \n\nFirst, do no harm....\n\nCarry on. \u263A",
    "id" : 624176937850830848,
    "created_at" : "2015-07-23 11:19:13 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 624294616024662016,
  "created_at" : "2015-07-23 19:06:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Cantore",
      "screen_name" : "JimCantore",
      "indices" : [ 3, 14 ],
      "id_str" : "21388284",
      "id" : 21388284
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JimCantore\/status\/624181375395082240\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/gvFuTL1i5v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKmJppiUcAEZRzg.jpg",
      "id_str" : "624181371984965633",
      "id" : 624181371984965633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKmJppiUcAEZRzg.jpg",
      "sizes" : [ {
        "h" : 744,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gvFuTL1i5v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624294360193044481",
  "text" : "RT @JimCantore: Massive shelf cloud at S. Pete Beach last night from a friend of mine! Wow! http:\/\/t.co\/gvFuTL1i5v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JimCantore\/status\/624181375395082240\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/gvFuTL1i5v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKmJppiUcAEZRzg.jpg",
        "id_str" : "624181371984965633",
        "id" : 624181371984965633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKmJppiUcAEZRzg.jpg",
        "sizes" : [ {
          "h" : 744,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gvFuTL1i5v"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624181375395082240",
    "text" : "Massive shelf cloud at S. Pete Beach last night from a friend of mine! Wow! http:\/\/t.co\/gvFuTL1i5v",
    "id" : 624181375395082240,
    "created_at" : "2015-07-23 11:36:51 +0000",
    "user" : {
      "name" : "Jim Cantore",
      "screen_name" : "JimCantore",
      "protected" : false,
      "id_str" : "21388284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619271293402267648\/bcAxWQCr_normal.jpg",
      "id" : 21388284,
      "verified" : true
    }
  },
  "id" : 624294360193044481,
  "created_at" : "2015-07-23 19:05:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "indices" : [ 3, 17 ],
      "id_str" : "2977412266",
      "id" : 2977412266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/farmingmadire\/status\/624185363825881088\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/C2WncjJT6J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKmNPhWWEAAR_3o.jpg",
      "id_str" : "624185321157169152",
      "id" : 624185321157169152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKmNPhWWEAAR_3o.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C2WncjJT6J"
    } ],
    "hashtags" : [ {
      "text" : "cattle",
      "indices" : [ 51, 58 ]
    }, {
      "text" : "limousin",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "AgIE",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624293363857117184",
  "text" : "RT @farmingmadire: Maxie sticking her tongue out\uD83D\uDE02\uD83D\uDE02 #cattle #limousin #AgIE http:\/\/t.co\/C2WncjJT6J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/farmingmadire\/status\/624185363825881088\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/C2WncjJT6J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKmNPhWWEAAR_3o.jpg",
        "id_str" : "624185321157169152",
        "id" : 624185321157169152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKmNPhWWEAAR_3o.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/C2WncjJT6J"
      } ],
      "hashtags" : [ {
        "text" : "cattle",
        "indices" : [ 32, 39 ]
      }, {
        "text" : "limousin",
        "indices" : [ 40, 49 ]
      }, {
        "text" : "AgIE",
        "indices" : [ 50, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624185363825881088",
    "text" : "Maxie sticking her tongue out\uD83D\uDE02\uD83D\uDE02 #cattle #limousin #AgIE http:\/\/t.co\/C2WncjJT6J",
    "id" : 624185363825881088,
    "created_at" : "2015-07-23 11:52:42 +0000",
    "user" : {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "protected" : false,
      "id_str" : "2977412266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723980308874420224\/USPqubG3_normal.jpg",
      "id" : 2977412266,
      "verified" : false
    }
  },
  "id" : 624293363857117184,
  "created_at" : "2015-07-23 19:01:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 98, 103 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623871778293727232",
  "text" : "PCP appt today. Hoping doc can get override for Odansetron. DD was 85 ibs yesterday.. lowest yet. #sick #thyroid #hashimotos",
  "id" : 623871778293727232,
  "created_at" : "2015-07-22 15:06:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teamStripe",
      "screen_name" : "teamStripe",
      "indices" : [ 3, 14 ],
      "id_str" : "2938475619",
      "id" : 2938475619
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 67, 79 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/623624758068953088\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/blFZuiaEzn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKePVUFWEAA1txA.jpg",
      "id_str" : "623624669745254400",
      "id" : 623624669745254400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKePVUFWEAA1txA.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/blFZuiaEzn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/623624758068953088\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/blFZuiaEzn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKePVWoWEAAhA8m.jpg",
      "id_str" : "623624670428925952",
      "id" : 623624670428925952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKePVWoWEAAhA8m.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/blFZuiaEzn"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/623624758068953088\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/blFZuiaEzn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKePVaWWUAE6upW.jpg",
      "id_str" : "623624671427186689",
      "id" : 623624671427186689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKePVaWWUAE6upW.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/blFZuiaEzn"
    } ],
    "hashtags" : [ {
      "text" : "teamStripe",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "yearofmaking",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623670116279042048",
  "text" : "RT @TeamStripe: Lady H meets the heifers #teamStripe #yearofmaking @ErinEFarley http:\/\/t.co\/blFZuiaEzn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 51, 63 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/623624758068953088\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/blFZuiaEzn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKePVUFWEAA1txA.jpg",
        "id_str" : "623624669745254400",
        "id" : 623624669745254400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKePVUFWEAA1txA.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/blFZuiaEzn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/623624758068953088\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/blFZuiaEzn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKePVWoWEAAhA8m.jpg",
        "id_str" : "623624670428925952",
        "id" : 623624670428925952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKePVWoWEAAhA8m.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/blFZuiaEzn"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/623624758068953088\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/blFZuiaEzn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKePVaWWUAE6upW.jpg",
        "id_str" : "623624671427186689",
        "id" : 623624671427186689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKePVaWWUAE6upW.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/blFZuiaEzn"
      } ],
      "hashtags" : [ {
        "text" : "teamStripe",
        "indices" : [ 25, 36 ]
      }, {
        "text" : "yearofmaking",
        "indices" : [ 37, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623624758068953088",
    "text" : "Lady H meets the heifers #teamStripe #yearofmaking @ErinEFarley http:\/\/t.co\/blFZuiaEzn",
    "id" : 623624758068953088,
    "created_at" : "2015-07-21 22:45:03 +0000",
    "user" : {
      "name" : "teamStripe",
      "screen_name" : "teamStripe",
      "protected" : false,
      "id_str" : "2938475619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620189924915048448\/JFbRz-QX_normal.jpg",
      "id" : 2938475619,
      "verified" : false
    }
  },
  "id" : 623670116279042048,
  "created_at" : "2015-07-22 01:45:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/aEc6D22oF3",
      "expanded_url" : "https:\/\/vine.co\/v\/e6jgIMJXWLg",
      "display_url" : "vine.co\/v\/e6jgIMJXWLg"
    } ]
  },
  "geo" : { },
  "id_str" : "623669575280918528",
  "text" : "RT @ZwartblesIE: Nosy noisy neighbours https:\/\/t.co\/aEc6D22oF3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/aEc6D22oF3",
        "expanded_url" : "https:\/\/vine.co\/v\/e6jgIMJXWLg",
        "display_url" : "vine.co\/v\/e6jgIMJXWLg"
      } ]
    },
    "geo" : { },
    "id_str" : "623600085813886976",
    "text" : "Nosy noisy neighbours https:\/\/t.co\/aEc6D22oF3",
    "id" : 623600085813886976,
    "created_at" : "2015-07-21 21:07:01 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 623669575280918528,
  "created_at" : "2015-07-22 01:43:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StackSocial",
      "screen_name" : "StackSocial",
      "indices" : [ 75, 87 ],
      "id_str" : "243742269",
      "id" : 243742269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/9PcO9Y9e5b",
      "expanded_url" : "https:\/\/stacksocial.com\/sales\/free-learn-to-cook-learn-to-learn-with-the-4-hour-chef-audiobook?rid=1070557",
      "display_url" : "stacksocial.com\/sales\/free-lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623507691026149376",
  "text" : "Get it free: Free: 'The 4-Hour Chef' Audiobook https:\/\/t.co\/9PcO9Y9e5b via @StackSocial",
  "id" : 623507691026149376,
  "created_at" : "2015-07-21 14:59:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/h5H6y5vkAD",
      "expanded_url" : "https:\/\/twitter.com\/dhammagirl\/status\/623154765019615232",
      "display_url" : "twitter.com\/dhammagirl\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623271430961147904",
  "text" : "LOL https:\/\/t.co\/h5H6y5vkAD",
  "id" : 623271430961147904,
  "created_at" : "2015-07-20 23:21:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ooijpolder",
      "screen_name" : "ooijpolder",
      "indices" : [ 3, 14 ],
      "id_str" : "230406620",
      "id" : 230406620
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ooijpolder\/status\/623174760386678784\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/cJD0qiLsY6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKX2JGFWUAEuXxa.jpg",
      "id_str" : "623174759572983809",
      "id" : 623174759572983809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKX2JGFWUAEuXxa.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cJD0qiLsY6"
    } ],
    "hashtags" : [ {
      "text" : "galloway",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "kalf",
      "indices" : [ 36, 41 ]
    }, {
      "text" : "ooijpolder",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623267819539562497",
  "text" : "RT @ooijpolder: Kiekeboe! #galloway #kalf #ooijpolder http:\/\/t.co\/cJD0qiLsY6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ooijpolder\/status\/623174760386678784\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/cJD0qiLsY6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKX2JGFWUAEuXxa.jpg",
        "id_str" : "623174759572983809",
        "id" : 623174759572983809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKX2JGFWUAEuXxa.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cJD0qiLsY6"
      } ],
      "hashtags" : [ {
        "text" : "galloway",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "kalf",
        "indices" : [ 20, 25 ]
      }, {
        "text" : "ooijpolder",
        "indices" : [ 26, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623174760386678784",
    "text" : "Kiekeboe! #galloway #kalf #ooijpolder http:\/\/t.co\/cJD0qiLsY6",
    "id" : 623174760386678784,
    "created_at" : "2015-07-20 16:56:55 +0000",
    "user" : {
      "name" : "Ooijpolder",
      "screen_name" : "ooijpolder",
      "protected" : false,
      "id_str" : "230406620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659317988902981632\/Z-MSRlib_normal.png",
      "id" : 230406620,
      "verified" : false
    }
  },
  "id" : 623267819539562497,
  "created_at" : "2015-07-20 23:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "indices" : [ 3, 17 ],
      "id_str" : "216776631",
      "id" : 216776631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623267528320663552",
  "text" : "RT @BernieSanders: We want a nation where young black men and women can live without fear of being falsely arrested, beaten or killed. #Bla\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackLivesMatter",
        "indices" : [ 116, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622854234573160449",
    "text" : "We want a nation where young black men and women can live without fear of being falsely arrested, beaten or killed. #BlackLivesMatter",
    "id" : 622854234573160449,
    "created_at" : "2015-07-19 19:43:16 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "protected" : false,
      "id_str" : "216776631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794596124686487552\/kqpbolIc_normal.jpg",
      "id" : 216776631,
      "verified" : true
    }
  },
  "id" : 623267528320663552,
  "created_at" : "2015-07-20 23:05:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623263610303852544",
  "text" : "DD doesnt want to take anything until she sees new endo... poor kid.",
  "id" : 623263610303852544,
  "created_at" : "2015-07-20 22:49:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623263081666363392",
  "text" : "the doc there gave levo 12.5 becuz DD said the 25 was making her ill after taking. she rx'd prednisone for the inflamed thyroid.",
  "id" : 623263081666363392,
  "created_at" : "2015-07-20 22:47:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623262657664131072",
  "text" : "omgoodness.. todays endo visit.. o-O. the endo wasnt there! we saw another doc in the group. they didnt have the U\/S done on June 30.",
  "id" : 623262657664131072,
  "created_at" : "2015-07-20 22:46:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffani Cameron",
      "screen_name" : "SnarkySteff",
      "indices" : [ 3, 15 ],
      "id_str" : "14523404",
      "id" : 14523404
    }, {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 20, 30 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623166644660109312",
  "text" : "RT @SnarkySteff: So @ShaunKing is detailing death of another woman in police custody he says warrants a federal investigation. Follow #Caro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shaun King",
        "screen_name" : "ShaunKing",
        "indices" : [ 3, 13 ],
        "id_str" : "755113",
        "id" : 755113
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CarolineSmall",
        "indices" : [ 117, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623165672718123008",
    "text" : "So @ShaunKing is detailing death of another woman in police custody he says warrants a federal investigation. Follow #CarolineSmall's story.",
    "id" : 623165672718123008,
    "created_at" : "2015-07-20 16:20:48 +0000",
    "user" : {
      "name" : "Steffani Cameron",
      "screen_name" : "SnarkySteff",
      "protected" : false,
      "id_str" : "14523404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737169314109739009\/447DLb8w_normal.jpg",
      "id" : 14523404,
      "verified" : false
    }
  },
  "id" : 623166644660109312,
  "created_at" : "2015-07-20 16:24:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "indices" : [ 3, 12 ],
      "id_str" : "1316959200",
      "id" : 1316959200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/623158938729586688\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/I5QsTMyDPN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKXnvazWcAAfKkY.jpg",
      "id_str" : "623158925295251456",
      "id" : 623158925295251456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKXnvazWcAAfKkY.jpg",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/I5QsTMyDPN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623159611349184512",
  "text" : "RT @zacaplus: http:\/\/t.co\/I5QsTMyDPN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/623158938729586688\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/I5QsTMyDPN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKXnvazWcAAfKkY.jpg",
        "id_str" : "623158925295251456",
        "id" : 623158925295251456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKXnvazWcAAfKkY.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/I5QsTMyDPN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623158938729586688",
    "text" : "http:\/\/t.co\/I5QsTMyDPN",
    "id" : 623158938729586688,
    "created_at" : "2015-07-20 15:54:03 +0000",
    "user" : {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "protected" : false,
      "id_str" : "1316959200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711110597593702400\/FL6-Tb30_normal.jpg",
      "id" : 1316959200,
      "verified" : false
    }
  },
  "id" : 623159611349184512,
  "created_at" : "2015-07-20 15:56:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PattyHankins",
      "screen_name" : "PattyHankins",
      "indices" : [ 3, 16 ],
      "id_str" : "13532012",
      "id" : 13532012
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PattyHankins\/status\/623155929714831360\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nvOP5pC6gO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJlKWwoUwAAVY2w.jpg",
      "id_str" : "619608178611765248",
      "id" : 619608178611765248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJlKWwoUwAAVY2w.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/nvOP5pC6gO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/RF7dhUxvD4",
      "expanded_url" : "http:\/\/www.beautifulflowerpictures.com\/blog\/new-photo-wisteria-and-azaleas\/",
      "display_url" : "beautifulflowerpictures.com\/blog\/new-photo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "623156730843766784",
  "text" : "RT @PattyHankins: New photo: Wisteria &amp; Azalea http:\/\/t.co\/RF7dhUxvD4 http:\/\/t.co\/nvOP5pC6gO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PattyHankins\/status\/623155929714831360\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/nvOP5pC6gO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJlKWwoUwAAVY2w.jpg",
        "id_str" : "619608178611765248",
        "id" : 619608178611765248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJlKWwoUwAAVY2w.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/nvOP5pC6gO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/RF7dhUxvD4",
        "expanded_url" : "http:\/\/www.beautifulflowerpictures.com\/blog\/new-photo-wisteria-and-azaleas\/",
        "display_url" : "beautifulflowerpictures.com\/blog\/new-photo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623155929714831360",
    "text" : "New photo: Wisteria &amp; Azalea http:\/\/t.co\/RF7dhUxvD4 http:\/\/t.co\/nvOP5pC6gO",
    "id" : 623155929714831360,
    "created_at" : "2015-07-20 15:42:05 +0000",
    "user" : {
      "name" : "PattyHankins",
      "screen_name" : "PattyHankins",
      "protected" : false,
      "id_str" : "13532012",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447972589\/ce1c67ef8c93397094d2835aae2e7c26_normal.jpeg",
      "id" : 13532012,
      "verified" : false
    }
  },
  "id" : 623156730843766784,
  "created_at" : "2015-07-20 15:45:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EarthSky",
      "screen_name" : "earthskyscience",
      "indices" : [ 3, 19 ],
      "id_str" : "22167056",
      "id" : 22167056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/67JZCEdulm",
      "expanded_url" : "http:\/\/bit.ly\/1HKOa0b",
      "display_url" : "bit.ly\/1HKOa0b"
    } ]
  },
  "geo" : { },
  "id_str" : "623147626578464768",
  "text" : "RT @earthskyscience: Best photos of the comet\nhttp:\/\/t.co\/67JZCEdulm\n\nPhoto from this weekend by Amit Ashok Kamble in New Zealand http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/earthskyscience\/status\/623146658155626496\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/IMUS06uUzf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKXclXuXAAAJ86N.jpg",
        "id_str" : "623146658042413056",
        "id" : 623146658042413056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKXclXuXAAAJ86N.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IMUS06uUzf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/67JZCEdulm",
        "expanded_url" : "http:\/\/bit.ly\/1HKOa0b",
        "display_url" : "bit.ly\/1HKOa0b"
      } ]
    },
    "geo" : { },
    "id_str" : "623146658155626496",
    "text" : "Best photos of the comet\nhttp:\/\/t.co\/67JZCEdulm\n\nPhoto from this weekend by Amit Ashok Kamble in New Zealand http:\/\/t.co\/IMUS06uUzf",
    "id" : 623146658155626496,
    "created_at" : "2015-07-20 15:05:15 +0000",
    "user" : {
      "name" : "EarthSky",
      "screen_name" : "earthskyscience",
      "protected" : false,
      "id_str" : "22167056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2577969326\/8qhuwbnqj34jtoad36wy_normal.png",
      "id" : 22167056,
      "verified" : false
    }
  },
  "id" : 623147626578464768,
  "created_at" : "2015-07-20 15:09:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623120798761492480",
  "text" : "RT @HoodedMan: Those in charge don't want true change, of course. They're pleased with the world as it is, no matter how bad it is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623119043160113152",
    "text" : "Those in charge don't want true change, of course. They're pleased with the world as it is, no matter how bad it is.",
    "id" : 623119043160113152,
    "created_at" : "2015-07-20 13:15:31 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 623120798761492480,
  "created_at" : "2015-07-20 13:22:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623114898101411840",
  "text" : "RT @ZachsMind: we're gonna need a new paradigm. we've tried the extremes and we tried moderation. none of these things work in practice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622971556793184256",
    "text" : "we're gonna need a new paradigm. we've tried the extremes and we tried moderation. none of these things work in practice.",
    "id" : 622971556793184256,
    "created_at" : "2015-07-20 03:29:28 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 623114898101411840,
  "created_at" : "2015-07-20 12:59:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elan gale",
      "screen_name" : "theyearofelan",
      "indices" : [ 3, 17 ],
      "id_str" : "20012063",
      "id" : 20012063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623114406914859008",
  "text" : "RT @theyearofelan: Maybe being delusional is actually just the best way to get through life!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623029874601492481",
    "text" : "Maybe being delusional is actually just the best way to get through life!",
    "id" : 623029874601492481,
    "created_at" : "2015-07-20 07:21:12 +0000",
    "user" : {
      "name" : "elan gale",
      "screen_name" : "theyearofelan",
      "protected" : false,
      "id_str" : "20012063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3334977351\/db58b880e01fdea08cc8152d75d484f5_normal.jpeg",
      "id" : 20012063,
      "verified" : true
    }
  },
  "id" : 623114406914859008,
  "created_at" : "2015-07-20 12:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623113281398534144",
  "text" : "getting myself all worked up over endo appt today. i just know he's rxing vit D and thats it. i need to be strong and stand up for my DD.",
  "id" : 623113281398534144,
  "created_at" : "2015-07-20 12:52:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lorraine cumming",
      "screen_name" : "wildlifelass",
      "indices" : [ 3, 16 ],
      "id_str" : "526710903",
      "id" : 526710903
    }, {
      "name" : "SaveOurSparrows",
      "screen_name" : "SaveOurSparrows",
      "indices" : [ 18, 34 ],
      "id_str" : "3299796214",
      "id" : 3299796214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622873732219031552",
  "text" : "RT @wildlifelass: @SaveOurSparrows my favourite sequence of one of the little fledglings at our holiday feeders recently.....bless x http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SaveOurSparrows",
        "screen_name" : "SaveOurSparrows",
        "indices" : [ 0, 16 ],
        "id_str" : "3299796214",
        "id" : 3299796214
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/619630172858372096\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/boHxyKbtv7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJleVVWWsAAVZol.jpg",
        "id_str" : "619630144341323776",
        "id" : 619630144341323776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJleVVWWsAAVZol.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/boHxyKbtv7"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/619630172858372096\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/boHxyKbtv7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJleV1sWwAAi7Mc.jpg",
        "id_str" : "619630153023537152",
        "id" : 619630153023537152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJleV1sWwAAi7Mc.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/boHxyKbtv7"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/wildlifelass\/status\/619630172858372096\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/boHxyKbtv7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJleWbiWsAAN4hd.jpg",
        "id_str" : "619630163182137344",
        "id" : 619630163182137344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJleWbiWsAAN4hd.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/boHxyKbtv7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619630172858372096",
    "in_reply_to_user_id" : 3299796214,
    "text" : "@SaveOurSparrows my favourite sequence of one of the little fledglings at our holiday feeders recently.....bless x http:\/\/t.co\/boHxyKbtv7",
    "id" : 619630172858372096,
    "created_at" : "2015-07-10 22:12:00 +0000",
    "in_reply_to_screen_name" : "SaveOurSparrows",
    "in_reply_to_user_id_str" : "3299796214",
    "user" : {
      "name" : "lorraine cumming",
      "screen_name" : "wildlifelass",
      "protected" : false,
      "id_str" : "526710903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686952360673996800\/EGTFCaqx_normal.jpg",
      "id" : 526710903,
      "verified" : false
    }
  },
  "id" : 622873732219031552,
  "created_at" : "2015-07-19 21:00:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hyperparathyroid",
      "indices" : [ 44, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622868962079076352",
  "text" : "hmm.. low vit d and high calcium related to #hyperparathyroid",
  "id" : 622868962079076352,
  "created_at" : "2015-07-19 20:41:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ondansetron",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622824430364966912",
  "text" : "kid ran out out july 10 (2x\/day).. insurance only covers 21 pills over 23 days? wth is that about? ppl get high on it or what? #ondansetron",
  "id" : 622824430364966912,
  "created_at" : "2015-07-19 17:44:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rant",
      "indices" : [ 8, 13 ]
    }, {
      "text" : "ondansetron",
      "indices" : [ 34, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622823854453432321",
  "text" : "arrgg.. #rant thought I could get #ondansetron refill today.. nope. insurance wont let it go through. now cvs says we can get it friday.",
  "id" : 622823854453432321,
  "created_at" : "2015-07-19 17:42:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622784259929935872",
  "geo" : { },
  "id_str" : "622810917634473984",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time oh jeezus.. ((hugs))",
  "id" : 622810917634473984,
  "in_reply_to_status_id" : 622784259929935872,
  "created_at" : "2015-07-19 16:51:08 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/6rXyzzRI7M",
      "expanded_url" : "https:\/\/twitter.com\/aliceinthewater\/status\/622094282866884608",
      "display_url" : "twitter.com\/aliceinthewate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622780957213523968",
  "text" : "i can only hope.. https:\/\/t.co\/6rXyzzRI7M",
  "id" : 622780957213523968,
  "created_at" : "2015-07-19 14:52:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thecrazysheeplady",
      "screen_name" : "crazysheeplady",
      "indices" : [ 3, 18 ],
      "id_str" : "20524646",
      "id" : 20524646
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/crazysheeplady\/status\/622564511673942016\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/elHUji35Nx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKPLH_GWIAA2K17.jpg",
      "id_str" : "622564511564832768",
      "id" : 622564511564832768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKPLH_GWIAA2K17.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1210,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/elHUji35Nx"
    } ],
    "hashtags" : [ {
      "text" : "ilovemysheeps",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622584818094723072",
  "text" : "RT @crazysheeplady: Maisie, sleeping off the hot afternoon. #ilovemysheeps http:\/\/t.co\/elHUji35Nx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/crazysheeplady\/status\/622564511673942016\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/elHUji35Nx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKPLH_GWIAA2K17.jpg",
        "id_str" : "622564511564832768",
        "id" : 622564511564832768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKPLH_GWIAA2K17.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1210,
          "resize" : "fit",
          "w" : 1210
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/elHUji35Nx"
      } ],
      "hashtags" : [ {
        "text" : "ilovemysheeps",
        "indices" : [ 40, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622564511673942016",
    "text" : "Maisie, sleeping off the hot afternoon. #ilovemysheeps http:\/\/t.co\/elHUji35Nx",
    "id" : 622564511673942016,
    "created_at" : "2015-07-19 00:32:00 +0000",
    "user" : {
      "name" : "thecrazysheeplady",
      "screen_name" : "crazysheeplady",
      "protected" : false,
      "id_str" : "20524646",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77050420\/me_and_punkin_small_normal.jpg",
      "id" : 20524646,
      "verified" : false
    }
  },
  "id" : 622584818094723072,
  "created_at" : "2015-07-19 01:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "wood works crando",
      "screen_name" : "crando0630",
      "indices" : [ 89, 100 ],
      "id_str" : "362750077",
      "id" : 362750077
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/EfIprVfMBt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jNWgAALhNh.jpg",
      "id_str" : "622547805245177856",
      "id" : 622547805245177856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jNWgAALhNh.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EfIprVfMBt"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/EfIprVfMBt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jOWcAIwwCy.jpg",
      "id_str" : "622547805249368066",
      "id" : 622547805249368066,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jOWcAIwwCy.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EfIprVfMBt"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/EfIprVfMBt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jMWwAE55AI.jpg",
      "id_str" : "622547805240999937",
      "id" : 622547805240999937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jMWwAE55AI.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EfIprVfMBt"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/EfIprVfMBt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jRW8AEc0ft.jpg",
      "id_str" : "622547805261983745",
      "id" : 622547805261983745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jRW8AEc0ft.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EfIprVfMBt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622558180887908352",
  "text" : "RT @ErinEFarley: Always nice to have help when taking photos. Got one sheep down already @crando0630. http:\/\/t.co\/EfIprVfMBt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "wood works crando",
        "screen_name" : "crando0630",
        "indices" : [ 72, 83 ],
        "id_str" : "362750077",
        "id" : 362750077
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/EfIprVfMBt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jNWgAALhNh.jpg",
        "id_str" : "622547805245177856",
        "id" : 622547805245177856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jNWgAALhNh.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EfIprVfMBt"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/EfIprVfMBt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jOWcAIwwCy.jpg",
        "id_str" : "622547805249368066",
        "id" : 622547805249368066,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jOWcAIwwCy.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EfIprVfMBt"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/EfIprVfMBt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jMWwAE55AI.jpg",
        "id_str" : "622547805240999937",
        "id" : 622547805240999937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jMWwAE55AI.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/EfIprVfMBt"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622547813310709760\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/EfIprVfMBt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKO77jRW8AEc0ft.jpg",
        "id_str" : "622547805261983745",
        "id" : 622547805261983745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKO77jRW8AEc0ft.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/EfIprVfMBt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622547813310709760",
    "text" : "Always nice to have help when taking photos. Got one sheep down already @crando0630. http:\/\/t.co\/EfIprVfMBt",
    "id" : 622547813310709760,
    "created_at" : "2015-07-18 23:25:39 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 622558180887908352,
  "created_at" : "2015-07-19 00:06:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "chronicillness",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/lsVTlVreHt",
      "expanded_url" : "https:\/\/shar.es\/1s7CPz",
      "display_url" : "shar.es\/1s7CPz"
    } ]
  },
  "geo" : { },
  "id_str" : "622506229361975296",
  "text" : "good &gt;&gt; The Spoon Theory written by Christine Miserandino https:\/\/t.co\/lsVTlVreHt #sick #chronicillness",
  "id" : 622506229361975296,
  "created_at" : "2015-07-18 20:40:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622496284356780032",
  "geo" : { },
  "id_str" : "622502445252538368",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre been following HTM here and on FB. just added JSP from yr recommend. thanks : )",
  "id" : 622502445252538368,
  "in_reply_to_status_id" : 622496284356780032,
  "created_at" : "2015-07-18 20:25:23 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622478399743901696",
  "text" : "writing this stuff out is helping me process it : )",
  "id" : 622478399743901696,
  "created_at" : "2015-07-18 18:49:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622478158114258944",
  "text" : "and maybe not weird but seems like it to me.. one day her body went kaplooey and has been off since then. #sick",
  "id" : 622478158114258944,
  "created_at" : "2015-07-18 18:48:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashimotos",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "sick",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622475606178066432",
  "text" : "docs basing symptoms on anxiety. endo dx #hashimotos but doesnt think thats cause of feeling #sick, weight loss. so im researching.",
  "id" : 622475606178066432,
  "created_at" : "2015-07-18 18:38:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 108, 113 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622474720684978176",
  "text" : "her tsh in range 07\/07 but quite variable so who knows if that means much? jumped 8.53 to 14 (er) in 2 days #sick #thyroid #hashimotos",
  "id" : 622474720684978176,
  "created_at" : "2015-07-18 18:35:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622472562895884288",
  "text" : "fasting glucose 92 (65-99); LDL cholest. 136 (&lt;130); calcium, protein, albumin high end of range. #sick",
  "id" : 622472562895884288,
  "created_at" : "2015-07-18 18:26:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622470857080852480",
  "text" : "ferritin 28 (10-154) in range but low enough to cause symptoms? along w def vit D 17 (&gt;30) maybe absorption issues? hmm.. #sick",
  "id" : 622470857080852480,
  "created_at" : "2015-07-18 18:19:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622440977995837440\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/QcsrPolNhk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKNaxYMWcAAnirn.jpg",
      "id_str" : "622440977861603328",
      "id" : 622440977861603328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKNaxYMWcAAnirn.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1621,
        "resize" : "fit",
        "w" : 1216
      } ],
      "display_url" : "pic.twitter.com\/QcsrPolNhk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622446053783154688",
  "text" : "RT @ErinEFarley: Have had this puzzle for ages. Just noticed the tongues! \uD83D\uDE1B\uD83D\uDC2E\uD83D\uDE1B http:\/\/t.co\/QcsrPolNhk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/622440977995837440\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/QcsrPolNhk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKNaxYMWcAAnirn.jpg",
        "id_str" : "622440977861603328",
        "id" : 622440977861603328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKNaxYMWcAAnirn.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1621,
          "resize" : "fit",
          "w" : 1216
        } ],
        "display_url" : "pic.twitter.com\/QcsrPolNhk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622440977995837440",
    "text" : "Have had this puzzle for ages. Just noticed the tongues! \uD83D\uDE1B\uD83D\uDC2E\uD83D\uDE1B http:\/\/t.co\/QcsrPolNhk",
    "id" : 622440977995837440,
    "created_at" : "2015-07-18 16:21:08 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 622446053783154688,
  "created_at" : "2015-07-18 16:41:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622443824477011968",
  "text" : "been pouring over er labs, endo labs. checking definitions, values, ref ranges.. can I get college credit for this? lol",
  "id" : 622443824477011968,
  "created_at" : "2015-07-18 16:32:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "indices" : [ 3, 15 ],
      "id_str" : "954590804",
      "id" : 954590804
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/622152071203188736\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/pBrCyKZBYN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKJUAysWcAACeMC.jpg",
      "id_str" : "622152071115075584",
      "id" : 622152071115075584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKJUAysWcAACeMC.jpg",
      "sizes" : [ {
        "h" : 628,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pBrCyKZBYN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622239357727055873",
  "text" : "RT @planetepics: A bird fell asleep in my hair http:\/\/t.co\/pBrCyKZBYN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/planetepics\/status\/622152071203188736\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/pBrCyKZBYN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKJUAysWcAACeMC.jpg",
        "id_str" : "622152071115075584",
        "id" : 622152071115075584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKJUAysWcAACeMC.jpg",
        "sizes" : [ {
          "h" : 628,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pBrCyKZBYN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622152071203188736",
    "text" : "A bird fell asleep in my hair http:\/\/t.co\/pBrCyKZBYN",
    "id" : 622152071203188736,
    "created_at" : "2015-07-17 21:13:07 +0000",
    "user" : {
      "name" : "Life on Earth",
      "screen_name" : "planetepics",
      "protected" : false,
      "id_str" : "954590804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463495027600015360\/_Jyj6WD6_normal.jpeg",
      "id" : 954590804,
      "verified" : false
    }
  },
  "id" : 622239357727055873,
  "created_at" : "2015-07-18 02:59:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "indices" : [ 3, 17 ],
      "id_str" : "216776631",
      "id" : 216776631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622233903173095424",
  "text" : "RT @BernieSanders: No president, not even the best one, can bring about the changes that we need in this country unless there is a politica\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622232598765420544",
    "text" : "No president, not even the best one, can bring about the changes that we need in this country unless there is a political revolution.",
    "id" : 622232598765420544,
    "created_at" : "2015-07-18 02:33:06 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "protected" : false,
      "id_str" : "216776631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794596124686487552\/kqpbolIc_normal.jpg",
      "id" : 216776631,
      "verified" : true
    }
  },
  "id" : 622233903173095424,
  "created_at" : "2015-07-18 02:38:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622232609754583040",
  "text" : "@Lluminous_ I'm sorry dear kitty. Smooches.",
  "id" : 622232609754583040,
  "created_at" : "2015-07-18 02:33:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Paul Turner",
      "screen_name" : "JesusNeedsNewPR",
      "indices" : [ 3, 19 ],
      "id_str" : "727580030084251648",
      "id" : 727580030084251648
    }, {
      "name" : "franklingraham",
      "screen_name" : "franklingraham",
      "indices" : [ 40, 55 ],
      "id_str" : "16570984",
      "id" : 16570984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/mNmayDdiWG",
      "expanded_url" : "http:\/\/ift.tt\/1Olptfk",
      "display_url" : "ift.tt\/1Olptfk"
    } ]
  },
  "geo" : { },
  "id_str" : "622223236848320512",
  "text" : "RT @JesusNeedsNewPR: Christian friends, @FranklinGraham needs to hear from you. He needs to hear over and over \u2026 http:\/\/t.co\/mNmayDdiWG htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "franklingraham",
        "screen_name" : "franklingraham",
        "indices" : [ 19, 34 ],
        "id_str" : "16570984",
        "id" : 16570984
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JesusNeedsNewPR\/status\/622222631748653058\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/6eDto9qOor",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKKUL9PWcAEWfrp.jpg",
        "id_str" : "622222631668969473",
        "id" : 622222631668969473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKKUL9PWcAEWfrp.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/6eDto9qOor"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/mNmayDdiWG",
        "expanded_url" : "http:\/\/ift.tt\/1Olptfk",
        "display_url" : "ift.tt\/1Olptfk"
      } ]
    },
    "geo" : { },
    "id_str" : "622222631748653058",
    "text" : "Christian friends, @FranklinGraham needs to hear from you. He needs to hear over and over \u2026 http:\/\/t.co\/mNmayDdiWG http:\/\/t.co\/6eDto9qOor",
    "id" : 622222631748653058,
    "created_at" : "2015-07-18 01:53:30 +0000",
    "user" : {
      "name" : "Matthew Paul Turner",
      "screen_name" : "HeyMPT",
      "protected" : false,
      "id_str" : "10206812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749619882552098816\/HgjwUHtr_normal.jpg",
      "id" : 10206812,
      "verified" : false
    }
  },
  "id" : 622223236848320512,
  "created_at" : "2015-07-18 01:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622221859979952128",
  "text" : "RT @fairlyspiritual: You changed your profile picture, so I really have no idea who you are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622221234386763777",
    "text" : "You changed your profile picture, so I really have no idea who you are.",
    "id" : 622221234386763777,
    "created_at" : "2015-07-18 01:47:57 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 622221859979952128,
  "created_at" : "2015-07-18 01:50:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "indices" : [ 3, 15 ],
      "id_str" : "2830503949",
      "id" : 2830503949
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/622219913659166720\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/dARqWtSU16",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKKRtrUVEAETAZw.jpg",
      "id_str" : "622219912438681601",
      "id" : 622219912438681601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKKRtrUVEAETAZw.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2522,
        "resize" : "fit",
        "w" : 4107
      } ],
      "display_url" : "pic.twitter.com\/dARqWtSU16"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622221358081159168",
  "text" : "RT @ChippyCMunk: So cool to see http:\/\/t.co\/dARqWtSU16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChippyCMunk\/status\/622219913659166720\/photo\/1",
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/dARqWtSU16",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKKRtrUVEAETAZw.jpg",
        "id_str" : "622219912438681601",
        "id" : 622219912438681601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKKRtrUVEAETAZw.jpg",
        "sizes" : [ {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2522,
          "resize" : "fit",
          "w" : 4107
        } ],
        "display_url" : "pic.twitter.com\/dARqWtSU16"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622219913659166720",
    "text" : "So cool to see http:\/\/t.co\/dARqWtSU16",
    "id" : 622219913659166720,
    "created_at" : "2015-07-18 01:42:42 +0000",
    "user" : {
      "name" : "Chippy Chipmunk",
      "screen_name" : "ChippyCMunk",
      "protected" : false,
      "id_str" : "2830503949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514880688881803264\/hubzdP2R_normal.jpeg",
      "id" : 2830503949,
      "verified" : false
    }
  },
  "id" : 622221358081159168,
  "created_at" : "2015-07-18 01:48:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baby Animals",
      "screen_name" : "BabyAnimalPics",
      "indices" : [ 3, 18 ],
      "id_str" : "1372975219",
      "id" : 1372975219
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BabyAnimalPics\/status\/561685183880257536\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Lm6cygbfqG",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B8uBsstIMAAuF2G.png",
      "id_str" : "561685183452426240",
      "id" : 561685183452426240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B8uBsstIMAAuF2G.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 288
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 288
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 288
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 288
      } ],
      "display_url" : "pic.twitter.com\/Lm6cygbfqG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622209105160241152",
  "text" : "RT @BabyAnimalPics: Cat gets in a fight. Fat cat does his best to help. http:\/\/t.co\/Lm6cygbfqG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BabyAnimalPics\/status\/561685183880257536\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/Lm6cygbfqG",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B8uBsstIMAAuF2G.png",
        "id_str" : "561685183452426240",
        "id" : 561685183452426240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B8uBsstIMAAuF2G.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 288
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 288
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 288
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 288
        } ],
        "display_url" : "pic.twitter.com\/Lm6cygbfqG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622200436733423616",
    "text" : "Cat gets in a fight. Fat cat does his best to help. http:\/\/t.co\/Lm6cygbfqG",
    "id" : 622200436733423616,
    "created_at" : "2015-07-18 00:25:18 +0000",
    "user" : {
      "name" : "Baby Animals",
      "screen_name" : "BabyAnimalPics",
      "protected" : false,
      "id_str" : "1372975219",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674018647833075712\/4AnZjeut_normal.jpg",
      "id" : 1372975219,
      "verified" : false
    }
  },
  "id" : 622209105160241152,
  "created_at" : "2015-07-18 00:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622185983270907905",
  "text" : "@ThePlushGourmet hope she returns shortly and safely to your loving arms.",
  "id" : 622185983270907905,
  "created_at" : "2015-07-17 23:27:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/e4PlCUigqB",
      "expanded_url" : "https:\/\/instagram.com\/p\/5QWW_JHw8d\/",
      "display_url" : "instagram.com\/p\/5QWW_JHw8d\/"
    } ]
  },
  "geo" : { },
  "id_str" : "622185511646531584",
  "text" : "RT @JeremyCShipp: Bird times. https:\/\/t.co\/e4PlCUigqB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 35 ],
        "url" : "https:\/\/t.co\/e4PlCUigqB",
        "expanded_url" : "https:\/\/instagram.com\/p\/5QWW_JHw8d\/",
        "display_url" : "instagram.com\/p\/5QWW_JHw8d\/"
      } ]
    },
    "geo" : { },
    "id_str" : "622183931773906944",
    "text" : "Bird times. https:\/\/t.co\/e4PlCUigqB",
    "id" : 622183931773906944,
    "created_at" : "2015-07-17 23:19:43 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 622185511646531584,
  "created_at" : "2015-07-17 23:26:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622182785508352000",
  "text" : "RT @Irish_Atheist: I'm so excited for another anti-gay straight male Christian explaining how wrong I am for being who I am. https:\/\/t.co\/W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/WwF65XQNlw",
        "expanded_url" : "https:\/\/twitter.com\/prestonsprinkle\/status\/622171282604343296",
        "display_url" : "twitter.com\/prestonsprinkl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622181471403511808",
    "text" : "I'm so excited for another anti-gay straight male Christian explaining how wrong I am for being who I am. https:\/\/t.co\/WwF65XQNlw",
    "id" : 622181471403511808,
    "created_at" : "2015-07-17 23:09:57 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 622182785508352000,
  "created_at" : "2015-07-17 23:15:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steffany Barton",
      "screen_name" : "AngelsInSight",
      "indices" : [ 3, 17 ],
      "id_str" : "107914068",
      "id" : 107914068
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soul",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622088672779837440",
  "text" : "RT @AngelsInSight: Don't try to be right nor fear you're all wrong. Be who you are. Let your #soul shine on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "soul",
        "indices" : [ 74, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622006705518346240",
    "text" : "Don't try to be right nor fear you're all wrong. Be who you are. Let your #soul shine on.",
    "id" : 622006705518346240,
    "created_at" : "2015-07-17 11:35:29 +0000",
    "user" : {
      "name" : "Steffany Barton",
      "screen_name" : "AngelsInSight",
      "protected" : false,
      "id_str" : "107914068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704891116093575169\/rVKHCW8N_normal.jpg",
      "id" : 107914068,
      "verified" : false
    }
  },
  "id" : 622088672779837440,
  "created_at" : "2015-07-17 17:01:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Angel Witch",
      "screen_name" : "carribeth",
      "indices" : [ 3, 13 ],
      "id_str" : "41803502",
      "id" : 41803502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622088474250842112",
  "text" : "RT @carribeth: There should be a cosmic rule where a few times in your life, we each have to live another person's life for one week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622072717500616704",
    "text" : "There should be a cosmic rule where a few times in your life, we each have to live another person's life for one week.",
    "id" : 622072717500616704,
    "created_at" : "2015-07-17 15:57:48 +0000",
    "user" : {
      "name" : "The Angel Witch",
      "screen_name" : "carribeth",
      "protected" : false,
      "id_str" : "41803502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779516772777127937\/4DvKHSbz_normal.jpg",
      "id" : 41803502,
      "verified" : false
    }
  },
  "id" : 622088474250842112,
  "created_at" : "2015-07-17 17:00:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louise Hammond",
      "screen_name" : "techclerk",
      "indices" : [ 3, 13 ],
      "id_str" : "523343125",
      "id" : 523343125
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Izzy",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622083913880596480",
  "text" : "RT @techclerk: #Izzy luvs to chat to the swans every walk, can't believe they still have 8 cygnets, normally only end up with 3 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/techclerk\/status\/621385662940450816\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/85Yheq2lGV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ-a810WIAANcDJ.jpg",
        "id_str" : "621385643629879296",
        "id" : 621385643629879296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ-a810WIAANcDJ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/85Yheq2lGV"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/techclerk\/status\/621385662940450816\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/85Yheq2lGV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ-a814WIAAWRrP.jpg",
        "id_str" : "621385643646656512",
        "id" : 621385643646656512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ-a814WIAAWRrP.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/85Yheq2lGV"
      } ],
      "hashtags" : [ {
        "text" : "Izzy",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621385662940450816",
    "text" : "#Izzy luvs to chat to the swans every walk, can't believe they still have 8 cygnets, normally only end up with 3 http:\/\/t.co\/85Yheq2lGV",
    "id" : 621385662940450816,
    "created_at" : "2015-07-15 18:27:41 +0000",
    "user" : {
      "name" : "Louise Hammond",
      "screen_name" : "techclerk",
      "protected" : false,
      "id_str" : "523343125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573235084091908096\/-Woej5Rp_normal.jpeg",
      "id" : 523343125,
      "verified" : false
    }
  },
  "id" : 622083913880596480,
  "created_at" : "2015-07-17 16:42:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "indices" : [ 3, 13 ],
      "id_str" : "15104467",
      "id" : 15104467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622083716718985220",
  "text" : "RT @FogBelter: No ... Prisons are Profit Engines ... as Wars are. Success or Failure is irrelevant as long as profit is made.  https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/SgYvm29EL5",
        "expanded_url" : "https:\/\/twitter.com\/ryanjreilly\/status\/622079012840587264",
        "display_url" : "twitter.com\/ryanjreilly\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622083483448426496",
    "text" : "No ... Prisons are Profit Engines ... as Wars are. Success or Failure is irrelevant as long as profit is made.  https:\/\/t.co\/SgYvm29EL5",
    "id" : 622083483448426496,
    "created_at" : "2015-07-17 16:40:34 +0000",
    "user" : {
      "name" : "FogBelter",
      "screen_name" : "FogBelter",
      "protected" : false,
      "id_str" : "15104467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/263286875\/Joshua_A_Norton_normal.jpg",
      "id" : 15104467,
      "verified" : false
    }
  },
  "id" : 622083716718985220,
  "created_at" : "2015-07-17 16:41:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tech",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "feedly",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Iuc0nVgnEW",
      "expanded_url" : "http:\/\/scripting.com\/2015\/07\/17\/whatTheInternetActuallyLooksLike.html",
      "display_url" : "scripting.com\/2015\/07\/17\/wha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "622050251566940160",
  "text" : "What the Internet actually looks like http:\/\/t.co\/Iuc0nVgnEW #tech #feedly",
  "id" : 622050251566940160,
  "created_at" : "2015-07-17 14:28:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samia Aibef",
      "screen_name" : "saibef",
      "indices" : [ 3, 10 ],
      "id_str" : "284137630",
      "id" : 284137630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "perspective",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621872640651841536",
  "text" : "RT @saibef: Only thing U sometimes have control over is #perspective. You don't have control over Ur situation. But U've a choice about how\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "perspective",
        "indices" : [ 44, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621613800723091457",
    "text" : "Only thing U sometimes have control over is #perspective. You don't have control over Ur situation. But U've a choice about how U view it.",
    "id" : 621613800723091457,
    "created_at" : "2015-07-16 09:34:13 +0000",
    "user" : {
      "name" : "Samia Aibef",
      "screen_name" : "saibef",
      "protected" : false,
      "id_str" : "284137630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759847752930959361\/s2FNF_pa_normal.jpg",
      "id" : 284137630,
      "verified" : false
    }
  },
  "id" : 621872640651841536,
  "created_at" : "2015-07-17 02:42:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/NBWLWm6thS",
      "expanded_url" : "http:\/\/brucegerencser.net\/2015\/07\/interpreting-the-bible-one-book-endless-interpretations\/",
      "display_url" : "brucegerencser.net\/2015\/07\/interp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621871224889716736",
  "text" : "Interpreting the Bible: One Book, Endless Interpretations\n\nhttp:\/\/t.co\/NBWLWm6thS\n\nSent from FeedLab",
  "id" : 621871224889716736,
  "created_at" : "2015-07-17 02:37:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621848331057106944",
  "geo" : { },
  "id_str" : "621852401746726912",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind oh oh.. please say that about Sanders then... ; )",
  "id" : 621852401746726912,
  "in_reply_to_status_id" : 621848331057106944,
  "created_at" : "2015-07-17 01:22:20 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621831548644519936",
  "text" : "we are all human. we are all evil. there is no line to differentiate between some evil and more evil therefore we are all equal.",
  "id" : 621831548644519936,
  "created_at" : "2015-07-16 23:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621825498654601216",
  "text" : "RT @sarahnmoon: But are you going to call that \"evil?\" Why or why not? Because it doesn't fit your agenda against autonomy of pregnant ppl?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "621821843150897152",
    "geo" : { },
    "id_str" : "621822019798175744",
    "in_reply_to_user_id" : 24254537,
    "text" : "But are you going to call that \"evil?\" Why or why not? Because it doesn't fit your agenda against autonomy of pregnant ppl?",
    "id" : 621822019798175744,
    "in_reply_to_status_id" : 621821843150897152,
    "created_at" : "2015-07-16 23:21:37 +0000",
    "in_reply_to_screen_name" : "GrumpyTheology",
    "in_reply_to_user_id_str" : "24254537",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 621825498654601216,
  "created_at" : "2015-07-16 23:35:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621825437543477248",
  "text" : "RT @sarahnmoon: All those out-of-context quotes about \"saving the organs\" would still apply. Still not the kind of thing to discuss over sa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "621821678113423360",
    "geo" : { },
    "id_str" : "621821843150897152",
    "in_reply_to_user_id" : 24254537,
    "text" : "All those out-of-context quotes about \"saving the organs\" would still apply. Still not the kind of thing to discuss over salad.",
    "id" : 621821843150897152,
    "in_reply_to_status_id" : 621821678113423360,
    "created_at" : "2015-07-16 23:20:54 +0000",
    "in_reply_to_screen_name" : "GrumpyTheology",
    "in_reply_to_user_id_str" : "24254537",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 621825437543477248,
  "created_at" : "2015-07-16 23:35:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621825394270932992",
  "text" : "RT @sarahnmoon: What if fetal tissue was donated by a grieving mother hoping her miscarried child's body could help save lives one day? Sti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621821678113423360",
    "text" : "What if fetal tissue was donated by a grieving mother hoping her miscarried child's body could help save lives one day? Still \"evil?\"",
    "id" : 621821678113423360,
    "created_at" : "2015-07-16 23:20:15 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 621825394270932992,
  "created_at" : "2015-07-16 23:35:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Martin, SJ",
      "screen_name" : "JamesMartinSJ",
      "indices" : [ 3, 17 ],
      "id_str" : "226320142",
      "id" : 226320142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621824591158214656",
  "text" : "RT @JamesMartinSJ: Just as the paralyzed man was carried to Jesus by friends in Mark 2:1-12 \nWe often come to grace carried by others. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/cH2O0NGw4R",
        "expanded_url" : "https:\/\/vine.co\/v\/enFWUxn7aJ3",
        "display_url" : "vine.co\/v\/enFWUxn7aJ3"
      } ]
    },
    "geo" : { },
    "id_str" : "618862294232137729",
    "text" : "Just as the paralyzed man was carried to Jesus by friends in Mark 2:1-12 \nWe often come to grace carried by others. https:\/\/t.co\/cH2O0NGw4R",
    "id" : 618862294232137729,
    "created_at" : "2015-07-08 19:20:43 +0000",
    "user" : {
      "name" : "James Martin, SJ",
      "screen_name" : "JamesMartinSJ",
      "protected" : false,
      "id_str" : "226320142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573235627325591552\/BvUyZbwk_normal.jpeg",
      "id" : 226320142,
      "verified" : true
    }
  },
  "id" : 621824591158214656,
  "created_at" : "2015-07-16 23:31:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruth Graham",
      "screen_name" : "publicroad",
      "indices" : [ 3, 14 ],
      "id_str" : "57048551",
      "id" : 57048551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621824164832411649",
  "text" : "RT @publicroad: Reading comments this AM: \"Celibacy is worth it\" says married guy whose avatar is a photo of himself w\/ his wife. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/publicroad\/status\/620933539694034944\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/KIVR4NNO6h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ3_wuAWsAAzz1O.jpg",
        "id_str" : "620933536095318016",
        "id" : 620933536095318016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ3_wuAWsAAzz1O.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KIVR4NNO6h"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "620729623685517312",
    "geo" : { },
    "id_str" : "620933539694034944",
    "in_reply_to_user_id" : 57048551,
    "text" : "Reading comments this AM: \"Celibacy is worth it\" says married guy whose avatar is a photo of himself w\/ his wife. http:\/\/t.co\/KIVR4NNO6h",
    "id" : 620933539694034944,
    "in_reply_to_status_id" : 620729623685517312,
    "created_at" : "2015-07-14 12:31:06 +0000",
    "in_reply_to_screen_name" : "publicroad",
    "in_reply_to_user_id_str" : "57048551",
    "user" : {
      "name" : "Ruth Graham",
      "screen_name" : "publicroad",
      "protected" : false,
      "id_str" : "57048551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518548593922150400\/44ENUg3__normal.jpeg",
      "id" : 57048551,
      "verified" : false
    }
  },
  "id" : 621824164832411649,
  "created_at" : "2015-07-16 23:30:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ela Enterprise",
      "screen_name" : "vida_ying_yang",
      "indices" : [ 3, 18 ],
      "id_str" : "2763786195",
      "id" : 2763786195
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vida_ying_yang\/status\/615645324837695488\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ohSwVLoFW8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIs2KTmUsAAyBv0.jpg",
      "id_str" : "615645324753809408",
      "id" : 615645324753809408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIs2KTmUsAAyBv0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 880
      } ],
      "display_url" : "pic.twitter.com\/ohSwVLoFW8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621807728558776320",
  "text" : "RT @vida_ying_yang: \uD83C\uDF3B\u2764\uFE0F\uD83D\uDE0A http:\/\/t.co\/ohSwVLoFW8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vida_ying_yang\/status\/615645324837695488\/photo\/1",
        "indices" : [ 5, 27 ],
        "url" : "http:\/\/t.co\/ohSwVLoFW8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIs2KTmUsAAyBv0.jpg",
        "id_str" : "615645324753809408",
        "id" : 615645324753809408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIs2KTmUsAAyBv0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 880
        } ],
        "display_url" : "pic.twitter.com\/ohSwVLoFW8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615645324837695488",
    "text" : "\uD83C\uDF3B\u2764\uFE0F\uD83D\uDE0A http:\/\/t.co\/ohSwVLoFW8",
    "id" : 615645324837695488,
    "created_at" : "2015-06-29 22:17:38 +0000",
    "user" : {
      "name" : "Ela Enterprise",
      "screen_name" : "vida_ying_yang",
      "protected" : false,
      "id_str" : "2763786195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508542917431291905\/r5yrbBYi_normal.jpeg",
      "id" : 2763786195,
      "verified" : false
    }
  },
  "id" : 621807728558776320,
  "created_at" : "2015-07-16 22:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "indices" : [ 3, 17 ],
      "id_str" : "2977412266",
      "id" : 2977412266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/farmingmadire\/status\/621667145076895744\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/cHESkzpYAa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKCa9NbXAAEqieL.jpg",
      "id_str" : "621667124944240641",
      "id" : 621667124944240641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKCa9NbXAAEqieL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cHESkzpYAa"
    } ],
    "hashtags" : [ {
      "text" : "cattle",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "AgIE",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621739895342657536",
  "text" : "RT @farmingmadire: Another selfie from bluebell #cattle #AgIE http:\/\/t.co\/cHESkzpYAa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/farmingmadire\/status\/621667145076895744\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/cHESkzpYAa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKCa9NbXAAEqieL.jpg",
        "id_str" : "621667124944240641",
        "id" : 621667124944240641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKCa9NbXAAEqieL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cHESkzpYAa"
      } ],
      "hashtags" : [ {
        "text" : "cattle",
        "indices" : [ 29, 36 ]
      }, {
        "text" : "AgIE",
        "indices" : [ 37, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621667145076895744",
    "text" : "Another selfie from bluebell #cattle #AgIE http:\/\/t.co\/cHESkzpYAa",
    "id" : 621667145076895744,
    "created_at" : "2015-07-16 13:06:12 +0000",
    "user" : {
      "name" : "Sarah Armstrong",
      "screen_name" : "farmingmadire",
      "protected" : false,
      "id_str" : "2977412266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723980308874420224\/USPqubG3_normal.jpg",
      "id" : 2977412266,
      "verified" : false
    }
  },
  "id" : 621739895342657536,
  "created_at" : "2015-07-16 17:55:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    }, {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 106, 115 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MYmicfpEgU",
      "expanded_url" : "http:\/\/tags.hawksey.info\/",
      "display_url" : "tags.hawksey.info"
    } ]
  },
  "geo" : { },
  "id_str" : "621712853410648064",
  "text" : "RT @mhawksey: Check out TAGS a free Google Sheet template for archiving tweets http:\/\/t.co\/MYmicfpEgU via @mhawksey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Hawksey",
        "screen_name" : "mhawksey",
        "indices" : [ 92, 101 ],
        "id_str" : "13046992",
        "id" : 13046992
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/MYmicfpEgU",
        "expanded_url" : "http:\/\/tags.hawksey.info\/",
        "display_url" : "tags.hawksey.info"
      } ]
    },
    "geo" : { },
    "id_str" : "519769984629624832",
    "text" : "Check out TAGS a free Google Sheet template for archiving tweets http:\/\/t.co\/MYmicfpEgU via @mhawksey",
    "id" : 519769984629624832,
    "created_at" : "2014-10-08 08:43:15 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 621712853410648064,
  "created_at" : "2015-07-16 16:07:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SHEREDWOLF\/status\/621694495923552256\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/x5H4COCG2D",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CKCz2UpUYAAoOds.png",
      "id_str" : "621694494413447168",
      "id" : 621694494413447168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CKCz2UpUYAAoOds.png",
      "sizes" : [ {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 390
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 390
      }, {
        "h" : 205,
        "resize" : "fit",
        "w" : 390
      } ],
      "display_url" : "pic.twitter.com\/x5H4COCG2D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621698171790585856",
  "text" : "RT @SHEREDWOLF: :) http:\/\/t.co\/x5H4COCG2D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SHEREDWOLF\/status\/621694495923552256\/photo\/1",
        "indices" : [ 3, 25 ],
        "url" : "http:\/\/t.co\/x5H4COCG2D",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CKCz2UpUYAAoOds.png",
        "id_str" : "621694494413447168",
        "id" : 621694494413447168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CKCz2UpUYAAoOds.png",
        "sizes" : [ {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 390
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 390
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 390
        } ],
        "display_url" : "pic.twitter.com\/x5H4COCG2D"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621694495923552256",
    "text" : ":) http:\/\/t.co\/x5H4COCG2D",
    "id" : 621694495923552256,
    "created_at" : "2015-07-16 14:54:53 +0000",
    "user" : {
      "name" : "\uADF8\uB140 - \uB291\uB300",
      "screen_name" : "wolves_my_love",
      "protected" : false,
      "id_str" : "560545385",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752248927899021313\/APaMam9p_normal.jpg",
      "id" : 560545385,
      "verified" : false
    }
  },
  "id" : 621698171790585856,
  "created_at" : "2015-07-16 15:09:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christina Coleman",
      "screen_name" : "ChrissyCole",
      "indices" : [ 3, 15 ],
      "id_str" : "25545470",
      "id" : 25545470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatHappenedToSandraBland",
      "indices" : [ 104, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621697908711231488",
  "text" : "RT @ChrissyCole: She drove to Texas for a new job. Three days later, she was found dead in a jail cell. #WhatHappenedToSandraBland? http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatHappenedToSandraBland",
        "indices" : [ 87, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ajoXzlt9Zx",
        "expanded_url" : "http:\/\/bit.ly\/1GofVJO",
        "display_url" : "bit.ly\/1GofVJO"
      } ]
    },
    "geo" : { },
    "id_str" : "621687096051388416",
    "text" : "She drove to Texas for a new job. Three days later, she was found dead in a jail cell. #WhatHappenedToSandraBland? http:\/\/t.co\/ajoXzlt9Zx",
    "id" : 621687096051388416,
    "created_at" : "2015-07-16 14:25:28 +0000",
    "user" : {
      "name" : "Christina Coleman",
      "screen_name" : "ChrissyCole",
      "protected" : false,
      "id_str" : "25545470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504313698828029952\/wIQu2FwW_normal.jpeg",
      "id" : 25545470,
      "verified" : false
    }
  },
  "id" : 621697908711231488,
  "created_at" : "2015-07-16 15:08:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501759584185638912\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/tPrrEkZcpE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvabrugIYAA-4Ur.jpg",
      "id_str" : "501759584017866752",
      "id" : 501759584017866752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvabrugIYAA-4Ur.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/tPrrEkZcpE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621505703304409088",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/tPrrEkZcpE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/501759584185638912\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/tPrrEkZcpE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvabrugIYAA-4Ur.jpg",
        "id_str" : "501759584017866752",
        "id" : 501759584017866752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvabrugIYAA-4Ur.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/tPrrEkZcpE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621499582216843264",
    "text" : "http:\/\/t.co\/tPrrEkZcpE",
    "id" : 621499582216843264,
    "created_at" : "2015-07-16 02:00:21 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 621505703304409088,
  "created_at" : "2015-07-16 02:24:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/WnYIa6V9r6",
      "expanded_url" : "https:\/\/twitter.com\/billroorbach\/status\/621387621449789441",
      "display_url" : "twitter.com\/billroorbach\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621486346000052225",
  "text" : "precious https:\/\/t.co\/WnYIa6V9r6",
  "id" : 621486346000052225,
  "created_at" : "2015-07-16 01:07:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "indices" : [ 3, 13 ],
      "id_str" : "194209267",
      "id" : 194209267
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621482838291030016",
  "text" : "RT @EpicReads: Life's greatest disappointment: leaving a bookstore empty handed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621482033567637504",
    "text" : "Life's greatest disappointment: leaving a bookstore empty handed.",
    "id" : 621482033567637504,
    "created_at" : "2015-07-16 00:50:38 +0000",
    "user" : {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "protected" : false,
      "id_str" : "194209267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710877075469701121\/1Vj7UzYf_normal.jpg",
      "id" : 194209267,
      "verified" : true
    }
  },
  "id" : 621482838291030016,
  "created_at" : "2015-07-16 00:53:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DuckDuckGo",
      "screen_name" : "duckduckgo",
      "indices" : [ 3, 14 ],
      "id_str" : "14504859",
      "id" : 14504859
    }, {
      "name" : "Jerry Reptak",
      "screen_name" : "JetFault",
      "indices" : [ 70, 79 ],
      "id_str" : "383415711",
      "id" : 383415711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/LSBKPG1SqT",
      "expanded_url" : "https:\/\/duckduckgo.com\/?q=days+from+july+15+to+aug+15&ia=answer",
      "display_url" : "duckduckgo.com\/?q=days+from+j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621480058818031616",
  "text" : "RT @duckduckgo: Get the number of days between dates. Code written by @JetFault and just updated by Bujiraso:\nhttps:\/\/t.co\/LSBKPG1SqT http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jerry Reptak",
        "screen_name" : "JetFault",
        "indices" : [ 54, 63 ],
        "id_str" : "383415711",
        "id" : 383415711
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/duckduckgo\/status\/621477351759724544\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/PeyQZAnSeA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ_uW9CW8AEPvZl.png",
        "id_str" : "621477351709405185",
        "id" : 621477351709405185,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ_uW9CW8AEPvZl.png",
        "sizes" : [ {
          "h" : 195,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 165,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 403
        } ],
        "display_url" : "pic.twitter.com\/PeyQZAnSeA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/LSBKPG1SqT",
        "expanded_url" : "https:\/\/duckduckgo.com\/?q=days+from+july+15+to+aug+15&ia=answer",
        "display_url" : "duckduckgo.com\/?q=days+from+j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621477351759724544",
    "text" : "Get the number of days between dates. Code written by @JetFault and just updated by Bujiraso:\nhttps:\/\/t.co\/LSBKPG1SqT http:\/\/t.co\/PeyQZAnSeA",
    "id" : 621477351759724544,
    "created_at" : "2015-07-16 00:32:01 +0000",
    "user" : {
      "name" : "DuckDuckGo",
      "screen_name" : "duckduckgo",
      "protected" : false,
      "id_str" : "14504859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467502291415617536\/SP8_ylk9_normal.png",
      "id" : 14504859,
      "verified" : true
    }
  },
  "id" : 621480058818031616,
  "created_at" : "2015-07-16 00:42:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess Deitz",
      "screen_name" : "JessDeitz",
      "indices" : [ 3, 13 ],
      "id_str" : "2743179005",
      "id" : 2743179005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621472554650308608",
  "text" : "RT @JessDeitz: While this Song Sparrow was privately preening, I was spying on it like a weirdo. This is when it caught me. http:\/\/t.co\/5Wu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JessDeitz\/status\/621446592399286273\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/5WujlEj9kd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ_SYfBWUAAC-pA.jpg",
        "id_str" : "621446591686266880",
        "id" : 621446591686266880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ_SYfBWUAAC-pA.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1800
        } ],
        "display_url" : "pic.twitter.com\/5WujlEj9kd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621446592399286273",
    "text" : "While this Song Sparrow was privately preening, I was spying on it like a weirdo. This is when it caught me. http:\/\/t.co\/5WujlEj9kd",
    "id" : 621446592399286273,
    "created_at" : "2015-07-15 22:29:48 +0000",
    "user" : {
      "name" : "Jess Deitz",
      "screen_name" : "JessDeitz",
      "protected" : false,
      "id_str" : "2743179005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799684589912518656\/wvxM5XiO_normal.jpg",
      "id" : 2743179005,
      "verified" : false
    }
  },
  "id" : 621472554650308608,
  "created_at" : "2015-07-16 00:12:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/621435377396654080\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/IHxdh6N2uG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ_ILrDUkAA3mpO.jpg",
      "id_str" : "621435376461189120",
      "id" : 621435376461189120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ_ILrDUkAA3mpO.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/IHxdh6N2uG"
    } ],
    "hashtags" : [ {
      "text" : "snore",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "vabirdlibrary",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621436457585123328",
  "text" : "RT @Library4birds: Miss Dove chose a bedtime story for storytime today. It worked.\n#snore #vabirdlibrary http:\/\/t.co\/IHxdh6N2uG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/621435377396654080\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/IHxdh6N2uG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ_ILrDUkAA3mpO.jpg",
        "id_str" : "621435376461189120",
        "id" : 621435376461189120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ_ILrDUkAA3mpO.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/IHxdh6N2uG"
      } ],
      "hashtags" : [ {
        "text" : "snore",
        "indices" : [ 64, 70 ]
      }, {
        "text" : "vabirdlibrary",
        "indices" : [ 71, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621435377396654080",
    "text" : "Miss Dove chose a bedtime story for storytime today. It worked.\n#snore #vabirdlibrary http:\/\/t.co\/IHxdh6N2uG",
    "id" : 621435377396654080,
    "created_at" : "2015-07-15 21:45:14 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 621436457585123328,
  "created_at" : "2015-07-15 21:49:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Rice",
      "screen_name" : "Caerwynt_Loops",
      "indices" : [ 3, 18 ],
      "id_str" : "33176865",
      "id" : 33176865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Caerwynt_Loops\/status\/619210591824138240\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/Yyc1Aw1Aia",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJfgtgKWUAAQhjY.jpg",
      "id_str" : "619210546118807552",
      "id" : 619210546118807552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJfgtgKWUAAQhjY.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Yyc1Aw1Aia"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621422269378752512",
  "text" : "RT @Caerwynt_Loops: The girls ain't impressed http:\/\/t.co\/Yyc1Aw1Aia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Caerwynt_Loops\/status\/619210591824138240\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/Yyc1Aw1Aia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJfgtgKWUAAQhjY.jpg",
        "id_str" : "619210546118807552",
        "id" : 619210546118807552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJfgtgKWUAAQhjY.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Yyc1Aw1Aia"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619210591824138240",
    "text" : "The girls ain't impressed http:\/\/t.co\/Yyc1Aw1Aia",
    "id" : 619210591824138240,
    "created_at" : "2015-07-09 18:24:44 +0000",
    "user" : {
      "name" : "David Rice",
      "screen_name" : "Caerwynt_Loops",
      "protected" : false,
      "id_str" : "33176865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792075019736219649\/eSGcUv-o_normal.jpg",
      "id" : 33176865,
      "verified" : false
    }
  },
  "id" : 621422269378752512,
  "created_at" : "2015-07-15 20:53:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621410277347733505",
  "text" : "soo.. DD drinking fortified protein drinks, milkshakes w fortified breakfast drink daily but is vit D def.. seems like not absorbing it?",
  "id" : 621410277347733505,
  "created_at" : "2015-07-15 20:05:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/gC4cXmKvpc",
      "expanded_url" : "http:\/\/Nurse.com",
      "display_url" : "Nurse.com"
    }, {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/gM77GGHcl2",
      "expanded_url" : "https:\/\/news.nurse.com\/2015\/07\/01\/misdiagnosis-of-lyme-disease-problematic\/",
      "display_url" : "news.nurse.com\/2015\/07\/01\/mis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621407851106406400",
  "text" : "RT @AlisynGayle: Misdiagnosis of Lyme disease problematic | http:\/\/t.co\/gC4cXmKvpc News https:\/\/t.co\/gM77GGHcl2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/gC4cXmKvpc",
        "expanded_url" : "http:\/\/Nurse.com",
        "display_url" : "Nurse.com"
      }, {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/gM77GGHcl2",
        "expanded_url" : "https:\/\/news.nurse.com\/2015\/07\/01\/misdiagnosis-of-lyme-disease-problematic\/",
        "display_url" : "news.nurse.com\/2015\/07\/01\/mis\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621394627199922176",
    "text" : "Misdiagnosis of Lyme disease problematic | http:\/\/t.co\/gC4cXmKvpc News https:\/\/t.co\/gM77GGHcl2",
    "id" : 621394627199922176,
    "created_at" : "2015-07-15 19:03:18 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 621407851106406400,
  "created_at" : "2015-07-15 19:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Reynolds \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "Sarah__Reynolds",
      "indices" : [ 3, 19 ],
      "id_str" : "179719307",
      "id" : 179719307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/0VDVT47gcN",
      "expanded_url" : "http:\/\/www.pnhp.org\/news\/2015\/july\/health-insurance-companies-seek-big-rate-increases-for-2016",
      "display_url" : "pnhp.org\/news\/2015\/july\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621389322588188672",
  "text" : "RT @Sarah__Reynolds: The largest health insurers are planning to increase rates 20-40% in 2016 http:\/\/t.co\/0VDVT47gcN Why we need #SinglePa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Sanders",
        "screen_name" : "BernieSanders",
        "indices" : [ 128, 142 ],
        "id_str" : "216776631",
        "id" : 216776631
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/0VDVT47gcN",
        "expanded_url" : "http:\/\/www.pnhp.org\/news\/2015\/july\/health-insurance-companies-seek-big-rate-increases-for-2016",
        "display_url" : "pnhp.org\/news\/2015\/july\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621221408580857856",
    "text" : "The largest health insurers are planning to increase rates 20-40% in 2016 http:\/\/t.co\/0VDVT47gcN Why we need #SinglePayer &amp; @BernieSanders",
    "id" : 621221408580857856,
    "created_at" : "2015-07-15 07:35:00 +0000",
    "user" : {
      "name" : "Sarah Reynolds \uD83C\uDDFA\uD83C\uDDF8",
      "screen_name" : "Sarah__Reynolds",
      "protected" : false,
      "id_str" : "179719307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788893429250027520\/MTZgY8KA_normal.jpg",
      "id" : 179719307,
      "verified" : false
    }
  },
  "id" : 621389322588188672,
  "created_at" : "2015-07-15 18:42:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621350947134943232",
  "geo" : { },
  "id_str" : "621381447660797952",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ouch. ((hugs))",
  "id" : 621381447660797952,
  "in_reply_to_status_id" : 621350947134943232,
  "created_at" : "2015-07-15 18:10:56 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621380553258991616",
  "text" : "@Lluminous_ sounds interesting..lol",
  "id" : 621380553258991616,
  "created_at" : "2015-07-15 18:07:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Micu",
      "screen_name" : "axelk",
      "indices" : [ 3, 9 ],
      "id_str" : "6808272",
      "id" : 6808272
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/axelk\/status\/621352271150977025\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/tsQvJwiAdR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ98l5HUEAATkNB.png",
      "id_str" : "621352264028917760",
      "id" : 621352264028917760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ98l5HUEAATkNB.png",
      "sizes" : [ {
        "h" : 113,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 489
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 489
      } ],
      "display_url" : "pic.twitter.com\/tsQvJwiAdR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621358775195316224",
  "text" : "RT @axelk: PDF becomes 4th most popular religion http:\/\/t.co\/tsQvJwiAdR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/axelk\/status\/621352271150977025\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/tsQvJwiAdR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ98l5HUEAATkNB.png",
        "id_str" : "621352264028917760",
        "id" : 621352264028917760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ98l5HUEAATkNB.png",
        "sizes" : [ {
          "h" : 113,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 489
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 489
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 489
        } ],
        "display_url" : "pic.twitter.com\/tsQvJwiAdR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621352271150977025",
    "text" : "PDF becomes 4th most popular religion http:\/\/t.co\/tsQvJwiAdR",
    "id" : 621352271150977025,
    "created_at" : "2015-07-15 16:15:00 +0000",
    "user" : {
      "name" : "Alex Micu",
      "screen_name" : "axelk",
      "protected" : false,
      "id_str" : "6808272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615910847194505216\/fzE6oBsv_normal.png",
      "id" : 6808272,
      "verified" : false
    }
  },
  "id" : 621358775195316224,
  "created_at" : "2015-07-15 16:40:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/mhNYCdWigH",
      "expanded_url" : "http:\/\/www.upworthy.com\/a-navy-diver-thought-he-heard-someone-talking-to-him-underwater-turns-out-it-was-a-beluga-whale?g=2",
      "display_url" : "upworthy.com\/a-navy-diver-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621348557371625472",
  "text" : "Noc the whale nearly taught himself to talk. 31 years later, he's still one-of-a-kind. http:\/\/t.co\/mhNYCdWigH",
  "id" : 621348557371625472,
  "created_at" : "2015-07-15 16:00:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote For Bernie",
      "screen_name" : "vote_for_bernie",
      "indices" : [ 3, 19 ],
      "id_str" : "3312879640",
      "id" : 3312879640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FeelTheBern",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jMKyqafl1K",
      "expanded_url" : "http:\/\/voteforbernie.org\/debate\/",
      "display_url" : "voteforbernie.org\/debate\/"
    } ]
  },
  "geo" : { },
  "id_str" : "621327959719313408",
  "text" : "RT @vote_for_bernie: Our campaign to tell the DNC we want more debates launches on August 5!\n\nJoin us@ http:\/\/t.co\/jMKyqafl1K #FeelTheBern \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vote_for_bernie\/status\/616300503991869441\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/c0Xx7sTCml",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CI2KCouUMAAHLZ_.jpg",
        "id_str" : "616300501915676672",
        "id" : 616300501915676672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI2KCouUMAAHLZ_.jpg",
        "sizes" : [ {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/c0Xx7sTCml"
      } ],
      "hashtags" : [ {
        "text" : "FeelTheBern",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/jMKyqafl1K",
        "expanded_url" : "http:\/\/voteforbernie.org\/debate\/",
        "display_url" : "voteforbernie.org\/debate\/"
      } ]
    },
    "geo" : { },
    "id_str" : "616300503991869441",
    "text" : "Our campaign to tell the DNC we want more debates launches on August 5!\n\nJoin us@ http:\/\/t.co\/jMKyqafl1K #FeelTheBern http:\/\/t.co\/c0Xx7sTCml",
    "id" : 616300503991869441,
    "created_at" : "2015-07-01 17:41:05 +0000",
    "user" : {
      "name" : "Vote For Bernie",
      "screen_name" : "vote_for_bernie",
      "protected" : false,
      "id_str" : "3312879640",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615653650149408768\/0VHkgIn9_normal.png",
      "id" : 3312879640,
      "verified" : false
    }
  },
  "id" : 621327959719313408,
  "created_at" : "2015-07-15 14:38:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/509491433372663808\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/I0wyxaU1YC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxITwlIIgAAWaTX.jpg",
      "id_str" : "509491433167159296",
      "id" : 509491433167159296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxITwlIIgAAWaTX.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I0wyxaU1YC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621146318472392705",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/I0wyxaU1YC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/509491433372663808\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/I0wyxaU1YC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxITwlIIgAAWaTX.jpg",
        "id_str" : "509491433167159296",
        "id" : 509491433167159296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxITwlIIgAAWaTX.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I0wyxaU1YC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621137151330226177",
    "text" : "http:\/\/t.co\/I0wyxaU1YC",
    "id" : 621137151330226177,
    "created_at" : "2015-07-15 02:00:11 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 621146318472392705,
  "created_at" : "2015-07-15 02:36:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PinarAkal1\/status\/621139679211974656\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/E1ZUCtWRog",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ67P0rUkAAiUMz.jpg",
      "id_str" : "621139679136485376",
      "id" : 621139679136485376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ67P0rUkAAiUMz.jpg",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E1ZUCtWRog"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621144047420342272",
  "text" : "RT @PinarAkal1: May my soul bloom in love for all existence.\n\n~ Rudolf Steiner http:\/\/t.co\/E1ZUCtWRog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PinarAkal1\/status\/621139679211974656\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/E1ZUCtWRog",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ67P0rUkAAiUMz.jpg",
        "id_str" : "621139679136485376",
        "id" : 621139679136485376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ67P0rUkAAiUMz.jpg",
        "sizes" : [ {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/E1ZUCtWRog"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621139679211974656",
    "text" : "May my soul bloom in love for all existence.\n\n~ Rudolf Steiner http:\/\/t.co\/E1ZUCtWRog",
    "id" : 621139679211974656,
    "created_at" : "2015-07-15 02:10:14 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 621144047420342272,
  "created_at" : "2015-07-15 02:27:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621143349223911425",
  "text" : "RT @ZachsMind: It's a person's life that means something. Not how they died or whether or not other people believe their death meant anythi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621141335219638273",
    "text" : "It's a person's life that means something. Not how they died or whether or not other people believe their death meant anything.",
    "id" : 621141335219638273,
    "created_at" : "2015-07-15 02:16:49 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 621143349223911425,
  "created_at" : "2015-07-15 02:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621006403260448768",
  "geo" : { },
  "id_str" : "621142053326618624",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time since early June on ativan, anti-nausea daily.",
  "id" : 621142053326618624,
  "in_reply_to_status_id" : 621006403260448768,
  "created_at" : "2015-07-15 02:19:40 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621006403260448768",
  "geo" : { },
  "id_str" : "621141602283749376",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time started off on may 7 w intense nausea, weak, dizzy. She insisted she needed hospital.",
  "id" : 621141602283749376,
  "in_reply_to_status_id" : 621006403260448768,
  "created_at" : "2015-07-15 02:17:52 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "holly wood\uD83C\uDFF4",
      "screen_name" : "girlziplocked",
      "indices" : [ 3, 17 ],
      "id_str" : "20221325",
      "id" : 20221325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621130445493792768",
  "text" : "RT @girlziplocked: POISON IVY: We have to kill all men.\nHARLEY QUINN: DAMN, BITCH, THAT'S COLD. \nPOISON IVY: So are you in?\nHARLEY QUINN: O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "621126683899351040",
    "geo" : { },
    "id_str" : "621127077203472384",
    "in_reply_to_user_id" : 20221325,
    "text" : "POISON IVY: We have to kill all men.\nHARLEY QUINN: DAMN, BITCH, THAT'S COLD. \nPOISON IVY: So are you in?\nHARLEY QUINN: Oh god yes.",
    "id" : 621127077203472384,
    "in_reply_to_status_id" : 621126683899351040,
    "created_at" : "2015-07-15 01:20:09 +0000",
    "in_reply_to_screen_name" : "girlziplocked",
    "in_reply_to_user_id_str" : "20221325",
    "user" : {
      "name" : "holly wood\uD83C\uDFF4",
      "screen_name" : "girlziplocked",
      "protected" : false,
      "id_str" : "20221325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799539214270480385\/YWuIUG3F_normal.jpg",
      "id" : 20221325,
      "verified" : false
    }
  },
  "id" : 621130445493792768,
  "created_at" : "2015-07-15 01:33:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Activist",
      "screen_name" : "TheActivistDr",
      "indices" : [ 3, 17 ],
      "id_str" : "259986564",
      "id" : 259986564
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HearUs",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/n5yiKj6don",
      "expanded_url" : "http:\/\/www.healthnutnews.com\/breaking-4th-doctor-an-md-found-dead-gunshot-wound-to-head\/#.dpuf",
      "display_url" : "healthnutnews.com\/breaking-4th-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621126583248621574",
  "text" : "RT @TheActivistDr: 9 doctors missing or found dead in less than a month. Nothing to see here, folks. http:\/\/t.co\/n5yiKj6don #HearUs #recall\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HearUs",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "recallsb277",
        "indices" : [ 113, 125 ]
      }, {
        "text" : "Corruption",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/n5yiKj6don",
        "expanded_url" : "http:\/\/www.healthnutnews.com\/breaking-4th-doctor-an-md-found-dead-gunshot-wound-to-head\/#.dpuf",
        "display_url" : "healthnutnews.com\/breaking-4th-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621119284777914368",
    "text" : "9 doctors missing or found dead in less than a month. Nothing to see here, folks. http:\/\/t.co\/n5yiKj6don #HearUs #recallsb277 #Corruption",
    "id" : 621119284777914368,
    "created_at" : "2015-07-15 00:49:11 +0000",
    "user" : {
      "name" : "Dr Activist",
      "screen_name" : "TheActivistDr",
      "protected" : false,
      "id_str" : "259986564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616560666443296768\/BFzkbf1u_normal.jpg",
      "id" : 259986564,
      "verified" : false
    }
  },
  "id" : 621126583248621574,
  "created_at" : "2015-07-15 01:18:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Thanksgiving",
      "screen_name" : "dexhandle",
      "indices" : [ 3, 13 ],
      "id_str" : "11068232",
      "id" : 11068232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621125378137026565",
  "text" : "RT @dexhandle: The oldest living person in the world was alive before the Wright Brothers flew the first plane\n\nAnd we just sent something \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620950414284996608",
    "text" : "The oldest living person in the world was alive before the Wright Brothers flew the first plane\n\nAnd we just sent something past Pluto today",
    "id" : 620950414284996608,
    "created_at" : "2015-07-14 13:38:10 +0000",
    "user" : {
      "name" : "Erik Thanksgiving",
      "screen_name" : "dexhandle",
      "protected" : false,
      "id_str" : "11068232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739245799758958593\/O497SzX3_normal.jpg",
      "id" : 11068232,
      "verified" : false
    }
  },
  "id" : 621125378137026565,
  "created_at" : "2015-07-15 01:13:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam Sullivan",
      "screen_name" : "thepamsullivan",
      "indices" : [ 3, 18 ],
      "id_str" : "248477730",
      "id" : 248477730
    }, {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 106, 118 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "Diana Augustin",
      "screen_name" : "thejenwilkinson",
      "indices" : [ 120, 136 ],
      "id_str" : "793908379672461312",
      "id" : 793908379672461312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Blackfish",
      "indices" : [ 79, 89 ]
    }, {
      "text" : "EmptyTheTanks",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/WYWld0i7P2",
      "expanded_url" : "http:\/\/www.am730.ca\/syn\/112\/83490\/83490",
      "display_url" : "am730.ca\/syn\/112\/83490\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621123849330012160",
  "text" : "RT @thepamsullivan: Reunion in Sea 4 Family of Orcas\u2764\uFE0F\uD83D\uDC0B http:\/\/t.co\/WYWld0i7P2 #Blackfish #EmptyTheTanks .@oceanshaman .@thejenwilkinson ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GRAY",
        "screen_name" : "oceanshaman",
        "indices" : [ 86, 98 ],
        "id_str" : "45674330",
        "id" : 45674330
      }, {
        "name" : "Diana Augustin",
        "screen_name" : "thejenwilkinson",
        "indices" : [ 100, 116 ],
        "id_str" : "793908379672461312",
        "id" : 793908379672461312
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/thepamsullivan\/status\/621115802247426048\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/55PZhlNp1b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ6lh4QWEAApjni.jpg",
        "id_str" : "621115800078913536",
        "id" : 621115800078913536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ6lh4QWEAApjni.jpg",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 513
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/55PZhlNp1b"
      } ],
      "hashtags" : [ {
        "text" : "Blackfish",
        "indices" : [ 59, 69 ]
      }, {
        "text" : "EmptyTheTanks",
        "indices" : [ 70, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/WYWld0i7P2",
        "expanded_url" : "http:\/\/www.am730.ca\/syn\/112\/83490\/83490",
        "display_url" : "am730.ca\/syn\/112\/83490\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621115802247426048",
    "text" : "Reunion in Sea 4 Family of Orcas\u2764\uFE0F\uD83D\uDC0B http:\/\/t.co\/WYWld0i7P2 #Blackfish #EmptyTheTanks .@oceanshaman .@thejenwilkinson http:\/\/t.co\/55PZhlNp1b",
    "id" : 621115802247426048,
    "created_at" : "2015-07-15 00:35:21 +0000",
    "user" : {
      "name" : "Pam Sullivan",
      "screen_name" : "thepamsullivan",
      "protected" : false,
      "id_str" : "248477730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690381687713308673\/jDKULeoI_normal.jpg",
      "id" : 248477730,
      "verified" : false
    }
  },
  "id" : 621123849330012160,
  "created_at" : "2015-07-15 01:07:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/84q2x8ftlu",
      "expanded_url" : "http:\/\/thedancingdonkey.blogspot.com\/2015\/07\/when-pigs-fly.html",
      "display_url" : "thedancingdonkey.blogspot.com\/2015\/07\/when-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621083329484443648",
  "text" : "The Dancing Donkey: When Pigs Fly http:\/\/t.co\/84q2x8ftlu",
  "id" : 621083329484443648,
  "created_at" : "2015-07-14 22:26:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/5vbxM8xcm5",
      "expanded_url" : "http:\/\/notes.bsoist.com\/notes.html",
      "display_url" : "notes.bsoist.com\/notes.html"
    } ]
  },
  "geo" : { },
  "id_str" : "621076492877975552",
  "text" : "He played by his own rules July 14 http:\/\/t.co\/5vbxM8xcm5",
  "id" : 621076492877975552,
  "created_at" : "2015-07-14 21:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA New Horizons",
      "screen_name" : "NASANewHorizons",
      "indices" : [ 51, 67 ],
      "id_str" : "2734713482",
      "id" : 2734713482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PlutoFlyby",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620993404378419204",
  "text" : "RT @NASA: Pluto sent a love note back to Earth via @NASANewHorizons. This is the last image taken before today's #PlutoFlyby. http:\/\/t.co\/a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA New Horizons",
        "screen_name" : "NASANewHorizons",
        "indices" : [ 41, 57 ],
        "id_str" : "2734713482",
        "id" : 2734713482
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/620936275336368128\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/a2AE20LHcR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ4CQIkVEAEaAnw.png",
        "id_str" : "620936274824728577",
        "id" : 620936274824728577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ4CQIkVEAEaAnw.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/a2AE20LHcR"
      } ],
      "hashtags" : [ {
        "text" : "PlutoFlyby",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620936275336368128",
    "text" : "Pluto sent a love note back to Earth via @NASANewHorizons. This is the last image taken before today's #PlutoFlyby. http:\/\/t.co\/a2AE20LHcR",
    "id" : 620936275336368128,
    "created_at" : "2015-07-14 12:41:59 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 620993404378419204,
  "created_at" : "2015-07-14 16:28:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Christian",
      "screen_name" : "manxmannin",
      "indices" : [ 3, 14 ],
      "id_str" : "335894103",
      "id" : 335894103
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/manxmannin\/status\/620793085040140293\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/3hXeyEUfto",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ2AAUQWwAAySV3.jpg",
      "id_str" : "620793066572660736",
      "id" : 620793066572660736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ2AAUQWwAAySV3.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3hXeyEUfto"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/manxmannin\/status\/620793085040140293\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/3hXeyEUfto",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ2AAUQXAAAZ0aA.jpg",
      "id_str" : "620793066572677120",
      "id" : 620793066572677120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ2AAUQXAAAZ0aA.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3hXeyEUfto"
    } ],
    "hashtags" : [ {
      "text" : "isleofman",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620993128934309888",
  "text" : "RT @manxmannin: Black Guillemot, Douglas #isleofman http:\/\/t.co\/3hXeyEUfto",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/manxmannin\/status\/620793085040140293\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/3hXeyEUfto",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ2AAUQWwAAySV3.jpg",
        "id_str" : "620793066572660736",
        "id" : 620793066572660736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ2AAUQWwAAySV3.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3hXeyEUfto"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/manxmannin\/status\/620793085040140293\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/3hXeyEUfto",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ2AAUQXAAAZ0aA.jpg",
        "id_str" : "620793066572677120",
        "id" : 620793066572677120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ2AAUQXAAAZ0aA.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3hXeyEUfto"
      } ],
      "hashtags" : [ {
        "text" : "isleofman",
        "indices" : [ 25, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620793085040140293",
    "text" : "Black Guillemot, Douglas #isleofman http:\/\/t.co\/3hXeyEUfto",
    "id" : 620793085040140293,
    "created_at" : "2015-07-14 03:12:59 +0000",
    "user" : {
      "name" : "Peter Christian",
      "screen_name" : "manxmannin",
      "protected" : false,
      "id_str" : "335894103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796427906524282880\/py5BQHWr_normal.jpg",
      "id" : 335894103,
      "verified" : false
    }
  },
  "id" : 620993128934309888,
  "created_at" : "2015-07-14 16:27:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620989398381948928",
  "text" : "She's afraid of another episode so I've been sleeping in bottom bunk for weeks now. On worse days, I stay in room during the day also.",
  "id" : 620989398381948928,
  "created_at" : "2015-07-14 16:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620988898051784704",
  "text" : "She hasn't touched tv video games since. Can't tolerate heat, hot water.",
  "id" : 620988898051784704,
  "created_at" : "2015-07-14 16:11:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620987756697780224",
  "text" : "She's avg 87 lbs. Drinking fortified milkshakes, protein drinks daily. Tolerates some chicken. Even her underwear is loose!",
  "id" : 620987756697780224,
  "created_at" : "2015-07-14 16:06:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620986690233044992",
  "text" : "The kid has not been normal since may 7. Some days not as bad but gen nausea, dizzy, sick daily.",
  "id" : 620986690233044992,
  "created_at" : "2015-07-14 16:02:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620985706874335232",
  "text" : "I'm not a doc but blood work doesn't reveal too much. Endo will prob say keep taking levo, see ya in 6 mos.",
  "id" : 620985706874335232,
  "created_at" : "2015-07-14 15:58:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620984549837832192",
  "text" : "I'm not a responsible person. Do not put me in charge. I mess things up.. badly.",
  "id" : 620984549837832192,
  "created_at" : "2015-07-14 15:53:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rescuedducks",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/gpl3ZM3fR1",
      "expanded_url" : "https:\/\/instagram.com\/p\/5GaUROBH5m\/",
      "display_url" : "instagram.com\/p\/5GaUROBH5m\/"
    } ]
  },
  "geo" : { },
  "id_str" : "620787527994220544",
  "text" : "RT @ducksandclucks: Our nightly game of \"eat the croc.\" #rescuedducks https:\/\/t.co\/gpl3ZM3fR1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rescuedducks",
        "indices" : [ 36, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/gpl3ZM3fR1",
        "expanded_url" : "https:\/\/instagram.com\/p\/5GaUROBH5m\/",
        "display_url" : "instagram.com\/p\/5GaUROBH5m\/"
      } ]
    },
    "geo" : { },
    "id_str" : "620785283383042048",
    "text" : "Our nightly game of \"eat the croc.\" #rescuedducks https:\/\/t.co\/gpl3ZM3fR1",
    "id" : 620785283383042048,
    "created_at" : "2015-07-14 02:41:59 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 620787527994220544,
  "created_at" : "2015-07-14 02:50:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aentee \uD83C\uDF39",
      "screen_name" : "readatmidnight",
      "indices" : [ 3, 18 ],
      "id_str" : "3248418114",
      "id" : 3248418114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620785964378664960",
  "text" : "RT @readatmidnight: Just spent $40 on bookmarks... 90% of my books are kindle versions... Curse you cute etsy stores \uD83D\uDE28\uD83D\uDC96",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620425497646739456",
    "text" : "Just spent $40 on bookmarks... 90% of my books are kindle versions... Curse you cute etsy stores \uD83D\uDE28\uD83D\uDC96",
    "id" : 620425497646739456,
    "created_at" : "2015-07-13 02:52:20 +0000",
    "user" : {
      "name" : "aentee \uD83C\uDF39",
      "screen_name" : "readatmidnight",
      "protected" : false,
      "id_str" : "3248418114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793343195212046336\/0uuU0qgL_normal.jpg",
      "id" : 3248418114,
      "verified" : false
    }
  },
  "id" : 620785964378664960,
  "created_at" : "2015-07-14 02:44:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620785615676788737",
  "text" : "RT @JosephRanseth: Compassion is a natural product when we realize the truth that we are all connected and that all we see in others merely\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620776761802887168",
    "text" : "Compassion is a natural product when we realize the truth that we are all connected and that all we see in others merely reflects ourselves.",
    "id" : 620776761802887168,
    "created_at" : "2015-07-14 02:08:08 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 620785615676788737,
  "created_at" : "2015-07-14 02:43:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620784414440689664",
  "text" : "RT @Wolf_Mommy: In awe of the mama nursing her toddler in the shopping cart while waiting in line behind me today. She is an inspiration!\n#\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NIP",
        "indices" : [ 122, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620777107606507520",
    "text" : "In awe of the mama nursing her toddler in the shopping cart while waiting in line behind me today. She is an inspiration!\n#NIP",
    "id" : 620777107606507520,
    "created_at" : "2015-07-14 02:09:30 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 620784414440689664,
  "created_at" : "2015-07-14 02:38:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620729891634417664",
  "text" : "some labs came in for DD - #thyroid peroxidase ab = 352 (should be less than 9) ; VITAMIN D,25-OH,TOTAL,IA = 17 (30 - 100)",
  "id" : 620729891634417664,
  "created_at" : "2015-07-13 23:01:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "indices" : [ 3, 19 ],
      "id_str" : "457436503",
      "id" : 457436503
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/620689456408985600\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ngpSBcm9Ee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ0huo8WIAAdrvZ.jpg",
      "id_str" : "620689408795222016",
      "id" : 620689408795222016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ0huo8WIAAdrvZ.jpg",
      "sizes" : [ {
        "h" : 639,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ngpSBcm9Ee"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620690564737048576",
  "text" : "RT @hilltopfarmgirl: Family photo, Plato, Hemlock &amp; their son. Presently trying for another. http:\/\/t.co\/ngpSBcm9Ee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hilltopfarmgirl\/status\/620689456408985600\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/ngpSBcm9Ee",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ0huo8WIAAdrvZ.jpg",
        "id_str" : "620689408795222016",
        "id" : 620689408795222016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ0huo8WIAAdrvZ.jpg",
        "sizes" : [ {
          "h" : 639,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ngpSBcm9Ee"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620689456408985600",
    "text" : "Family photo, Plato, Hemlock &amp; their son. Presently trying for another. http:\/\/t.co\/ngpSBcm9Ee",
    "id" : 620689456408985600,
    "created_at" : "2015-07-13 20:21:12 +0000",
    "user" : {
      "name" : "Hill Top Farm",
      "screen_name" : "hilltopfarmgirl",
      "protected" : false,
      "id_str" : "457436503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3491566457\/61244b7682c638ad4b0a097321ae762e_normal.jpeg",
      "id" : 457436503,
      "verified" : false
    }
  },
  "id" : 620690564737048576,
  "created_at" : "2015-07-13 20:25:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Kaufman",
      "screen_name" : "kaufman_jack",
      "indices" : [ 74, 87 ],
      "id_str" : "307373582",
      "id" : 307373582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/6ZCJe1BnUE",
      "expanded_url" : "http:\/\/jackkaufman.net\/18516-the-revenue-ive-made-from-products\/",
      "display_url" : "jackkaufman.net\/18516-the-reve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620627710382067712",
  "text" : "$18,516: The revenue I\u2019ve made from 2 products http:\/\/t.co\/6ZCJe1BnUE via @kaufman_jack",
  "id" : 620627710382067712,
  "created_at" : "2015-07-13 16:15:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/a4wQhZYqBc",
      "expanded_url" : "https:\/\/twitter.com\/khoureld\/status\/620550979004448768",
      "display_url" : "twitter.com\/khoureld\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620617285263339520",
  "text" : "heeheehee https:\/\/t.co\/a4wQhZYqBc",
  "id" : 620617285263339520,
  "created_at" : "2015-07-13 15:34:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "indices" : [ 3, 15 ],
      "id_str" : "14873767",
      "id" : 14873767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620616748082008065",
  "text" : "RT @DanteAtkins: 2\/2 those costs will stabilize in the future once you get past the first-time glut  Can't judge water pressure by when a d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "620615954913865728",
    "geo" : { },
    "id_str" : "620616376319737856",
    "in_reply_to_user_id" : 14873767,
    "text" : "2\/2 those costs will stabilize in the future once you get past the first-time glut  Can't judge water pressure by when a dam first bursts.",
    "id" : 620616376319737856,
    "in_reply_to_status_id" : 620615954913865728,
    "created_at" : "2015-07-13 15:30:49 +0000",
    "in_reply_to_screen_name" : "DanteAtkins",
    "in_reply_to_user_id_str" : "14873767",
    "user" : {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "protected" : false,
      "id_str" : "14873767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466040900196372480\/uSZa77kS_normal.jpeg",
      "id" : 14873767,
      "verified" : true
    }
  },
  "id" : 620616748082008065,
  "created_at" : "2015-07-13 15:32:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "indices" : [ 3, 15 ],
      "id_str" : "14873767",
      "id" : 14873767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620616728343642113",
  "text" : "RT @DanteAtkins: IL's Medicaid issue +BC\/BS premium hikes indicate ONE thing alone: they underestimated just how many sick people had forgo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620615954913865728",
    "text" : "IL's Medicaid issue +BC\/BS premium hikes indicate ONE thing alone: they underestimated just how many sick people had forgone care. 1\/2",
    "id" : 620615954913865728,
    "created_at" : "2015-07-13 15:29:08 +0000",
    "user" : {
      "name" : "Dante Atkins",
      "screen_name" : "DanteAtkins",
      "protected" : false,
      "id_str" : "14873767",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466040900196372480\/uSZa77kS_normal.jpeg",
      "id" : 14873767,
      "verified" : true
    }
  },
  "id" : 620616728343642113,
  "created_at" : "2015-07-13 15:32:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShareThis",
      "screen_name" : "ShareThis",
      "indices" : [ 74, 84 ],
      "id_str" : "14116807",
      "id" : 14116807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/WEWSHm9ZCb",
      "expanded_url" : "https:\/\/shar.es\/1s0MqZ",
      "display_url" : "shar.es\/1s0MqZ"
    } ]
  },
  "geo" : { },
  "id_str" : "620598716119011328",
  "text" : "Why I Changed My Mind About Marriage Equality https:\/\/t.co\/WEWSHm9ZCb via @sharethis",
  "id" : 620598716119011328,
  "created_at" : "2015-07-13 14:20:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "indices" : [ 3, 13 ],
      "id_str" : "65698096",
      "id" : 65698096
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/splcenter\/status\/620261398589759490\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/jRUYYMyKLr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJo-T9GUkAAHeFU.png",
      "id_str" : "619876411256377344",
      "id" : 619876411256377344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJo-T9GUkAAHeFU.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1306
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jRUYYMyKLr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/P1CfHYodbB",
      "expanded_url" : "http:\/\/sp.lc\/PtBy3",
      "display_url" : "sp.lc\/PtBy3"
    } ]
  },
  "geo" : { },
  "id_str" : "620425937755205632",
  "text" : "RT @splcenter: Take a look inside this 1970s high school history book http:\/\/t.co\/P1CfHYodbB http:\/\/t.co\/jRUYYMyKLr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/splcenter\/status\/620261398589759490\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/jRUYYMyKLr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJo-T9GUkAAHeFU.png",
        "id_str" : "619876411256377344",
        "id" : 619876411256377344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJo-T9GUkAAHeFU.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1306
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jRUYYMyKLr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/P1CfHYodbB",
        "expanded_url" : "http:\/\/sp.lc\/PtBy3",
        "display_url" : "sp.lc\/PtBy3"
      } ]
    },
    "geo" : { },
    "id_str" : "620261398589759490",
    "text" : "Take a look inside this 1970s high school history book http:\/\/t.co\/P1CfHYodbB http:\/\/t.co\/jRUYYMyKLr",
    "id" : 620261398589759490,
    "created_at" : "2015-07-12 16:00:15 +0000",
    "user" : {
      "name" : "SPLC",
      "screen_name" : "splcenter",
      "protected" : false,
      "id_str" : "65698096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798779235825426433\/n3bvatib_normal.jpg",
      "id" : 65698096,
      "verified" : true
    }
  },
  "id" : 620425937755205632,
  "created_at" : "2015-07-13 02:54:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "indices" : [ 3, 16 ],
      "id_str" : "6091632",
      "id" : 6091632
    }, {
      "name" : "Wild Goose Festival",
      "screen_name" : "WildGooseFest",
      "indices" : [ 21, 35 ],
      "id_str" : "67942677",
      "id" : 67942677
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620425525274800128",
  "text" : "RT @mikemchargue: At @WildGooseFest, all races, genders, orientations, and abilities were celebrated and lifted up. May the Church more lik\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wild Goose Festival",
        "screen_name" : "WildGooseFest",
        "indices" : [ 3, 17 ],
        "id_str" : "67942677",
        "id" : 67942677
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620425008356134912",
    "text" : "At @WildGooseFest, all races, genders, orientations, and abilities were celebrated and lifted up. May the Church more like it every day.",
    "id" : 620425008356134912,
    "created_at" : "2015-07-13 02:50:23 +0000",
    "user" : {
      "name" : "Science Mike",
      "screen_name" : "mikemchargue",
      "protected" : false,
      "id_str" : "6091632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577831344459280384\/TzT6L7Ob_normal.jpeg",
      "id" : 6091632,
      "verified" : true
    }
  },
  "id" : 620425525274800128,
  "created_at" : "2015-07-13 02:52:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/eBreu4B6n7",
      "expanded_url" : "https:\/\/instagram.com\/p\/5DwvtXOWP4\/",
      "display_url" : "instagram.com\/p\/5DwvtXOWP4\/"
    } ]
  },
  "geo" : { },
  "id_str" : "620412940206870528",
  "text" : "RT @bcmystery: Neighbors. https:\/\/t.co\/eBreu4B6n7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 34 ],
        "url" : "https:\/\/t.co\/eBreu4B6n7",
        "expanded_url" : "https:\/\/instagram.com\/p\/5DwvtXOWP4\/",
        "display_url" : "instagram.com\/p\/5DwvtXOWP4\/"
      } ]
    },
    "geo" : { },
    "id_str" : "620412369479438336",
    "text" : "Neighbors. https:\/\/t.co\/eBreu4B6n7",
    "id" : 620412369479438336,
    "created_at" : "2015-07-13 02:00:10 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 620412940206870528,
  "created_at" : "2015-07-13 02:02:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. \u0394. \u0126UN\u0166",
      "screen_name" : "authorsahunt",
      "indices" : [ 3, 16 ],
      "id_str" : "119038924",
      "id" : 119038924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620412461099954176",
  "text" : "RT @authorsahunt: I can\u2019t imagine what the Yelp reviews on the United States of America would look like",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620409763663196160",
    "text" : "I can\u2019t imagine what the Yelp reviews on the United States of America would look like",
    "id" : 620409763663196160,
    "created_at" : "2015-07-13 01:49:48 +0000",
    "user" : {
      "name" : "S. \u0394. \u0126UN\u0166",
      "screen_name" : "authorsahunt",
      "protected" : false,
      "id_str" : "119038924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757970884804116480\/GbzKF8qR_normal.jpg",
      "id" : 119038924,
      "verified" : false
    }
  },
  "id" : 620412461099954176,
  "created_at" : "2015-07-13 02:00:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "S. \u0394. \u0126UN\u0166",
      "screen_name" : "authorsahunt",
      "indices" : [ 3, 16 ],
      "id_str" : "119038924",
      "id" : 119038924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/4tFntyNyyc",
      "expanded_url" : "https:\/\/twitter.com\/WritersEdit\/status\/617001109542998017",
      "display_url" : "twitter.com\/WritersEdit\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620410599885938688",
  "text" : "RT @authorsahunt: Yooooo free Scrivener https:\/\/t.co\/4tFntyNyyc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/4tFntyNyyc",
        "expanded_url" : "https:\/\/twitter.com\/WritersEdit\/status\/617001109542998017",
        "display_url" : "twitter.com\/WritersEdit\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620404309730066432",
    "text" : "Yooooo free Scrivener https:\/\/t.co\/4tFntyNyyc",
    "id" : 620404309730066432,
    "created_at" : "2015-07-13 01:28:08 +0000",
    "user" : {
      "name" : "S. \u0394. \u0126UN\u0166",
      "screen_name" : "authorsahunt",
      "protected" : false,
      "id_str" : "119038924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757970884804116480\/GbzKF8qR_normal.jpg",
      "id" : 119038924,
      "verified" : false
    }
  },
  "id" : 620410599885938688,
  "created_at" : "2015-07-13 01:53:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620408148805857280",
  "geo" : { },
  "id_str" : "620408818539716608",
  "in_reply_to_user_id" : 73908822,
  "text" : "@dwaynereaves nice shot : )",
  "id" : 620408818539716608,
  "in_reply_to_status_id" : 620408148805857280,
  "created_at" : "2015-07-13 01:46:03 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/620408493028327424\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Y6TZA44K6q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJwiPI4UsAEd-zd.png",
      "id_str" : "620408492147388417",
      "id" : 620408492147388417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJwiPI4UsAEd-zd.png",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/Y6TZA44K6q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620408493028327424",
  "text" : "Took a pic of my lock screen.. Would be better with date of Supreme Court ruling.. gah. http:\/\/t.co\/Y6TZA44K6q",
  "id" : 620408493028327424,
  "created_at" : "2015-07-13 01:44:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620360248948297728",
  "geo" : { },
  "id_str" : "620361793299456000",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle lol",
  "id" : 620361793299456000,
  "in_reply_to_status_id" : 620360248948297728,
  "created_at" : "2015-07-12 22:39:11 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Melchior",
      "screen_name" : "Kate_Melchior",
      "indices" : [ 3, 17 ],
      "id_str" : "528035811",
      "id" : 528035811
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Kate_Melchior\/status\/619465290183630848\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/HcRXMP8oGh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJjIYX0UwAEWQO_.jpg",
      "id_str" : "619465269799337985",
      "id" : 619465269799337985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJjIYX0UwAEWQO_.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HcRXMP8oGh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620361084340449280",
  "text" : "RT @Kate_Melchior: http:\/\/t.co\/HcRXMP8oGh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kate_Melchior\/status\/619465290183630848\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/HcRXMP8oGh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJjIYX0UwAEWQO_.jpg",
        "id_str" : "619465269799337985",
        "id" : 619465269799337985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJjIYX0UwAEWQO_.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HcRXMP8oGh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619465290183630848",
    "text" : "http:\/\/t.co\/HcRXMP8oGh",
    "id" : 619465290183630848,
    "created_at" : "2015-07-10 11:16:48 +0000",
    "user" : {
      "name" : "Kate Melchior",
      "screen_name" : "Kate_Melchior",
      "protected" : false,
      "id_str" : "528035811",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690263201632497664\/gUsnAmjB_normal.jpg",
      "id" : 528035811,
      "verified" : false
    }
  },
  "id" : 620361084340449280,
  "created_at" : "2015-07-12 22:36:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620360371006779392",
  "text" : "@Lluminous_ : (",
  "id" : 620360371006779392,
  "created_at" : "2015-07-12 22:33:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620354158718283780",
  "geo" : { },
  "id_str" : "620354901361729536",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle live in Dutchess County, NY. Lots of ticks.",
  "id" : 620354901361729536,
  "in_reply_to_status_id" : 620354158718283780,
  "created_at" : "2015-07-12 22:11:48 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620342349324009472",
  "geo" : { },
  "id_str" : "620354170864955393",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle curr. focus on thyroid. Waiting on more detailed blood work results from Endo.",
  "id" : 620354170864955393,
  "in_reply_to_status_id" : 620342349324009472,
  "created_at" : "2015-07-12 22:08:54 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620342349324009472",
  "geo" : { },
  "id_str" : "620353599672029185",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle Lyme was ruled out as lab said negative.. so no talk of coinfxns.",
  "id" : 620353599672029185,
  "in_reply_to_status_id" : 620342349324009472,
  "created_at" : "2015-07-12 22:06:38 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620342590840406016",
  "geo" : { },
  "id_str" : "620352648227745796",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle blood was drawn at her doc office. Probably Quest Diagnostics.",
  "id" : 620352648227745796,
  "in_reply_to_status_id" : 620342590840406016,
  "created_at" : "2015-07-12 22:02:51 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred O'Donnell",
      "screen_name" : "fred_od_photo",
      "indices" : [ 3, 17 ],
      "id_str" : "490232734",
      "id" : 490232734
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fred_od_photo\/status\/619598172776632320\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/0DcQINgIB1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJlBQD-UMAAIKXm.jpg",
      "id_str" : "619598167940542464",
      "id" : 619598167940542464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJlBQD-UMAAIKXm.jpg",
      "sizes" : [ {
        "h" : 791,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2725,
        "resize" : "fit",
        "w" : 3529
      } ],
      "display_url" : "pic.twitter.com\/0DcQINgIB1"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 56, 62 ]
    }, {
      "text" : "nature",
      "indices" : [ 63, 70 ]
    }, {
      "text" : "photography",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620339973292695552",
  "text" : "RT @fred_od_photo: Black Swan at the Colac Bird Reserve\n#birds #nature #photography http:\/\/t.co\/0DcQINgIB1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fred_od_photo\/status\/619598172776632320\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/0DcQINgIB1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJlBQD-UMAAIKXm.jpg",
        "id_str" : "619598167940542464",
        "id" : 619598167940542464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJlBQD-UMAAIKXm.jpg",
        "sizes" : [ {
          "h" : 791,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2725,
          "resize" : "fit",
          "w" : 3529
        } ],
        "display_url" : "pic.twitter.com\/0DcQINgIB1"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 37, 43 ]
      }, {
        "text" : "nature",
        "indices" : [ 44, 51 ]
      }, {
        "text" : "photography",
        "indices" : [ 52, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619598172776632320",
    "text" : "Black Swan at the Colac Bird Reserve\n#birds #nature #photography http:\/\/t.co\/0DcQINgIB1",
    "id" : 619598172776632320,
    "created_at" : "2015-07-10 20:04:50 +0000",
    "user" : {
      "name" : "Fred O'Donnell",
      "screen_name" : "fred_od_photo",
      "protected" : false,
      "id_str" : "490232734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000414226331\/32364109846fcd2fd06e4f4f76321bfd_normal.jpeg",
      "id" : 490232734,
      "verified" : false
    }
  },
  "id" : 620339973292695552,
  "created_at" : "2015-07-12 21:12:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 0, 12 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620334420550119424",
  "geo" : { },
  "id_str" : "620337683882246144",
  "in_reply_to_user_id" : 90733366,
  "text" : "@AlisynGayle thx for the links! : )",
  "id" : 620337683882246144,
  "in_reply_to_status_id" : 620334420550119424,
  "created_at" : "2015-07-12 21:03:23 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "indices" : [ 3, 12 ],
      "id_str" : "265346131",
      "id" : 265346131
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/620327635919331328\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/hWaHeaVytv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvYsBYVEAAlXZU.jpg",
      "id_str" : "620327624489897984",
      "id" : 620327624489897984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvYsBYVEAAlXZU.jpg",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hWaHeaVytv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620327977633619968",
  "text" : "RT @iauaauoo: Turtle dove http:\/\/t.co\/hWaHeaVytv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/620327635919331328\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/hWaHeaVytv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvYsBYVEAAlXZU.jpg",
        "id_str" : "620327624489897984",
        "id" : 620327624489897984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvYsBYVEAAlXZU.jpg",
        "sizes" : [ {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hWaHeaVytv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620327635919331328",
    "text" : "Turtle dove http:\/\/t.co\/hWaHeaVytv",
    "id" : 620327635919331328,
    "created_at" : "2015-07-12 20:23:28 +0000",
    "user" : {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "protected" : false,
      "id_str" : "265346131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768291432213774336\/m7AAnnuF_normal.jpg",
      "id" : 265346131,
      "verified" : false
    }
  },
  "id" : 620327977633619968,
  "created_at" : "2015-07-12 20:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "indices" : [ 3, 12 ],
      "id_str" : "265346131",
      "id" : 265346131
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/620327676352434176\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/vlAPnMNkU5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvYul7UEAAZSNX.jpg",
      "id_str" : "620327668660047872",
      "id" : 620327668660047872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvYul7UEAAZSNX.jpg",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vlAPnMNkU5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620327952945909760",
  "text" : "RT @iauaauoo: Lake in early morning http:\/\/t.co\/vlAPnMNkU5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/620327676352434176\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/vlAPnMNkU5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvYul7UEAAZSNX.jpg",
        "id_str" : "620327668660047872",
        "id" : 620327668660047872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvYul7UEAAZSNX.jpg",
        "sizes" : [ {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/vlAPnMNkU5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620327676352434176",
    "text" : "Lake in early morning http:\/\/t.co\/vlAPnMNkU5",
    "id" : 620327676352434176,
    "created_at" : "2015-07-12 20:23:37 +0000",
    "user" : {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "protected" : false,
      "id_str" : "265346131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768291432213774336\/m7AAnnuF_normal.jpg",
      "id" : 265346131,
      "verified" : false
    }
  },
  "id" : 620327952945909760,
  "created_at" : "2015-07-12 20:24:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Darnell",
      "screen_name" : "andydarnell",
      "indices" : [ 3, 15 ],
      "id_str" : "16982281",
      "id" : 16982281
    }, {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 62, 75 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AixEocWClr",
      "expanded_url" : "http:\/\/amzn.to\/1diNcfW",
      "display_url" : "amzn.to\/1diNcfW"
    } ]
  },
  "geo" : { },
  "id_str" : "620327359472922625",
  "text" : "RT @andydarnell: I just finished The Martian: A Novel. Thanks @adamrshields for the recommendation. Fun geeky read! http:\/\/t.co\/AixEocWClr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Shields",
        "screen_name" : "adamrshields",
        "indices" : [ 45, 58 ],
        "id_str" : "14835882",
        "id" : 14835882
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/AixEocWClr",
        "expanded_url" : "http:\/\/amzn.to\/1diNcfW",
        "display_url" : "amzn.to\/1diNcfW"
      } ]
    },
    "geo" : { },
    "id_str" : "620312575121719296",
    "text" : "I just finished The Martian: A Novel. Thanks @adamrshields for the recommendation. Fun geeky read! http:\/\/t.co\/AixEocWClr",
    "id" : 620312575121719296,
    "created_at" : "2015-07-12 19:23:37 +0000",
    "user" : {
      "name" : "Andy Darnell",
      "screen_name" : "andydarnell",
      "protected" : false,
      "id_str" : "16982281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775518187928576000\/mrFKLant_normal.jpg",
      "id" : 16982281,
      "verified" : false
    }
  },
  "id" : 620327359472922625,
  "created_at" : "2015-07-12 20:22:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Beth Pfeiffer",
      "screen_name" : "marybethpf",
      "indices" : [ 3, 14 ],
      "id_str" : "39181447",
      "id" : 39181447
    }, {
      "name" : "John Ferro",
      "screen_name" : "PoJoEnviro",
      "indices" : [ 73, 84 ],
      "id_str" : "214073670",
      "id" : 214073670
    }, {
      "name" : "LymeDiseaseChallenge",
      "screen_name" : "LymeChallenge",
      "indices" : [ 108, 122 ],
      "id_str" : "2837875803",
      "id" : 2837875803
    }, {
      "name" : "LymeDisease.org",
      "screen_name" : "Lymenews",
      "indices" : [ 123, 132 ],
      "id_str" : "47791514",
      "id" : 47791514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LymeDisease",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/xtxcoj6yz2",
      "expanded_url" : "http:\/\/www.poughkeepsiejournal.com\/story\/news\/health\/lyme-disease\/2015\/07\/11\/lyme-disease-trends-research-legislation\/29769685\/",
      "display_url" : "poughkeepsiejournal.com\/story\/news\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620326947734880257",
  "text" : "RT @marybethpf: Great roundup of #LymeDisease challenges and research by @PoJoEnviro http:\/\/t.co\/xtxcoj6yz2 @LymeChallenge @Lymenews @Angel\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Ferro",
        "screen_name" : "PoJoEnviro",
        "indices" : [ 57, 68 ],
        "id_str" : "214073670",
        "id" : 214073670
      }, {
        "name" : "LymeDiseaseChallenge",
        "screen_name" : "LymeChallenge",
        "indices" : [ 92, 106 ],
        "id_str" : "2837875803",
        "id" : 2837875803
      }, {
        "name" : "LymeDisease.org",
        "screen_name" : "Lymenews",
        "indices" : [ 107, 116 ],
        "id_str" : "47791514",
        "id" : 47791514
      }, {
        "name" : "Angela LeBrun",
        "screen_name" : "Angela4design",
        "indices" : [ 117, 131 ],
        "id_str" : "59268268",
        "id" : 59268268
      }, {
        "name" : "Lyme Disease UK",
        "screen_name" : "UKLyme",
        "indices" : [ 132, 139 ],
        "id_str" : "1313589116",
        "id" : 1313589116
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LymeDisease",
        "indices" : [ 17, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/xtxcoj6yz2",
        "expanded_url" : "http:\/\/www.poughkeepsiejournal.com\/story\/news\/health\/lyme-disease\/2015\/07\/11\/lyme-disease-trends-research-legislation\/29769685\/",
        "display_url" : "poughkeepsiejournal.com\/story\/news\/hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "620236874272145408",
    "text" : "Great roundup of #LymeDisease challenges and research by @PoJoEnviro http:\/\/t.co\/xtxcoj6yz2 @LymeChallenge @Lymenews @Angela4design @UKLyme",
    "id" : 620236874272145408,
    "created_at" : "2015-07-12 14:22:48 +0000",
    "user" : {
      "name" : "Mary Beth Pfeiffer",
      "screen_name" : "marybethpf",
      "protected" : false,
      "id_str" : "39181447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750153171180355585\/np5KVNLf_normal.jpg",
      "id" : 39181447,
      "verified" : false
    }
  },
  "id" : 620326947734880257,
  "created_at" : "2015-07-12 20:20:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "indices" : [ 3, 10 ],
      "id_str" : "163535738",
      "id" : 163535738
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lesism\/status\/620305938256371712\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7oXcm4nGS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvE9meWsAAoJ8x.jpg",
      "id_str" : "620305936272502784",
      "id" : 620305936272502784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvE9meWsAAoJ8x.jpg",
      "sizes" : [ {
        "h" : 643,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/7oXcm4nGS3"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Lesism\/status\/620305938256371712\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7oXcm4nGS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvE9qhWEAAySTT.jpg",
      "id_str" : "620305937358786560",
      "id" : 620305937358786560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvE9qhWEAAySTT.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 499
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 499
      } ],
      "display_url" : "pic.twitter.com\/7oXcm4nGS3"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Lesism\/status\/620305938256371712\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/7oXcm4nGS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvE9ozWcAEKqLK.jpg",
      "id_str" : "620305936897437697",
      "id" : 620305936897437697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvE9ozWcAEKqLK.jpg",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/7oXcm4nGS3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620306496186937344",
  "text" : "RT @Lesism: \"Where's the cat? Did you leave a window open? Call the police!\" http:\/\/t.co\/7oXcm4nGS3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lesism\/status\/620305938256371712\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/7oXcm4nGS3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvE9meWsAAoJ8x.jpg",
        "id_str" : "620305936272502784",
        "id" : 620305936272502784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvE9meWsAAoJ8x.jpg",
        "sizes" : [ {
          "h" : 643,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/7oXcm4nGS3"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Lesism\/status\/620305938256371712\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/7oXcm4nGS3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvE9qhWEAAySTT.jpg",
        "id_str" : "620305937358786560",
        "id" : 620305937358786560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvE9qhWEAAySTT.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 499
        } ],
        "display_url" : "pic.twitter.com\/7oXcm4nGS3"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Lesism\/status\/620305938256371712\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/7oXcm4nGS3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJvE9ozWcAEKqLK.jpg",
        "id_str" : "620305936897437697",
        "id" : 620305936897437697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJvE9ozWcAEKqLK.jpg",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/7oXcm4nGS3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620305938256371712",
    "text" : "\"Where's the cat? Did you leave a window open? Call the police!\" http:\/\/t.co\/7oXcm4nGS3",
    "id" : 620305938256371712,
    "created_at" : "2015-07-12 18:57:15 +0000",
    "user" : {
      "name" : "Les Floyd",
      "screen_name" : "Lesism",
      "protected" : false,
      "id_str" : "163535738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572425243185008640\/5Pr-CKc3_normal.jpeg",
      "id" : 163535738,
      "verified" : false
    }
  },
  "id" : 620306496186937344,
  "created_at" : "2015-07-12 18:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620298375762706432",
  "text" : "blah.. im not keeping on top of things due to my lazy nature.. didnt check the paperwork. i need to be slapped.",
  "id" : 620298375762706432,
  "created_at" : "2015-07-12 18:27:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 0, 12 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620276673418674176",
  "geo" : { },
  "id_str" : "620277944838172672",
  "in_reply_to_user_id" : 51846392,
  "text" : "@Jeweldspear def take it easy today and stay cool. : )",
  "id" : 620277944838172672,
  "in_reply_to_status_id" : 620276673418674176,
  "created_at" : "2015-07-12 17:06:00 +0000",
  "in_reply_to_screen_name" : "Jeweldspear",
  "in_reply_to_user_id_str" : "51846392",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Atanas G Atanasov",
      "screen_name" : "_atanas_",
      "indices" : [ 3, 12 ],
      "id_str" : "2257558088",
      "id" : 2257558088
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetAPaper",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/djTy6iRIXR",
      "expanded_url" : "https:\/\/twitter.com\/_atanas_\/status\/614687339781226496",
      "display_url" : "twitter.com\/_atanas_\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620277053024280576",
  "text" : "RT @_atanas_: High pre-hospital vitamin D serum levels are associated with lower 30-day mortality https:\/\/t.co\/djTy6iRIXR\n\n#TweetAPaper @Ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dr. Gu",
        "screen_name" : "Marianne_Guenot",
        "indices" : [ 122, 138 ],
        "id_str" : "2805863557",
        "id" : 2805863557
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TweetAPaper",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/djTy6iRIXR",
        "expanded_url" : "https:\/\/twitter.com\/_atanas_\/status\/614687339781226496",
        "display_url" : "twitter.com\/_atanas_\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619776663199592449",
    "text" : "High pre-hospital vitamin D serum levels are associated with lower 30-day mortality https:\/\/t.co\/djTy6iRIXR\n\n#TweetAPaper @Marianne_Guenot",
    "id" : 619776663199592449,
    "created_at" : "2015-07-11 07:54:06 +0000",
    "user" : {
      "name" : "Dr Atanas G Atanasov",
      "screen_name" : "_atanas_",
      "protected" : false,
      "id_str" : "2257558088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566245387904626688\/CejivL-v_normal.jpeg",
      "id" : 2257558088,
      "verified" : false
    }
  },
  "id" : 620277053024280576,
  "created_at" : "2015-07-12 17:02:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 0, 12 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620273976606994432",
  "geo" : { },
  "id_str" : "620275104728109056",
  "in_reply_to_user_id" : 51846392,
  "text" : "@Jeweldspear are you getting fluids down? If not better today, get to ER. Best.",
  "id" : 620275104728109056,
  "in_reply_to_status_id" : 620273976606994432,
  "created_at" : "2015-07-12 16:54:43 +0000",
  "in_reply_to_screen_name" : "Jeweldspear",
  "in_reply_to_user_id_str" : "51846392",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620268521306615808",
  "geo" : { },
  "id_str" : "620272088549588993",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre breathe.. ((hugs))",
  "id" : 620272088549588993,
  "in_reply_to_status_id" : 620268521306615808,
  "created_at" : "2015-07-12 16:42:44 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620236589684387840",
  "geo" : { },
  "id_str" : "620271122593021953",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides one of my faves...",
  "id" : 620271122593021953,
  "in_reply_to_status_id" : 620236589684387840,
  "created_at" : "2015-07-12 16:38:54 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620270419841544192",
  "text" : "@Lluminous_ yup. Ppl think I'm sweet but they haven't seen my karma... ugh.",
  "id" : 620270419841544192,
  "created_at" : "2015-07-12 16:36:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620207841224192001",
  "geo" : { },
  "id_str" : "620269942131326980",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ((((hugs))))",
  "id" : 620269942131326980,
  "in_reply_to_status_id" : 620207841224192001,
  "created_at" : "2015-07-12 16:34:12 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620268389148270592",
  "text" : "RT @TheGoldenMirror: They who defend their cages are the ones most trapped of all. Learn to see your bars for what they are and learn to st\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620246616008753152",
    "text" : "They who defend their cages are the ones most trapped of all. Learn to see your bars for what they are and learn to step through them.",
    "id" : 620246616008753152,
    "created_at" : "2015-07-12 15:01:31 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 620268389148270592,
  "created_at" : "2015-07-12 16:28:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Miguel)))",
      "screen_name" : "buddhatree",
      "indices" : [ 3, 14 ],
      "id_str" : "144858839",
      "id" : 144858839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620267328794697728",
  "text" : "RT @buddhatree: Oh Pluto has a moon? Then it's a planet. Boom. Done. #science",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "science",
        "indices" : [ 53, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620247378348498946",
    "text" : "Oh Pluto has a moon? Then it's a planet. Boom. Done. #science",
    "id" : 620247378348498946,
    "created_at" : "2015-07-12 15:04:33 +0000",
    "user" : {
      "name" : "(((Miguel)))",
      "screen_name" : "buddhatree",
      "protected" : false,
      "id_str" : "144858839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660673332522545152\/7fIJBCXu_normal.jpg",
      "id" : 144858839,
      "verified" : false
    }
  },
  "id" : 620267328794697728,
  "created_at" : "2015-07-12 16:23:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620266558053552128",
  "text" : "RT @ZachsMind: You know what's unnatural? A belief system that tries to make everyone conform. Controlling individual thought is what's tru\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620259152116346881",
    "text" : "You know what's unnatural? A belief system that tries to make everyone conform. Controlling individual thought is what's truly unnatural.",
    "id" : 620259152116346881,
    "created_at" : "2015-07-12 15:51:20 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 620266558053552128,
  "created_at" : "2015-07-12 16:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/620264782109782016\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/NkxaIiMnp1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJufgwrUkAAsj3j.jpg",
      "id_str" : "620264758864809984",
      "id" : 620264758864809984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJufgwrUkAAsj3j.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 468,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NkxaIiMnp1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620265558152491012",
  "text" : "RT @SciencePorn: Bridge made for local crab population http:\/\/t.co\/NkxaIiMnp1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/620264782109782016\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/NkxaIiMnp1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJufgwrUkAAsj3j.jpg",
        "id_str" : "620264758864809984",
        "id" : 620264758864809984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJufgwrUkAAsj3j.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 265,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 840
        }, {
          "h" : 468,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NkxaIiMnp1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620264782109782016",
    "text" : "Bridge made for local crab population http:\/\/t.co\/NkxaIiMnp1",
    "id" : 620264782109782016,
    "created_at" : "2015-07-12 16:13:42 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 620265558152491012,
  "created_at" : "2015-07-12 16:16:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 3, 14 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Wolf_Mommy\/status\/620068999401836544\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/XJvEMx7TrY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJrtdBkUcAAyP7j.jpg",
      "id_str" : "620068981609623552",
      "id" : 620068981609623552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJrtdBkUcAAyP7j.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 964
      } ],
      "display_url" : "pic.twitter.com\/XJvEMx7TrY"
    } ],
    "hashtags" : [ {
      "text" : "cosleeping",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620069499006517248",
  "text" : "RT @Wolf_Mommy: The most use this crib has ever gotten. #cosleeping http:\/\/t.co\/XJvEMx7TrY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wolf_Mommy\/status\/620068999401836544\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/XJvEMx7TrY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJrtdBkUcAAyP7j.jpg",
        "id_str" : "620068981609623552",
        "id" : 620068981609623552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJrtdBkUcAAyP7j.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 964
        }, {
          "h" : 637,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 964
        } ],
        "display_url" : "pic.twitter.com\/XJvEMx7TrY"
      } ],
      "hashtags" : [ {
        "text" : "cosleeping",
        "indices" : [ 40, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620068999401836544",
    "text" : "The most use this crib has ever gotten. #cosleeping http:\/\/t.co\/XJvEMx7TrY",
    "id" : 620068999401836544,
    "created_at" : "2015-07-12 03:15:44 +0000",
    "user" : {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "protected" : false,
      "id_str" : "187357122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000077645055\/7c54c4e8fb8f48b0dead155c682c67da_normal.jpeg",
      "id" : 187357122,
      "verified" : false
    }
  },
  "id" : 620069499006517248,
  "created_at" : "2015-07-12 03:17:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/517744163953975296\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/YL6U2dggB9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9lkubCcAE8-d2.jpg",
      "id_str" : "517744163782029313",
      "id" : 517744163782029313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9lkubCcAE8-d2.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/YL6U2dggB9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620066870423617536",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/YL6U2dggB9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/517744163953975296\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/YL6U2dggB9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By9lkubCcAE8-d2.jpg",
        "id_str" : "517744163782029313",
        "id" : 517744163782029313,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9lkubCcAE8-d2.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/YL6U2dggB9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620065236188561408",
    "text" : "http:\/\/t.co\/YL6U2dggB9",
    "id" : 620065236188561408,
    "created_at" : "2015-07-12 03:00:47 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 620066870423617536,
  "created_at" : "2015-07-12 03:07:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620053081603055616",
  "text" : "RT @Floridaline: A god who is all-knowing and all-powerful and who does not even make sure his creatures understand his (cont) http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/2SOliIqGjp",
        "expanded_url" : "http:\/\/tl.gd\/n_1sn1edg",
        "display_url" : "tl.gd\/n_1sn1edg"
      } ]
    },
    "geo" : { },
    "id_str" : "620048965116010496",
    "text" : "A god who is all-knowing and all-powerful and who does not even make sure his creatures understand his (cont) http:\/\/t.co\/2SOliIqGjp",
    "id" : 620048965116010496,
    "created_at" : "2015-07-12 01:56:07 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 620053081603055616,
  "created_at" : "2015-07-12 02:12:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620052146319396864",
  "text" : "@Lluminous_ oh gosh.. no. ((hugs))",
  "id" : 620052146319396864,
  "created_at" : "2015-07-12 02:08:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Take That Darwin",
      "screen_name" : "TakeThatDarwin",
      "indices" : [ 0, 15 ],
      "id_str" : "920925912",
      "id" : 920925912
    }, {
      "name" : "Amalek",
      "screen_name" : "deisidiamonia",
      "indices" : [ 16, 30 ],
      "id_str" : "280827427",
      "id" : 280827427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618870883231367168",
  "geo" : { },
  "id_str" : "620051673013202945",
  "in_reply_to_user_id" : 920925912,
  "text" : "@TakeThatDarwin @deisidiamonia LOL",
  "id" : 620051673013202945,
  "in_reply_to_status_id" : 618870883231367168,
  "created_at" : "2015-07-12 02:06:53 +0000",
  "in_reply_to_screen_name" : "TakeThatDarwin",
  "in_reply_to_user_id_str" : "920925912",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vote For Bernie",
      "screen_name" : "vote_for_bernie",
      "indices" : [ 95, 111 ],
      "id_str" : "3312879640",
      "id" : 3312879640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/vjqCVEF68h",
      "expanded_url" : "http:\/\/voteforbernie.org\/",
      "display_url" : "voteforbernie.org"
    } ]
  },
  "geo" : { },
  "id_str" : "619921103746678784",
  "text" : "How and when to vote for Bernie Sanders in the Primaries (by State) http:\/\/t.co\/vjqCVEF68h via @vote_for_bernie",
  "id" : 619921103746678784,
  "created_at" : "2015-07-11 17:28:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "god",
      "indices" : [ 45, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619875160385040384",
  "text" : "RT @ZachsMind: Why would a loving omniscient #god have ever created hell in the first place, if there was no rational need for one?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "god",
        "indices" : [ 30, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619710137222049793",
    "text" : "Why would a loving omniscient #god have ever created hell in the first place, if there was no rational need for one?",
    "id" : 619710137222049793,
    "created_at" : "2015-07-11 03:29:45 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 619875160385040384,
  "created_at" : "2015-07-11 14:25:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Paris Nicolaides",
      "screen_name" : "OdysseusCA",
      "indices" : [ 57, 68 ],
      "id_str" : "36462468",
      "id" : 36462468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619875035533213696",
  "text" : "RT @ZachsMind: Why would an all powerful all knowing god @OdysseusCA have to fight at all? How could Lucifer even be a threat to a god?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paris Nicolaides",
        "screen_name" : "OdysseusCA",
        "indices" : [ 42, 53 ],
        "id_str" : "36462468",
        "id" : 36462468
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "619710544120029184",
    "geo" : { },
    "id_str" : "619711111248502784",
    "in_reply_to_user_id" : 36462468,
    "text" : "Why would an all powerful all knowing god @OdysseusCA have to fight at all? How could Lucifer even be a threat to a god?",
    "id" : 619711111248502784,
    "in_reply_to_status_id" : 619710544120029184,
    "created_at" : "2015-07-11 03:33:37 +0000",
    "in_reply_to_screen_name" : "OdysseusCA",
    "in_reply_to_user_id_str" : "36462468",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 619875035533213696,
  "created_at" : "2015-07-11 14:24:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619874980399054848",
  "text" : "RT @ZachsMind: i mean if a god can't defend himself against his own creation, that's not a god. that's an idiot playing with fire.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619711248943353856",
    "text" : "i mean if a god can't defend himself against his own creation, that's not a god. that's an idiot playing with fire.",
    "id" : 619711248943353856,
    "created_at" : "2015-07-11 03:34:10 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 619874980399054848,
  "created_at" : "2015-07-11 14:24:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lorraine Moss",
      "screen_name" : "MossLorraine",
      "indices" : [ 3, 16 ],
      "id_str" : "471076453",
      "id" : 471076453
    }, {
      "name" : "Martin Hume",
      "screen_name" : "martinhume",
      "indices" : [ 18, 29 ],
      "id_str" : "214343084",
      "id" : 214343084
    }, {
      "name" : "The Telegraph",
      "screen_name" : "Telegraph",
      "indices" : [ 30, 40 ],
      "id_str" : "16343974",
      "id" : 16343974
    }, {
      "name" : "Sarah Knapton",
      "screen_name" : "sarahknapton",
      "indices" : [ 41, 54 ],
      "id_str" : "18604355",
      "id" : 18604355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619695911497781248",
  "text" : "RT @MossLorraine: @martinhume @Telegraph @sarahknapton well did anyone really think there'd be no drawbacks to pesticides??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Hume",
        "screen_name" : "martinhume",
        "indices" : [ 0, 11 ],
        "id_str" : "214343084",
        "id" : 214343084
      }, {
        "name" : "The Telegraph",
        "screen_name" : "Telegraph",
        "indices" : [ 12, 22 ],
        "id_str" : "16343974",
        "id" : 16343974
      }, {
        "name" : "Sarah Knapton",
        "screen_name" : "sarahknapton",
        "indices" : [ 23, 36 ],
        "id_str" : "18604355",
        "id" : 18604355
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "619635157813841920",
    "geo" : { },
    "id_str" : "619638340963430401",
    "in_reply_to_user_id" : 214343084,
    "text" : "@martinhume @Telegraph @sarahknapton well did anyone really think there'd be no drawbacks to pesticides??",
    "id" : 619638340963430401,
    "in_reply_to_status_id" : 619635157813841920,
    "created_at" : "2015-07-10 22:44:27 +0000",
    "in_reply_to_screen_name" : "martinhume",
    "in_reply_to_user_id_str" : "214343084",
    "user" : {
      "name" : "Lorraine Moss",
      "screen_name" : "MossLorraine",
      "protected" : false,
      "id_str" : "471076453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482155653365268481\/QEUa0HmW_normal.jpeg",
      "id" : 471076453,
      "verified" : false
    }
  },
  "id" : 619695911497781248,
  "created_at" : "2015-07-11 02:33:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "indices" : [ 3, 17 ],
      "id_str" : "195173057",
      "id" : 195173057
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lindapoitevin\/status\/619694236397604865\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/bk8cYaAanr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJmYm5MUEAEl57C.jpg",
      "id_str" : "619694217695072257",
      "id" : 619694217695072257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJmYm5MUEAEl57C.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bk8cYaAanr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619695028882030592",
  "text" : "RT @lindapoitevin: It's been like this for an hour. My arm is dead. :P http:\/\/t.co\/bk8cYaAanr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lindapoitevin\/status\/619694236397604865\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/bk8cYaAanr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJmYm5MUEAEl57C.jpg",
        "id_str" : "619694217695072257",
        "id" : 619694217695072257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJmYm5MUEAEl57C.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bk8cYaAanr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619694236397604865",
    "text" : "It's been like this for an hour. My arm is dead. :P http:\/\/t.co\/bk8cYaAanr",
    "id" : 619694236397604865,
    "created_at" : "2015-07-11 02:26:33 +0000",
    "user" : {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "protected" : false,
      "id_str" : "195173057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653593067958571008\/PyqlHnTV_normal.jpg",
      "id" : 195173057,
      "verified" : false
    }
  },
  "id" : 619695028882030592,
  "created_at" : "2015-07-11 02:29:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAH",
      "screen_name" : "NAHypothyroid",
      "indices" : [ 3, 17 ],
      "id_str" : "3185611998",
      "id" : 3185611998
    }, {
      "name" : "Hypothyroid Mom",
      "screen_name" : "HypothyroidMom",
      "indices" : [ 93, 108 ],
      "id_str" : "842279588",
      "id" : 842279588
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroiddoctors",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/712PuGGHqq",
      "expanded_url" : "http:\/\/ow.ly\/PrV8A",
      "display_url" : "ow.ly\/PrV8A"
    } ]
  },
  "geo" : { },
  "id_str" : "619668377737515008",
  "text" : "RT @NAHypothyroid: Read Tristin's journey with #thyroiddoctors http:\/\/t.co\/712PuGGHqq Thanks @HypothyroidMom!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hypothyroid Mom",
        "screen_name" : "HypothyroidMom",
        "indices" : [ 74, 89 ],
        "id_str" : "842279588",
        "id" : 842279588
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thyroiddoctors",
        "indices" : [ 28, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/712PuGGHqq",
        "expanded_url" : "http:\/\/ow.ly\/PrV8A",
        "display_url" : "ow.ly\/PrV8A"
      } ]
    },
    "geo" : { },
    "id_str" : "619628533183348736",
    "text" : "Read Tristin's journey with #thyroiddoctors http:\/\/t.co\/712PuGGHqq Thanks @HypothyroidMom!",
    "id" : 619628533183348736,
    "created_at" : "2015-07-10 22:05:29 +0000",
    "user" : {
      "name" : "NAH",
      "screen_name" : "NAHypothyroid",
      "protected" : false,
      "id_str" : "3185611998",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794306852343324672\/vUkyPLXy_normal.jpg",
      "id" : 3185611998,
      "verified" : false
    }
  },
  "id" : 619668377737515008,
  "created_at" : "2015-07-11 00:43:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/619640551802060800\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/vJrHOoiECi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJlnzEGWUAA12Bt.jpg",
      "id_str" : "619640550711513088",
      "id" : 619640550711513088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJlnzEGWUAA12Bt.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 425
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vJrHOoiECi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619641260312252416",
  "text" : "RT @CUMALi_YILDIZ: Silent reflections on a lake in Scotland http:\/\/t.co\/vJrHOoiECi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/619640551802060800\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/vJrHOoiECi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJlnzEGWUAA12Bt.jpg",
        "id_str" : "619640550711513088",
        "id" : 619640550711513088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJlnzEGWUAA12Bt.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 425
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vJrHOoiECi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619640551802060800",
    "text" : "Silent reflections on a lake in Scotland http:\/\/t.co\/vJrHOoiECi",
    "id" : 619640551802060800,
    "created_at" : "2015-07-10 22:53:14 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 619641260312252416,
  "created_at" : "2015-07-10 22:56:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619576136436088832",
  "geo" : { },
  "id_str" : "619634117714571265",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time that is a creepy comment!",
  "id" : 619634117714571265,
  "in_reply_to_status_id" : 619576136436088832,
  "created_at" : "2015-07-10 22:27:40 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/OJo8zTc5O0",
      "expanded_url" : "https:\/\/shar.es\/1qNcZy",
      "display_url" : "shar.es\/1qNcZy"
    } ]
  },
  "geo" : { },
  "id_str" : "619629493280481284",
  "text" : "teacher outed as atheist... &gt; The Sequel to God\u2019s Not Dead Happened in My Classroom, But In Reverse https:\/\/t.co\/OJo8zTc5O0",
  "id" : 619629493280481284,
  "created_at" : "2015-07-10 22:09:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lyme",
      "indices" : [ 5, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619574980918018048",
  "text" : "told #Lyme negative. looked at results.. band 41 positive, band 23 indetermined. test=LYME AB WEST-BLOT IGG\/IGM (4033-7)",
  "id" : 619574980918018048,
  "created_at" : "2015-07-10 18:32:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Digital Reader",
      "screen_name" : "inkbitspixels",
      "indices" : [ 3, 17 ],
      "id_str" : "2790546893",
      "id" : 2790546893
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/inkbitspixels\/status\/619308124348874752\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/qULHaISQUP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJg5dSxUMAQ_q5R.png",
      "id_str" : "619308124181114884",
      "id" : 619308124181114884,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJg5dSxUMAQ_q5R.png",
      "sizes" : [ {
        "h" : 172,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 250
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 250
      } ],
      "display_url" : "pic.twitter.com\/qULHaISQUP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/75FRBduIdU",
      "expanded_url" : "http:\/\/dlvr.it\/BTG3y9",
      "display_url" : "dlvr.it\/BTG3y9"
    } ]
  },
  "geo" : { },
  "id_str" : "619567764924186624",
  "text" : "RT @inkbitspixels: Uncle http:\/\/t.co\/75FRBduIdU http:\/\/t.co\/qULHaISQUP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/inkbitspixels\/status\/619308124348874752\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/qULHaISQUP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJg5dSxUMAQ_q5R.png",
        "id_str" : "619308124181114884",
        "id" : 619308124181114884,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJg5dSxUMAQ_q5R.png",
        "sizes" : [ {
          "h" : 172,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 250
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 250
        } ],
        "display_url" : "pic.twitter.com\/qULHaISQUP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/75FRBduIdU",
        "expanded_url" : "http:\/\/dlvr.it\/BTG3y9",
        "display_url" : "dlvr.it\/BTG3y9"
      } ]
    },
    "geo" : { },
    "id_str" : "619308124348874752",
    "text" : "Uncle http:\/\/t.co\/75FRBduIdU http:\/\/t.co\/qULHaISQUP",
    "id" : 619308124348874752,
    "created_at" : "2015-07-10 00:52:17 +0000",
    "user" : {
      "name" : "The Digital Reader",
      "screen_name" : "inkbitspixels",
      "protected" : false,
      "id_str" : "2790546893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619304105715089408\/9PRPsrJn_normal.png",
      "id" : 2790546893,
      "verified" : false
    }
  },
  "id" : 619567764924186624,
  "created_at" : "2015-07-10 18:04:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/IaLJXrTrx3",
      "expanded_url" : "http:\/\/tl.gd\/nk8u1v",
      "display_url" : "tl.gd\/nk8u1v"
    } ]
  },
  "geo" : { },
  "id_str" : "619536771290910720",
  "text" : "RT @Floridaline: \"The idea that a fully conscious creature would undergo physical and mental torture through (cont) http:\/\/t.co\/IaLJXrTrx3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/IaLJXrTrx3",
        "expanded_url" : "http:\/\/tl.gd\/nk8u1v",
        "display_url" : "tl.gd\/nk8u1v"
      } ]
    },
    "geo" : { },
    "id_str" : "619535461078433792",
    "text" : "\"The idea that a fully conscious creature would undergo physical and mental torture through (cont) http:\/\/t.co\/IaLJXrTrx3",
    "id" : 619535461078433792,
    "created_at" : "2015-07-10 15:55:38 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 619536771290910720,
  "created_at" : "2015-07-10 16:00:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel",
      "screen_name" : "RedWineMonk",
      "indices" : [ 3, 15 ],
      "id_str" : "124465060",
      "id" : 124465060
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RedWineMonk\/status\/619528893914050561\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/dNGn1QD40O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJkCPPEUcAAn2AH.jpg",
      "id_str" : "619528884506095616",
      "id" : 619528884506095616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJkCPPEUcAAn2AH.jpg",
      "sizes" : [ {
        "h" : 901,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/dNGn1QD40O"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619532396380209152",
  "text" : "RT @RedWineMonk: Little BlackCap from my walk today.\n#birds http:\/\/t.co\/dNGn1QD40O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RedWineMonk\/status\/619528893914050561\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/dNGn1QD40O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJkCPPEUcAAn2AH.jpg",
        "id_str" : "619528884506095616",
        "id" : 619528884506095616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJkCPPEUcAAn2AH.jpg",
        "sizes" : [ {
          "h" : 901,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/dNGn1QD40O"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 36, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619528893914050561",
    "text" : "Little BlackCap from my walk today.\n#birds http:\/\/t.co\/dNGn1QD40O",
    "id" : 619528893914050561,
    "created_at" : "2015-07-10 15:29:33 +0000",
    "user" : {
      "name" : "Daniel",
      "screen_name" : "RedWineMonk",
      "protected" : false,
      "id_str" : "124465060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697879998175309830\/YkwzLVNt_normal.jpg",
      "id" : 124465060,
      "verified" : false
    }
  },
  "id" : 619532396380209152,
  "created_at" : "2015-07-10 15:43:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher L.Nelson",
      "screen_name" : "aGlimpseOfNatur",
      "indices" : [ 3, 19 ],
      "id_str" : "948148885",
      "id" : 948148885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "photography",
      "indices" : [ 81, 93 ]
    }, {
      "text" : "sunrise",
      "indices" : [ 94, 102 ]
    }, {
      "text" : "country",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "clouds",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619532156910575616",
  "text" : "RT @aGlimpseOfNatur: Looking down a country road at sunrise, central IL.\n#nature #photography #sunrise #country #clouds\u2026 https:\/\/t.co\/g9v5T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "photography",
        "indices" : [ 60, 72 ]
      }, {
        "text" : "sunrise",
        "indices" : [ 73, 81 ]
      }, {
        "text" : "country",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "clouds",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/g9v5Ts2GnV",
        "expanded_url" : "https:\/\/instagram.com\/p\/49fThht_XO\/",
        "display_url" : "instagram.com\/p\/49fThht_XO\/"
      } ]
    },
    "geo" : { },
    "id_str" : "619529592014045184",
    "text" : "Looking down a country road at sunrise, central IL.\n#nature #photography #sunrise #country #clouds\u2026 https:\/\/t.co\/g9v5Ts2GnV",
    "id" : 619529592014045184,
    "created_at" : "2015-07-10 15:32:19 +0000",
    "user" : {
      "name" : "Christopher L.Nelson",
      "screen_name" : "aGlimpseOfNatur",
      "protected" : false,
      "id_str" : "948148885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000440341160\/57de693b0035faa61f82dad137cdf728_normal.jpeg",
      "id" : 948148885,
      "verified" : false
    }
  },
  "id" : 619532156910575616,
  "created_at" : "2015-07-10 15:42:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dianna E Anderson",
      "screen_name" : "diannaeanderson",
      "indices" : [ 3, 19 ],
      "id_str" : "41939243",
      "id" : 41939243
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619531976391938048",
  "text" : "RT @diannaeanderson: \u2026and going, \u201CA rainbow doesn\u2019t seem like a terrible thing. What does it do? Glitter at you?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "619528616204828672",
    "geo" : { },
    "id_str" : "619528762107953154",
    "in_reply_to_user_id" : 41939243,
    "text" : "\u2026and going, \u201CA rainbow doesn\u2019t seem like a terrible thing. What does it do? Glitter at you?\"",
    "id" : 619528762107953154,
    "in_reply_to_status_id" : 619528616204828672,
    "created_at" : "2015-07-10 15:29:01 +0000",
    "in_reply_to_screen_name" : "diannaeanderson",
    "in_reply_to_user_id_str" : "41939243",
    "user" : {
      "name" : "Dianna E Anderson",
      "screen_name" : "diannaeanderson",
      "protected" : false,
      "id_str" : "41939243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695538623568080896\/93W_dXCZ_normal.jpg",
      "id" : 41939243,
      "verified" : false
    }
  },
  "id" : 619531976391938048,
  "created_at" : "2015-07-10 15:41:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619530124879212544",
  "geo" : { },
  "id_str" : "619531643196411904",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe awww.. ((hugs)) for you and the pup",
  "id" : 619531643196411904,
  "in_reply_to_status_id" : 619530124879212544,
  "created_at" : "2015-07-10 15:40:28 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonei B Csoka, PhD",
      "screen_name" : "abcsoka",
      "indices" : [ 3, 11 ],
      "id_str" : "245520753",
      "id" : 245520753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/FtpdtoCivb",
      "expanded_url" : "http:\/\/nyti.ms\/1fqxrIl",
      "display_url" : "nyti.ms\/1fqxrIl"
    } ]
  },
  "geo" : { },
  "id_str" : "619325526017200129",
  "text" : "RT @abcsoka: Scientists Demonstrate Animal Mind-Melds http:\/\/t.co\/FtpdtoCivb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/FtpdtoCivb",
        "expanded_url" : "http:\/\/nyti.ms\/1fqxrIl",
        "display_url" : "nyti.ms\/1fqxrIl"
      } ]
    },
    "geo" : { },
    "id_str" : "619245334338736128",
    "text" : "Scientists Demonstrate Animal Mind-Melds http:\/\/t.co\/FtpdtoCivb",
    "id" : 619245334338736128,
    "created_at" : "2015-07-09 20:42:47 +0000",
    "user" : {
      "name" : "Antonei B Csoka, PhD",
      "screen_name" : "abcsoka",
      "protected" : false,
      "id_str" : "245520753",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2642191737\/a89301660ea0faa6123aed58d59ca6f8_normal.jpeg",
      "id" : 245520753,
      "verified" : true
    }
  },
  "id" : 619325526017200129,
  "created_at" : "2015-07-10 02:01:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619283223852548096",
  "geo" : { },
  "id_str" : "619320482081411072",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem adorable!",
  "id" : 619320482081411072,
  "in_reply_to_status_id" : 619283223852548096,
  "created_at" : "2015-07-10 01:41:24 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/pCG4GFaOQK",
      "expanded_url" : "https:\/\/twitter.com\/Harvey_Art\/status\/619193434386104321",
      "display_url" : "twitter.com\/Harvey_Art\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619318058537066496",
  "text" : "beautiful! https:\/\/t.co\/pCG4GFaOQK",
  "id" : 619318058537066496,
  "created_at" : "2015-07-10 01:31:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/X3Pq3eiPkK",
      "expanded_url" : "https:\/\/twitter.com\/Chickypoo333\/status\/619162660655902720",
      "display_url" : "twitter.com\/Chickypoo333\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619164920131756032",
  "text" : "i'll have to try this... https:\/\/t.co\/X3Pq3eiPkK",
  "id" : 619164920131756032,
  "created_at" : "2015-07-09 15:23:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Morrison",
      "screen_name" : "JamesPMorrison",
      "indices" : [ 3, 18 ],
      "id_str" : "23125412",
      "id" : 23125412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618952109338267649",
  "text" : "RT @JamesPMorrison: A governor &amp; state legislators are actually trying to end the weekend for workers. Think about that agenda. Let it sink\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618949460979159040",
    "text" : "A governor &amp; state legislators are actually trying to end the weekend for workers. Think about that agenda. Let it sink in. You OK w\/ that?",
    "id" : 618949460979159040,
    "created_at" : "2015-07-09 01:07:05 +0000",
    "user" : {
      "name" : "James Morrison",
      "screen_name" : "JamesPMorrison",
      "protected" : false,
      "id_str" : "23125412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680571620180639748\/yNkgM7wB_normal.jpg",
      "id" : 23125412,
      "verified" : true
    }
  },
  "id" : 618952109338267649,
  "created_at" : "2015-07-09 01:17:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jjkkkkk",
      "screen_name" : "verwon",
      "indices" : [ 3, 10 ],
      "id_str" : "754498613858926592",
      "id" : 754498613858926592
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/verwon\/status\/618621074641584128\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/SMTzZ4sZZd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJXIkw0UYAA2R9H.jpg",
      "id_str" : "618621057738498048",
      "id" : 618621057738498048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJXIkw0UYAA2R9H.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 880,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SMTzZ4sZZd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618866723148681216",
  "text" : "RT @verwon: http:\/\/t.co\/SMTzZ4sZZd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/verwon\/status\/618621074641584128\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/SMTzZ4sZZd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJXIkw0UYAA2R9H.jpg",
        "id_str" : "618621057738498048",
        "id" : 618621057738498048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJXIkw0UYAA2R9H.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 880,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 698
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SMTzZ4sZZd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618621074641584128",
    "text" : "http:\/\/t.co\/SMTzZ4sZZd",
    "id" : 618621074641584128,
    "created_at" : "2015-07-08 03:22:12 +0000",
    "user" : {
      "name" : "Verleen Freeman",
      "screen_name" : "MrsScottFreeman",
      "protected" : false,
      "id_str" : "25932816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738947696673751040\/6NUO3E3B_normal.jpg",
      "id" : 25932816,
      "verified" : false
    }
  },
  "id" : 618866723148681216,
  "created_at" : "2015-07-08 19:38:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medicalskeptic",
      "screen_name" : "medskep",
      "indices" : [ 3, 11 ],
      "id_str" : "133545597",
      "id" : 133545597
    }, {
      "name" : "Jocelyn Kaiser",
      "screen_name" : "jocelynkaiser",
      "indices" : [ 118, 132 ],
      "id_str" : "20784310",
      "id" : 20784310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/MSYyS31HpP",
      "expanded_url" : "http:\/\/bit.ly\/1TiW7ky",
      "display_url" : "bit.ly\/1TiW7ky"
    } ]
  },
  "geo" : { },
  "id_str" : "618866560179019776",
  "text" : "RT @medskep: Why many labs fear studies that try to replicate cancer studies l  via Science http:\/\/t.co\/MSYyS31HpP by @jocelynkaiser",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jocelyn Kaiser",
        "screen_name" : "jocelynkaiser",
        "indices" : [ 105, 119 ],
        "id_str" : "20784310",
        "id" : 20784310
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/MSYyS31HpP",
        "expanded_url" : "http:\/\/bit.ly\/1TiW7ky",
        "display_url" : "bit.ly\/1TiW7ky"
      } ]
    },
    "geo" : { },
    "id_str" : "618471063408631808",
    "text" : "Why many labs fear studies that try to replicate cancer studies l  via Science http:\/\/t.co\/MSYyS31HpP by @jocelynkaiser",
    "id" : 618471063408631808,
    "created_at" : "2015-07-07 17:26:06 +0000",
    "user" : {
      "name" : "Medicalskeptic",
      "screen_name" : "medskep",
      "protected" : false,
      "id_str" : "133545597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1394688432\/IMAG0474-1_normal.jpg",
      "id" : 133545597,
      "verified" : false
    }
  },
  "id" : 618866560179019776,
  "created_at" : "2015-07-08 19:37:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medicalskeptic",
      "screen_name" : "medskep",
      "indices" : [ 3, 11 ],
      "id_str" : "133545597",
      "id" : 133545597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/6qCmlHKS76",
      "expanded_url" : "http:\/\/bit.ly\/1ClIg8R",
      "display_url" : "bit.ly\/1ClIg8R"
    } ]
  },
  "geo" : { },
  "id_str" : "618865720106057728",
  "text" : "RT @medskep: Why is the CDC Taking Research Funding from a Pharmaceutical Company? http:\/\/t.co\/6qCmlHKS76 2013",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/6qCmlHKS76",
        "expanded_url" : "http:\/\/bit.ly\/1ClIg8R",
        "display_url" : "bit.ly\/1ClIg8R"
      } ]
    },
    "geo" : { },
    "id_str" : "618224676758687745",
    "text" : "Why is the CDC Taking Research Funding from a Pharmaceutical Company? http:\/\/t.co\/6qCmlHKS76 2013",
    "id" : 618224676758687745,
    "created_at" : "2015-07-07 01:07:03 +0000",
    "user" : {
      "name" : "Medicalskeptic",
      "screen_name" : "medskep",
      "protected" : false,
      "id_str" : "133545597",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1394688432\/IMAG0474-1_normal.jpg",
      "id" : 133545597,
      "verified" : false
    }
  },
  "id" : 618865720106057728,
  "created_at" : "2015-07-08 19:34:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel H. Wilson",
      "screen_name" : "danielwilsonpdx",
      "indices" : [ 3, 19 ],
      "id_str" : "52477188",
      "id" : 52477188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618865123344650240",
  "text" : "RT @danielwilsonpdx: Stock disruptions. Flights grounded. Industrial robot accidents... Hands over your heads people -- it's the #ROBOPOCAL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ROBOPOCALPYSE",
        "indices" : [ 108, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618863410453811200",
    "text" : "Stock disruptions. Flights grounded. Industrial robot accidents... Hands over your heads people -- it's the #ROBOPOCALPYSE!",
    "id" : 618863410453811200,
    "created_at" : "2015-07-08 19:25:09 +0000",
    "user" : {
      "name" : "Daniel H. Wilson",
      "screen_name" : "danielwilsonpdx",
      "protected" : false,
      "id_str" : "52477188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565758877283520512\/lYwj3t59_normal.png",
      "id" : 52477188,
      "verified" : true
    }
  },
  "id" : 618865123344650240,
  "created_at" : "2015-07-08 19:31:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "indices" : [ 3, 12 ],
      "id_str" : "13046992",
      "id" : 13046992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618837415336235008",
  "text" : "RT @mhawksey: If you setup \"Keep your Twitter Archive fresh on Google Drive\" prior to 8th Dec 2014 fresh copy required https:\/\/t.co\/OroGywY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/OroGywY8a7",
        "expanded_url" : "https:\/\/mashe.hawksey.info\/2013\/01\/sync-twitter-archive-with-google-drive\/#comment-176906",
        "display_url" : "mashe.hawksey.info\/2013\/01\/sync-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618417887892635652",
    "text" : "If you setup \"Keep your Twitter Archive fresh on Google Drive\" prior to 8th Dec 2014 fresh copy required https:\/\/t.co\/OroGywY8a7",
    "id" : 618417887892635652,
    "created_at" : "2015-07-07 13:54:48 +0000",
    "user" : {
      "name" : "Martin Hawksey",
      "screen_name" : "mhawksey",
      "protected" : false,
      "id_str" : "13046992",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2390851993\/xu6aptqy6a8rb2h2w5by_normal.jpeg",
      "id" : 13046992,
      "verified" : false
    }
  },
  "id" : 618837415336235008,
  "created_at" : "2015-07-08 17:41:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/8OXe6Zu9DD",
      "expanded_url" : "https:\/\/twitter.com\/itsandygill\/status\/618606775282044929",
      "display_url" : "twitter.com\/itsandygill\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618608536239636482",
  "text" : "hehehe...  https:\/\/t.co\/8OXe6Zu9DD",
  "id" : 618608536239636482,
  "created_at" : "2015-07-08 02:32:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618606606771564544",
  "geo" : { },
  "id_str" : "618607852450631680",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind feel better soon : )",
  "id" : 618607852450631680,
  "in_reply_to_status_id" : 618606606771564544,
  "created_at" : "2015-07-08 02:29:39 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "indices" : [ 3, 12 ],
      "id_str" : "800652126",
      "id" : 800652126
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/617537636215881732\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/BmTPFIPzrT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJHvNRMUkAAfRyv.jpg",
      "id_str" : "617537635158888448",
      "id" : 617537635158888448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJHvNRMUkAAfRyv.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1064,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BmTPFIPzrT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618599788548915201",
  "text" : "RT @MrRat395: Tonight nature provides the fireworks! http:\/\/t.co\/BmTPFIPzrT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/617537636215881732\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/BmTPFIPzrT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJHvNRMUkAAfRyv.jpg",
        "id_str" : "617537635158888448",
        "id" : 617537635158888448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJHvNRMUkAAfRyv.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1064,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/BmTPFIPzrT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "617537636215881732",
    "text" : "Tonight nature provides the fireworks! http:\/\/t.co\/BmTPFIPzrT",
    "id" : 617537636215881732,
    "created_at" : "2015-07-05 03:37:00 +0000",
    "user" : {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "protected" : false,
      "id_str" : "800652126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779503692802240512\/iVwM-mwl_normal.jpg",
      "id" : 800652126,
      "verified" : false
    }
  },
  "id" : 618599788548915201,
  "created_at" : "2015-07-08 01:57:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618599679404703744",
  "text" : "RT @CrystalLewis: The word \"homosexual\" (arsenokoitai) didn't appear in the bible until 1958. Previous translations were \"masturbator\" and \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618597397413920769",
    "text" : "The word \"homosexual\" (arsenokoitai) didn't appear in the bible until 1958. Previous translations were \"masturbator\" and \"self-abuser.\"",
    "id" : 618597397413920769,
    "created_at" : "2015-07-08 01:48:07 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 618599679404703744,
  "created_at" : "2015-07-08 01:57:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618599557304332288",
  "text" : "RT @CrystalLewis: And new testament refs to homosexuality involve the word \"arsenokoitai\"-- a word with no known translation.  https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/gSUlyog8fg",
        "expanded_url" : "https:\/\/twitter.com\/bfwriter\/status\/618596630913228801",
        "display_url" : "twitter.com\/bfwriter\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618597011764461568",
    "text" : "And new testament refs to homosexuality involve the word \"arsenokoitai\"-- a word with no known translation.  https:\/\/t.co\/gSUlyog8fg",
    "id" : 618597011764461568,
    "created_at" : "2015-07-08 01:46:35 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 618599557304332288,
  "created_at" : "2015-07-08 01:56:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618597748351172608",
  "geo" : { },
  "id_str" : "618599009104580609",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind ouch. Warm salt (microwave) in a sock.",
  "id" : 618599009104580609,
  "in_reply_to_status_id" : 618597748351172608,
  "created_at" : "2015-07-08 01:54:31 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "indices" : [ 3, 18 ],
      "id_str" : "1972360812",
      "id" : 1972360812
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CityStitchette\/status\/618575527822143488\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/WcyYPVr0rK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJWfJDQUYAAwzDD.jpg",
      "id_str" : "618575501674700800",
      "id" : 618575501674700800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJWfJDQUYAAwzDD.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WcyYPVr0rK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618579227366006785",
  "text" : "RT @CityStitchette: The city sky is melting. http:\/\/t.co\/WcyYPVr0rK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CityStitchette\/status\/618575527822143488\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/WcyYPVr0rK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJWfJDQUYAAwzDD.jpg",
        "id_str" : "618575501674700800",
        "id" : 618575501674700800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJWfJDQUYAAwzDD.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WcyYPVr0rK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618575527822143488",
    "text" : "The city sky is melting. http:\/\/t.co\/WcyYPVr0rK",
    "id" : 618575527822143488,
    "created_at" : "2015-07-08 00:21:13 +0000",
    "user" : {
      "name" : "Patricia Shaw",
      "screen_name" : "CityStitchette",
      "protected" : false,
      "id_str" : "1972360812",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765660039294152704\/LtNgIXNF_normal.jpg",
      "id" : 1972360812,
      "verified" : false
    }
  },
  "id" : 618579227366006785,
  "created_at" : "2015-07-08 00:35:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PatheosProgXn",
      "screen_name" : "PatheosProgXn",
      "indices" : [ 3, 17 ],
      "id_str" : "370939557",
      "id" : 370939557
    }, {
      "name" : "Kyle Roberts",
      "screen_name" : "kylearoberts",
      "indices" : [ 20, 33 ],
      "id_str" : "16450329",
      "id" : 16450329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ZsnmJob7tH",
      "expanded_url" : "http:\/\/ow.ly\/314zDZ",
      "display_url" : "ow.ly\/314zDZ"
    } ]
  },
  "geo" : { },
  "id_str" : "618498655511818240",
  "text" : "RT @PatheosProgXn: .@kylearoberts: A Note For Bible-Believing Christians Who Want to Be Inclusive http:\/\/t.co\/ZsnmJob7tH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kyle Roberts",
        "screen_name" : "kylearoberts",
        "indices" : [ 1, 14 ],
        "id_str" : "16450329",
        "id" : 16450329
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/ZsnmJob7tH",
        "expanded_url" : "http:\/\/ow.ly\/314zDZ",
        "display_url" : "ow.ly\/314zDZ"
      } ]
    },
    "geo" : { },
    "id_str" : "618491834029985793",
    "text" : ".@kylearoberts: A Note For Bible-Believing Christians Who Want to Be Inclusive http:\/\/t.co\/ZsnmJob7tH",
    "id" : 618491834029985793,
    "created_at" : "2015-07-07 18:48:38 +0000",
    "user" : {
      "name" : "PatheosProgXn",
      "screen_name" : "PatheosProgXn",
      "protected" : false,
      "id_str" : "370939557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1544486884\/crosstattoo_normal.jpg",
      "id" : 370939557,
      "verified" : false
    }
  },
  "id" : 618498655511818240,
  "created_at" : "2015-07-07 19:15:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618483399125286912",
  "geo" : { },
  "id_str" : "618484764824207360",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley I try not to do mean even though I might agree.",
  "id" : 618484764824207360,
  "in_reply_to_status_id" : 618483399125286912,
  "created_at" : "2015-07-07 18:20:33 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618483399125286912",
  "geo" : { },
  "id_str" : "618484553074757632",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley sometimes I almost RT something cuz its funny but realize it's mean, too.",
  "id" : 618484553074757632,
  "in_reply_to_status_id" : 618483399125286912,
  "created_at" : "2015-07-07 18:19:42 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gladstone's Land",
      "screen_name" : "GladstonesLand",
      "indices" : [ 3, 18 ],
      "id_str" : "3346635707",
      "id" : 3346635707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Coos",
      "indices" : [ 37, 42 ]
    }, {
      "text" : "CoosDay",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618483593891958785",
  "text" : "RT @GladstonesLand: Our wee Highland #Coos look much cuter on #CoosDay,don't they? We can definitely spot a wry smile on that shy one! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GladstonesLand\/status\/618449705849237504\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/5eWLE0g19J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJUsutAWwAAoPuO.jpg",
        "id_str" : "618449704700002304",
        "id" : 618449704700002304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJUsutAWwAAoPuO.jpg",
        "sizes" : [ {
          "h" : 943,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 943,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 566,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5eWLE0g19J"
      } ],
      "hashtags" : [ {
        "text" : "Coos",
        "indices" : [ 17, 22 ]
      }, {
        "text" : "CoosDay",
        "indices" : [ 42, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618449705849237504",
    "text" : "Our wee Highland #Coos look much cuter on #CoosDay,don't they? We can definitely spot a wry smile on that shy one! http:\/\/t.co\/5eWLE0g19J",
    "id" : 618449705849237504,
    "created_at" : "2015-07-07 16:01:14 +0000",
    "user" : {
      "name" : "Gladstone's Land",
      "screen_name" : "GladstonesLand",
      "protected" : false,
      "id_str" : "3346635707",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614460397190574080\/F8ABbBNT_normal.jpg",
      "id" : 3346635707,
      "verified" : false
    }
  },
  "id" : 618483593891958785,
  "created_at" : "2015-07-07 18:15:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618480150645243906",
  "text" : "RT @rjmedwed: I got called an \u201Cindoctrinator\u201D this morning at my LGBT suicide prevention workshop this morning in Calhoun.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618478969411760128",
    "text" : "I got called an \u201Cindoctrinator\u201D this morning at my LGBT suicide prevention workshop this morning in Calhoun.",
    "id" : 618478969411760128,
    "created_at" : "2015-07-07 17:57:31 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 618480150645243906,
  "created_at" : "2015-07-07 18:02:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/618254282316451840\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/xQCjLjGRMr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJR6_jzUEAI2voA.jpg",
      "id_str" : "618254281217413122",
      "id" : 618254281217413122,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJR6_jzUEAI2voA.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/xQCjLjGRMr"
    } ],
    "hashtags" : [ {
      "text" : "vabirdlibrary",
      "indices" : [ 43, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618256582829285376",
  "text" : "RT @Library4birds: \"If it fits, she sits.\"\n#vabirdlibrary http:\/\/t.co\/xQCjLjGRMr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/618254282316451840\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/xQCjLjGRMr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJR6_jzUEAI2voA.jpg",
        "id_str" : "618254281217413122",
        "id" : 618254281217413122,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJR6_jzUEAI2voA.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/xQCjLjGRMr"
      } ],
      "hashtags" : [ {
        "text" : "vabirdlibrary",
        "indices" : [ 24, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618254282316451840",
    "text" : "\"If it fits, she sits.\"\n#vabirdlibrary http:\/\/t.co\/xQCjLjGRMr",
    "id" : 618254282316451840,
    "created_at" : "2015-07-07 03:04:42 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 618256582829285376,
  "created_at" : "2015-07-07 03:13:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vala Afshar",
      "screen_name" : "ValaAfshar",
      "indices" : [ 3, 14 ],
      "id_str" : "259725229",
      "id" : 259725229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/abdophoto\/status\/569281570319650816\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/AdE4Qn3PCj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Z-kRFCYAAqgIR.jpg",
      "id_str" : "569281564433866752",
      "id" : 569281564433866752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Z-kRFCYAAqgIR.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 718
      } ],
      "display_url" : "pic.twitter.com\/AdE4Qn3PCj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/LCp5henuh1",
      "expanded_url" : "http:\/\/nyti.ms\/1CAWYm1",
      "display_url" : "nyti.ms\/1CAWYm1"
    } ]
  },
  "geo" : { },
  "id_str" : "618241934532939777",
  "text" : "RT @ValaAfshar: What they said about the laptop, 30 years ago http:\/\/t.co\/LCp5henuh1 http:\/\/t.co\/AdE4Qn3PCj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/abdophoto\/status\/569281570319650816\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/AdE4Qn3PCj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Z-kRFCYAAqgIR.jpg",
        "id_str" : "569281564433866752",
        "id" : 569281564433866752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Z-kRFCYAAqgIR.jpg",
        "sizes" : [ {
          "h" : 389,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 718
        } ],
        "display_url" : "pic.twitter.com\/AdE4Qn3PCj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/LCp5henuh1",
        "expanded_url" : "http:\/\/nyti.ms\/1CAWYm1",
        "display_url" : "nyti.ms\/1CAWYm1"
      } ]
    },
    "geo" : { },
    "id_str" : "618229751908401152",
    "text" : "What they said about the laptop, 30 years ago http:\/\/t.co\/LCp5henuh1 http:\/\/t.co\/AdE4Qn3PCj",
    "id" : 618229751908401152,
    "created_at" : "2015-07-07 01:27:13 +0000",
    "user" : {
      "name" : "Vala Afshar",
      "screen_name" : "ValaAfshar",
      "protected" : false,
      "id_str" : "259725229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1259558245\/vala_300dpi_normal.jpg",
      "id" : 259725229,
      "verified" : true
    }
  },
  "id" : 618241934532939777,
  "created_at" : "2015-07-07 02:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaytheist",
      "screen_name" : "Gaytheist",
      "indices" : [ 3, 13 ],
      "id_str" : "50409017",
      "id" : 50409017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618230515854872576",
  "text" : "RT @Gaytheist: We need a revolutionary social philosophy, not one of I got mine, but one of 'nobody eats until everyone has something.'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618116646750674944",
    "text" : "We need a revolutionary social philosophy, not one of I got mine, but one of 'nobody eats until everyone has something.'",
    "id" : 618116646750674944,
    "created_at" : "2015-07-06 17:57:47 +0000",
    "user" : {
      "name" : "Gaytheist",
      "screen_name" : "Gaytheist",
      "protected" : false,
      "id_str" : "50409017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707652676293517312\/V-AQphFX_normal.jpg",
      "id" : 50409017,
      "verified" : false
    }
  },
  "id" : 618230515854872576,
  "created_at" : "2015-07-07 01:30:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Butterfly Lady",
      "screen_name" : "MyButterflyLady",
      "indices" : [ 3, 19 ],
      "id_str" : "43840165",
      "id" : 43840165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618150743737004032",
  "text" : "RT @MyButterflyLady: My course on \"Raising Monarchs for Fun\" starts tomorrow. Would love to have you join us in the fun!\n\nClick on the... h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kKV78bRs06",
        "expanded_url" : "http:\/\/fb.me\/6HC3UhD8k",
        "display_url" : "fb.me\/6HC3UhD8k"
      } ]
    },
    "geo" : { },
    "id_str" : "618149678014689280",
    "text" : "My course on \"Raising Monarchs for Fun\" starts tomorrow. Would love to have you join us in the fun!\n\nClick on the... http:\/\/t.co\/kKV78bRs06",
    "id" : 618149678014689280,
    "created_at" : "2015-07-06 20:09:02 +0000",
    "user" : {
      "name" : "Butterfly Lady",
      "screen_name" : "MyButterflyLady",
      "protected" : false,
      "id_str" : "43840165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459046153300873216\/dVqsSzSO_normal.jpeg",
      "id" : 43840165,
      "verified" : false
    }
  },
  "id" : 618150743737004032,
  "created_at" : "2015-07-06 20:13:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618149870772338691",
  "text" : "Anyone play Wordbase? My username here is my username there.",
  "id" : 618149870772338691,
  "created_at" : "2015-07-06 20:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doctors for America",
      "screen_name" : "Drsforamerica",
      "indices" : [ 3, 17 ],
      "id_str" : "25911044",
      "id" : 25911044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/J3glmftiFb",
      "expanded_url" : "http:\/\/www.modernhealthcare.com\/article\/20150704\/MAGAZINE\/307049961\/obama-speech-kicks-off-new-drive-to-expand-medicaid",
      "display_url" : "modernhealthcare.com\/article\/201507\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "618142749045473281",
  "text" : "RT @Drsforamerica: Obama speech kicks off new drive to expand Medicaid http:\/\/t.co\/J3glmftiFb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/J3glmftiFb",
        "expanded_url" : "http:\/\/www.modernhealthcare.com\/article\/20150704\/MAGAZINE\/307049961\/obama-speech-kicks-off-new-drive-to-expand-medicaid",
        "display_url" : "modernhealthcare.com\/article\/201507\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618139925435658240",
    "text" : "Obama speech kicks off new drive to expand Medicaid http:\/\/t.co\/J3glmftiFb",
    "id" : 618139925435658240,
    "created_at" : "2015-07-06 19:30:17 +0000",
    "user" : {
      "name" : "Doctors for America",
      "screen_name" : "Drsforamerica",
      "protected" : false,
      "id_str" : "25911044",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738722026584723456\/A8cXWuMw_normal.jpg",
      "id" : 25911044,
      "verified" : false
    }
  },
  "id" : 618142749045473281,
  "created_at" : "2015-07-06 19:41:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "indices" : [ 3, 19 ],
      "id_str" : "492604254",
      "id" : 492604254
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jays",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "birdwatching",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618139580081029121",
  "text" : "RT @naturechronicle: What a pair! Baby Steller\u2019s #jays, the newest members of the flock, and, oh, how they love the water! #birdwatching ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/naturechronicle\/status\/616975109740326912\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/amNGWn9v5f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CI_vl39UEAAOTV_.jpg",
        "id_str" : "616975107928363008",
        "id" : 616975107928363008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI_vl39UEAAOTV_.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 733
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 733
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/amNGWn9v5f"
      } ],
      "hashtags" : [ {
        "text" : "jays",
        "indices" : [ 28, 33 ]
      }, {
        "text" : "birdwatching",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616975109740326912",
    "text" : "What a pair! Baby Steller\u2019s #jays, the newest members of the flock, and, oh, how they love the water! #birdwatching http:\/\/t.co\/amNGWn9v5f",
    "id" : 616975109740326912,
    "created_at" : "2015-07-03 14:21:43 +0000",
    "user" : {
      "name" : "Julie Gomez",
      "screen_name" : "naturechronicle",
      "protected" : false,
      "id_str" : "492604254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3166619966\/e7f8777d0fc93299ea6002d3e754aca8_normal.jpeg",
      "id" : 492604254,
      "verified" : false
    }
  },
  "id" : 618139580081029121,
  "created_at" : "2015-07-06 19:28:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket",
      "screen_name" : "Pocket",
      "indices" : [ 62, 69 ],
      "id_str" : "27530178",
      "id" : 27530178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Q2tyD7qQzB",
      "expanded_url" : "http:\/\/pocket.co\/sorv7j",
      "display_url" : "pocket.co\/sorv7j"
    } ]
  },
  "geo" : { },
  "id_str" : "618101105126416384",
  "text" : "How to Use a Simple Pocket Notebook to Improve Your Life (via @Pocket) http:\/\/t.co\/Q2tyD7qQzB",
  "id" : 618101105126416384,
  "created_at" : "2015-07-06 16:56:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617877248318787585",
  "text" : "RT @JeremyCShipp: Spoiler alert! The world ends with a, \"Oh, we should have fixed that 100 years ago, huh?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "617860199248850944",
    "text" : "Spoiler alert! The world ends with a, \"Oh, we should have fixed that 100 years ago, huh?\"",
    "id" : 617860199248850944,
    "created_at" : "2015-07-06 00:58:45 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 617877248318787585,
  "created_at" : "2015-07-06 02:06:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617819342630039552",
  "geo" : { },
  "id_str" : "617875044274995200",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind naahh.. you're underestimating yourself.",
  "id" : 617875044274995200,
  "in_reply_to_status_id" : 617819342630039552,
  "created_at" : "2015-07-06 01:57:44 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "indices" : [ 3, 17 ],
      "id_str" : "216776631",
      "id" : 216776631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617874255162818560",
  "text" : "RT @BernieSanders: Medicare is more cost-effective than private insurers, and could serve as the foundation for a single-payer system. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/w3TJJnCiZw",
        "expanded_url" : "http:\/\/bernie.to\/sign-medicare",
        "display_url" : "bernie.to\/sign-medicare"
      } ]
    },
    "geo" : { },
    "id_str" : "617857013742112768",
    "text" : "Medicare is more cost-effective than private insurers, and could serve as the foundation for a single-payer system. http:\/\/t.co\/w3TJJnCiZw",
    "id" : 617857013742112768,
    "created_at" : "2015-07-06 00:46:05 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "BernieSanders",
      "protected" : false,
      "id_str" : "216776631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794596124686487552\/kqpbolIc_normal.jpg",
      "id" : 216776631,
      "verified" : true
    }
  },
  "id" : 617874255162818560,
  "created_at" : "2015-07-06 01:54:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "julia park tracey",
      "screen_name" : "juliaparktracey",
      "indices" : [ 3, 19 ],
      "id_str" : "36072583",
      "id" : 36072583
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/juliaparktracey\/status\/617863541907980288\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/u0rdmdUc9J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJMXniPW8AALHpB.jpg",
      "id_str" : "617863541853450240",
      "id" : 617863541853450240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJMXniPW8AALHpB.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u0rdmdUc9J"
    } ],
    "hashtags" : [ {
      "text" : "cat",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "crazycatlady",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "youknowit",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617873999108919300",
  "text" : "RT @juliaparktracey: In case of emotional breakdown, place #cat here. #crazycatlady #youknowit http:\/\/t.co\/u0rdmdUc9J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/juliaparktracey\/status\/617863541907980288\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/u0rdmdUc9J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJMXniPW8AALHpB.jpg",
        "id_str" : "617863541853450240",
        "id" : 617863541853450240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJMXniPW8AALHpB.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/u0rdmdUc9J"
      } ],
      "hashtags" : [ {
        "text" : "cat",
        "indices" : [ 38, 42 ]
      }, {
        "text" : "crazycatlady",
        "indices" : [ 49, 62 ]
      }, {
        "text" : "youknowit",
        "indices" : [ 63, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "617863541907980288",
    "text" : "In case of emotional breakdown, place #cat here. #crazycatlady #youknowit http:\/\/t.co\/u0rdmdUc9J",
    "id" : 617863541907980288,
    "created_at" : "2015-07-06 01:12:02 +0000",
    "user" : {
      "name" : "julia park tracey",
      "screen_name" : "juliaparktracey",
      "protected" : false,
      "id_str" : "36072583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730393905993121794\/Pc_ep_UQ_normal.jpg",
      "id" : 36072583,
      "verified" : false
    }
  },
  "id" : 617873999108919300,
  "created_at" : "2015-07-06 01:53:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "indices" : [ 3, 17 ],
      "id_str" : "493714995",
      "id" : 493714995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/hHYIDi98Zs",
      "expanded_url" : "http:\/\/wp.me\/p2h2UO-2ET",
      "display_url" : "wp.me\/p2h2UO-2ET"
    } ]
  },
  "geo" : { },
  "id_str" : "617873670938214400",
  "text" : "RT @johnpavlovitz: Is Nana Really Burning In Hell Right Now? http:\/\/t.co\/hHYIDi98Zs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/hHYIDi98Zs",
        "expanded_url" : "http:\/\/wp.me\/p2h2UO-2ET",
        "display_url" : "wp.me\/p2h2UO-2ET"
      } ]
    },
    "geo" : { },
    "id_str" : "617865166106042369",
    "text" : "Is Nana Really Burning In Hell Right Now? http:\/\/t.co\/hHYIDi98Zs",
    "id" : 617865166106042369,
    "created_at" : "2015-07-06 01:18:29 +0000",
    "user" : {
      "name" : "John Pavlovitz",
      "screen_name" : "johnpavlovitz",
      "protected" : false,
      "id_str" : "493714995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565007886665801728\/YIch3UHW_normal.jpeg",
      "id" : 493714995,
      "verified" : false
    }
  },
  "id" : 617873670938214400,
  "created_at" : "2015-07-06 01:52:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617741324968689664",
  "text" : "Normally I groan about social gatherings but I'm sad to be missing BBQ today. Have to stay w my #sick cupcake in our room.",
  "id" : 617741324968689664,
  "created_at" : "2015-07-05 17:06:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Astonishing Pictures",
      "screen_name" : "AstonishingPix",
      "indices" : [ 3, 18 ],
      "id_str" : "355445976",
      "id" : 355445976
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HistoricalPics\/status\/506539540128215040\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/0MGWNvt9dY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BweXBwOIgAEId7s.jpg",
      "id_str" : "506539539482312705",
      "id" : 506539539482312705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BweXBwOIgAEId7s.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/0MGWNvt9dY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617520487766335488",
  "text" : "RT @AstonishingPix: Twitter in 1935 http:\/\/t.co\/0MGWNvt9dY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.grabinbox.com\" rel=\"nofollow\"\u003EGrabInbox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HistoricalPics\/status\/506539540128215040\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/0MGWNvt9dY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BweXBwOIgAEId7s.jpg",
        "id_str" : "506539539482312705",
        "id" : 506539539482312705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BweXBwOIgAEId7s.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/0MGWNvt9dY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "617213911880708096",
    "text" : "Twitter in 1935 http:\/\/t.co\/0MGWNvt9dY",
    "id" : 617213911880708096,
    "created_at" : "2015-07-04 06:10:38 +0000",
    "user" : {
      "name" : "Astonishing Pictures",
      "screen_name" : "AstonishingPix",
      "protected" : false,
      "id_str" : "355445976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427880879818420224\/rbu_FxnL_normal.jpeg",
      "id" : 355445976,
      "verified" : false
    }
  },
  "id" : 617520487766335488,
  "created_at" : "2015-07-05 02:28:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617348002349477888",
  "geo" : { },
  "id_str" : "617519260294873088",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides don't blame him.. smooches to Jasper!",
  "id" : 617519260294873088,
  "in_reply_to_status_id" : 617348002349477888,
  "created_at" : "2015-07-05 02:23:59 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Thompson",
      "screen_name" : "bri66thomp",
      "indices" : [ 3, 14 ],
      "id_str" : "1269155425",
      "id" : 1269155425
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bri66thomp\/status\/617424607851737088\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/097encQUCv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJGIZoGWcAApEPg.jpg",
      "id_str" : "617424597768630272",
      "id" : 617424597768630272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJGIZoGWcAApEPg.jpg",
      "sizes" : [ {
        "h" : 692,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/097encQUCv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617424790085894144",
  "text" : "RT @bri66thomp: A great find at the headland near Skomer, by my mate. Chough-in brilliant\uD83D\uDE03 Well done mate. http:\/\/t.co\/097encQUCv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bri66thomp\/status\/617424607851737088\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/097encQUCv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJGIZoGWcAApEPg.jpg",
        "id_str" : "617424597768630272",
        "id" : 617424597768630272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJGIZoGWcAApEPg.jpg",
        "sizes" : [ {
          "h" : 692,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/097encQUCv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "617424607851737088",
    "text" : "A great find at the headland near Skomer, by my mate. Chough-in brilliant\uD83D\uDE03 Well done mate. http:\/\/t.co\/097encQUCv",
    "id" : 617424607851737088,
    "created_at" : "2015-07-04 20:07:52 +0000",
    "user" : {
      "name" : "Brian Thompson",
      "screen_name" : "bri66thomp",
      "protected" : false,
      "id_str" : "1269155425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3386684382\/fbb7fe7df647846b9dd863894164d1c9_normal.jpeg",
      "id" : 1269155425,
      "verified" : false
    }
  },
  "id" : 617424790085894144,
  "created_at" : "2015-07-04 20:08:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617424660179890177",
  "text" : "i hate it when i agree w someone i dont really like... meh.",
  "id" : 617424660179890177,
  "created_at" : "2015-07-04 20:08:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617347662187233280",
  "text" : "I knew I should have scheduled blood work sooner. Ugh.",
  "id" : 617347662187233280,
  "created_at" : "2015-07-04 15:02:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "levothyroxine",
      "indices" : [ 50, 64 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617347170094739458",
  "text" : "Poor kid.. now she's feeling ill after taking her #levothyroxine (25mg) since a week ago. #thyroid #hashimotos and I think she's got UTI.",
  "id" : 617347170094739458,
  "created_at" : "2015-07-04 15:00:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/ZF1TepMjZ1",
      "expanded_url" : "https:\/\/instagram.com\/p\/4sttiVHwwR\/",
      "display_url" : "instagram.com\/p\/4sttiVHwwR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "617169994309345280",
  "text" : "RT @JeremyCShipp: Sunset. https:\/\/t.co\/ZF1TepMjZ1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/ZF1TepMjZ1",
        "expanded_url" : "https:\/\/instagram.com\/p\/4sttiVHwwR\/",
        "display_url" : "instagram.com\/p\/4sttiVHwwR\/"
      } ]
    },
    "geo" : { },
    "id_str" : "617168734675992576",
    "text" : "Sunset. https:\/\/t.co\/ZF1TepMjZ1",
    "id" : 617168734675992576,
    "created_at" : "2015-07-04 03:11:07 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 617169994309345280,
  "created_at" : "2015-07-04 03:16:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616728183149359104",
  "geo" : { },
  "id_str" : "617117618735087620",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe oh damn. I'm so sorry. (((hugs)))",
  "id" : 617117618735087620,
  "in_reply_to_status_id" : 616728183149359104,
  "created_at" : "2015-07-03 23:48:00 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617081965477502976",
  "text" : "We were supposed to walk in for blood draw at Endo office.. 1st come 1st served. Blah.",
  "id" : 617081965477502976,
  "created_at" : "2015-07-03 21:26:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 98, 106 ]
    }, {
      "text" : "hashimotos",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "617081364106596352",
  "text" : "Made appt w lab for blood work next Tues. At least it looks like Endo doc ordered a lot of tests. #thyroid #hashimotos",
  "id" : 617081364106596352,
  "created_at" : "2015-07-03 21:23:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mistyglen Holsteins",
      "screen_name" : "MistyglenFarms",
      "indices" : [ 3, 18 ],
      "id_str" : "257993189",
      "id" : 257993189
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MistyglenFarms\/status\/612076360421539840\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/xDNjMPZ5oW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH6IHDnWsAAct0r.jpg",
      "id_str" : "612076254179799040",
      "id" : 612076254179799040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH6IHDnWsAAct0r.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xDNjMPZ5oW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616688357016530944",
  "text" : "RT @MistyglenFarms: Dufus was not helpful in my endeavour to photograph the sunset. http:\/\/t.co\/xDNjMPZ5oW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MistyglenFarms\/status\/612076360421539840\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/xDNjMPZ5oW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH6IHDnWsAAct0r.jpg",
        "id_str" : "612076254179799040",
        "id" : 612076254179799040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH6IHDnWsAAct0r.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xDNjMPZ5oW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612076360421539840",
    "text" : "Dufus was not helpful in my endeavour to photograph the sunset. http:\/\/t.co\/xDNjMPZ5oW",
    "id" : 612076360421539840,
    "created_at" : "2015-06-20 01:55:50 +0000",
    "user" : {
      "name" : "Mistyglen Holsteins",
      "screen_name" : "MistyglenFarms",
      "protected" : false,
      "id_str" : "257993189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631031833\/4f4f61f801dde69b035748ec285d91dc_normal.jpeg",
      "id" : 257993189,
      "verified" : false
    }
  },
  "id" : 616688357016530944,
  "created_at" : "2015-07-02 19:22:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616687391202484224",
  "text" : "DH is off to do grocery shopping. Hope he remembers my advil congestion. Usually works a treat on my sinuses.",
  "id" : 616687391202484224,
  "created_at" : "2015-07-02 19:18:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616643687167193088",
  "text" : "Found a mouse on top of unwashed laundry in washer today. Was alive but didn't move well.",
  "id" : 616643687167193088,
  "created_at" : "2015-07-02 16:24:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616643022504259585",
  "text" : "I've been feeling icky all week. Sinuses I'm sure. Bleh.",
  "id" : 616643022504259585,
  "created_at" : "2015-07-02 16:22:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/MtLw1zC8MB",
      "expanded_url" : "http:\/\/cnb.cx\/1NeSs53",
      "display_url" : "cnb.cx\/1NeSs53"
    } ]
  },
  "geo" : { },
  "id_str" : "616432727332651008",
  "text" : "RT @SangyeH: Public Health Officials Know: Recently Vaccinated Individuals Spread Disease http:\/\/t.co\/MtLw1zC8MB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/MtLw1zC8MB",
        "expanded_url" : "http:\/\/cnb.cx\/1NeSs53",
        "display_url" : "cnb.cx\/1NeSs53"
      } ]
    },
    "geo" : { },
    "id_str" : "616395932221833216",
    "text" : "Public Health Officials Know: Recently Vaccinated Individuals Spread Disease http:\/\/t.co\/MtLw1zC8MB",
    "id" : 616395932221833216,
    "created_at" : "2015-07-02 00:00:16 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 616432727332651008,
  "created_at" : "2015-07-02 02:26:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/eVghHrBgUj",
      "expanded_url" : "https:\/\/instagram.com\/p\/4nZOC7hH2w\/",
      "display_url" : "instagram.com\/p\/4nZOC7hH2w\/"
    } ]
  },
  "geo" : { },
  "id_str" : "616423608961863680",
  "text" : "RT @ducksandclucks: Watermelon time. https:\/\/t.co\/eVghHrBgUj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/eVghHrBgUj",
        "expanded_url" : "https:\/\/instagram.com\/p\/4nZOC7hH2w\/",
        "display_url" : "instagram.com\/p\/4nZOC7hH2w\/"
      } ]
    },
    "geo" : { },
    "id_str" : "616420007132725248",
    "text" : "Watermelon time. https:\/\/t.co\/eVghHrBgUj",
    "id" : 616420007132725248,
    "created_at" : "2015-07-02 01:35:56 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 616423608961863680,
  "created_at" : "2015-07-02 01:50:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616422627050176512",
  "text" : "RT @Floridaline: \"A crime by a finite being against an infinite being is an infinite impossibility.\"--Robert Ingersoll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616420399820210177",
    "text" : "\"A crime by a finite being against an infinite being is an infinite impossibility.\"--Robert Ingersoll",
    "id" : 616420399820210177,
    "created_at" : "2015-07-02 01:37:30 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 616422627050176512,
  "created_at" : "2015-07-02 01:46:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 3, 18 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616422487782477824",
  "text" : "RT @AnnotatedBible: Atheists are right!\n\nThe doctrine of God punishing people in Hell fire forever is not logical and is not moral.\n\nhttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/GrTaGsHelZ",
        "expanded_url" : "https:\/\/fusiontheism.wordpress.com\/2015\/07\/01\/what-the-hell\/",
        "display_url" : "fusiontheism.wordpress.com\/2015\/07\/01\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "616420664392560640",
    "text" : "Atheists are right!\n\nThe doctrine of God punishing people in Hell fire forever is not logical and is not moral.\n\nhttps:\/\/t.co\/GrTaGsHelZ",
    "id" : 616420664392560640,
    "created_at" : "2015-07-02 01:38:33 +0000",
    "user" : {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "protected" : false,
      "id_str" : "242204735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449392620867817472\/7TtHluzO_normal.jpeg",
      "id" : 242204735,
      "verified" : false
    }
  },
  "id" : 616422487782477824,
  "created_at" : "2015-07-02 01:45:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shadow's Whiskers",
      "screen_name" : "ShadowsWhiskers",
      "indices" : [ 3, 19 ],
      "id_str" : "956687508",
      "id" : 956687508
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ShadowsWhiskers\/status\/614644821328728064\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/QLbBozf5XV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIeoNVLUMAEDtZC.jpg",
      "id_str" : "614644821135732737",
      "id" : 614644821135732737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIeoNVLUMAEDtZC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1102,
        "resize" : "fit",
        "w" : 1102
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QLbBozf5XV"
    } ],
    "hashtags" : [ {
      "text" : "incognito",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616421547075629057",
  "text" : "RT @ShadowsWhiskers: Katy #incognito http:\/\/t.co\/QLbBozf5XV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ShadowsWhiskers\/status\/614644821328728064\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/QLbBozf5XV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIeoNVLUMAEDtZC.jpg",
        "id_str" : "614644821135732737",
        "id" : 614644821135732737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIeoNVLUMAEDtZC.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1102,
          "resize" : "fit",
          "w" : 1102
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QLbBozf5XV"
      } ],
      "hashtags" : [ {
        "text" : "incognito",
        "indices" : [ 5, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614644821328728064",
    "text" : "Katy #incognito http:\/\/t.co\/QLbBozf5XV",
    "id" : 614644821328728064,
    "created_at" : "2015-06-27 04:01:59 +0000",
    "user" : {
      "name" : "Shadow's Whiskers",
      "screen_name" : "ShadowsWhiskers",
      "protected" : false,
      "id_str" : "956687508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714110788898856960\/ZixdW1u1_normal.jpg",
      "id" : 956687508,
      "verified" : false
    }
  },
  "id" : 616421547075629057,
  "created_at" : "2015-07-02 01:42:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adorable Animals",
      "screen_name" : "ANIMALPlCTURES",
      "indices" : [ 3, 18 ],
      "id_str" : "2440122246",
      "id" : 2440122246
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ANIMALPlCTURES\/status\/616241389614039040\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/unZdWlUynp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CI1UR0JWUAA6r-s.jpg",
      "id_str" : "616241389051990016",
      "id" : 616241389051990016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI1UR0JWUAA6r-s.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/unZdWlUynp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616287482095792128",
  "text" : "RT @ANIMALPlCTURES: Bird parenting. http:\/\/t.co\/unZdWlUynp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ANIMALPlCTURES\/status\/616241389614039040\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/unZdWlUynp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CI1UR0JWUAA6r-s.jpg",
        "id_str" : "616241389051990016",
        "id" : 616241389051990016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CI1UR0JWUAA6r-s.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/unZdWlUynp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616241389614039040",
    "text" : "Bird parenting. http:\/\/t.co\/unZdWlUynp",
    "id" : 616241389614039040,
    "created_at" : "2015-07-01 13:46:11 +0000",
    "user" : {
      "name" : "Adorable Animals",
      "screen_name" : "ANIMALPlCTURES",
      "protected" : false,
      "id_str" : "2440122246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477022793142267904\/UTHgo6G7_normal.jpeg",
      "id" : 2440122246,
      "verified" : false
    }
  },
  "id" : 616287482095792128,
  "created_at" : "2015-07-01 16:49:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 13, 25 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616282984451342336",
  "geo" : { },
  "id_str" : "616285793825460225",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny @Floridaline wth did I just watch?? Is she for real?? Ugh.",
  "id" : 616285793825460225,
  "in_reply_to_status_id" : 616282984451342336,
  "created_at" : "2015-07-01 16:42:37 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]