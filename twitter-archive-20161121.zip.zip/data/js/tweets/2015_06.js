Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Walkden",
      "screen_name" : "PeteWalkden1973",
      "indices" : [ 3, 19 ],
      "id_str" : "633175541",
      "id" : 633175541
    }, {
      "name" : "RSPB Scotland",
      "screen_name" : "RSPBScotland",
      "indices" : [ 90, 103 ],
      "id_str" : "308502351",
      "id" : 308502351
    }, {
      "name" : "BirdGuides",
      "screen_name" : "BirdGuides",
      "indices" : [ 104, 115 ],
      "id_str" : "17099499",
      "id" : 17099499
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PeteWalkden1973\/status\/615980270294974464\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/254bBpBOGi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIxmwvkWsAA3Sas.jpg",
      "id_str" : "615980236631617536",
      "id" : 615980236631617536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIxmwvkWsAA3Sas.jpg",
      "sizes" : [ {
        "h" : 307,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 1017
      } ],
      "display_url" : "pic.twitter.com\/254bBpBOGi"
    } ],
    "hashtags" : [ {
      "text" : "Shetland",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615987440558456832",
  "text" : "RT @PeteWalkden1973: A freshly fledged wren from #Shetland. All fluffy and windswept. :o) @RSPBScotland @BirdGuides http:\/\/t.co\/254bBpBOGi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RSPB Scotland",
        "screen_name" : "RSPBScotland",
        "indices" : [ 69, 82 ],
        "id_str" : "308502351",
        "id" : 308502351
      }, {
        "name" : "BirdGuides",
        "screen_name" : "BirdGuides",
        "indices" : [ 83, 94 ],
        "id_str" : "17099499",
        "id" : 17099499
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PeteWalkden1973\/status\/615980270294974464\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/254bBpBOGi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIxmwvkWsAA3Sas.jpg",
        "id_str" : "615980236631617536",
        "id" : 615980236631617536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIxmwvkWsAA3Sas.jpg",
        "sizes" : [ {
          "h" : 307,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 1017
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 1017
        } ],
        "display_url" : "pic.twitter.com\/254bBpBOGi"
      } ],
      "hashtags" : [ {
        "text" : "Shetland",
        "indices" : [ 28, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615980270294974464",
    "text" : "A freshly fledged wren from #Shetland. All fluffy and windswept. :o) @RSPBScotland @BirdGuides http:\/\/t.co\/254bBpBOGi",
    "id" : 615980270294974464,
    "created_at" : "2015-06-30 20:28:35 +0000",
    "user" : {
      "name" : "Pete Walkden",
      "screen_name" : "PeteWalkden1973",
      "protected" : false,
      "id_str" : "633175541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486168097544364032\/zZwmO66V_normal.png",
      "id" : 633175541,
      "verified" : false
    }
  },
  "id" : 615987440558456832,
  "created_at" : "2015-06-30 20:57:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Lucas",
      "screen_name" : "ellisethan",
      "indices" : [ 3, 14 ],
      "id_str" : "231450675",
      "id" : 231450675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ellisethan\/status\/615883336502910977\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/zmYGai0GQE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIwOnBuWoAAG-7z.jpg",
      "id_str" : "615883312683458560",
      "id" : 615883312683458560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIwOnBuWoAAG-7z.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zmYGai0GQE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615987227244498944",
  "text" : "RT @ellisethan: Just been checking on the kids. All's well. http:\/\/t.co\/zmYGai0GQE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ellisethan\/status\/615883336502910977\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/zmYGai0GQE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIwOnBuWoAAG-7z.jpg",
        "id_str" : "615883312683458560",
        "id" : 615883312683458560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIwOnBuWoAAG-7z.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zmYGai0GQE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615883336502910977",
    "text" : "Just been checking on the kids. All's well. http:\/\/t.co\/zmYGai0GQE",
    "id" : 615883336502910977,
    "created_at" : "2015-06-30 14:03:24 +0000",
    "user" : {
      "name" : "Mark Lucas",
      "screen_name" : "ellisethan",
      "protected" : false,
      "id_str" : "231450675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613255521282293760\/XgjbzdVm_normal.png",
      "id" : 231450675,
      "verified" : false
    }
  },
  "id" : 615987227244498944,
  "created_at" : "2015-06-30 20:56:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615973471877734400",
  "text" : "Ultrasound done. PCP tomorrow, thank god.. poor kid feels so crappy. taking anti-nausea daily now along w ativan and still in bed.",
  "id" : 615973471877734400,
  "created_at" : "2015-06-30 20:01:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail",
      "screen_name" : "BirdAndGarden",
      "indices" : [ 3, 17 ],
      "id_str" : "465570280",
      "id" : 465570280
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BirdAndGarden\/status\/615659474406252545\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/CaGy92FZgm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CItDB4UWcAEygJh.jpg",
      "id_str" : "615659473642876929",
      "id" : 615659473642876929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CItDB4UWcAEygJh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/CaGy92FZgm"
    } ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "summer",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615660112292769792",
  "text" : "RT @BirdAndGarden: A perfect ending to a pretty great day. #nature #summer A wonderful peaceful walk. http:\/\/t.co\/CaGy92FZgm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BirdAndGarden\/status\/615659474406252545\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/CaGy92FZgm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CItDB4UWcAEygJh.jpg",
        "id_str" : "615659473642876929",
        "id" : 615659473642876929,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CItDB4UWcAEygJh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/CaGy92FZgm"
      } ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 40, 47 ]
      }, {
        "text" : "summer",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615659474406252545",
    "text" : "A perfect ending to a pretty great day. #nature #summer A wonderful peaceful walk. http:\/\/t.co\/CaGy92FZgm",
    "id" : 615659474406252545,
    "created_at" : "2015-06-29 23:13:51 +0000",
    "user" : {
      "name" : "Gail",
      "screen_name" : "BirdAndGarden",
      "protected" : false,
      "id_str" : "465570280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634801624624398339\/s-72Q7qt_normal.jpg",
      "id" : 465570280,
      "verified" : false
    }
  },
  "id" : 615660112292769792,
  "created_at" : "2015-06-29 23:16:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barry Sarling",
      "screen_name" : "BarrySarling",
      "indices" : [ 3, 16 ],
      "id_str" : "2471327180",
      "id" : 2471327180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615627327687553024",
  "text" : "RT @BarrySarling: This woodpigeon is getting more tame by the day, wonder if it's because I'm giving him breakfast each morning? lol http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BarrySarling\/status\/615257958117703680\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/FCNTdQAhl5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CInV2fnW8AAZZsx.jpg",
        "id_str" : "615257956289015808",
        "id" : 615257956289015808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CInV2fnW8AAZZsx.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/FCNTdQAhl5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615257958117703680",
    "text" : "This woodpigeon is getting more tame by the day, wonder if it's because I'm giving him breakfast each morning? lol http:\/\/t.co\/FCNTdQAhl5",
    "id" : 615257958117703680,
    "created_at" : "2015-06-28 20:38:22 +0000",
    "user" : {
      "name" : "Barry Sarling",
      "screen_name" : "BarrySarling",
      "protected" : false,
      "id_str" : "2471327180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/501811983465725953\/Cwhi2DA__normal.jpeg",
      "id" : 2471327180,
      "verified" : false
    }
  },
  "id" : 615627327687553024,
  "created_at" : "2015-06-29 21:06:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "News Radio 1230",
      "screen_name" : "ABC1230News",
      "indices" : [ 3, 15 ],
      "id_str" : "1621030400",
      "id" : 1621030400
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ABC1230News\/status\/615220285986447361\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/xgQCBr1VK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CImzlyZWoAAAUvn.jpg",
      "id_str" : "615220285877428224",
      "id" : 615220285877428224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CImzlyZWoAAAUvn.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/xgQCBr1VK1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/FPIRBa0BBZ",
      "expanded_url" : "http:\/\/abc1230news.1230thefan.com\/2015\/06\/28\/two-blind-cows-find-sweet-friendship-at-new-york-farm-sanctuary\/",
      "display_url" : "abc1230news.1230thefan.com\/2015\/06\/28\/two\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615338244461461504",
  "text" : "RT @ABC1230News: Two Blind Cows Find Sweet Friendship at New York Farm Sanctuary -  http:\/\/t.co\/FPIRBa0BBZ http:\/\/t.co\/xgQCBr1VK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/abc1230news.1230thefan.com\" rel=\"nofollow\"\u003EABC1230NEWS APP\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABC1230News\/status\/615220285986447361\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/xgQCBr1VK1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CImzlyZWoAAAUvn.jpg",
        "id_str" : "615220285877428224",
        "id" : 615220285877428224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CImzlyZWoAAAUvn.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 630
        } ],
        "display_url" : "pic.twitter.com\/xgQCBr1VK1"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/FPIRBa0BBZ",
        "expanded_url" : "http:\/\/abc1230news.1230thefan.com\/2015\/06\/28\/two-blind-cows-find-sweet-friendship-at-new-york-farm-sanctuary\/",
        "display_url" : "abc1230news.1230thefan.com\/2015\/06\/28\/two\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615220285986447361",
    "text" : "Two Blind Cows Find Sweet Friendship at New York Farm Sanctuary -  http:\/\/t.co\/FPIRBa0BBZ http:\/\/t.co\/xgQCBr1VK1",
    "id" : 615220285986447361,
    "created_at" : "2015-06-28 18:08:41 +0000",
    "user" : {
      "name" : "News Radio 1230",
      "screen_name" : "ABC1230News",
      "protected" : false,
      "id_str" : "1621030400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431865417368215553\/08nRC2Yr_normal.png",
      "id" : 1621030400,
      "verified" : false
    }
  },
  "id" : 615338244461461504,
  "created_at" : "2015-06-29 01:57:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Summerfield",
      "screen_name" : "katiesummerfie2",
      "indices" : [ 3, 19 ],
      "id_str" : "1550301937",
      "id" : 1550301937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615285220141608960",
  "text" : "RT @katiesummerfie2: Standing on top of a hay bale in a ring feeder mooing her head off. She must like being up there as her 2xtime today h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/katiesummerfie2\/status\/615206558272720896\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/qnsPWGorRb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CImnF63WIAEhoV8.jpg",
        "id_str" : "615206544255361025",
        "id" : 615206544255361025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CImnF63WIAEhoV8.jpg",
        "sizes" : [ {
          "h" : 567,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 614
        }, {
          "h" : 1001,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qnsPWGorRb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615206558272720896",
    "text" : "Standing on top of a hay bale in a ring feeder mooing her head off. She must like being up there as her 2xtime today http:\/\/t.co\/qnsPWGorRb",
    "id" : 615206558272720896,
    "created_at" : "2015-06-28 17:14:08 +0000",
    "user" : {
      "name" : "Katie Summerfield",
      "screen_name" : "katiesummerfie2",
      "protected" : false,
      "id_str" : "1550301937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795320964150132736\/GHvX07rE_normal.jpg",
      "id" : 1550301937,
      "verified" : false
    }
  },
  "id" : 615285220141608960,
  "created_at" : "2015-06-28 22:26:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lorna",
      "screen_name" : "lorna_prentice",
      "indices" : [ 3, 18 ],
      "id_str" : "1445806682",
      "id" : 1445806682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highlandcattle",
      "indices" : [ 44, 59 ]
    }, {
      "text" : "heifer",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "bull",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "isleofiona",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615284105211736064",
  "text" : "RT @lorna_prentice: 'What you looking at?!' #highlandcattle #heifer #bull #isleofiona @floorsblackies http:\/\/t.co\/2q4bXbgdXf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lorna_prentice\/status\/615241585723342848\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/2q4bXbgdXf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CInG5l3XAAAPmfu.jpg",
        "id_str" : "615241516831932416",
        "id" : 615241516831932416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CInG5l3XAAAPmfu.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2q4bXbgdXf"
      } ],
      "hashtags" : [ {
        "text" : "highlandcattle",
        "indices" : [ 24, 39 ]
      }, {
        "text" : "heifer",
        "indices" : [ 40, 47 ]
      }, {
        "text" : "bull",
        "indices" : [ 48, 53 ]
      }, {
        "text" : "isleofiona",
        "indices" : [ 54, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615241585723342848",
    "text" : "'What you looking at?!' #highlandcattle #heifer #bull #isleofiona @floorsblackies http:\/\/t.co\/2q4bXbgdXf",
    "id" : 615241585723342848,
    "created_at" : "2015-06-28 19:33:19 +0000",
    "user" : {
      "name" : "lorna",
      "screen_name" : "lorna_prentice",
      "protected" : false,
      "id_str" : "1445806682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595942156382162944\/stOZ9RmR_normal.jpg",
      "id" : 1445806682,
      "verified" : false
    }
  },
  "id" : 615284105211736064,
  "created_at" : "2015-06-28 22:22:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/A80zKwon8k",
      "expanded_url" : "http:\/\/scripting.com\/2015\/06\/28\/itsNotLeftVsRight.html",
      "display_url" : "scripting.com\/2015\/06\/28\/its\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615271600284377090",
  "text" : "It's not left vs right\n\nhttp:\/\/t.co\/A80zKwon8k\n\nSent from FeedLab",
  "id" : 615271600284377090,
  "created_at" : "2015-06-28 21:32:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/8l4cZPboCv",
      "expanded_url" : "http:\/\/www.producthunt.com\/tech\/proudify",
      "display_url" : "producthunt.com\/tech\/proudify"
    } ]
  },
  "geo" : { },
  "id_str" : "615270440483823617",
  "text" : "Proudify: Upload a pic to get it rainbowed and support LGBT equality http:\/\/t.co\/8l4cZPboCv",
  "id" : 615270440483823617,
  "created_at" : "2015-06-28 21:27:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Ward",
      "screen_name" : "SteveWardNature",
      "indices" : [ 3, 19 ],
      "id_str" : "439904865",
      "id" : 439904865
    }, {
      "name" : "Blue Planet Society",
      "screen_name" : "Seasaver",
      "indices" : [ 126, 135 ],
      "id_str" : "22029553",
      "id" : 22029553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615263408783536128",
  "text" : "RT @SteveWardNature: Incoming Puffin .. Only ever photographed puffins once a few years ago for a few hours at the the Farnes @Seasaver htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Blue Planet Society",
        "screen_name" : "Seasaver",
        "indices" : [ 105, 114 ],
        "id_str" : "22029553",
        "id" : 22029553
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SteveWardNature\/status\/614897958484619264\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Q1X5tr8quh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIiObzbWIAAftVC.jpg",
        "id_str" : "614897957448589312",
        "id" : 614897957448589312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIiObzbWIAAftVC.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Q1X5tr8quh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614897958484619264",
    "text" : "Incoming Puffin .. Only ever photographed puffins once a few years ago for a few hours at the the Farnes @Seasaver http:\/\/t.co\/Q1X5tr8quh",
    "id" : 614897958484619264,
    "created_at" : "2015-06-27 20:47:52 +0000",
    "user" : {
      "name" : "Steve Ward",
      "screen_name" : "SteveWardNature",
      "protected" : false,
      "id_str" : "439904865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772147069247258624\/tVjgDN7S_normal.jpg",
      "id" : 439904865,
      "verified" : false
    }
  },
  "id" : 615263408783536128,
  "created_at" : "2015-06-28 21:00:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Ward",
      "screen_name" : "SteveWardNature",
      "indices" : [ 3, 19 ],
      "id_str" : "439904865",
      "id" : 439904865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SteveWardNature\/status\/614545660512194562\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/3txLYBp31V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdOBVxWUAApoNY.jpg",
      "id_str" : "614545659090325504",
      "id" : 614545659090325504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdOBVxWUAApoNY.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3txLYBp31V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615263339254554624",
  "text" : "RT @SteveWardNature: Great Egret last light http:\/\/t.co\/3txLYBp31V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SteveWardNature\/status\/614545660512194562\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/3txLYBp31V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdOBVxWUAApoNY.jpg",
        "id_str" : "614545659090325504",
        "id" : 614545659090325504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdOBVxWUAApoNY.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/3txLYBp31V"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614545660512194562",
    "text" : "Great Egret last light http:\/\/t.co\/3txLYBp31V",
    "id" : 614545660512194562,
    "created_at" : "2015-06-26 21:27:57 +0000",
    "user" : {
      "name" : "Steve Ward",
      "screen_name" : "SteveWardNature",
      "protected" : false,
      "id_str" : "439904865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772147069247258624\/tVjgDN7S_normal.jpg",
      "id" : 439904865,
      "verified" : false
    }
  },
  "id" : 615263339254554624,
  "created_at" : "2015-06-28 20:59:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Don Winslow",
      "screen_name" : "donwinslow",
      "indices" : [ 3, 14 ],
      "id_str" : "255812611",
      "id" : 255812611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615263270421835777",
  "text" : "RT @donwinslow: RT: After 15 years of writing about the war on drugs &amp; 45 years of failure, we must stop this madness.  Please read:\nhttp:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/e8HVAjLIAz",
        "expanded_url" : "http:\/\/thebea.st\/1CCuUQf",
        "display_url" : "thebea.st\/1CCuUQf"
      } ]
    },
    "geo" : { },
    "id_str" : "615245864022380544",
    "text" : "RT: After 15 years of writing about the war on drugs &amp; 45 years of failure, we must stop this madness.  Please read:\nhttp:\/\/t.co\/e8HVAjLIAz",
    "id" : 615245864022380544,
    "created_at" : "2015-06-28 19:50:19 +0000",
    "user" : {
      "name" : "Don Winslow",
      "screen_name" : "donwinslow",
      "protected" : false,
      "id_str" : "255812611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730137010472525824\/9qHC0cdL_normal.jpg",
      "id" : 255812611,
      "verified" : true
    }
  },
  "id" : 615263270421835777,
  "created_at" : "2015-06-28 20:59:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randal Rauser",
      "screen_name" : "RandalRauser",
      "indices" : [ 3, 16 ],
      "id_str" : "384611030",
      "id" : 384611030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheism",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "Christianity",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ClImpmTwMb",
      "expanded_url" : "http:\/\/randalrauser.com\/2015\/06\/review-copies-of-is-the-atheist-my-neighbor-for-bloggers\/",
      "display_url" : "randalrauser.com\/2015\/06\/review\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615225150867439616",
  "text" : "RT @RandalRauser: Here's how to request a review copy of my book \"Is the Atheist My Neighbor?\" http:\/\/t.co\/ClImpmTwMb #atheism #Christianity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheism",
        "indices" : [ 100, 108 ]
      }, {
        "text" : "Christianity",
        "indices" : [ 109, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/ClImpmTwMb",
        "expanded_url" : "http:\/\/randalrauser.com\/2015\/06\/review-copies-of-is-the-atheist-my-neighbor-for-bloggers\/",
        "display_url" : "randalrauser.com\/2015\/06\/review\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615223275208048640",
    "text" : "Here's how to request a review copy of my book \"Is the Atheist My Neighbor?\" http:\/\/t.co\/ClImpmTwMb #atheism #Christianity",
    "id" : 615223275208048640,
    "created_at" : "2015-06-28 18:20:33 +0000",
    "user" : {
      "name" : "Randal Rauser",
      "screen_name" : "RandalRauser",
      "protected" : false,
      "id_str" : "384611030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/452541600741076992\/U1bR7T-i_normal.jpeg",
      "id" : 384611030,
      "verified" : false
    }
  },
  "id" : 615225150867439616,
  "created_at" : "2015-06-28 18:28:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 3, 7 ],
      "id_str" : "12133382",
      "id" : 12133382
    }, {
      "name" : "Ian McKellen",
      "screen_name" : "IanMcKellen",
      "indices" : [ 10, 22 ],
      "id_str" : "104969057",
      "id" : 104969057
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PBS\/status\/615214466947502080\/video\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/zkmjr2WqEb",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/615214442419232768\/pu\/img\/pnu0JcEW15OIxAIi.jpg",
      "id_str" : "615214442419232768",
      "id" : 615214442419232768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/615214442419232768\/pu\/img\/pnu0JcEW15OIxAIi.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zkmjr2WqEb"
    } ],
    "hashtags" : [ {
      "text" : "NYCPride",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "ViciousPBS",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615224641280430080",
  "text" : "RT @PBS: .@IanMcKellen is a rockstar at the #NYCPride March. #ViciousPBS http:\/\/t.co\/zkmjr2WqEb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian McKellen",
        "screen_name" : "IanMcKellen",
        "indices" : [ 1, 13 ],
        "id_str" : "104969057",
        "id" : 104969057
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PBS\/status\/615214466947502080\/video\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/zkmjr2WqEb",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/615214442419232768\/pu\/img\/pnu0JcEW15OIxAIi.jpg",
        "id_str" : "615214442419232768",
        "id" : 615214442419232768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/615214442419232768\/pu\/img\/pnu0JcEW15OIxAIi.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zkmjr2WqEb"
      } ],
      "hashtags" : [ {
        "text" : "NYCPride",
        "indices" : [ 35, 44 ]
      }, {
        "text" : "ViciousPBS",
        "indices" : [ 52, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615214466947502080",
    "text" : ".@IanMcKellen is a rockstar at the #NYCPride March. #ViciousPBS http:\/\/t.co\/zkmjr2WqEb",
    "id" : 615214466947502080,
    "created_at" : "2015-06-28 17:45:33 +0000",
    "user" : {
      "name" : "PBS",
      "screen_name" : "PBS",
      "protected" : false,
      "id_str" : "12133382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701812252425322499\/hmTCz_yg_normal.png",
      "id" : 12133382,
      "verified" : true
    }
  },
  "id" : 615224641280430080,
  "created_at" : "2015-06-28 18:25:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/3zd51kFuPw",
      "expanded_url" : "https:\/\/stacksocial.com\/sales\/andru-chill-usb-smartphone-charger-green?rid=1070557",
      "display_url" : "stacksocial.com\/sales\/andru-ch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615223215863033860",
  "text" : "Adorbs! Get Andru USB Charger - Charge Hard, Play Harder with This Friendly Android Power Bot (40% off) https:\/\/t.co\/3zd51kFuPw",
  "id" : 615223215863033860,
  "created_at" : "2015-06-28 18:20:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/akOHwx4zgt",
      "expanded_url" : "https:\/\/stacksocial.com\/?rid=1070557",
      "display_url" : "stacksocial.com\/?rid=1070557"
    } ]
  },
  "geo" : { },
  "id_str" : "615222882080280576",
  "text" : "Hand-picked apps, gadgets and tech tools to satisfy your inner geek https:\/\/t.co\/akOHwx4zgt",
  "id" : 615222882080280576,
  "created_at" : "2015-06-28 18:19:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StackSocial",
      "screen_name" : "StackSocial",
      "indices" : [ 3, 15 ],
      "id_str" : "243742269",
      "id" : 243742269
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StackSocial\/status\/615218118051270657\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/tTWXFsc8vH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CImxnl-UcAAZvsj.png",
      "id_str" : "615218117879296000",
      "id" : 615218117879296000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CImxnl-UcAAZvsj.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/tTWXFsc8vH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qBqG6hY1FA",
      "expanded_url" : "http:\/\/stck.so\/1GK80be",
      "display_url" : "stck.so\/1GK80be"
    } ]
  },
  "geo" : { },
  "id_str" : "615222189256798208",
  "text" : "RT @StackSocial: Charge your device with this awesome Android robot inspired charger: http:\/\/t.co\/qBqG6hY1FA http:\/\/t.co\/tTWXFsc8vH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StackSocial\/status\/615218118051270657\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/tTWXFsc8vH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CImxnl-UcAAZvsj.png",
        "id_str" : "615218117879296000",
        "id" : 615218117879296000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CImxnl-UcAAZvsj.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 575
        } ],
        "display_url" : "pic.twitter.com\/tTWXFsc8vH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/qBqG6hY1FA",
        "expanded_url" : "http:\/\/stck.so\/1GK80be",
        "display_url" : "stck.so\/1GK80be"
      } ]
    },
    "geo" : { },
    "id_str" : "615218118051270657",
    "text" : "Charge your device with this awesome Android robot inspired charger: http:\/\/t.co\/qBqG6hY1FA http:\/\/t.co\/tTWXFsc8vH",
    "id" : 615218118051270657,
    "created_at" : "2015-06-28 18:00:04 +0000",
    "user" : {
      "name" : "StackSocial",
      "screen_name" : "StackSocial",
      "protected" : false,
      "id_str" : "243742269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000435130305\/cdc7430fe161d71a665285fef2068fdd_normal.png",
      "id" : 243742269,
      "verified" : false
    }
  },
  "id" : 615222189256798208,
  "created_at" : "2015-06-28 18:16:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/millionsnaps\/status\/614673827436498944\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/yUTk4r51io",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIfClokVAAAlxCP.jpg",
      "id_str" : "614673825960099840",
      "id" : 614673825960099840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIfClokVAAAlxCP.jpg",
      "sizes" : [ {
        "h" : 664,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yUTk4r51io"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615221007373217792",
  "text" : "RT @millionsnaps: Breathtaking Driftwood Dragon http:\/\/t.co\/yUTk4r51io",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/millionsnaps\/status\/614673827436498944\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/yUTk4r51io",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIfClokVAAAlxCP.jpg",
        "id_str" : "614673825960099840",
        "id" : 614673825960099840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIfClokVAAAlxCP.jpg",
        "sizes" : [ {
          "h" : 664,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 664,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/yUTk4r51io"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614673827436498944",
    "text" : "Breathtaking Driftwood Dragon http:\/\/t.co\/yUTk4r51io",
    "id" : 614673827436498944,
    "created_at" : "2015-06-27 05:57:15 +0000",
    "user" : {
      "name" : "Business Dubai",
      "screen_name" : "BusinessDBI",
      "protected" : false,
      "id_str" : "3069877766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651997136301649920\/rmyTjXeL_normal.jpg",
      "id" : 3069877766,
      "verified" : false
    }
  },
  "id" : 615221007373217792,
  "created_at" : "2015-06-28 18:11:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Queer&Present Danger",
      "screen_name" : "awhooker",
      "indices" : [ 3, 12 ],
      "id_str" : "49647020",
      "id" : 49647020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615217457687568384",
  "text" : "RT @awhooker: I say again: there is no such thing as 'biblical marriage' unless you are planning to marry a Bible.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615105719990358016",
    "text" : "I say again: there is no such thing as 'biblical marriage' unless you are planning to marry a Bible.",
    "id" : 615105719990358016,
    "created_at" : "2015-06-28 10:33:26 +0000",
    "user" : {
      "name" : "Queer&Present Danger",
      "screen_name" : "awhooker",
      "protected" : false,
      "id_str" : "49647020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757638708069855232\/AbUAf7XA_normal.jpg",
      "id" : 49647020,
      "verified" : false
    }
  },
  "id" : 615217457687568384,
  "created_at" : "2015-06-28 17:57:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615217116044726272",
  "text" : "RT @sarahnmoon: so basically me and these kids deconstructed the entire sunday school lesson and I was like, \"Uh...ok let's go outside and \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "615215387110719488",
    "geo" : { },
    "id_str" : "615215533114425344",
    "in_reply_to_user_id" : 24254537,
    "text" : "so basically me and these kids deconstructed the entire sunday school lesson and I was like, \"Uh...ok let's go outside and see the chickens\"",
    "id" : 615215533114425344,
    "in_reply_to_status_id" : 615215387110719488,
    "created_at" : "2015-06-28 17:49:47 +0000",
    "in_reply_to_screen_name" : "GrumpyTheology",
    "in_reply_to_user_id_str" : "24254537",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 615217116044726272,
  "created_at" : "2015-06-28 17:56:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Midori Takaki",
      "screen_name" : "MidoriTakaki",
      "indices" : [ 3, 16 ],
      "id_str" : "425854912",
      "id" : 425854912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615216502564888576",
  "text" : "RT @MidoriTakaki: Pleasr RT - Rescued magpie fledgling. Neck wings move, but not feet. Could be stunned or hit by car. Gave water soup. Sug\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615214007251808256",
    "text" : "Pleasr RT - Rescued magpie fledgling. Neck wings move, but not feet. Could be stunned or hit by car. Gave water soup. Suggestion for food?",
    "id" : 615214007251808256,
    "created_at" : "2015-06-28 17:43:44 +0000",
    "user" : {
      "name" : "Midori Takaki",
      "screen_name" : "MidoriTakaki",
      "protected" : false,
      "id_str" : "425854912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1667942042\/twitter_normal.jpg",
      "id" : 425854912,
      "verified" : false
    }
  },
  "id" : 615216502564888576,
  "created_at" : "2015-06-28 17:53:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/615192727643402240\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/m4NJX66dvV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CImahlUXAAACzRx.jpg",
      "id_str" : "615192725856649216",
      "id" : 615192725856649216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CImahlUXAAACzRx.jpg",
      "sizes" : [ {
        "h" : 931,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 931,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/m4NJX66dvV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615208197259952128",
  "text" : "RT @jacqueduncalf: \"I want all this sorted and a letter on my desk by Monday morning saying you swear to change \" http:\/\/t.co\/m4NJX66dvV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/615192727643402240\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/m4NJX66dvV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CImahlUXAAACzRx.jpg",
        "id_str" : "615192725856649216",
        "id" : 615192725856649216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CImahlUXAAACzRx.jpg",
        "sizes" : [ {
          "h" : 931,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 931,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/m4NJX66dvV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615192727643402240",
    "text" : "\"I want all this sorted and a letter on my desk by Monday morning saying you swear to change \" http:\/\/t.co\/m4NJX66dvV",
    "id" : 615192727643402240,
    "created_at" : "2015-06-28 16:19:10 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 615208197259952128,
  "created_at" : "2015-06-28 17:20:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615206898187563012",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ohh Dead Harvest looks good! *puts  it on list*",
  "id" : 615206898187563012,
  "created_at" : "2015-06-28 17:15:29 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615197772380123136",
  "geo" : { },
  "id_str" : "615205265806393345",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe teeheehee",
  "id" : 615205265806393345,
  "in_reply_to_status_id" : 615197772380123136,
  "created_at" : "2015-06-28 17:08:59 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kittiwake",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "coquetisland",
      "indices" : [ 47, 60 ]
    }, {
      "text" : "amble",
      "indices" : [ 107, 113 ]
    }, {
      "text" : "cute",
      "indices" : [ 114, 119 ]
    }, {
      "text" : "seabird",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615204410663280640",
  "text" : "RT @RSPBCoquet: #Kittiwake population is up on #coquetisland by 13% to 326. The largest ever recorded here #amble #cute #seabird http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RSPBCoquet\/status\/614086663820734464\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/QCeWVKi0RP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWskMCW8AAMrUb.jpg",
        "id_str" : "614086661912326144",
        "id" : 614086661912326144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWskMCW8AAMrUb.jpg",
        "sizes" : [ {
          "h" : 626,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1822,
          "resize" : "fit",
          "w" : 2981
        } ],
        "display_url" : "pic.twitter.com\/QCeWVKi0RP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/RSPBCoquet\/status\/614086663820734464\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/QCeWVKi0RP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWsjvMWEAAgRFc.jpg",
        "id_str" : "614086654169583616",
        "id" : 614086654169583616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWsjvMWEAAgRFc.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3110,
          "resize" : "fit",
          "w" : 4147
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QCeWVKi0RP"
      } ],
      "hashtags" : [ {
        "text" : "Kittiwake",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "coquetisland",
        "indices" : [ 31, 44 ]
      }, {
        "text" : "amble",
        "indices" : [ 91, 97 ]
      }, {
        "text" : "cute",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "seabird",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614086663820734464",
    "text" : "#Kittiwake population is up on #coquetisland by 13% to 326. The largest ever recorded here #amble #cute #seabird http:\/\/t.co\/QCeWVKi0RP",
    "id" : 614086663820734464,
    "created_at" : "2015-06-25 15:04:04 +0000",
    "user" : {
      "name" : "Rosy Tern",
      "screen_name" : "Coquet_Island",
      "protected" : false,
      "id_str" : "2842590207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530427031813500928\/iWMdiFmN_normal.jpeg",
      "id" : 2842590207,
      "verified" : false
    }
  },
  "id" : 615204410663280640,
  "created_at" : "2015-06-28 17:05:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "615192075160547328",
  "geo" : { },
  "id_str" : "615195038285451264",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe thx for comment. Makes me feel better about it. : )",
  "id" : 615195038285451264,
  "in_reply_to_status_id" : 615192075160547328,
  "created_at" : "2015-06-28 16:28:21 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615187836774543360",
  "text" : "Frankly, I'm the crazy one. DD is way ahead mentally than I was at her age.",
  "id" : 615187836774543360,
  "created_at" : "2015-06-28 15:59:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sertraline",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "anxiety",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "meds",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615186989013442560",
  "text" : "Because DD reaction to #sertraline doc mentioned inpatient stay to find right #anxiety #meds",
  "id" : 615186989013442560,
  "created_at" : "2015-06-28 15:56:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "anxiety",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615186390310109185",
  "text" : "It's frustrating not knowing whether #thyroid or #anxiety causing symptoms.",
  "id" : 615186390310109185,
  "created_at" : "2015-06-28 15:53:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anxiety",
      "indices" : [ 69, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615185885785661440",
  "text" : "I've been living in her bottom bunk for several days now because her #anxiety spikes when I leave",
  "id" : 615185885785661440,
  "created_at" : "2015-06-28 15:51:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615185035440844801",
  "text" : "I'm kinda hoping the u\/s on Tues shows something so they say \"no wonder you feel so crappy!\" sick DD #thyroid",
  "id" : 615185035440844801,
  "created_at" : "2015-06-28 15:48:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Castellan",
      "screen_name" : "revlucymeg",
      "indices" : [ 3, 14 ],
      "id_str" : "16651282",
      "id" : 16651282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GC78",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614951972752523264",
  "text" : "RT @revlucymeg: Heartening to hear person after person rise to speak against for-profit prisons and mass incarceration #GC78",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GC78",
        "indices" : [ 103, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614948151061934080",
    "text" : "Heartening to hear person after person rise to speak against for-profit prisons and mass incarceration #GC78",
    "id" : 614948151061934080,
    "created_at" : "2015-06-28 00:07:19 +0000",
    "user" : {
      "name" : "Megan Castellan",
      "screen_name" : "revlucymeg",
      "protected" : false,
      "id_str" : "16651282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697833886554820608\/ZwST36CL_normal.jpg",
      "id" : 16651282,
      "verified" : false
    }
  },
  "id" : 614951972752523264,
  "created_at" : "2015-06-28 00:22:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recorded Books",
      "screen_name" : "recordedbooks",
      "indices" : [ 53, 67 ],
      "id_str" : "16904257",
      "id" : 16904257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobooks",
      "indices" : [ 20, 31 ]
    }, {
      "text" : "JIAM",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "AudiobookMonth",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/VCqNF0RKN5",
      "expanded_url" : "http:\/\/www.hotlistens.com\/last-days-of-june-is-audiobook-month-giveaway-recordedbooks-jiam\/",
      "display_url" : "hotlistens.com\/last-days-of-j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614910392511430656",
  "text" : "I ENTERED TO WIN 25 #audiobooks downloads plus more! @Recordedbooks #JIAM #AudiobookMonth http:\/\/t.co\/VCqNF0RKN5",
  "id" : 614910392511430656,
  "created_at" : "2015-06-27 21:37:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    }, {
      "name" : "Candace Robinson",
      "screen_name" : "candacemom2two",
      "indices" : [ 107, 122 ],
      "id_str" : "72562363",
      "id" : 72562363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/2A16wwd05x",
      "expanded_url" : "http:\/\/goo.gl\/wERBli",
      "display_url" : "goo.gl\/wERBli"
    } ]
  },
  "geo" : { },
  "id_str" : "614909011876515840",
  "text" : "RT @BeasBookNook: Saturday Situation~ Link Up Your Bookish Posts and Giveaways! http:\/\/t.co\/2A16wwd05x via @candacemom2two",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Candace Robinson",
        "screen_name" : "candacemom2two",
        "indices" : [ 89, 104 ],
        "id_str" : "72562363",
        "id" : 72562363
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/2A16wwd05x",
        "expanded_url" : "http:\/\/goo.gl\/wERBli",
        "display_url" : "goo.gl\/wERBli"
      } ]
    },
    "geo" : { },
    "id_str" : "614902538060591104",
    "text" : "Saturday Situation~ Link Up Your Bookish Posts and Giveaways! http:\/\/t.co\/2A16wwd05x via @candacemom2two",
    "id" : 614902538060591104,
    "created_at" : "2015-06-27 21:06:04 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 614909011876515840,
  "created_at" : "2015-06-27 21:31:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "indices" : [ 3, 16 ],
      "id_str" : "43298413",
      "id" : 43298413
    }, {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 18, 32 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NathanDunbar\/status\/614884919207141376\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/2oNoMs7T1N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIiCkXoWcAERDE3.jpg",
      "id_str" : "614884910466232321",
      "id" : 614884910466232321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIiCkXoWcAERDE3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 552
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 552
      } ],
      "display_url" : "pic.twitter.com\/2oNoMs7T1N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614890902184701952",
  "text" : "RT @NathanDunbar: @johnnie_cakes just give her this, which I wrote to my cousin. http:\/\/t.co\/2oNoMs7T1N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John",
        "screen_name" : "johnnie_cakes",
        "indices" : [ 0, 14 ],
        "id_str" : "16901470",
        "id" : 16901470
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NathanDunbar\/status\/614884919207141376\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/2oNoMs7T1N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIiCkXoWcAERDE3.jpg",
        "id_str" : "614884910466232321",
        "id" : 614884910466232321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIiCkXoWcAERDE3.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 150,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 552
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 552
        } ],
        "display_url" : "pic.twitter.com\/2oNoMs7T1N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "614884684846137345",
    "geo" : { },
    "id_str" : "614884919207141376",
    "in_reply_to_user_id" : 16901470,
    "text" : "@johnnie_cakes just give her this, which I wrote to my cousin. http:\/\/t.co\/2oNoMs7T1N",
    "id" : 614884919207141376,
    "in_reply_to_status_id" : 614884684846137345,
    "created_at" : "2015-06-27 19:56:03 +0000",
    "in_reply_to_screen_name" : "johnnie_cakes",
    "in_reply_to_user_id_str" : "16901470",
    "user" : {
      "name" : "Nathan",
      "screen_name" : "NathanDunbar",
      "protected" : false,
      "id_str" : "43298413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683069342842503169\/t-eR15ya_normal.jpg",
      "id" : 43298413,
      "verified" : false
    }
  },
  "id" : 614890902184701952,
  "created_at" : "2015-06-27 20:19:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "indices" : [ 3, 14 ],
      "id_str" : "276314137",
      "id" : 276314137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614874363351953408",
  "text" : "RT @jonlieffmd: First animal sensor of Earth's magnetic field found in the brain of a tiny worm related to internal compass http:\/\/t.co\/MgL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brain",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/MgL4H04669",
        "expanded_url" : "http:\/\/bit.ly\/1MMTnYk",
        "display_url" : "bit.ly\/1MMTnYk"
      } ]
    },
    "geo" : { },
    "id_str" : "614870832595255297",
    "text" : "First animal sensor of Earth's magnetic field found in the brain of a tiny worm related to internal compass http:\/\/t.co\/MgL4H04669 #brain",
    "id" : 614870832595255297,
    "created_at" : "2015-06-27 19:00:04 +0000",
    "user" : {
      "name" : "Jon Lieff MD",
      "screen_name" : "jonlieffmd",
      "protected" : false,
      "id_str" : "276314137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1762803890\/JonLieffMD4_normal.jpg",
      "id" : 276314137,
      "verified" : false
    }
  },
  "id" : 614874363351953408,
  "created_at" : "2015-06-27 19:14:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/614869850276667393\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/78cPMhU3wc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIh03t6XAAAB4Ch.jpg",
      "id_str" : "614869849702072320",
      "id" : 614869849702072320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIh03t6XAAAB4Ch.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/78cPMhU3wc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/DYkrPdU57J",
      "expanded_url" : "http:\/\/nyti.ms\/1BKaREk",
      "display_url" : "nyti.ms\/1BKaREk"
    } ]
  },
  "geo" : { },
  "id_str" : "614871775600594944",
  "text" : "RT @nytimes: Watch: Obama sings \"Amazing Grace\" at the funeral for the Rev. Clementa Pinckney http:\/\/t.co\/DYkrPdU57J http:\/\/t.co\/78cPMhU3wc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/614869850276667393\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/78cPMhU3wc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIh03t6XAAAB4Ch.jpg",
        "id_str" : "614869849702072320",
        "id" : 614869849702072320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIh03t6XAAAB4Ch.jpg",
        "sizes" : [ {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/78cPMhU3wc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/DYkrPdU57J",
        "expanded_url" : "http:\/\/nyti.ms\/1BKaREk",
        "display_url" : "nyti.ms\/1BKaREk"
      } ]
    },
    "geo" : { },
    "id_str" : "614869850276667393",
    "text" : "Watch: Obama sings \"Amazing Grace\" at the funeral for the Rev. Clementa Pinckney http:\/\/t.co\/DYkrPdU57J http:\/\/t.co\/78cPMhU3wc",
    "id" : 614869850276667393,
    "created_at" : "2015-06-27 18:56:10 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 614871775600594944,
  "created_at" : "2015-06-27 19:03:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 0, 13 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614862196766445568",
  "geo" : { },
  "id_str" : "614868759250083840",
  "in_reply_to_user_id" : 17374293,
  "text" : "@JeremyCShipp pain.. ick. ((hugs))",
  "id" : 614868759250083840,
  "in_reply_to_status_id" : 614862196766445568,
  "created_at" : "2015-06-27 18:51:50 +0000",
  "in_reply_to_screen_name" : "JeremyCShipp",
  "in_reply_to_user_id_str" : "17374293",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Langerak",
      "screen_name" : "Linda_Langerak",
      "indices" : [ 3, 18 ],
      "id_str" : "2757425865",
      "id" : 2757425865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Linda_Langerak\/status\/614078010296176640\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/WvCqkhIkR2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWkqheWcAAQt_f.jpg",
      "id_str" : "614077974653071360",
      "id" : 614077974653071360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWkqheWcAAQt_f.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/WvCqkhIkR2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Linda_Langerak\/status\/614078010296176640\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/WvCqkhIkR2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWkqiJWgAUDCPd.jpg",
      "id_str" : "614077974833430533",
      "id" : 614077974833430533,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWkqiJWgAUDCPd.jpg",
      "sizes" : [ {
        "h" : 481,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/WvCqkhIkR2"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Linda_Langerak\/status\/614078010296176640\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/WvCqkhIkR2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWkqjfWsAEdj1-.jpg",
      "id_str" : "614077975194152961",
      "id" : 614077975194152961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWkqjfWsAEdj1-.jpg",
      "sizes" : [ {
        "h" : 511,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WvCqkhIkR2"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "birdphotography",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614868285344100352",
  "text" : "RT @Linda_Langerak: Someone had a lot to say.... Male Brown Headed Cowbird #birds #birdphotography http:\/\/t.co\/WvCqkhIkR2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Linda_Langerak\/status\/614078010296176640\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/WvCqkhIkR2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWkqheWcAAQt_f.jpg",
        "id_str" : "614077974653071360",
        "id" : 614077974653071360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWkqheWcAAQt_f.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/WvCqkhIkR2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Linda_Langerak\/status\/614078010296176640\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/WvCqkhIkR2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWkqiJWgAUDCPd.jpg",
        "id_str" : "614077974833430533",
        "id" : 614077974833430533,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWkqiJWgAUDCPd.jpg",
        "sizes" : [ {
          "h" : 481,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/WvCqkhIkR2"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Linda_Langerak\/status\/614078010296176640\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/WvCqkhIkR2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIWkqjfWsAEdj1-.jpg",
        "id_str" : "614077975194152961",
        "id" : 614077975194152961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIWkqjfWsAEdj1-.jpg",
        "sizes" : [ {
          "h" : 511,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/WvCqkhIkR2"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 55, 61 ]
      }, {
        "text" : "birdphotography",
        "indices" : [ 62, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614078010296176640",
    "text" : "Someone had a lot to say.... Male Brown Headed Cowbird #birds #birdphotography http:\/\/t.co\/WvCqkhIkR2",
    "id" : 614078010296176640,
    "created_at" : "2015-06-25 14:29:41 +0000",
    "user" : {
      "name" : "Linda Langerak",
      "screen_name" : "Linda_Langerak",
      "protected" : false,
      "id_str" : "2757425865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738906606138580993\/Ubt_ogXQ_normal.jpg",
      "id" : 2757425865,
      "verified" : false
    }
  },
  "id" : 614868285344100352,
  "created_at" : "2015-06-27 18:49:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/614860862398959616\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/87HJDznVyo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhspZOUMAAkylF.jpg",
      "id_str" : "614860807537438720",
      "id" : 614860807537438720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhspZOUMAAkylF.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/87HJDznVyo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/614860862398959616\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/87HJDznVyo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhspZ_UkAA7uD9.jpg",
      "id_str" : "614860807742984192",
      "id" : 614860807742984192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhspZ_UkAA7uD9.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/87HJDznVyo"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/614860862398959616\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/87HJDznVyo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhspapUYAIhnz4.jpg",
      "id_str" : "614860807919132674",
      "id" : 614860807919132674,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhspapUYAIhnz4.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/87HJDznVyo"
    } ],
    "hashtags" : [ {
      "text" : "wildflowers",
      "indices" : [ 73, 85 ]
    }, {
      "text" : "Nebraska",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614862993353011200",
  "text" : "RT @rm123077: All the spring rains sprouted lots of Coreopsis this year. #wildflowers #Nebraska http:\/\/t.co\/87HJDznVyo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/614860862398959616\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/87HJDznVyo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhspZOUMAAkylF.jpg",
        "id_str" : "614860807537438720",
        "id" : 614860807537438720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhspZOUMAAkylF.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/87HJDznVyo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/614860862398959616\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/87HJDznVyo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhspZ_UkAA7uD9.jpg",
        "id_str" : "614860807742984192",
        "id" : 614860807742984192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhspZ_UkAA7uD9.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/87HJDznVyo"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/614860862398959616\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/87HJDznVyo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhspapUYAIhnz4.jpg",
        "id_str" : "614860807919132674",
        "id" : 614860807919132674,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhspapUYAIhnz4.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/87HJDznVyo"
      } ],
      "hashtags" : [ {
        "text" : "wildflowers",
        "indices" : [ 59, 71 ]
      }, {
        "text" : "Nebraska",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614860862398959616",
    "text" : "All the spring rains sprouted lots of Coreopsis this year. #wildflowers #Nebraska http:\/\/t.co\/87HJDznVyo",
    "id" : 614860862398959616,
    "created_at" : "2015-06-27 18:20:27 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 614862993353011200,
  "created_at" : "2015-06-27 18:28:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dodgson Wood",
      "screen_name" : "dodgsonwood",
      "indices" : [ 3, 15 ],
      "id_str" : "2840524667",
      "id" : 2840524667
    }, {
      "name" : "Woolfest Cumbria",
      "screen_name" : "WoolfestGB",
      "indices" : [ 27, 38 ],
      "id_str" : "2792048530",
      "id" : 2792048530
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dodgsonwood\/status\/614816727227084800\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/LvVTAIl49Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhEdF6WgAAw5vf.jpg",
      "id_str" : "614816615729889280",
      "id" : 614816615729889280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhEdF6WgAAw5vf.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LvVTAIl49Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614858576633442304",
  "text" : "RT @dodgsonwood: Exhausted @WoolfestGB http:\/\/t.co\/LvVTAIl49Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Woolfest Cumbria",
        "screen_name" : "WoolfestGB",
        "indices" : [ 10, 21 ],
        "id_str" : "2792048530",
        "id" : 2792048530
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dodgsonwood\/status\/614816727227084800\/photo\/1",
        "indices" : [ 22, 44 ],
        "url" : "http:\/\/t.co\/LvVTAIl49Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhEdF6WgAAw5vf.jpg",
        "id_str" : "614816615729889280",
        "id" : 614816615729889280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhEdF6WgAAw5vf.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LvVTAIl49Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614816727227084800",
    "text" : "Exhausted @WoolfestGB http:\/\/t.co\/LvVTAIl49Q",
    "id" : 614816727227084800,
    "created_at" : "2015-06-27 15:25:05 +0000",
    "user" : {
      "name" : "Dodgson Wood",
      "screen_name" : "dodgsonwood",
      "protected" : false,
      "id_str" : "2840524667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601414774686089216\/R4nVNjog_normal.jpg",
      "id" : 2840524667,
      "verified" : false
    }
  },
  "id" : 614858576633442304,
  "created_at" : "2015-06-27 18:11:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614858101024534530",
  "text" : "Her weight has gone up. Holding at 89 lbs. Milkshakes and protein drinks daily.",
  "id" : 614858101024534530,
  "created_at" : "2015-06-27 18:09:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SteamPoweredGiraffe",
      "screen_name" : "SPGiraffe",
      "indices" : [ 3, 13 ],
      "id_str" : "21124068",
      "id" : 21124068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oQTvB4SiIB",
      "expanded_url" : "http:\/\/steampoweredgiraffe.com\/playingcards.html",
      "display_url" : "steampoweredgiraffe.com\/playingcards.h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614857483765612544",
  "text" : "RT @SPGiraffe: We aren't restocking our SPG decks, so once they're gone, they're gone for good! Get yours now!http:\/\/t.co\/oQTvB4SiIB http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SPGiraffe\/status\/614851046037282816\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/vBt1Vfol4X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhjxH_UAAA8RGS.jpg",
        "id_str" : "614851044745412608",
        "id" : 614851044745412608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhjxH_UAAA8RGS.jpg",
        "sizes" : [ {
          "h" : 465,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 820,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vBt1Vfol4X"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SPGiraffe\/status\/614851046037282816\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/vBt1Vfol4X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhjxK3UAAAvhmv.jpg",
        "id_str" : "614851045517164544",
        "id" : 614851045517164544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhjxK3UAAAvhmv.jpg",
        "sizes" : [ {
          "h" : 414,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 309
        } ],
        "display_url" : "pic.twitter.com\/vBt1Vfol4X"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/oQTvB4SiIB",
        "expanded_url" : "http:\/\/steampoweredgiraffe.com\/playingcards.html",
        "display_url" : "steampoweredgiraffe.com\/playingcards.h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614851046037282816",
    "text" : "We aren't restocking our SPG decks, so once they're gone, they're gone for good! Get yours now!http:\/\/t.co\/oQTvB4SiIB http:\/\/t.co\/vBt1Vfol4X",
    "id" : 614851046037282816,
    "created_at" : "2015-06-27 17:41:27 +0000",
    "user" : {
      "name" : "SteamPoweredGiraffe",
      "screen_name" : "SPGiraffe",
      "protected" : false,
      "id_str" : "21124068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712827378909601793\/4oJPYDlb_normal.jpg",
      "id" : 21124068,
      "verified" : false
    }
  },
  "id" : 614857483765612544,
  "created_at" : "2015-06-27 18:07:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ketones",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "diabetes",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "stress",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "sick",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614857325933953025",
  "text" : "Does one need rx to test blood sugar? DD had high #ketones on ER labs #diabetes #thyroid #stress #sick",
  "id" : 614857325933953025,
  "created_at" : "2015-06-27 18:06:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614853489387290624",
  "text" : "My poor babe had another episode this am. Ativan, anti-nausea kept it from total meltdown but still.. #sick #thyroid",
  "id" : 614853489387290624,
  "created_at" : "2015-06-27 17:51:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ADF",
      "screen_name" : "AlinaDal_F",
      "indices" : [ 3, 14 ],
      "id_str" : "1484891485",
      "id" : 1484891485
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AlinaDal_F\/status\/610693669159596032\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Hj1TG2oL7N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHmep9eWEAA-WwN.jpg",
      "id_str" : "610693668199075840",
      "id" : 610693668199075840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHmep9eWEAA-WwN.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 757,
        "resize" : "fit",
        "w" : 1165
      }, {
        "h" : 665,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Hj1TG2oL7N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614835063629459456",
  "text" : "RT @AlinaDal_F: Love is the enchanted dawn of every heart.\nAlphonse de Lamartine http:\/\/t.co\/Hj1TG2oL7N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlinaDal_F\/status\/610693669159596032\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/Hj1TG2oL7N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHmep9eWEAA-WwN.jpg",
        "id_str" : "610693668199075840",
        "id" : 610693668199075840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHmep9eWEAA-WwN.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 757,
          "resize" : "fit",
          "w" : 1165
        }, {
          "h" : 665,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Hj1TG2oL7N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610693669159596032",
    "text" : "Love is the enchanted dawn of every heart.\nAlphonse de Lamartine http:\/\/t.co\/Hj1TG2oL7N",
    "id" : 610693669159596032,
    "created_at" : "2015-06-16 06:21:31 +0000",
    "user" : {
      "name" : "ADF",
      "screen_name" : "AlinaDal_F",
      "protected" : false,
      "id_str" : "1484891485",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728238240889712640\/sM8dPtFi_normal.jpg",
      "id" : 1484891485,
      "verified" : false
    }
  },
  "id" : 614835063629459456,
  "created_at" : "2015-06-27 16:37:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "indices" : [ 0, 12 ],
      "id_str" : "21833728",
      "id" : 21833728
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 13, 25 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614816013226524676",
  "geo" : { },
  "id_str" : "614834927960461312",
  "in_reply_to_user_id" : 21833728,
  "text" : "@Brasilmagic @VirgoJohnny ohhh.. Can that happen?? That would be awesome.",
  "id" : 614834927960461312,
  "in_reply_to_status_id" : 614816013226524676,
  "created_at" : "2015-06-27 16:37:24 +0000",
  "in_reply_to_screen_name" : "Brasilmagic",
  "in_reply_to_user_id_str" : "21833728",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Snyder",
      "screen_name" : "noteon",
      "indices" : [ 3, 10 ],
      "id_str" : "16065917",
      "id" : 16065917
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/noteon\/status\/614832048889589761\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/aKjaMxEZMz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhSe1uWwAEB5Jo.jpg",
      "id_str" : "614832038907133953",
      "id" : 614832038907133953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhSe1uWwAEB5Jo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/aKjaMxEZMz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614833727802318848",
  "text" : "RT @noteon: Inscription on the Jefferson memorial http:\/\/t.co\/aKjaMxEZMz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/noteon\/status\/614832048889589761\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/aKjaMxEZMz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIhSe1uWwAEB5Jo.jpg",
        "id_str" : "614832038907133953",
        "id" : 614832038907133953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIhSe1uWwAEB5Jo.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/aKjaMxEZMz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614832048889589761",
    "text" : "Inscription on the Jefferson memorial http:\/\/t.co\/aKjaMxEZMz",
    "id" : 614832048889589761,
    "created_at" : "2015-06-27 16:25:58 +0000",
    "user" : {
      "name" : "Keith Snyder",
      "screen_name" : "noteon",
      "protected" : false,
      "id_str" : "16065917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734735503069585408\/AmMDryty_normal.jpg",
      "id" : 16065917,
      "verified" : false
    }
  },
  "id" : 614833727802318848,
  "created_at" : "2015-06-27 16:32:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikki NB Miner Bill",
      "screen_name" : "BoaterNikki",
      "indices" : [ 3, 15 ],
      "id_str" : "636266522",
      "id" : 636266522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/613797644817813505\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/KSFEGn17wI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CISlsdxXAAAR8eb.jpg",
      "id_str" : "613797632553713664",
      "id" : 613797632553713664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CISlsdxXAAAR8eb.jpg",
      "sizes" : [ {
        "h" : 261,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KSFEGn17wI"
    } ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "photography",
      "indices" : [ 70, 82 ]
    }, {
      "text" : "canal",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "boatsthattweet",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614833462554558464",
  "text" : "RT @BoaterNikki: 'Mirror image'\nHave a wonderful evening all \uD83D\uDE06\n#photo #photography #canal #boatsthattweet http:\/\/t.co\/KSFEGn17wI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoaterNikki\/status\/613797644817813505\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/KSFEGn17wI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CISlsdxXAAAR8eb.jpg",
        "id_str" : "613797632553713664",
        "id" : 613797632553713664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CISlsdxXAAAR8eb.jpg",
        "sizes" : [ {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KSFEGn17wI"
      } ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 46, 52 ]
      }, {
        "text" : "photography",
        "indices" : [ 53, 65 ]
      }, {
        "text" : "canal",
        "indices" : [ 66, 72 ]
      }, {
        "text" : "boatsthattweet",
        "indices" : [ 73, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613797644817813505",
    "text" : "'Mirror image'\nHave a wonderful evening all \uD83D\uDE06\n#photo #photography #canal #boatsthattweet http:\/\/t.co\/KSFEGn17wI",
    "id" : 613797644817813505,
    "created_at" : "2015-06-24 19:55:36 +0000",
    "user" : {
      "name" : "Nikki NB Miner Bill",
      "screen_name" : "BoaterNikki",
      "protected" : false,
      "id_str" : "636266522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741687568840982529\/gMJEotN6_normal.jpg",
      "id" : 636266522,
      "verified" : false
    }
  },
  "id" : 614833462554558464,
  "created_at" : "2015-06-27 16:31:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 3, 15 ],
      "id_str" : "298992506",
      "id" : 298992506
    }, {
      "name" : "pooks",
      "screen_name" : "Siberia61",
      "indices" : [ 20, 30 ],
      "id_str" : "1244239765",
      "id" : 1244239765
    }, {
      "name" : "Birds Wildlife UK",
      "screen_name" : "Birds_UK",
      "indices" : [ 99, 108 ],
      "id_str" : "80293950",
      "id" : 80293950
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 109, 121 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "30DaysWild",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "Springwatch",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614831737261158400",
  "text" : "RT @wildlife_uk: RT @Siberia61: Ever get the feeling your being watched ? #30DaysWild #Springwatch @Birds_UK @wildlife_uk http:\/\/t.co\/q3hPR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pooks",
        "screen_name" : "Siberia61",
        "indices" : [ 3, 13 ],
        "id_str" : "1244239765",
        "id" : 1244239765
      }, {
        "name" : "Birds Wildlife UK",
        "screen_name" : "Birds_UK",
        "indices" : [ 82, 91 ],
        "id_str" : "80293950",
        "id" : 80293950
      }, {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 92, 104 ],
        "id_str" : "298992506",
        "id" : 298992506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/613310866012901376\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/q3hPRUggz8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CILq6ChWUAAotxA.jpg",
        "id_str" : "613310782105866240",
        "id" : 613310782105866240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CILq6ChWUAAotxA.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q3hPRUggz8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/613310866012901376\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/q3hPRUggz8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CILq6C3WwAEfvhW.jpg",
        "id_str" : "613310782198169601",
        "id" : 613310782198169601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CILq6C3WwAEfvhW.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q3hPRUggz8"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/613310866012901376\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/q3hPRUggz8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CILq6DLWUAAVgbj.jpg",
        "id_str" : "613310782282027008",
        "id" : 613310782282027008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CILq6DLWUAAVgbj.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q3hPRUggz8"
      } ],
      "hashtags" : [ {
        "text" : "30DaysWild",
        "indices" : [ 57, 68 ]
      }, {
        "text" : "Springwatch",
        "indices" : [ 69, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614197662301192192",
    "text" : "RT @Siberia61: Ever get the feeling your being watched ? #30DaysWild #Springwatch @Birds_UK @wildlife_uk http:\/\/t.co\/q3hPRUggz8",
    "id" : 614197662301192192,
    "created_at" : "2015-06-25 22:25:08 +0000",
    "user" : {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "protected" : false,
      "id_str" : "298992506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543830606543478784\/DvQW3ag9_normal.png",
      "id" : 298992506,
      "verified" : false
    }
  },
  "id" : 614831737261158400,
  "created_at" : "2015-06-27 16:24:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614827891390595072",
  "text" : "RT @morsemusings: I'm a rainbow, you're a rainbow. Not limited by the sky. Fly. Fly. Fly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614820920499179520",
    "text" : "I'm a rainbow, you're a rainbow. Not limited by the sky. Fly. Fly. Fly.",
    "id" : 614820920499179520,
    "created_at" : "2015-06-27 15:41:44 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 614827891390595072,
  "created_at" : "2015-06-27 16:09:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sad girl",
      "screen_name" : "_courtkneelove",
      "indices" : [ 3, 18 ],
      "id_str" : "52157153",
      "id" : 52157153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614826096022921216",
  "text" : "RT @_courtkneelove: THIS GENERATION IS TURNING THE WORLD UPSIDE DOWN AND CHALLENGING INJUSTICE AND ITS THRILLING",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614823022214524933",
    "text" : "THIS GENERATION IS TURNING THE WORLD UPSIDE DOWN AND CHALLENGING INJUSTICE AND ITS THRILLING",
    "id" : 614823022214524933,
    "created_at" : "2015-06-27 15:50:06 +0000",
    "user" : {
      "name" : "sad girl",
      "screen_name" : "_courtkneelove",
      "protected" : false,
      "id_str" : "52157153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800970830406619137\/-yM3wQJF_normal.jpg",
      "id" : 52157153,
      "verified" : false
    }
  },
  "id" : 614826096022921216,
  "created_at" : "2015-06-27 16:02:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jelani cobb",
      "screen_name" : "jelani9",
      "indices" : [ 3, 11 ],
      "id_str" : "14155907",
      "id" : 14155907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614826011629330432",
  "text" : "RT @jelani9: In past 24 hours we got a President singing spirituals, a rainbow-colored White House &amp; the term \"on the pole\" redefined as re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614817575525064704",
    "text" : "In past 24 hours we got a President singing spirituals, a rainbow-colored White House &amp; the term \"on the pole\" redefined as revolutionary.",
    "id" : 614817575525064704,
    "created_at" : "2015-06-27 15:28:27 +0000",
    "user" : {
      "name" : "jelani cobb",
      "screen_name" : "jelani9",
      "protected" : false,
      "id_str" : "14155907",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491951552827899905\/Qyy9JSK4_normal.jpeg",
      "id" : 14155907,
      "verified" : true
    }
  },
  "id" : 614826011629330432,
  "created_at" : "2015-06-27 16:01:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SWTLackfordLakes",
      "screen_name" : "SWTLackfordLake",
      "indices" : [ 3, 19 ],
      "id_str" : "2812734654",
      "id" : 2812734654
    }, {
      "name" : "SuffolkWildlifeTrust",
      "screen_name" : "suffolkwildlife",
      "indices" : [ 108, 124 ],
      "id_str" : "57052934",
      "id" : 57052934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lackfordlakes",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614825407037198336",
  "text" : "RT @SWTLackfordLake: Green sandpiper at #lackfordlakes today, takes our total to 131 bird species for 2015. @suffolkwildlife http:\/\/t.co\/9H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SuffolkWildlifeTrust",
        "screen_name" : "suffolkwildlife",
        "indices" : [ 87, 103 ],
        "id_str" : "57052934",
        "id" : 57052934
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SWTLackfordLake\/status\/614544062734041090\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/9HLQJzRVBK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdMkV-WwAEYTR2.jpg",
        "id_str" : "614544061417046017",
        "id" : 614544061417046017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdMkV-WwAEYTR2.jpg",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 1008
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 1008
        } ],
        "display_url" : "pic.twitter.com\/9HLQJzRVBK"
      } ],
      "hashtags" : [ {
        "text" : "lackfordlakes",
        "indices" : [ 19, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614544062734041090",
    "text" : "Green sandpiper at #lackfordlakes today, takes our total to 131 bird species for 2015. @suffolkwildlife http:\/\/t.co\/9HLQJzRVBK",
    "id" : 614544062734041090,
    "created_at" : "2015-06-26 21:21:36 +0000",
    "user" : {
      "name" : "SWTLackfordLakes",
      "screen_name" : "SWTLackfordLake",
      "protected" : false,
      "id_str" : "2812734654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605380042819047425\/WSfYbZu8_normal.jpg",
      "id" : 2812734654,
      "verified" : false
    }
  },
  "id" : 614825407037198336,
  "created_at" : "2015-06-27 15:59:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "teamStripe",
      "screen_name" : "teamStripe",
      "indices" : [ 3, 14 ],
      "id_str" : "2938475619",
      "id" : 2938475619
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/4PvySS63ps",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rYzWsAA0YuM.jpg",
      "id_str" : "614800368644567040",
      "id" : 614800368644567040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rYzWsAA0YuM.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4PvySS63ps"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/4PvySS63ps",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rZKWwAAxy2X.jpg",
      "id_str" : "614800368741040128",
      "id" : 614800368741040128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rZKWwAAxy2X.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4PvySS63ps"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/4PvySS63ps",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rbCWoAAY3mm.jpg",
      "id_str" : "614800369244348416",
      "id" : 614800369244348416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rbCWoAAY3mm.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4PvySS63ps"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/4PvySS63ps",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rboWoAI6n5K.jpg",
      "id_str" : "614800369403731970",
      "id" : 614800369403731970,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rboWoAI6n5K.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4PvySS63ps"
    } ],
    "hashtags" : [ {
      "text" : "beltedCalfwash",
      "indices" : [ 16, 31 ]
    }, {
      "text" : "teamStripe",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614810134838120448",
  "text" : "RT @TeamStripe: #beltedCalfwash #teamStripe http:\/\/t.co\/4PvySS63ps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/4PvySS63ps",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rYzWsAA0YuM.jpg",
        "id_str" : "614800368644567040",
        "id" : 614800368644567040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rYzWsAA0YuM.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4PvySS63ps"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/4PvySS63ps",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rZKWwAAxy2X.jpg",
        "id_str" : "614800368741040128",
        "id" : 614800368741040128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rZKWwAAxy2X.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4PvySS63ps"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/4PvySS63ps",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rbCWoAAY3mm.jpg",
        "id_str" : "614800369244348416",
        "id" : 614800369244348416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rbCWoAAY3mm.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4PvySS63ps"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/TeamStripe\/status\/614800481987260417\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/4PvySS63ps",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIg1rboWoAI6n5K.jpg",
        "id_str" : "614800369403731970",
        "id" : 614800369403731970,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIg1rboWoAI6n5K.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4PvySS63ps"
      } ],
      "hashtags" : [ {
        "text" : "beltedCalfwash",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "teamStripe",
        "indices" : [ 16, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614800481987260417",
    "text" : "#beltedCalfwash #teamStripe http:\/\/t.co\/4PvySS63ps",
    "id" : 614800481987260417,
    "created_at" : "2015-06-27 14:20:32 +0000",
    "user" : {
      "name" : "teamStripe",
      "screen_name" : "teamStripe",
      "protected" : false,
      "id_str" : "2938475619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620189924915048448\/JFbRz-QX_normal.jpg",
      "id" : 2938475619,
      "verified" : false
    }
  },
  "id" : 614810134838120448,
  "created_at" : "2015-06-27 14:58:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/569168399919669248\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/tBHrZzLxCs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-YXpN8IUAAQQKE.jpg",
      "id_str" : "569168399792885760",
      "id" : 569168399792885760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-YXpN8IUAAQQKE.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/tBHrZzLxCs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614805954983514112",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/tBHrZzLxCs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/569168399919669248\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/tBHrZzLxCs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-YXpN8IUAAQQKE.jpg",
        "id_str" : "569168399792885760",
        "id" : 569168399792885760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-YXpN8IUAAQQKE.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/tBHrZzLxCs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614805431454724101",
    "text" : "http:\/\/t.co\/tBHrZzLxCs",
    "id" : 614805431454724101,
    "created_at" : "2015-06-27 14:40:12 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 614805954983514112,
  "created_at" : "2015-06-27 14:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krystle J",
      "screen_name" : "Iacoguy",
      "indices" : [ 3, 11 ],
      "id_str" : "214100900",
      "id" : 214100900
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Iacoguy\/status\/614605749214277632\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/xCBXjFrXnV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIeEq_PUsAAF7H8.jpg",
      "id_str" : "614605748224438272",
      "id" : 614605748224438272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIeEq_PUsAAF7H8.jpg",
      "sizes" : [ {
        "h" : 499,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 654
      } ],
      "display_url" : "pic.twitter.com\/xCBXjFrXnV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614613323812839425",
  "text" : "RT @Iacoguy: I watched it happen. http:\/\/t.co\/xCBXjFrXnV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Iacoguy\/status\/614605749214277632\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/xCBXjFrXnV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIeEq_PUsAAF7H8.jpg",
        "id_str" : "614605748224438272",
        "id" : 614605748224438272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIeEq_PUsAAF7H8.jpg",
        "sizes" : [ {
          "h" : 499,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 499,
          "resize" : "fit",
          "w" : 654
        } ],
        "display_url" : "pic.twitter.com\/xCBXjFrXnV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614605749214277632",
    "text" : "I watched it happen. http:\/\/t.co\/xCBXjFrXnV",
    "id" : 614605749214277632,
    "created_at" : "2015-06-27 01:26:44 +0000",
    "user" : {
      "name" : "Krystle J",
      "screen_name" : "Iacoguy",
      "protected" : false,
      "id_str" : "214100900",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797803450407014400\/7nFnkbOc_normal.jpg",
      "id" : 214100900,
      "verified" : false
    }
  },
  "id" : 614613323812839425,
  "created_at" : "2015-06-27 01:56:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/SE0R6OSB7y",
      "expanded_url" : "https:\/\/twitter.com\/brittbrat_b\/status\/614586961110675456",
      "display_url" : "twitter.com\/brittbrat_b\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614611743168425984",
  "text" : "RT @MotivateSean: The backs of African Americans and slaughter of Natives.  https:\/\/t.co\/SE0R6OSB7y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/SE0R6OSB7y",
        "expanded_url" : "https:\/\/twitter.com\/brittbrat_b\/status\/614586961110675456",
        "display_url" : "twitter.com\/brittbrat_b\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614596900621168640",
    "text" : "The backs of African Americans and slaughter of Natives.  https:\/\/t.co\/SE0R6OSB7y",
    "id" : 614596900621168640,
    "created_at" : "2015-06-27 00:51:34 +0000",
    "user" : {
      "name" : "(dr-ix)",
      "screen_name" : "iamdryx",
      "protected" : false,
      "id_str" : "135765344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797458089171623936\/_8yBUi24_normal.jpg",
      "id" : 135765344,
      "verified" : false
    }
  },
  "id" : 614611743168425984,
  "created_at" : "2015-06-27 01:50:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klara Gibson",
      "screen_name" : "artbyklara",
      "indices" : [ 3, 14 ],
      "id_str" : "2861330135",
      "id" : 2861330135
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/artbyklara\/status\/614550162103476224\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/dopB1qBLWi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdSHDZWwAAW7hC.jpg",
      "id_str" : "614550155283578880",
      "id" : 614550155283578880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdSHDZWwAAW7hC.jpg",
      "sizes" : [ {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/dopB1qBLWi"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614611177675595777",
  "text" : "RT @artbyklara: Celebrating this special day by posting my first digital drawing ever! :) #LoveWins http:\/\/t.co\/dopB1qBLWi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/artbyklara\/status\/614550162103476224\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/dopB1qBLWi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdSHDZWwAAW7hC.jpg",
        "id_str" : "614550155283578880",
        "id" : 614550155283578880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdSHDZWwAAW7hC.jpg",
        "sizes" : [ {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/dopB1qBLWi"
      } ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614550162103476224",
    "text" : "Celebrating this special day by posting my first digital drawing ever! :) #LoveWins http:\/\/t.co\/dopB1qBLWi",
    "id" : 614550162103476224,
    "created_at" : "2015-06-26 21:45:51 +0000",
    "user" : {
      "name" : "Klara Gibson",
      "screen_name" : "artbyklara",
      "protected" : false,
      "id_str" : "2861330135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799485987747459072\/nrqc3kka_normal.jpg",
      "id" : 2861330135,
      "verified" : false
    }
  },
  "id" : 614611177675595777,
  "created_at" : "2015-06-27 01:48:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614610954421186560",
  "text" : "RT @TheChristianLft: Currently six corporations control roughly 90% of the media in the United States. Bottom Line: The media can't be... h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/SVQfLQRx3B",
        "expanded_url" : "http:\/\/fb.me\/6CmMAa5yU",
        "display_url" : "fb.me\/6CmMAa5yU"
      } ]
    },
    "geo" : { },
    "id_str" : "614608453827432448",
    "text" : "Currently six corporations control roughly 90% of the media in the United States. Bottom Line: The media can't be... http:\/\/t.co\/SVQfLQRx3B",
    "id" : 614608453827432448,
    "created_at" : "2015-06-27 01:37:28 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 614610954421186560,
  "created_at" : "2015-06-27 01:47:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Aunties",
      "screen_name" : "whaeapower",
      "indices" : [ 3, 14 ],
      "id_str" : "1483921698",
      "id" : 1483921698
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whaeapower\/status\/614586826095919104\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/rOCt1ngbpG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdzdkgVAAABNkv.jpg",
      "id_str" : "614586826012033024",
      "id" : 614586826012033024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdzdkgVAAABNkv.jpg",
      "sizes" : [ {
        "h" : 509,
        "resize" : "fit",
        "w" : 603
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 603
      } ],
      "display_url" : "pic.twitter.com\/rOCt1ngbpG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614610911253413888",
  "text" : "RT @whaeapower: Be silly. Be kind. Be weird.\nThere's no time for anything else.\nIndeed. http:\/\/t.co\/rOCt1ngbpG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whaeapower\/status\/614586826095919104\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/rOCt1ngbpG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdzdkgVAAABNkv.jpg",
        "id_str" : "614586826012033024",
        "id" : 614586826012033024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdzdkgVAAABNkv.jpg",
        "sizes" : [ {
          "h" : 509,
          "resize" : "fit",
          "w" : 603
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 603
        } ],
        "display_url" : "pic.twitter.com\/rOCt1ngbpG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614586826095919104",
    "text" : "Be silly. Be kind. Be weird.\nThere's no time for anything else.\nIndeed. http:\/\/t.co\/rOCt1ngbpG",
    "id" : 614586826095919104,
    "created_at" : "2015-06-27 00:11:32 +0000",
    "user" : {
      "name" : "The Aunties",
      "screen_name" : "whaeapower",
      "protected" : false,
      "id_str" : "1483921698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767958114209378305\/tPPQeLJx_normal.png",
      "id" : 1483921698,
      "verified" : false
    }
  },
  "id" : 614610911253413888,
  "created_at" : "2015-06-27 01:47:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614493987043442689",
  "text" : "RT @_NealeDWalsch: God is not a Super Being in the Sky, with the same emotional needs as human beings. God is life's Essential Energy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614493599946919936",
    "text" : "God is not a Super Being in the Sky, with the same emotional needs as human beings. God is life's Essential Energy.",
    "id" : 614493599946919936,
    "created_at" : "2015-06-26 18:01:05 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 614493987043442689,
  "created_at" : "2015-06-26 18:02:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "614461676751089668",
  "geo" : { },
  "id_str" : "614470065807826945",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves I think mercy and compassion are God's trademarks. You've got a big heart.",
  "id" : 614470065807826945,
  "in_reply_to_status_id" : 614461676751089668,
  "created_at" : "2015-06-26 16:27:34 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613945271509086208",
  "geo" : { },
  "id_str" : "614468791548944384",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves : ((",
  "id" : 614468791548944384,
  "in_reply_to_status_id" : 613945271509086208,
  "created_at" : "2015-06-26 16:22:30 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/513929178534531072\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/9rOs1LOfuv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByHX3WRCEAAHb5W.jpg",
      "id_str" : "513929178366742528",
      "id" : 513929178366742528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByHX3WRCEAAHb5W.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 406
      } ],
      "display_url" : "pic.twitter.com\/9rOs1LOfuv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614464438180151296",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/9rOs1LOfuv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/513929178534531072\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/9rOs1LOfuv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByHX3WRCEAAHb5W.jpg",
        "id_str" : "513929178366742528",
        "id" : 513929178366742528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByHX3WRCEAAHb5W.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 406
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 406
        } ],
        "display_url" : "pic.twitter.com\/9rOs1LOfuv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614460672773083136",
    "text" : "http:\/\/t.co\/9rOs1LOfuv",
    "id" : 614460672773083136,
    "created_at" : "2015-06-26 15:50:15 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 614464438180151296,
  "created_at" : "2015-06-26 16:05:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Tolstoy",
      "screen_name" : "TolstoySays",
      "indices" : [ 3, 15 ],
      "id_str" : "382991619",
      "id" : 382991619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614464129013796864",
  "text" : "RT @TolstoySays: There\u2019s nothing worse than the pretense of kindness. Feigned kindness is more repulsive than honest hatred.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614459823074054144",
    "text" : "There\u2019s nothing worse than the pretense of kindness. Feigned kindness is more repulsive than honest hatred.",
    "id" : 614459823074054144,
    "created_at" : "2015-06-26 15:46:52 +0000",
    "user" : {
      "name" : "Leo Tolstoy",
      "screen_name" : "TolstoySays",
      "protected" : false,
      "id_str" : "382991619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1567369613\/uewb_10_img0685_normal.jpg",
      "id" : 382991619,
      "verified" : false
    }
  },
  "id" : 614464129013796864,
  "created_at" : "2015-06-26 16:03:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Love4Vibes\u2122",
      "screen_name" : "VibesMood",
      "indices" : [ 3, 13 ],
      "id_str" : "363189270",
      "id" : 363189270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614463674615525376",
  "text" : "RT @VibesMood: I really want to meet myself and see how i'm actually like from someone else's point of view",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614458361996705792",
    "text" : "I really want to meet myself and see how i'm actually like from someone else's point of view",
    "id" : 614458361996705792,
    "created_at" : "2015-06-26 15:41:04 +0000",
    "user" : {
      "name" : "Love4Vibes\u2122",
      "screen_name" : "VibesMood",
      "protected" : false,
      "id_str" : "363189270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721154203129806848\/HBiK22Jr_normal.jpg",
      "id" : 363189270,
      "verified" : false
    }
  },
  "id" : 614463674615525376,
  "created_at" : "2015-06-26 16:02:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "indices" : [ 3, 12 ],
      "id_str" : "8234572",
      "id" : 8234572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/ZW2pMA3MNY",
      "expanded_url" : "http:\/\/www.nytimes.com\/2015\/06\/27\/us\/supreme-court-same-sex-marriage.html?smid=tw-bna&_r=0",
      "display_url" : "nytimes.com\/2015\/06\/27\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614443137105313792",
  "text" : "RT @cantrell: The United States just took an enormously important step forward. http:\/\/t.co\/ZW2pMA3MNY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/ZW2pMA3MNY",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/06\/27\/us\/supreme-court-same-sex-marriage.html?smid=tw-bna&_r=0",
        "display_url" : "nytimes.com\/2015\/06\/27\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614434713638424576",
    "text" : "The United States just took an enormously important step forward. http:\/\/t.co\/ZW2pMA3MNY",
    "id" : 614434713638424576,
    "created_at" : "2015-06-26 14:07:06 +0000",
    "user" : {
      "name" : "Christian Cantrell",
      "screen_name" : "cantrell",
      "protected" : false,
      "id_str" : "8234572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3466700371\/ca68118063303c7fe19a3cf79e68a9f8_normal.jpeg",
      "id" : 8234572,
      "verified" : true
    }
  },
  "id" : 614443137105313792,
  "created_at" : "2015-06-26 14:40:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "indices" : [ 3, 12 ],
      "id_str" : "290187508",
      "id" : 290187508
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rjmedwed\/status\/614434727408332801\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Pm0fFOAP05",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbpIEkWwAAjoI0.png",
      "id_str" : "614434724057104384",
      "id" : 614434724057104384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbpIEkWwAAjoI0.png",
      "sizes" : [ {
        "h" : 91,
        "resize" : "fit",
        "w" : 271
      }, {
        "h" : 91,
        "resize" : "crop",
        "w" : 91
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 271
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 271
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 271
      } ],
      "display_url" : "pic.twitter.com\/Pm0fFOAP05"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614443074887000064",
  "text" : "RT @rjmedwed: Indeed. God bless us all, too. http:\/\/t.co\/Pm0fFOAP05",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rjmedwed\/status\/614434727408332801\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/Pm0fFOAP05",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbpIEkWwAAjoI0.png",
        "id_str" : "614434724057104384",
        "id" : 614434724057104384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbpIEkWwAAjoI0.png",
        "sizes" : [ {
          "h" : 91,
          "resize" : "fit",
          "w" : 271
        }, {
          "h" : 91,
          "resize" : "crop",
          "w" : 91
        }, {
          "h" : 91,
          "resize" : "fit",
          "w" : 271
        }, {
          "h" : 91,
          "resize" : "fit",
          "w" : 271
        }, {
          "h" : 91,
          "resize" : "fit",
          "w" : 271
        } ],
        "display_url" : "pic.twitter.com\/Pm0fFOAP05"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614434727408332801",
    "text" : "Indeed. God bless us all, too. http:\/\/t.co\/Pm0fFOAP05",
    "id" : 614434727408332801,
    "created_at" : "2015-06-26 14:07:09 +0000",
    "user" : {
      "name" : "Robbie Medwed",
      "screen_name" : "rjmedwed",
      "protected" : false,
      "id_str" : "290187508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793275006558101504\/yAxWgTTZ_normal.jpg",
      "id" : 290187508,
      "verified" : false
    }
  },
  "id" : 614443074887000064,
  "created_at" : "2015-06-26 14:40:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614442735928479744",
  "text" : "I have the chills and tears in my eyes.. History being made and I'm alive to see it.",
  "id" : 614442735928479744,
  "created_at" : "2015-06-26 14:38:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614441412235522048",
  "text" : "RT @CoryBooker: Today is about unconditional love &amp; hope\u2014between people, and for our country as a nation of equality and acceptance http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CoryBooker\/status\/614435083005612032\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/44kBc2Ncoy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbpZ4FWwAAlWva.jpg",
        "id_str" : "614435029943500800",
        "id" : 614435029943500800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbpZ4FWwAAlWva.jpg",
        "sizes" : [ {
          "h" : 1346,
          "resize" : "fit",
          "w" : 1346
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/44kBc2Ncoy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614435083005612032",
    "text" : "Today is about unconditional love &amp; hope\u2014between people, and for our country as a nation of equality and acceptance http:\/\/t.co\/44kBc2Ncoy",
    "id" : 614435083005612032,
    "created_at" : "2015-06-26 14:08:34 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 614441412235522048,
  "created_at" : "2015-06-26 14:33:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "Daniel Beerthuis \uD83D\uDC94",
      "screen_name" : "DanielBeerthuis",
      "indices" : [ 23, 39 ],
      "id_str" : "53309297",
      "id" : 53309297
    }, {
      "name" : "Freedom to Marry",
      "screen_name" : "freedomtomarry",
      "indices" : [ 85, 100 ],
      "id_str" : "14056708",
      "id" : 14056708
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DanielBeerthuis\/status\/614435594945589248\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/BGJmgX3hUZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbp6uPVAAEFGnS.png",
      "id_str" : "614435594236657665",
      "id" : 614435594236657665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbp6uPVAAEFGnS.png",
      "sizes" : [ {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/BGJmgX3hUZ"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "MarriageEquality",
      "indices" : [ 51, 68 ]
    }, {
      "text" : "SCOTUSMarriage",
      "indices" : [ 69, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614440141667594240",
  "text" : "RT @JamiaStarheart: RT @DanielBeerthuis: #LoveWins #MarriageEquality #SCOTUSMarriage @freedomtomarry http:\/\/t.co\/BGJmgX3hUZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Beerthuis \uD83D\uDC94",
        "screen_name" : "DanielBeerthuis",
        "indices" : [ 3, 19 ],
        "id_str" : "53309297",
        "id" : 53309297
      }, {
        "name" : "Freedom to Marry",
        "screen_name" : "freedomtomarry",
        "indices" : [ 65, 80 ],
        "id_str" : "14056708",
        "id" : 14056708
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DanielBeerthuis\/status\/614435594945589248\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/BGJmgX3hUZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbp6uPVAAEFGnS.png",
        "id_str" : "614435594236657665",
        "id" : 614435594236657665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbp6uPVAAEFGnS.png",
        "sizes" : [ {
          "h" : 535,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 627,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/BGJmgX3hUZ"
      } ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "MarriageEquality",
        "indices" : [ 31, 48 ]
      }, {
        "text" : "SCOTUSMarriage",
        "indices" : [ 49, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614435798935576576",
    "text" : "RT @DanielBeerthuis: #LoveWins #MarriageEquality #SCOTUSMarriage @freedomtomarry http:\/\/t.co\/BGJmgX3hUZ",
    "id" : 614435798935576576,
    "created_at" : "2015-06-26 14:11:24 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 614440141667594240,
  "created_at" : "2015-06-26 14:28:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aussie",
      "indices" : [ 116, 123 ]
    }, {
      "text" : "smart",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/zctoLspMRW",
      "expanded_url" : "http:\/\/po.st\/bxFPsl",
      "display_url" : "po.st\/bxFPsl"
    } ]
  },
  "geo" : { },
  "id_str" : "614226526414970880",
  "text" : "Mom Tells Baby To Say \u201CMama\u201D For A Bite Of Food, But The Hungry Dog Answers \u201CMama\u201D Instead!! http:\/\/t.co\/zctoLspMRW #aussie #smart",
  "id" : 614226526414970880,
  "created_at" : "2015-06-26 00:19:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CrueHead_4_Life\/status\/614205160869490688\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/yrB82mAplV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIYYVhZWgAQlfLp.jpg",
      "id_str" : "614205157203673092",
      "id" : 614205157203673092,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIYYVhZWgAQlfLp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/yrB82mAplV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614211599985979392",
  "text" : "RT @CrueHead_4_Life: http:\/\/t.co\/yrB82mAplV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CrueHead_4_Life\/status\/614205160869490688\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/yrB82mAplV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIYYVhZWgAQlfLp.jpg",
        "id_str" : "614205157203673092",
        "id" : 614205157203673092,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIYYVhZWgAQlfLp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/yrB82mAplV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614205160869490688",
    "text" : "http:\/\/t.co\/yrB82mAplV",
    "id" : 614205160869490688,
    "created_at" : "2015-06-25 22:54:56 +0000",
    "user" : {
      "name" : "\uD83D\uDCAFRated-R-Rockstar\uD83D\uDCAF",
      "screen_name" : "RatedRRockstar_",
      "protected" : false,
      "id_str" : "2611710445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789189636245495808\/tXLjYsXr_normal.jpg",
      "id" : 2611710445,
      "verified" : false
    }
  },
  "id" : 614211599985979392,
  "created_at" : "2015-06-25 23:20:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "sarahnmoon",
      "indices" : [ 3, 14 ],
      "id_str" : "748426543987318784",
      "id" : 748426543987318784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614210994370387968",
  "text" : "RT @sarahnmoon: Apparently in 2015 the year of our Lord it's controversial to say that a 25 year old adult can get pregnant and not be a \"d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614206953418567680",
    "text" : "Apparently in 2015 the year of our Lord it's controversial to say that a 25 year old adult can get pregnant and not be a \"disappointment\"",
    "id" : 614206953418567680,
    "created_at" : "2015-06-25 23:02:03 +0000",
    "user" : {
      "name" : "Sarah",
      "screen_name" : "GrumpyTheology",
      "protected" : true,
      "id_str" : "24254537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783823376938831872\/y8R_i-U-_normal.jpg",
      "id" : 24254537,
      "verified" : false
    }
  },
  "id" : 614210994370387968,
  "created_at" : "2015-06-25 23:18:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ProtectSacredGriz",
      "screen_name" : "alisonbuckley",
      "indices" : [ 3, 17 ],
      "id_str" : "69411258",
      "id" : 69411258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "universalHealthCare",
      "indices" : [ 42, 62 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 63, 75 ]
    }, {
      "text" : "MedicareforAll",
      "indices" : [ 76, 91 ]
    }, {
      "text" : "Bernie21016",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/pw3WopDugt",
      "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/614202452997468160",
      "display_url" : "twitter.com\/nytimes\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614210670956032001",
  "text" : "RT @alisonbuckley: Good. Now we need true #universalHealthCare #SinglePayer #MedicareforAll #Bernie21016 https:\/\/t.co\/pw3WopDugt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "universalHealthCare",
        "indices" : [ 23, 43 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 44, 56 ]
      }, {
        "text" : "MedicareforAll",
        "indices" : [ 57, 72 ]
      }, {
        "text" : "Bernie21016",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/pw3WopDugt",
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/614202452997468160",
        "display_url" : "twitter.com\/nytimes\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614202841108905985",
    "text" : "Good. Now we need true #universalHealthCare #SinglePayer #MedicareforAll #Bernie21016 https:\/\/t.co\/pw3WopDugt",
    "id" : 614202841108905985,
    "created_at" : "2015-06-25 22:45:43 +0000",
    "user" : {
      "name" : "#ProtectSacredGriz",
      "screen_name" : "alisonbuckley",
      "protected" : false,
      "id_str" : "69411258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781784216753156096\/GSd1m5bl_normal.jpg",
      "id" : 69411258,
      "verified" : false
    }
  },
  "id" : 614210670956032001,
  "created_at" : "2015-06-25 23:16:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 3, 19 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614210045274886144",
  "text" : "RT @fairlyspiritual: Every individual was formed by a community. From conception, to birth, to our earliest moments of life, we were formed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614208195767070720",
    "text" : "Every individual was formed by a community. From conception, to birth, to our earliest moments of life, we were formed by a the community.",
    "id" : 614208195767070720,
    "created_at" : "2015-06-25 23:06:59 +0000",
    "user" : {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "protected" : false,
      "id_str" : "24233147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791519966008791040\/L6NShhyf_normal.jpg",
      "id" : 24233147,
      "verified" : false
    }
  },
  "id" : 614210045274886144,
  "created_at" : "2015-06-25 23:14:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/parkstepp\/status\/614208500365946880\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/hS5RmFQncv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIYbTrkUAAAu8fs.jpg",
      "id_str" : "614208424109146112",
      "id" : 614208424109146112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIYbTrkUAAAu8fs.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/hS5RmFQncv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614209807533387776",
  "text" : "RT @parkstepp: Expand..Expand..Expand ... http:\/\/t.co\/hS5RmFQncv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/parkstepp\/status\/614208500365946880\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/hS5RmFQncv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIYbTrkUAAAu8fs.jpg",
        "id_str" : "614208424109146112",
        "id" : 614208424109146112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIYbTrkUAAAu8fs.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/hS5RmFQncv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614208500365946880",
    "text" : "Expand..Expand..Expand ... http:\/\/t.co\/hS5RmFQncv",
    "id" : 614208500365946880,
    "created_at" : "2015-06-25 23:08:12 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 614209807533387776,
  "created_at" : "2015-06-25 23:13:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "indices" : [ 3, 16 ],
      "id_str" : "1348108910",
      "id" : 1348108910
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/608153109957722112\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/odDR3Yas78",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHCYBljUkAAsB0T.jpg",
      "id_str" : "608153102722568192",
      "id" : 608153102722568192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHCYBljUkAAsB0T.jpg",
      "sizes" : [ {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/odDR3Yas78"
    } ],
    "hashtags" : [ {
      "text" : "PrinceRupert",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614167027809447936",
  "text" : "RT @ScarlettWulf: The Deer are Always a Lovely Welcome Home. They love sleeping &amp; eating in our Garden. #PrinceRupert http:\/\/t.co\/odDR3Yas78",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScarlettWulf\/status\/608153109957722112\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/odDR3Yas78",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHCYBljUkAAsB0T.jpg",
        "id_str" : "608153102722568192",
        "id" : 608153102722568192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHCYBljUkAAsB0T.jpg",
        "sizes" : [ {
          "h" : 696,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/odDR3Yas78"
      } ],
      "hashtags" : [ {
        "text" : "PrinceRupert",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608153109957722112",
    "text" : "The Deer are Always a Lovely Welcome Home. They love sleeping &amp; eating in our Garden. #PrinceRupert http:\/\/t.co\/odDR3Yas78",
    "id" : 608153109957722112,
    "created_at" : "2015-06-09 06:06:15 +0000",
    "user" : {
      "name" : "Tish Millard",
      "screen_name" : "ScarlettWulf",
      "protected" : false,
      "id_str" : "1348108910",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741919775668867072\/yzqHRx03_normal.jpg",
      "id" : 1348108910,
      "verified" : false
    }
  },
  "id" : 614167027809447936,
  "created_at" : "2015-06-25 20:23:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "feedly",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/rW9OPoY6s0",
      "expanded_url" : "http:\/\/the-digital-reader.com\/2015\/06\/25\/free-android-apps-25-june-monument-valley-plus-50-more-in-free-apps\/",
      "display_url" : "the-digital-reader.com\/2015\/06\/25\/fre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614141282601041921",
  "text" : "Free Android Apps (25 June):  Monument Valley, Plus $50 More in Free Apps http:\/\/t.co\/rW9OPoY6s0 #books #feedly",
  "id" : 614141282601041921,
  "created_at" : "2015-06-25 18:41:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "crystal 42 cat",
      "screen_name" : "42_crystal",
      "indices" : [ 3, 14 ],
      "id_str" : "2742218714",
      "id" : 2742218714
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/42_crystal\/status\/614098570661208064\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/U0Q1uD4oc2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIW3ZTSWEAAjlzE.jpg",
      "id_str" : "614098569507770368",
      "id" : 614098569507770368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIW3ZTSWEAAjlzE.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1970,
        "resize" : "fit",
        "w" : 2627
      } ],
      "display_url" : "pic.twitter.com\/U0Q1uD4oc2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614111528955060224",
  "text" : "RT @42_crystal: I think this jackdaw was finding the hot weather a bit too much :) http:\/\/t.co\/U0Q1uD4oc2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/42_crystal\/status\/614098570661208064\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/U0Q1uD4oc2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIW3ZTSWEAAjlzE.jpg",
        "id_str" : "614098569507770368",
        "id" : 614098569507770368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIW3ZTSWEAAjlzE.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1970,
          "resize" : "fit",
          "w" : 2627
        } ],
        "display_url" : "pic.twitter.com\/U0Q1uD4oc2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614098570661208064",
    "text" : "I think this jackdaw was finding the hot weather a bit too much :) http:\/\/t.co\/U0Q1uD4oc2",
    "id" : 614098570661208064,
    "created_at" : "2015-06-25 15:51:23 +0000",
    "user" : {
      "name" : "crystal 42 cat",
      "screen_name" : "42_crystal",
      "protected" : false,
      "id_str" : "2742218714",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513679230190620673\/7dnbGIBV_normal.jpeg",
      "id" : 2742218714,
      "verified" : false
    }
  },
  "id" : 614111528955060224,
  "created_at" : "2015-06-25 16:42:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Audiobooked",
      "screen_name" : "audiobooked",
      "indices" : [ 38, 50 ],
      "id_str" : "2797832461",
      "id" : 2797832461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614111419680858112",
  "text" : "Listening to The Sixth Extinction via @audiobooked .. Scary what's happening...",
  "id" : 614111419680858112,
  "created_at" : "2015-06-25 16:42:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tantor Audio",
      "screen_name" : "TantorAudio",
      "indices" : [ 3, 15 ],
      "id_str" : "36229151",
      "id" : 36229151
    }, {
      "name" : "Juliet Blackwell",
      "screen_name" : "JulietBlackwell",
      "indices" : [ 18, 34 ],
      "id_str" : "89701092",
      "id" : 89701092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WitchcraftMysteries",
      "indices" : [ 100, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614100773400616965",
  "text" : "RT @TantorAudio: .@JulietBlackwell is today's featured author! Stop by to win a free download from  #WitchcraftMysteries http:\/\/t.co\/ZoWp7l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juliet Blackwell",
        "screen_name" : "JulietBlackwell",
        "indices" : [ 1, 17 ],
        "id_str" : "89701092",
        "id" : 89701092
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WitchcraftMysteries",
        "indices" : [ 83, 103 ]
      }, {
        "text" : "audiomonth",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/ZoWp7lhsID",
        "expanded_url" : "http:\/\/on.fb.me\/1KeQoKL",
        "display_url" : "on.fb.me\/1KeQoKL"
      } ]
    },
    "geo" : { },
    "id_str" : "614095003124649984",
    "text" : ".@JulietBlackwell is today's featured author! Stop by to win a free download from  #WitchcraftMysteries http:\/\/t.co\/ZoWp7lhsID #audiomonth",
    "id" : 614095003124649984,
    "created_at" : "2015-06-25 15:37:12 +0000",
    "user" : {
      "name" : "Tantor Audio",
      "screen_name" : "TantorAudio",
      "protected" : false,
      "id_str" : "36229151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2364777444\/b78ebmeq2b2b5vx8uvwd_normal.png",
      "id" : 36229151,
      "verified" : false
    }
  },
  "id" : 614100773400616965,
  "created_at" : "2015-06-25 16:00:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Defreitas",
      "screen_name" : "alisondefreitas",
      "indices" : [ 3, 19 ],
      "id_str" : "117746792",
      "id" : 117746792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/2rA034c7z9",
      "expanded_url" : "http:\/\/thkpr.gs\/3672303",
      "display_url" : "thkpr.gs\/3672303"
    } ]
  },
  "geo" : { },
  "id_str" : "614076330305540097",
  "text" : "RT @alisondefreitas: BREAKING: Supreme Court Will Not Take Away Health Care From Millions Of Americans http:\/\/t.co\/2rA034c7z9 via @thinkpro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 109, 123 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/2rA034c7z9",
        "expanded_url" : "http:\/\/thkpr.gs\/3672303",
        "display_url" : "thkpr.gs\/3672303"
      } ]
    },
    "geo" : { },
    "id_str" : "614074991110451201",
    "text" : "BREAKING: Supreme Court Will Not Take Away Health Care From Millions Of Americans http:\/\/t.co\/2rA034c7z9 via @thinkprogress",
    "id" : 614074991110451201,
    "created_at" : "2015-06-25 14:17:41 +0000",
    "user" : {
      "name" : "Alison Defreitas",
      "screen_name" : "alisondefreitas",
      "protected" : false,
      "id_str" : "117746792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747881643734630401\/ZjaOJAF-_normal.jpg",
      "id" : 117746792,
      "verified" : false
    }
  },
  "id" : 614076330305540097,
  "created_at" : "2015-06-25 14:23:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mother Jones",
      "screen_name" : "MotherJones",
      "indices" : [ 93, 105 ],
      "id_str" : "18510860",
      "id" : 18510860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/dCqu4tzNXF",
      "expanded_url" : "http:\/\/www.motherjones.com\/politics\/2015\/06\/bobby-jindal-zack-kopplin-evolution",
      "display_url" : "motherjones.com\/politics\/2015\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614075199428927488",
  "text" : "The 21-year-old college kid who has made Bobby Jindal's life hell http:\/\/t.co\/dCqu4tzNXF via @MotherJones",
  "id" : 614075199428927488,
  "created_at" : "2015-06-25 14:18:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rockcoder Apps",
      "screen_name" : "RockcoderApps",
      "indices" : [ 0, 14 ],
      "id_str" : "2421108704",
      "id" : 2421108704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613807238508101632",
  "geo" : { },
  "id_str" : "613817633583009793",
  "in_reply_to_user_id" : 2421108704,
  "text" : "@RockcoderApps this didn't work, either...",
  "id" : 613817633583009793,
  "in_reply_to_status_id" : 613807238508101632,
  "created_at" : "2015-06-24 21:15:02 +0000",
  "in_reply_to_screen_name" : "RockcoderApps",
  "in_reply_to_user_id_str" : "2421108704",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rockcoder Apps",
      "screen_name" : "RockcoderApps",
      "indices" : [ 0, 14 ],
      "id_str" : "2421108704",
      "id" : 2421108704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613806150191063040",
  "geo" : { },
  "id_str" : "613817433883807744",
  "in_reply_to_user_id" : 2421108704,
  "text" : "@RockcoderApps it says something went wrong, check location enabled, try again later. lumia 1520, wp8.1, no sim, wifi on.",
  "id" : 613817433883807744,
  "in_reply_to_status_id" : 613806150191063040,
  "created_at" : "2015-06-24 21:14:15 +0000",
  "in_reply_to_screen_name" : "RockcoderApps",
  "in_reply_to_user_id_str" : "2421108704",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rockcoder Apps",
      "screen_name" : "RockcoderApps",
      "indices" : [ 0, 14 ],
      "id_str" : "2421108704",
      "id" : 2421108704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613641636237737984",
  "geo" : { },
  "id_str" : "613783999908040708",
  "in_reply_to_user_id" : 2421108704,
  "text" : "@RockcoderApps I have location services enabled but keep getting error message. Maybe doesn't work without sim card.",
  "id" : 613783999908040708,
  "in_reply_to_status_id" : 613641636237737984,
  "created_at" : "2015-06-24 19:01:23 +0000",
  "in_reply_to_screen_name" : "RockcoderApps",
  "in_reply_to_user_id_str" : "2421108704",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 0, 14 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613762630940000256",
  "geo" : { },
  "id_str" : "613767807365435393",
  "in_reply_to_user_id" : 2191061814,
  "text" : "@Irish_Atheist ((highfive)) that made me chuckle : )",
  "id" : 613767807365435393,
  "in_reply_to_status_id" : 613762630940000256,
  "created_at" : "2015-06-24 17:57:03 +0000",
  "in_reply_to_screen_name" : "Irish_Atheist",
  "in_reply_to_user_id_str" : "2191061814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613767489273655296",
  "text" : "RT @Irish_Atheist: I believe khaki shorts with black socks are unnatural, but I'm not calling for a constitutional ban. https:\/\/t.co\/S0DvTV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/S0DvTVPHv5",
        "expanded_url" : "https:\/\/twitter.com\/anti_poon\/status\/610015375699243008",
        "display_url" : "twitter.com\/anti_poon\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613762630940000256",
    "text" : "I believe khaki shorts with black socks are unnatural, but I'm not calling for a constitutional ban. https:\/\/t.co\/S0DvTVPHv5",
    "id" : 613762630940000256,
    "created_at" : "2015-06-24 17:36:29 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 613767489273655296,
  "created_at" : "2015-06-24 17:55:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K.B. Spangler",
      "screen_name" : "KBSpangler",
      "indices" : [ 3, 14 ],
      "id_str" : "991943287",
      "id" : 991943287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613524269142810624",
  "text" : "RT @KBSpangler: Dog: HURTS\nMe: Oh no, what did you eat?\nDog: BEE\nMe: What have I said about eating bees?\nDog: DON'T\nME: Then why did you ea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612969318444195840",
    "text" : "Dog: HURTS\nMe: Oh no, what did you eat?\nDog: BEE\nMe: What have I said about eating bees?\nDog: DON'T\nME: Then why did you eat it?\nDog: BEE!!!",
    "id" : 612969318444195840,
    "created_at" : "2015-06-22 13:04:08 +0000",
    "user" : {
      "name" : "K.B. Spangler",
      "screen_name" : "KBSpangler",
      "protected" : false,
      "id_str" : "991943287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518224323555778561\/jiqCh_ir_normal.jpeg",
      "id" : 991943287,
      "verified" : false
    }
  },
  "id" : 613524269142810624,
  "created_at" : "2015-06-24 01:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "\u041A\u0430\u0442\u044E\u0448\u0430 \u0410\u043D\u0433\u0435\u043B",
      "screen_name" : "Tomthunkit",
      "indices" : [ 23, 34 ],
      "id_str" : "2371889310",
      "id" : 2371889310
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Tomthunkit\/status\/613434872087117828\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/0DWZoT5s3K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CINbw9RUAAAkYaL.png",
      "id_str" : "613434870891544576",
      "id" : 613434870891544576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINbw9RUAAAkYaL.png",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 174,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/0DWZoT5s3K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613438876586278912",
  "text" : "RT @JamiaStarheart: RT @Tomthunkit: Go Back. http:\/\/t.co\/0DWZoT5s3K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u041A\u0430\u0442\u044E\u0448\u0430 \u0410\u043D\u0433\u0435\u043B",
        "screen_name" : "Tomthunkit",
        "indices" : [ 3, 14 ],
        "id_str" : "2371889310",
        "id" : 2371889310
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Tomthunkit\/status\/613434872087117828\/photo\/1",
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/0DWZoT5s3K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CINbw9RUAAAkYaL.png",
        "id_str" : "613434870891544576",
        "id" : 613434870891544576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINbw9RUAAAkYaL.png",
        "sizes" : [ {
          "h" : 306,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/0DWZoT5s3K"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613435335066918912",
    "text" : "RT @Tomthunkit: Go Back. http:\/\/t.co\/0DWZoT5s3K",
    "id" : 613435335066918912,
    "created_at" : "2015-06-23 19:55:55 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 613438876586278912,
  "created_at" : "2015-06-23 20:09:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "indices" : [ 3, 19 ],
      "id_str" : "111095506",
      "id" : 111095506
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheCartel",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613438510897451008",
  "text" : "RT @BlackstoneAudio: We're giving away a download of #TheCartel audiobook! Reply to enter! We'll notify a winner tomorrow morning! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BlackstoneAudio\/status\/613435370911305728\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/JPhsJuffeM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CINb2gvWUAAj02t.jpg",
        "id_str" : "613434966312112128",
        "id" : 613434966312112128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINb2gvWUAAj02t.jpg",
        "sizes" : [ {
          "h" : 2400,
          "resize" : "fit",
          "w" : 2400
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JPhsJuffeM"
      } ],
      "hashtags" : [ {
        "text" : "TheCartel",
        "indices" : [ 32, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613435370911305728",
    "text" : "We're giving away a download of #TheCartel audiobook! Reply to enter! We'll notify a winner tomorrow morning! http:\/\/t.co\/JPhsJuffeM",
    "id" : 613435370911305728,
    "created_at" : "2015-06-23 19:56:04 +0000",
    "user" : {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "protected" : false,
      "id_str" : "111095506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556139629351403520\/J5Y-trdL_normal.jpeg",
      "id" : 111095506,
      "verified" : false
    }
  },
  "id" : 613438510897451008,
  "created_at" : "2015-06-23 20:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blackstone",
      "screen_name" : "BlackstoneAudio",
      "indices" : [ 0, 16 ],
      "id_str" : "111095506",
      "id" : 111095506
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613435370911305728",
  "geo" : { },
  "id_str" : "613438464747565056",
  "in_reply_to_user_id" : 111095506,
  "text" : "@BlackstoneAudio sounds interesting!",
  "id" : 613438464747565056,
  "in_reply_to_status_id" : 613435370911305728,
  "created_at" : "2015-06-23 20:08:21 +0000",
  "in_reply_to_screen_name" : "BlackstoneAudio",
  "in_reply_to_user_id_str" : "111095506",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613419537267060736",
  "text" : "feeling hopeful. reading #thyroid threads and finding ppl w varying numbers and symptoms. stick w my gut feeling re: DD",
  "id" : 613419537267060736,
  "created_at" : "2015-06-23 18:53:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613157810008944640",
  "geo" : { },
  "id_str" : "613159268284559360",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous 42",
  "id" : 613159268284559360,
  "in_reply_to_status_id" : 613157810008944640,
  "created_at" : "2015-06-23 01:38:56 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613143164153688064",
  "geo" : { },
  "id_str" : "613154357064896512",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ohh jeezus.. did someone curse you? damn. : (( ((hugs))",
  "id" : 613154357064896512,
  "in_reply_to_status_id" : 613143164153688064,
  "created_at" : "2015-06-23 01:19:25 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "symptom",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613126963490856960",
  "text" : "she's not been right since may 7. shower spray feels weird. noises too loud. heat intolerance. sensations out of whack. #symptom",
  "id" : 613126963490856960,
  "created_at" : "2015-06-22 23:30:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "symptom",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613126369489342464",
  "text" : "now I get why she wanted her head xrayed.. blurred vision, could see light, color but no details. lost sense of up and down. #symptom",
  "id" : 613126369489342464,
  "created_at" : "2015-06-22 23:28:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "613046019735969792",
  "geo" : { },
  "id_str" : "613087385111412736",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ugh... : (((",
  "id" : 613087385111412736,
  "in_reply_to_status_id" : 613046019735969792,
  "created_at" : "2015-06-22 20:53:17 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "indices" : [ 3, 17 ],
      "id_str" : "2882327230",
      "id" : 2882327230
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/612939556392947712\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/rcKWA91lQ2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIGZRcbXAAEBHlW.jpg",
      "id_str" : "612939549266870273",
      "id" : 612939549266870273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIGZRcbXAAEBHlW.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 746,
        "resize" : "fit",
        "w" : 1120
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rcKWA91lQ2"
    } ],
    "hashtags" : [ {
      "text" : "MrsBlackbird",
      "indices" : [ 36, 49 ]
    }, {
      "text" : "HydePark",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "London",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613079308685459457",
  "text" : "RT @missmuckyduck: Strike the pose.\n#MrsBlackbird #HydePark #London http:\/\/t.co\/rcKWA91lQ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/missmuckyduck\/status\/612939556392947712\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/rcKWA91lQ2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIGZRcbXAAEBHlW.jpg",
        "id_str" : "612939549266870273",
        "id" : 612939549266870273,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIGZRcbXAAEBHlW.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 1120
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rcKWA91lQ2"
      } ],
      "hashtags" : [ {
        "text" : "MrsBlackbird",
        "indices" : [ 17, 30 ]
      }, {
        "text" : "HydePark",
        "indices" : [ 31, 40 ]
      }, {
        "text" : "London",
        "indices" : [ 41, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612939556392947712",
    "text" : "Strike the pose.\n#MrsBlackbird #HydePark #London http:\/\/t.co\/rcKWA91lQ2",
    "id" : 612939556392947712,
    "created_at" : "2015-06-22 11:05:52 +0000",
    "user" : {
      "name" : "LAURA",
      "screen_name" : "missmuckyduck",
      "protected" : false,
      "id_str" : "2882327230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798429096971792385\/pd6Q4U5r_normal.jpg",
      "id" : 2882327230,
      "verified" : false
    }
  },
  "id" : 613079308685459457,
  "created_at" : "2015-06-22 20:21:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612785534738558977",
  "text" : "RT @JeremyCShipp: Maybe we're all a bunch of raccoons in an overcoat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612781745386033152",
    "text" : "Maybe we're all a bunch of raccoons in an overcoat.",
    "id" : 612781745386033152,
    "created_at" : "2015-06-22 00:38:47 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 612785534738558977,
  "created_at" : "2015-06-22 00:53:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walt, Sock's & Snoop",
      "screen_name" : "walthollick",
      "indices" : [ 3, 15 ],
      "id_str" : "340547450",
      "id" : 340547450
    }, {
      "name" : "CelebrationOfDogs",
      "screen_name" : "dogcelebration",
      "indices" : [ 76, 91 ],
      "id_str" : "1273396333",
      "id" : 1273396333
    }, {
      "name" : "DogDose.com",
      "screen_name" : "DogDoseDotCom",
      "indices" : [ 92, 106 ],
      "id_str" : "2393785369",
      "id" : 2393785369
    }, {
      "name" : "Dog Confessions",
      "screen_name" : "DoggyFessions",
      "indices" : [ 107, 121 ],
      "id_str" : "2864432945",
      "id" : 2864432945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612680994664128512",
  "text" : "RT @walthollick: \"It's a long way down there, will u climb down if we fall\" @dogcelebration @DogDoseDotCom @DoggyFessions http:\/\/t.co\/BAcjT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CelebrationOfDogs",
        "screen_name" : "dogcelebration",
        "indices" : [ 59, 74 ],
        "id_str" : "1273396333",
        "id" : 1273396333
      }, {
        "name" : "DogDose.com",
        "screen_name" : "DogDoseDotCom",
        "indices" : [ 75, 89 ],
        "id_str" : "2393785369",
        "id" : 2393785369
      }, {
        "name" : "Dog Confessions",
        "screen_name" : "DoggyFessions",
        "indices" : [ 90, 104 ],
        "id_str" : "2864432945",
        "id" : 2864432945
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/walthollick\/status\/612677543511097344\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/BAcjTx6Xus",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CICq9ZPXAAEFKCY.jpg",
        "id_str" : "612677521046437889",
        "id" : 612677521046437889,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CICq9ZPXAAEFKCY.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/BAcjTx6Xus"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612677543511097344",
    "text" : "\"It's a long way down there, will u climb down if we fall\" @dogcelebration @DogDoseDotCom @DoggyFessions http:\/\/t.co\/BAcjTx6Xus",
    "id" : 612677543511097344,
    "created_at" : "2015-06-21 17:44:44 +0000",
    "user" : {
      "name" : "Walt, Sock's & Snoop",
      "screen_name" : "walthollick",
      "protected" : false,
      "id_str" : "340547450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782160826530693120\/CFPbB5Mo_normal.jpg",
      "id" : 340547450,
      "verified" : false
    }
  },
  "id" : 612680994664128512,
  "created_at" : "2015-06-21 17:58:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 13, 25 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612679085941223424",
  "geo" : { },
  "id_str" : "612680467016495105",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley @newlandfarm love her!",
  "id" : 612680467016495105,
  "in_reply_to_status_id" : 612679085941223424,
  "created_at" : "2015-06-21 17:56:21 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 47, 59 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/612679085941223424\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/MjBPJ9azTw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CICsX6QWwAEZ8cq.jpg",
      "id_str" : "612679076097212417",
      "id" : 612679076097212417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CICsX6QWwAEZ8cq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MjBPJ9azTw"
    } ],
    "hashtags" : [ {
      "text" : "RiggitGalloway",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "yearofmaking",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612680218671742976",
  "text" : "RT @ErinEFarley: Lady H is done! My version of @newlandfarm's beautiful #RiggitGalloway. #yearofmaking http:\/\/t.co\/MjBPJ9azTw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Newland Farm",
        "screen_name" : "newlandfarm",
        "indices" : [ 30, 42 ],
        "id_str" : "2259182801",
        "id" : 2259182801
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/612679085941223424\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/MjBPJ9azTw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CICsX6QWwAEZ8cq.jpg",
        "id_str" : "612679076097212417",
        "id" : 612679076097212417,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CICsX6QWwAEZ8cq.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MjBPJ9azTw"
      } ],
      "hashtags" : [ {
        "text" : "RiggitGalloway",
        "indices" : [ 55, 70 ]
      }, {
        "text" : "yearofmaking",
        "indices" : [ 72, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612679085941223424",
    "text" : "Lady H is done! My version of @newlandfarm's beautiful #RiggitGalloway. #yearofmaking http:\/\/t.co\/MjBPJ9azTw",
    "id" : 612679085941223424,
    "created_at" : "2015-06-21 17:50:51 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 612680218671742976,
  "created_at" : "2015-06-21 17:55:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612647644301795328",
  "text" : "now DH is upset over my family's issues.. ugh.",
  "id" : 612647644301795328,
  "created_at" : "2015-06-21 15:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612647248548261888",
  "text" : "DD may be 20 but she's my kid and her well being comes first. some ppl dont understand. she may not be dying but she feels crappy.",
  "id" : 612647248548261888,
  "created_at" : "2015-06-21 15:44:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612646843655262208",
  "text" : "i cant handle stress. i need to stick to my guns when i \"know\" and not be pressured to do something trying to be nice.",
  "id" : 612646843655262208,
  "created_at" : "2015-06-21 15:42:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612373021622444032",
  "geo" : { },
  "id_str" : "612375009605079040",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides hahaha .. and .. ew.",
  "id" : 612375009605079040,
  "in_reply_to_status_id" : 612373021622444032,
  "created_at" : "2015-06-20 21:42:34 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612374558520274944",
  "text" : "RT @SciencePorn: In 1977 we received a radio signal from space that lasted 72 seconds. To this day, we still don\u2019t know where it came from.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612366848127012864",
    "text" : "In 1977 we received a radio signal from space that lasted 72 seconds. To this day, we still don\u2019t know where it came from.",
    "id" : 612366848127012864,
    "created_at" : "2015-06-20 21:10:08 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 612374558520274944,
  "created_at" : "2015-06-20 21:40:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612374429834809345",
  "text" : "RT @bunnybuddhism: Our greatest hops are not always the ones we had prepared.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612367099785289728",
    "text" : "Our greatest hops are not always the ones we had prepared.",
    "id" : 612367099785289728,
    "created_at" : "2015-06-20 21:11:08 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 612374429834809345,
  "created_at" : "2015-06-20 21:40:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feathers",
      "screen_name" : "FeathersBirding",
      "indices" : [ 3, 19 ],
      "id_str" : "2361363194",
      "id" : 2361363194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612374134002159616",
  "text" : "RT @FeathersBirding: The baby Blue Tits are peeping out of the nest hole in the Oast House now, won't be long before they fledge! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FeathersBirding\/status\/606456147734851585\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/6w2egEpVsk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGqQpvsXIAAzGac.jpg",
        "id_str" : "606456146686320640",
        "id" : 606456146686320640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGqQpvsXIAAzGac.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6w2egEpVsk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606456147734851585",
    "text" : "The baby Blue Tits are peeping out of the nest hole in the Oast House now, won't be long before they fledge! http:\/\/t.co\/6w2egEpVsk",
    "id" : 606456147734851585,
    "created_at" : "2015-06-04 13:43:07 +0000",
    "user" : {
      "name" : "Feathers",
      "screen_name" : "FeathersBirding",
      "protected" : false,
      "id_str" : "2361363194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517605352817176576\/pTxE5uc5_normal.jpeg",
      "id" : 2361363194,
      "verified" : false
    }
  },
  "id" : 612374134002159616,
  "created_at" : "2015-06-20 21:39:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/529608481180254208\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/YxKvNBsbeG",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B1mMGpKIYAACArX.png",
      "id_str" : "529608476948193280",
      "id" : 529608476948193280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B1mMGpKIYAACArX.png",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YxKvNBsbeG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612372781792161792",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/YxKvNBsbeG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/529608481180254208\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/YxKvNBsbeG",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B1mMGpKIYAACArX.png",
        "id_str" : "529608476948193280",
        "id" : 529608476948193280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B1mMGpKIYAACArX.png",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YxKvNBsbeG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612371893270781952",
    "text" : "http:\/\/t.co\/YxKvNBsbeG",
    "id" : 612371893270781952,
    "created_at" : "2015-06-20 21:30:11 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 612372781792161792,
  "created_at" : "2015-06-20 21:33:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihaveemptyheart",
      "indices" : [ 10, 26 ]
    }, {
      "text" : "dontplacateme",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/1M5FLkxdiP",
      "expanded_url" : "https:\/\/twitter.com\/Pontifex\/status\/611755312693915649",
      "display_url" : "twitter.com\/Pontifex\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612372510173208576",
  "text" : "((groan)) #ihaveemptyheart #dontplacateme https:\/\/t.co\/1M5FLkxdiP",
  "id" : 612372510173208576,
  "created_at" : "2015-06-20 21:32:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612371864095182848",
  "text" : "i dont like this iron forged through fire bit.. bleh. i dont want to grow or be responsible. God, just annihilate me now.",
  "id" : 612371864095182848,
  "created_at" : "2015-06-20 21:30:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/4DViT92Jr9",
      "expanded_url" : "http:\/\/tl.gd\/nk308s",
      "display_url" : "tl.gd\/nk308s"
    } ]
  },
  "geo" : { },
  "id_str" : "612063994636042244",
  "text" : "RT @Floridaline: \"If God is omnipotent, by definition he can't be harmed. He is therefore punishing his (cont) http:\/\/t.co\/4DViT92Jr9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/4DViT92Jr9",
        "expanded_url" : "http:\/\/tl.gd\/nk308s",
        "display_url" : "tl.gd\/nk308s"
      } ]
    },
    "geo" : { },
    "id_str" : "612058209340272641",
    "text" : "\"If God is omnipotent, by definition he can't be harmed. He is therefore punishing his (cont) http:\/\/t.co\/4DViT92Jr9",
    "id" : 612058209340272641,
    "created_at" : "2015-06-20 00:43:43 +0000",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 612063994636042244,
  "created_at" : "2015-06-20 01:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prasanna",
      "screen_name" : "PrasannaBidkar",
      "indices" : [ 3, 18 ],
      "id_str" : "417862287",
      "id" : 417862287
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "kindlenotes",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/c6KsvwqYAD",
      "expanded_url" : "http:\/\/wp.me\/p4EsQ9-1jz",
      "display_url" : "wp.me\/p4EsQ9-1jz"
    } ]
  },
  "geo" : { },
  "id_str" : "612061782044225536",
  "text" : "RT @PrasannaBidkar: Exporting Kindle Notes http:\/\/t.co\/c6KsvwqYAD  #kindle #kindlenotes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 47, 54 ]
      }, {
        "text" : "kindlenotes",
        "indices" : [ 55, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/c6KsvwqYAD",
        "expanded_url" : "http:\/\/wp.me\/p4EsQ9-1jz",
        "display_url" : "wp.me\/p4EsQ9-1jz"
      } ]
    },
    "geo" : { },
    "id_str" : "612018397258186752",
    "text" : "Exporting Kindle Notes http:\/\/t.co\/c6KsvwqYAD  #kindle #kindlenotes",
    "id" : 612018397258186752,
    "created_at" : "2015-06-19 22:05:31 +0000",
    "user" : {
      "name" : "Prasanna",
      "screen_name" : "PrasannaBidkar",
      "protected" : false,
      "id_str" : "417862287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704172378377465856\/yXBCbuME_normal.jpg",
      "id" : 417862287,
      "verified" : false
    }
  },
  "id" : 612061782044225536,
  "created_at" : "2015-06-20 00:57:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Farmer",
      "screen_name" : "A_Farmer",
      "indices" : [ 3, 12 ],
      "id_str" : "27647174",
      "id" : 27647174
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/A_Farmer\/status\/611544708364505088\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/xI0SIBKp7N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHykrAqWUAEKP1v.png",
      "id_str" : "611544708234498049",
      "id" : 611544708234498049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHykrAqWUAEKP1v.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xI0SIBKp7N"
    } ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612061366774538240",
  "text" : "RT @A_Farmer: A reminder from my #Kindle notes. http:\/\/t.co\/xI0SIBKp7N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/A_Farmer\/status\/611544708364505088\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/xI0SIBKp7N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHykrAqWUAEKP1v.png",
        "id_str" : "611544708234498049",
        "id" : 611544708234498049,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHykrAqWUAEKP1v.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xI0SIBKp7N"
      } ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 19, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611544708364505088",
    "text" : "A reminder from my #Kindle notes. http:\/\/t.co\/xI0SIBKp7N",
    "id" : 611544708364505088,
    "created_at" : "2015-06-18 14:43:15 +0000",
    "user" : {
      "name" : "Adam Farmer",
      "screen_name" : "A_Farmer",
      "protected" : false,
      "id_str" : "27647174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3765291143\/b8a51f128a911012f1ca4dd8e064831c_normal.jpeg",
      "id" : 27647174,
      "verified" : false
    }
  },
  "id" : 612061366774538240,
  "created_at" : "2015-06-20 00:56:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "indices" : [ 3, 14 ],
      "id_str" : "2236808551",
      "id" : 2236808551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "rabbits",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "animals",
      "indices" : [ 106, 114 ]
    }, {
      "text" : "canon",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611694689641701376",
  "text" : "RT @JenLRPhoto: Caught this cute little dude sneaking around yesterday :) #photography #rabbits #wildlife #animals #canon http:\/\/t.co\/POTyW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JenLRPhoto\/status\/608341806317772801\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/POTyWSx7kq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHFDnLWWcAAJigF.jpg",
        "id_str" : "608341765012221952",
        "id" : 608341765012221952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHFDnLWWcAAJigF.jpg",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 437,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 746,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/POTyWSx7kq"
      } ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 58, 70 ]
      }, {
        "text" : "rabbits",
        "indices" : [ 71, 79 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 80, 89 ]
      }, {
        "text" : "animals",
        "indices" : [ 90, 98 ]
      }, {
        "text" : "canon",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608341806317772801",
    "text" : "Caught this cute little dude sneaking around yesterday :) #photography #rabbits #wildlife #animals #canon http:\/\/t.co\/POTyWSx7kq",
    "id" : 608341806317772801,
    "created_at" : "2015-06-09 18:36:03 +0000",
    "user" : {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "protected" : false,
      "id_str" : "2236808551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916989995909120\/ZPqHp6yp_normal.jpg",
      "id" : 2236808551,
      "verified" : false
    }
  },
  "id" : 611694689641701376,
  "created_at" : "2015-06-19 00:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "indices" : [ 3, 14 ],
      "id_str" : "2236808551",
      "id" : 2236808551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jeep",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "photography",
      "indices" : [ 90, 102 ]
    }, {
      "text" : "turtles",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 112, 121 ]
    }, {
      "text" : "OwenSound",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611694606321848320",
  "text" : "RT @JenLRPhoto: Saw this big guy while out in the #jeep today, stop, reverse, ebrake on..\n#photography #turtles #wildlife #OwenSound http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JenLRPhoto\/status\/608059501443477504\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/QbEi4fjQM2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHBC1DgXEAIPRtE.jpg",
        "id_str" : "608059428936552450",
        "id" : 608059428936552450,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHBC1DgXEAIPRtE.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QbEi4fjQM2"
      } ],
      "hashtags" : [ {
        "text" : "jeep",
        "indices" : [ 34, 39 ]
      }, {
        "text" : "photography",
        "indices" : [ 74, 86 ]
      }, {
        "text" : "turtles",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 96, 105 ]
      }, {
        "text" : "OwenSound",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608059501443477504",
    "text" : "Saw this big guy while out in the #jeep today, stop, reverse, ebrake on..\n#photography #turtles #wildlife #OwenSound http:\/\/t.co\/QbEi4fjQM2",
    "id" : 608059501443477504,
    "created_at" : "2015-06-08 23:54:17 +0000",
    "user" : {
      "name" : "CityGirlWithaView",
      "screen_name" : "JenLRPhoto",
      "protected" : false,
      "id_str" : "2236808551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792916989995909120\/ZPqHp6yp_normal.jpg",
      "id" : 2236808551,
      "verified" : false
    }
  },
  "id" : 611694606321848320,
  "created_at" : "2015-06-19 00:38:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611641656274587648",
  "text" : "DD saw endo today. mildly enlarged #thyroid. thinks anxiety main source of symptoms (I dont agree.) U\/S, bloodwork ordered.",
  "id" : 611641656274587648,
  "created_at" : "2015-06-18 21:08:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "611379987514458112",
  "geo" : { },
  "id_str" : "611560214312169473",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem thx. im not panicking.. yet..lol. we'll get it figured out. hope yr feeling better now! such exciting time (matt) : )",
  "id" : 611560214312169473,
  "in_reply_to_status_id" : 611379987514458112,
  "created_at" : "2015-06-18 15:44:51 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Malcontent",
      "screen_name" : "TheMal_Content",
      "indices" : [ 3, 18 ],
      "id_str" : "398713254",
      "id" : 398713254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611559476110467072",
  "text" : "RT @TheMal_Content: Shooting black people won't get you shot by American police, who shoot black people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611555101157797888",
    "text" : "Shooting black people won't get you shot by American police, who shoot black people.",
    "id" : 611555101157797888,
    "created_at" : "2015-06-18 15:24:32 +0000",
    "user" : {
      "name" : "The Malcontent",
      "screen_name" : "TheMal_Content",
      "protected" : false,
      "id_str" : "398713254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485838035901509632\/w8ypg7p__normal.jpeg",
      "id" : 398713254,
      "verified" : false
    }
  },
  "id" : 611559476110467072,
  "created_at" : "2015-06-18 15:41:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    }, {
      "name" : "Daniel Handler",
      "screen_name" : "DanielHandler",
      "indices" : [ 97, 111 ],
      "id_str" : "2495072576",
      "id" : 2495072576
    }, {
      "name" : "Lemony Snicket",
      "screen_name" : "lemonysnicket",
      "indices" : [ 112, 126 ],
      "id_str" : "872570005",
      "id" : 872570005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611559358426710016",
  "text" : "RT @Library4birds: \u201CAll the secrets of the world are contained in books. Read at your own risk.\u201D @DanielHandler @lemonysnicket http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Handler",
        "screen_name" : "DanielHandler",
        "indices" : [ 78, 92 ],
        "id_str" : "2495072576",
        "id" : 2495072576
      }, {
        "name" : "Lemony Snicket",
        "screen_name" : "lemonysnicket",
        "indices" : [ 93, 107 ],
        "id_str" : "872570005",
        "id" : 872570005
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/611555182246260736\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/rNp4SPCo8x",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHyuMnvVEAAnbTt.jpg",
        "id_str" : "611555181264703488",
        "id" : 611555181264703488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHyuMnvVEAAnbTt.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rNp4SPCo8x"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611555182246260736",
    "text" : "\u201CAll the secrets of the world are contained in books. Read at your own risk.\u201D @DanielHandler @lemonysnicket http:\/\/t.co\/rNp4SPCo8x",
    "id" : 611555182246260736,
    "created_at" : "2015-06-18 15:24:52 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 611559358426710016,
  "created_at" : "2015-06-18 15:41:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 70, 84 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/ej3E4bIVLv",
      "expanded_url" : "https:\/\/shar.es\/12SR92",
      "display_url" : "shar.es\/12SR92"
    } ]
  },
  "geo" : { },
  "id_str" : "611537357527994369",
  "text" : "Christian Fundamentalism\u2019s Grand Illusion https:\/\/t.co\/ej3E4bIVLv via @UnfundieXians",
  "id" : 611537357527994369,
  "created_at" : "2015-06-18 14:14:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610878297166217216",
  "geo" : { },
  "id_str" : "611348255008550914",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ((hugs))",
  "id" : 611348255008550914,
  "in_reply_to_status_id" : 610878297166217216,
  "created_at" : "2015-06-18 01:42:36 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611319908857716736",
  "text" : "RT @RustBeltRebel: didnt die until later at the hospital. which means that she may have SEEN\/HEARD them comforting him while she lay injure\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "611318741725540353",
    "geo" : { },
    "id_str" : "611319093082390528",
    "in_reply_to_user_id" : 2382724914,
    "text" : "didnt die until later at the hospital. which means that she may have SEEN\/HEARD them comforting him while she lay injured.",
    "id" : 611319093082390528,
    "in_reply_to_status_id" : 611318741725540353,
    "created_at" : "2015-06-17 23:46:44 +0000",
    "in_reply_to_screen_name" : "RustBeltRebel",
    "in_reply_to_user_id_str" : "2382724914",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 611319908857716736,
  "created_at" : "2015-06-17 23:49:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611319893305217024",
  "text" : "RT @RustBeltRebel: now i'm reading that woman who was killed by her police officer husband and who was given hugs *on the scene*--",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611318741725540353",
    "text" : "now i'm reading that woman who was killed by her police officer husband and who was given hugs *on the scene*--",
    "id" : 611318741725540353,
    "created_at" : "2015-06-17 23:45:20 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 611319893305217024,
  "created_at" : "2015-06-17 23:49:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "thyroid",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "mysterydiagnosis",
      "indices" : [ 84, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611278765847629824",
  "text" : "DD was 93lbs on june 4. 87lbs june 17. took blood for thyroid, lyme. #sick #thyroid #mysterydiagnosis",
  "id" : 611278765847629824,
  "created_at" : "2015-06-17 21:06:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    }, {
      "name" : "Newland Farm",
      "screen_name" : "newlandfarm",
      "indices" : [ 98, 110 ],
      "id_str" : "2259182801",
      "id" : 2259182801
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/611021595189112832\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/WLWLR8l9Bz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHrI5lHWIAEvPJN.jpg",
      "id_str" : "611021591003144193",
      "id" : 611021591003144193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHrI5lHWIAEvPJN.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WLWLR8l9Bz"
    } ],
    "hashtags" : [ {
      "text" : "yearofmaking",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611169182714085376",
  "text" : "RT @ErinEFarley: Lady H is nearly done. Faceless cows are weird. #yearofmaking \nHow's she looking @newlandfarm? http:\/\/t.co\/WLWLR8l9Bz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Newland Farm",
        "screen_name" : "newlandfarm",
        "indices" : [ 81, 93 ],
        "id_str" : "2259182801",
        "id" : 2259182801
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/611021595189112832\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/WLWLR8l9Bz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHrI5lHWIAEvPJN.jpg",
        "id_str" : "611021591003144193",
        "id" : 611021591003144193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHrI5lHWIAEvPJN.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WLWLR8l9Bz"
      } ],
      "hashtags" : [ {
        "text" : "yearofmaking",
        "indices" : [ 48, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611021595189112832",
    "text" : "Lady H is nearly done. Faceless cows are weird. #yearofmaking \nHow's she looking @newlandfarm? http:\/\/t.co\/WLWLR8l9Bz",
    "id" : 611021595189112832,
    "created_at" : "2015-06-17 04:04:35 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 611169182714085376,
  "created_at" : "2015-06-17 13:51:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SteamPoweredGiraffe",
      "screen_name" : "SPGiraffe",
      "indices" : [ 3, 13 ],
      "id_str" : "21124068",
      "id" : 21124068
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SPGiraffe\/status\/610985920997814273\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/AsPyiLecjr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHqodMpUkAIpNrd.jpg",
      "id_str" : "610985919026335746",
      "id" : 610985919026335746,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHqodMpUkAIpNrd.jpg",
      "sizes" : [ {
        "h" : 783,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 783,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 783,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/AsPyiLecjr"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/SPGiraffe\/status\/610985920997814273\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/AsPyiLecjr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHqodQ3VEAELK6W.jpg",
      "id_str" : "610985920158830593",
      "id" : 610985920158830593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHqodQ3VEAELK6W.jpg",
      "sizes" : [ {
        "h" : 516,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/AsPyiLecjr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/IWynd4VHpe",
      "expanded_url" : "http:\/\/steampoweredgiraffe.com\/vqpreorder.html",
      "display_url" : "steampoweredgiraffe.com\/vqpreorder.html"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/VmLGH79C5q",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=uN9TLjUbMc8",
      "display_url" : "youtube.com\/watch?v=uN9TLj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610988542374866944",
  "text" : "RT @SPGiraffe: Preorder our new album, Vice Quadrant, TODAY! http:\/\/t.co\/IWynd4VHpe https:\/\/t.co\/VmLGH79C5q http:\/\/t.co\/AsPyiLecjr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SPGiraffe\/status\/610985920997814273\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/AsPyiLecjr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHqodMpUkAIpNrd.jpg",
        "id_str" : "610985919026335746",
        "id" : 610985919026335746,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHqodMpUkAIpNrd.jpg",
        "sizes" : [ {
          "h" : 783,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 783,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 783,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/AsPyiLecjr"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SPGiraffe\/status\/610985920997814273\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/AsPyiLecjr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHqodQ3VEAELK6W.jpg",
        "id_str" : "610985920158830593",
        "id" : 610985920158830593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHqodQ3VEAELK6W.jpg",
        "sizes" : [ {
          "h" : 516,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 319,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/AsPyiLecjr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/IWynd4VHpe",
        "expanded_url" : "http:\/\/steampoweredgiraffe.com\/vqpreorder.html",
        "display_url" : "steampoweredgiraffe.com\/vqpreorder.html"
      }, {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/VmLGH79C5q",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=uN9TLjUbMc8",
        "display_url" : "youtube.com\/watch?v=uN9TLj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610985920997814273",
    "text" : "Preorder our new album, Vice Quadrant, TODAY! http:\/\/t.co\/IWynd4VHpe https:\/\/t.co\/VmLGH79C5q http:\/\/t.co\/AsPyiLecjr",
    "id" : 610985920997814273,
    "created_at" : "2015-06-17 01:42:49 +0000",
    "user" : {
      "name" : "SteamPoweredGiraffe",
      "screen_name" : "SPGiraffe",
      "protected" : false,
      "id_str" : "21124068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712827378909601793\/4oJPYDlb_normal.jpg",
      "id" : 21124068,
      "verified" : false
    }
  },
  "id" : 610988542374866944,
  "created_at" : "2015-06-17 01:53:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolf Mommy",
      "screen_name" : "Wolf_Mommy",
      "indices" : [ 0, 11 ],
      "id_str" : "187357122",
      "id" : 187357122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610986801952501760",
  "geo" : { },
  "id_str" : "610987940785848321",
  "in_reply_to_user_id" : 187357122,
  "text" : "@Wolf_Mommy what a precious face! sooo smoochable! : )",
  "id" : 610987940785848321,
  "in_reply_to_status_id" : 610986801952501760,
  "created_at" : "2015-06-17 01:50:51 +0000",
  "in_reply_to_screen_name" : "Wolf_Mommy",
  "in_reply_to_user_id_str" : "187357122",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "God of Evolution",
      "screen_name" : "godofevolution",
      "indices" : [ 3, 18 ],
      "id_str" : "1220319096",
      "id" : 1220319096
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/godofevolution\/status\/610929662286376960\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/uyBZ7IoYWd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHp1SkJUAAEDI48.jpg",
      "id_str" : "610929661262954497",
      "id" : 610929661262954497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHp1SkJUAAEDI48.jpg",
      "sizes" : [ {
        "h" : 317,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 669
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 669
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/uyBZ7IoYWd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/2s4haGeTM7",
      "expanded_url" : "http:\/\/www.godofevolution.com\/thank-you-for-having-a-sane-christian-view\/",
      "display_url" : "godofevolution.com\/thank-you-for-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610931116598497281",
  "text" : "RT @godofevolution: \u2018Thank you for having a sane Christian\u00A0view\u2019 http:\/\/t.co\/2s4haGeTM7 http:\/\/t.co\/uyBZ7IoYWd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/godofevolution\/status\/610929662286376960\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/uyBZ7IoYWd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHp1SkJUAAEDI48.jpg",
        "id_str" : "610929661262954497",
        "id" : 610929661262954497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHp1SkJUAAEDI48.jpg",
        "sizes" : [ {
          "h" : 317,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 669
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 669
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/uyBZ7IoYWd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/2s4haGeTM7",
        "expanded_url" : "http:\/\/www.godofevolution.com\/thank-you-for-having-a-sane-christian-view\/",
        "display_url" : "godofevolution.com\/thank-you-for-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610929662286376960",
    "text" : "\u2018Thank you for having a sane Christian\u00A0view\u2019 http:\/\/t.co\/2s4haGeTM7 http:\/\/t.co\/uyBZ7IoYWd",
    "id" : 610929662286376960,
    "created_at" : "2015-06-16 21:59:16 +0000",
    "user" : {
      "name" : "God of Evolution",
      "screen_name" : "godofevolution",
      "protected" : false,
      "id_str" : "1220319096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674299817472819200\/uHcXuV0d_normal.png",
      "id" : 1220319096,
      "verified" : false
    }
  },
  "id" : 610931116598497281,
  "created_at" : "2015-06-16 22:05:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 3, 9 ],
      "id_str" : "29417304",
      "id" : 29417304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/jsDInteCrT",
      "expanded_url" : "https:\/\/twitter.com\/realdonaldtrump\/status\/537157586316165120",
      "display_url" : "twitter.com\/realdonaldtrum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610924280461815808",
  "text" : "RT @deray: By that standard, there will never be a white male president again.  https:\/\/t.co\/jsDInteCrT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/jsDInteCrT",
        "expanded_url" : "https:\/\/twitter.com\/realdonaldtrump\/status\/537157586316165120",
        "display_url" : "twitter.com\/realdonaldtrum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610844051110150144",
    "text" : "By that standard, there will never be a white male president again.  https:\/\/t.co\/jsDInteCrT",
    "id" : 610844051110150144,
    "created_at" : "2015-06-16 16:19:05 +0000",
    "user" : {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "protected" : false,
      "id_str" : "29417304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801064994188173312\/kRr2hLGv_normal.jpg",
      "id" : 29417304,
      "verified" : true
    }
  },
  "id" : 610924280461815808,
  "created_at" : "2015-06-16 21:37:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610861972867915776",
  "text" : "my poor kid's wasting away. cant wait for DR appt tomorrow. since may 7, except for maybe 5 days, she's been living in bed. losing weight.",
  "id" : 610861972867915776,
  "created_at" : "2015-06-16 17:30:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "indices" : [ 3, 19 ],
      "id_str" : "1067008352",
      "id" : 1067008352
    }, {
      "name" : "Linford Armstrong",
      "screen_name" : "linford86",
      "indices" : [ 29, 39 ],
      "id_str" : "763400264363761664",
      "id" : 763400264363761664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/VlNjLQkLB5",
      "expanded_url" : "http:\/\/skepticfreethought.com\/libere\/2015\/06\/16\/the-problem-of-hell-as-i-presently-see-it\/",
      "display_url" : "skepticfreethought.com\/libere\/2015\/06\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610853578807345152",
  "text" : "RT @CounterApologis: Go read @linford86 knock some shit out of the park on the Problem of Hell: http:\/\/t.co\/VlNjLQkLB5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Linford Armstrong",
        "screen_name" : "linford86",
        "indices" : [ 8, 18 ],
        "id_str" : "763400264363761664",
        "id" : 763400264363761664
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/VlNjLQkLB5",
        "expanded_url" : "http:\/\/skepticfreethought.com\/libere\/2015\/06\/16\/the-problem-of-hell-as-i-presently-see-it\/",
        "display_url" : "skepticfreethought.com\/libere\/2015\/06\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610847685487239168",
    "text" : "Go read @linford86 knock some shit out of the park on the Problem of Hell: http:\/\/t.co\/VlNjLQkLB5",
    "id" : 610847685487239168,
    "created_at" : "2015-06-16 16:33:31 +0000",
    "user" : {
      "name" : "Counter Apologist",
      "screen_name" : "CounterApologis",
      "protected" : false,
      "id_str" : "1067008352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075418480\/134a0239b125d5ad2cc7a96e607a4b6c_normal.jpeg",
      "id" : 1067008352,
      "verified" : false
    }
  },
  "id" : 610853578807345152,
  "created_at" : "2015-06-16 16:56:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Blackwell",
      "screen_name" : "apblackwell",
      "indices" : [ 3, 15 ],
      "id_str" : "17854752",
      "id" : 17854752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610837473355296768",
  "text" : "RT @apblackwell: @NatsNaturePics @chriswitt1966 @Swan_Sanctuary @Swanwhisperer @hounslowculture  #swan family #BedfontLakes #bedfont http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christopher Witt",
        "screen_name" : "chriswitt1966",
        "indices" : [ 16, 30 ],
        "id_str" : "1430955528",
        "id" : 1430955528
      }, {
        "name" : "The Swan Sanctuary",
        "screen_name" : "Swan_Sanctuary",
        "indices" : [ 31, 46 ],
        "id_str" : "19557718",
        "id" : 19557718
      }, {
        "name" : "Wildlifeloverforever",
        "screen_name" : "Swanwhisperer",
        "indices" : [ 47, 61 ],
        "id_str" : "272369448",
        "id" : 272369448
      }, {
        "name" : "Hounslow Culture",
        "screen_name" : "hounslowculture",
        "indices" : [ 62, 78 ],
        "id_str" : "146385748",
        "id" : 146385748
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/apblackwell\/status\/610565281996517376\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/T7CwKtXQAM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHkp3viW8AE1oE3.jpg",
        "id_str" : "610565262115532801",
        "id" : 610565262115532801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHkp3viW8AE1oE3.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/T7CwKtXQAM"
      } ],
      "hashtags" : [ {
        "text" : "swan",
        "indices" : [ 80, 85 ]
      }, {
        "text" : "BedfontLakes",
        "indices" : [ 93, 106 ]
      }, {
        "text" : "bedfont",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610565281996517376",
    "in_reply_to_user_id" : 2905563562,
    "text" : "@NatsNaturePics @chriswitt1966 @Swan_Sanctuary @Swanwhisperer @hounslowculture  #swan family #BedfontLakes #bedfont http:\/\/t.co\/T7CwKtXQAM",
    "id" : 610565281996517376,
    "created_at" : "2015-06-15 21:51:21 +0000",
    "in_reply_to_screen_name" : "byNatDavidson",
    "in_reply_to_user_id_str" : "2905563562",
    "user" : {
      "name" : "Andy Blackwell",
      "screen_name" : "apblackwell",
      "protected" : false,
      "id_str" : "17854752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792656487025901568\/aX694yDa_normal.jpg",
      "id" : 17854752,
      "verified" : false
    }
  },
  "id" : 610837473355296768,
  "created_at" : "2015-06-16 15:52:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "indices" : [ 3, 14 ],
      "id_str" : "3312535865",
      "id" : 3312535865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/610446868959637504\/video\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/zBW2WdM4rm",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/610444808298086401\/pu\/img\/-BeVAPZrIHrhgtPu.jpg",
      "id_str" : "610444808298086401",
      "id" : 610444808298086401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/610444808298086401\/pu\/img\/-BeVAPZrIHrhgtPu.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zBW2WdM4rm"
    } ],
    "hashtags" : [ {
      "text" : "dailyMorag",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610835305822822400",
  "text" : "RT @dailyMorag: Highland Cowwashing is hard work #dailyMorag http:\/\/t.co\/zBW2WdM4rm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailyMorag\/status\/610446868959637504\/video\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/zBW2WdM4rm",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/610444808298086401\/pu\/img\/-BeVAPZrIHrhgtPu.jpg",
        "id_str" : "610444808298086401",
        "id" : 610444808298086401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/610444808298086401\/pu\/img\/-BeVAPZrIHrhgtPu.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zBW2WdM4rm"
      } ],
      "hashtags" : [ {
        "text" : "dailyMorag",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610446868959637504",
    "text" : "Highland Cowwashing is hard work #dailyMorag http:\/\/t.co\/zBW2WdM4rm",
    "id" : 610446868959637504,
    "created_at" : "2015-06-15 14:00:49 +0000",
    "user" : {
      "name" : "dailyMorag",
      "screen_name" : "dailyMorag",
      "protected" : false,
      "id_str" : "3312535865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620185595063730176\/IT0BdRti_normal.jpg",
      "id" : 3312535865,
      "verified" : false
    }
  },
  "id" : 610835305822822400,
  "created_at" : "2015-06-16 15:44:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Muriel Gray",
      "screen_name" : "ArtyBagger",
      "indices" : [ 3, 14 ],
      "id_str" : "2784159969",
      "id" : 2784159969
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ArtyBagger\/status\/610559216139534336\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/lj3hFqLz3S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHkkXxiWoAEXoa0.jpg",
      "id_str" : "610559215338430465",
      "id" : 610559215338430465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHkkXxiWoAEXoa0.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 446
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 446
      } ],
      "display_url" : "pic.twitter.com\/lj3hFqLz3S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610562384877481986",
  "text" : "RT @ArtyBagger: Now become obsessed with the absolute beauty of Norwegian Bunad. Look at the needle work! http:\/\/t.co\/lj3hFqLz3S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ArtyBagger\/status\/610559216139534336\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/lj3hFqLz3S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHkkXxiWoAEXoa0.jpg",
        "id_str" : "610559215338430465",
        "id" : 610559215338430465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHkkXxiWoAEXoa0.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 446
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 446
        } ],
        "display_url" : "pic.twitter.com\/lj3hFqLz3S"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610559216139534336",
    "text" : "Now become obsessed with the absolute beauty of Norwegian Bunad. Look at the needle work! http:\/\/t.co\/lj3hFqLz3S",
    "id" : 610559216139534336,
    "created_at" : "2015-06-15 21:27:15 +0000",
    "user" : {
      "name" : "Muriel Gray",
      "screen_name" : "ArtyBagger",
      "protected" : false,
      "id_str" : "2784159969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608783689577820160\/GV24EEdU_normal.jpg",
      "id" : 2784159969,
      "verified" : false
    }
  },
  "id" : 610562384877481986,
  "created_at" : "2015-06-15 21:39:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610516887500365825",
  "text" : "sooo looking at her labs, DD TSH went from 8.53 (june 4) to 14.6 (june 6) #thyroid",
  "id" : 610516887500365825,
  "created_at" : "2015-06-15 18:39:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "indices" : [ 3, 15 ],
      "id_str" : "629225037",
      "id" : 629225037
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/610403223401299968\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/dqXBcQZLdT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHiWerjW8AA_ocv.jpg",
      "id_str" : "610403203339972608",
      "id" : 610403203339972608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHiWerjW8AA_ocv.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 801
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 801
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/dqXBcQZLdT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610473012232605696",
  "text" : "RT @AndyBoxHill: This sullen looking toad has the Monday morning look about her. Hope yours is feeling better! \uD83D\uDE0A http:\/\/t.co\/dqXBcQZLdT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AndyBoxHill\/status\/610403223401299968\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/dqXBcQZLdT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHiWerjW8AA_ocv.jpg",
        "id_str" : "610403203339972608",
        "id" : 610403203339972608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHiWerjW8AA_ocv.jpg",
        "sizes" : [ {
          "h" : 435,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 801
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 801
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/dqXBcQZLdT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610403223401299968",
    "text" : "This sullen looking toad has the Monday morning look about her. Hope yours is feeling better! \uD83D\uDE0A http:\/\/t.co\/dqXBcQZLdT",
    "id" : 610403223401299968,
    "created_at" : "2015-06-15 11:07:23 +0000",
    "user" : {
      "name" : "Andrew Wright",
      "screen_name" : "AndyBoxHill",
      "protected" : false,
      "id_str" : "629225037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543479254550593536\/nw_rTozc_normal.jpeg",
      "id" : 629225037,
      "verified" : false
    }
  },
  "id" : 610473012232605696,
  "created_at" : "2015-06-15 15:44:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 0, 14 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610458585739296768",
  "geo" : { },
  "id_str" : "610461930415857665",
  "in_reply_to_user_id" : 21729540,
  "text" : "@knittingknots PR gets me so angry.. grrrr...",
  "id" : 610461930415857665,
  "in_reply_to_status_id" : 610458585739296768,
  "created_at" : "2015-06-15 15:00:40 +0000",
  "in_reply_to_screen_name" : "knittingknots",
  "in_reply_to_user_id_str" : "21729540",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610170800335884288",
  "geo" : { },
  "id_str" : "610209996224233472",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre thanks. i'll look into this. : )",
  "id" : 610209996224233472,
  "in_reply_to_status_id" : 610170800335884288,
  "created_at" : "2015-06-14 22:19:34 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/rko1FdNO8r",
      "expanded_url" : "http:\/\/www.mdjunction.com\/forums\/lyme-disease-support-forums\/medicine-treatments\/3052451-lyme-disease-panic-attacks-psychiatric-anxiety",
      "display_url" : "mdjunction.com\/forums\/lyme-di\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610164403007307777",
  "text" : "huh.. lyme disease and panic attacks &gt;&gt; http:\/\/t.co\/rko1FdNO8r",
  "id" : 610164403007307777,
  "created_at" : "2015-06-14 19:18:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Rogers",
      "screen_name" : "FalkirkBairn01",
      "indices" : [ 3, 18 ],
      "id_str" : "219045591",
      "id" : 219045591
    }, {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "indices" : [ 20, 34 ],
      "id_str" : "272369448",
      "id" : 272369448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FalkirkBairn01\/status\/610120918489300992\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ZNoHunEtrU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHeVvKoWIAEHnYX.jpg",
      "id_str" : "610120912071958529",
      "id" : 610120912071958529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHeVvKoWIAEHnYX.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZNoHunEtrU"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/FalkirkBairn01\/status\/610120918489300992\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ZNoHunEtrU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHeVve4W8AEHTtB.jpg",
      "id_str" : "610120917507829761",
      "id" : 610120917507829761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHeVve4W8AEHTtB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 652
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZNoHunEtrU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610127567723589632",
  "text" : "RT @FalkirkBairn01: @Swanwhisperer Couple of close shots of one of the adults http:\/\/t.co\/ZNoHunEtrU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wildlifeloverforever",
        "screen_name" : "Swanwhisperer",
        "indices" : [ 0, 14 ],
        "id_str" : "272369448",
        "id" : 272369448
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FalkirkBairn01\/status\/610120918489300992\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ZNoHunEtrU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHeVvKoWIAEHnYX.jpg",
        "id_str" : "610120912071958529",
        "id" : 610120912071958529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHeVvKoWIAEHnYX.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZNoHunEtrU"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FalkirkBairn01\/status\/610120918489300992\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/ZNoHunEtrU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHeVve4W8AEHTtB.jpg",
        "id_str" : "610120917507829761",
        "id" : 610120917507829761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHeVve4W8AEHTtB.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZNoHunEtrU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "609417681687719936",
    "geo" : { },
    "id_str" : "610120918489300992",
    "in_reply_to_user_id" : 272369448,
    "text" : "@Swanwhisperer Couple of close shots of one of the adults http:\/\/t.co\/ZNoHunEtrU",
    "id" : 610120918489300992,
    "in_reply_to_status_id" : 609417681687719936,
    "created_at" : "2015-06-14 16:25:37 +0000",
    "in_reply_to_screen_name" : "Swanwhisperer",
    "in_reply_to_user_id_str" : "272369448",
    "user" : {
      "name" : "Alan Rogers",
      "screen_name" : "FalkirkBairn01",
      "protected" : false,
      "id_str" : "219045591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1180065228\/g2ztK9gx_normal",
      "id" : 219045591,
      "verified" : false
    }
  },
  "id" : 610127567723589632,
  "created_at" : "2015-06-14 16:52:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/610121627184070656\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/MMwQt5grJf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHeWYyEW8AAKg-j.jpg",
      "id_str" : "610121627033071616",
      "id" : 610121627033071616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHeWYyEW8AAKg-j.jpg",
      "sizes" : [ {
        "h" : 802,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 908,
        "resize" : "fit",
        "w" : 679
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 908,
        "resize" : "fit",
        "w" : 679
      } ],
      "display_url" : "pic.twitter.com\/MMwQt5grJf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610127376593350658",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E http:\/\/t.co\/MMwQt5grJf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/610121627184070656\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/MMwQt5grJf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHeWYyEW8AAKg-j.jpg",
        "id_str" : "610121627033071616",
        "id" : 610121627033071616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHeWYyEW8AAKg-j.jpg",
        "sizes" : [ {
          "h" : 802,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 908,
          "resize" : "fit",
          "w" : 679
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 908,
          "resize" : "fit",
          "w" : 679
        } ],
        "display_url" : "pic.twitter.com\/MMwQt5grJf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610121627184070656",
    "text" : "\uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E http:\/\/t.co\/MMwQt5grJf",
    "id" : 610121627184070656,
    "created_at" : "2015-06-14 16:28:26 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 610127376593350658,
  "created_at" : "2015-06-14 16:51:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/507009817836552193\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/mpy89pZaXD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwlCvhwIIAAwVSp.jpg",
      "id_str" : "507009817337405440",
      "id" : 507009817337405440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwlCvhwIIAAwVSp.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/mpy89pZaXD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610126870454136832",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/mpy89pZaXD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/507009817836552193\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/mpy89pZaXD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwlCvhwIIAAwVSp.jpg",
        "id_str" : "507009817337405440",
        "id" : 507009817337405440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwlCvhwIIAAwVSp.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/mpy89pZaXD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610124552669106176",
    "text" : "http:\/\/t.co\/mpy89pZaXD",
    "id" : 610124552669106176,
    "created_at" : "2015-06-14 16:40:03 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 610126870454136832,
  "created_at" : "2015-06-14 16:49:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "610083561316720640",
  "geo" : { },
  "id_str" : "610103027559739393",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ((hugs))",
  "id" : 610103027559739393,
  "in_reply_to_status_id" : 610083561316720640,
  "created_at" : "2015-06-14 15:14:31 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610095907384741888",
  "text" : "dd had another episode last night.. another ativan and i slept on bottom bunk. my poor baby.",
  "id" : 610095907384741888,
  "created_at" : "2015-06-14 14:46:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/609941491474145280\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/nMSpkZSX1I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHbyitbWUAA-JdI.jpg",
      "id_str" : "609941477679058944",
      "id" : 609941477679058944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHbyitbWUAA-JdI.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nMSpkZSX1I"
    } ],
    "hashtags" : [ {
      "text" : "LadyH",
      "indices" : [ 76, 82 ]
    }, {
      "text" : "yearofmaking",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610094890660315136",
  "text" : "RT @ErinEFarley: I think I've finally got it! Just a few ends to weave in.  #LadyH #yearofmaking http:\/\/t.co\/nMSpkZSX1I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/609941491474145280\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/nMSpkZSX1I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHbyitbWUAA-JdI.jpg",
        "id_str" : "609941477679058944",
        "id" : 609941477679058944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHbyitbWUAA-JdI.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/nMSpkZSX1I"
      } ],
      "hashtags" : [ {
        "text" : "LadyH",
        "indices" : [ 59, 65 ]
      }, {
        "text" : "yearofmaking",
        "indices" : [ 66, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609941491474145280",
    "text" : "I think I've finally got it! Just a few ends to weave in.  #LadyH #yearofmaking http:\/\/t.co\/nMSpkZSX1I",
    "id" : 609941491474145280,
    "created_at" : "2015-06-14 04:32:38 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 610094890660315136,
  "created_at" : "2015-06-14 14:42:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609941491474145280",
  "geo" : { },
  "id_str" : "610094856380227584",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley gorgeous! thx for sharing pics of your knitting. i really enjoy it. : )",
  "id" : 610094856380227584,
  "in_reply_to_status_id" : 609941491474145280,
  "created_at" : "2015-06-14 14:42:03 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/514136575597641728\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/K7Yx7MEXnz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByKUfcZIYAE9Tr9.jpg",
      "id_str" : "514136575392112641",
      "id" : 514136575392112641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByKUfcZIYAE9Tr9.jpg",
      "sizes" : [ {
        "h" : 670,
        "resize" : "fit",
        "w" : 368
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 368
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 368
      } ],
      "display_url" : "pic.twitter.com\/K7Yx7MEXnz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609835470428721154",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/K7Yx7MEXnz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/514136575597641728\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/K7Yx7MEXnz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByKUfcZIYAE9Tr9.jpg",
        "id_str" : "514136575392112641",
        "id" : 514136575392112641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByKUfcZIYAE9Tr9.jpg",
        "sizes" : [ {
          "h" : 670,
          "resize" : "fit",
          "w" : 368
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 368
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 368
        } ],
        "display_url" : "pic.twitter.com\/K7Yx7MEXnz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609810012702134274",
    "text" : "http:\/\/t.co\/K7Yx7MEXnz",
    "id" : 609810012702134274,
    "created_at" : "2015-06-13 19:50:11 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 609835470428721154,
  "created_at" : "2015-06-13 21:31:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609747160242982912",
  "text" : "ppl will be looking at house today. dh is cleaning and its making dd sick.",
  "id" : 609747160242982912,
  "created_at" : "2015-06-13 15:40:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 3, 15 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yearofmaking",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609727472205201408",
  "text" : "RT @ErinEFarley: Very happy with the one on the left. Trying to work out making the one on the right match. #yearofmaking http:\/\/t.co\/6g5Up\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErinEFarley\/status\/609594580854509568\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/6g5Up53EIO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHW3CYIWwAADZHt.jpg",
        "id_str" : "609594576043687936",
        "id" : 609594576043687936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHW3CYIWwAADZHt.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6g5Up53EIO"
      } ],
      "hashtags" : [ {
        "text" : "yearofmaking",
        "indices" : [ 91, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609594580854509568",
    "text" : "Very happy with the one on the left. Trying to work out making the one on the right match. #yearofmaking http:\/\/t.co\/6g5Up53EIO",
    "id" : 609594580854509568,
    "created_at" : "2015-06-13 05:34:08 +0000",
    "user" : {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "protected" : false,
      "id_str" : "1305052615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786931673208283136\/hvomQJZM_normal.jpg",
      "id" : 1305052615,
      "verified" : false
    }
  },
  "id" : 609727472205201408,
  "created_at" : "2015-06-13 14:22:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609594580854509568",
  "geo" : { },
  "id_str" : "609727438235508736",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley such tiny stitches.. beautiful.",
  "id" : 609727438235508736,
  "in_reply_to_status_id" : 609594580854509568,
  "created_at" : "2015-06-13 14:22:04 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609726902400622592",
  "text" : "@Skeptical_Lady so much THIS!!",
  "id" : 609726902400622592,
  "created_at" : "2015-06-13 14:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan",
      "screen_name" : "geminicat7",
      "indices" : [ 3, 14 ],
      "id_str" : "1704413916",
      "id" : 1704413916
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/geminicat7\/status\/609641324791373824\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/t6Y0zvwlQ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHXhjggXAAAlGVS.jpg",
      "id_str" : "609641324715900928",
      "id" : 609641324715900928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHXhjggXAAAlGVS.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 851,
        "resize" : "fit",
        "w" : 1134
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t6Y0zvwlQ6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609726147174236161",
  "text" : "RT @geminicat7: A little flotilla accompanying me upstream this morning ... http:\/\/t.co\/t6Y0zvwlQ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/geminicat7\/status\/609641324791373824\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/t6Y0zvwlQ6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHXhjggXAAAlGVS.jpg",
        "id_str" : "609641324715900928",
        "id" : 609641324715900928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHXhjggXAAAlGVS.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 851,
          "resize" : "fit",
          "w" : 1134
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/t6Y0zvwlQ6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 54.511173, -1.352818 ]
    },
    "id_str" : "609641324791373824",
    "text" : "A little flotilla accompanying me upstream this morning ... http:\/\/t.co\/t6Y0zvwlQ6",
    "id" : 609641324791373824,
    "created_at" : "2015-06-13 08:39:53 +0000",
    "user" : {
      "name" : "Jan",
      "screen_name" : "geminicat7",
      "protected" : false,
      "id_str" : "1704413916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566524030535352320\/e64XS3wl_normal.jpeg",
      "id" : 1704413916,
      "verified" : false
    }
  },
  "id" : 609726147174236161,
  "created_at" : "2015-06-13 14:16:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609520468421382144",
  "geo" : { },
  "id_str" : "609522378725531648",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley yum!!",
  "id" : 609522378725531648,
  "in_reply_to_status_id" : 609520468421382144,
  "created_at" : "2015-06-13 00:47:14 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JAScribbles\/status\/609493091230334977\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/kkPyZh8vnb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHVas0TVAAAY5Hh.jpg",
      "id_str" : "609493050579025920",
      "id" : 609493050579025920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHVas0TVAAAY5Hh.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kkPyZh8vnb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/dS7kAsHUKR",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/236885354\/blue-and-white-fashion-hippie-boho",
      "display_url" : "etsy.com\/listing\/236885\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609496090241576961",
  "text" : "RT @JAScribbles: https:\/\/t.co\/dS7kAsHUKR http:\/\/t.co\/kkPyZh8vnb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JAScribbles\/status\/609493091230334977\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/kkPyZh8vnb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHVas0TVAAAY5Hh.jpg",
        "id_str" : "609493050579025920",
        "id" : 609493050579025920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHVas0TVAAAY5Hh.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kkPyZh8vnb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/dS7kAsHUKR",
        "expanded_url" : "https:\/\/www.etsy.com\/listing\/236885354\/blue-and-white-fashion-hippie-boho",
        "display_url" : "etsy.com\/listing\/236885\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609493091230334977",
    "text" : "https:\/\/t.co\/dS7kAsHUKR http:\/\/t.co\/kkPyZh8vnb",
    "id" : 609493091230334977,
    "created_at" : "2015-06-12 22:50:51 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 609496090241576961,
  "created_at" : "2015-06-12 23:02:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609468156810297344",
  "text" : "DD still not feeling great. she feels \"on the fence\"..",
  "id" : 609468156810297344,
  "created_at" : "2015-06-12 21:11:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "indices" : [ 3, 18 ],
      "id_str" : "1323776491",
      "id" : 1323776491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609411777286287363",
  "text" : "RT @humblethinker1: God creating at the risk of the creature's eternal damnation is unethical, no?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607575415717130240",
    "text" : "God creating at the risk of the creature's eternal damnation is unethical, no?",
    "id" : 607575415717130240,
    "created_at" : "2015-06-07 15:50:41 +0000",
    "user" : {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "protected" : false,
      "id_str" : "1323776491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744730630085173249\/ApIVKrhX_normal.jpg",
      "id" : 1323776491,
      "verified" : false
    }
  },
  "id" : 609411777286287363,
  "created_at" : "2015-06-12 17:27:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609179131197063169",
  "geo" : { },
  "id_str" : "609366705219969024",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe ouch...",
  "id" : 609366705219969024,
  "in_reply_to_status_id" : 609179131197063169,
  "created_at" : "2015-06-12 14:28:38 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609177623814508544",
  "geo" : { },
  "id_str" : "609366077936680961",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe poor kitty...",
  "id" : 609366077936680961,
  "in_reply_to_status_id" : 609177623814508544,
  "created_at" : "2015-06-12 14:26:09 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u82E5\u3055\u3093@",
      "screen_name" : "radio_skyblue12",
      "indices" : [ 3, 19 ],
      "id_str" : "564655643",
      "id" : 564655643
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/radio_skyblue12\/status\/609139643531984896\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Mg51J9t31y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHQZQs1VEAAlRPQ.jpg",
      "id_str" : "609139624305299456",
      "id" : 609139624305299456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHQZQs1VEAAlRPQ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Mg51J9t31y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609171019086065664",
  "text" : "RT @radio_skyblue12: \u30ED\u30FC\u30BD\u30F3\u306B\u3068\u3093\u3067\u3082\u306A\u3044\u304A\u5BA2\u304C\uFF01\u3073\u3063\u304F\u308A\u3084\u308F\u3002 http:\/\/t.co\/Mg51J9t31y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/radio_skyblue12\/status\/609139643531984896\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/Mg51J9t31y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHQZQs1VEAAlRPQ.jpg",
        "id_str" : "609139624305299456",
        "id" : 609139624305299456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHQZQs1VEAAlRPQ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Mg51J9t31y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609139643531984896",
    "text" : "\u30ED\u30FC\u30BD\u30F3\u306B\u3068\u3093\u3067\u3082\u306A\u3044\u304A\u5BA2\u304C\uFF01\u3073\u3063\u304F\u308A\u3084\u308F\u3002 http:\/\/t.co\/Mg51J9t31y",
    "id" : 609139643531984896,
    "created_at" : "2015-06-11 23:26:22 +0000",
    "user" : {
      "name" : "\u82E5\u3055\u3093@",
      "screen_name" : "radio_skyblue12",
      "protected" : false,
      "id_str" : "564655643",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726408981137125376\/r9gOq-Si_normal.jpg",
      "id" : 564655643,
      "verified" : false
    }
  },
  "id" : 609171019086065664,
  "created_at" : "2015-06-12 01:31:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/506125076597440512\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/XYWFnmXnh8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
      "id_str" : "506125076387729408",
      "id" : 506125076387729408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XYWFnmXnh8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609094056619184128",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/XYWFnmXnh8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/506125076597440512\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/XYWFnmXnh8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
        "id_str" : "506125076387729408",
        "id" : 506125076387729408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwYeE04CEAA99jW.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XYWFnmXnh8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609092766681997313",
    "text" : "http:\/\/t.co\/XYWFnmXnh8",
    "id" : 609092766681997313,
    "created_at" : "2015-06-11 20:20:06 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 609094056619184128,
  "created_at" : "2015-06-11 20:25:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison",
      "screen_name" : "BluefaceAlison",
      "indices" : [ 3, 18 ],
      "id_str" : "2973601289",
      "id" : 2973601289
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BluefaceAlison\/status\/609065222972780544\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/dmCde3Nzdz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPVgjnWQAAHi6-.jpg",
      "id_str" : "609065129917956096",
      "id" : 609065129917956096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPVgjnWQAAHi6-.jpg",
      "sizes" : [ {
        "h" : 681,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1162,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 1644
      } ],
      "display_url" : "pic.twitter.com\/dmCde3Nzdz"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/BluefaceAlison\/status\/609065222972780544\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/dmCde3Nzdz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPVgA3WQAAiyFH.jpg",
      "id_str" : "609065120589824000",
      "id" : 609065120589824000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPVgA3WQAAiyFH.jpg",
      "sizes" : [ {
        "h" : 583,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 995,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1700,
        "resize" : "fit",
        "w" : 1750
      } ],
      "display_url" : "pic.twitter.com\/dmCde3Nzdz"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/BluefaceAlison\/status\/609065222972780544\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/dmCde3Nzdz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPVl5xWgAAa5cr.jpg",
      "id_str" : "609065221764841472",
      "id" : 609065221764841472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPVl5xWgAAa5cr.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1704,
        "resize" : "fit",
        "w" : 2272
      } ],
      "display_url" : "pic.twitter.com\/dmCde3Nzdz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609070511054827520",
  "text" : "RT @BluefaceAlison: Finished these socks with my hand-dyed gradient yarn :) http:\/\/t.co\/dmCde3Nzdz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BluefaceAlison\/status\/609065222972780544\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/dmCde3Nzdz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPVgjnWQAAHi6-.jpg",
        "id_str" : "609065129917956096",
        "id" : 609065129917956096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPVgjnWQAAHi6-.jpg",
        "sizes" : [ {
          "h" : 681,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1162,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1866,
          "resize" : "fit",
          "w" : 1644
        } ],
        "display_url" : "pic.twitter.com\/dmCde3Nzdz"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/BluefaceAlison\/status\/609065222972780544\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/dmCde3Nzdz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPVgA3WQAAiyFH.jpg",
        "id_str" : "609065120589824000",
        "id" : 609065120589824000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPVgA3WQAAiyFH.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 995,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1700,
          "resize" : "fit",
          "w" : 1750
        } ],
        "display_url" : "pic.twitter.com\/dmCde3Nzdz"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/BluefaceAlison\/status\/609065222972780544\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/dmCde3Nzdz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPVl5xWgAAa5cr.jpg",
        "id_str" : "609065221764841472",
        "id" : 609065221764841472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPVl5xWgAAa5cr.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1704,
          "resize" : "fit",
          "w" : 2272
        } ],
        "display_url" : "pic.twitter.com\/dmCde3Nzdz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609065222972780544",
    "text" : "Finished these socks with my hand-dyed gradient yarn :) http:\/\/t.co\/dmCde3Nzdz",
    "id" : 609065222972780544,
    "created_at" : "2015-06-11 18:30:39 +0000",
    "user" : {
      "name" : "Alison",
      "screen_name" : "BluefaceAlison",
      "protected" : false,
      "id_str" : "2973601289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663750702108405760\/hISQWBXs_normal.jpg",
      "id" : 2973601289,
      "verified" : false
    }
  },
  "id" : 609070511054827520,
  "created_at" : "2015-06-11 18:51:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609067148380647424",
  "text" : "she got her referral to endocrinologist today. maybe he can do more specific testing to pin down these weird episodes.",
  "id" : 609067148380647424,
  "created_at" : "2015-06-11 18:38:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609066740627173377",
  "text" : "well the ativan seemed to do the trick but I'd like to get her onto the hydroxyzine instead.",
  "id" : 609066740627173377,
  "created_at" : "2015-06-11 18:36:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anime",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609042070771277825",
  "text" : "RT @Matth3ous: What is it with #anime and boobs?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "anime",
        "indices" : [ 16, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609041018978189312",
    "text" : "What is it with #anime and boobs?",
    "id" : 609041018978189312,
    "created_at" : "2015-06-11 16:54:29 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 609042070771277825,
  "created_at" : "2015-06-11 16:58:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609016624444796928",
  "text" : "DD afraid to try the hydroxyline so another ativan today. she's only been out of bed maybe 3 hours total since Sat er visit.",
  "id" : 609016624444796928,
  "created_at" : "2015-06-11 15:17:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pooks",
      "screen_name" : "Siberia61",
      "indices" : [ 3, 13 ],
      "id_str" : "1244239765",
      "id" : 1244239765
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZASByEx1Y4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRbHWkAEhgOm.jpg",
      "id_str" : "608983506077782017",
      "id" : 608983506077782017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRbHWkAEhgOm.jpg",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZASByEx1Y4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZASByEx1Y4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRbRXIAET9-9.jpg",
      "id_str" : "608983506119761921",
      "id" : 608983506119761921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRbRXIAET9-9.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZASByEx1Y4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZASByEx1Y4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRhZWMAE4dIK.jpg",
      "id_str" : "608983507763867649",
      "id" : 608983507763867649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRhZWMAE4dIK.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZASByEx1Y4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZASByEx1Y4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRiIW4AAmPP-.jpg",
      "id_str" : "608983507961044992",
      "id" : 608983507961044992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRiIW4AAmPP-.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZASByEx1Y4"
    } ],
    "hashtags" : [ {
      "text" : "swans",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608992164287234048",
  "text" : "RT @Siberia61: Any chance of syncing Mr #swans ? ... Yes ...... Yes ...... Fabulous ! Thanks ! Ps bless you \uD83D\uDE00 http:\/\/t.co\/ZASByEx1Y4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ZASByEx1Y4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRbHWkAEhgOm.jpg",
        "id_str" : "608983506077782017",
        "id" : 608983506077782017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRbHWkAEhgOm.jpg",
        "sizes" : [ {
          "h" : 393,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZASByEx1Y4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ZASByEx1Y4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRbRXIAET9-9.jpg",
        "id_str" : "608983506119761921",
        "id" : 608983506119761921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRbRXIAET9-9.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZASByEx1Y4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ZASByEx1Y4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRhZWMAE4dIK.jpg",
        "id_str" : "608983507763867649",
        "id" : 608983507763867649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRhZWMAE4dIK.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZASByEx1Y4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Siberia61\/status\/608983545860747265\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ZASByEx1Y4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOLRiIW4AAmPP-.jpg",
        "id_str" : "608983507961044992",
        "id" : 608983507961044992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOLRiIW4AAmPP-.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZASByEx1Y4"
      } ],
      "hashtags" : [ {
        "text" : "swans",
        "indices" : [ 25, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608983545860747265",
    "text" : "Any chance of syncing Mr #swans ? ... Yes ...... Yes ...... Fabulous ! Thanks ! Ps bless you \uD83D\uDE00 http:\/\/t.co\/ZASByEx1Y4",
    "id" : 608983545860747265,
    "created_at" : "2015-06-11 13:06:06 +0000",
    "user" : {
      "name" : "pooks",
      "screen_name" : "Siberia61",
      "protected" : false,
      "id_str" : "1244239765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667649979863969792\/DP8gQLi6_normal.jpg",
      "id" : 1244239765,
      "verified" : false
    }
  },
  "id" : 608992164287234048,
  "created_at" : "2015-06-11 13:40:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "indices" : [ 3, 11 ],
      "id_str" : "250852478",
      "id" : 250852478
    }, {
      "name" : "Digital Journal",
      "screen_name" : "digitaljournal",
      "indices" : [ 102, 117 ],
      "id_str" : "15135567",
      "id" : 15135567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/KrcfDRbRTJ",
      "expanded_url" : "http:\/\/www.digitaljournal.com\/science\/experiment-shows-future-events-decide-what-happens-in-the-past\/article\/434829",
      "display_url" : "digitaljournal.com\/science\/experi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608810979015712769",
  "text" : "RT @jeczaja: Scientists show future events decide what happens in the past http:\/\/t.co\/KrcfDRbRTJ via @digitaljournal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Digital Journal",
        "screen_name" : "digitaljournal",
        "indices" : [ 89, 104 ],
        "id_str" : "15135567",
        "id" : 15135567
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/KrcfDRbRTJ",
        "expanded_url" : "http:\/\/www.digitaljournal.com\/science\/experiment-shows-future-events-decide-what-happens-in-the-past\/article\/434829",
        "display_url" : "digitaljournal.com\/science\/experi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608808912142225408",
    "text" : "Scientists show future events decide what happens in the past http:\/\/t.co\/KrcfDRbRTJ via @digitaljournal",
    "id" : 608808912142225408,
    "created_at" : "2015-06-11 01:32:10 +0000",
    "user" : {
      "name" : "Je' Czaja",
      "screen_name" : "jeczaja",
      "protected" : false,
      "id_str" : "250852478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545010686699393024\/wxdpPJoe_normal.jpeg",
      "id" : 250852478,
      "verified" : false
    }
  },
  "id" : 608810979015712769,
  "created_at" : "2015-06-11 01:40:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608802201755074560",
  "text" : "your concept of sin and my concept of sin are not the same, Franklin Graham \"Let\u2019s just stop doing business with those who promote sin..\"",
  "id" : 608802201755074560,
  "created_at" : "2015-06-11 01:05:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/xdT0dm4P8P",
      "expanded_url" : "http:\/\/bsl.io\/OJI4Yw",
      "display_url" : "bsl.io\/OJI4Yw"
    } ]
  },
  "geo" : { },
  "id_str" : "608778753968365568",
  "text" : "just weird, he \"taunts\"  &gt;&gt; Jim Bob Duggar Has a Gross Courting Habit http:\/\/t.co\/xdT0dm4P8P",
  "id" : 608778753968365568,
  "created_at" : "2015-06-10 23:32:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "indices" : [ 3, 18 ],
      "id_str" : "31986700",
      "id" : 31986700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608744738179690496",
  "text" : "RT @VeryShortStory: Perfect for each other, they lived a block apart, but would never meet. They lived in different worlds. His was Faceboo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608744401754550272",
    "text" : "Perfect for each other, they lived a block apart, but would never meet. They lived in different worlds. His was Facebook, hers was Twitter.",
    "id" : 608744401754550272,
    "created_at" : "2015-06-10 21:15:49 +0000",
    "user" : {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "protected" : false,
      "id_str" : "31986700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/141070636\/42291_normal.jpg",
      "id" : 31986700,
      "verified" : false
    }
  },
  "id" : 608744738179690496,
  "created_at" : "2015-06-10 21:17:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "neurotic",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608744557887516672",
  "text" : "its terrible when i want to scold DH for liking something on FB that I disagree with! #neurotic",
  "id" : 608744557887516672,
  "created_at" : "2015-06-10 21:16:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 3, 15 ],
      "id_str" : "298992506",
      "id" : 298992506
    }, {
      "name" : "Ian Steel",
      "screen_name" : "Snettisher",
      "indices" : [ 20, 31 ],
      "id_str" : "97523471",
      "id" : 97523471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608742029099679744",
  "text" : "RT @wildlife_uk: RT @Snettisher: Hidden among wildflowers alongside the path at RSPB Strumpshaw Fen, a mother pheasant tends her brood http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Steel",
        "screen_name" : "Snettisher",
        "indices" : [ 3, 14 ],
        "id_str" : "97523471",
        "id" : 97523471
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Snettisher\/status\/607647769193541632\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/tR1nt4jkYj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG7MbQJWQAAKKkM.jpg",
        "id_str" : "607647768304304128",
        "id" : 607647768304304128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG7MbQJWQAAKKkM.jpg",
        "sizes" : [ {
          "h" : 1085,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 794,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tR1nt4jkYj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608390643774320642",
    "text" : "RT @Snettisher: Hidden among wildflowers alongside the path at RSPB Strumpshaw Fen, a mother pheasant tends her brood http:\/\/t.co\/tR1nt4jkYj",
    "id" : 608390643774320642,
    "created_at" : "2015-06-09 21:50:07 +0000",
    "user" : {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "protected" : false,
      "id_str" : "298992506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543830606543478784\/DvQW3ag9_normal.png",
      "id" : 298992506,
      "verified" : false
    }
  },
  "id" : 608742029099679744,
  "created_at" : "2015-06-10 21:06:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "indices" : [ 3, 12 ],
      "id_str" : "265346131",
      "id" : 265346131
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/608740883207327744\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/wIXdexmdb6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHKumEoUwAAQSp0.jpg",
      "id_str" : "608740868749574144",
      "id" : 608740868749574144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHKumEoUwAAQSp0.jpg",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wIXdexmdb6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608741934555901955",
  "text" : "RT @iauaauoo: Tree of roost http:\/\/t.co\/wIXdexmdb6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iauaauoo\/status\/608740883207327744\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/wIXdexmdb6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHKumEoUwAAQSp0.jpg",
        "id_str" : "608740868749574144",
        "id" : 608740868749574144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHKumEoUwAAQSp0.jpg",
        "sizes" : [ {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wIXdexmdb6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608740883207327744",
    "text" : "Tree of roost http:\/\/t.co\/wIXdexmdb6",
    "id" : 608740883207327744,
    "created_at" : "2015-06-10 21:01:51 +0000",
    "user" : {
      "name" : "shim",
      "screen_name" : "iauaauoo",
      "protected" : false,
      "id_str" : "265346131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768291432213774336\/m7AAnnuF_normal.jpg",
      "id" : 265346131,
      "verified" : false
    }
  },
  "id" : 608741934555901955,
  "created_at" : "2015-06-10 21:06:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 14, 22 ]
    }, {
      "text" : "gluten",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608741415879868416",
  "text" : "reading about #thyroid issues.. see a mention of #gluten causing high TPO.. huh.",
  "id" : 608741415879868416,
  "created_at" : "2015-06-10 21:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lady Lorraine",
      "screen_name" : "GothGirl51",
      "indices" : [ 3, 14 ],
      "id_str" : "3036600698",
      "id" : 3036600698
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GothGirl51\/status\/608582406434603008\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Og2gF9f8N7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHIeeQaW8AA9rEB.jpg",
      "id_str" : "608582404798869504",
      "id" : 608582404798869504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHIeeQaW8AA9rEB.jpg",
      "sizes" : [ {
        "h" : 269,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2221,
        "resize" : "fit",
        "w" : 2809
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 810,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Og2gF9f8N7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608688484992323584",
  "text" : "RT @GothGirl51: Baby Greenfinch on my garden fence, just too cute :) http:\/\/t.co\/Og2gF9f8N7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GothGirl51\/status\/608582406434603008\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/Og2gF9f8N7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHIeeQaW8AA9rEB.jpg",
        "id_str" : "608582404798869504",
        "id" : 608582404798869504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHIeeQaW8AA9rEB.jpg",
        "sizes" : [ {
          "h" : 269,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2221,
          "resize" : "fit",
          "w" : 2809
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 810,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Og2gF9f8N7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608582406434603008",
    "text" : "Baby Greenfinch on my garden fence, just too cute :) http:\/\/t.co\/Og2gF9f8N7",
    "id" : 608582406434603008,
    "created_at" : "2015-06-10 10:32:07 +0000",
    "user" : {
      "name" : "Lady Lorraine",
      "screen_name" : "GothGirl51",
      "protected" : false,
      "id_str" : "3036600698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798615472405172224\/uykh9WSQ_normal.jpg",
      "id" : 3036600698,
      "verified" : false
    }
  },
  "id" : 608688484992323584,
  "created_at" : "2015-06-10 17:33:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug  Bursch",
      "screen_name" : "fairlyspiritual",
      "indices" : [ 0, 16 ],
      "id_str" : "24233147",
      "id" : 24233147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608682234141286401",
  "geo" : { },
  "id_str" : "608688136860921856",
  "in_reply_to_user_id" : 24233147,
  "text" : "@fairlyspiritual lol.. your tweet about changing from inside made me think of it and IMO exactly whats happening in politics.",
  "id" : 608688136860921856,
  "in_reply_to_status_id" : 608682234141286401,
  "created_at" : "2015-06-10 17:32:15 +0000",
  "in_reply_to_screen_name" : "fairlyspiritual",
  "in_reply_to_user_id_str" : "24233147",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/lQmolIhmv3",
      "expanded_url" : "https:\/\/twitter.com\/fairlyspiritual\/status\/608677604204281857",
      "display_url" : "twitter.com\/fairlyspiritua\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608681678899396608",
  "text" : "\"When fascism comes to America, it will be wrapped in the flag and carrying the cross.\" - Sinclair Lewis https:\/\/t.co\/lQmolIhmv3",
  "id" : 608681678899396608,
  "created_at" : "2015-06-10 17:06:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frogger",
      "screen_name" : "SillyFrogger",
      "indices" : [ 3, 16 ],
      "id_str" : "1117985780",
      "id" : 1117985780
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SillyFrogger\/status\/607890520518610944\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/lHQ96FG7M5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-pNQyUYAED9BF.jpg",
      "id_str" : "607890520027717633",
      "id" : 607890520027717633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-pNQyUYAED9BF.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/lHQ96FG7M5"
    } ],
    "hashtags" : [ {
      "text" : "kittyloafmonday",
      "indices" : [ 22, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608441923490181120",
  "text" : "RT @SillyFrogger: For #kittyloafmonday - me on some nice flannel blankets http:\/\/t.co\/lHQ96FG7M5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SillyFrogger\/status\/607890520518610944\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/lHQ96FG7M5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-pNQyUYAED9BF.jpg",
        "id_str" : "607890520027717633",
        "id" : 607890520027717633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-pNQyUYAED9BF.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/lHQ96FG7M5"
      } ],
      "hashtags" : [ {
        "text" : "kittyloafmonday",
        "indices" : [ 4, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607890520518610944",
    "text" : "For #kittyloafmonday - me on some nice flannel blankets http:\/\/t.co\/lHQ96FG7M5",
    "id" : 607890520518610944,
    "created_at" : "2015-06-08 12:42:48 +0000",
    "user" : {
      "name" : "Frogger",
      "screen_name" : "SillyFrogger",
      "protected" : false,
      "id_str" : "1117985780",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797805911158951936\/nOzjsmDV_normal.jpg",
      "id" : 1117985780,
      "verified" : false
    }
  },
  "id" : 608441923490181120,
  "created_at" : "2015-06-10 01:13:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/lF2bU1If8A",
      "expanded_url" : "http:\/\/www.phoenixmag.com\/People\/west-of-westboro.html",
      "display_url" : "phoenixmag.com\/People\/west-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608441437148057602",
  "text" : "literally turns my stomach... &gt;&gt; West of Westboro http:\/\/t.co\/lF2bU1If8A",
  "id" : 608441437148057602,
  "created_at" : "2015-06-10 01:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doris Montgomery",
      "screen_name" : "den_haven",
      "indices" : [ 0, 10 ],
      "id_str" : "702063298083053568",
      "id" : 702063298083053568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608406223172583425",
  "text" : "@den_haven oh my..lol.. love the pose. adorable.",
  "id" : 608406223172583425,
  "created_at" : "2015-06-09 22:52:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "audiobook",
      "indices" : [ 5, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/PSV4JkbzLt",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/A-Mur...\/dp\/B00YNRAQ50\/ref=sr_1_2",
      "display_url" : "amazon.co.uk\/A-Mur...\/dp\/B0\u2026"
    }, {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/GfwjJUOSio",
      "expanded_url" : "https:\/\/www.rafflecopter.com\/rafl\/display\/e949f9421\/",
      "display_url" : "rafflecopter.com\/rafl\/display\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608391625711185921",
  "text" : "#win #audiobook A Murderer's Heart  http:\/\/t.co\/PSV4JkbzLt \u2026...  https:\/\/t.co\/GfwjJUOSio",
  "id" : 608391625711185921,
  "created_at" : "2015-06-09 21:54:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Phillips",
      "screen_name" : "yodasworld",
      "indices" : [ 3, 14 ],
      "id_str" : "87992708",
      "id" : 87992708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/4UrCTsFWLq",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/2015\/06\/09\/jeb-bush-1995-book_n_7542964.html?ncid=txtlnkusaolp00000592",
      "display_url" : "huffingtonpost.com\/2015\/06\/09\/jeb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608350836113215490",
  "text" : "RT @yodasworld: Jeb Bush In 1995: Unwed Mothers Should Be Publicly Shamed http:\/\/t.co\/4UrCTsFWLq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/4UrCTsFWLq",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2015\/06\/09\/jeb-bush-1995-book_n_7542964.html?ncid=txtlnkusaolp00000592",
        "display_url" : "huffingtonpost.com\/2015\/06\/09\/jeb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608348951780163584",
    "text" : "Jeb Bush In 1995: Unwed Mothers Should Be Publicly Shamed http:\/\/t.co\/4UrCTsFWLq",
    "id" : 608348951780163584,
    "created_at" : "2015-06-09 19:04:27 +0000",
    "user" : {
      "name" : "David Phillips",
      "screen_name" : "yodasworld",
      "protected" : false,
      "id_str" : "87992708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2817611659\/43163bb8744658a23f371a3fd130fb75_normal.jpeg",
      "id" : 87992708,
      "verified" : false
    }
  },
  "id" : 608350836113215490,
  "created_at" : "2015-06-09 19:11:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607980875125551104",
  "geo" : { },
  "id_str" : "608347618612256768",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides nonononononono...",
  "id" : 608347618612256768,
  "in_reply_to_status_id" : 607980875125551104,
  "created_at" : "2015-06-09 18:59:09 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/608343037626982400\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/9jdaLodcVM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHFEwaNW0AEPKTp.jpg",
      "id_str" : "608343023131480065",
      "id" : 608343023131480065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHFEwaNW0AEPKTp.jpg",
      "sizes" : [ {
        "h" : 876,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 876,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9jdaLodcVM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608346047522439168",
  "text" : "RT @Salmonae1: Young Starling found a full cup. http:\/\/t.co\/9jdaLodcVM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/608343037626982400\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/9jdaLodcVM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHFEwaNW0AEPKTp.jpg",
        "id_str" : "608343023131480065",
        "id" : 608343023131480065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHFEwaNW0AEPKTp.jpg",
        "sizes" : [ {
          "h" : 876,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 876,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9jdaLodcVM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608343037626982400",
    "text" : "Young Starling found a full cup. http:\/\/t.co\/9jdaLodcVM",
    "id" : 608343037626982400,
    "created_at" : "2015-06-09 18:40:57 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 608346047522439168,
  "created_at" : "2015-06-09 18:52:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scully",
      "screen_name" : "ScullyNoreen",
      "indices" : [ 3, 16 ],
      "id_str" : "2288856122",
      "id" : 2288856122
    }, {
      "name" : "SeaWorld",
      "screen_name" : "SeaWorld",
      "indices" : [ 124, 133 ],
      "id_str" : "94618543",
      "id" : 94618543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608342216592007168",
  "text" : "RT @ScullyNoreen: Let them go home to the ocean or a \"sanctuary \" where they can be REAL Orcas again!\nNot performing clowns @SeaWorld! http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SeaWorld",
        "screen_name" : "SeaWorld",
        "indices" : [ 106, 115 ],
        "id_str" : "94618543",
        "id" : 94618543
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ScullyNoreen\/status\/607245830173519873\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/uNqOPnkEGc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG1e3LrU8AAls1d.jpg",
        "id_str" : "607245826885218304",
        "id" : 607245826885218304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG1e3LrU8AAls1d.jpg",
        "sizes" : [ {
          "h" : 543,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/uNqOPnkEGc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607245830173519873",
    "text" : "Let them go home to the ocean or a \"sanctuary \" where they can be REAL Orcas again!\nNot performing clowns @SeaWorld! http:\/\/t.co\/uNqOPnkEGc",
    "id" : 607245830173519873,
    "created_at" : "2015-06-06 18:01:02 +0000",
    "user" : {
      "name" : "scully",
      "screen_name" : "ScullyNoreen",
      "protected" : false,
      "id_str" : "2288856122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797690760652943360\/eedo8EHV_normal.jpg",
      "id" : 2288856122,
      "verified" : false
    }
  },
  "id" : 608342216592007168,
  "created_at" : "2015-06-09 18:37:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SM #2",
      "screen_name" : "MonetSays",
      "indices" : [ 3, 13 ],
      "id_str" : "234140722",
      "id" : 234140722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/m2LF996gyd",
      "expanded_url" : "https:\/\/twitter.com\/shaunking\/status\/608321838020739072",
      "display_url" : "twitter.com\/shaunking\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608325494308794368",
  "text" : "RT @MonetSays: Shanks \uD83D\uDE33 https:\/\/t.co\/m2LF996gyd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 32 ],
        "url" : "https:\/\/t.co\/m2LF996gyd",
        "expanded_url" : "https:\/\/twitter.com\/shaunking\/status\/608321838020739072",
        "display_url" : "twitter.com\/shaunking\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608323676589719553",
    "text" : "Shanks \uD83D\uDE33 https:\/\/t.co\/m2LF996gyd",
    "id" : 608323676589719553,
    "created_at" : "2015-06-09 17:24:01 +0000",
    "user" : {
      "name" : "SM #2",
      "screen_name" : "MonetSays",
      "protected" : false,
      "id_str" : "234140722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794588147514482688\/k9ccnJcv_normal.jpg",
      "id" : 234140722,
      "verified" : false
    }
  },
  "id" : 608325494308794368,
  "created_at" : "2015-06-09 17:31:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608037466776444928",
  "text" : "i told her maybe we could take a yoga class together. thats supposed 2B good for calming.",
  "id" : 608037466776444928,
  "created_at" : "2015-06-08 22:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anxiety",
      "indices" : [ 17, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608037189893685248",
  "text" : "she's always had #anxiety but I didn't realize the extent of it. poor kid. i just want her 2B happy, healthy.",
  "id" : 608037189893685248,
  "created_at" : "2015-06-08 22:25:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608034327839043584",
  "geo" : { },
  "id_str" : "608035242826469377",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides that was the other thing she felt far away and pinches felt dull (B4 any drugs).. had ativan,zofran.",
  "id" : 608035242826469377,
  "in_reply_to_status_id" : 608034327839043584,
  "created_at" : "2015-06-08 22:17:53 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hallucinations",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608034000440053760",
  "text" : "I forgot.. she said she felt something breathe on her and that I was a scary dark figure the night before. so fear? pain? #hallucinations",
  "id" : 608034000440053760,
  "created_at" : "2015-06-08 22:12:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608031449812467714",
  "text" : "i think the \"excitement\" caught up w me. my tum is feeling a bit off now.",
  "id" : 608031449812467714,
  "created_at" : "2015-06-08 22:02:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ativan",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608031024388440064",
  "text" : "forgot to mention.. DD was hallucinating while we were at ER on Sat. maybe it was the #ativan ? gloves on wall turned into creatures.",
  "id" : 608031024388440064,
  "created_at" : "2015-06-08 22:01:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Martin",
      "screen_name" : "TRMartin",
      "indices" : [ 3, 12 ],
      "id_str" : "23612342",
      "id" : 23612342
    }, {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 14, 28 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607978312535834624",
  "text" : "RT @TRMartin: @BrianRathbone:Beyond grateful to Wales &amp;Dr, Gillian. heartbroken at how I've been treated by the system here.Dead already if\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fantasy Author",
        "screen_name" : "BrianRathbone",
        "indices" : [ 0, 14 ],
        "id_str" : "16494321",
        "id" : 16494321
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "607972869545455616",
    "geo" : { },
    "id_str" : "607974878596210689",
    "in_reply_to_user_id" : 16494321,
    "text" : "@BrianRathbone:Beyond grateful to Wales &amp;Dr, Gillian. heartbroken at how I've been treated by the system here.Dead already if not for Wales",
    "id" : 607974878596210689,
    "in_reply_to_status_id" : 607972869545455616,
    "created_at" : "2015-06-08 18:18:01 +0000",
    "in_reply_to_screen_name" : "BrianRathbone",
    "in_reply_to_user_id_str" : "16494321",
    "user" : {
      "name" : "Tiffany Martin",
      "screen_name" : "TRMartin",
      "protected" : false,
      "id_str" : "23612342",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798902936629899265\/X208vI54_normal.jpg",
      "id" : 23612342,
      "verified" : false
    }
  },
  "id" : 607978312535834624,
  "created_at" : "2015-06-08 18:31:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/522442355526213632\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/zS8gtyOwOL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0AWjd7CQAAZ685.jpg",
      "id_str" : "522442355358449664",
      "id" : 522442355358449664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0AWjd7CQAAZ685.jpg",
      "sizes" : [ {
        "h" : 503,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 472,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zS8gtyOwOL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607976922832896000",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/zS8gtyOwOL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/522442355526213632\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/zS8gtyOwOL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0AWjd7CQAAZ685.jpg",
        "id_str" : "522442355358449664",
        "id" : 522442355358449664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0AWjd7CQAAZ685.jpg",
        "sizes" : [ {
          "h" : 503,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 503,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 472,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zS8gtyOwOL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607975395800043520",
    "text" : "http:\/\/t.co\/zS8gtyOwOL",
    "id" : 607975395800043520,
    "created_at" : "2015-06-08 18:20:04 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 607976922832896000,
  "created_at" : "2015-06-08 18:26:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "indices" : [ 3, 15 ],
      "id_str" : "21833728",
      "id" : 21833728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/pO3380qRZG",
      "expanded_url" : "http:\/\/reverbpress.com\/news\/jim-bob-duggar-molestation-common-christian-families-video\/",
      "display_url" : "reverbpress.com\/news\/jim-bob-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607976873801490432",
  "text" : "RT @Brasilmagic: Jim Bob Duggar: Molestation Is Common In Christian Families  http:\/\/t.co\/pO3380qRZG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/pO3380qRZG",
        "expanded_url" : "http:\/\/reverbpress.com\/news\/jim-bob-duggar-molestation-common-christian-families-video\/",
        "display_url" : "reverbpress.com\/news\/jim-bob-d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "607951013388156928",
    "text" : "Jim Bob Duggar: Molestation Is Common In Christian Families  http:\/\/t.co\/pO3380qRZG",
    "id" : 607951013388156928,
    "created_at" : "2015-06-08 16:43:11 +0000",
    "user" : {
      "name" : "Brasilmagic",
      "screen_name" : "Brasilmagic",
      "protected" : false,
      "id_str" : "21833728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789894919787679744\/CXf0r3bi_normal.jpg",
      "id" : 21833728,
      "verified" : false
    }
  },
  "id" : 607976873801490432,
  "created_at" : "2015-06-08 18:25:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607976566065364992",
  "text" : "RT @RustBeltRebel: if a kid isn't sitting down like they were told to, police get to shoot them? is that how it works now?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "607976126405709824",
    "geo" : { },
    "id_str" : "607976351669174274",
    "in_reply_to_user_id" : 2382724914,
    "text" : "if a kid isn't sitting down like they were told to, police get to shoot them? is that how it works now?",
    "id" : 607976351669174274,
    "in_reply_to_status_id" : 607976126405709824,
    "created_at" : "2015-06-08 18:23:52 +0000",
    "in_reply_to_screen_name" : "RustBeltRebel",
    "in_reply_to_user_id_str" : "2382724914",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 607976566065364992,
  "created_at" : "2015-06-08 18:24:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/6e3Ie8UNTu",
      "expanded_url" : "https:\/\/www.evernote.com\/shard\/s462\/sh\/d4637853-fb3e-404f-b2ee-4c650564b3e1\/31d83ddd99f2b414253a1e8452a75d6a",
      "display_url" : "evernote.com\/shard\/s462\/sh\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607951838973960193",
  "text" : "#thyroid labs - DD - started levothyroxine today 25mg Hope it helps https:\/\/t.co\/6e3Ie8UNTu",
  "id" : 607951838973960193,
  "created_at" : "2015-06-08 16:46:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Quinn",
      "screen_name" : "poemblaze",
      "indices" : [ 3, 13 ],
      "id_str" : "114232355",
      "id" : 114232355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tanka",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "micropoetry",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607903304803360768",
  "text" : "RT @poemblaze: The world alive\nwith so many voices--\nsongbirds\nand mourning \ndoves.\n\n#tanka #micropoetry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tanka",
        "indices" : [ 70, 76 ]
      }, {
        "text" : "micropoetry",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607520092033708033",
    "text" : "The world alive\nwith so many voices--\nsongbirds\nand mourning \ndoves.\n\n#tanka #micropoetry",
    "id" : 607520092033708033,
    "created_at" : "2015-06-07 12:10:51 +0000",
    "user" : {
      "name" : "Matt Quinn",
      "screen_name" : "poemblaze",
      "protected" : false,
      "id_str" : "114232355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771370130898944000\/UHCpJF-N_normal.jpg",
      "id" : 114232355,
      "verified" : false
    }
  },
  "id" : 607903304803360768,
  "created_at" : "2015-06-08 13:33:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "indices" : [ 3, 16 ],
      "id_str" : "256540769",
      "id" : 256540769
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HarryShannon\/status\/607899049191022593\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/xxUMQYV30Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-w8-EUAAAFt4s.jpg",
      "id_str" : "607899036218032128",
      "id" : 607899036218032128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-w8-EUAAAFt4s.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xxUMQYV30Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607902987248369664",
  "text" : "RT @HarryShannon: Yawn. Good morning. http:\/\/t.co\/xxUMQYV30Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HarryShannon\/status\/607899049191022593\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/xxUMQYV30Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-w8-EUAAAFt4s.jpg",
        "id_str" : "607899036218032128",
        "id" : 607899036218032128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-w8-EUAAAFt4s.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/xxUMQYV30Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607899049191022593",
    "text" : "Yawn. Good morning. http:\/\/t.co\/xxUMQYV30Y",
    "id" : 607899049191022593,
    "created_at" : "2015-06-08 13:16:42 +0000",
    "user" : {
      "name" : "Harry Shannon",
      "screen_name" : "HarryShannon",
      "protected" : false,
      "id_str" : "256540769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798645625289965568\/8ai82ECm_normal.jpg",
      "id" : 256540769,
      "verified" : false
    }
  },
  "id" : 607902987248369664,
  "created_at" : "2015-06-08 13:32:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Clarke",
      "screen_name" : "Mr_Mike_Clarke",
      "indices" : [ 3, 18 ],
      "id_str" : "19768990",
      "id" : 19768990
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Mr_Mike_Clarke\/status\/607894542755504128\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/sXqKSiDuea",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-s3W3WQAAmCGH.jpg",
      "id_str" : "607894541748813824",
      "id" : 607894541748813824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-s3W3WQAAmCGH.jpg",
      "sizes" : [ {
        "h" : 706,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 545
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 545
      } ],
      "display_url" : "pic.twitter.com\/sXqKSiDuea"
    } ],
    "hashtags" : [ {
      "text" : "WorldOceansDay",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607902796793413633",
  "text" : "RT @Mr_Mike_Clarke: The most epic high-five you'll ever see! \n \n#WorldOceansDay http:\/\/t.co\/sXqKSiDuea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Mr_Mike_Clarke\/status\/607894542755504128\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/sXqKSiDuea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-s3W3WQAAmCGH.jpg",
        "id_str" : "607894541748813824",
        "id" : 607894541748813824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-s3W3WQAAmCGH.jpg",
        "sizes" : [ {
          "h" : 706,
          "resize" : "fit",
          "w" : 545
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 706,
          "resize" : "fit",
          "w" : 545
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 706,
          "resize" : "fit",
          "w" : 545
        } ],
        "display_url" : "pic.twitter.com\/sXqKSiDuea"
      } ],
      "hashtags" : [ {
        "text" : "WorldOceansDay",
        "indices" : [ 44, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607894542755504128",
    "text" : "The most epic high-five you'll ever see! \n \n#WorldOceansDay http:\/\/t.co\/sXqKSiDuea",
    "id" : 607894542755504128,
    "created_at" : "2015-06-08 12:58:47 +0000",
    "user" : {
      "name" : "Michael Clarke",
      "screen_name" : "Mr_Mike_Clarke",
      "protected" : false,
      "id_str" : "19768990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755456702552674305\/Pc7ciPL3_normal.jpg",
      "id" : 19768990,
      "verified" : false
    }
  },
  "id" : 607902796793413633,
  "created_at" : "2015-06-08 13:31:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "audiobook",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/PSV4JkbzLt",
      "expanded_url" : "http:\/\/www.amazon.co.uk\/A-Mur...\/dp\/B00YNRAQ50\/ref=sr_1_2",
      "display_url" : "amazon.co.uk\/A-Mur...\/dp\/B0\u2026"
    }, {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/GfwjJUOSio",
      "expanded_url" : "https:\/\/www.rafflecopter.com\/rafl\/display\/e949f9421\/",
      "display_url" : "rafflecopter.com\/rafl\/display\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607895383738597376",
  "text" : "#audiobook A Murderer's Heart  http:\/\/t.co\/PSV4JkbzLt \u2026...  https:\/\/t.co\/GfwjJUOSio",
  "id" : 607895383738597376,
  "created_at" : "2015-06-08 13:02:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "indices" : [ 3, 17 ],
      "id_str" : "2191061814",
      "id" : 2191061814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "McKinney",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607668811781840897",
  "text" : "RT @Irish_Atheist: You call yourself the freest nation on earth and then you treat your black children like livestock. #McKinney",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "McKinney",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607664834323349504",
    "text" : "You call yourself the freest nation on earth and then you treat your black children like livestock. #McKinney",
    "id" : 607664834323349504,
    "created_at" : "2015-06-07 21:46:01 +0000",
    "user" : {
      "name" : "The Irish Atheist",
      "screen_name" : "Irish_Atheist",
      "protected" : false,
      "id_str" : "2191061814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000732092966\/d824b28f36a408810e110fd95fff4519_normal.jpeg",
      "id" : 2191061814,
      "verified" : false
    }
  },
  "id" : 607668811781840897,
  "created_at" : "2015-06-07 22:01:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "indices" : [ 3, 15 ],
      "id_str" : "19791234",
      "id" : 19791234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607648096617676801",
  "text" : "RT @Emperor_Bob: Pool Party Turns Violent When Police Show Up and Assault and Nearly Shoot Multiple Teens: \nThe disturbing inci... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/cvmLq5JV2U",
        "expanded_url" : "http:\/\/bit.ly\/1IvV5zf",
        "display_url" : "bit.ly\/1IvV5zf"
      } ]
    },
    "geo" : { },
    "id_str" : "607643861540675584",
    "text" : "Pool Party Turns Violent When Police Show Up and Assault and Nearly Shoot Multiple Teens: \nThe disturbing inci... http:\/\/t.co\/cvmLq5JV2U",
    "id" : 607643861540675584,
    "created_at" : "2015-06-07 20:22:40 +0000",
    "user" : {
      "name" : "Robert Cortez",
      "screen_name" : "Emperor_Bob",
      "protected" : false,
      "id_str" : "19791234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3352084632\/6ebf06ce559f48c77c691cb928fc62ab_normal.png",
      "id" : 19791234,
      "verified" : false
    }
  },
  "id" : 607648096617676801,
  "created_at" : "2015-06-07 20:39:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/607645007005282305\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/QqxpE2EZ6t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG7J6bTXEAAQFEr.jpg",
      "id_str" : "607645005340151808",
      "id" : 607645005340151808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG7J6bTXEAAQFEr.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/QqxpE2EZ6t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607645782515322881",
  "text" : "RT @CUMALi_YILDIZ: Dukes Pass, Trossachs..\n.By ViewBug member david mould http:\/\/t.co\/QqxpE2EZ6t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/607645007005282305\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/QqxpE2EZ6t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CG7J6bTXEAAQFEr.jpg",
        "id_str" : "607645005340151808",
        "id" : 607645005340151808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG7J6bTXEAAQFEr.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/QqxpE2EZ6t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607645007005282305",
    "text" : "Dukes Pass, Trossachs..\n.By ViewBug member david mould http:\/\/t.co\/QqxpE2EZ6t",
    "id" : 607645007005282305,
    "created_at" : "2015-06-07 20:27:13 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 607645782515322881,
  "created_at" : "2015-06-07 20:30:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607601933029908481",
  "geo" : { },
  "id_str" : "607613189417803776",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre ive been hearing that from ppl w thyroid issues. kinda makes sense w hormones involved.",
  "id" : 607613189417803776,
  "in_reply_to_status_id" : 607601933029908481,
  "created_at" : "2015-06-07 18:20:47 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Feldman",
      "screen_name" : "UnseelieMe",
      "indices" : [ 0, 11 ],
      "id_str" : "92123740",
      "id" : 92123740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607596951589253120",
  "geo" : { },
  "id_str" : "607600893320667137",
  "in_reply_to_user_id" : 92123740,
  "text" : "@UnseelieMe she's starting on synthroid. hope that will help get her sorted. my poor girl. im glad DR thought to do thyroid test.",
  "id" : 607600893320667137,
  "in_reply_to_status_id" : 607596951589253120,
  "created_at" : "2015-06-07 17:31:56 +0000",
  "in_reply_to_screen_name" : "UnseelieMe",
  "in_reply_to_user_id_str" : "92123740",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/moosebegab\/status\/607594304811462656\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/5cFPqo0Mkh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG6bzN0WcAEKEc4.jpg",
      "id_str" : "607594303926464513",
      "id" : 607594303926464513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG6bzN0WcAEKEc4.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5cFPqo0Mkh"
    } ],
    "hashtags" : [ {
      "text" : "thyroid",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607594304811462656",
  "text" : "#thyroid numbers for DD. Possibly contributing to recent panics, nausea. http:\/\/t.co\/5cFPqo0Mkh",
  "id" : 607594304811462656,
  "created_at" : "2015-06-07 17:05:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "607579655927951361",
  "geo" : { },
  "id_str" : "607588091910619136",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem oh no.. DD's been sick recently like that. No proper dx yet but panic attack may be part. Hope you feel better soon!",
  "id" : 607588091910619136,
  "in_reply_to_status_id" : 607579655927951361,
  "created_at" : "2015-06-07 16:41:04 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    }, {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 32, 43 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607340161723191296",
  "text" : "RT @JohnFugelsang: They tell me @SenSanders can't win b\/c America won't vote for a Socialist Jew.  I tell them America celebrates a Sociali\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Sanders",
        "screen_name" : "SenSanders",
        "indices" : [ 13, 24 ],
        "id_str" : "29442313",
        "id" : 29442313
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606121057343414272",
    "text" : "They tell me @SenSanders can't win b\/c America won't vote for a Socialist Jew.  I tell them America celebrates a Socialist Jew every Dec 25.",
    "id" : 606121057343414272,
    "created_at" : "2015-06-03 15:31:35 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 607340161723191296,
  "created_at" : "2015-06-07 00:15:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607294261432877058",
  "text" : "Home again. DD konked out on ativan and zorfan.",
  "id" : 607294261432877058,
  "created_at" : "2015-06-06 21:13:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607249910531035136",
  "text" : "Spending day in ER with DD",
  "id" : 607249910531035136,
  "created_at" : "2015-06-06 18:17:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sertraline",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606996539282759681",
  "text" : "Poor kid puked up #sertraline and now having panic attack.. : (",
  "id" : 606996539282759681,
  "created_at" : "2015-06-06 01:30:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/6vg9PyqbwI",
      "expanded_url" : "https:\/\/twitter.com\/wildwitchyju\/status\/606944090803064834",
      "display_url" : "twitter.com\/wildwitchyju\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606944494433529856",
  "text" : "pretty. looks like flowers. https:\/\/t.co\/6vg9PyqbwI",
  "id" : 606944494433529856,
  "created_at" : "2015-06-05 22:03:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/5mrXtfQJCO",
      "expanded_url" : "https:\/\/twitter.com\/jabinks846\/status\/606783236979752960",
      "display_url" : "twitter.com\/jabinks846\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606925281597759488",
  "text" : "im jealous! :D https:\/\/t.co\/5mrXtfQJCO",
  "id" : 606925281597759488,
  "created_at" : "2015-06-05 20:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Handbasket",
      "screen_name" : "PhyllisCopeland",
      "indices" : [ 3, 19 ],
      "id_str" : "456236531",
      "id" : 456236531
    }, {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 22, 35 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/502372315427262464\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Gj6ntz1uUD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvjI9YUIcAElyUA.jpg",
      "id_str" : "502372315276275713",
      "id" : 502372315276275713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvjI9YUIcAElyUA.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Gj6ntz1uUD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606924806173401088",
  "text" : "RT @PhyllisCopeland: \u201C@Elverojaguar: http:\/\/t.co\/Gj6ntz1uUD\u201D\n\n\"Hey, Robbie! Check it out - someone set out a couple of sleeping bags up her\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Cult Cat",
        "screen_name" : "Elverojaguar",
        "indices" : [ 1, 14 ],
        "id_str" : "580857186",
        "id" : 580857186
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/502372315427262464\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/Gj6ntz1uUD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvjI9YUIcAElyUA.jpg",
        "id_str" : "502372315276275713",
        "id" : 502372315276275713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvjI9YUIcAElyUA.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/Gj6ntz1uUD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "606917245273538560",
    "geo" : { },
    "id_str" : "606924132438163456",
    "in_reply_to_user_id" : 580857186,
    "text" : "\u201C@Elverojaguar: http:\/\/t.co\/Gj6ntz1uUD\u201D\n\n\"Hey, Robbie! Check it out - someone set out a couple of sleeping bags up here!\"",
    "id" : 606924132438163456,
    "in_reply_to_status_id" : 606917245273538560,
    "created_at" : "2015-06-05 20:42:43 +0000",
    "in_reply_to_screen_name" : "Elverojaguar",
    "in_reply_to_user_id_str" : "580857186",
    "user" : {
      "name" : "Helena Handbasket",
      "screen_name" : "PhyllisCopeland",
      "protected" : false,
      "id_str" : "456236531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422034415401717760\/IAWHgsPN_normal.jpeg",
      "id" : 456236531,
      "verified" : false
    }
  },
  "id" : 606924806173401088,
  "created_at" : "2015-06-05 20:45:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "indices" : [ 3, 10 ],
      "id_str" : "6872302",
      "id" : 6872302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/jXmWPscEYo",
      "expanded_url" : "http:\/\/goo.gl\/fb\/IuZJqa",
      "display_url" : "goo.gl\/fb\/IuZJqa"
    } ]
  },
  "geo" : { },
  "id_str" : "606916586121908225",
  "text" : "RT @Mahala: More Than One Mama Bear Can Take http:\/\/t.co\/jXmWPscEYo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/jXmWPscEYo",
        "expanded_url" : "http:\/\/goo.gl\/fb\/IuZJqa",
        "display_url" : "goo.gl\/fb\/IuZJqa"
      } ]
    },
    "geo" : { },
    "id_str" : "606901167109464065",
    "text" : "More Than One Mama Bear Can Take http:\/\/t.co\/jXmWPscEYo",
    "id" : 606901167109464065,
    "created_at" : "2015-06-05 19:11:28 +0000",
    "user" : {
      "name" : "Mahala",
      "screen_name" : "Mahala",
      "protected" : false,
      "id_str" : "6872302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/577710645\/pigtails_normal.jpg",
      "id" : 6872302,
      "verified" : false
    }
  },
  "id" : 606916586121908225,
  "created_at" : "2015-06-05 20:12:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzy Taylor",
      "screen_name" : "FolkArtPapercut",
      "indices" : [ 3, 19 ],
      "id_str" : "110760690",
      "id" : 110760690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606901497033551872",
  "text" : "RT @FolkArtPapercut: No.  I don't use computers, I don't fold, I don't use rubber stamps.  Hand-drawn and hand-cut - always! http:\/\/t.co\/Os\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FolkArtPapercut\/status\/523100879365632001\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/OsMtaIyJdK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0JtegpCQAEu8wf.jpg",
        "id_str" : "523100877653950465",
        "id" : 523100877653950465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0JtegpCQAEu8wf.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/OsMtaIyJdK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523100879365632001",
    "text" : "No.  I don't use computers, I don't fold, I don't use rubber stamps.  Hand-drawn and hand-cut - always! http:\/\/t.co\/OsMtaIyJdK",
    "id" : 523100879365632001,
    "created_at" : "2014-10-17 13:19:03 +0000",
    "user" : {
      "name" : "Suzy Taylor",
      "screen_name" : "FolkArtPapercut",
      "protected" : false,
      "id_str" : "110760690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643693004730036224\/Ej6hJf0p_normal.jpg",
      "id" : 110760690,
      "verified" : false
    }
  },
  "id" : 606901497033551872,
  "created_at" : "2015-06-05 19:12:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bored Panda",
      "screen_name" : "boredpanda",
      "indices" : [ 3, 14 ],
      "id_str" : "59627487",
      "id" : 59627487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/XZ4Z4BxomP",
      "expanded_url" : "http:\/\/www.boredpanda.com\/paper-cut-folk-art-suzy-taylor\/",
      "display_url" : "boredpanda.com\/paper-cut-folk\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606900759960162304",
  "text" : "RT @boredpanda: Artist Hand-Cuts Insanely Intricate Paper Art From Single Sheets Of Paper (27 pics): http:\/\/t.co\/XZ4Z4BxomP http:\/\/t.co\/7bd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/boredpanda\/status\/606897885486161920\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/7bd3Mbc15O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGwiaRgW8AE6j5K.jpg",
        "id_str" : "606897884559241217",
        "id" : 606897884559241217,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGwiaRgW8AE6j5K.jpg",
        "sizes" : [ {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7bd3Mbc15O"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/XZ4Z4BxomP",
        "expanded_url" : "http:\/\/www.boredpanda.com\/paper-cut-folk-art-suzy-taylor\/",
        "display_url" : "boredpanda.com\/paper-cut-folk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606897885486161920",
    "text" : "Artist Hand-Cuts Insanely Intricate Paper Art From Single Sheets Of Paper (27 pics): http:\/\/t.co\/XZ4Z4BxomP http:\/\/t.co\/7bd3Mbc15O",
    "id" : 606897885486161920,
    "created_at" : "2015-06-05 18:58:26 +0000",
    "user" : {
      "name" : "Bored Panda",
      "screen_name" : "boredpanda",
      "protected" : false,
      "id_str" : "59627487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485712694964518912\/KFezSCjG_normal.jpeg",
      "id" : 59627487,
      "verified" : false
    }
  },
  "id" : 606900759960162304,
  "created_at" : "2015-06-05 19:09:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenkers News (ENG)",
      "screen_name" : "jenkers_en",
      "indices" : [ 3, 14 ],
      "id_str" : "3096702665",
      "id" : 3096702665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/DtSXelPjyo",
      "expanded_url" : "http:\/\/jenke.rs\/Zu03Hz",
      "display_url" : "jenke.rs\/Zu03Hz"
    } ]
  },
  "geo" : { },
  "id_str" : "606896777971810304",
  "text" : "RT @jenkers_en: Orphaned moose killed: Camper disturbed as officials kill and blow-up baby moose http:\/\/t.co\/DtSXelPjyo http:\/\/t.co\/rYq1yP7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/jenkers.com\/en\" rel=\"nofollow\"\u003EJenkers Eng Posting\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jenkers_en\/status\/606614970424565760\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/rYq1yP7g3m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGshGVAUAAATQnb.jpg",
        "id_str" : "606614967412850688",
        "id" : 606614967412850688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGshGVAUAAATQnb.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 502
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 502
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 502
        } ],
        "display_url" : "pic.twitter.com\/rYq1yP7g3m"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/DtSXelPjyo",
        "expanded_url" : "http:\/\/jenke.rs\/Zu03Hz",
        "display_url" : "jenke.rs\/Zu03Hz"
      } ]
    },
    "geo" : { },
    "id_str" : "606614970424565760",
    "text" : "Orphaned moose killed: Camper disturbed as officials kill and blow-up baby moose http:\/\/t.co\/DtSXelPjyo http:\/\/t.co\/rYq1yP7g3m",
    "id" : 606614970424565760,
    "created_at" : "2015-06-05 00:14:13 +0000",
    "user" : {
      "name" : "Jenkers News (ENG)",
      "screen_name" : "jenkers_en",
      "protected" : false,
      "id_str" : "3096702665",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588324718677254145\/-y5BbeY4_normal.png",
      "id" : 3096702665,
      "verified" : false
    }
  },
  "id" : 606896777971810304,
  "created_at" : "2015-06-05 18:54:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606883717710245888",
  "text" : "RT @Charmantides: Is there any way in windows of seeing the last usb device you connected\/ list of devices sorted by time connected? Having\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606883413920989184",
    "text" : "Is there any way in windows of seeing the last usb device you connected\/ list of devices sorted by time connected? Having usb problems.",
    "id" : 606883413920989184,
    "created_at" : "2015-06-05 18:00:55 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 606883717710245888,
  "created_at" : "2015-06-05 18:02:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OMGFacts\/status\/501209653418926083\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/sX6S4uz2ul",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvSnhimIEAAuJqc.jpg",
      "id_str" : "501209653209206784",
      "id" : 501209653209206784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvSnhimIEAAuJqc.jpg",
      "sizes" : [ {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/sX6S4uz2ul"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606883149876985856",
  "text" : "RT @OMGFacts: A raft full of Newfoundland dogs... being pulled by a single Newfoundland. http:\/\/t.co\/sX6S4uz2ul",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OMGFacts\/status\/501209653418926083\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/sX6S4uz2ul",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvSnhimIEAAuJqc.jpg",
        "id_str" : "501209653209206784",
        "id" : 501209653209206784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvSnhimIEAAuJqc.jpg",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sX6S4uz2ul"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606879455542431744",
    "text" : "A raft full of Newfoundland dogs... being pulled by a single Newfoundland. http:\/\/t.co\/sX6S4uz2ul",
    "id" : 606879455542431744,
    "created_at" : "2015-06-05 17:45:12 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 606883149876985856,
  "created_at" : "2015-06-05 17:59:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/606852269238157312\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/rio1WKkpF4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGv45LfUgAAoUBr.jpg",
      "id_str" : "606852236031852544",
      "id" : 606852236031852544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGv45LfUgAAoUBr.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rio1WKkpF4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/606852269238157312\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/rio1WKkpF4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGv45N9VIAA3HAm.jpg",
      "id_str" : "606852236694593536",
      "id" : 606852236694593536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGv45N9VIAA3HAm.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rio1WKkpF4"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 33, 39 ]
    }, {
      "text" : "RockyMountains",
      "indices" : [ 40, 55 ]
    }, {
      "text" : "Colorado",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606881722865745921",
  "text" : "RT @rm123077: Clark's Nutcracker #birds #RockyMountains #Colorado http:\/\/t.co\/rio1WKkpF4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/606852269238157312\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/rio1WKkpF4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGv45LfUgAAoUBr.jpg",
        "id_str" : "606852236031852544",
        "id" : 606852236031852544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGv45LfUgAAoUBr.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rio1WKkpF4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/606852269238157312\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/rio1WKkpF4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGv45N9VIAA3HAm.jpg",
        "id_str" : "606852236694593536",
        "id" : 606852236694593536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGv45N9VIAA3HAm.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rio1WKkpF4"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 19, 25 ]
      }, {
        "text" : "RockyMountains",
        "indices" : [ 26, 41 ]
      }, {
        "text" : "Colorado",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606852269238157312",
    "text" : "Clark's Nutcracker #birds #RockyMountains #Colorado http:\/\/t.co\/rio1WKkpF4",
    "id" : 606852269238157312,
    "created_at" : "2015-06-05 15:57:10 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 606881722865745921,
  "created_at" : "2015-06-05 17:54:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/fnZXcq2irh",
      "expanded_url" : "https:\/\/www.thedodo.com\/duck-greet-boy-1172907672.html",
      "display_url" : "thedodo.com\/duck-greet-boy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606872357165236224",
  "text" : "precious! &gt;&gt; This duck couldn't be happier to see his little human home from school https:\/\/t.co\/fnZXcq2irh",
  "id" : 606872357165236224,
  "created_at" : "2015-06-05 17:16:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snorklhuahua",
      "screen_name" : "weinerdog4life",
      "indices" : [ 3, 18 ],
      "id_str" : "189238523",
      "id" : 189238523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606833074668765185",
  "text" : "RT @weinerdog4life: I say potato you say potato, another guy says potato, everyone starts chanting potato, the potato meeting was a huge su\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604899675208966144",
    "text" : "I say potato you say potato, another guy says potato, everyone starts chanting potato, the potato meeting was a huge success",
    "id" : 604899675208966144,
    "created_at" : "2015-05-31 06:38:15 +0000",
    "user" : {
      "name" : "Snorklhuahua",
      "screen_name" : "weinerdog4life",
      "protected" : false,
      "id_str" : "189238523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613835563863375872\/SwUrfTYo_normal.jpg",
      "id" : 189238523,
      "verified" : false
    }
  },
  "id" : 606833074668765185,
  "created_at" : "2015-06-05 14:40:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Hohulin",
      "screen_name" : "TayHoho",
      "indices" : [ 3, 11 ],
      "id_str" : "118951770",
      "id" : 118951770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606832295169900544",
  "text" : "RT @TayHoho: Idea: Fund your presidential candidacy with Kickstarter. Backers get cool perks like free bumper stickers and a sleepover in t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606526642442371072",
    "text" : "Idea: Fund your presidential candidacy with Kickstarter. Backers get cool perks like free bumper stickers and a sleepover in the Oval Office",
    "id" : 606526642442371072,
    "created_at" : "2015-06-04 18:23:14 +0000",
    "user" : {
      "name" : "Taylor Hohulin",
      "screen_name" : "TayHoho",
      "protected" : false,
      "id_str" : "118951770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674482065685929985\/zjOgh8Dz_normal.jpg",
      "id" : 118951770,
      "verified" : false
    }
  },
  "id" : 606832295169900544,
  "created_at" : "2015-06-05 14:37:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606830615992913920",
  "text" : "DD has anxiety which results in nausea, upset stomach. she also got meds for stomach acid.",
  "id" : 606830615992913920,
  "created_at" : "2015-06-05 14:31:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606829436701450241",
  "text" : "im on effexor if i skip a pill, im gen down on the floor sick. takes up to a week to get normal. im terrified to subject my DD to this.",
  "id" : 606829436701450241,
  "created_at" : "2015-06-05 14:26:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606828314335055872",
  "text" : "ok peeps.. anyone familiar w sertraline? doc rx'd for DD. she said it was gentler than others, wldnt cause withdrawal acc skipping a pill.",
  "id" : 606828314335055872,
  "created_at" : "2015-06-05 14:21:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/FhjJBSBf7d",
      "expanded_url" : "http:\/\/q4lt.com\/making-a-case-for-the-impossible-1",
      "display_url" : "q4lt.com\/making-a-case-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606624232022417409",
  "text" : "ATP, melatonin and living without food.. interesting &gt;&gt; Making a Case for the \u201CImpossible\u201D http:\/\/t.co\/FhjJBSBf7d",
  "id" : 606624232022417409,
  "created_at" : "2015-06-05 00:51:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/sr03LWs4DX",
      "expanded_url" : "https:\/\/youtu.be\/VzDNLA-IjmU",
      "display_url" : "youtu.be\/VzDNLA-IjmU"
    } ]
  },
  "geo" : { },
  "id_str" : "606612150300372994",
  "text" : "\"it's a recipe for incest\" (2011) quiverfull of it - fundie baby factories https:\/\/t.co\/sr03LWs4DX",
  "id" : 606612150300372994,
  "created_at" : "2015-06-05 00:03:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "606483807571574785",
  "geo" : { },
  "id_str" : "606485222851530752",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time you just made me laugh and I needed that after watching that video! ((hugs))",
  "id" : 606485222851530752,
  "in_reply_to_status_id" : 606483807571574785,
  "created_at" : "2015-06-04 15:38:39 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/tRWF00NpYQ",
      "expanded_url" : "http:\/\/ow.ly\/NS2V4",
      "display_url" : "ow.ly\/NS2V4"
    } ]
  },
  "geo" : { },
  "id_str" : "606482915858481152",
  "text" : "RT @ChickenJen: Welcome to Sovereign, Maine. Welcome home. http:\/\/t.co\/tRWF00NpYQ FREE eBook download today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/tRWF00NpYQ",
        "expanded_url" : "http:\/\/ow.ly\/NS2V4",
        "display_url" : "ow.ly\/NS2V4"
      } ]
    },
    "geo" : { },
    "id_str" : "606479541423480832",
    "text" : "Welcome to Sovereign, Maine. Welcome home. http:\/\/t.co\/tRWF00NpYQ FREE eBook download today.",
    "id" : 606479541423480832,
    "created_at" : "2015-06-04 15:16:05 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 606482915858481152,
  "created_at" : "2015-06-04 15:29:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "indices" : [ 3, 17 ],
      "id_str" : "3230864579",
      "id" : 3230864579
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vabirdlibrary",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606482802016710656",
  "text" : "RT @Library4birds: Ma'am, your hold seems to have been picked up by another Lady Finch. She looked just like you. #vabirdlibrary http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Library4birds\/status\/606478908997910528\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/duaml4tQk4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGqlWpLUQAAxRNO.jpg",
        "id_str" : "606478908263776256",
        "id" : 606478908263776256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGqlWpLUQAAxRNO.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/duaml4tQk4"
      } ],
      "hashtags" : [ {
        "text" : "vabirdlibrary",
        "indices" : [ 95, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606478908997910528",
    "text" : "Ma'am, your hold seems to have been picked up by another Lady Finch. She looked just like you. #vabirdlibrary http:\/\/t.co\/duaml4tQk4",
    "id" : 606478908997910528,
    "created_at" : "2015-06-04 15:13:34 +0000",
    "user" : {
      "name" : "Bird Library",
      "screen_name" : "Library4birds",
      "protected" : false,
      "id_str" : "3230864579",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716692683918422017\/966rSZ_f_normal.jpg",
      "id" : 3230864579,
      "verified" : false
    }
  },
  "id" : 606482802016710656,
  "created_at" : "2015-06-04 15:29:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oogie McGuire",
      "screen_name" : "OogieM",
      "indices" : [ 3, 10 ],
      "id_str" : "23070873",
      "id" : 23070873
    }, {
      "name" : "Gareth Wyn Jones",
      "screen_name" : "1GarethWynJones",
      "indices" : [ 103, 119 ],
      "id_str" : "79968923",
      "id" : 79968923
    }, {
      "name" : "BBC",
      "screen_name" : "BBC",
      "indices" : [ 120, 124 ],
      "id_str" : "19701628",
      "id" : 19701628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606481216636874752",
  "text" : "RT @OogieM: Come on Folks can't we pay to see this? Internet makes us all neighbors why limit viewing? @1GarethWynJones @BBC http:\/\/t.co\/Z7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gareth Wyn Jones",
        "screen_name" : "1GarethWynJones",
        "indices" : [ 91, 107 ],
        "id_str" : "79968923",
        "id" : 79968923
      }, {
        "name" : "BBC",
        "screen_name" : "BBC",
        "indices" : [ 108, 112 ],
        "id_str" : "19701628",
        "id" : 19701628
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OogieM\/status\/606438380818173954\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Z7GGkuCILY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGqAflhVAAItJLu.png",
        "id_str" : "606438379970953218",
        "id" : 606438379970953218,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGqAflhVAAItJLu.png",
        "sizes" : [ {
          "h" : 592,
          "resize" : "fit",
          "w" : 881
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 881
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Z7GGkuCILY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "606427233868238850",
    "geo" : { },
    "id_str" : "606438380818173954",
    "in_reply_to_user_id" : 79968923,
    "text" : "Come on Folks can't we pay to see this? Internet makes us all neighbors why limit viewing? @1GarethWynJones @BBC http:\/\/t.co\/Z7GGkuCILY",
    "id" : 606438380818173954,
    "in_reply_to_status_id" : 606427233868238850,
    "created_at" : "2015-06-04 12:32:31 +0000",
    "in_reply_to_screen_name" : "1GarethWynJones",
    "in_reply_to_user_id_str" : "79968923",
    "user" : {
      "name" : "Oogie McGuire",
      "screen_name" : "OogieM",
      "protected" : false,
      "id_str" : "23070873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/91941397\/SDIM0271_square_normal.jpg",
      "id" : 23070873,
      "verified" : false
    }
  },
  "id" : 606481216636874752,
  "created_at" : "2015-06-04 15:22:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606480329180880896",
  "text" : "a fucking bandage aint gonna help, jerk. and handcuffs? really? yelling \"stay with me\" is that for show? wtf is going on out there??",
  "id" : 606480329180880896,
  "created_at" : "2015-06-04 15:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Union",
      "screen_name" : "itsgabrielleu",
      "indices" : [ 3, 17 ],
      "id_str" : "256881576",
      "id" : 256881576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/V3D6Gnyhnr",
      "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/606471460702580736",
      "display_url" : "twitter.com\/ShaunKing\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606479138870988800",
  "text" : "RT @itsgabrielleu: No words...  https:\/\/t.co\/V3D6Gnyhnr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 36 ],
        "url" : "https:\/\/t.co\/V3D6Gnyhnr",
        "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/status\/606471460702580736",
        "display_url" : "twitter.com\/ShaunKing\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606474597756739584",
    "text" : "No words...  https:\/\/t.co\/V3D6Gnyhnr",
    "id" : 606474597756739584,
    "created_at" : "2015-06-04 14:56:26 +0000",
    "user" : {
      "name" : "Gabrielle Union",
      "screen_name" : "itsgabrielleu",
      "protected" : false,
      "id_str" : "256881576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672068677211172864\/2EAoEgP1_normal.jpg",
      "id" : 256881576,
      "verified" : true
    }
  },
  "id" : 606479138870988800,
  "created_at" : "2015-06-04 15:14:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/C2SZlzlvZo",
      "expanded_url" : "https:\/\/news.virginia.edu\/content\/researchers-find-textbook-altering-link-between-brain-immune-system",
      "display_url" : "news.virginia.edu\/content\/resear\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606190717283745793",
  "text" : "RT @SciencePorn: Researchers find novel link between brain, immune system, with major disease implications https:\/\/t.co\/C2SZlzlvZo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/C2SZlzlvZo",
        "expanded_url" : "https:\/\/news.virginia.edu\/content\/researchers-find-textbook-altering-link-between-brain-immune-system",
        "display_url" : "news.virginia.edu\/content\/resear\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606167296294436864",
    "text" : "Researchers find novel link between brain, immune system, with major disease implications https:\/\/t.co\/C2SZlzlvZo",
    "id" : 606167296294436864,
    "created_at" : "2015-06-03 18:35:20 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 606190717283745793,
  "created_at" : "2015-06-03 20:08:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "indices" : [ 3, 18 ],
      "id_str" : "1323776491",
      "id" : 1323776491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606180246505844736",
  "text" : "RT @humblethinker1: For the mimetic theorist when does the self begin to exist? Pre birth? Post birth?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "606179276774178816",
    "geo" : { },
    "id_str" : "606179582899716096",
    "in_reply_to_user_id" : 1323776491,
    "text" : "For the mimetic theorist when does the self begin to exist? Pre birth? Post birth?",
    "id" : 606179582899716096,
    "in_reply_to_status_id" : 606179276774178816,
    "created_at" : "2015-06-03 19:24:09 +0000",
    "in_reply_to_screen_name" : "humblethinker1",
    "in_reply_to_user_id_str" : "1323776491",
    "user" : {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "protected" : false,
      "id_str" : "1323776491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744730630085173249\/ApIVKrhX_normal.jpg",
      "id" : 1323776491,
      "verified" : false
    }
  },
  "id" : 606180246505844736,
  "created_at" : "2015-06-03 19:26:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "indices" : [ 3, 18 ],
      "id_str" : "1323776491",
      "id" : 1323776491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606180119896592384",
  "text" : "RT @humblethinker1: &gt;&gt;\"It is desire that engenders the self and causes it to exist.\" What?What!?&gt;&gt;",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "606178181503053824",
    "geo" : { },
    "id_str" : "606178785617010688",
    "in_reply_to_user_id" : 1323776491,
    "text" : "&gt;&gt;\"It is desire that engenders the self and causes it to exist.\" What?What!?&gt;&gt;",
    "id" : 606178785617010688,
    "in_reply_to_status_id" : 606178181503053824,
    "created_at" : "2015-06-03 19:20:59 +0000",
    "in_reply_to_screen_name" : "humblethinker1",
    "in_reply_to_user_id_str" : "1323776491",
    "user" : {
      "name" : "humblethinker",
      "screen_name" : "humblethinker1",
      "protected" : false,
      "id_str" : "1323776491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744730630085173249\/ApIVKrhX_normal.jpg",
      "id" : 1323776491,
      "verified" : false
    }
  },
  "id" : 606180119896592384,
  "created_at" : "2015-06-03 19:26:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606168338880991232",
  "text" : "@Lluminous_ not a DC fan? I actually like the #woo : )",
  "id" : 606168338880991232,
  "created_at" : "2015-06-03 18:39:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/wIMMBXy3s0",
      "expanded_url" : "https:\/\/www.doesthedogdie.com\/",
      "display_url" : "doesthedogdie.com"
    } ]
  },
  "geo" : { },
  "id_str" : "606109096413171712",
  "text" : "RT @adampknave: Wanna know if a dog dies in the movie you're about to watch? Here's a handy resource: https:\/\/t.co\/wIMMBXy3s0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/wIMMBXy3s0",
        "expanded_url" : "https:\/\/www.doesthedogdie.com\/",
        "display_url" : "doesthedogdie.com"
      } ]
    },
    "geo" : { },
    "id_str" : "606108213671378944",
    "text" : "Wanna know if a dog dies in the movie you're about to watch? Here's a handy resource: https:\/\/t.co\/wIMMBXy3s0",
    "id" : 606108213671378944,
    "created_at" : "2015-06-03 14:40:33 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 606109096413171712,
  "created_at" : "2015-06-03 14:44:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "H",
      "screen_name" : "countrymousie",
      "indices" : [ 3, 17 ],
      "id_str" : "112481274",
      "id" : 112481274
    }, {
      "name" : "Suffolk Owls",
      "screen_name" : "suffolkowls",
      "indices" : [ 77, 89 ],
      "id_str" : "34614237",
      "id" : 34614237
    }, {
      "name" : "BBC Springwatch",
      "screen_name" : "BBCSpringwatch",
      "indices" : [ 99, 114 ],
      "id_str" : "71229689",
      "id" : 71229689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wallettes",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "Suffolk",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "tearful",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606108810223226880",
  "text" : "RT @countrymousie: Today I visited the orphaned little owlets  #Wallettes at @suffolkowls #Suffolk @BBCSpringwatch ..#tearful moment http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Suffolk Owls",
        "screen_name" : "suffolkowls",
        "indices" : [ 58, 70 ],
        "id_str" : "34614237",
        "id" : 34614237
      }, {
        "name" : "BBC Springwatch",
        "screen_name" : "BBCSpringwatch",
        "indices" : [ 80, 95 ],
        "id_str" : "71229689",
        "id" : 71229689
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/countrymousie\/status\/606047632826466305\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/ZvxX3QcW7f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGkdASsWgAIW38B.jpg",
        "id_str" : "606047515713110018",
        "id" : 606047515713110018,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGkdASsWgAIW38B.jpg",
        "sizes" : [ {
          "h" : 1126,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 528,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 299,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZvxX3QcW7f"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/countrymousie\/status\/606047632826466305\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/ZvxX3QcW7f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGkdG-cXIAAj54_.jpg",
        "id_str" : "606047630536417280",
        "id" : 606047630536417280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGkdG-cXIAAj54_.jpg",
        "sizes" : [ {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1068,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 854,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZvxX3QcW7f"
      } ],
      "hashtags" : [ {
        "text" : "Wallettes",
        "indices" : [ 44, 54 ]
      }, {
        "text" : "Suffolk",
        "indices" : [ 71, 79 ]
      }, {
        "text" : "tearful",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606047632826466305",
    "text" : "Today I visited the orphaned little owlets  #Wallettes at @suffolkowls #Suffolk @BBCSpringwatch ..#tearful moment http:\/\/t.co\/ZvxX3QcW7f",
    "id" : 606047632826466305,
    "created_at" : "2015-06-03 10:39:50 +0000",
    "user" : {
      "name" : "H",
      "screen_name" : "countrymousie",
      "protected" : false,
      "id_str" : "112481274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781439858053087232\/Dq3N5hbi_normal.jpg",
      "id" : 112481274,
      "verified" : false
    }
  },
  "id" : 606108810223226880,
  "created_at" : "2015-06-03 14:42:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danarchist",
      "screen_name" : "RelUnrelated",
      "indices" : [ 3, 16 ],
      "id_str" : "50666280",
      "id" : 50666280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606107935626952704",
  "text" : "RT @RelUnrelated: Why are so many people concerned with the sexuality of people they aren't having sex with?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605458899144015872",
    "text" : "Why are so many people concerned with the sexuality of people they aren't having sex with?",
    "id" : 605458899144015872,
    "created_at" : "2015-06-01 19:40:25 +0000",
    "user" : {
      "name" : "Danarchist",
      "screen_name" : "RelUnrelated",
      "protected" : false,
      "id_str" : "50666280",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795441979362594816\/upE0CyC4_normal.jpg",
      "id" : 50666280,
      "verified" : false
    }
  },
  "id" : 606107935626952704,
  "created_at" : "2015-06-03 14:39:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn H",
      "screen_name" : "Dawnh1253",
      "indices" : [ 3, 13 ],
      "id_str" : "238335003",
      "id" : 238335003
    }, {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 15, 27 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Dawnh1253\/status\/606092250863570944\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LC0XHN482m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGlFrSWWQAApPqC.jpg",
      "id_str" : "606092234820304896",
      "id" : 606092234820304896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGlFrSWWQAApPqC.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LC0XHN482m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606107191729397762",
  "text" : "RT @Dawnh1253: @ErinEFarley Nearly finished the hat Erin, I've been lucky no little knots! \uD83D\uDE00\uD83D\uDC4D http:\/\/t.co\/LC0XHN482m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Erin Farley",
        "screen_name" : "ErinEFarley",
        "indices" : [ 0, 12 ],
        "id_str" : "1305052615",
        "id" : 1305052615
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dawnh1253\/status\/606092250863570944\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/LC0XHN482m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGlFrSWWQAApPqC.jpg",
        "id_str" : "606092234820304896",
        "id" : 606092234820304896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGlFrSWWQAApPqC.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LC0XHN482m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606092250863570944",
    "in_reply_to_user_id" : 1305052615,
    "text" : "@ErinEFarley Nearly finished the hat Erin, I've been lucky no little knots! \uD83D\uDE00\uD83D\uDC4D http:\/\/t.co\/LC0XHN482m",
    "id" : 606092250863570944,
    "created_at" : "2015-06-03 13:37:07 +0000",
    "in_reply_to_screen_name" : "ErinEFarley",
    "in_reply_to_user_id_str" : "1305052615",
    "user" : {
      "name" : "Dawn H",
      "screen_name" : "Dawnh1253",
      "protected" : false,
      "id_str" : "238335003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675815535272153089\/Ci7XwEsE_normal.jpg",
      "id" : 238335003,
      "verified" : false
    }
  },
  "id" : 606107191729397762,
  "created_at" : "2015-06-03 14:36:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetiumapp.com\" rel=\"nofollow\"\u003ETweetium for Windows\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Farley",
      "screen_name" : "ErinEFarley",
      "indices" : [ 0, 12 ],
      "id_str" : "1305052615",
      "id" : 1305052615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605948742051708928",
  "geo" : { },
  "id_str" : "606106949747404800",
  "in_reply_to_user_id" : 1305052615,
  "text" : "@ErinEFarley thumbs up!",
  "id" : 606106949747404800,
  "in_reply_to_status_id" : 605948742051708928,
  "created_at" : "2015-06-03 14:35:32 +0000",
  "in_reply_to_screen_name" : "ErinEFarley",
  "in_reply_to_user_id_str" : "1305052615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religion",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "feedly",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/qh6tvDeN3F",
      "expanded_url" : "http:\/\/www.flyinginthespirit.cuttys.net\/2015\/06\/03\/book-review-by-david-matthew-disarming-scripture-by-derek-flood\/",
      "display_url" : "flyinginthespirit.cuttys.net\/2015\/06\/03\/boo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606101869136592896",
  "text" : "Book review by David Matthew \u2013 \u2018Disarming Scripture\u2019 by Derek Flood http:\/\/t.co\/qh6tvDeN3F #religion #feedly",
  "id" : 606101869136592896,
  "created_at" : "2015-06-03 14:15:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam S. McHugh",
      "screen_name" : "adamsmchugh",
      "indices" : [ 3, 15 ],
      "id_str" : "59503007",
      "id" : 59503007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605882327277797376",
  "text" : "RT @adamsmchugh: Introverts aren't antisocial. We're selectively social. So if we devote a lot of energy to you, it means we value you very\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454063622843400192",
    "text" : "Introverts aren't antisocial. We're selectively social. So if we devote a lot of energy to you, it means we value you very highly.",
    "id" : 454063622843400192,
    "created_at" : "2014-04-10 01:09:38 +0000",
    "user" : {
      "name" : "Adam S. McHugh",
      "screen_name" : "adamsmchugh",
      "protected" : false,
      "id_str" : "59503007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784630344934944768\/72Sfp9d__normal.jpg",
      "id" : 59503007,
      "verified" : false
    }
  },
  "id" : 605882327277797376,
  "created_at" : "2015-06-02 23:42:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vine",
      "screen_name" : "vine",
      "indices" : [ 3, 8 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/V3e00tM5aU",
      "expanded_url" : "https:\/\/vine.co\/v\/eK5hrtP6ZFL",
      "display_url" : "vine.co\/v\/eK5hrtP6ZFL"
    } ]
  },
  "geo" : { },
  "id_str" : "605861171623653379",
  "text" : "RT @vine: Baby screech owl https:\/\/t.co\/V3e00tM5aU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 40 ],
        "url" : "https:\/\/t.co\/V3e00tM5aU",
        "expanded_url" : "https:\/\/vine.co\/v\/eK5hrtP6ZFL",
        "display_url" : "vine.co\/v\/eK5hrtP6ZFL"
      } ]
    },
    "geo" : { },
    "id_str" : "605860319282364416",
    "text" : "Baby screech owl https:\/\/t.co\/V3e00tM5aU",
    "id" : 605860319282364416,
    "created_at" : "2015-06-02 22:15:31 +0000",
    "user" : {
      "name" : "Vine",
      "screen_name" : "vine",
      "protected" : false,
      "id_str" : "586671909",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748904410504425473\/s7HNVSYF_normal.jpg",
      "id" : 586671909,
      "verified" : true
    }
  },
  "id" : 605861171623653379,
  "created_at" : "2015-06-02 22:18:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/v9WaRVQAGI",
      "expanded_url" : "http:\/\/tallgirlinback.com\/rant\/teen-sex-education-through-their-eyes\/",
      "display_url" : "tallgirlinback.com\/rant\/teen-sex-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605847673971707904",
  "text" : "too controversial, not allowed to speak.. &gt;&gt; Teen Sex Education Through Their Eyes http:\/\/t.co\/v9WaRVQAGI",
  "id" : 605847673971707904,
  "created_at" : "2015-06-02 21:25:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "indices" : [ 0, 15 ],
      "id_str" : "17376893",
      "id" : 17376893
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 16, 28 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605732993727123456",
  "geo" : { },
  "id_str" : "605788657652396034",
  "in_reply_to_user_id" : 17376893,
  "text" : "@RightWingWatch @VirgoJohnny actually.. He's correct. Destroy the old thinking, birth the new! Yay!",
  "id" : 605788657652396034,
  "in_reply_to_status_id" : 605732993727123456,
  "created_at" : "2015-06-02 17:30:45 +0000",
  "in_reply_to_screen_name" : "RightWingWatch",
  "in_reply_to_user_id_str" : "17376893",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    }, {
      "name" : "BBC Springwatch",
      "screen_name" : "BBCSpringwatch",
      "indices" : [ 90, 105 ],
      "id_str" : "71229689",
      "id" : 71229689
    }, {
      "name" : "BTO Garden BirdWatch",
      "screen_name" : "BTO_GBW",
      "indices" : [ 106, 114 ],
      "id_str" : "31802395",
      "id" : 31802395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CDWG",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "Springwatch",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605454637219639296",
  "text" : "RT @CamoDave_: Live cam capture- Woodpigeon sat on its nest in the very windy #CDWG today @BBCSpringwatch @BTO_GBW #Springwatch http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BBC Springwatch",
        "screen_name" : "BBCSpringwatch",
        "indices" : [ 75, 90 ],
        "id_str" : "71229689",
        "id" : 71229689
      }, {
        "name" : "BTO Garden BirdWatch",
        "screen_name" : "BTO_GBW",
        "indices" : [ 91, 99 ],
        "id_str" : "31802395",
        "id" : 31802395
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/605452906767261696\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/guOTH2bGPF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGcANXbWwAAbFqE.jpg",
        "id_str" : "605452904531673088",
        "id" : 605452904531673088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGcANXbWwAAbFqE.jpg",
        "sizes" : [ {
          "h" : 1079,
          "resize" : "fit",
          "w" : 1473
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/guOTH2bGPF"
      } ],
      "hashtags" : [ {
        "text" : "CDWG",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "Springwatch",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605452906767261696",
    "text" : "Live cam capture- Woodpigeon sat on its nest in the very windy #CDWG today @BBCSpringwatch @BTO_GBW #Springwatch http:\/\/t.co\/guOTH2bGPF",
    "id" : 605452906767261696,
    "created_at" : "2015-06-01 19:16:36 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 605454637219639296,
  "created_at" : "2015-06-01 19:23:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "indices" : [ 0, 15 ],
      "id_str" : "17376893",
      "id" : 17376893
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 16, 28 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605439634101792768",
  "geo" : { },
  "id_str" : "605454568210710528",
  "in_reply_to_user_id" : 17376893,
  "text" : "@RightWingWatch @VirgoJohnny *roll my eyes so hard they pop out!*",
  "id" : 605454568210710528,
  "in_reply_to_status_id" : 605439634101792768,
  "created_at" : "2015-06-01 19:23:12 +0000",
  "in_reply_to_screen_name" : "RightWingWatch",
  "in_reply_to_user_id_str" : "17376893",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bjz photographs",
      "screen_name" : "BarbieTweetings",
      "indices" : [ 3, 19 ],
      "id_str" : "128747619",
      "id" : 128747619
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BarbieTweetings\/status\/604807020596719616\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/LxutyObQ9A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGS0x9NUYAAtDtu.jpg",
      "id_str" : "604807020311502848",
      "id" : 604807020311502848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGS0x9NUYAAtDtu.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LxutyObQ9A"
    } ],
    "hashtags" : [ {
      "text" : "ducks",
      "indices" : [ 38, 44 ]
    }, {
      "text" : "flowers",
      "indices" : [ 47, 55 ]
    }, {
      "text" : "Monet",
      "indices" : [ 57, 63 ]
    }, {
      "text" : "botanicalgardens",
      "indices" : [ 65, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605453549833723905",
  "text" : "RT @BarbieTweetings: Water lilies and #ducks ~ #flowers  #Monet  #botanicalgardens http:\/\/t.co\/LxutyObQ9A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BarbieTweetings\/status\/604807020596719616\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/LxutyObQ9A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGS0x9NUYAAtDtu.jpg",
        "id_str" : "604807020311502848",
        "id" : 604807020311502848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGS0x9NUYAAtDtu.jpg",
        "sizes" : [ {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LxutyObQ9A"
      } ],
      "hashtags" : [ {
        "text" : "ducks",
        "indices" : [ 17, 23 ]
      }, {
        "text" : "flowers",
        "indices" : [ 26, 34 ]
      }, {
        "text" : "Monet",
        "indices" : [ 36, 42 ]
      }, {
        "text" : "botanicalgardens",
        "indices" : [ 44, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604807020596719616",
    "text" : "Water lilies and #ducks ~ #flowers  #Monet  #botanicalgardens http:\/\/t.co\/LxutyObQ9A",
    "id" : 604807020596719616,
    "created_at" : "2015-05-31 00:30:05 +0000",
    "user" : {
      "name" : "bjz photographs",
      "screen_name" : "BarbieTweetings",
      "protected" : false,
      "id_str" : "128747619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788534140974960640\/HI84Dqm3_normal.jpg",
      "id" : 128747619,
      "verified" : false
    }
  },
  "id" : 605453549833723905,
  "created_at" : "2015-06-01 19:19:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523956948417257472\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/WNkEwlCFvf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0V4EYCCAAA7rQO.jpg",
      "id_str" : "523956948224311296",
      "id" : 523956948224311296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0V4EYCCAAA7rQO.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 474
      } ],
      "display_url" : "pic.twitter.com\/WNkEwlCFvf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605453222938087424",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/WNkEwlCFvf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/523956948417257472\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/WNkEwlCFvf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0V4EYCCAAA7rQO.jpg",
        "id_str" : "523956948224311296",
        "id" : 523956948224311296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0V4EYCCAAA7rQO.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 474
        } ],
        "display_url" : "pic.twitter.com\/WNkEwlCFvf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605434969247387648",
    "text" : "http:\/\/t.co\/WNkEwlCFvf",
    "id" : 605434969247387648,
    "created_at" : "2015-06-01 18:05:19 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 605453222938087424,
  "created_at" : "2015-06-01 19:17:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "indices" : [ 3, 13 ],
      "id_str" : "1137173257",
      "id" : 1137173257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/605434144278126592\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/L1zqkDyXRX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbvIGoWwAADXHa.jpg",
      "id_str" : "605434122425778176",
      "id" : 605434122425778176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbvIGoWwAADXHa.jpg",
      "sizes" : [ {
        "h" : 514,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 878,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 878,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L1zqkDyXRX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605452539010686976",
  "text" : "RT @Salmonae1: Young Starling looking where the seed was coming from. http:\/\/t.co\/L1zqkDyXRX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Salmonae1\/status\/605434144278126592\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/L1zqkDyXRX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbvIGoWwAADXHa.jpg",
        "id_str" : "605434122425778176",
        "id" : 605434122425778176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbvIGoWwAADXHa.jpg",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 878,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 878,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/L1zqkDyXRX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605434144278126592",
    "text" : "Young Starling looking where the seed was coming from. http:\/\/t.co\/L1zqkDyXRX",
    "id" : 605434144278126592,
    "created_at" : "2015-06-01 18:02:03 +0000",
    "user" : {
      "name" : "Cliff Slater",
      "screen_name" : "Salmonae1",
      "protected" : false,
      "id_str" : "1137173257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3188297432\/292de522ac8902ba802b265ed039ae86_normal.jpeg",
      "id" : 1137173257,
      "verified" : false
    }
  },
  "id" : 605452539010686976,
  "created_at" : "2015-06-01 19:15:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "605423469841522691",
  "geo" : { },
  "id_str" : "605441652069670912",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides lol.. that was creepy how it just showed up.",
  "id" : 605441652069670912,
  "in_reply_to_status_id" : 605423469841522691,
  "created_at" : "2015-06-01 18:31:53 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/605423579975532544\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/FMiJ7MdBUP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGblicsWcAAHvQd.jpg",
      "id_str" : "605423579908435968",
      "id" : 605423579908435968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGblicsWcAAHvQd.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/FMiJ7MdBUP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605441413191475200",
  "text" : "RT @Elverojaguar: \uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E http:\/\/t.co\/FMiJ7MdBUP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/605423579975532544\/photo\/1",
        "indices" : [ 10, 32 ],
        "url" : "http:\/\/t.co\/FMiJ7MdBUP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGblicsWcAAHvQd.jpg",
        "id_str" : "605423579908435968",
        "id" : 605423579908435968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGblicsWcAAHvQd.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/FMiJ7MdBUP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605423579975532544",
    "text" : "\uD83D\uDC3E\uD83D\uDE38\uD83D\uDC3E\uD83D\uDE39\uD83D\uDC3E\uD83D\uDE3A\uD83D\uDC3E\uD83D\uDE3B\uD83D\uDC3E http:\/\/t.co\/FMiJ7MdBUP",
    "id" : 605423579975532544,
    "created_at" : "2015-06-01 17:20:04 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 605441413191475200,
  "created_at" : "2015-06-01 18:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605426885238091776",
  "text" : "RT @worldtreeman: generations of fear based teachings and responses...we have a lot to undo dear travellers of conscious evolution",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605420888390004736",
    "text" : "generations of fear based teachings and responses...we have a lot to undo dear travellers of conscious evolution",
    "id" : 605420888390004736,
    "created_at" : "2015-06-01 17:09:22 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 605426885238091776,
  "created_at" : "2015-06-01 17:33:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NTRangerJaneL",
      "screen_name" : "LancasterJane13",
      "indices" : [ 3, 19 ],
      "id_str" : "637191127",
      "id" : 637191127
    }, {
      "name" : "North East NT",
      "screen_name" : "NorthEastNT",
      "indices" : [ 50, 62 ],
      "id_str" : "312074337",
      "id" : 312074337
    }, {
      "name" : "Northumberland Coast",
      "screen_name" : "Northumb_Coast",
      "indices" : [ 102, 117 ],
      "id_str" : "430831812",
      "id" : 430831812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Summer",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605426355115835393",
  "text" : "RT @LancasterJane13: \"Wooly Bear\" catterpillar at @NorthEastNT Druridge Bay today - Tiger Moth family @Northumb_Coast #Summer http:\/\/t.co\/v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "North East NT",
        "screen_name" : "NorthEastNT",
        "indices" : [ 29, 41 ],
        "id_str" : "312074337",
        "id" : 312074337
      }, {
        "name" : "Northumberland Coast",
        "screen_name" : "Northumb_Coast",
        "indices" : [ 81, 96 ],
        "id_str" : "430831812",
        "id" : 430831812
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LancasterJane13\/status\/605421728458620930\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/vy1oROZbgI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbj2AXXEAA3SyK.jpg",
        "id_str" : "605421716878331904",
        "id" : 605421716878331904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbj2AXXEAA3SyK.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vy1oROZbgI"
      } ],
      "hashtags" : [ {
        "text" : "Summer",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605421728458620930",
    "text" : "\"Wooly Bear\" catterpillar at @NorthEastNT Druridge Bay today - Tiger Moth family @Northumb_Coast #Summer http:\/\/t.co\/vy1oROZbgI",
    "id" : 605421728458620930,
    "created_at" : "2015-06-01 17:12:42 +0000",
    "user" : {
      "name" : "NTRangerJaneL",
      "screen_name" : "LancasterJane13",
      "protected" : false,
      "id_str" : "637191127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795634006226108416\/79lj6k1R_normal.jpg",
      "id" : 637191127,
      "verified" : false
    }
  },
  "id" : 605426355115835393,
  "created_at" : "2015-06-01 17:31:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura B.",
      "screen_name" : "ABBestphotos",
      "indices" : [ 3, 16 ],
      "id_str" : "963523560",
      "id" : 963523560
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/XwD3btAhU4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8_TUcAASWop.jpg",
      "id_str" : "605400946131103744",
      "id" : 605400946131103744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8_TUcAASWop.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 895
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 895
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XwD3btAhU4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/XwD3btAhU4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8ejUYAAjbEp.jpg",
      "id_str" : "605400937339838464",
      "id" : 605400937339838464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8ejUYAAjbEp.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XwD3btAhU4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/XwD3btAhU4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8wiU8AAz1S8.jpg",
      "id_str" : "605400942167519232",
      "id" : 605400942167519232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8wiU8AAz1S8.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 517
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XwD3btAhU4"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/XwD3btAhU4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8tlUgAAjyb3.jpg",
      "id_str" : "605400941374767104",
      "id" : 605400941374767104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8tlUgAAjyb3.jpg",
      "sizes" : [ {
        "h" : 766,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 326,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/XwD3btAhU4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605425949019111424",
  "text" : "RT @ABBestphotos: Thanks May, you were more than I could have asked for! Way more. Couples month :) http:\/\/t.co\/XwD3btAhU4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/XwD3btAhU4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8_TUcAASWop.jpg",
        "id_str" : "605400946131103744",
        "id" : 605400946131103744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8_TUcAASWop.jpg",
        "sizes" : [ {
          "h" : 1100,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XwD3btAhU4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/XwD3btAhU4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8ejUYAAjbEp.jpg",
        "id_str" : "605400937339838464",
        "id" : 605400937339838464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8ejUYAAjbEp.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XwD3btAhU4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/XwD3btAhU4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8wiU8AAz1S8.jpg",
        "id_str" : "605400942167519232",
        "id" : 605400942167519232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8wiU8AAz1S8.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 517
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XwD3btAhU4"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/ABBestphotos\/status\/605400946965774336\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/XwD3btAhU4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbQ8tlUgAAjyb3.jpg",
        "id_str" : "605400941374767104",
        "id" : 605400941374767104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbQ8tlUgAAjyb3.jpg",
        "sizes" : [ {
          "h" : 766,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/XwD3btAhU4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605400946965774336",
    "text" : "Thanks May, you were more than I could have asked for! Way more. Couples month :) http:\/\/t.co\/XwD3btAhU4",
    "id" : 605400946965774336,
    "created_at" : "2015-06-01 15:50:08 +0000",
    "user" : {
      "name" : "Laura B.",
      "screen_name" : "ABBestphotos",
      "protected" : false,
      "id_str" : "963523560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762858708418244608\/qL1VkoJh_normal.jpg",
      "id" : 963523560,
      "verified" : false
    }
  },
  "id" : 605425949019111424,
  "created_at" : "2015-06-01 17:29:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hex maniac michael",
      "screen_name" : "hecksmaniac",
      "indices" : [ 3, 15 ],
      "id_str" : "44296522",
      "id" : 44296522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605425149047906304",
  "text" : "RT @hecksmaniac: I do want to put out a reminder that folks who can't\/don't transition w\/medical aid still deserve to have their gender res\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605422557022425089",
    "text" : "I do want to put out a reminder that folks who can't\/don't transition w\/medical aid still deserve to have their gender respected.",
    "id" : 605422557022425089,
    "created_at" : "2015-06-01 17:16:00 +0000",
    "user" : {
      "name" : "hex maniac michael",
      "screen_name" : "hecksmaniac",
      "protected" : false,
      "id_str" : "44296522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769248680985567232\/IrtecnjE_normal.jpg",
      "id" : 44296522,
      "verified" : false
    }
  },
  "id" : 605425149047906304,
  "created_at" : "2015-06-01 17:26:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "indices" : [ 3, 18 ],
      "id_str" : "18725718",
      "id" : 18725718
    }, {
      "name" : "Bruce Jenner",
      "screen_name" : "iambrucejenner",
      "indices" : [ 69, 84 ],
      "id_str" : "51218139",
      "id" : 51218139
    }, {
      "name" : "Caitlyn Jenner",
      "screen_name" : "Caitlyn_Jenner",
      "indices" : [ 85, 100 ],
      "id_str" : "3303293865",
      "id" : 3303293865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VanityFair",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/9kCA4B16zs",
      "expanded_url" : "https:\/\/shar.es\/12H9ZH",
      "display_url" : "shar.es\/12H9ZH"
    } ]
  },
  "geo" : { },
  "id_str" : "605424966075592705",
  "text" : "RT @christianpiatt: Meet Caitlyn (formerly Bruce) Jenner #VanityFair @iambrucejenner @Caitlyn_Jenner https:\/\/t.co\/9kCA4B16zs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bruce Jenner",
        "screen_name" : "iambrucejenner",
        "indices" : [ 49, 64 ],
        "id_str" : "51218139",
        "id" : 51218139
      }, {
        "name" : "Caitlyn Jenner",
        "screen_name" : "Caitlyn_Jenner",
        "indices" : [ 65, 80 ],
        "id_str" : "3303293865",
        "id" : 3303293865
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VanityFair",
        "indices" : [ 37, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/9kCA4B16zs",
        "expanded_url" : "https:\/\/shar.es\/12H9ZH",
        "display_url" : "shar.es\/12H9ZH"
      } ]
    },
    "geo" : { },
    "id_str" : "605423350316449795",
    "text" : "Meet Caitlyn (formerly Bruce) Jenner #VanityFair @iambrucejenner @Caitlyn_Jenner https:\/\/t.co\/9kCA4B16zs",
    "id" : 605423350316449795,
    "created_at" : "2015-06-01 17:19:09 +0000",
    "user" : {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "protected" : false,
      "id_str" : "18725718",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765072572337704960\/hMj5pUf0_normal.jpg",
      "id" : 18725718,
      "verified" : false
    }
  },
  "id" : 605424966075592705,
  "created_at" : "2015-06-01 17:25:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.BradStevenson.co\/Aeries\" rel=\"nofollow\"\u003EAeries for Windows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa sardini",
      "screen_name" : "lisasardini",
      "indices" : [ 3, 15 ],
      "id_str" : "1370358499",
      "id" : 1370358499
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/605402211401658368\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/8t0FIAebVQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbSGoZVIAEZXsz.jpg",
      "id_str" : "605402211292618753",
      "id" : 605402211292618753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbSGoZVIAEZXsz.jpg",
      "sizes" : [ {
        "h" : 401,
        "resize" : "fit",
        "w" : 534
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 534
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 534
      } ],
      "display_url" : "pic.twitter.com\/8t0FIAebVQ"
    } ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 38, 44 ]
    }, {
      "text" : "nature",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605423844506116096",
  "text" : "RT @lisasardini: Resting in the shade #birds #nature http:\/\/t.co\/8t0FIAebVQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisasardini\/status\/605402211401658368\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/8t0FIAebVQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbSGoZVIAEZXsz.jpg",
        "id_str" : "605402211292618753",
        "id" : 605402211292618753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbSGoZVIAEZXsz.jpg",
        "sizes" : [ {
          "h" : 401,
          "resize" : "fit",
          "w" : 534
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 534
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 534
        } ],
        "display_url" : "pic.twitter.com\/8t0FIAebVQ"
      } ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 21, 27 ]
      }, {
        "text" : "nature",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605402211401658368",
    "text" : "Resting in the shade #birds #nature http:\/\/t.co\/8t0FIAebVQ",
    "id" : 605402211401658368,
    "created_at" : "2015-06-01 15:55:09 +0000",
    "user" : {
      "name" : "lisa sardini",
      "screen_name" : "lisasardini",
      "protected" : false,
      "id_str" : "1370358499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794929677102092289\/U4HUzkeG_normal.jpg",
      "id" : 1370358499,
      "verified" : false
    }
  },
  "id" : 605423844506116096,
  "created_at" : "2015-06-01 17:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]