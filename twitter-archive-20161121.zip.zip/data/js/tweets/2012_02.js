Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modern Activism",
      "screen_name" : "modernactivism",
      "indices" : [ 3, 18 ],
      "id_str" : "263966773",
      "id" : 263966773
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 84, 94 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174992890559344641",
  "text" : "RT @modernactivism: US taxpayers give $5 billion for hospitals in nation of Georgia @StateDept. Yet can't have national health care http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 64, 74 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "taxes",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/MJTROBTb",
        "expanded_url" : "http:\/\/bit.ly\/AwyTpx",
        "display_url" : "bit.ly\/AwyTpx"
      } ]
    },
    "geo" : { },
    "id_str" : "174990476347314176",
    "text" : "US taxpayers give $5 billion for hospitals in nation of Georgia @StateDept. Yet can't have national health care http:\/\/t.co\/MJTROBTb #taxes",
    "id" : 174990476347314176,
    "created_at" : "2012-02-29 22:52:35 +0000",
    "user" : {
      "name" : "Modern Activism",
      "screen_name" : "modernactivism",
      "protected" : false,
      "id_str" : "263966773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748309943183257600\/mbEbLgsQ_normal.jpg",
      "id" : 263966773,
      "verified" : false
    }
  },
  "id" : 174992890559344641,
  "created_at" : "2012-02-29 23:02:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174992018781646848",
  "text" : "RT @Silvercrone: Blessing to them both&gt;Nicole Graham & Astro: Mother stayed by horse's side for 3 hrs after getting trapped http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/FgkIlRju",
        "expanded_url" : "http:\/\/bit.ly\/AkLth5",
        "display_url" : "bit.ly\/AkLth5"
      } ]
    },
    "geo" : { },
    "id_str" : "174985208658010113",
    "text" : "Blessing to them both&gt;Nicole Graham & Astro: Mother stayed by horse's side for 3 hrs after getting trapped http:\/\/t.co\/FgkIlRju",
    "id" : 174985208658010113,
    "created_at" : "2012-02-29 22:31:39 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 174992018781646848,
  "created_at" : "2012-02-29 22:58:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White Wolf",
      "screen_name" : "The_WhiteWolf_",
      "indices" : [ 3, 18 ],
      "id_str" : "116065011",
      "id" : 116065011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/mk0DKZLL",
      "expanded_url" : "http:\/\/bit.ly\/Horse-Rescue",
      "display_url" : "bit.ly\/Horse-Rescue"
    } ]
  },
  "geo" : { },
  "id_str" : "174989653663944705",
  "text" : "RT @The_WhiteWolf_: Woman saves her horse from drowning out of sheer love and determination http:\/\/t.co\/mk0DKZLL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/mk0DKZLL",
        "expanded_url" : "http:\/\/bit.ly\/Horse-Rescue",
        "display_url" : "bit.ly\/Horse-Rescue"
      } ]
    },
    "geo" : { },
    "id_str" : "174981573903532032",
    "text" : "Woman saves her horse from drowning out of sheer love and determination http:\/\/t.co\/mk0DKZLL",
    "id" : 174981573903532032,
    "created_at" : "2012-02-29 22:17:12 +0000",
    "user" : {
      "name" : "White Wolf",
      "screen_name" : "The_WhiteWolf_",
      "protected" : false,
      "id_str" : "116065011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708594602\/Arctic_wolf_by_Arctic_Wolf_Alpine_normal.jpg",
      "id" : 116065011,
      "verified" : false
    }
  },
  "id" : 174989653663944705,
  "created_at" : "2012-02-29 22:49:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Melody Fletcher",
      "screen_name" : "DeliberateBlog",
      "indices" : [ 17, 32 ],
      "id_str" : "342207359",
      "id" : 342207359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/jI9a6wmW",
      "expanded_url" : "http:\/\/is.gd\/JR3kbN",
      "display_url" : "is.gd\/JR3kbN"
    } ]
  },
  "geo" : { },
  "id_str" : "174295357994450944",
  "text" : "RT @JohnCali: RT @DeliberateBlog: A Chat With John Cali - On Channeling, Manifesting And 2012 http:\/\/t.co\/jI9a6wmW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melody Fletcher",
        "screen_name" : "DeliberateBlog",
        "indices" : [ 3, 18 ],
        "id_str" : "342207359",
        "id" : 342207359
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/jI9a6wmW",
        "expanded_url" : "http:\/\/is.gd\/JR3kbN",
        "display_url" : "is.gd\/JR3kbN"
      } ]
    },
    "geo" : { },
    "id_str" : "174293067250139138",
    "text" : "RT @DeliberateBlog: A Chat With John Cali - On Channeling, Manifesting And 2012 http:\/\/t.co\/jI9a6wmW",
    "id" : 174293067250139138,
    "created_at" : "2012-02-28 00:41:20 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 174295357994450944,
  "created_at" : "2012-02-28 00:50:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 3, 16 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174284098267918336",
  "text" : "RT @InvisCollege: Until you can release judgement, you cannot release karma. Jennifer Starlight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174283529142800385",
    "text" : "Until you can release judgement, you cannot release karma. Jennifer Starlight",
    "id" : 174283529142800385,
    "created_at" : "2012-02-28 00:03:26 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "protected" : false,
      "id_str" : "415556669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645216237\/invisible_college_normal.jpg",
      "id" : 415556669,
      "verified" : false
    }
  },
  "id" : 174284098267918336,
  "created_at" : "2012-02-28 00:05:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Studios",
      "screen_name" : "WordHero",
      "indices" : [ 3, 12 ],
      "id_str" : "349186626",
      "id" : 349186626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174281784173928448",
  "text" : "RT @WordHero: Android Market finally cleared 1k installs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174276982039773186",
    "text" : "Android Market finally cleared 1k installs.",
    "id" : 174276982039773186,
    "created_at" : "2012-02-27 23:37:25 +0000",
    "user" : {
      "name" : "Sven Studios",
      "screen_name" : "WordHero",
      "protected" : false,
      "id_str" : "349186626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000775732053\/7ff02f57dc799cb7c1d08f75d0037084_normal.png",
      "id" : 349186626,
      "verified" : false
    }
  },
  "id" : 174281784173928448,
  "created_at" : "2012-02-27 23:56:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174281195520135168",
  "text" : "RT @LSFProgram: If a person remains cheerful and loving towards everyone, life will be an absolute joy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174279305503834113",
    "text" : "If a person remains cheerful and loving towards everyone, life will be an absolute joy.",
    "id" : 174279305503834113,
    "created_at" : "2012-02-27 23:46:39 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 174281195520135168,
  "created_at" : "2012-02-27 23:54:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174255975316992001",
  "text" : "not feeling well today. virus. bleh.",
  "id" : 174255975316992001,
  "created_at" : "2012-02-27 22:13:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LymeDisease.org",
      "screen_name" : "Lymenews",
      "indices" : [ 3, 12 ],
      "id_str" : "47791514",
      "id" : 47791514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lyme",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/7FW1H0zv",
      "expanded_url" : "http:\/\/bit.ly\/xjuZVF",
      "display_url" : "bit.ly\/xjuZVF"
    } ]
  },
  "geo" : { },
  "id_str" : "174255778616713216",
  "text" : "RT @Lymenews: Why were results of important Lyme disease study kept hidden for over a decade? http:\/\/t.co\/7FW1H0zv #lyme",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lyme",
        "indices" : [ 101, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/7FW1H0zv",
        "expanded_url" : "http:\/\/bit.ly\/xjuZVF",
        "display_url" : "bit.ly\/xjuZVF"
      } ]
    },
    "geo" : { },
    "id_str" : "172711789379862528",
    "text" : "Why were results of important Lyme disease study kept hidden for over a decade? http:\/\/t.co\/7FW1H0zv #lyme",
    "id" : 172711789379862528,
    "created_at" : "2012-02-23 15:57:54 +0000",
    "user" : {
      "name" : "LymeDisease.org",
      "screen_name" : "Lymenews",
      "protected" : false,
      "id_str" : "47791514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585121378396811264\/cBO4OfUQ_normal.jpg",
      "id" : 47791514,
      "verified" : false
    }
  },
  "id" : 174255778616713216,
  "created_at" : "2012-02-27 22:13:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174245046646874112",
  "text" : "RT @By_Bashar: We have idolized the Christ Consciousness..... instead of Mirroring it. ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174241548492484610",
    "text" : "We have idolized the Christ Consciousness..... instead of Mirroring it. ~ bashar",
    "id" : 174241548492484610,
    "created_at" : "2012-02-27 21:16:37 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 174245046646874112,
  "created_at" : "2012-02-27 21:30:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/WazXSxWR",
      "expanded_url" : "http:\/\/bit.ly\/walAe6",
      "display_url" : "bit.ly\/walAe6"
    } ]
  },
  "geo" : { },
  "id_str" : "174202083271122945",
  "text" : "RT @FreeRangeKids: Murder by nursing? Very upsetting case in every way: http:\/\/t.co\/WazXSxWR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/WazXSxWR",
        "expanded_url" : "http:\/\/bit.ly\/walAe6",
        "display_url" : "bit.ly\/walAe6"
      } ]
    },
    "geo" : { },
    "id_str" : "174200042431852545",
    "text" : "Murder by nursing? Very upsetting case in every way: http:\/\/t.co\/WazXSxWR",
    "id" : 174200042431852545,
    "created_at" : "2012-02-27 18:31:41 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 174202083271122945,
  "created_at" : "2012-02-27 18:39:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WTF",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/mZYdWAyF",
      "expanded_url" : "http:\/\/bit.ly\/zMU1Nx",
      "display_url" : "bit.ly\/zMU1Nx"
    } ]
  },
  "geo" : { },
  "id_str" : "174199154602553344",
  "text" : "Lena Fokina: Babies left screaming as they are swung round head of 'baby yoga' guru http:\/\/t.co\/mZYdWAyF #WTF",
  "id" : 174199154602553344,
  "created_at" : "2012-02-27 18:28:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/qfbrDU74",
      "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyH7pMaa",
      "display_url" : "tmblr.co\/ZwrrNyH7pMaa"
    } ]
  },
  "geo" : { },
  "id_str" : "174186775076540416",
  "text" : "RT @parkstepp: \"A tree is a tree\u2014although its meaning to the man who views it (\u201Cthe truth\u201D) depends upon his...\" http:\/\/t.co\/qfbrDU74",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/qfbrDU74",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyH7pMaa",
        "display_url" : "tmblr.co\/ZwrrNyH7pMaa"
      } ]
    },
    "geo" : { },
    "id_str" : "174183635765837824",
    "text" : "\"A tree is a tree\u2014although its meaning to the man who views it (\u201Cthe truth\u201D) depends upon his...\" http:\/\/t.co\/qfbrDU74",
    "id" : 174183635765837824,
    "created_at" : "2012-02-27 17:26:29 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 174186775076540416,
  "created_at" : "2012-02-27 17:38:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/I7QMHCSv",
      "expanded_url" : "http:\/\/bit.ly\/wa0CgV",
      "display_url" : "bit.ly\/wa0CgV"
    } ]
  },
  "geo" : { },
  "id_str" : "174185318176657408",
  "text" : "PINKCLOUD.DK \u00BB THE OIL SILO HOME http:\/\/t.co\/I7QMHCSv",
  "id" : 174185318176657408,
  "created_at" : "2012-02-27 17:33:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/a53el4CQ",
      "expanded_url" : "http:\/\/tinyurl.com\/7n466f5",
      "display_url" : "tinyurl.com\/7n466f5"
    } ]
  },
  "geo" : { },
  "id_str" : "174184438396235779",
  "text" : "RT @Soulseedzforall: Choose not to buy into other peoples\u2019 hatred and insecurity. New article about claiming your power http:\/\/t.co\/a53el4CQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/a53el4CQ",
        "expanded_url" : "http:\/\/tinyurl.com\/7n466f5",
        "display_url" : "tinyurl.com\/7n466f5"
      } ]
    },
    "geo" : { },
    "id_str" : "174177864437088256",
    "text" : "Choose not to buy into other peoples\u2019 hatred and insecurity. New article about claiming your power http:\/\/t.co\/a53el4CQ",
    "id" : 174177864437088256,
    "created_at" : "2012-02-27 17:03:33 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 174184438396235779,
  "created_at" : "2012-02-27 17:29:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Better Oats Oatmeal",
      "screen_name" : "Better_Oats",
      "indices" : [ 3, 15 ],
      "id_str" : "119432618",
      "id" : 119432618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174180474724417536",
  "text" : "RT @Better_Oats: To celebrate National Strawberry Day, we're giving away a 1-month supply of Oat Revolution Strawberries & Cream! RT to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174177286910783488",
    "text" : "To celebrate National Strawberry Day, we're giving away a 1-month supply of Oat Revolution Strawberries & Cream! RT to enter!",
    "id" : 174177286910783488,
    "created_at" : "2012-02-27 17:01:15 +0000",
    "user" : {
      "name" : "Better Oats Oatmeal",
      "screen_name" : "Better_Oats",
      "protected" : false,
      "id_str" : "119432618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789470447133863936\/6G6mraog_normal.jpg",
      "id" : 119432618,
      "verified" : false
    }
  },
  "id" : 174180474724417536,
  "created_at" : "2012-02-27 17:13:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "indices" : [ 3, 16 ],
      "id_str" : "415556669",
      "id" : 415556669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174169527288999936",
  "text" : "RT @InvisCollege: Love is simply a choice away. Min",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172644028792315904",
    "text" : "Love is simply a choice away. Min",
    "id" : 172644028792315904,
    "created_at" : "2012-02-23 11:28:38 +0000",
    "user" : {
      "name" : "Jennifer Starlight",
      "screen_name" : "InvisCollege",
      "protected" : false,
      "id_str" : "415556669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1645216237\/invisible_college_normal.jpg",
      "id" : 415556669,
      "verified" : false
    }
  },
  "id" : 174169527288999936,
  "created_at" : "2012-02-27 16:30:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174168058821230592",
  "text" : "and no generic epi-pens? $100 a pop.. and they're finicky to temp, etc. usually need more than 1...",
  "id" : 174168058821230592,
  "created_at" : "2012-02-27 16:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174167710580736001",
  "text" : "I have no doubt multi-vacc's for infants are not good. peanut allergies are soaring.",
  "id" : 174167710580736001,
  "created_at" : "2012-02-27 16:23:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174167178977873921",
  "text" : "DH is allergic to crustacean. makes me nervous sometimes. (are you SURE there's no shrimp in that eggroll???)",
  "id" : 174167178977873921,
  "created_at" : "2012-02-27 16:21:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foodallergies",
      "indices" : [ 54, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/lygkwFOb",
      "expanded_url" : "http:\/\/bit.ly\/xpbJkF",
      "display_url" : "bit.ly\/xpbJkF"
    } ]
  },
  "geo" : { },
  "id_str" : "174166208407543809",
  "text" : "so sad &gt;&gt; WhatWeWishWeKnew http:\/\/t.co\/lygkwFOb #foodallergies",
  "id" : 174166208407543809,
  "created_at" : "2012-02-27 16:17:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 3, 12 ],
      "id_str" : "18581294",
      "id" : 18581294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/xX7bkkGd",
      "expanded_url" : "http:\/\/bit.ly\/x65c3w",
      "display_url" : "bit.ly\/x65c3w"
    } ]
  },
  "geo" : { },
  "id_str" : "174147876379820032",
  "text" : "RT @namenick: Literary Brooch for a Book Lover [Picture] http:\/\/t.co\/xX7bkkGd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/xX7bkkGd",
        "expanded_url" : "http:\/\/bit.ly\/x65c3w",
        "display_url" : "bit.ly\/x65c3w"
      } ]
    },
    "geo" : { },
    "id_str" : "174143517491339264",
    "text" : "Literary Brooch for a Book Lover [Picture] http:\/\/t.co\/xX7bkkGd",
    "id" : 174143517491339264,
    "created_at" : "2012-02-27 14:47:04 +0000",
    "user" : {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "protected" : false,
      "id_str" : "18581294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739156618710024192\/iSvI5Blh_normal.jpg",
      "id" : 18581294,
      "verified" : false
    }
  },
  "id" : 174147876379820032,
  "created_at" : "2012-02-27 15:04:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174141595229237248",
  "text" : "RT @ShipsofSong: Every person drawn into your reality is to assist you to learn love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174141441679962114",
    "text" : "Every person drawn into your reality is to assist you to learn love.",
    "id" : 174141441679962114,
    "created_at" : "2012-02-27 14:38:49 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 174141595229237248,
  "created_at" : "2012-02-27 14:39:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174140539338375170",
  "geo" : { },
  "id_str" : "174141238411399168",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time sounds lovely! : )",
  "id" : 174141238411399168,
  "in_reply_to_status_id" : 174140539338375170,
  "created_at" : "2012-02-27 14:38:01 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173949600812634112",
  "text" : "RT @DeepakChopra: When you give up being right, totally & completely, your life will flow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173949319861370880",
    "text" : "When you give up being right, totally & completely, your life will flow.",
    "id" : 173949319861370880,
    "created_at" : "2012-02-27 01:55:24 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 173949600812634112,
  "created_at" : "2012-02-27 01:56:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Strudwick",
      "screen_name" : "PatrickStrud",
      "indices" : [ 3, 16 ],
      "id_str" : "20703607",
      "id" : 20703607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173936946161262592",
  "text" : "RT @PatrickStrud: Despicable. A priest walks out of the funeral he is conducting because the dead woman's daughter is gay: http:\/\/t.co\/T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/TrV4PCFm",
        "expanded_url" : "http:\/\/p.ost.im\/p\/exWC4v",
        "display_url" : "p.ost.im\/p\/exWC4v"
      } ]
    },
    "geo" : { },
    "id_str" : "173898560927047681",
    "text" : "Despicable. A priest walks out of the funeral he is conducting because the dead woman's daughter is gay: http:\/\/t.co\/TrV4PCFm",
    "id" : 173898560927047681,
    "created_at" : "2012-02-26 22:33:42 +0000",
    "user" : {
      "name" : "Patrick Strudwick",
      "screen_name" : "PatrickStrud",
      "protected" : false,
      "id_str" : "20703607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754588287709409280\/pXNMxm1d_normal.jpg",
      "id" : 20703607,
      "verified" : true
    }
  },
  "id" : 173936946161262592,
  "created_at" : "2012-02-27 01:06:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173935789732925440",
  "text" : "RT @By_Bashar: Faith is taking the first step even when you don't see the whole staircase. ~ M.L.King",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173924369733648387",
    "text" : "Faith is taking the first step even when you don't see the whole staircase. ~ M.L.King",
    "id" : 173924369733648387,
    "created_at" : "2012-02-27 00:16:15 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 173935789732925440,
  "created_at" : "2012-02-27 01:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173909319648157697",
  "text" : "i might set up a blog just for my thoughts on this book... hmmm...",
  "id" : 173909319648157697,
  "created_at" : "2012-02-26 23:16:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173906495895912448",
  "text" : "@SamsaricWarrior what a cool idea!",
  "id" : 173906495895912448,
  "created_at" : "2012-02-26 23:05:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173898317359620097",
  "geo" : { },
  "id_str" : "173901855519289344",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees 5 & 8? hmm.. not on my radar..lol",
  "id" : 173901855519289344,
  "in_reply_to_status_id" : 173898317359620097,
  "created_at" : "2012-02-26 22:46:47 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173897882615824384",
  "geo" : { },
  "id_str" : "173901370179596288",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees indecisive, preoccupied and passive.. yup. lol",
  "id" : 173901370179596288,
  "in_reply_to_status_id" : 173897882615824384,
  "created_at" : "2012-02-26 22:44:52 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173897634195587072",
  "geo" : { },
  "id_str" : "173900902921535489",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees I love intellectual discussion and stimulation. where im happiest I think.",
  "id" : 173900902921535489,
  "in_reply_to_status_id" : 173897634195587072,
  "created_at" : "2012-02-26 22:43:00 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173897072469217281",
  "geo" : { },
  "id_str" : "173900528760258560",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees yes, info overload is familiar. at 46, im just now feeling comfortable in my own skin so running a little slow..lol",
  "id" : 173900528760258560,
  "in_reply_to_status_id" : 173897072469217281,
  "created_at" : "2012-02-26 22:41:31 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173896894714617857",
  "geo" : { },
  "id_str" : "173900011728420864",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees yup. live and let live attitude. dont like intolerance. and trouble making decisions.. rofl.. thats sooo me.",
  "id" : 173900011728420864,
  "in_reply_to_status_id" : 173896894714617857,
  "created_at" : "2012-02-26 22:39:28 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173892946750472192",
  "geo" : { },
  "id_str" : "173894530234462209",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees I share my birthday w Albert Einstein..lol.. March 14",
  "id" : 173894530234462209,
  "in_reply_to_status_id" : 173892946750472192,
  "created_at" : "2012-02-26 22:17:41 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 0, 10 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173892946750472192",
  "geo" : { },
  "id_str" : "173894211849031680",
  "in_reply_to_user_id" : 93341555,
  "text" : "@wow_trees oh, me,me,me!",
  "id" : 173894211849031680,
  "in_reply_to_status_id" : 173892946750472192,
  "created_at" : "2012-02-26 22:16:25 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173875564715847680",
  "geo" : { },
  "id_str" : "173876134134558720",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope you know, loving our pets shows us the possibilities of human love.",
  "id" : 173876134134558720,
  "in_reply_to_status_id" : 173875564715847680,
  "created_at" : "2012-02-26 21:04:35 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173874999336251394",
  "geo" : { },
  "id_str" : "173875754571010050",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time yay! glad to be of service, my sweet. : )",
  "id" : 173875754571010050,
  "in_reply_to_status_id" : 173874999336251394,
  "created_at" : "2012-02-26 21:03:05 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173875509502025728",
  "text" : "@SocialistXian he didnt like the church back then, either.",
  "id" : 173875509502025728,
  "created_at" : "2012-02-26 21:02:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2nd",
      "indices" : [ 24, 28 ]
    }, {
      "text" : "Karma",
      "indices" : [ 36, 42 ]
    }, {
      "text" : "ICP",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173875054394867714",
  "text" : "RT @AnAmericanMonk: The #2nd low of #Karma is'You attract to you what you are not what you want' The Twelve Sacred Principles of Karma' #ICP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2nd",
        "indices" : [ 4, 8 ]
      }, {
        "text" : "Karma",
        "indices" : [ 16, 22 ]
      }, {
        "text" : "ICP",
        "indices" : [ 116, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173874679143071744",
    "text" : "The #2nd low of #Karma is'You attract to you what you are not what you want' The Twelve Sacred Principles of Karma' #ICP",
    "id" : 173874679143071744,
    "created_at" : "2012-02-26 20:58:48 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 173875054394867714,
  "created_at" : "2012-02-26 21:00:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R Lawrence \u24CB",
      "screen_name" : "TheUHMethod",
      "indices" : [ 3, 15 ],
      "id_str" : "220760593",
      "id" : 220760593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173874055613644800",
  "text" : "RT @TheUHMethod: We can only judge others from our unique perspective. Since everyone\u2019s perspectives are unique, what is the point of ju ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICP",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172765479818104833",
    "text" : "We can only judge others from our unique perspective. Since everyone\u2019s perspectives are unique, what is the point of judging others? #ICP",
    "id" : 172765479818104833,
    "created_at" : "2012-02-23 19:31:14 +0000",
    "user" : {
      "name" : "Michael R Lawrence \u24CB",
      "screen_name" : "TheUHMethod",
      "protected" : false,
      "id_str" : "220760593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750824021923491840\/0PoHY8dh_normal.jpg",
      "id" : 220760593,
      "verified" : false
    }
  },
  "id" : 173874055613644800,
  "created_at" : "2012-02-26 20:56:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "san jekel",
      "screen_name" : "sanjekel41",
      "indices" : [ 3, 14 ],
      "id_str" : "46183698",
      "id" : 46183698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173873894648856576",
  "text" : "RT @sanjekel41: Friends are God's way of taking care of us",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173870647917813760",
    "text" : "Friends are God's way of taking care of us",
    "id" : 173870647917813760,
    "created_at" : "2012-02-26 20:42:47 +0000",
    "user" : {
      "name" : "san jekel",
      "screen_name" : "sanjekel41",
      "protected" : false,
      "id_str" : "46183698",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590833791997980672\/EpwwhZdg_normal.jpg",
      "id" : 46183698,
      "verified" : false
    }
  },
  "id" : 173873894648856576,
  "created_at" : "2012-02-26 20:55:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173870859361075200",
  "geo" : { },
  "id_str" : "173873533963874305",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope awww.. nice!",
  "id" : 173873533963874305,
  "in_reply_to_status_id" : 173870859361075200,
  "created_at" : "2012-02-26 20:54:15 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173873329181163520",
  "text" : "RT @derekrootboy: I put two quantum mechanics into a box and when I opened it I discovered they'd killed each other. Poetic justice if y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "philosophy",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173871677225172994",
    "text" : "I put two quantum mechanics into a box and when I opened it I discovered they'd killed each other. Poetic justice if you ask me. #philosophy",
    "id" : 173871677225172994,
    "created_at" : "2012-02-26 20:46:52 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 173873329181163520,
  "created_at" : "2012-02-26 20:53:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173872848476192768",
  "text" : "@SocialistXian have you read \"the Kingdom of God is Within You\" by Leo Tolstoy? im reading now and its very enlightening to me.",
  "id" : 173872848476192768,
  "created_at" : "2012-02-26 20:51:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173872423547056128",
  "text" : "@SocialistXian I suppose it depends how you disagree.",
  "id" : 173872423547056128,
  "created_at" : "2012-02-26 20:49:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 0, 15 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173868309756911616",
  "geo" : { },
  "id_str" : "173871818002792449",
  "in_reply_to_user_id" : 30825946,
  "text" : "@JonathanElliot breathe. it's just temporary. it will be over with and you'll feel better.",
  "id" : 173871818002792449,
  "in_reply_to_status_id" : 173868309756911616,
  "created_at" : "2012-02-26 20:47:26 +0000",
  "in_reply_to_screen_name" : "JonathanElliot",
  "in_reply_to_user_id_str" : "30825946",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 0, 15 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173869220440973312",
  "geo" : { },
  "id_str" : "173871630722924544",
  "in_reply_to_user_id" : 30825946,
  "text" : "@JonathanElliot true.. I can't see any one of them as our next president.",
  "id" : 173871630722924544,
  "in_reply_to_status_id" : 173869220440973312,
  "created_at" : "2012-02-26 20:46:41 +0000",
  "in_reply_to_screen_name" : "JonathanElliot",
  "in_reply_to_user_id_str" : "30825946",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 0, 15 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173869081030705152",
  "geo" : { },
  "id_str" : "173871420437299200",
  "in_reply_to_user_id" : 30825946,
  "text" : "@JonathanElliot cuz all the candidates are just so amusing...lol",
  "id" : 173871420437299200,
  "in_reply_to_status_id" : 173869081030705152,
  "created_at" : "2012-02-26 20:45:51 +0000",
  "in_reply_to_screen_name" : "JonathanElliot",
  "in_reply_to_user_id_str" : "30825946",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purplepoetry77",
      "screen_name" : "purplepoetry77",
      "indices" : [ 3, 18 ],
      "id_str" : "2511633660",
      "id" : 2511633660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sixwords",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173769761518403584",
  "text" : "RT @purplepoetry77: persistent caw ~ the crow knows ~ solitude #sixwords",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sixwords",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173768951313080320",
    "text" : "persistent caw ~ the crow knows ~ solitude #sixwords",
    "id" : 173768951313080320,
    "created_at" : "2012-02-26 13:58:41 +0000",
    "user" : {
      "name" : "poemscape",
      "screen_name" : "poemscape",
      "protected" : true,
      "id_str" : "310624642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552530565875105796\/G7vcRm1e_normal.jpeg",
      "id" : 310624642,
      "verified" : false
    }
  },
  "id" : 173769761518403584,
  "created_at" : "2012-02-26 14:01:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173768667740389376",
  "geo" : { },
  "id_str" : "173769627099336704",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I havent clothes shopped in mall in long time. I used to enjoy it but now I just get tired. low endurance.",
  "id" : 173769627099336704,
  "in_reply_to_status_id" : 173768667740389376,
  "created_at" : "2012-02-26 14:01:22 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin",
      "screen_name" : "mrscapra",
      "indices" : [ 0, 9 ],
      "id_str" : "1969965566",
      "id" : 1969965566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173769295980011521",
  "text" : "@MrsCapra my MIL has mentioned them. I'll have to check it out cuz I really need pants..lol. mine are all too short now.",
  "id" : 173769295980011521,
  "created_at" : "2012-02-26 14:00:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173768840738643968",
  "text" : "maybe I'll use my red pencil for marking \"kingdom of god within you\" .. got post-its in it right now. so many things...",
  "id" : 173768840738643968,
  "created_at" : "2012-02-26 13:58:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin",
      "screen_name" : "mrscapra",
      "indices" : [ 0, 9 ],
      "id_str" : "1969965566",
      "id" : 1969965566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173768021133889536",
  "text" : "@MrsCapra I did find 1 pair.. but $98!! sigh. im round and short. bad combo..lol.",
  "id" : 173768021133889536,
  "created_at" : "2012-02-26 13:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin",
      "screen_name" : "mrscapra",
      "indices" : [ 0, 9 ],
      "id_str" : "1969965566",
      "id" : 1969965566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173767598473883648",
  "text" : "@MrsCapra after about 2 hours, 5-8 pairs of pants tried.. I got tired and we came home.",
  "id" : 173767598473883648,
  "created_at" : "2012-02-26 13:53:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173764255907196928",
  "text" : "went shopping for pants yesterday. came home with nothing. sigh.",
  "id" : 173764255907196928,
  "created_at" : "2012-02-26 13:40:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173758037666955265",
  "text" : "RT @By_Bashar: Everything has a reason for being part an event~down to the , most infinitesimal detail. Nothing is an accident No except ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173757496262000640",
    "text" : "Everything has a reason for being part an event~down to the , most infinitesimal detail. Nothing is an accident No exceptions ~ bashar",
    "id" : 173757496262000640,
    "created_at" : "2012-02-26 13:13:10 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 173758037666955265,
  "created_at" : "2012-02-26 13:15:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ 30, 43 ],
      "id_str" : "116994659",
      "id" : 116994659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173426630503575553",
  "text" : "RT @neiltyson: Decided to buy @SamHarrisOrg's latest book, where he argues FreeWill is an illusion. So I guess I had no choice in the matter",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Harris",
        "screen_name" : "SamHarrisOrg",
        "indices" : [ 15, 28 ],
        "id_str" : "116994659",
        "id" : 116994659
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173426325451837440",
    "text" : "Decided to buy @SamHarrisOrg's latest book, where he argues FreeWill is an illusion. So I guess I had no choice in the matter",
    "id" : 173426325451837440,
    "created_at" : "2012-02-25 15:17:12 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 173426630503575553,
  "created_at" : "2012-02-25 15:18:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 3, 10 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173420576852025344",
  "text" : "RT @SsmDad: 10 women arrstd in Cameroon for being lesbians.Consensual same-gender sex is punishable up to five yrs in jail (via @realcou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.icebirdapp.com\" rel=\"nofollow\"\u003EIcebird for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Linda Franklin",
        "screen_name" : "realcougarwoman",
        "indices" : [ 116, 132 ],
        "id_str" : "18529650",
        "id" : 18529650
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173404606875959296",
    "text" : "10 women arrstd in Cameroon for being lesbians.Consensual same-gender sex is punishable up to five yrs in jail (via @realcougarwoman) sad :(",
    "id" : 173404606875959296,
    "created_at" : "2012-02-25 13:50:54 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "protected" : false,
      "id_str" : "122393631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649760376880525312\/faJeQ4K3_normal.jpg",
      "id" : 122393631,
      "verified" : false
    }
  },
  "id" : 173420576852025344,
  "created_at" : "2012-02-25 14:54:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173419648807735296",
  "text" : "@SamsaricWarrior heehee.. never walk away from chocolate! ; )",
  "id" : 173419648807735296,
  "created_at" : "2012-02-25 14:50:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 0, 10 ],
      "id_str" : "82447359",
      "id" : 82447359
    }, {
      "name" : "Renee Baio",
      "screen_name" : "MrsScottBaio",
      "indices" : [ 11, 24 ],
      "id_str" : "82432490",
      "id" : 82432490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173222762113019904",
  "geo" : { },
  "id_str" : "173223341157654528",
  "in_reply_to_user_id" : 82447359,
  "text" : "@ScottBaio @MrsScottBaio awww.. now that's a man in love..hehe : ) very sweet!",
  "id" : 173223341157654528,
  "in_reply_to_status_id" : 173222762113019904,
  "created_at" : "2012-02-25 01:50:37 +0000",
  "in_reply_to_screen_name" : "ScottBaio",
  "in_reply_to_user_id_str" : "82447359",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173211986388197376",
  "text" : "RT @TheEntertainer: It's time for a RADICAL SHIFT in consciousness, the old ways are crumbling, and this is a GOOD thing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173211603204976640",
    "text" : "It's time for a RADICAL SHIFT in consciousness, the old ways are crumbling, and this is a GOOD thing.",
    "id" : 173211603204976640,
    "created_at" : "2012-02-25 01:03:58 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 173211986388197376,
  "created_at" : "2012-02-25 01:05:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173209018762919937",
  "geo" : { },
  "id_str" : "173210084443299840",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench yeah.. that happens : P",
  "id" : 173210084443299840,
  "in_reply_to_status_id" : 173209018762919937,
  "created_at" : "2012-02-25 00:57:56 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "N. John Shore, Jr.",
      "screen_name" : "johnshore",
      "indices" : [ 88, 98 ],
      "id_str" : "74710075",
      "id" : 74710075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/FCg9j2Zk",
      "expanded_url" : "http:\/\/johnshore.com\/2012\/02\/24\/do-you-feel-a-drunken-street-orgy-coming-on\/",
      "display_url" : "johnshore.com\/2012\/02\/24\/do-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173154368986693632",
  "text" : "hysterical! &gt;&gt; Do you feel a drunken street orgy coming on?: http:\/\/t.co\/FCg9j2Zk @johnshore",
  "id" : 173154368986693632,
  "created_at" : "2012-02-24 21:16:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173113979915354112",
  "text" : "RT @Buddhaworld: stop worry now, we all sit in one boat. I have the finger in the hole, so all is fine. Buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173113609201782785",
    "text" : "stop worry now, we all sit in one boat. I have the finger in the hole, so all is fine. Buddha volko.",
    "id" : 173113609201782785,
    "created_at" : "2012-02-24 18:34:35 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 173113979915354112,
  "created_at" : "2012-02-24 18:36:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ICP",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "Amazon",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173111843634692096",
  "text" : "RT @AnAmericanMonk: A book on Christian Mysticism \"A Metaphysical Interpretation of the Bible' for the mystic in you. #ICP #Amazon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ICP",
        "indices" : [ 98, 102 ]
      }, {
        "text" : "Amazon",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173110270510641152",
    "text" : "A book on Christian Mysticism \"A Metaphysical Interpretation of the Bible' for the mystic in you. #ICP #Amazon",
    "id" : 173110270510641152,
    "created_at" : "2012-02-24 18:21:19 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 173111843634692096,
  "created_at" : "2012-02-24 18:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rita Hartnett",
      "screen_name" : "amphib_avenger",
      "indices" : [ 3, 18 ],
      "id_str" : "757703497848614912",
      "id" : 757703497848614912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/kEbC0SK0",
      "expanded_url" : "http:\/\/vimeo.com\/channels\/slothtv",
      "display_url" : "vimeo.com\/channels\/sloth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173110426333224960",
  "text" : "RT @amphib_avenger: Now all the videos are in one place. Start wasting time. Now. http:\/\/t.co\/kEbC0SK0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/kEbC0SK0",
        "expanded_url" : "http:\/\/vimeo.com\/channels\/slothtv",
        "display_url" : "vimeo.com\/channels\/sloth\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "173109496393109506",
    "text" : "Now all the videos are in one place. Start wasting time. Now. http:\/\/t.co\/kEbC0SK0",
    "id" : 173109496393109506,
    "created_at" : "2012-02-24 18:18:14 +0000",
    "user" : {
      "name" : "Lucy Cooke",
      "screen_name" : "mslucycooke",
      "protected" : false,
      "id_str" : "20788157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701145255803035653\/z5BEa-3s_normal.jpg",
      "id" : 20788157,
      "verified" : false
    }
  },
  "id" : 173110426333224960,
  "created_at" : "2012-02-24 18:21:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Andrew Mence",
      "screen_name" : "AndrewMence",
      "indices" : [ 16, 28 ],
      "id_str" : "337167663",
      "id" : 337167663
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 122, 132 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/6z6weoGD",
      "expanded_url" : "http:\/\/bit.ly\/xdFM2p",
      "display_url" : "bit.ly\/xdFM2p"
    } ]
  },
  "geo" : { },
  "id_str" : "173106993433804800",
  "text" : "RT @SangyeH: RT @AndrewMence: Ever seen a baby sloth in a onesie made out of old socks? You need to http:\/\/t.co\/6z6weoGD\u201D @JALpalyul ||  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Mence",
        "screen_name" : "AndrewMence",
        "indices" : [ 3, 15 ],
        "id_str" : "337167663",
        "id" : 337167663
      }, {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 109, 119 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/6z6weoGD",
        "expanded_url" : "http:\/\/bit.ly\/xdFM2p",
        "display_url" : "bit.ly\/xdFM2p"
      } ]
    },
    "geo" : { },
    "id_str" : "173102609027182594",
    "text" : "RT @AndrewMence: Ever seen a baby sloth in a onesie made out of old socks? You need to http:\/\/t.co\/6z6weoGD\u201D @JALpalyul || ROTFLMBO",
    "id" : 173102609027182594,
    "created_at" : "2012-02-24 17:50:52 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 173106993433804800,
  "created_at" : "2012-02-24 18:08:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173104498099761152",
  "geo" : { },
  "id_str" : "173106552503402497",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott cool beans! lol.. im reading it slowly and might have to get out my highlighter! i keep thinking of #ows while reading...",
  "id" : 173106552503402497,
  "in_reply_to_status_id" : 173104498099761152,
  "created_at" : "2012-02-24 18:06:32 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173096366388674560",
  "text" : "RT @_NealeDWalsch: It is time for the world to stop kidding itself, to wake up, to realize that the only problem of humanity is lack of  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nealedonaldwalsch.com\" rel=\"nofollow\"\u003ENeale Donald Walsch\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173059860554981376",
    "text" : "It is time for the world to stop kidding itself, to wake up, to realize that the only problem of humanity is lack of love.",
    "id" : 173059860554981376,
    "created_at" : "2012-02-24 15:01:00 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 173096366388674560,
  "created_at" : "2012-02-24 17:26:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "indices" : [ 3, 14 ],
      "id_str" : "283660852",
      "id" : 283660852
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slothville\/status\/173085249293660160\/photo\/1",
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/u43UhaBt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AmbsHgBCMAA8oJC.jpg",
      "id_str" : "173085249297854464",
      "id" : 173085249297854464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmbsHgBCMAA8oJC.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/u43UhaBt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173087787380260864",
  "text" : "RT @slothville: Sloth photo bomb! http:\/\/t.co\/u43UhaBt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slothville\/status\/173085249293660160\/photo\/1",
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/u43UhaBt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AmbsHgBCMAA8oJC.jpg",
        "id_str" : "173085249297854464",
        "id" : 173085249297854464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AmbsHgBCMAA8oJC.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/u43UhaBt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173085249293660160",
    "text" : "Sloth photo bomb! http:\/\/t.co\/u43UhaBt",
    "id" : 173085249293660160,
    "created_at" : "2012-02-24 16:41:54 +0000",
    "user" : {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "protected" : false,
      "id_str" : "283660852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529221111280463872\/E06rTIEQ_normal.jpeg",
      "id" : 283660852,
      "verified" : false
    }
  },
  "id" : 173087787380260864,
  "created_at" : "2012-02-24 16:51:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 0, 12 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173083304554283008",
  "geo" : { },
  "id_str" : "173087584568885248",
  "in_reply_to_user_id" : 40585382,
  "text" : "@ReverendSue they dont see the correlation between their views of running country and the taliban, etc.",
  "id" : 173087584568885248,
  "in_reply_to_status_id" : 173083304554283008,
  "created_at" : "2012-02-24 16:51:10 +0000",
  "in_reply_to_screen_name" : "ReverendSue",
  "in_reply_to_user_id_str" : "40585382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173082952593448962",
  "text" : "@Kerrianne_xx LOL.. 3 anteaters, 1 account. their keeper tweets about them inc. pics.",
  "id" : 173082952593448962,
  "created_at" : "2012-02-24 16:32:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173081834484285440",
  "text" : "@Kerrianne_xx I follow an anteater here on twitter and on facebook. well, 3 in 1 actually..lol. pua, aurora & ori.",
  "id" : 173081834484285440,
  "created_at" : "2012-02-24 16:28:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173081320312934400",
  "text" : "RT @wow_trees: Weird peacock turkeys are sprinting down the street. What kind of birds are these? Ugh, they're too elusive to take pictu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173080179160268800",
    "text" : "Weird peacock turkeys are sprinting down the street. What kind of birds are these? Ugh, they're too elusive to take pictures of.",
    "id" : 173080179160268800,
    "created_at" : "2012-02-24 16:21:45 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 173081320312934400,
  "created_at" : "2012-02-24 16:26:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173070628885237761",
  "text" : "Im really enjoying The Kingdom of God is Within You by Tolstoy .. another AHA book (like when I read ACIM)",
  "id" : 173070628885237761,
  "created_at" : "2012-02-24 15:43:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172712070452756480",
  "text" : "RT @Squirrely007: Finnish President's Husband Caught Eyeing Danish Princess' Breasts? | ABC News Blogs - Yahoo! News http:\/\/t.co\/smWEC7K ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo News",
        "screen_name" : "YahooNews",
        "indices" : [ 124, 134 ],
        "id_str" : "7309052",
        "id" : 7309052
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/smWEC7KO",
        "expanded_url" : "http:\/\/news.yahoo.com\/blogs\/abc-blogs\/finnish-presidents-husband-busted-eyeing-dannish-princesss-breasts-212046367--abc-news.html",
        "display_url" : "news.yahoo.com\/blogs\/abc-blog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "172711420910239744",
    "text" : "Finnish President's Husband Caught Eyeing Danish Princess' Breasts? | ABC News Blogs - Yahoo! News http:\/\/t.co\/smWEC7KO via @YahooNews",
    "id" : 172711420910239744,
    "created_at" : "2012-02-23 15:56:26 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 172712070452756480,
  "created_at" : "2012-02-23 15:59:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172698440831213568",
  "text" : "RT @bend_time: whats w\/ marines dying in helicopter crashes? getting too repetitive, needs examination.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172698281573490688",
    "text" : "whats w\/ marines dying in helicopter crashes? getting too repetitive, needs examination.",
    "id" : 172698281573490688,
    "created_at" : "2012-02-23 15:04:13 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 172698440831213568,
  "created_at" : "2012-02-23 15:04:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172507622795247616",
  "geo" : { },
  "id_str" : "172508122940850176",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts that was interesting, tho. no group rights but individuals. hmm..",
  "id" : 172508122940850176,
  "in_reply_to_status_id" : 172507622795247616,
  "created_at" : "2012-02-23 02:28:36 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "indices" : [ 3, 15 ],
      "id_str" : "4207961",
      "id" : 4207961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172504356376150016",
  "text" : "RT @chrislhayes: When people use the word \"illegal\" as a noun, it sounds to me like saying \"coloreds\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172502620135632899",
    "text" : "When people use the word \"illegal\" as a noun, it sounds to me like saying \"coloreds\"",
    "id" : 172502620135632899,
    "created_at" : "2012-02-23 02:06:44 +0000",
    "user" : {
      "name" : "Christopher Hayes",
      "screen_name" : "chrislhayes",
      "protected" : false,
      "id_str" : "4207961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499446228\/MSNBC_Headshot_normal.jpg",
      "id" : 4207961,
      "verified" : true
    }
  },
  "id" : 172504356376150016,
  "created_at" : "2012-02-23 02:13:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aisha Tyler",
      "screen_name" : "aishatyler",
      "indices" : [ 3, 14 ],
      "id_str" : "18125335",
      "id" : 18125335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172503973251657728",
  "text" : "RT @aishatyler: Yes. Let's eliminate birth control, sex education & programs for the poor. Then collect all the bonus children & let The ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172501375517851648",
    "text" : "Yes. Let's eliminate birth control, sex education & programs for the poor. Then collect all the bonus children & let The Hunger Games begin!",
    "id" : 172501375517851648,
    "created_at" : "2012-02-23 02:01:47 +0000",
    "user" : {
      "name" : "Aisha Tyler",
      "screen_name" : "aishatyler",
      "protected" : false,
      "id_str" : "18125335",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712063772521844736\/RTF6y76E_normal.jpg",
      "id" : 18125335,
      "verified" : true
    }
  },
  "id" : 172503973251657728,
  "created_at" : "2012-02-23 02:12:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GirlsLibrary \u10E6",
      "screen_name" : "GirlsLibrary",
      "indices" : [ 3, 16 ],
      "id_str" : "267844771",
      "id" : 267844771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172497779380326400",
  "text" : "RT @GirlsLibrary: Sometimes GOOD people make BAD choices. It doesn't mean they're bad...it means they're HUMAN! \u2665",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172495650624249856",
    "text" : "Sometimes GOOD people make BAD choices. It doesn't mean they're bad...it means they're HUMAN! \u2665",
    "id" : 172495650624249856,
    "created_at" : "2012-02-23 01:39:02 +0000",
    "user" : {
      "name" : "GirlsLibrary \u10E6",
      "screen_name" : "GirlsLibrary",
      "protected" : false,
      "id_str" : "267844771",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773279034532782080\/XLjyWJIc_normal.jpg",
      "id" : 267844771,
      "verified" : false
    }
  },
  "id" : 172497779380326400,
  "created_at" : "2012-02-23 01:47:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172497667191095297",
  "text" : "im so mean.. when I see a 1 man, 1 women bumper sticker.. I wanna slap a rainbow sticker on it! lol",
  "id" : 172497667191095297,
  "created_at" : "2012-02-23 01:47:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/eLuZrtzS",
      "expanded_url" : "http:\/\/bit.ly\/z8MeIO",
      "display_url" : "bit.ly\/z8MeIO"
    } ]
  },
  "geo" : { },
  "id_str" : "172409113060458496",
  "text" : "RT @holycutenesss: Rat and cat share milk http:\/\/t.co\/eLuZrtzS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/eLuZrtzS",
        "expanded_url" : "http:\/\/bit.ly\/z8MeIO",
        "display_url" : "bit.ly\/z8MeIO"
      } ]
    },
    "geo" : { },
    "id_str" : "172407263565324288",
    "text" : "Rat and cat share milk http:\/\/t.co\/eLuZrtzS",
    "id" : 172407263565324288,
    "created_at" : "2012-02-22 19:47:49 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 172409113060458496,
  "created_at" : "2012-02-22 19:55:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Keyes",
      "screen_name" : "smkeyes",
      "indices" : [ 10, 18 ],
      "id_str" : "15636435",
      "id" : 15636435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172402450731507712",
  "text" : "@iEyeAyes @smkeyes you see, they are not real ppl. god doesnt care about them. o-O",
  "id" : 172402450731507712,
  "created_at" : "2012-02-22 19:28:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172400054034903040",
  "text" : "RT @ToadHollowPhoto: Oh WOW, this is the cutest little feathered-friend I have ever seen! Great shots! \"Luna...Who?\" - http:\/\/t.co\/hGclZ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edith Levy",
        "screen_name" : "Edithlevy21",
        "indices" : [ 123, 135 ],
        "id_str" : "172465164",
        "id" : 172465164
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/hGclZsHN",
        "expanded_url" : "http:\/\/wp.me\/p1AFRw-oM",
        "display_url" : "wp.me\/p1AFRw-oM"
      } ]
    },
    "geo" : { },
    "id_str" : "172394013113061376",
    "text" : "Oh WOW, this is the cutest little feathered-friend I have ever seen! Great shots! \"Luna...Who?\" - http:\/\/t.co\/hGclZsHN via @Edithlevy21",
    "id" : 172394013113061376,
    "created_at" : "2012-02-22 18:55:10 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 172400054034903040,
  "created_at" : "2012-02-22 19:19:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172384561408393217",
  "text" : "RT @ToadHollowPhoto: A truly stunning and gorgeous pair of Grey Wolves! GREAT shots! \"Who's Afraid of the Big, Bad Wolf?\" - http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edith Levy",
        "screen_name" : "Edithlevy21",
        "indices" : [ 128, 140 ],
        "id_str" : "172465164",
        "id" : 172465164
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/ACRRBwr2",
        "expanded_url" : "http:\/\/wp.me\/p1AFRw-oz",
        "display_url" : "wp.me\/p1AFRw-oz"
      } ]
    },
    "geo" : { },
    "id_str" : "172383141737144320",
    "text" : "A truly stunning and gorgeous pair of Grey Wolves! GREAT shots! \"Who's Afraid of the Big, Bad Wolf?\" - http:\/\/t.co\/ACRRBwr2 via @Edithlevy21",
    "id" : 172383141737144320,
    "created_at" : "2012-02-22 18:11:58 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 172384561408393217,
  "created_at" : "2012-02-22 18:17:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Mitzi Connell",
      "screen_name" : "MitziConnell",
      "indices" : [ 17, 30 ],
      "id_str" : "21952042",
      "id" : 21952042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/iu27VdJh",
      "expanded_url" : "http:\/\/goo.gl\/fb\/8fpvh",
      "display_url" : "goo.gl\/fb\/8fpvh"
    } ]
  },
  "geo" : { },
  "id_str" : "172381536899973120",
  "text" : "RT @JohnCali: RT @MitziConnell: My latest post:  \u2026the sky might fall today http:\/\/t.co\/iu27VdJh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitzi Connell",
        "screen_name" : "MitziConnell",
        "indices" : [ 3, 16 ],
        "id_str" : "21952042",
        "id" : 21952042
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/iu27VdJh",
        "expanded_url" : "http:\/\/goo.gl\/fb\/8fpvh",
        "display_url" : "goo.gl\/fb\/8fpvh"
      } ]
    },
    "geo" : { },
    "id_str" : "172380549577588736",
    "text" : "RT @MitziConnell: My latest post:  \u2026the sky might fall today http:\/\/t.co\/iu27VdJh",
    "id" : 172380549577588736,
    "created_at" : "2012-02-22 18:01:40 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 172381536899973120,
  "created_at" : "2012-02-22 18:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Byron Katie",
      "screen_name" : "ByronKatie",
      "indices" : [ 17, 28 ],
      "id_str" : "22733967",
      "id" : 22733967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172380238158893056",
  "text" : "RT @JohnCali: RT @ByronKatie: You don\u2019t experience anxiety unless you\u2019re attached to a thought that isn\u2019t true for you. It\u2019s that simple.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Byron Katie",
        "screen_name" : "ByronKatie",
        "indices" : [ 3, 14 ],
        "id_str" : "22733967",
        "id" : 22733967
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172379357136957441",
    "text" : "RT @ByronKatie: You don\u2019t experience anxiety unless you\u2019re attached to a thought that isn\u2019t true for you. It\u2019s that simple.",
    "id" : 172379357136957441,
    "created_at" : "2012-02-22 17:56:56 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 172380238158893056,
  "created_at" : "2012-02-22 18:00:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172378846346227712",
  "text" : "@Kerrianne_xx lol.. dm sent. feel free to unfollow if my tweets dont suit you : )",
  "id" : 172378846346227712,
  "created_at" : "2012-02-22 17:54:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172375513766178817",
  "text" : "@Kerrianne_xx I cant dm you.. you dont follow me. do you have a contact page somewhere? : )",
  "id" : 172375513766178817,
  "created_at" : "2012-02-22 17:41:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172372986718990336",
  "text" : "@Kerrianne_xx sure!",
  "id" : 172372986718990336,
  "created_at" : "2012-02-22 17:31:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/V4qFaoid",
      "expanded_url" : "http:\/\/tinyurl.com\/6rcf49j",
      "display_url" : "tinyurl.com\/6rcf49j"
    } ]
  },
  "geo" : { },
  "id_str" : "172372401689071616",
  "text" : "RT @Seeds4Parents: Learning to love yourself is the greatest love of all. Whitney, New article http:\/\/t.co\/V4qFaoid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/V4qFaoid",
        "expanded_url" : "http:\/\/tinyurl.com\/6rcf49j",
        "display_url" : "tinyurl.com\/6rcf49j"
      } ]
    },
    "geo" : { },
    "id_str" : "172368418136272896",
    "text" : "Learning to love yourself is the greatest love of all. Whitney, New article http:\/\/t.co\/V4qFaoid",
    "id" : 172368418136272896,
    "created_at" : "2012-02-22 17:13:27 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 172372401689071616,
  "created_at" : "2012-02-22 17:29:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheists",
      "indices" : [ 58, 67 ]
    }, {
      "text" : "God",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172371639902806017",
  "text" : "RT @ReverendSue: To the \"religious:\" STOP your attacks on #atheists! If you believe in God then you know #God loves all. Your hate of at ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheists",
        "indices" : [ 41, 50 ]
      }, {
        "text" : "God",
        "indices" : [ 88, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172369384269033472",
    "text" : "To the \"religious:\" STOP your attacks on #atheists! If you believe in God then you know #God loves all. Your hate of atheists is NOT God.",
    "id" : 172369384269033472,
    "created_at" : "2012-02-22 17:17:18 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 172371639902806017,
  "created_at" : "2012-02-22 17:26:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172371567987273728",
  "text" : "RT @By_Bashar: To resist anything is to be in the service of it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172368391846371329",
    "text" : "To resist anything is to be in the service of it.",
    "id" : 172368391846371329,
    "created_at" : "2012-02-22 17:13:21 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 172371567987273728,
  "created_at" : "2012-02-22 17:25:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172371282023817216",
  "text" : "RT @LukeRomyn: I asked for a massage with a happy ending. She slapped me on the ass and said, \"They all lived happily ever after....\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172370485336752128",
    "text" : "I asked for a massage with a happy ending. She slapped me on the ass and said, \"They all lived happily ever after....\"",
    "id" : 172370485336752128,
    "created_at" : "2012-02-22 17:21:40 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 172371282023817216,
  "created_at" : "2012-02-22 17:24:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/QD15Oos0",
      "expanded_url" : "http:\/\/johnshore.com\/2011\/05\/24\/is-hell-real-what-are-we-six\/",
      "display_url" : "johnshore.com\/2011\/05\/24\/is-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172370522242428928",
  "text" : "Is Hell Real? What Are We, Six?: http:\/\/t.co\/QD15Oos0",
  "id" : 172370522242428928,
  "created_at" : "2012-02-22 17:21:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/WOurUTVe",
      "expanded_url" : "http:\/\/bit.ly\/ysrW0o",
      "display_url" : "bit.ly\/ysrW0o"
    } ]
  },
  "geo" : { },
  "id_str" : "172359071989637120",
  "text" : "separation | nakedpastor http:\/\/t.co\/WOurUTVe",
  "id" : 172359071989637120,
  "created_at" : "2012-02-22 16:36:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172354670503792641",
  "text" : "RT @By_Bashar: \"The only true measure of success is the amount of joy we are feeling.\" ~ Abraham Hicks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172354022022447104",
    "text" : "\"The only true measure of success is the amount of joy we are feeling.\" ~ Abraham Hicks",
    "id" : 172354022022447104,
    "created_at" : "2012-02-22 16:16:15 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 172354670503792641,
  "created_at" : "2012-02-22 16:18:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172354164133855232",
  "text" : "RT @SheilaWalsh: If fame, wealth and beauty made people happy, Hollywood would be the happiest place on earth. This is clearly a fatally ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172353734007984128",
    "text" : "If fame, wealth and beauty made people happy, Hollywood would be the happiest place on earth. This is clearly a fatally flawed dream",
    "id" : 172353734007984128,
    "created_at" : "2012-02-22 16:15:07 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 172354164133855232,
  "created_at" : "2012-02-22 16:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/ijkLDfIf",
      "expanded_url" : "http:\/\/bit.ly\/Ay4M74",
      "display_url" : "bit.ly\/Ay4M74"
    } ]
  },
  "geo" : { },
  "id_str" : "172353582203551746",
  "text" : "RT @wow_trees: Rainn Wilson on spiritual revolution http:\/\/t.co\/ijkLDfIf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/ijkLDfIf",
        "expanded_url" : "http:\/\/bit.ly\/Ay4M74",
        "display_url" : "bit.ly\/Ay4M74"
      } ]
    },
    "geo" : { },
    "id_str" : "172352255398387713",
    "text" : "Rainn Wilson on spiritual revolution http:\/\/t.co\/ijkLDfIf",
    "id" : 172352255398387713,
    "created_at" : "2012-02-22 16:09:14 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 172353582203551746,
  "created_at" : "2012-02-22 16:14:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noam C.",
      "screen_name" : "Noamchomski",
      "indices" : [ 3, 15 ],
      "id_str" : "4827531879",
      "id" : 4827531879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172353282612793345",
  "text" : "RT @NoamChomski: You must learn to separate your reality from the false televised reality.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172351190779170816",
    "text" : "You must learn to separate your reality from the false televised reality.",
    "id" : 172351190779170816,
    "created_at" : "2012-02-22 16:05:00 +0000",
    "user" : {
      "name" : "Gore Vidal",
      "screen_name" : "GoreVidaI",
      "protected" : false,
      "id_str" : "314552752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261577927680\/04195b7bead5eb26cbf6440637b6a181_normal.jpeg",
      "id" : 314552752,
      "verified" : false
    }
  },
  "id" : 172353282612793345,
  "created_at" : "2012-02-22 16:13:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172350410135318528",
  "geo" : { },
  "id_str" : "172353246411755520",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time lots of weird viruses around. see others report long illness. feel better ((hugs))",
  "id" : 172353246411755520,
  "in_reply_to_status_id" : 172350410135318528,
  "created_at" : "2012-02-22 16:13:10 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172347706252070914",
  "text" : "did you know: the kingdom of god is within you by leo tolstoy inspired ghandi .. how cool!",
  "id" : 172347706252070914,
  "created_at" : "2012-02-22 15:51:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/fvSquo2o",
      "expanded_url" : "http:\/\/tinyurl.com\/6d57fo6",
      "display_url" : "tinyurl.com\/6d57fo6"
    } ]
  },
  "geo" : { },
  "id_str" : "172131879401684992",
  "text" : "RT @Seeds4Parents: Looking for God is like searching for sunglasses when they are on top of your head all along. http:\/\/t.co\/fvSquo2o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/fvSquo2o",
        "expanded_url" : "http:\/\/tinyurl.com\/6d57fo6",
        "display_url" : "tinyurl.com\/6d57fo6"
      } ]
    },
    "geo" : { },
    "id_str" : "172129360717955072",
    "text" : "Looking for God is like searching for sunglasses when they are on top of your head all along. http:\/\/t.co\/fvSquo2o",
    "id" : 172129360717955072,
    "created_at" : "2012-02-22 01:23:32 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 172131879401684992,
  "created_at" : "2012-02-22 01:33:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172123028862414848",
  "text" : "RT @dailygalaxy: Water! 140 Trillion Times Earth's Oceans--Surrounds a Voracious Black Hole at the Edge of the Universe \nhttp:\/\/t.co\/FVh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/FVh7jF28",
        "expanded_url" : "http:\/\/bit.ly\/AEZiWd",
        "display_url" : "bit.ly\/AEZiWd"
      } ]
    },
    "geo" : { },
    "id_str" : "172122330141700097",
    "text" : "Water! 140 Trillion Times Earth's Oceans--Surrounds a Voracious Black Hole at the Edge of the Universe \nhttp:\/\/t.co\/FVh7jF28",
    "id" : 172122330141700097,
    "created_at" : "2012-02-22 00:55:36 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 172123028862414848,
  "created_at" : "2012-02-22 00:58:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Rebel Renee",
      "screen_name" : "nay731",
      "indices" : [ 16, 23 ],
      "id_str" : "57466954",
      "id" : 57466954
    }, {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 25, 33 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WarriorsRUs",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172069322443857920",
  "text" : "RT @SangyeH: RT @nay731: @SangyeH Only way to combat an avalanche of hate is with an avalanche of love. #WarriorsRUs | Nice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rebel Renee",
        "screen_name" : "nay731",
        "indices" : [ 3, 10 ],
        "id_str" : "57466954",
        "id" : 57466954
      }, {
        "name" : "Ani Sangye",
        "screen_name" : "SangyeH",
        "indices" : [ 12, 20 ],
        "id_str" : "54744689",
        "id" : 54744689
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WarriorsRUs",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172068710339706880",
    "text" : "RT @nay731: @SangyeH Only way to combat an avalanche of hate is with an avalanche of love. #WarriorsRUs | Nice",
    "id" : 172068710339706880,
    "created_at" : "2012-02-21 21:22:32 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 172069322443857920,
  "created_at" : "2012-02-21 21:24:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/vDwXQSsi",
      "expanded_url" : "http:\/\/tinyurl.com\/888fl2u",
      "display_url" : "tinyurl.com\/888fl2u"
    } ]
  },
  "geo" : { },
  "id_str" : "172067000938541057",
  "text" : "RT @Soulseedzforall: They told me I wasn\u2019t really a boy today.\u201D New article http:\/\/t.co\/vDwXQSsi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/vDwXQSsi",
        "expanded_url" : "http:\/\/tinyurl.com\/888fl2u",
        "display_url" : "tinyurl.com\/888fl2u"
      } ]
    },
    "geo" : { },
    "id_str" : "172061255505412096",
    "text" : "They told me I wasn\u2019t really a boy today.\u201D New article http:\/\/t.co\/vDwXQSsi",
    "id" : 172061255505412096,
    "created_at" : "2012-02-21 20:52:54 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 172067000938541057,
  "created_at" : "2012-02-21 21:15:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172052789470560256",
  "text" : "oh yeah, hubby said I amazed him today..lol. I like to keep him on his toes..heehee",
  "id" : 172052789470560256,
  "created_at" : "2012-02-21 20:19:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172033465720651778",
  "text" : "the crows tell me its all ok...",
  "id" : 172033465720651778,
  "created_at" : "2012-02-21 19:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MB's eBookNewser",
      "screen_name" : "eBookNewser",
      "indices" : [ 3, 15 ],
      "id_str" : "509372493",
      "id" : 509372493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/UrXnbTEQ",
      "expanded_url" : "http:\/\/mbist.ro\/xKRe5R",
      "display_url" : "mbist.ro\/xKRe5R"
    } ]
  },
  "geo" : { },
  "id_str" : "171964435714424835",
  "text" : "RT @eBookNewser: Kindle Fire 2, already? http:\/\/t.co\/UrXnbTEQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/UrXnbTEQ",
        "expanded_url" : "http:\/\/mbist.ro\/xKRe5R",
        "display_url" : "mbist.ro\/xKRe5R"
      } ]
    },
    "geo" : { },
    "id_str" : "171963180568936448",
    "text" : "Kindle Fire 2, already? http:\/\/t.co\/UrXnbTEQ",
    "id" : 171963180568936448,
    "created_at" : "2012-02-21 14:23:11 +0000",
    "user" : {
      "name" : "AppNewser",
      "screen_name" : "AppNewser",
      "protected" : false,
      "id_str" : "90893629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461987151496744960\/7LSAvXUw_normal.png",
      "id" : 90893629,
      "verified" : false
    }
  },
  "id" : 171964435714424835,
  "created_at" : "2012-02-21 14:28:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilke Breder",
      "screen_name" : "onejackdaw",
      "indices" : [ 3, 14 ],
      "id_str" : "79162356",
      "id" : 79162356
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/bywJNt8Z",
      "expanded_url" : "http:\/\/nyti.ms\/xhThhG",
      "display_url" : "nyti.ms\/xhThhG"
    } ]
  },
  "geo" : { },
  "id_str" : "171964241933385729",
  "text" : "RT @onejackdaw: Cosmologists Try to Explain a Universe Springing From Nothing: http:\/\/t.co\/bywJNt8Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/bywJNt8Z",
        "expanded_url" : "http:\/\/nyti.ms\/xhThhG",
        "display_url" : "nyti.ms\/xhThhG"
      } ]
    },
    "geo" : { },
    "id_str" : "171963246608265216",
    "text" : "Cosmologists Try to Explain a Universe Springing From Nothing: http:\/\/t.co\/bywJNt8Z",
    "id" : 171963246608265216,
    "created_at" : "2012-02-21 14:23:27 +0000",
    "user" : {
      "name" : "Hilke Breder",
      "screen_name" : "onejackdaw",
      "protected" : false,
      "id_str" : "79162356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595735568\/HB_4_4048_normal.jpg",
      "id" : 79162356,
      "verified" : false
    }
  },
  "id" : 171964241933385729,
  "created_at" : "2012-02-21 14:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin",
      "screen_name" : "mrscapra",
      "indices" : [ 0, 9 ],
      "id_str" : "1969965566",
      "id" : 1969965566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171951638175682560",
  "text" : "@MrsCapra its therapeutic! : )",
  "id" : 171951638175682560,
  "created_at" : "2012-02-21 13:37:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Jenkins",
      "screen_name" : "rachelbirder",
      "indices" : [ 3, 16 ],
      "id_str" : "25067227",
      "id" : 25067227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/TBu4uJi5",
      "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2012\/02\/120220161307.htm",
      "display_url" : "sciencedaily.com\/releases\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171950023796461568",
  "text" : "RT @rachelbirder: 300-million-yr-old forest found buried under volcanic ash http:\/\/t.co\/TBu4uJi5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/iTweet.net\" rel=\"nofollow\"\u003EiTweet.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/TBu4uJi5",
        "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2012\/02\/120220161307.htm",
        "display_url" : "sciencedaily.com\/releases\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "171946418037207040",
    "text" : "300-million-yr-old forest found buried under volcanic ash http:\/\/t.co\/TBu4uJi5",
    "id" : 171946418037207040,
    "created_at" : "2012-02-21 13:16:35 +0000",
    "user" : {
      "name" : "Rachel Jenkins",
      "screen_name" : "rachelbirder",
      "protected" : false,
      "id_str" : "25067227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140703050\/2-11-09_010_normal.JPG",
      "id" : 25067227,
      "verified" : false
    }
  },
  "id" : 171950023796461568,
  "created_at" : "2012-02-21 13:30:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171779636978651136",
  "text" : "I swear I think I have some weird latent viral thing. sometimes my blood feels weird.",
  "id" : 171779636978651136,
  "created_at" : "2012-02-21 02:13:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnn",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/TvxGazgh",
      "expanded_url" : "http:\/\/www.cnn.com\/2012\/02\/20\/politics\/ensign-vet\/index.html",
      "display_url" : "cnn.com\/2012\/02\/20\/pol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171768907479261184",
  "text" : "From senators to animals: Lawmaker who fell from grace now working as a vet http:\/\/t.co\/TvxGazgh #cnn",
  "id" : 171768907479261184,
  "created_at" : "2012-02-21 01:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171759668929118209",
  "geo" : { },
  "id_str" : "171765862808829953",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves hmm.. whats that quote?? \"what others think of you is none of your business\" ; ) what YOU think of you is what counts!",
  "id" : 171765862808829953,
  "in_reply_to_status_id" : 171759668929118209,
  "created_at" : "2012-02-21 01:19:07 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171735100172681216",
  "geo" : { },
  "id_str" : "171747623995314178",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin awww, thats cute : )",
  "id" : 171747623995314178,
  "in_reply_to_status_id" : 171735100172681216,
  "created_at" : "2012-02-21 00:06:39 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171745660549349377",
  "text" : "nature of personal reality (seth) by jane roberts \/  the kingdom of god is within you by leo tolstoy",
  "id" : 171745660549349377,
  "created_at" : "2012-02-20 23:58:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171745171778715648",
  "text" : "hubby took me to B&N today. got to browse for a long time : ) and get 2 books!",
  "id" : 171745171778715648,
  "created_at" : "2012-02-20 23:56:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171654791284535297",
  "text" : "hubby is so excited. got so many replies to ad for free boat. local person is taking it tomorrow.",
  "id" : 171654791284535297,
  "created_at" : "2012-02-20 17:57:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harley Dean Mathews",
      "screen_name" : "crossbonesmin",
      "indices" : [ 3, 17 ],
      "id_str" : "23484033",
      "id" : 23484033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171654437847318528",
  "text" : "RT @crossbonesmin: Do any pastors or ppl on here have or know of a Bible that separated the different writers of the OT as J E P etc? #s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Outlaw Preachers",
        "screen_name" : "outlawpreachers",
        "indices" : [ 122, 138 ],
        "id_str" : "63836224",
        "id" : 63836224
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "study",
        "indices" : [ 115, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171651594490888192",
    "text" : "Do any pastors or ppl on here have or know of a Bible that separated the different writers of the OT as J E P etc? #study @outlawpreachers",
    "id" : 171651594490888192,
    "created_at" : "2012-02-20 17:45:03 +0000",
    "user" : {
      "name" : "Harley Dean Mathews",
      "screen_name" : "crossbonesmin",
      "protected" : false,
      "id_str" : "23484033",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565960539302400000\/iGCI4KaR_normal.jpeg",
      "id" : 23484033,
      "verified" : false
    }
  },
  "id" : 171654437847318528,
  "created_at" : "2012-02-20 17:56:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "penetration",
      "indices" : [ 48, 60 ]
    }, {
      "text" : "GOP",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171653695350640641",
  "text" : "RT @bend_time: so,if a woman is against vaginal #penetration ultrasound, but forced to have it anyway, #GOP, isnt that also a definition ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "penetration",
        "indices" : [ 33, 45 ]
      }, {
        "text" : "GOP",
        "indices" : [ 88, 92 ]
      }, {
        "text" : "rape",
        "indices" : [ 125, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171652470227996672",
    "text" : "so,if a woman is against vaginal #penetration ultrasound, but forced to have it anyway, #GOP, isnt that also a definition of #rape?",
    "id" : 171652470227996672,
    "created_at" : "2012-02-20 17:48:32 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 171653695350640641,
  "created_at" : "2012-02-20 17:53:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xavier",
      "screen_name" : "Rev_Xavier",
      "indices" : [ 3, 14 ],
      "id_str" : "335740776",
      "id" : 335740776
    }, {
      "name" : "DC Debbie",
      "screen_name" : "DCdebbie",
      "indices" : [ 19, 28 ],
      "id_str" : "14266637",
      "id" : 14266637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171653566359027713",
  "text" : "RT @Rev_Xavier: RT @DCdebbie: Twitter Poll: retweet this if you think birth control should be legal and accessible to all women, especia ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DC Debbie",
        "screen_name" : "DCdebbie",
        "indices" : [ 3, 12 ],
        "id_str" : "14266637",
        "id" : 14266637
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171628746971955200",
    "text" : "RT @DCdebbie: Twitter Poll: retweet this if you think birth control should be legal and accessible to all women, especially the poor.",
    "id" : 171628746971955200,
    "created_at" : "2012-02-20 16:14:16 +0000",
    "user" : {
      "name" : "Xavier",
      "screen_name" : "Rev_Xavier",
      "protected" : false,
      "id_str" : "335740776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800778567349047300\/zsMRYmAv_normal.jpg",
      "id" : 335740776,
      "verified" : false
    }
  },
  "id" : 171653566359027713,
  "created_at" : "2012-02-20 17:52:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WiseStamp",
      "screen_name" : "WiseStamp",
      "indices" : [ 3, 13 ],
      "id_str" : "15892927",
      "id" : 15892927
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pinterest",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/31RMZQ8g",
      "expanded_url" : "http:\/\/bit.ly\/yaqvfm",
      "display_url" : "bit.ly\/yaqvfm"
    } ]
  },
  "geo" : { },
  "id_str" : "171637674929688576",
  "text" : "RT @WiseStamp: Pinterest users check this out: 2 new ways to promote your #Pinterest with WiseStamp | WiseStamp Blog \u261Bhttp:\/\/t.co\/31RMZQ8g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pinterest",
        "indices" : [ 59, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/31RMZQ8g",
        "expanded_url" : "http:\/\/bit.ly\/yaqvfm",
        "display_url" : "bit.ly\/yaqvfm"
      } ]
    },
    "geo" : { },
    "id_str" : "171637024275701761",
    "text" : "Pinterest users check this out: 2 new ways to promote your #Pinterest with WiseStamp | WiseStamp Blog \u261Bhttp:\/\/t.co\/31RMZQ8g",
    "id" : 171637024275701761,
    "created_at" : "2012-02-20 16:47:10 +0000",
    "user" : {
      "name" : "WiseStamp",
      "screen_name" : "WiseStamp",
      "protected" : false,
      "id_str" : "15892927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705091492637974528\/-9Jqy_jM_normal.jpg",
      "id" : 15892927,
      "verified" : false
    }
  },
  "id" : 171637674929688576,
  "created_at" : "2012-02-20 16:49:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171637435065831424",
  "text" : "@SocialistXian how I felt when I went to local church.. and now.. going to bible study. \"dont throw baby out w bath water\" &lt;-- my motto..lol",
  "id" : 171637435065831424,
  "created_at" : "2012-02-20 16:48:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171634962729152512",
  "text" : "i love you #justsayin",
  "id" : 171634962729152512,
  "created_at" : "2012-02-20 16:38:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cara Lynch",
      "screen_name" : "caradox",
      "indices" : [ 3, 11 ],
      "id_str" : "19045427",
      "id" : 19045427
    }, {
      "name" : "pourmecoffee",
      "screen_name" : "pourmecoffee",
      "indices" : [ 16, 29 ],
      "id_str" : "16906137",
      "id" : 16906137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171426527894970369",
  "text" : "RT @caradox: RT @pourmecoffee: If Rick Santorum has not yet judged the adequacy of your faith, please be patient as he works through the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pourmecoffee",
        "screen_name" : "pourmecoffee",
        "indices" : [ 3, 16 ],
        "id_str" : "16906137",
        "id" : 16906137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171423939736764416",
    "text" : "RT @pourmecoffee: If Rick Santorum has not yet judged the adequacy of your faith, please be patient as he works through the backlog.",
    "id" : 171423939736764416,
    "created_at" : "2012-02-20 02:40:26 +0000",
    "user" : {
      "name" : "Cara Lynch",
      "screen_name" : "caradox",
      "protected" : false,
      "id_str" : "19045427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1930663719\/Cara_normal.jpg",
      "id" : 19045427,
      "verified" : false
    }
  },
  "id" : 171426527894970369,
  "created_at" : "2012-02-20 02:50:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ninethousandone",
      "screen_name" : "icpchad",
      "indices" : [ 3, 11 ],
      "id_str" : "16603994",
      "id" : 16603994
    }, {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 13, 26 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171426315839344640",
  "text" : "RT @icpchad: @UnseeingEyes - What if every point of view is needed as a piece in a puzzle ... to make the picture complete?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vincenzo Scipioni",
        "screen_name" : "UnseeingEyes",
        "indices" : [ 0, 13 ],
        "id_str" : "36008885",
        "id" : 36008885
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "171424183941726208",
    "geo" : { },
    "id_str" : "171424809933225985",
    "in_reply_to_user_id" : 36008885,
    "text" : "@UnseeingEyes - What if every point of view is needed as a piece in a puzzle ... to make the picture complete?",
    "id" : 171424809933225985,
    "in_reply_to_status_id" : 171424183941726208,
    "created_at" : "2012-02-20 02:43:54 +0000",
    "in_reply_to_screen_name" : "UnseeingEyes",
    "in_reply_to_user_id_str" : "36008885",
    "user" : {
      "name" : "ninethousandone",
      "screen_name" : "icpchad",
      "protected" : false,
      "id_str" : "16603994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681887434\/modernman533_normal.jpg",
      "id" : 16603994,
      "verified" : false
    }
  },
  "id" : 171426315839344640,
  "created_at" : "2012-02-20 02:49:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171417581037686784",
  "text" : "RT @UnseeingEyes: Right or wrong? Rid your mind of those concepts. Even thinking...for most people \"thinking\" is detrimental. Focus on \" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171417368537468928",
    "text" : "Right or wrong? Rid your mind of those concepts. Even thinking...for most people \"thinking\" is detrimental. Focus on \"the good.\"",
    "id" : 171417368537468928,
    "created_at" : "2012-02-20 02:14:20 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 171417581037686784,
  "created_at" : "2012-02-20 02:15:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "indices" : [ 3, 17 ],
      "id_str" : "20444825",
      "id" : 20444825
    }, {
      "name" : "Rick Santorum",
      "screen_name" : "RickSantorum",
      "indices" : [ 71, 84 ],
      "id_str" : "58379000",
      "id" : 58379000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171415847791894528",
  "text" : "RT @genetics_blog: when should I recieve my iraq war reimbursement? RT @RickSantorum: Govt cannot force you to pay for something that vi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Santorum",
        "screen_name" : "RickSantorum",
        "indices" : [ 52, 65 ],
        "id_str" : "58379000",
        "id" : 58379000
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171390355789463552",
    "text" : "when should I recieve my iraq war reimbursement? RT @RickSantorum: Govt cannot force you to pay for something that violates faith or beliefs",
    "id" : 171390355789463552,
    "created_at" : "2012-02-20 00:26:59 +0000",
    "user" : {
      "name" : "Stephen Turner",
      "screen_name" : "genetics_blog",
      "protected" : false,
      "id_str" : "20444825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660439762856230913\/ARYE5YB6_normal.jpg",
      "id" : 20444825,
      "verified" : false
    }
  },
  "id" : 171415847791894528,
  "created_at" : "2012-02-20 02:08:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171412968620294144",
  "text" : "@SocialistXian insecurity...",
  "id" : 171412968620294144,
  "created_at" : "2012-02-20 01:56:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171411438089420800",
  "text" : "RT @umairh: Folks, it's not important that we all \"agree\". It's important that we all have the freedom to think, reason, feel. And live.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171067672665145344",
    "text" : "Folks, it's not important that we all \"agree\". It's important that we all have the freedom to think, reason, feel. And live.",
    "id" : 171067672665145344,
    "created_at" : "2012-02-19 03:04:46 +0000",
    "user" : {
      "name" : "\u2764\uFE0F",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773859502227595265\/AxQy4xO0_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 171411438089420800,
  "created_at" : "2012-02-20 01:50:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 14, 27 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171405087174963200",
  "geo" : { },
  "id_str" : "171411173655326720",
  "in_reply_to_user_id" : 36008885,
  "text" : "or at least.. @UnseeingEyes an accessible parent but society has made that extremely difficult.",
  "id" : 171411173655326720,
  "in_reply_to_status_id" : 171405087174963200,
  "created_at" : "2012-02-20 01:49:43 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171405910420357120",
  "geo" : { },
  "id_str" : "171410464864092161",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad : (((((",
  "id" : 171410464864092161,
  "in_reply_to_status_id" : 171405910420357120,
  "created_at" : "2012-02-20 01:46:54 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Spiewak",
      "screen_name" : "jasonspiewak",
      "indices" : [ 3, 16 ],
      "id_str" : "33041669",
      "id" : 33041669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171394143212404736",
  "text" : "RT @jasonspiewak: A black belt is a white belt that never quit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170915485142097920",
    "text" : "A black belt is a white belt that never quit",
    "id" : 170915485142097920,
    "created_at" : "2012-02-18 17:00:01 +0000",
    "user" : {
      "name" : "Jason Spiewak",
      "screen_name" : "jasonspiewak",
      "protected" : false,
      "id_str" : "33041669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/145539028\/fishin_normal.jpg",
      "id" : 33041669,
      "verified" : false
    }
  },
  "id" : 171394143212404736,
  "created_at" : "2012-02-20 00:42:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bren\u00E9 Brown",
      "screen_name" : "BreneBrown",
      "indices" : [ 3, 14 ],
      "id_str" : "14717311",
      "id" : 14717311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171362096393625600",
  "text" : "RT @BreneBrown: The scientists + theologians who insist we choose between science + faith have abandoned the heart of both: curiosity +  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171360517905055745",
    "text" : "The scientists + theologians who insist we choose between science + faith have abandoned the heart of both: curiosity + mystery.",
    "id" : 171360517905055745,
    "created_at" : "2012-02-19 22:28:25 +0000",
    "user" : {
      "name" : "Bren\u00E9 Brown",
      "screen_name" : "BreneBrown",
      "protected" : false,
      "id_str" : "14717311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/690719388828246016\/ngOQQnrd_normal.jpg",
      "id" : 14717311,
      "verified" : true
    }
  },
  "id" : 171362096393625600,
  "created_at" : "2012-02-19 22:34:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171361408116727809",
  "text" : "RT @oshum: Are Truth and Lie...Enemies?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171359548190363649",
    "text" : "Are Truth and Lie...Enemies?",
    "id" : 171359548190363649,
    "created_at" : "2012-02-19 22:24:34 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 171361408116727809,
  "created_at" : "2012-02-19 22:31:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 24, 30 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171361029358489600",
  "text" : "the bass guitar! : ) RT @oshum: If Angels play Harps....what does the Devil play?",
  "id" : 171361029358489600,
  "created_at" : "2012-02-19 22:30:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171360096364933120",
  "geo" : { },
  "id_str" : "171360619117817856",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ; ) woohoo!",
  "id" : 171360619117817856,
  "in_reply_to_status_id" : 171360096364933120,
  "created_at" : "2012-02-19 22:28:49 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171340832643874816",
  "text" : "RT @TrishScott: RT @ieyeayes: Top Ten Catholic Teachings Santorum Rejects while Obsessing about Birth Control http:\/\/t.co\/TDFcIeZd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/TDFcIeZd",
        "expanded_url" : "http:\/\/www.juancole.com\/2012\/02\/top-ten-catholic-teachings-santorum-rejects-while-obsessing-about-birth-control.html",
        "display_url" : "juancole.com\/2012\/02\/top-te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "171336904791429122",
    "text" : "RT @ieyeayes: Top Ten Catholic Teachings Santorum Rejects while Obsessing about Birth Control http:\/\/t.co\/TDFcIeZd",
    "id" : 171336904791429122,
    "created_at" : "2012-02-19 20:54:36 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 171340832643874816,
  "created_at" : "2012-02-19 21:10:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma White",
      "screen_name" : "TheRealSupermum",
      "indices" : [ 3, 19 ],
      "id_str" : "254781401",
      "id" : 254781401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171330635875622912",
  "text" : "RT @TheRealSupermum: This remote is broken. I've pushed pause,power,sleep, mute,volume, nothing works! I don't understand! I'm pointing  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171323177975291904",
    "text" : "This remote is broken. I've pushed pause,power,sleep, mute,volume, nothing works! I don't understand! I'm pointing it right at the children!",
    "id" : 171323177975291904,
    "created_at" : "2012-02-19 20:00:03 +0000",
    "user" : {
      "name" : "Emma White",
      "screen_name" : "TheRealSupermum",
      "protected" : false,
      "id_str" : "254781401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653490744687243264\/I7UirP7N_normal.jpg",
      "id" : 254781401,
      "verified" : false
    }
  },
  "id" : 171330635875622912,
  "created_at" : "2012-02-19 20:29:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pinterest",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171330153971060737",
  "text" : "didnt think about that.. when adding to #pinterest about copyright stuff. maybe I'll just stick to like or re-pin, not adding...",
  "id" : 171330153971060737,
  "created_at" : "2012-02-19 20:27:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Dale Emery",
      "screen_name" : "dhemery",
      "indices" : [ 25, 33 ],
      "id_str" : "9040122",
      "id" : 9040122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171320691927425025",
  "text" : "RT @angelaharms: Yes! RT @dhemery \"I knew I should\" is not  the whole truth. More true: Some part of me \"knew I should,\" and other parts ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dale Emery",
        "screen_name" : "dhemery",
        "indices" : [ 8, 16 ],
        "id_str" : "9040122",
        "id" : 9040122
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171319458621698048",
    "text" : "Yes! RT @dhemery \"I knew I should\" is not  the whole truth. More true: Some part of me \"knew I should,\" and other parts of me disagreed.",
    "id" : 171319458621698048,
    "created_at" : "2012-02-19 19:45:16 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 171320691927425025,
  "created_at" : "2012-02-19 19:50:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 3, 12 ],
      "id_str" : "18581294",
      "id" : 18581294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instagram",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/lYWyNu73",
      "expanded_url" : "http:\/\/ow.ly\/99KXW",
      "display_url" : "ow.ly\/99KXW"
    } ]
  },
  "geo" : { },
  "id_str" : "171309651000967169",
  "text" : "RT @namenick: Cool #instagram pictures of readers and their ebooks http:\/\/t.co\/lYWyNu73",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "instagram",
        "indices" : [ 5, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/lYWyNu73",
        "expanded_url" : "http:\/\/ow.ly\/99KXW",
        "display_url" : "ow.ly\/99KXW"
      } ]
    },
    "geo" : { },
    "id_str" : "171173821968171008",
    "text" : "Cool #instagram pictures of readers and their ebooks http:\/\/t.co\/lYWyNu73",
    "id" : 171173821968171008,
    "created_at" : "2012-02-19 10:06:34 +0000",
    "user" : {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "protected" : false,
      "id_str" : "18581294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739156618710024192\/iSvI5Blh_normal.jpg",
      "id" : 18581294,
      "verified" : false
    }
  },
  "id" : 171309651000967169,
  "created_at" : "2012-02-19 19:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "indices" : [ 3, 16 ],
      "id_str" : "15120037",
      "id" : 15120037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171306027701125121",
  "text" : "RT @AnissaMayhew: You guys make me happu to have Twitter as more than a social media tool, it's a place I can enjoy my friends and their ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171295299954933760",
    "text" : "You guys make me happu to have Twitter as more than a social media tool, it's a place I can enjoy my friends and their craziness",
    "id" : 171295299954933760,
    "created_at" : "2012-02-19 18:09:16 +0000",
    "user" : {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "protected" : false,
      "id_str" : "15120037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3062161006\/ad2239750e205707bab7b90d1b5e5373_normal.jpeg",
      "id" : 15120037,
      "verified" : false
    }
  },
  "id" : 171306027701125121,
  "created_at" : "2012-02-19 18:51:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171304948536057859",
  "text" : "@Tideliar awww... that's so sweet! lol",
  "id" : 171304948536057859,
  "created_at" : "2012-02-19 18:47:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail Phelps",
      "screen_name" : "Gailrphelps",
      "indices" : [ 3, 15 ],
      "id_str" : "78799957",
      "id" : 78799957
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/7qFkISIs",
      "expanded_url" : "http:\/\/bridgingtime.com\/page0005.html",
      "display_url" : "bridgingtime.com\/page0005.html"
    } ]
  },
  "geo" : { },
  "id_str" : "171284524628582400",
  "text" : "RT @Gailrphelps: The proof of God is in the experience  http:\/\/t.co\/7qFkISIs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/7qFkISIs",
        "expanded_url" : "http:\/\/bridgingtime.com\/page0005.html",
        "display_url" : "bridgingtime.com\/page0005.html"
      } ]
    },
    "geo" : { },
    "id_str" : "171283793947262976",
    "text" : "The proof of God is in the experience  http:\/\/t.co\/7qFkISIs",
    "id" : 171283793947262976,
    "created_at" : "2012-02-19 17:23:33 +0000",
    "user" : {
      "name" : "Gail Phelps",
      "screen_name" : "Gailrphelps",
      "protected" : false,
      "id_str" : "78799957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1431633625\/sandy_normal.jpg",
      "id" : 78799957,
      "verified" : false
    }
  },
  "id" : 171284524628582400,
  "created_at" : "2012-02-19 17:26:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 25, 40 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pinterest",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/FrTCgTSH",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/200410252137886195\/",
      "display_url" : "pinterest.com\/pin\/2004102521\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171283616280756224",
  "text" : "making Cindy famous..lol @ducksandclucks http:\/\/t.co\/FrTCgTSH #pinterest",
  "id" : 171283616280756224,
  "created_at" : "2012-02-19 17:22:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "indices" : [ 3, 16 ],
      "id_str" : "74399881",
      "id" : 74399881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171274633981591554",
  "text" : "RT @pamelamarie8: fear is an illusion....love is the only answer!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171273945608232960",
    "text" : "fear is an illusion....love is the only answer!",
    "id" : 171273945608232960,
    "created_at" : "2012-02-19 16:44:25 +0000",
    "user" : {
      "name" : "Pam",
      "screen_name" : "pamelamarie8",
      "protected" : false,
      "id_str" : "74399881",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445924023600287744\/sh9pRUES_normal.jpeg",
      "id" : 74399881,
      "verified" : false
    }
  },
  "id" : 171274633981591554,
  "created_at" : "2012-02-19 16:47:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/szwnyAJ2",
      "expanded_url" : "http:\/\/twitpic.com\/8m1xn7",
      "display_url" : "twitpic.com\/8m1xn7"
    } ]
  },
  "geo" : { },
  "id_str" : "171272953290428420",
  "text" : "RT @ducksandclucks: Cindy Buttons: Give. Me. That. Cookie. Right. Now. Or. Else. http:\/\/t.co\/szwnyAJ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/szwnyAJ2",
        "expanded_url" : "http:\/\/twitpic.com\/8m1xn7",
        "display_url" : "twitpic.com\/8m1xn7"
      } ]
    },
    "geo" : { },
    "id_str" : "171272566323945472",
    "text" : "Cindy Buttons: Give. Me. That. Cookie. Right. Now. Or. Else. http:\/\/t.co\/szwnyAJ2",
    "id" : 171272566323945472,
    "created_at" : "2012-02-19 16:38:56 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 171272953290428420,
  "created_at" : "2012-02-19 16:40:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "indices" : [ 3, 18 ],
      "id_str" : "272595921",
      "id" : 272595921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/3GQOYUnb",
      "expanded_url" : "http:\/\/twitpic.com\/8m1wr3",
      "display_url" : "twitpic.com\/8m1wr3"
    } ]
  },
  "geo" : { },
  "id_str" : "171272668950171650",
  "text" : "RT @ducksandclucks: I am being sat upon. http:\/\/t.co\/3GQOYUnb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/3GQOYUnb",
        "expanded_url" : "http:\/\/twitpic.com\/8m1wr3",
        "display_url" : "twitpic.com\/8m1wr3"
      } ]
    },
    "geo" : { },
    "id_str" : "171272088450113537",
    "text" : "I am being sat upon. http:\/\/t.co\/3GQOYUnb",
    "id" : 171272088450113537,
    "created_at" : "2012-02-19 16:37:02 +0000",
    "user" : {
      "name" : "Ducks and Clucks",
      "screen_name" : "ducksandclucks",
      "protected" : false,
      "id_str" : "272595921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714872721482588160\/nIICo_YT_normal.jpg",
      "id" : 272595921,
      "verified" : false
    }
  },
  "id" : 171272668950171650,
  "created_at" : "2012-02-19 16:39:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 36 ],
      "url" : "https:\/\/t.co\/iSiIZKxZ",
      "expanded_url" : "https:\/\/twitter.com\/#!\/moosebegab\/status\/171268992193929216",
      "display_url" : "twitter.com\/#!\/moosebegab\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171272167340785664",
  "text" : "@BibleAlsoSays https:\/\/t.co\/iSiIZKxZ",
  "id" : 171272167340785664,
  "created_at" : "2012-02-19 16:37:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 8, 22 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171269848037466115",
  "text" : "I think @biblealsosays would get a kick out of my previous tweet. Vikki's comment made me giggle.. lol",
  "id" : 171269848037466115,
  "created_at" : "2012-02-19 16:28:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/FL8psq7b",
      "expanded_url" : "http:\/\/tl.gd\/g0o3uo",
      "display_url" : "tl.gd\/g0o3uo"
    } ]
  },
  "geo" : { },
  "id_str" : "171268992193929216",
  "text" : "LOL &gt;&gt; \"I get so confused...a wife is supposed to have sex with her husband whenever he wants it because the (cont) http:\/\/t.co\/FL8psq7b",
  "id" : 171268992193929216,
  "created_at" : "2012-02-19 16:24:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USE",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171045524022112256",
  "text" : "RT @UnseeingEyes: Today is the start of a new way of thinking. #USE -V-",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USE",
        "indices" : [ 45, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170860882316898305",
    "text" : "Today is the start of a new way of thinking. #USE -V-",
    "id" : 170860882316898305,
    "created_at" : "2012-02-18 13:23:03 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 171045524022112256,
  "created_at" : "2012-02-19 01:36:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMGFacts Celebs",
      "screen_name" : "OMGFactsCelebs",
      "indices" : [ 3, 18 ],
      "id_str" : "705411897323970560",
      "id" : 705411897323970560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171045057309315073",
  "text" : "RT @OMGFactsCelebs: Aerosmith's Dude Looks Like a Lady was written about Vince Neil of Motley Crue.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169964431688728576",
    "text" : "Aerosmith's Dude Looks Like a Lady was written about Vince Neil of Motley Crue.",
    "id" : 169964431688728576,
    "created_at" : "2012-02-16 02:00:52 +0000",
    "user" : {
      "name" : "Dose Hollywood",
      "screen_name" : "DoseOfHollywood",
      "protected" : false,
      "id_str" : "184648622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705417258235875328\/f3xWXtH1_normal.jpg",
      "id" : 184648622,
      "verified" : false
    }
  },
  "id" : 171045057309315073,
  "created_at" : "2012-02-19 01:34:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Studios",
      "screen_name" : "WordHero",
      "indices" : [ 13, 22 ],
      "id_str" : "349186626",
      "id" : 349186626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 29, 40 ]
    }, {
      "text" : "android",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "wordgame",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171018674973573120",
  "text" : "love playing @WordHero on my #kindlefire .. my new addiction #android #wordgame",
  "id" : 171018674973573120,
  "created_at" : "2012-02-18 23:50:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171015760687267840",
  "text" : "we ran out of cat food for our diner customers so they are getting leftover cold cuts and the good cat food! lol",
  "id" : 171015760687267840,
  "created_at" : "2012-02-18 23:38:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170943722136145923",
  "geo" : { },
  "id_str" : "170947866028810242",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous wow! well, im sooo excited for you : )",
  "id" : 170947866028810242,
  "in_reply_to_status_id" : 170943722136145923,
  "created_at" : "2012-02-18 19:08:41 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170943995000795136",
  "geo" : { },
  "id_str" : "170947560691875841",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous lol.. aww.. you dont have to. im just nosy! : )",
  "id" : 170947560691875841,
  "in_reply_to_status_id" : 170943995000795136,
  "created_at" : "2012-02-18 19:07:29 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170927380137902081",
  "text" : "usps site is stupid. #justsayin",
  "id" : 170927380137902081,
  "created_at" : "2012-02-18 17:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170917889409421312",
  "text" : "RT @AniKnits: There are 6 billion people on this Earth. There are. 6 billion paths to the top of the mountain to meet God. ~Dalai Lama v ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170917719674322946",
    "text" : "There are 6 billion people on this Earth. There are. 6 billion paths to the top of the mountain to meet God. ~Dalai Lama via @reikihealingny",
    "id" : 170917719674322946,
    "created_at" : "2012-02-18 17:08:54 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 170917889409421312,
  "created_at" : "2012-02-18 17:09:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David A. Graham",
      "screen_name" : "GrahamDavidA",
      "indices" : [ 3, 16 ],
      "id_str" : "46955476",
      "id" : 46955476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170912438827491328",
  "text" : "RT @GrahamDavidA: HOLY SHIT: Va. GOP lawmaker: women had already made the decision to be \"vaginally penetrated when they got pregnant.\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/0482WPVG",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/double_x\/doublex\/2012\/02\/virginia_ultrasound_law_women_who_want_an_abortion_will_be_forcibly_penetrated_for_no_medical_reason.single.html",
        "display_url" : "slate.com\/articles\/doubl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170550506031288321",
    "text" : "HOLY SHIT: Va. GOP lawmaker: women had already made the decision to be \"vaginally penetrated when they got pregnant.\" http:\/\/t.co\/0482WPVG",
    "id" : 170550506031288321,
    "created_at" : "2012-02-17 16:49:43 +0000",
    "user" : {
      "name" : "David A. Graham",
      "screen_name" : "GrahamDavidA",
      "protected" : false,
      "id_str" : "46955476",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522799754778931200\/72hRBE0y_normal.jpeg",
      "id" : 46955476,
      "verified" : true
    }
  },
  "id" : 170912438827491328,
  "created_at" : "2012-02-18 16:47:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170908732161654784",
  "text" : "RT @CrystalLewis: I really don't want to bore\/annoy y'all with my \"Hell\" soapbox again, but if u blv God owns an afterlife torture chamb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170908412429860864",
    "text" : "I really don't want to bore\/annoy y'all with my \"Hell\" soapbox again, but if u blv God owns an afterlife torture chamber, please reconsider.",
    "id" : 170908412429860864,
    "created_at" : "2012-02-18 16:31:55 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 170908732161654784,
  "created_at" : "2012-02-18 16:33:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 0, 13 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170907398343634944",
  "geo" : { },
  "id_str" : "170907837894111233",
  "in_reply_to_user_id" : 135615040,
  "text" : "@CrystalLewis oh my..",
  "id" : 170907837894111233,
  "in_reply_to_status_id" : 170907398343634944,
  "created_at" : "2012-02-18 16:29:38 +0000",
  "in_reply_to_screen_name" : "CrystalLewis",
  "in_reply_to_user_id_str" : "135615040",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170865936344158208",
  "geo" : { },
  "id_str" : "170907327417946113",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous awesome!! miss nosy here will want to hear all the details afterwards! lol",
  "id" : 170907327417946113,
  "in_reply_to_status_id" : 170865936344158208,
  "created_at" : "2012-02-18 16:27:36 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170905739831951360",
  "geo" : { },
  "id_str" : "170906689434959872",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous omg.. how did I miss this? ((goingtocheckoutyourtimeline))",
  "id" : 170906689434959872,
  "in_reply_to_status_id" : 170905739831951360,
  "created_at" : "2012-02-18 16:25:04 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "petpeeve",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170906360010117122",
  "text" : "#petpeeve ppl using term \"sheep\" in a bad way. I love sheep.. gentle, quiet grazers.",
  "id" : 170906360010117122,
  "created_at" : "2012-02-18 16:23:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satan DeSade",
      "screen_name" : "TheLadySatan",
      "indices" : [ 3, 16 ],
      "id_str" : "51739434",
      "id" : 51739434
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 18, 32 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170905410331623424",
  "text" : "RT @TheLadySatan: @BibleAlsoSays @ashleyjones_08 Heaven = the ultimate carrot and stick schtick.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BibleAlsoSays",
        "screen_name" : "BibleAlsoSays",
        "indices" : [ 0, 14 ],
        "id_str" : "2511428924",
        "id" : 2511428924
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170902281183698944",
    "text" : "@BibleAlsoSays @ashleyjones_08 Heaven = the ultimate carrot and stick schtick.",
    "id" : 170902281183698944,
    "created_at" : "2012-02-18 16:07:33 +0000",
    "user" : {
      "name" : "Satan DeSade",
      "screen_name" : "TheLadySatan",
      "protected" : false,
      "id_str" : "51739434",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573156124427345920\/3HrqJ4o3_normal.jpeg",
      "id" : 51739434,
      "verified" : false
    }
  },
  "id" : 170905410331623424,
  "created_at" : "2012-02-18 16:19:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/3jtR6TGy",
      "expanded_url" : "http:\/\/bit.ly\/zTCl2q",
      "display_url" : "bit.ly\/zTCl2q"
    } ]
  },
  "geo" : { },
  "id_str" : "170593330038718465",
  "text" : "RT @holycutenesss: Dormouse saved after walking into tea shop http:\/\/t.co\/3jtR6TGy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/3jtR6TGy",
        "expanded_url" : "http:\/\/bit.ly\/zTCl2q",
        "display_url" : "bit.ly\/zTCl2q"
      } ]
    },
    "geo" : { },
    "id_str" : "170592301326929920",
    "text" : "Dormouse saved after walking into tea shop http:\/\/t.co\/3jtR6TGy",
    "id" : 170592301326929920,
    "created_at" : "2012-02-17 19:35:48 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 170593330038718465,
  "created_at" : "2012-02-17 19:39:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 3, 11 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170592372919504896",
  "text" : "RT @mercola: Those who eat moderately high levels of protein are twice as likely to lose weight and keep it off as those who don't eat m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170587149106806784",
    "text" : "Those who eat moderately high levels of protein are twice as likely to lose weight and keep it off as those who don't eat much protein.",
    "id" : 170587149106806784,
    "created_at" : "2012-02-17 19:15:20 +0000",
    "user" : {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "protected" : false,
      "id_str" : "12524522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757500786188300288\/VKqAzYkD_normal.jpg",
      "id" : 12524522,
      "verified" : false
    }
  },
  "id" : 170592372919504896,
  "created_at" : "2012-02-17 19:36:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 102, 110 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/WG9PhEHn",
      "expanded_url" : "http:\/\/youtu.be\/UDlH9sV0lHU",
      "display_url" : "youtu.be\/UDlH9sV0lHU"
    } ]
  },
  "geo" : { },
  "id_str" : "170591161591939073",
  "text" : "Making a Killing: The Untold Story of Psychotropic Drugging - Full Movie...: http:\/\/t.co\/WG9PhEHn via @youtube",
  "id" : 170591161591939073,
  "created_at" : "2012-02-17 19:31:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170563275359125506",
  "geo" : { },
  "id_str" : "170566708988354560",
  "in_reply_to_user_id" : 17165443,
  "text" : "@kindlevixen absolutely, call him on it! you go, girl!",
  "id" : 170566708988354560,
  "in_reply_to_status_id" : 170563275359125506,
  "created_at" : "2012-02-17 17:54:07 +0000",
  "in_reply_to_screen_name" : "moxie_hart",
  "in_reply_to_user_id_str" : "17165443",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "indices" : [ 95, 103 ],
      "id_str" : "8192222",
      "id" : 8192222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/sik7kqsh",
      "expanded_url" : "http:\/\/jezebel.com\/5885747\/how-in-the-hell-are-we-supposed-to-grant-fertilized-eggs-constitutional-rights",
      "display_url" : "jezebel.com\/5885747\/how-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170552921224790016",
  "text" : "Roe V World: How in the Hell are We Supposed to Grant Fertilized Eggs Constitutional Rights? - @Jezebel http:\/\/t.co\/sik7kqsh",
  "id" : 170552921224790016,
  "created_at" : "2012-02-17 16:59:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170544635737948160",
  "text" : "RT @JohnCali: The reality that you are living is nothing more than an indication of your vibration. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170540524019785728",
    "text" : "The reality that you are living is nothing more than an indication of your vibration. ~ Abraham",
    "id" : 170540524019785728,
    "created_at" : "2012-02-17 16:10:04 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 170544635737948160,
  "created_at" : "2012-02-17 16:26:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/sikoqL6j",
      "expanded_url" : "http:\/\/thedancingdonkey.blogspot.com\/2012\/02\/conspiracy-continues.html",
      "display_url" : "thedancingdonkey.blogspot.com\/2012\/02\/conspi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170335229037379584",
  "text" : "The Dancing Donkey: The Conspiracy Continues http:\/\/t.co\/sikoqL6j",
  "id" : 170335229037379584,
  "created_at" : "2012-02-17 02:34:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheryl Lorraine",
      "screen_name" : "cherapple",
      "indices" : [ 3, 13 ],
      "id_str" : "18154412",
      "id" : 18154412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170286001208569856",
  "text" : "RT @cherapple: You know you're an introvert when.... RT @coachbethb: My latest blog post, starring some of your comments! http:\/\/t.co\/8G ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/8GBWF9QX",
        "expanded_url" : "http:\/\/bit.ly\/zSGhNl",
        "display_url" : "bit.ly\/zSGhNl"
      } ]
    },
    "geo" : { },
    "id_str" : "170279035627249664",
    "text" : "You know you're an introvert when.... RT @coachbethb: My latest blog post, starring some of your comments! http:\/\/t.co\/8GBWF9QX",
    "id" : 170279035627249664,
    "created_at" : "2012-02-16 22:51:00 +0000",
    "user" : {
      "name" : "Cheryl Lorraine",
      "screen_name" : "cherapple",
      "protected" : false,
      "id_str" : "18154412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696457861367463936\/OXLJGgzB_normal.jpg",
      "id" : 18154412,
      "verified" : false
    }
  },
  "id" : 170286001208569856,
  "created_at" : "2012-02-16 23:18:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "indices" : [ 3, 9 ],
      "id_str" : "14647570",
      "id" : 14647570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/qGxtlOfS",
      "expanded_url" : "http:\/\/bit.ly\/xxE5K3",
      "display_url" : "bit.ly\/xxE5K3"
    } ]
  },
  "geo" : { },
  "id_str" : "170253399407865857",
  "text" : "RT @sciam: DNA Robot Kills Cancer Cells http:\/\/t.co\/qGxtlOfS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/qGxtlOfS",
        "expanded_url" : "http:\/\/bit.ly\/xxE5K3",
        "display_url" : "bit.ly\/xxE5K3"
      } ]
    },
    "geo" : { },
    "id_str" : "170250718844960770",
    "text" : "DNA Robot Kills Cancer Cells http:\/\/t.co\/qGxtlOfS",
    "id" : 170250718844960770,
    "created_at" : "2012-02-16 20:58:29 +0000",
    "user" : {
      "name" : "Scientific American",
      "screen_name" : "sciam",
      "protected" : false,
      "id_str" : "14647570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676776763431620608\/1eNZzxq0_normal.png",
      "id" : 14647570,
      "verified" : true
    }
  },
  "id" : 170253399407865857,
  "created_at" : "2012-02-16 21:09:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170229162076946432",
  "text" : "Zurker need more ppl on it. Diaspora has ppl but harder to post. Both good.",
  "id" : 170229162076946432,
  "created_at" : "2012-02-16 19:32:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmedia",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 44 ],
      "url" : "https:\/\/t.co\/nZbiyPKq",
      "expanded_url" : "https:\/\/diasp.org\/u\/abfabgab",
      "display_url" : "diasp.org\/u\/abfabgab"
    }, {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/ylDpjRmh",
      "expanded_url" : "http:\/\/www.abfabgab.com\/zurker",
      "display_url" : "abfabgab.com\/zurker"
    } ]
  },
  "geo" : { },
  "id_str" : "170228666972901377",
  "text" : "2 other social forums: https:\/\/t.co\/nZbiyPKq http:\/\/t.co\/ylDpjRmh #socialmedia",
  "id" : 170228666972901377,
  "created_at" : "2012-02-16 19:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170213686261202944",
  "text" : "RT @Squirrely007: GOP how the hell are you preventing women from testifying in something affects their entire life??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170211819758166016",
    "text" : "GOP how the hell are you preventing women from testifying in something affects their entire life??",
    "id" : 170211819758166016,
    "created_at" : "2012-02-16 18:23:54 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 170213686261202944,
  "created_at" : "2012-02-16 18:31:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "contraception",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/aPaIBF3z",
      "expanded_url" : "http:\/\/youtu.be\/RCPU0Qsv9wM",
      "display_url" : "youtu.be\/RCPU0Qsv9wM"
    } ]
  },
  "geo" : { },
  "id_str" : "170206743211675648",
  "text" : "RT @SangyeH: The Testimony Chairman Issa Doesn't Want You to Hear http:\/\/t.co\/aPaIBF3z &lt;--Let's make this go viral #contraception #wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "contraception",
        "indices" : [ 105, 119 ]
      }, {
        "text" : "waronwomen",
        "indices" : [ 120, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/aPaIBF3z",
        "expanded_url" : "http:\/\/youtu.be\/RCPU0Qsv9wM",
        "display_url" : "youtu.be\/RCPU0Qsv9wM"
      } ]
    },
    "geo" : { },
    "id_str" : "170198101280296960",
    "text" : "The Testimony Chairman Issa Doesn't Want You to Hear http:\/\/t.co\/aPaIBF3z &lt;--Let's make this go viral #contraception #waronwomen",
    "id" : 170198101280296960,
    "created_at" : "2012-02-16 17:29:24 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 170206743211675648,
  "created_at" : "2012-02-16 18:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/5S5YQwbt",
      "expanded_url" : "http:\/\/mblogs.discovermagazine.com\/80beats\/2012\/02\/15\/miniature-chameleon-sits-on-the-head-of-a-match\/",
      "display_url" : "mblogs.discovermagazine.com\/80beats\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170206306370727937",
  "text" : "RT @mindymayhem: Miniature Chameleon Sits on the Head of a Match | Discover Magazine http:\/\/t.co\/5S5YQwbt One of 4 new species found!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/5S5YQwbt",
        "expanded_url" : "http:\/\/mblogs.discovermagazine.com\/80beats\/2012\/02\/15\/miniature-chameleon-sits-on-the-head-of-a-match\/",
        "display_url" : "mblogs.discovermagazine.com\/80beats\/2012\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170203871426265088",
    "text" : "Miniature Chameleon Sits on the Head of a Match | Discover Magazine http:\/\/t.co\/5S5YQwbt One of 4 new species found!",
    "id" : 170203871426265088,
    "created_at" : "2012-02-16 17:52:19 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 170206306370727937,
  "created_at" : "2012-02-16 18:02:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170195884926173185",
  "geo" : { },
  "id_str" : "170196349638295552",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms lovely. peaceful. : )",
  "id" : 170196349638295552,
  "in_reply_to_status_id" : 170195884926173185,
  "created_at" : "2012-02-16 17:22:26 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170195324739125248",
  "geo" : { },
  "id_str" : "170196031106064387",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms heehee.. you get me. its frustrating to understand things others do not.. yet it is perfect as is.",
  "id" : 170196031106064387,
  "in_reply_to_status_id" : 170195324739125248,
  "created_at" : "2012-02-16 17:21:10 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170195356594880512",
  "text" : "..learning a lot about what makes my MIL tick, too.. spending this time w her.",
  "id" : 170195356594880512,
  "created_at" : "2012-02-16 17:18:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170193889809022976",
  "geo" : { },
  "id_str" : "170194930822684672",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms : ) that came out like a whine.. but not meant to be. more of observation and seeing who I am",
  "id" : 170194930822684672,
  "in_reply_to_status_id" : 170193889809022976,
  "created_at" : "2012-02-16 17:16:48 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170194175931846659",
  "text" : "I learn a lot about myself from going to bible study w my MIL every week.",
  "id" : 170194175931846659,
  "created_at" : "2012-02-16 17:13:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170193517954605056",
  "text" : "RT @mindymayhem: How anyone who wants to threaten the health of others considers themself acting out of morality is beyond me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170192645103169537",
    "text" : "How anyone who wants to threaten the health of others considers themself acting out of morality is beyond me.",
    "id" : 170192645103169537,
    "created_at" : "2012-02-16 17:07:43 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 170193517954605056,
  "created_at" : "2012-02-16 17:11:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170192972896411648",
  "text" : "I am half christian, half pagan. just enough to not belong in either group. (like everything else..)",
  "id" : 170192972896411648,
  "created_at" : "2012-02-16 17:09:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170191962874445824",
  "text" : "RT @JohnCali: It is of no value, ever, to activate and talk about something that doesn\u2019t feel good. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170186874105761792",
    "text" : "It is of no value, ever, to activate and talk about something that doesn\u2019t feel good. ~ Abraham",
    "id" : 170186874105761792,
    "created_at" : "2012-02-16 16:44:47 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 170191962874445824,
  "created_at" : "2012-02-16 17:05:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170191864442519553",
  "text" : "RT @JohnCali: People believe that you\u2019ve got to focus upon the problem in order to find a solution...we say, no solution ever comes fort ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170187134895009792",
    "text" : "People believe that you\u2019ve got to focus upon the problem in order to find a solution...we say, no solution ever comes forth~Abraham",
    "id" : 170187134895009792,
    "created_at" : "2012-02-16 16:45:49 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 170191864442519553,
  "created_at" : "2012-02-16 17:04:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170191776416661506",
  "text" : "RT @Squirrely007: I'm just a soul whose intentions are good, oh lord please don't let me be misunderstood.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170187392999899136",
    "text" : "I'm just a soul whose intentions are good, oh lord please don't let me be misunderstood.",
    "id" : 170187392999899136,
    "created_at" : "2012-02-16 16:46:51 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 170191776416661506,
  "created_at" : "2012-02-16 17:04:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170177774915555329",
  "text" : "RT @bend_time: the only way to feel differently is to change our own minds. we are never powerless.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170165518530121729",
    "text" : "the only way to feel differently is to change our own minds. we are never powerless.",
    "id" : 170165518530121729,
    "created_at" : "2012-02-16 15:19:55 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 170177774915555329,
  "created_at" : "2012-02-16 16:08:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169894367677517824",
  "text" : "RT @UnseeingEyes: I need 4 VOTES to tie \"J K Rowling\" & 5 VOTES to MOVE PAST her. If you haven't VOTED, PLEASE VOTE Twitter's BEST Autho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/gG5V1JSG",
        "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
        "display_url" : "shortyawards.com\/UnseeingEyes"
      } ]
    },
    "geo" : { },
    "id_str" : "169884883005607936",
    "text" : "I need 4 VOTES to tie \"J K Rowling\" & 5 VOTES to MOVE PAST her. If you haven't VOTED, PLEASE VOTE Twitter's BEST Author http:\/\/t.co\/gG5V1JSG",
    "id" : 169884883005607936,
    "created_at" : "2012-02-15 20:44:47 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 169894367677517824,
  "created_at" : "2012-02-15 21:22:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Z7rVNPet",
      "expanded_url" : "http:\/\/twitpic.com\/8kckfv",
      "display_url" : "twitpic.com\/8kckfv"
    } ]
  },
  "geo" : { },
  "id_str" : "169842558816624642",
  "text" : "Your Aspie score: 119 of 200\nYour neurotypical (non-autistic) score: 87 of 200\nYou seem to have both Aspie and neu http:\/\/t.co\/Z7rVNPet",
  "id" : 169842558816624642,
  "created_at" : "2012-02-15 17:56:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169571099716231169",
  "geo" : { },
  "id_str" : "169573465374982145",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell ((waves)) Hello! im enjoying tasty cake! nomnomnom",
  "id" : 169573465374982145,
  "in_reply_to_status_id" : 169571099716231169,
  "created_at" : "2012-02-15 00:07:19 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169570423003037696",
  "text" : "DD made us a cake for V Day.. what a funny, sweet kid : )",
  "id" : 169570423003037696,
  "created_at" : "2012-02-14 23:55:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169553822933450753",
  "text" : "#kindlefire anyone know how the gallery works? or how to get pics in it?",
  "id" : 169553822933450753,
  "created_at" : "2012-02-14 22:49:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169545474997616640",
  "text" : "either that.. or he's waiting for something meaty to go with the kibble! lol",
  "id" : 169545474997616640,
  "created_at" : "2012-02-14 22:16:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169545134084595713",
  "text" : "beautiful brown stray kitty just chillin' on our porch.. that warms my heart!",
  "id" : 169545134084595713,
  "created_at" : "2012-02-14 22:14:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169543577532235777",
  "text" : "@SamsaricWarrior I often think I might not have made it this far w\/out DD. her presence has pushed me to grow.",
  "id" : 169543577532235777,
  "created_at" : "2012-02-14 22:08:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169540480466550786",
  "text" : "@SamsaricWarrior parenting is tough.. I still go over past decisions and think \"what if?\" sigh.",
  "id" : 169540480466550786,
  "created_at" : "2012-02-14 21:56:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169538807601967104",
  "text" : "DH got card & chocolate for DD.. he's so sweet!",
  "id" : 169538807601967104,
  "created_at" : "2012-02-14 21:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169537972927086592",
  "text" : "@SamsaricWarrior you can only guide him. he has his own path and must make that journey himself. ((hugs))",
  "id" : 169537972927086592,
  "created_at" : "2012-02-14 21:46:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    }, {
      "name" : "S.H. Photography",
      "screen_name" : "S_H_Photography",
      "indices" : [ 24, 40 ],
      "id_str" : "301075028",
      "id" : 301075028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/6IpR96qM",
      "expanded_url" : "http:\/\/bit.ly\/wSsVxF",
      "display_url" : "bit.ly\/wSsVxF"
    } ]
  },
  "geo" : { },
  "id_str" : "169502960131375104",
  "text" : "RT @screek: Great post! @S_H_Photography: Dinner With Squirrel. http:\/\/t.co\/6IpR96qM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "S.H. Photography",
        "screen_name" : "S_H_Photography",
        "indices" : [ 12, 28 ],
        "id_str" : "301075028",
        "id" : 301075028
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/6IpR96qM",
        "expanded_url" : "http:\/\/bit.ly\/wSsVxF",
        "display_url" : "bit.ly\/wSsVxF"
      } ]
    },
    "geo" : { },
    "id_str" : "169497688524603392",
    "text" : "Great post! @S_H_Photography: Dinner With Squirrel. http:\/\/t.co\/6IpR96qM",
    "id" : 169497688524603392,
    "created_at" : "2012-02-14 19:06:12 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 169502960131375104,
  "created_at" : "2012-02-14 19:27:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "Noncontroversial BpD",
      "screen_name" : "BenjaminPDixon",
      "indices" : [ 28, 43 ],
      "id_str" : "24903894",
      "id" : 24903894
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 44, 56 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169497449881280513",
  "text" : "RT @ReverendSue: Agreed! RT @BenjaminPDixon @ReverendSue America would not be America if we tried to make it a Christian nation. #separa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Noncontroversial BpD",
        "screen_name" : "BenjaminPDixon",
        "indices" : [ 11, 26 ],
        "id_str" : "24903894",
        "id" : 24903894
      }, {
        "name" : "Reverend Sue",
        "screen_name" : "ReverendSue",
        "indices" : [ 27, 39 ],
        "id_str" : "40585382",
        "id" : 40585382
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "separatechurchandstate",
        "indices" : [ 112, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169493625280020480",
    "text" : "Agreed! RT @BenjaminPDixon @ReverendSue America would not be America if we tried to make it a Christian nation. #separatechurchandstate",
    "id" : 169493625280020480,
    "created_at" : "2012-02-14 18:50:03 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 169497449881280513,
  "created_at" : "2012-02-14 19:05:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169488373273202688",
  "text" : "RT @ShipsofSong: There are many paths to enlightenment.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169487989058187264",
    "text" : "There are many paths to enlightenment.",
    "id" : 169487989058187264,
    "created_at" : "2012-02-14 18:27:40 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 169488373273202688,
  "created_at" : "2012-02-14 18:29:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169487208514985984",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous i know you've been down lately.. so a ((hug)) 4U on this day : )",
  "id" : 169487208514985984,
  "created_at" : "2012-02-14 18:24:34 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169482905062612992",
  "geo" : { },
  "id_str" : "169486523455111168",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings everything is perspective, isnt it? lol Glad you're still with us ((hugs))",
  "id" : 169486523455111168,
  "in_reply_to_status_id" : 169482905062612992,
  "created_at" : "2012-02-14 18:21:50 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169483094129254400",
  "geo" : { },
  "id_str" : "169486244177387520",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver ((((((hugs)))))) i know, i know...",
  "id" : 169486244177387520,
  "in_reply_to_status_id" : 169483094129254400,
  "created_at" : "2012-02-14 18:20:44 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Cat",
      "screen_name" : "HenryCatTwo",
      "indices" : [ 0, 12 ],
      "id_str" : "366576169",
      "id" : 366576169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169483090509565952",
  "geo" : { },
  "id_str" : "169485719176364032",
  "in_reply_to_user_id" : 366576169,
  "text" : "@HenryCatTwo dearest Henry, thank you so much for blessing me w your friendship. I love you!!! *\u2665* *\u2665* *\u2665*",
  "id" : 169485719176364032,
  "in_reply_to_status_id" : 169483090509565952,
  "created_at" : "2012-02-14 18:18:39 +0000",
  "in_reply_to_screen_name" : "HenryCatTwo",
  "in_reply_to_user_id_str" : "366576169",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coralie Saint-Louis",
      "screen_name" : "CoralieSL",
      "indices" : [ 3, 13 ],
      "id_str" : "28922763",
      "id" : 28922763
    }, {
      "name" : "Mash Entertainment",
      "screen_name" : "mashentertain",
      "indices" : [ 109, 123 ],
      "id_str" : "112240656",
      "id" : 112240656
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 124, 133 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/q98bcZvf",
      "expanded_url" : "http:\/\/mashable.com\/2012\/02\/12\/whitney-houston-twitter\/",
      "display_url" : "mashable.com\/2012\/02\/12\/whi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169219205802115073",
  "text" : "RT @CoralieSL: Twitter Breaks News of Whitney Houston Death 27 Minutes Before Press http:\/\/t.co\/q98bcZvf via @mashentertain @mashable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mash Entertainment",
        "screen_name" : "mashentertain",
        "indices" : [ 94, 108 ],
        "id_str" : "112240656",
        "id" : 112240656
      }, {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 109, 118 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/q98bcZvf",
        "expanded_url" : "http:\/\/mashable.com\/2012\/02\/12\/whitney-houston-twitter\/",
        "display_url" : "mashable.com\/2012\/02\/12\/whi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169217498372247552",
    "text" : "Twitter Breaks News of Whitney Houston Death 27 Minutes Before Press http:\/\/t.co\/q98bcZvf via @mashentertain @mashable",
    "id" : 169217498372247552,
    "created_at" : "2012-02-14 00:32:50 +0000",
    "user" : {
      "name" : "Coralie Saint-Louis",
      "screen_name" : "CoralieSL",
      "protected" : false,
      "id_str" : "28922763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748675416424996864\/mn3C0efz_normal.jpg",
      "id" : 28922763,
      "verified" : false
    }
  },
  "id" : 169219205802115073,
  "created_at" : "2012-02-14 00:39:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Marcus Sakey",
      "screen_name" : "MarcusSakey",
      "indices" : [ 20, 32 ],
      "id_str" : "47186719",
      "id" : 47186719
    }, {
      "name" : "Travel Channel",
      "screen_name" : "travelchannel",
      "indices" : [ 95, 109 ],
      "id_str" : "14363353",
      "id" : 14363353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HiddenCity",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169186353299468289",
  "text" : "RT @DuttonBooks: RT @MarcusSakey Who really killed Kurt Cobain? Tomorrow night on #HiddenCity, @travelchannel 9ET.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcus Sakey",
        "screen_name" : "MarcusSakey",
        "indices" : [ 3, 15 ],
        "id_str" : "47186719",
        "id" : 47186719
      }, {
        "name" : "Travel Channel",
        "screen_name" : "travelchannel",
        "indices" : [ 78, 92 ],
        "id_str" : "14363353",
        "id" : 14363353
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HiddenCity",
        "indices" : [ 65, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169181565375623168",
    "text" : "RT @MarcusSakey Who really killed Kurt Cobain? Tomorrow night on #HiddenCity, @travelchannel 9ET.",
    "id" : 169181565375623168,
    "created_at" : "2012-02-13 22:10:03 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 169186353299468289,
  "created_at" : "2012-02-13 22:29:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dream",
      "screen_name" : "dreamonus",
      "indices" : [ 3, 13 ],
      "id_str" : "330444567",
      "id" : 330444567
    }, {
      "name" : "Wendy Kinsey",
      "screen_name" : "AgnesGoochy627",
      "indices" : [ 88, 103 ],
      "id_str" : "293793713",
      "id" : 293793713
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 104, 115 ],
      "id_str" : "93747129",
      "id" : 93747129
    }, {
      "name" : "Sheila M. Chin",
      "screen_name" : "shemchin",
      "indices" : [ 116, 125 ],
      "id_str" : "23135724",
      "id" : 23135724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/Cmc6poPX",
      "expanded_url" : "http:\/\/post.ly\/5M0Da",
      "display_url" : "post.ly\/5M0Da"
    } ]
  },
  "geo" : { },
  "id_str" : "169173612752928768",
  "text" : "RT @dreamonus: Winners of Oath of Office by Michael Palmer http:\/\/t.co\/Cmc6poPX. Cgrts! @AgnesGoochy627 @moosebegab @shemchin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wendy Kinsey",
        "screen_name" : "AgnesGoochy627",
        "indices" : [ 73, 88 ],
        "id_str" : "293793713",
        "id" : 293793713
      }, {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 89, 100 ],
        "id_str" : "93747129",
        "id" : 93747129
      }, {
        "name" : "Sheila M. Chin",
        "screen_name" : "shemchin",
        "indices" : [ 101, 110 ],
        "id_str" : "23135724",
        "id" : 23135724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/Cmc6poPX",
        "expanded_url" : "http:\/\/post.ly\/5M0Da",
        "display_url" : "post.ly\/5M0Da"
      } ]
    },
    "geo" : { },
    "id_str" : "169168806810361856",
    "text" : "Winners of Oath of Office by Michael Palmer http:\/\/t.co\/Cmc6poPX. Cgrts! @AgnesGoochy627 @moosebegab @shemchin",
    "id" : 169168806810361856,
    "created_at" : "2012-02-13 21:19:21 +0000",
    "user" : {
      "name" : "iDreamBooks",
      "screen_name" : "idreambooks",
      "protected" : false,
      "id_str" : "291362177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000408113381\/2d164446b84c952a2cab0bda95e6c40e_normal.png",
      "id" : 291362177,
      "verified" : false
    }
  },
  "id" : 169173612752928768,
  "created_at" : "2012-02-13 21:38:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/gG5V1JSG",
      "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
      "display_url" : "shortyawards.com\/UnseeingEyes"
    } ]
  },
  "geo" : { },
  "id_str" : "169173348885069825",
  "text" : "RT @UnseeingEyes: Feb 13, 2012...With 4 Voting Days LEFT, -V- is 81 Votes out of 6th Place in the Shorty Awards http:\/\/t.co\/gG5V1JSG -Th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/gG5V1JSG",
        "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
        "display_url" : "shortyawards.com\/UnseeingEyes"
      } ]
    },
    "geo" : { },
    "id_str" : "169171133147525120",
    "text" : "Feb 13, 2012...With 4 Voting Days LEFT, -V- is 81 Votes out of 6th Place in the Shorty Awards http:\/\/t.co\/gG5V1JSG -The TOP 6 are Finalists",
    "id" : 169171133147525120,
    "created_at" : "2012-02-13 21:28:35 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 169173348885069825,
  "created_at" : "2012-02-13 21:37:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    }, {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 80, 95 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169163740049190912",
  "text" : "RT @adamrshields: If you have a large kindle library you should check this out \u201C@BooksOnTheKnob: Managing Your Kindle Library , Part I h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Books OnTheKnob",
        "screen_name" : "BooksOnTheKnob",
        "indices" : [ 62, 77 ],
        "id_str" : "29451040",
        "id" : 29451040
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/SrliPInb",
        "expanded_url" : "http:\/\/goo.gl\/fb\/mXmX9",
        "display_url" : "goo.gl\/fb\/mXmX9"
      } ]
    },
    "geo" : { },
    "id_str" : "169163173906235394",
    "text" : "If you have a large kindle library you should check this out \u201C@BooksOnTheKnob: Managing Your Kindle Library , Part I http:\/\/t.co\/SrliPInb\u201D",
    "id" : 169163173906235394,
    "created_at" : "2012-02-13 20:56:58 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 169163740049190912,
  "created_at" : "2012-02-13 20:59:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PowerfulLivingDesign",
      "screen_name" : "DesignIntuition",
      "indices" : [ 65, 81 ],
      "id_str" : "109693092",
      "id" : 109693092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169093146314153984",
  "text" : "RT @By_Bashar: What you are afraid to lose is already lost. \u00A0~ rt@DesignIntuition",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PowerfulLivingDesign",
        "screen_name" : "DesignIntuition",
        "indices" : [ 50, 66 ],
        "id_str" : "109693092",
        "id" : 109693092
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169092524659572736",
    "text" : "What you are afraid to lose is already lost. \u00A0~ rt@DesignIntuition",
    "id" : 169092524659572736,
    "created_at" : "2012-02-13 16:16:14 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 169093146314153984,
  "created_at" : "2012-02-13 16:18:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169086729763037184",
  "text" : "RT @screek: The moose whisperer: How an animal lover became friends with Jack the giant... just don't mention her boyfriend! http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/zIZAsToy",
        "expanded_url" : "http:\/\/bit.ly\/ziNdHk",
        "display_url" : "bit.ly\/ziNdHk"
      } ]
    },
    "geo" : { },
    "id_str" : "169080063319478272",
    "text" : "The moose whisperer: How an animal lover became friends with Jack the giant... just don't mention her boyfriend! http:\/\/t.co\/zIZAsToy",
    "id" : 169080063319478272,
    "created_at" : "2012-02-13 15:26:43 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 169086729763037184,
  "created_at" : "2012-02-13 15:53:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169083424500486145",
  "text" : "Freedom is not something you get from the Govt. Freedom is something you get from yourself.",
  "id" : 169083424500486145,
  "created_at" : "2012-02-13 15:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168881579706421248",
  "text" : "RT @By_Bashar: In order to change something, we have to take our focus OFF that reality & ON the reality we want.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168881132769787905",
    "text" : "In order to change something, we have to take our focus OFF that reality & ON the reality we want.",
    "id" : 168881132769787905,
    "created_at" : "2012-02-13 02:16:14 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 168881579706421248,
  "created_at" : "2012-02-13 02:18:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 3, 13 ],
      "id_str" : "82447359",
      "id" : 82447359
    }, {
      "name" : "Sedna Suicide \u2693",
      "screen_name" : "REALLYcristal",
      "indices" : [ 80, 94 ],
      "id_str" : "80711669",
      "id" : 80711669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168875123925975041",
  "text" : "RT @ScottBaio: Not sad tired from my toddler waking before 6am every morning RT @REALLYcristal Scott Baio is at my mall.Right now. I see ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sedna Suicide \u2693",
        "screen_name" : "REALLYcristal",
        "indices" : [ 65, 79 ],
        "id_str" : "80711669",
        "id" : 80711669
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168874218950361089",
    "text" : "Not sad tired from my toddler waking before 6am every morning RT @REALLYcristal Scott Baio is at my mall.Right now. I see him. He looks sad.",
    "id" : 168874218950361089,
    "created_at" : "2012-02-13 01:48:45 +0000",
    "user" : {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "protected" : false,
      "id_str" : "82447359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742477919801335816\/O6okGPN6_normal.jpg",
      "id" : 82447359,
      "verified" : true
    }
  },
  "id" : 168875123925975041,
  "created_at" : "2012-02-13 01:52:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168868355271434243",
  "text" : "RT @By_Bashar: We all affirm what we believe every day. Unfortunately, many have become masters at affirming negative ones.~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168866040758022145",
    "text" : "We all affirm what we believe every day. Unfortunately, many have become masters at affirming negative ones.~ bashar",
    "id" : 168866040758022145,
    "created_at" : "2012-02-13 01:16:16 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 168868355271434243,
  "created_at" : "2012-02-13 01:25:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168818639519223809",
  "geo" : { },
  "id_str" : "168819789022765057",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous yeah, I gotchya.. : ( exercise, distracting your thoughts, a good cry, change of scenery, doing something out of ordinary..",
  "id" : 168819789022765057,
  "in_reply_to_status_id" : 168818639519223809,
  "created_at" : "2012-02-12 22:12:28 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168817739614531584",
  "text" : "another advil sinus pill..",
  "id" : 168817739614531584,
  "created_at" : "2012-02-12 22:04:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168803955269312512",
  "geo" : { },
  "id_str" : "168817446264909824",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous you are not alone.. ive gone thru periods like that (as well as many other humans!)",
  "id" : 168817446264909824,
  "in_reply_to_status_id" : 168803955269312512,
  "created_at" : "2012-02-12 22:03:10 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "photo",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "photog",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/N05ZMybh",
      "expanded_url" : "http:\/\/www.martinbelan.com\/p912283134\/e31e1618f",
      "display_url" : "martinbelan.com\/p912283134\/e31\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168803347107823616",
  "text" : "RT @MartinBelan: Snow Bunting found some seeds http:\/\/t.co\/N05ZMybh #birds #photo #photog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "photo",
        "indices" : [ 58, 64 ]
      }, {
        "text" : "photog",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/N05ZMybh",
        "expanded_url" : "http:\/\/www.martinbelan.com\/p912283134\/e31e1618f",
        "display_url" : "martinbelan.com\/p912283134\/e31\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "168802387904053250",
    "text" : "Snow Bunting found some seeds http:\/\/t.co\/N05ZMybh #birds #photo #photog",
    "id" : 168802387904053250,
    "created_at" : "2012-02-12 21:03:20 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 168803347107823616,
  "created_at" : "2012-02-12 21:07:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 21, 35 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168799646855069696",
  "text" : "RT @CelticCamera: RT @JohnFugelsang: I have no problem with US drone bombs that kill civilians just don't ever let my tax $ pay for condoms.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Fugelsang",
        "screen_name" : "JohnFugelsang",
        "indices" : [ 3, 17 ],
        "id_str" : "33276161",
        "id" : 33276161
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168798477101441025",
    "text" : "RT @JohnFugelsang: I have no problem with US drone bombs that kill civilians just don't ever let my tax $ pay for condoms.",
    "id" : 168798477101441025,
    "created_at" : "2012-02-12 20:47:47 +0000",
    "user" : {
      "name" : "Gareth Glynn Ash",
      "screen_name" : "GarethGlynnAsh",
      "protected" : false,
      "id_str" : "21884322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714154956157227009\/p5XPCMj1_normal.jpg",
      "id" : 21884322,
      "verified" : false
    }
  },
  "id" : 168799646855069696,
  "created_at" : "2012-02-12 20:52:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168785769970937857",
  "geo" : { },
  "id_str" : "168787181979189248",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver (((hugs))) sweetie",
  "id" : 168787181979189248,
  "in_reply_to_status_id" : 168785769970937857,
  "created_at" : "2012-02-12 20:02:54 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "indices" : [ 3, 11 ],
      "id_str" : "14232408",
      "id" : 14232408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/NYIk9ItL",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/252060910364251980\/",
      "display_url" : "pinterest.com\/pin\/2520609103\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168778230134865920",
  "text" : "RT @offgrid: http:\/\/t.co\/NYIk9ItL  Albert Einstein said what ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/NYIk9ItL",
        "expanded_url" : "http:\/\/pinterest.com\/pin\/252060910364251980\/",
        "display_url" : "pinterest.com\/pin\/2520609103\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "168777214589018113",
    "text" : "http:\/\/t.co\/NYIk9ItL  Albert Einstein said what ?",
    "id" : 168777214589018113,
    "created_at" : "2012-02-12 19:23:18 +0000",
    "user" : {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "protected" : false,
      "id_str" : "14232408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658770933063151617\/yzshyxdA_normal.jpg",
      "id" : 14232408,
      "verified" : false
    }
  },
  "id" : 168778230134865920,
  "created_at" : "2012-02-12 19:27:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168776154386403328",
  "text" : "RT @bcmystery: Chocolate, oh chocolate, comest to me. Mantling a donut, draping almonds, I care not. I ask only that thou leap unto my b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168772375633084416",
    "text" : "Chocolate, oh chocolate, comest to me. Mantling a donut, draping almonds, I care not. I ask only that thou leap unto my bosom this day.",
    "id" : 168772375633084416,
    "created_at" : "2012-02-12 19:04:04 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 168776154386403328,
  "created_at" : "2012-02-12 19:19:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168774838901669888",
  "geo" : { },
  "id_str" : "168775832230301696",
  "in_reply_to_user_id" : 17165443,
  "text" : "@kindlevixen sounds like panic attack or a virus...",
  "id" : 168775832230301696,
  "in_reply_to_status_id" : 168774838901669888,
  "created_at" : "2012-02-12 19:17:48 +0000",
  "in_reply_to_screen_name" : "moxie_hart",
  "in_reply_to_user_id_str" : "17165443",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cute",
      "indices" : [ 37, 42 ]
    }, {
      "text" : "sloths",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/V5kUYxZW",
      "expanded_url" : "http:\/\/perfectlycute.com\/post\/162\/occupy-sloth-street.html",
      "display_url" : "perfectlycute.com\/post\/162\/occup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168769665865236480",
  "text" : "Perfectly Cute  http:\/\/t.co\/V5kUYxZW #cute #sloths",
  "id" : 168769665865236480,
  "created_at" : "2012-02-12 18:53:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168753492595458048",
  "text" : "@SamsaricWarrior i flunked my way thru school so im not good example..lol. she has social issues, noise bothers her...",
  "id" : 168753492595458048,
  "created_at" : "2012-02-12 17:49:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168748508147490816",
  "text" : "@SamsaricWarrior all good.. well, except trying to keep DD from flunking 10th grade.. but other than that.. lol",
  "id" : 168748508147490816,
  "created_at" : "2012-02-12 17:29:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168747182319599616",
  "text" : "@SamsaricWarrior I am good. Nice to see you recovering. : )",
  "id" : 168747182319599616,
  "created_at" : "2012-02-12 17:23:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168744235162546177",
  "geo" : { },
  "id_str" : "168745439867314176",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous I wish I could remember how @SamsaricWarrior puts it.. but its all temporary.. everything. ((hugs))",
  "id" : 168745439867314176,
  "in_reply_to_status_id" : 168744235162546177,
  "created_at" : "2012-02-12 17:17:02 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168743234955255808",
  "text" : "RT @UnseeingEyes: You envision what you want to happen in your mind's eye...& then you try your damn-est to replicate that. More often t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168742463547244544",
    "text" : "You envision what you want to happen in your mind's eye...& then you try your damn-est to replicate that. More often than not you will.",
    "id" : 168742463547244544,
    "created_at" : "2012-02-12 17:05:13 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 168743234955255808,
  "created_at" : "2012-02-12 17:08:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 2, 15 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168742112840531968",
  "geo" : { },
  "id_str" : "168743156542742528",
  "in_reply_to_user_id" : 36008885,
  "text" : ". @UnseeingEyes same msg from my TKD instructor.. specifically about my breaking boards.",
  "id" : 168743156542742528,
  "in_reply_to_status_id" : 168742112840531968,
  "created_at" : "2012-02-12 17:07:58 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168742930876604416",
  "text" : "RT @UnseeingEyes: When you are up at the plate, don't go up there \"trying not to miss\"...go up there with confidence knowing you will ge ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168742112840531968",
    "text" : "When you are up at the plate, don't go up there \"trying not to miss\"...go up there with confidence knowing you will get a hit.",
    "id" : 168742112840531968,
    "created_at" : "2012-02-12 17:03:49 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 168742930876604416,
  "created_at" : "2012-02-12 17:07:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168739106820587521",
  "text" : "RT @bend_time: for a long time most ppl were older than i. then for a while most were my age.now,suddenly,most ppl are younger. #ticktoc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ticktockworld",
        "indices" : [ 113, 127 ]
      }, {
        "text" : "perspective",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168738864041689088",
    "text" : "for a long time most ppl were older than i. then for a while most were my age.now,suddenly,most ppl are younger. #ticktockworld #perspective",
    "id" : 168738864041689088,
    "created_at" : "2012-02-12 16:50:54 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 168739106820587521,
  "created_at" : "2012-02-12 16:51:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168738785113288704",
  "text" : "RT @UnseeingEyes: It looks like the Shorty Awards did their Audit; so I really need the HELP & SUPPORT of my Friends to finish in the Top 6.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168738188578398208",
    "text" : "It looks like the Shorty Awards did their Audit; so I really need the HELP & SUPPORT of my Friends to finish in the Top 6.",
    "id" : 168738188578398208,
    "created_at" : "2012-02-12 16:48:13 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 168738785113288704,
  "created_at" : "2012-02-12 16:50:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "indices" : [ 0, 11 ],
      "id_str" : "15314194",
      "id" : 15314194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168736229666467841",
  "geo" : { },
  "id_str" : "168736584320028675",
  "in_reply_to_user_id" : 15314194,
  "text" : "@dee_carney LOL",
  "id" : 168736584320028675,
  "in_reply_to_status_id" : 168736229666467841,
  "created_at" : "2012-02-12 16:41:51 +0000",
  "in_reply_to_screen_name" : "dee_carney",
  "in_reply_to_user_id_str" : "15314194",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee Carney",
      "screen_name" : "dee_carney",
      "indices" : [ 0, 11 ],
      "id_str" : "15314194",
      "id" : 15314194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168735512444674048",
  "geo" : { },
  "id_str" : "168735930373521409",
  "in_reply_to_user_id" : 15314194,
  "text" : "@dee_carney @mdvbookreviewer see bottom of website.. its fake.",
  "id" : 168735930373521409,
  "in_reply_to_status_id" : 168735512444674048,
  "created_at" : "2012-02-12 16:39:15 +0000",
  "in_reply_to_screen_name" : "dee_carney",
  "in_reply_to_user_id_str" : "15314194",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "indices" : [ 3, 11 ],
      "id_str" : "14232408",
      "id" : 14232408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/cpkMY9WC",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/252060910364250813\/",
      "display_url" : "pinterest.com\/pin\/2520609103\u2026"
    }, {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/gmDV2hn1",
      "expanded_url" : "http:\/\/www.Offgrid-Living.com",
      "display_url" : "Offgrid-Living.com"
    } ]
  },
  "geo" : { },
  "id_str" : "168734756790484992",
  "text" : "RT @offgrid: http:\/\/t.co\/cpkMY9WC Steiner built log homes  http:\/\/t.co\/gmDV2hn1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/cpkMY9WC",
        "expanded_url" : "http:\/\/pinterest.com\/pin\/252060910364250813\/",
        "display_url" : "pinterest.com\/pin\/2520609103\u2026"
      }, {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/gmDV2hn1",
        "expanded_url" : "http:\/\/www.Offgrid-Living.com",
        "display_url" : "Offgrid-Living.com"
      } ]
    },
    "geo" : { },
    "id_str" : "168703496072339459",
    "text" : "http:\/\/t.co\/cpkMY9WC Steiner built log homes  http:\/\/t.co\/gmDV2hn1",
    "id" : 168703496072339459,
    "created_at" : "2012-02-12 14:30:22 +0000",
    "user" : {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "protected" : false,
      "id_str" : "14232408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658770933063151617\/yzshyxdA_normal.jpg",
      "id" : 14232408,
      "verified" : false
    }
  },
  "id" : 168734756790484992,
  "created_at" : "2012-02-12 16:34:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168730196168540162",
  "text" : "RT @UnseeingEyes: There is a lot of pain in this world, a lot of suffering, loss, & heartache. And the best resource we have to combat t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168729802197577729",
    "text" : "There is a lot of pain in this world, a lot of suffering, loss, & heartache. And the best resource we have to combat this is: Communication.",
    "id" : 168729802197577729,
    "created_at" : "2012-02-12 16:14:54 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 168730196168540162,
  "created_at" : "2012-02-12 16:16:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168514936245469186",
  "geo" : { },
  "id_str" : "168520407572430848",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous a particular book? I just finished Containment by Christian Cantrell on my kindle .. sci-fi drama.. loved it!",
  "id" : 168520407572430848,
  "in_reply_to_status_id" : 168514936245469186,
  "created_at" : "2012-02-12 02:22:50 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/0VUNK52j",
      "expanded_url" : "http:\/\/www.abfabgab.com\/my-dad\/",
      "display_url" : "abfabgab.com\/my-dad\/"
    } ]
  },
  "in_reply_to_status_id_str" : "168500331184001024",
  "geo" : { },
  "id_str" : "168519651872092160",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous thx.. 3yrs next month. spent his last day holding his hand. : ) http:\/\/t.co\/0VUNK52j",
  "id" : 168519651872092160,
  "in_reply_to_status_id" : 168500331184001024,
  "created_at" : "2012-02-12 02:19:50 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168508539118174208",
  "text" : "RT @parkstepp: \"We really must take into account the totality. This isn\u2019t just a human experience on this planet, this...\" http:\/\/t.co\/W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/WlQbPNCq",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyGGioQw",
        "display_url" : "tmblr.co\/ZwrrNyGGioQw"
      } ]
    },
    "geo" : { },
    "id_str" : "168508189573267458",
    "text" : "\"We really must take into account the totality. This isn\u2019t just a human experience on this planet, this...\" http:\/\/t.co\/WlQbPNCq",
    "id" : 168508189573267458,
    "created_at" : "2012-02-12 01:34:17 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 168508539118174208,
  "created_at" : "2012-02-12 01:35:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "indices" : [ 3, 18 ],
      "id_str" : "17621549",
      "id" : 17621549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168507420216266754",
  "text" : "RT @ReikiAwakening: Feet, what do I need them for? My soul has wings to fly. ~Frida Kahlo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168507246299463682",
    "text" : "Feet, what do I need them for? My soul has wings to fly. ~Frida Kahlo",
    "id" : 168507246299463682,
    "created_at" : "2012-02-12 01:30:32 +0000",
    "user" : {
      "name" : "Alice Langholt",
      "screen_name" : "ReikiAwakening",
      "protected" : false,
      "id_str" : "17621549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487076852842778625\/uKEYUGdu_normal.jpeg",
      "id" : 17621549,
      "verified" : false
    }
  },
  "id" : 168507420216266754,
  "created_at" : "2012-02-12 01:31:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 0, 14 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168504931345633280",
  "geo" : { },
  "id_str" : "168505520557264896",
  "in_reply_to_user_id" : 45254966,
  "text" : "@CharlesBivona its on tmz, yahoo, wikipedia, cnn...",
  "id" : 168505520557264896,
  "in_reply_to_status_id" : 168504931345633280,
  "created_at" : "2012-02-12 01:23:41 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/qvZvObo4",
      "expanded_url" : "http:\/\/www.tmz.com\/2012\/02\/11\/whitney-houston-dead\/",
      "display_url" : "tmz.com\/2012\/02\/11\/whi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168503625927241728",
  "text" : "http:\/\/t.co\/qvZvObo4",
  "id" : 168503625927241728,
  "created_at" : "2012-02-12 01:16:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168501825975234561",
  "geo" : { },
  "id_str" : "168502394634764288",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind I think this one is true.. its breaking news on front of yahoo. others are reporting it.",
  "id" : 168502394634764288,
  "in_reply_to_status_id" : 168501825975234561,
  "created_at" : "2012-02-12 01:11:16 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bells",
      "screen_name" : "bellie7",
      "indices" : [ 25, 33 ],
      "id_str" : "30717328",
      "id" : 30717328
    }, {
      "name" : "David Muir Fan",
      "screen_name" : "DavidMuirABC",
      "indices" : [ 37, 50 ],
      "id_str" : "531888061",
      "id" : 531888061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BREAKING",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168501670395908097",
  "text" : "RT @kindlevixen: Wtf :(  @bellie7 RT @DavidMuirABC: #BREAKING AP: Publicist Kristen Foster says singer Whitney Houston has died at age 48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bells",
        "screen_name" : "bellie7",
        "indices" : [ 8, 16 ],
        "id_str" : "30717328",
        "id" : 30717328
      }, {
        "name" : "David Muir Fan",
        "screen_name" : "DavidMuirABC",
        "indices" : [ 20, 33 ],
        "id_str" : "531888061",
        "id" : 531888061
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BREAKING",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168500871875919873",
    "text" : "Wtf :(  @bellie7 RT @DavidMuirABC: #BREAKING AP: Publicist Kristen Foster says singer Whitney Houston has died at age 48",
    "id" : 168500871875919873,
    "created_at" : "2012-02-12 01:05:13 +0000",
    "user" : {
      "name" : "Moxie Hart",
      "screen_name" : "moxie_hart",
      "protected" : false,
      "id_str" : "17165443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787765007673069568\/KoX_CNph_normal.jpg",
      "id" : 17165443,
      "verified" : false
    }
  },
  "id" : 168501670395908097,
  "created_at" : "2012-02-12 01:08:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168480384378609666",
  "geo" : { },
  "id_str" : "168498686316384256",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous after my Dad died, I got myself a BAB. His name is Ezra.",
  "id" : 168498686316384256,
  "in_reply_to_status_id" : 168480384378609666,
  "created_at" : "2012-02-12 00:56:32 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168468311112302592",
  "geo" : { },
  "id_str" : "168469655328014338",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous you need a trip to Build A Bear...",
  "id" : 168469655328014338,
  "in_reply_to_status_id" : 168468311112302592,
  "created_at" : "2012-02-11 23:01:10 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candywriter",
      "screen_name" : "candywriter",
      "indices" : [ 3, 15 ],
      "id_str" : "19004398",
      "id" : 19004398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/H4bOwelV",
      "expanded_url" : "http:\/\/tinyurl.com\/26h3qw3",
      "display_url" : "tinyurl.com\/26h3qw3"
    } ]
  },
  "geo" : { },
  "id_str" : "168394663470964736",
  "text" : "RT @candywriter: \u2600 \u2600 \u2600 Word Solitaire: Aurora is FREE this weekend only! http:\/\/t.co\/H4bOwelV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/H4bOwelV",
        "expanded_url" : "http:\/\/tinyurl.com\/26h3qw3",
        "display_url" : "tinyurl.com\/26h3qw3"
      } ]
    },
    "geo" : { },
    "id_str" : "168392142438400001",
    "text" : "\u2600 \u2600 \u2600 Word Solitaire: Aurora is FREE this weekend only! http:\/\/t.co\/H4bOwelV",
    "id" : 168392142438400001,
    "created_at" : "2012-02-11 17:53:09 +0000",
    "user" : {
      "name" : "Candywriter",
      "screen_name" : "candywriter",
      "protected" : false,
      "id_str" : "19004398",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731159934167961600\/5JoUaW1E_normal.jpg",
      "id" : 19004398,
      "verified" : true
    }
  },
  "id" : 168394663470964736,
  "created_at" : "2012-02-11 18:03:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168393354839732225",
  "geo" : { },
  "id_str" : "168394160179654656",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ((hugs)) dear.. ive got some weird virus going on making me feel weak off & on. just feeling off, tho, not miserable.",
  "id" : 168394160179654656,
  "in_reply_to_status_id" : 168393354839732225,
  "created_at" : "2012-02-11 18:01:11 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 15, 28 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/8lo1TM9C",
      "expanded_url" : "http:\/\/www.zurker.com\/update-1634-9",
      "display_url" : "zurker.com\/update-1634-9"
    } ]
  },
  "geo" : { },
  "id_str" : "168376485848170496",
  "text" : "thought of you @DwayneReaves http:\/\/t.co\/8lo1TM9C ..see comment about leasing photos",
  "id" : 168376485848170496,
  "created_at" : "2012-02-11 16:50:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/kCkCF1rt",
      "expanded_url" : "http:\/\/bit.ly\/zjn8qL",
      "display_url" : "bit.ly\/zjn8qL"
    } ]
  },
  "geo" : { },
  "id_str" : "168361723433205763",
  "text" : "RT @TheEntertainer: When one door closes, another one opens, but the hallways are a bitch! (New Blog) Please RT http:\/\/t.co\/kCkCF1rt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/kCkCF1rt",
        "expanded_url" : "http:\/\/bit.ly\/zjn8qL",
        "display_url" : "bit.ly\/zjn8qL"
      } ]
    },
    "geo" : { },
    "id_str" : "168354999884185601",
    "text" : "When one door closes, another one opens, but the hallways are a bitch! (New Blog) Please RT http:\/\/t.co\/kCkCF1rt",
    "id" : 168354999884185601,
    "created_at" : "2012-02-11 15:25:34 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 168361723433205763,
  "created_at" : "2012-02-11 15:52:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168360091098165249",
  "text" : "RT @TheEntertainer: This is BIG ASS Truth. We get SO lost and caught up in our stories, that we forget it's just a freakin' story.... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/vDvtP2Y0",
        "expanded_url" : "http:\/\/fb.me\/11PX4iIZc",
        "display_url" : "fb.me\/11PX4iIZc"
      } ]
    },
    "geo" : { },
    "id_str" : "168357047782477825",
    "text" : "This is BIG ASS Truth. We get SO lost and caught up in our stories, that we forget it's just a freakin' story.... http:\/\/t.co\/vDvtP2Y0",
    "id" : 168357047782477825,
    "created_at" : "2012-02-11 15:33:42 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 168360091098165249,
  "created_at" : "2012-02-11 15:45:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Kramer",
      "screen_name" : "bryankramer",
      "indices" : [ 3, 15 ],
      "id_str" : "16493868",
      "id" : 16493868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168025455046299648",
  "text" : "RT @bryankramer: \"I had to walk to school 40 miles in snow\" was good in the day. But imagine your kid when you say \"When I was born ther ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.2775318707, -121.876764251 ]
    },
    "id_str" : "167813809900240896",
    "text" : "\"I had to walk to school 40 miles in snow\" was good in the day. But imagine your kid when you say \"When I was born there was no internet\".",
    "id" : 167813809900240896,
    "created_at" : "2012-02-10 03:35:04 +0000",
    "user" : {
      "name" : "Bryan Kramer",
      "screen_name" : "bryankramer",
      "protected" : false,
      "id_str" : "16493868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722653421350821888\/9kBuLVET_normal.jpg",
      "id" : 16493868,
      "verified" : true
    }
  },
  "id" : 168025455046299648,
  "created_at" : "2012-02-10 17:36:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy",
      "screen_name" : "jimmy722",
      "indices" : [ 3, 12 ],
      "id_str" : "44360973",
      "id" : 44360973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168024879365492738",
  "text" : "RT @jimmy722: The Big Bang Theory continued its monster ratings with 16.06 million viewers & a 5.5 demo once again beating American Idol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bigbangtheory",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168014423246635011",
    "text" : "The Big Bang Theory continued its monster ratings with 16.06 million viewers & a 5.5 demo once again beating American Idol.  #Bigbangtheory",
    "id" : 168014423246635011,
    "created_at" : "2012-02-10 16:52:14 +0000",
    "user" : {
      "name" : "Jimmy",
      "screen_name" : "jimmy722",
      "protected" : false,
      "id_str" : "44360973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/272912670\/Big_Bang_Theory-DVD_Cover_normal.jpg",
      "id" : 44360973,
      "verified" : false
    }
  },
  "id" : 168024879365492738,
  "created_at" : "2012-02-10 17:33:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/baVqQ6ub",
      "expanded_url" : "http:\/\/www.zurker.com\/abfabgab",
      "display_url" : "zurker.com\/abfabgab"
    } ]
  },
  "geo" : { },
  "id_str" : "168019695088308225",
  "text" : "I updated my Z profile... http:\/\/t.co\/baVqQ6ub",
  "id" : 168019695088308225,
  "created_at" : "2012-02-10 17:13:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167794053197467648",
  "text" : "i dont like new twitter... ((whine))",
  "id" : 167794053197467648,
  "created_at" : "2012-02-10 02:16:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167755650670149634",
  "text" : "aaaaccckkk!!! what happened to my twitter? o-O",
  "id" : 167755650670149634,
  "created_at" : "2012-02-09 23:43:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Badash",
      "screen_name" : "davidbadash",
      "indices" : [ 0, 12 ],
      "id_str" : "7619982",
      "id" : 7619982
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 13, 25 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167681452820017153",
  "geo" : { },
  "id_str" : "167683385458831361",
  "in_reply_to_user_id" : 7619982,
  "text" : "@davidbadash @ReverendSue that is how I view them.. seeing the world through fear.",
  "id" : 167683385458831361,
  "in_reply_to_status_id" : 167681452820017153,
  "created_at" : "2012-02-09 18:56:49 +0000",
  "in_reply_to_screen_name" : "davidbadash",
  "in_reply_to_user_id_str" : "7619982",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167677268947255296",
  "geo" : { },
  "id_str" : "167680455947206657",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh dear.. ive never had them but I know they can be fierce. ((hugs))",
  "id" : 167680455947206657,
  "in_reply_to_status_id" : 167677268947255296,
  "created_at" : "2012-02-09 18:45:10 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialmedia",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/4dkWiw7v",
      "expanded_url" : "http:\/\/www.zurker.com\/update-2713-1",
      "display_url" : "zurker.com\/update-2713-1"
    }, {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/UrajmvJc",
      "expanded_url" : "http:\/\/www.zurker.com\/i-2713-hhddsmamay",
      "display_url" : "zurker.com\/i-2713-hhddsma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167647269263384576",
  "text" : "my zurker review: http:\/\/t.co\/4dkWiw7v invite: http:\/\/t.co\/UrajmvJc #socialmedia",
  "id" : 167647269263384576,
  "created_at" : "2012-02-09 16:33:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167622712859181056",
  "text" : "i never liked dodgeball. i dont like being jostled.",
  "id" : 167622712859181056,
  "created_at" : "2012-02-09 14:55:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aine Belton",
      "screen_name" : "AineBelton",
      "indices" : [ 3, 14 ],
      "id_str" : "24859536",
      "id" : 24859536
    }, {
      "name" : "Sean Gardner",
      "screen_name" : "2morrowknight",
      "indices" : [ 71, 85 ],
      "id_str" : "19478383",
      "id" : 19478383
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167615187019497472",
  "text" : "RT @AineBelton: You don't shine by putting out somebody else's light. ~@2morrowknight #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Gardner",
        "screen_name" : "2morrowknight",
        "indices" : [ 55, 69 ],
        "id_str" : "19478383",
        "id" : 19478383
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 70, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167613818015453185",
    "text" : "You don't shine by putting out somebody else's light. ~@2morrowknight #quote",
    "id" : 167613818015453185,
    "created_at" : "2012-02-09 14:20:22 +0000",
    "user" : {
      "name" : "Aine Belton",
      "screen_name" : "AineBelton",
      "protected" : false,
      "id_str" : "24859536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522994441531822080\/gWfpKN0w_normal.jpeg",
      "id" : 24859536,
      "verified" : false
    }
  },
  "id" : 167615187019497472,
  "created_at" : "2012-02-09 14:25:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/11IzyjC0",
      "expanded_url" : "http:\/\/grnd.tv\/6\/32681",
      "display_url" : "grnd.tv\/6\/32681"
    } ]
  },
  "geo" : { },
  "id_str" : "167410672349618178",
  "text" : "RT @Silvercrone: Diver frees entangled orca that had been crying for help http:\/\/t.co\/11IzyjC0 \/\/ What an awesome story! so wonderful!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/11IzyjC0",
        "expanded_url" : "http:\/\/grnd.tv\/6\/32681",
        "display_url" : "grnd.tv\/6\/32681"
      } ]
    },
    "geo" : { },
    "id_str" : "167408336235544576",
    "text" : "Diver frees entangled orca that had been crying for help http:\/\/t.co\/11IzyjC0 \/\/ What an awesome story! so wonderful!",
    "id" : 167408336235544576,
    "created_at" : "2012-02-09 00:43:52 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 167410672349618178,
  "created_at" : "2012-02-09 00:53:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167405889396019200",
  "geo" : { },
  "id_str" : "167406698972188672",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time russ got a flashlight so we could see.. saw fat 1 waddling in yard then saw 2nd one's eyes..lol",
  "id" : 167406698972188672,
  "in_reply_to_status_id" : 167405889396019200,
  "created_at" : "2012-02-09 00:37:21 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167405325752872960",
  "text" : "2 raccoons at the diner tonight : )",
  "id" : 167405325752872960,
  "created_at" : "2012-02-09 00:31:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Maya",
      "screen_name" : "taramayastales",
      "indices" : [ 3, 18 ],
      "id_str" : "23036403",
      "id" : 23036403
    }, {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 126, 134 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167384806018121729",
  "text" : "RT @taramayastales: straight out of a sci-fi story...  \"The Miraculous NASA Breakthrough That Could Save Millions of Lives\" - @gizmodo h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gizmodo",
        "screen_name" : "Gizmodo",
        "indices" : [ 106, 114 ],
        "id_str" : "2890961",
        "id" : 2890961
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/8y4Di4ro",
        "expanded_url" : "http:\/\/gizmodo.com\/5882725\/the-miraculous-nasa-breakthrough-that-could-save-millions-of-lives",
        "display_url" : "gizmodo.com\/5882725\/the-mi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "167339410856214528",
    "text" : "straight out of a sci-fi story...  \"The Miraculous NASA Breakthrough That Could Save Millions of Lives\" - @gizmodo http:\/\/t.co\/8y4Di4ro",
    "id" : 167339410856214528,
    "created_at" : "2012-02-08 20:09:59 +0000",
    "user" : {
      "name" : "Tara Maya",
      "screen_name" : "taramayastales",
      "protected" : false,
      "id_str" : "23036403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1309195863\/Unfinished_Song-Fae-Flat_Front-Med_normal.jpg",
      "id" : 23036403,
      "verified" : false
    }
  },
  "id" : 167384806018121729,
  "created_at" : "2012-02-08 23:10:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/UrajmvJc",
      "expanded_url" : "http:\/\/www.zurker.com\/i-2713-hhddsmamay",
      "display_url" : "zurker.com\/i-2713-hhddsma\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167342099107299328",
  "text" : "im trying out a new social media similar to FB but owned by users http:\/\/t.co\/UrajmvJc",
  "id" : 167342099107299328,
  "created_at" : "2012-02-08 20:20:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167275655430541313",
  "text" : "there's an alien in my blood...",
  "id" : 167275655430541313,
  "created_at" : "2012-02-08 15:56:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167067697815891968",
  "text" : "RT @TracyLatz: Sometimes we need to accept what is and go with the flow.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167067434296156160",
    "text" : "Sometimes we need to accept what is and go with the flow.",
    "id" : 167067434296156160,
    "created_at" : "2012-02-08 02:09:14 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 167067697815891968,
  "created_at" : "2012-02-08 02:10:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167062626684239873",
  "text" : "RT @ShipsofSong: Be most forgiving to yourselves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167060740501540864",
    "text" : "Be most forgiving to yourselves.",
    "id" : 167060740501540864,
    "created_at" : "2012-02-08 01:42:39 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 167062626684239873,
  "created_at" : "2012-02-08 01:50:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/WOvhXoCB",
      "expanded_url" : "http:\/\/lat.ms\/wHvYrV",
      "display_url" : "lat.ms\/wHvYrV"
    } ]
  },
  "geo" : { },
  "id_str" : "167061821453369346",
  "text" : "RT @screek: Alaska snow woes hit weary, starving moose http:\/\/t.co\/WOvhXoCB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/WOvhXoCB",
        "expanded_url" : "http:\/\/lat.ms\/wHvYrV",
        "display_url" : "lat.ms\/wHvYrV"
      } ]
    },
    "geo" : { },
    "id_str" : "167060704036274176",
    "text" : "Alaska snow woes hit weary, starving moose http:\/\/t.co\/WOvhXoCB",
    "id" : 167060704036274176,
    "created_at" : "2012-02-08 01:42:30 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 167061821453369346,
  "created_at" : "2012-02-08 01:46:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "senryu",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167060467125207040",
  "text" : "RT @CoyoteSings: old man \u2022 with an eight track player \u2022 and a one track mind.. | #senryu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "senryu",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167059102722310144",
    "text" : "old man \u2022 with an eight track player \u2022 and a one track mind.. | #senryu",
    "id" : 167059102722310144,
    "created_at" : "2012-02-08 01:36:08 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 167060467125207040,
  "created_at" : "2012-02-08 01:41:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "senryu",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167059285375848450",
  "text" : "RT @CoyoteSings: pigeons \u2022 teach me \u2022 the grace of clumsiness | #senryu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "senryu",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167058532993220610",
    "text" : "pigeons \u2022 teach me \u2022 the grace of clumsiness | #senryu",
    "id" : 167058532993220610,
    "created_at" : "2012-02-08 01:33:52 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 167059285375848450,
  "created_at" : "2012-02-08 01:36:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 19, 27 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167059065682407424",
  "text" : "Would someone give @SangyeH a cookie already?? LOL (oh, me too, plz?)",
  "id" : 167059065682407424,
  "created_at" : "2012-02-08 01:35:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167034622956417024",
  "text" : "RT @UnseeingEyes: Sometimes in order to make the right move; you don't make any moves... you let the situation unfold naturally while re ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167033181269266434",
    "text" : "Sometimes in order to make the right move; you don't make any moves... you let the situation unfold naturally while reacting accordingly.",
    "id" : 167033181269266434,
    "created_at" : "2012-02-07 23:53:08 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 167034622956417024,
  "created_at" : "2012-02-07 23:58:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    }, {
      "name" : "(((Ken. Just Ken.)))",
      "screen_name" : "pathseekerken",
      "indices" : [ 20, 34 ],
      "id_str" : "17051492",
      "id" : 17051492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167032739655196672",
  "text" : "RT @screek: Wow! RT @pathseekerken: .@etoile Purple Squirrel Found In Pennsylvania. http:\/\/t.co\/cuM4Pr3H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(((Ken. Just Ken.)))",
        "screen_name" : "pathseekerken",
        "indices" : [ 8, 22 ],
        "id_str" : "17051492",
        "id" : 17051492
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/cuM4Pr3H",
        "expanded_url" : "http:\/\/bit.ly\/AxwZUI",
        "display_url" : "bit.ly\/AxwZUI"
      } ]
    },
    "geo" : { },
    "id_str" : "167032009963749377",
    "text" : "Wow! RT @pathseekerken: .@etoile Purple Squirrel Found In Pennsylvania. http:\/\/t.co\/cuM4Pr3H",
    "id" : 167032009963749377,
    "created_at" : "2012-02-07 23:48:29 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 167032739655196672,
  "created_at" : "2012-02-07 23:51:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167032402135359489",
  "text" : "RT @LSFProgram: The journey of a thousand miles begins with a single step - Lao Tsu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167031559654883328",
    "text" : "The journey of a thousand miles begins with a single step - Lao Tsu",
    "id" : 167031559654883328,
    "created_at" : "2012-02-07 23:46:41 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 167032402135359489,
  "created_at" : "2012-02-07 23:50:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167031940891942912",
  "text" : "RT @Seeds4Parents: Speak your truth, no matter what needs to be said.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167031734444097536",
    "text" : "Speak your truth, no matter what needs to be said.",
    "id" : 167031734444097536,
    "created_at" : "2012-02-07 23:47:23 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 167031940891942912,
  "created_at" : "2012-02-07 23:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167031676659179520",
  "text" : "RT @UnseeingEyes: Our lives...every day...is a sort of story. & people like to know they are not alone; & enjoy when they identify with  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167030899987316736",
    "text" : "Our lives...every day...is a sort of story. & people like to know they are not alone; & enjoy when they identify with a feeling or emotion.",
    "id" : 167030899987316736,
    "created_at" : "2012-02-07 23:44:04 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 167031676659179520,
  "created_at" : "2012-02-07 23:47:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167027246597550080",
  "geo" : { },
  "id_str" : "167028557539844096",
  "in_reply_to_user_id" : 233971651,
  "text" : "@Selaniest my mom had finger stick to test blood sugar but I cant find it.. wondering if I can get one over the counter?",
  "id" : 167028557539844096,
  "in_reply_to_status_id" : 167027246597550080,
  "created_at" : "2012-02-07 23:34:46 +0000",
  "in_reply_to_screen_name" : "UnwashedThe",
  "in_reply_to_user_id_str" : "233971651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167026801334427648",
  "text" : "altho, dont think its diabetes.. comes out of blue.. weird weakness.",
  "id" : 167026801334427648,
  "created_at" : "2012-02-07 23:27:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167025749109391360",
  "text" : "can one test oneself for diabetes? like a finger prick thing or something OTC?",
  "id" : 167025749109391360,
  "created_at" : "2012-02-07 23:23:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janette",
      "screen_name" : "BeamMeUpPlz",
      "indices" : [ 0, 12 ],
      "id_str" : "22484703",
      "id" : 22484703
    }, {
      "name" : "jophsie",
      "screen_name" : "jophsie",
      "indices" : [ 28, 36 ],
      "id_str" : "356512360",
      "id" : 356512360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167021964286898179",
  "geo" : { },
  "id_str" : "167024602852233216",
  "in_reply_to_user_id" : 22484703,
  "text" : "@BeamMeUpPlz @WarriorBanker @jophsie TBH, sometimes ppl dont know what to say...",
  "id" : 167024602852233216,
  "in_reply_to_status_id" : 167021964286898179,
  "created_at" : "2012-02-07 23:19:03 +0000",
  "in_reply_to_screen_name" : "BeamMeUpPlz",
  "in_reply_to_user_id_str" : "22484703",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "indices" : [ 0, 11 ],
      "id_str" : "76225852",
      "id" : 76225852
    }, {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 12, 27 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167015194357280768",
  "geo" : { },
  "id_str" : "167023579655966721",
  "in_reply_to_user_id" : 76225852,
  "text" : "@TraLeeFitz @JonathanElliot ROFL.. his wackiness The Newt.. oh my.. thx 4 that : ) (btw: ive posted\/reshared past few days so...)",
  "id" : 167023579655966721,
  "in_reply_to_status_id" : 167015194357280768,
  "created_at" : "2012-02-07 23:14:59 +0000",
  "in_reply_to_screen_name" : "TraLeeFitz",
  "in_reply_to_user_id_str" : "76225852",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 2, 10 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167011393978109952",
  "geo" : { },
  "id_str" : "167012076789829632",
  "in_reply_to_user_id" : 59574144,
  "text" : ". @MWM4444 ..and we need to love those who hate, judge, condemn.. ((gulp))",
  "id" : 167012076789829632,
  "in_reply_to_status_id" : 167011393978109952,
  "created_at" : "2012-02-07 22:29:16 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167010685358841857",
  "text" : "more glimpses of knowing...",
  "id" : 167010685358841857,
  "created_at" : "2012-02-07 22:23:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Allan Lokos",
      "screen_name" : "AllanLokos",
      "indices" : [ 16, 27 ],
      "id_str" : "63180278",
      "id" : 63180278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167009859496185857",
  "text" : "RT @SangyeH: RT @AllanLokos: Peace can be found within no matter what the external circumstances.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allan Lokos",
        "screen_name" : "AllanLokos",
        "indices" : [ 3, 14 ],
        "id_str" : "63180278",
        "id" : 63180278
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167008152401870848",
    "text" : "RT @AllanLokos: Peace can be found within no matter what the external circumstances.",
    "id" : 167008152401870848,
    "created_at" : "2012-02-07 22:13:41 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 167009859496185857,
  "created_at" : "2012-02-07 22:20:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167009738243047425",
  "text" : "RT @By_Bashar: Simply be who you are, \u00A0do what you do best, be where you are called by joy, and let life work its magic on your behalf.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167008884693798913",
    "text" : "Simply be who you are, \u00A0do what you do best, be where you are called by joy, and let life work its magic on your behalf. ~ A Cohen",
    "id" : 167008884693798913,
    "created_at" : "2012-02-07 22:16:35 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 167009738243047425,
  "created_at" : "2012-02-07 22:19:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167005908122083328",
  "text" : "I think Im on the verge of understanding something..",
  "id" : 167005908122083328,
  "created_at" : "2012-02-07 22:04:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166985435497762816",
  "text" : "RT @TheGodLight: A child of God was never born without a purpose, your task is to rise above life, so that your divinity can shine through.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166984768762810370",
    "text" : "A child of God was never born without a purpose, your task is to rise above life, so that your divinity can shine through.",
    "id" : 166984768762810370,
    "created_at" : "2012-02-07 20:40:45 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 166985435497762816,
  "created_at" : "2012-02-07 20:43:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 55, 63 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/NmNn2UOL",
      "expanded_url" : "http:\/\/www.soulseeds.com\/grapevine\/2012\/02\/convictions-and-conversation\/#.TzGKh6qYsow.twitter",
      "display_url" : "soulseeds.com\/grapevine\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166984801654538241",
  "text" : "Convictions and Conversation  http:\/\/t.co\/NmNn2UOL via @AddThis",
  "id" : 166984801654538241,
  "created_at" : "2012-02-07 20:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "indices" : [ 0, 11 ],
      "id_str" : "76225852",
      "id" : 76225852
    }, {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 12, 27 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "diaspora",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166974718111531009",
  "geo" : { },
  "id_str" : "166980203279691776",
  "in_reply_to_user_id" : 76225852,
  "text" : "@TraLeeFitz @JonathanElliot I've got stuff in my stream... #diaspora",
  "id" : 166980203279691776,
  "in_reply_to_status_id" : 166974718111531009,
  "created_at" : "2012-02-07 20:22:37 +0000",
  "in_reply_to_screen_name" : "TraLeeFitz",
  "in_reply_to_user_id_str" : "76225852",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166964141519675392",
  "text" : "RT @By_Bashar: Everything has a reason for being part an event~down to the Tiniest, most infinitesimal detail. Nothing is an accident No ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166963567508197376",
    "text" : "Everything has a reason for being part an event~down to the Tiniest, most infinitesimal detail. Nothing is an accident No exceptions ~bashar",
    "id" : 166963567508197376,
    "created_at" : "2012-02-07 19:16:31 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 166964141519675392,
  "created_at" : "2012-02-07 19:18:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "Newt Gingrich",
      "screen_name" : "newtgingrich",
      "indices" : [ 47, 60 ],
      "id_str" : "20713061",
      "id" : 20713061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equality",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "Prop8",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166960891223482369",
  "text" : "RT @ReverendSue: No, it's called #equality!!! \"@newtgingrich: Court of Appeals overturning CA's #Prop8 another example of an out of cont ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Newt Gingrich",
        "screen_name" : "newtgingrich",
        "indices" : [ 30, 43 ],
        "id_str" : "20713061",
        "id" : 20713061
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "equality",
        "indices" : [ 16, 25 ]
      }, {
        "text" : "Prop8",
        "indices" : [ 79, 85 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166959656617512961",
    "text" : "No, it's called #equality!!! \"@newtgingrich: Court of Appeals overturning CA's #Prop8 another example of an out of control judiciary.\" #LGBT",
    "id" : 166959656617512961,
    "created_at" : "2012-02-07 19:00:58 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 166960891223482369,
  "created_at" : "2012-02-07 19:05:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/idreambooks.com\/books\" rel=\"nofollow\"\u003EiDreamBooks\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dream",
      "screen_name" : "dreamonus",
      "indices" : [ 106, 116 ],
      "id_str" : "330444567",
      "id" : 330444567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/deToJoKF",
      "expanded_url" : "http:\/\/idre.am\/AflxSI",
      "display_url" : "idre.am\/AflxSI"
    } ]
  },
  "geo" : { },
  "id_str" : "166960435856289792",
  "text" : "Genetically modified food gone wrong- win a new agro-thriller from NYT Bestselling author Michael Palmer. @dreamonus. http:\/\/t.co\/deToJoKF",
  "id" : 166960435856289792,
  "created_at" : "2012-02-07 19:04:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "ClassyChicChris",
      "indices" : [ 3, 19 ],
      "id_str" : "39891347",
      "id" : 39891347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166957379227877376",
  "text" : "RT @ClassyChicChris: so why is a pill bottle harder to open when you really really need to get in it????",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166957066508959744",
    "text" : "so why is a pill bottle harder to open when you really really need to get in it????",
    "id" : 166957066508959744,
    "created_at" : "2012-02-07 18:50:41 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "ClassyChicChris",
      "protected" : false,
      "id_str" : "39891347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503365467910586368\/Oc4PnotX_normal.jpeg",
      "id" : 39891347,
      "verified" : false
    }
  },
  "id" : 166957379227877376,
  "created_at" : "2012-02-07 18:51:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166957277478256641",
  "text" : "ive never had to take care of myself. always had hubby. DD similar to me. not any marketable skills.",
  "id" : 166957277478256641,
  "created_at" : "2012-02-07 18:51:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prop8",
      "indices" : [ 15, 21 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166956662916251648",
  "text" : "RT @Selaniest: #prop8  Just leave folks alone! Much love #LGBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "prop8",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 42, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166956438265147393",
    "text" : "#prop8  Just leave folks alone! Much love #LGBT",
    "id" : 166956438265147393,
    "created_at" : "2012-02-07 18:48:11 +0000",
    "user" : {
      "name" : "The Great Unwashed",
      "screen_name" : "UnwashedThe",
      "protected" : false,
      "id_str" : "233971651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672923186632216576\/tRMQmyrX_normal.jpg",
      "id" : 233971651,
      "verified" : false
    }
  },
  "id" : 166956662916251648,
  "created_at" : "2012-02-07 18:49:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166956518988722177",
  "text" : "so I took a pill for my sinus headache.. but dont know how to fix DD..",
  "id" : 166956518988722177,
  "created_at" : "2012-02-07 18:48:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166955837343014912",
  "text" : "RT @CrystalLewis: AND-- the applesauce will make your baked goods a bit more moist than oil. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166955180804423680",
    "text" : "AND-- the applesauce will make your baked goods a bit more moist than oil. :)",
    "id" : 166955180804423680,
    "created_at" : "2012-02-07 18:43:11 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 166955837343014912,
  "created_at" : "2012-02-07 18:45:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166955755361153024",
  "text" : "RT @CrystalLewis: Another tip... Lower the calories of any baking mix by using unsweetened applesauce instead of oil. Again, you won't n ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166954953892569088",
    "text" : "Another tip... Lower the calories of any baking mix by using unsweetened applesauce instead of oil. Again, you won't notice the difference!",
    "id" : 166954953892569088,
    "created_at" : "2012-02-07 18:42:17 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 166955755361153024,
  "created_at" : "2012-02-07 18:45:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166953462716825600",
  "geo" : { },
  "id_str" : "166955104266764289",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver purrrzzzz back at ya, dear Henry! youz sooo handsum!",
  "id" : 166955104266764289,
  "in_reply_to_status_id" : 166953462716825600,
  "created_at" : "2012-02-07 18:42:53 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166951113331982336",
  "text" : "bad sinus day and DD is flunking 10th grade.",
  "id" : 166951113331982336,
  "created_at" : "2012-02-07 18:27:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 73, 89 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/M9fqWdSp",
      "expanded_url" : "http:\/\/wp.me\/p1ML21-e5",
      "display_url" : "wp.me\/p1ML21-e5"
    } ]
  },
  "geo" : { },
  "id_str" : "166503692059680768",
  "text" : "Kingdoms, Afterlives and Political Shenanigans: http:\/\/t.co\/M9fqWdSp via @wordpressdotcom",
  "id" : 166503692059680768,
  "created_at" : "2012-02-06 12:49:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03C3\u03B7\u03C1\u03B1\u03BB\u03B5\u03BA",
      "screen_name" : "shralec",
      "indices" : [ 3, 11 ],
      "id_str" : "17549471",
      "id" : 17549471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166296366514057218",
  "text" : "RT @shralec: Do not conform to the pattern of this world, but be transformed by the renewing of your spirit. -Rom 12:2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166277329247670272",
    "text" : "Do not conform to the pattern of this world, but be transformed by the renewing of your spirit. -Rom 12:2",
    "id" : 166277329247670272,
    "created_at" : "2012-02-05 21:49:39 +0000",
    "user" : {
      "name" : "\u03C3\u03B7\u03C1\u03B1\u03BB\u03B5\u03BA",
      "screen_name" : "shralec",
      "protected" : false,
      "id_str" : "17549471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800733897231364096\/hZL-iXTQ_normal.jpg",
      "id" : 17549471,
      "verified" : false
    }
  },
  "id" : 166296366514057218,
  "created_at" : "2012-02-05 23:05:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166274371525156864",
  "geo" : { },
  "id_str" : "166276235524186112",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time oh.. poor babe..lol",
  "id" : 166276235524186112,
  "in_reply_to_status_id" : 166274371525156864,
  "created_at" : "2012-02-05 21:45:18 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166275915750457344",
  "text" : "RT @OMGFacts: A 30-second ad for Super Bowl I cost $42,000. For today's Super Bowl, 30-seconds will run you $3.5 million",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166274837101285376",
    "text" : "A 30-second ad for Super Bowl I cost $42,000. For today's Super Bowl, 30-seconds will run you $3.5 million",
    "id" : 166274837101285376,
    "created_at" : "2012-02-05 21:39:45 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 166275915750457344,
  "created_at" : "2012-02-05 21:44:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166275768769449984",
  "text" : "Kindle credit! woohoo! Points for hubby..lol",
  "id" : 166275768769449984,
  "created_at" : "2012-02-05 21:43:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166253815962669057",
  "text" : "RT @PinarAkal1: \u2740There are always flowers for those who want to see them. ~Henri Matisse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166253627105742848",
    "text" : "\u2740There are always flowers for those who want to see them. ~Henri Matisse",
    "id" : 166253627105742848,
    "created_at" : "2012-02-05 20:15:28 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 166253815962669057,
  "created_at" : "2012-02-05 20:16:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166253488622411777",
  "text" : "dizzy due to sinuses. grateful for stomach behaving, tho. : )",
  "id" : 166253488622411777,
  "created_at" : "2012-02-05 20:14:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LilyLuvTooteeStripey",
      "screen_name" : "LilyLuWhoT",
      "indices" : [ 3, 14 ],
      "id_str" : "141283057",
      "id" : 141283057
    }, {
      "name" : "Shayna La Belgique",
      "screen_name" : "ShaynaCat",
      "indices" : [ 19, 29 ],
      "id_str" : "184515961",
      "id" : 184515961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Purrs4Peace",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166252060357042176",
  "text" : "RT @LilyLuWhoT: RT @ShaynaCat: For all anipals & humans to be loved & wanted - purrrr... #Purrs4Peace",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shayna La Belgique",
        "screen_name" : "ShaynaCat",
        "indices" : [ 3, 13 ],
        "id_str" : "184515961",
        "id" : 184515961
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Purrs4Peace",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166250684893773825",
    "text" : "RT @ShaynaCat: For all anipals & humans to be loved & wanted - purrrr... #Purrs4Peace",
    "id" : 166250684893773825,
    "created_at" : "2012-02-05 20:03:46 +0000",
    "user" : {
      "name" : "LilyLuvTooteeStripey",
      "screen_name" : "LilyLuWhoT",
      "protected" : false,
      "id_str" : "141283057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795593747203559424\/YAF-oxZ2_normal.jpg",
      "id" : 141283057,
      "verified" : false
    }
  },
  "id" : 166252060357042176,
  "created_at" : "2012-02-05 20:09:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deplorable Michael",
      "screen_name" : "Michael214365",
      "indices" : [ 0, 14 ],
      "id_str" : "254629671",
      "id" : 254629671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166249403831697408",
  "geo" : { },
  "id_str" : "166251873404334081",
  "in_reply_to_user_id" : 254629671,
  "text" : "@Michael214365 lol.. yup! ; )",
  "id" : 166251873404334081,
  "in_reply_to_status_id" : 166249403831697408,
  "created_at" : "2012-02-05 20:08:30 +0000",
  "in_reply_to_screen_name" : "Michael214365",
  "in_reply_to_user_id_str" : "254629671",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166244167368978432",
  "text" : "cranky cranky cranky...",
  "id" : 166244167368978432,
  "created_at" : "2012-02-05 19:37:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165998339203149824",
  "text" : "RT @parkstepp: \"The fact that Terrorism has no fixed meaning does not mean it is inconsequential. The opposite is true....\" http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/NcBLrGFN",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyFvRrvY",
        "display_url" : "tmblr.co\/ZwrrNyFvRrvY"
      } ]
    },
    "geo" : { },
    "id_str" : "165997535968755712",
    "text" : "\"The fact that Terrorism has no fixed meaning does not mean it is inconsequential. The opposite is true....\" http:\/\/t.co\/NcBLrGFN",
    "id" : 165997535968755712,
    "created_at" : "2012-02-05 03:17:51 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 165998339203149824,
  "created_at" : "2012-02-05 03:21:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165997409820884992",
  "text" : "RT @ShipsofSong: Every individual has the right to their own perception of reality.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165996981737627648",
    "text" : "Every individual has the right to their own perception of reality.",
    "id" : 165996981737627648,
    "created_at" : "2012-02-05 03:15:39 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 165997409820884992,
  "created_at" : "2012-02-05 03:17:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzanne Simnick",
      "screen_name" : "SuzanneSimnick",
      "indices" : [ 3, 18 ],
      "id_str" : "388381588",
      "id" : 388381588
    }, {
      "name" : "Superhero Fan",
      "screen_name" : "DM286",
      "indices" : [ 20, 26 ],
      "id_str" : "294835491",
      "id" : 294835491
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 27, 41 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Stop The Wars",
      "screen_name" : "sickjew",
      "indices" : [ 42, 50 ],
      "id_str" : "65404941",
      "id" : 65404941
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SuzanneSimnick\/status\/165927249059643392\/photo\/1",
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/R9GvbZXf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ak199DMCAAAoWLN.jpg",
      "id_str" : "165927249063837696",
      "id" : 165927249063837696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ak199DMCAAAoWLN.jpg",
      "sizes" : [ {
        "h" : 599,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R9GvbZXf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165929749292658688",
  "text" : "RT @SuzanneSimnick: @DM286 @CharlesBivona @sickjew     Canada even does THIS better!!! http:\/\/t.co\/R9GvbZXf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Superhero Fan",
        "screen_name" : "DM286",
        "indices" : [ 0, 6 ],
        "id_str" : "294835491",
        "id" : 294835491
      }, {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 7, 21 ],
        "id_str" : "45254966",
        "id" : 45254966
      }, {
        "name" : "Stop The Wars",
        "screen_name" : "sickjew",
        "indices" : [ 22, 30 ],
        "id_str" : "65404941",
        "id" : 65404941
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SuzanneSimnick\/status\/165927249059643392\/photo\/1",
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/R9GvbZXf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ak199DMCAAAoWLN.jpg",
        "id_str" : "165927249063837696",
        "id" : 165927249063837696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ak199DMCAAAoWLN.jpg",
        "sizes" : [ {
          "h" : 599,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/R9GvbZXf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "165926340372070400",
    "geo" : { },
    "id_str" : "165927249059643392",
    "in_reply_to_user_id" : 294835491,
    "text" : "@DM286 @CharlesBivona @sickjew     Canada even does THIS better!!! http:\/\/t.co\/R9GvbZXf",
    "id" : 165927249059643392,
    "in_reply_to_status_id" : 165926340372070400,
    "created_at" : "2012-02-04 22:38:34 +0000",
    "in_reply_to_screen_name" : "DM286",
    "in_reply_to_user_id_str" : "294835491",
    "user" : {
      "name" : "Suzanne Simnick",
      "screen_name" : "SuzanneSimnick",
      "protected" : false,
      "id_str" : "388381588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654478647466835968\/ZacDBtTq_normal.jpg",
      "id" : 388381588,
      "verified" : false
    }
  },
  "id" : 165929749292658688,
  "created_at" : "2012-02-04 22:48:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165928853292847104",
  "text" : "\"well that was thoroughly depressing\" DH after watching One Rat Short. Misery loves company! lol",
  "id" : 165928853292847104,
  "created_at" : "2012-02-04 22:44:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165903549669183489",
  "text" : "RT @ShipsofSong: Darkness is simply a degree of light.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165902963531988992",
    "text" : "Darkness is simply a degree of light.",
    "id" : 165902963531988992,
    "created_at" : "2012-02-04 21:02:03 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 165903549669183489,
  "created_at" : "2012-02-04 21:04:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 3, 17 ],
      "id_str" : "183854047",
      "id" : 183854047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165903043731263489",
  "text" : "RT @CatFoodBreath: Cats are capable of making about 100 different sounds.  They all mean \"I'm hungry.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165901805832773632",
    "text" : "Cats are capable of making about 100 different sounds.  They all mean \"I'm hungry.\"",
    "id" : 165901805832773632,
    "created_at" : "2012-02-04 20:57:27 +0000",
    "user" : {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "protected" : false,
      "id_str" : "183854047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1112259384\/birman_normal.jpg",
      "id" : 183854047,
      "verified" : false
    }
  },
  "id" : 165903043731263489,
  "created_at" : "2012-02-04 21:02:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/GrbTKa1d",
      "expanded_url" : "http:\/\/www.openfilm.com\/videos\/one-rat-short",
      "display_url" : "openfilm.com\/videos\/one-rat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165890099958128641",
  "text" : "One Rat Short! http:\/\/t.co\/GrbTKa1d",
  "id" : 165890099958128641,
  "created_at" : "2012-02-04 20:10:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165886417233395714",
  "text" : "sinuses.. ugh. : (",
  "id" : 165886417233395714,
  "created_at" : "2012-02-04 19:56:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeverlyEverson",
      "screen_name" : "BeverlyEverson",
      "indices" : [ 59, 74 ],
      "id_str" : "15484732",
      "id" : 15484732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/BRjhRK29",
      "expanded_url" : "http:\/\/post.ly\/55WZ1",
      "display_url" : "post.ly\/55WZ1"
    } ]
  },
  "geo" : { },
  "id_str" : "165876040705650689",
  "text" : "Waiting For Their Ship To Come In http:\/\/t.co\/BRjhRK29 via @BeverlyEverson",
  "id" : 165876040705650689,
  "created_at" : "2012-02-04 19:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165874363650932737",
  "text" : "RT @DoreenVirtue444: Thank you, Archangel Zadkiel, for helping me focus upon my beautiful memories and let the rest go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165873220333998081",
    "text" : "Thank you, Archangel Zadkiel, for helping me focus upon my beautiful memories and let the rest go.",
    "id" : 165873220333998081,
    "created_at" : "2012-02-04 19:03:52 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 165874363650932737,
  "created_at" : "2012-02-04 19:08:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ajackson",
      "screen_name" : "antitheistangie",
      "indices" : [ 0, 16 ],
      "id_str" : "16959340",
      "id" : 16959340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165854334213562368",
  "geo" : { },
  "id_str" : "165859440086614017",
  "in_reply_to_user_id" : 16959340,
  "text" : "@antitheistangie TY4 that.. sometimes not sure what 2 say but want 2 express sympathy, consolation, etc.",
  "id" : 165859440086614017,
  "in_reply_to_status_id" : 165854334213562368,
  "created_at" : "2012-02-04 18:09:06 +0000",
  "in_reply_to_screen_name" : "antitheistangie",
  "in_reply_to_user_id_str" : "16959340",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Socialist Christian",
      "screen_name" : "socialistxian",
      "indices" : [ 0, 14 ],
      "id_str" : "771679270418714624",
      "id" : 771679270418714624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165858498347929600",
  "text" : "@SocialistXian jigglypuff! im prob considered a pinko liberal.. but what is pinko?",
  "id" : 165858498347929600,
  "created_at" : "2012-02-04 18:05:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 11, 27 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165850135992078336",
  "geo" : { },
  "id_str" : "165850887099662336",
  "in_reply_to_user_id" : 233971651,
  "text" : "@Selaniest @TheChristianLft voters have only 2 choices",
  "id" : 165850887099662336,
  "in_reply_to_status_id" : 165850135992078336,
  "created_at" : "2012-02-04 17:35:07 +0000",
  "in_reply_to_screen_name" : "UnwashedThe",
  "in_reply_to_user_id_str" : "233971651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janette",
      "screen_name" : "BeamMeUpPlz",
      "indices" : [ 0, 12 ],
      "id_str" : "22484703",
      "id" : 22484703
    }, {
      "name" : "jophsie",
      "screen_name" : "jophsie",
      "indices" : [ 13, 21 ],
      "id_str" : "356512360",
      "id" : 356512360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165836076127227904",
  "geo" : { },
  "id_str" : "165850301188947968",
  "in_reply_to_user_id" : 22484703,
  "text" : "@BeamMeUpPlz @jophsie @WarriorBanker agreed...",
  "id" : 165850301188947968,
  "in_reply_to_status_id" : 165836076127227904,
  "created_at" : "2012-02-04 17:32:47 +0000",
  "in_reply_to_screen_name" : "BeamMeUpPlz",
  "in_reply_to_user_id_str" : "22484703",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 87, 96 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/jqCAewpr",
      "expanded_url" : "http:\/\/gu.com\/p\/358an\/tw",
      "display_url" : "gu.com\/p\/358an\/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "165846724886265856",
  "text" : "RT @thesexyatheist: Unlikely animal friendships - in pictures http:\/\/t.co\/jqCAewpr via @guardian Prepare to be \"Awwww'd\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 67, 76 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/jqCAewpr",
        "expanded_url" : "http:\/\/gu.com\/p\/358an\/tw",
        "display_url" : "gu.com\/p\/358an\/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "165842512341250049",
    "text" : "Unlikely animal friendships - in pictures http:\/\/t.co\/jqCAewpr via @guardian Prepare to be \"Awwww'd\"",
    "id" : 165842512341250049,
    "created_at" : "2012-02-04 17:01:50 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 165846724886265856,
  "created_at" : "2012-02-04 17:18:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165842922812620801",
  "text" : "RT @DoreenVirtue444: What if, instead of succumbing to worry, you stopped and prayed for help instead?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165842511674359810",
    "text" : "What if, instead of succumbing to worry, you stopped and prayed for help instead?",
    "id" : 165842511674359810,
    "created_at" : "2012-02-04 17:01:50 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 165842922812620801,
  "created_at" : "2012-02-04 17:03:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165842832400191490",
  "text" : "RT @TheChristianLft: Why the [F-Bomb] is my government building hospitals and subsidizing Health care in Afghanistan and Iraq if we\u2019re.. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/UmscsMwB",
        "expanded_url" : "http:\/\/fb.me\/154VR3A8k",
        "display_url" : "fb.me\/154VR3A8k"
      } ]
    },
    "geo" : { },
    "id_str" : "165841838501134336",
    "text" : "Why the [F-Bomb] is my government building hospitals and subsidizing Health care in Afghanistan and Iraq if we\u2019re... http:\/\/t.co\/UmscsMwB",
    "id" : 165841838501134336,
    "created_at" : "2012-02-04 16:59:10 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 165842832400191490,
  "created_at" : "2012-02-04 17:03:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andie Redwine",
      "screen_name" : "AndieRedwine",
      "indices" : [ 3, 16 ],
      "id_str" : "14586373",
      "id" : 14586373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165841751003758593",
  "text" : "RT @AndieRedwine: I'm not anti-Jesus or anti-church.  What I am is anti-authoritarian control and pro-freedom.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165755612695769089",
    "text" : "I'm not anti-Jesus or anti-church.  What I am is anti-authoritarian control and pro-freedom.",
    "id" : 165755612695769089,
    "created_at" : "2012-02-04 11:16:32 +0000",
    "user" : {
      "name" : "Andie Redwine",
      "screen_name" : "AndieRedwine",
      "protected" : false,
      "id_str" : "14586373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701584336127037440\/3KYEojVz_normal.jpg",
      "id" : 14586373,
      "verified" : false
    }
  },
  "id" : 165841751003758593,
  "created_at" : "2012-02-04 16:58:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165837559677722626",
  "text" : "RT @JohnCali: Everything is energy and that\u2019s all there is to it. ~ Albert Einstein",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165836606765408258",
    "text" : "Everything is energy and that\u2019s all there is to it. ~ Albert Einstein",
    "id" : 165836606765408258,
    "created_at" : "2012-02-04 16:38:22 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 165837559677722626,
  "created_at" : "2012-02-04 16:42:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jophsie",
      "screen_name" : "jophsie",
      "indices" : [ 2, 10 ],
      "id_str" : "356512360",
      "id" : 356512360
    }, {
      "name" : "Janette",
      "screen_name" : "BeamMeUpPlz",
      "indices" : [ 11, 23 ],
      "id_str" : "22484703",
      "id" : 22484703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165822833128247296",
  "geo" : { },
  "id_str" : "165831348186124289",
  "in_reply_to_user_id" : 356512360,
  "text" : ". @jophsie @BeamMeUpPlz @WarriorBanker ...and who decides the correct interpretation?",
  "id" : 165831348186124289,
  "in_reply_to_status_id" : 165822833128247296,
  "created_at" : "2012-02-04 16:17:29 +0000",
  "in_reply_to_screen_name" : "jophsie",
  "in_reply_to_user_id_str" : "356512360",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KindleFireDept",
      "screen_name" : "KindleFireDept",
      "indices" : [ 6, 21 ],
      "id_str" : "867417752",
      "id" : 867417752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoToAppDemo",
      "indices" : [ 37, 49 ]
    }, {
      "text" : "KindleFire",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165829424573456384",
  "text" : "Thx 2 @KindleFireDept for showing me #GoToAppDemo for #KindleFire .. love it! Very helpful app.",
  "id" : 165829424573456384,
  "created_at" : "2012-02-04 16:09:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165827818268262400",
  "text" : "RT @JosephRanseth: Absolutely everything in this world makes sense if you can get a high enough perspective on it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165825213416751104",
    "text" : "Absolutely everything in this world makes sense if you can get a high enough perspective on it.",
    "id" : 165825213416751104,
    "created_at" : "2012-02-04 15:53:06 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 165827818268262400,
  "created_at" : "2012-02-04 16:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nichole Nordeman",
      "screen_name" : "nicholenordeman",
      "indices" : [ 3, 19 ],
      "id_str" : "133546408",
      "id" : 133546408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165626831075147776",
  "text" : "RT @nicholenordeman: My son just took the home phone into his room and called my cell & tried to order a snack from \"room service.\" Yah. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165617824193191939",
    "text" : "My son just took the home phone into his room and called my cell & tried to order a snack from \"room service.\" Yah.  I'll get right on that.",
    "id" : 165617824193191939,
    "created_at" : "2012-02-04 02:09:00 +0000",
    "user" : {
      "name" : "Nichole Nordeman",
      "screen_name" : "nicholenordeman",
      "protected" : false,
      "id_str" : "133546408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613844089948143617\/MwXWQOLI_normal.jpg",
      "id" : 133546408,
      "verified" : true
    }
  },
  "id" : 165626831075147776,
  "created_at" : "2012-02-04 02:44:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165609773729984513",
  "text" : "New guest at the diner this eve.. a small skittish calico kitty",
  "id" : 165609773729984513,
  "created_at" : "2012-02-04 01:37:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165595186225872896",
  "text" : "RT @By_Bashar: There is nothing in this universe you cannot handle. You are not a weak being.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165593962571235329",
    "text" : "There is nothing in this universe you cannot handle. You are not a weak being.",
    "id" : 165593962571235329,
    "created_at" : "2012-02-04 00:34:11 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 165595186225872896,
  "created_at" : "2012-02-04 00:39:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Vincent Mistretta",
      "screen_name" : "VinnieMistretta",
      "indices" : [ 63, 79 ],
      "id_str" : "189314968",
      "id" : 189314968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wildlife",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "Baxter_State_Park_ME",
      "indices" : [ 90, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/nbXLmTm8",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/11904",
      "display_url" : "wildobs.com\/wo\/11904"
    } ]
  },
  "geo" : { },
  "id_str" : "165587188774486016",
  "text" : "RT @wildobs: For the late crowd: Moose http:\/\/t.co\/nbXLmTm8 by @VinnieMistretta #wildlife #Baxter_State_Park_ME",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vincent Mistretta",
        "screen_name" : "VinnieMistretta",
        "indices" : [ 50, 66 ],
        "id_str" : "189314968",
        "id" : 189314968
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wildlife",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "Baxter_State_Park_ME",
        "indices" : [ 77, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/nbXLmTm8",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/11904",
        "display_url" : "wildobs.com\/wo\/11904"
      } ]
    },
    "geo" : { },
    "id_str" : "165586936696811521",
    "text" : "For the late crowd: Moose http:\/\/t.co\/nbXLmTm8 by @VinnieMistretta #wildlife #Baxter_State_Park_ME",
    "id" : 165586936696811521,
    "created_at" : "2012-02-04 00:06:16 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 165587188774486016,
  "created_at" : "2012-02-04 00:07:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165583905288753153",
  "geo" : { },
  "id_str" : "165586365839446016",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ba-bing! lol",
  "id" : 165586365839446016,
  "in_reply_to_status_id" : 165583905288753153,
  "created_at" : "2012-02-04 00:04:00 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abraham",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "buddhism",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165582289747709952",
  "text" : "resistance is where all pain comes from. interesting, eh? got that from #abraham and #buddhism",
  "id" : 165582289747709952,
  "created_at" : "2012-02-03 23:47:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165580924401098753",
  "text" : "I just dont see the sense in expending energy worrying about stuff that may or may not happen. but some ppl get perturbed if you dont...",
  "id" : 165580924401098753,
  "created_at" : "2012-02-03 23:42:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165579597574971394",
  "text" : "I didnt get the \"fun\" gene o-O",
  "id" : 165579597574971394,
  "created_at" : "2012-02-03 23:37:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165579485259890689",
  "text" : "the re agent who came thru house knew my mom. told hubby \"what a lady\" she was and how much fun she was..",
  "id" : 165579485259890689,
  "created_at" : "2012-02-03 23:36:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165569829884014592",
  "text" : "the brown cat actually peeked at bottom of porch B4 I even opened door (after I put food out, coming back inside)",
  "id" : 165569829884014592,
  "created_at" : "2012-02-03 22:58:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeschool",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165566184782168064",
  "text" : "well, I found some options, should we need to #homeschool next year...",
  "id" : 165566184782168064,
  "created_at" : "2012-02-03 22:43:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165516615981613058",
  "text" : "RT @GraveStomper: Humans look back on things &  say: I didn't realize all the opportunities I had. Maybe, right now, you don't realize a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165514881280385025",
    "text" : "Humans look back on things &  say: I didn't realize all the opportunities I had. Maybe, right now, you don't realize all your opportunities.",
    "id" : 165514881280385025,
    "created_at" : "2012-02-03 19:19:57 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 165516615981613058,
  "created_at" : "2012-02-03 19:26:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeschool",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165486140500090881",
  "text" : "I found Life of Fred math, Facinating Education science... #homeschool",
  "id" : 165486140500090881,
  "created_at" : "2012-02-03 17:25:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165428209574346754",
  "text" : "ok, are pigs flying?? DH just asked me to research... homeschooling! (possible move, diff school, sensitive kid) yup, its 2012.",
  "id" : 165428209574346754,
  "created_at" : "2012-02-03 13:35:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GQ Magazine",
      "screen_name" : "GQMagazine",
      "indices" : [ 113, 124 ],
      "id_str" : "21701757",
      "id" : 21701757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/f7GMUfL4",
      "expanded_url" : "http:\/\/www.gq.com\/news-politics\/newsmakers\/201202\/burning-man-sam-brown-jay-kirk-gq-february-2012",
      "display_url" : "gq.com\/news-politics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165220558542352384",
  "text" : "Burn Victim Sam Brown Treated With Virtual-Reality Video Game SnowWorld: Newsmakers: GQ http:\/\/t.co\/f7GMUfL4 via @gqmagazine",
  "id" : 165220558542352384,
  "created_at" : "2012-02-02 23:50:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Next Miyazaki Orsini",
      "screen_name" : "laureninspace",
      "indices" : [ 3, 17 ],
      "id_str" : "18278364",
      "id" : 18278364
    }, {
      "name" : "The Honey Badger",
      "screen_name" : "BronxZooHBadger",
      "indices" : [ 23, 39 ],
      "id_str" : "273624512",
      "id" : 273624512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/2quwdvOH",
      "expanded_url" : "http:\/\/bit.ly\/yNEz22",
      "display_url" : "bit.ly\/yNEz22"
    } ]
  },
  "geo" : { },
  "id_str" : "165218898575245312",
  "text" : "RT @laureninspace: The @BronxZooHBadger is on Pinterest! And he's even made a board of all the things he cares about: http:\/\/t.co\/2quwdvOH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Honey Badger",
        "screen_name" : "BronxZooHBadger",
        "indices" : [ 4, 20 ],
        "id_str" : "273624512",
        "id" : 273624512
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/2quwdvOH",
        "expanded_url" : "http:\/\/bit.ly\/yNEz22",
        "display_url" : "bit.ly\/yNEz22"
      } ]
    },
    "geo" : { },
    "id_str" : "165196121013104640",
    "text" : "The @BronxZooHBadger is on Pinterest! And he's even made a board of all the things he cares about: http:\/\/t.co\/2quwdvOH",
    "id" : 165196121013104640,
    "created_at" : "2012-02-02 22:13:19 +0000",
    "user" : {
      "name" : "Next Miyazaki Orsini",
      "screen_name" : "laureninspace",
      "protected" : false,
      "id_str" : "18278364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716656745230286849\/EsorKNBQ_normal.jpg",
      "id" : 18278364,
      "verified" : false
    }
  },
  "id" : 165218898575245312,
  "created_at" : "2012-02-02 23:43:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    }, {
      "name" : "Kristen Bell",
      "screen_name" : "IMKristenBell",
      "indices" : [ 65, 79 ],
      "id_str" : "53297035",
      "id" : 53297035
    }, {
      "name" : "Kristen Bell",
      "screen_name" : "IMKristenBell",
      "indices" : [ 99, 113 ],
      "id_str" : "53297035",
      "id" : 53297035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165218274399891458",
  "text" : "RT @adampknave: I just realized. We are all now as obsessed with @IMKristenBell watching sloths as @IMKristenBell is obsessed with sloth ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kristen Bell",
        "screen_name" : "IMKristenBell",
        "indices" : [ 49, 63 ],
        "id_str" : "53297035",
        "id" : 53297035
      }, {
        "name" : "Kristen Bell",
        "screen_name" : "IMKristenBell",
        "indices" : [ 83, 97 ],
        "id_str" : "53297035",
        "id" : 53297035
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165217275568332800",
    "text" : "I just realized. We are all now as obsessed with @IMKristenBell watching sloths as @IMKristenBell is obsessed with sloths themselves. Huh.",
    "id" : 165217275568332800,
    "created_at" : "2012-02-02 23:37:22 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 165218274399891458,
  "created_at" : "2012-02-02 23:41:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Clara Jeffery",
      "screen_name" : "ClaraJeffery",
      "indices" : [ 16, 29 ],
      "id_str" : "43412697",
      "id" : 43412697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165208614896807936",
  "text" : "RT @SangyeH: RT @ClaraJeffery: OUTRAGEOUS: kids taken fr undoc'd parents, put up for adoption, parental rights severed by US judges http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clara Jeffery",
        "screen_name" : "ClaraJeffery",
        "indices" : [ 3, 16 ],
        "id_str" : "43412697",
        "id" : 43412697
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/Q9sJWfBv",
        "expanded_url" : "http:\/\/abcn.ws\/yYEsXl",
        "display_url" : "abcn.ws\/yYEsXl"
      } ]
    },
    "geo" : { },
    "id_str" : "165203527168303104",
    "text" : "RT @ClaraJeffery: OUTRAGEOUS: kids taken fr undoc'd parents, put up for adoption, parental rights severed by US judges http:\/\/t.co\/Q9sJWfBv",
    "id" : 165203527168303104,
    "created_at" : "2012-02-02 22:42:44 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 165208614896807936,
  "created_at" : "2012-02-02 23:02:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165188576475234304",
  "geo" : { },
  "id_str" : "165189350471122944",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes oh, yeah.. how did he get away w that? o-O",
  "id" : 165189350471122944,
  "in_reply_to_status_id" : 165188576475234304,
  "created_at" : "2012-02-02 21:46:24 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165165019997282304",
  "text" : "RT @By_Bashar: If you do not know the way, seek footprints\u00A0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165163642059362304",
    "text" : "If you do not know the way, seek footprints\u00A0",
    "id" : 165163642059362304,
    "created_at" : "2012-02-02 20:04:15 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 165165019997282304,
  "created_at" : "2012-02-02 20:09:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Carpenter",
      "screen_name" : "MindJuiceMedia",
      "indices" : [ 0, 15 ],
      "id_str" : "55054587",
      "id" : 55054587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165149638071025664",
  "geo" : { },
  "id_str" : "165150468371251200",
  "in_reply_to_user_id" : 55054587,
  "text" : "@MindJuiceMedia I love word games! : )",
  "id" : 165150468371251200,
  "in_reply_to_status_id" : 165149638071025664,
  "created_at" : "2012-02-02 19:11:54 +0000",
  "in_reply_to_screen_name" : "MindJuiceMedia",
  "in_reply_to_user_id_str" : "55054587",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165142158737801216",
  "geo" : { },
  "id_str" : "165146403172122624",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous was a good article.. amazing how the VR reduced pain!",
  "id" : 165146403172122624,
  "in_reply_to_status_id" : 165142158737801216,
  "created_at" : "2012-02-02 18:55:45 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165141144471224320",
  "text" : "RT @ShipsofSong: Consciousness attracts Light.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165137429005746176",
    "text" : "Consciousness attracts Light.",
    "id" : 165137429005746176,
    "created_at" : "2012-02-02 18:20:05 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 165141144471224320,
  "created_at" : "2012-02-02 18:34:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165137757696569344",
  "geo" : { },
  "id_str" : "165140658573680640",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous opened for me using chrome",
  "id" : 165140658573680640,
  "in_reply_to_status_id" : 165137757696569344,
  "created_at" : "2012-02-02 18:32:55 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165135157320351744",
  "text" : "RT @By_Bashar: Everyone elses stress is their choice - it does not have to be yours.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165133482719322113",
    "text" : "Everyone elses stress is their choice - it does not have to be yours.",
    "id" : 165133482719322113,
    "created_at" : "2012-02-02 18:04:24 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 165135157320351744,
  "created_at" : "2012-02-02 18:11:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 107, 115 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/dMufQckS",
      "expanded_url" : "http:\/\/bit.ly\/wwYPt7",
      "display_url" : "bit.ly\/wwYPt7"
    } ]
  },
  "geo" : { },
  "id_str" : "165134001403727872",
  "text" : "Santorum to sick kid: Don\u2019t complain about $1 million drug costs | The Raw Story: http:\/\/t.co\/dMufQckS via @AddThis",
  "id" : 165134001403727872,
  "created_at" : "2012-02-02 18:06:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 0, 15 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165112909964386305",
  "geo" : { },
  "id_str" : "165114671865671680",
  "in_reply_to_user_id" : 143989898,
  "text" : "@ThrillersRockT fyi: that link doesnt work. also, I didnt see that particular book listed on IBC.",
  "id" : 165114671865671680,
  "in_reply_to_status_id" : 165112909964386305,
  "created_at" : "2012-02-02 16:49:40 +0000",
  "in_reply_to_screen_name" : "ThrillersRockT",
  "in_reply_to_user_id_str" : "143989898",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "liquidbuddha",
      "screen_name" : "liquidbuddha",
      "indices" : [ 3, 16 ],
      "id_str" : "18367675",
      "id" : 18367675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165110210682302464",
  "text" : "RT @liquidbuddha: Today's mantra... I am an intergalactic tidal wave of wanton love and magic!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165105704800231424",
    "text" : "Today's mantra... I am an intergalactic tidal wave of wanton love and magic!",
    "id" : 165105704800231424,
    "created_at" : "2012-02-02 16:14:02 +0000",
    "user" : {
      "name" : "liquidbuddha",
      "screen_name" : "liquidbuddha",
      "protected" : false,
      "id_str" : "18367675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1535027618\/LBS-PROFILE-LOGO2_normal.jpg",
      "id" : 18367675,
      "verified" : false
    }
  },
  "id" : 165110210682302464,
  "created_at" : "2012-02-02 16:31:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VOTE",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "Author",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/nXmkXaVF",
      "expanded_url" : "http:\/\/youtu.be\/QG3cDMpFhLM",
      "display_url" : "youtu.be\/QG3cDMpFhLM"
    } ]
  },
  "geo" : { },
  "id_str" : "164889244324737025",
  "text" : "RT @UnseeingEyes: Don't let this happen to me again! -Shorty Awards Experience- http:\/\/t.co\/nXmkXaVF #VOTE for Twitter's BEST #Author ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VOTE",
        "indices" : [ 83, 88 ]
      }, {
        "text" : "Author",
        "indices" : [ 108, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/nXmkXaVF",
        "expanded_url" : "http:\/\/youtu.be\/QG3cDMpFhLM",
        "display_url" : "youtu.be\/QG3cDMpFhLM"
      }, {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/gG5V1JSG",
        "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
        "display_url" : "shortyawards.com\/UnseeingEyes"
      } ]
    },
    "geo" : { },
    "id_str" : "164886289311739904",
    "text" : "Don't let this happen to me again! -Shorty Awards Experience- http:\/\/t.co\/nXmkXaVF #VOTE for Twitter's BEST #Author http:\/\/t.co\/gG5V1JSG",
    "id" : 164886289311739904,
    "created_at" : "2012-02-02 01:42:09 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 164889244324737025,
  "created_at" : "2012-02-02 01:53:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164848905748615169",
  "geo" : { },
  "id_str" : "164888497059147776",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous aww, im sorry ((hugs))",
  "id" : 164888497059147776,
  "in_reply_to_status_id" : 164848905748615169,
  "created_at" : "2012-02-02 01:50:55 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164841939827560448",
  "text" : "RT @KerriFar: Wonderful!! RT @Vinterjenta:  if you would like to see swans?  Svanesj\u00F8en http:\/\/t.co\/RBMgKbJT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/RBMgKbJT",
        "expanded_url" : "http:\/\/nblo.gs\/trIfm",
        "display_url" : "nblo.gs\/trIfm"
      } ]
    },
    "geo" : { },
    "id_str" : "164841530463494144",
    "text" : "Wonderful!! RT @Vinterjenta:  if you would like to see swans?  Svanesj\u00F8en http:\/\/t.co\/RBMgKbJT",
    "id" : 164841530463494144,
    "created_at" : "2012-02-01 22:44:18 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 164841939827560448,
  "created_at" : "2012-02-01 22:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164840645503090688",
  "geo" : { },
  "id_str" : "164841481344000001",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous bad day??",
  "id" : 164841481344000001,
  "in_reply_to_status_id" : 164840645503090688,
  "created_at" : "2012-02-01 22:44:06 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hayson\u2122",
      "screen_name" : "haysontweets",
      "indices" : [ 3, 16 ],
      "id_str" : "26431760",
      "id" : 26431760
    }, {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 83, 94 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/3vjAnh57",
      "expanded_url" : "http:\/\/boingboing.net\/2012\/01\/25\/the-adorable-snoring-dormouse.html",
      "display_url" : "boingboing.net\/2012\/01\/25\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164836393032491011",
  "text" : "RT @haysontweets: Cute of the day: snoring dormouse: http:\/\/t.co\/3vjAnh57  Thanks, @BoingBoing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boing Boing",
        "screen_name" : "BoingBoing",
        "indices" : [ 65, 76 ],
        "id_str" : "5971922",
        "id" : 5971922
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/3vjAnh57",
        "expanded_url" : "http:\/\/boingboing.net\/2012\/01\/25\/the-adorable-snoring-dormouse.html",
        "display_url" : "boingboing.net\/2012\/01\/25\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164486631519305728",
    "text" : "Cute of the day: snoring dormouse: http:\/\/t.co\/3vjAnh57  Thanks, @BoingBoing",
    "id" : 164486631519305728,
    "created_at" : "2012-01-31 23:14:03 +0000",
    "user" : {
      "name" : "hayson\u2122",
      "screen_name" : "haysontweets",
      "protected" : false,
      "id_str" : "26431760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2907993845\/7355cca78ab1ab1c0d35ac89552d175b_normal.jpeg",
      "id" : 26431760,
      "verified" : false
    }
  },
  "id" : 164836393032491011,
  "created_at" : "2012-02-01 22:23:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164794833855193088",
  "text" : "hmm.. I think hubby is having a breakdown...",
  "id" : 164794833855193088,
  "created_at" : "2012-02-01 19:38:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    }, {
      "name" : "Letitia Potorac",
      "screen_name" : "Letitia_Potorac",
      "indices" : [ 79, 95 ],
      "id_str" : "104479971",
      "id" : 104479971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164772124127539200",
  "text" : "RT @RichardWiseman: I have a thing for staircases and these are all amazing RT @Letitia_Potorac: Unbelievable and Incredible Staircases! ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Letitia Potorac",
        "screen_name" : "Letitia_Potorac",
        "indices" : [ 59, 75 ],
        "id_str" : "104479971",
        "id" : 104479971
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/CSpJyMY2",
        "expanded_url" : "http:\/\/ow.ly\/8NATY",
        "display_url" : "ow.ly\/8NATY"
      } ]
    },
    "geo" : { },
    "id_str" : "164766875086106626",
    "text" : "I have a thing for staircases and these are all amazing RT @Letitia_Potorac: Unbelievable and Incredible Staircases!! http:\/\/t.co\/CSpJyMY2",
    "id" : 164766875086106626,
    "created_at" : "2012-02-01 17:47:38 +0000",
    "user" : {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "protected" : false,
      "id_str" : "19512493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3225534671\/ef59c3b397d28dacb74034b47d8cd9e2_normal.jpeg",
      "id" : 19512493,
      "verified" : true
    }
  },
  "id" : 164772124127539200,
  "created_at" : "2012-02-01 18:08:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164770111205552128",
  "geo" : { },
  "id_str" : "164771169797545984",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl woohoo! you go, girl!! : )",
  "id" : 164771169797545984,
  "in_reply_to_status_id" : 164770111205552128,
  "created_at" : "2012-02-01 18:04:42 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/Wop0EMcx",
      "expanded_url" : "http:\/\/on.cc.com\/mWoWmI",
      "display_url" : "on.cc.com\/mWoWmI"
    } ]
  },
  "geo" : { },
  "id_str" : "164770555323613185",
  "text" : "rofl &gt;&gt; Daily Show: World of Class Warfare - The Poor's Free Ride Is Over http:\/\/t.co\/Wop0EMcx",
  "id" : 164770555323613185,
  "created_at" : "2012-02-01 18:02:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164738093944025088",
  "text" : "RT @CelticCamera: The new issue of PhotographyBB Onoine Magazine is hot off the the presses! Get you FREE copy gight here --&gt; http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/JD7TPV7B",
        "expanded_url" : "http:\/\/bit.ly\/zwzSWv",
        "display_url" : "bit.ly\/zwzSWv"
      } ]
    },
    "geo" : { },
    "id_str" : "164737294132199426",
    "text" : "The new issue of PhotographyBB Onoine Magazine is hot off the the presses! Get you FREE copy gight here --&gt; http:\/\/t.co\/JD7TPV7B",
    "id" : 164737294132199426,
    "created_at" : "2012-02-01 15:50:06 +0000",
    "user" : {
      "name" : "Gareth Glynn Ash",
      "screen_name" : "GarethGlynnAsh",
      "protected" : false,
      "id_str" : "21884322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714154956157227009\/p5XPCMj1_normal.jpg",
      "id" : 21884322,
      "verified" : false
    }
  },
  "id" : 164738093944025088,
  "created_at" : "2012-02-01 15:53:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael_Palmer",
      "screen_name" : "Michael_Palmer",
      "indices" : [ 43, 58 ],
      "id_str" : "17919174",
      "id" : 17919174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OathofOffice",
      "indices" : [ 26, 39 ]
    }, {
      "text" : "Readcast",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/XdNnUAYa",
      "expanded_url" : "http:\/\/www.scribd.com\/doc\/78685394",
      "display_url" : "scribd.com\/doc\/78685394"
    } ]
  },
  "geo" : { },
  "id_str" : "164736829889855488",
  "text" : "Reading \"Sneak Preview of #OathofOffice by @Michael_Palmer: Chapte...\" on Scribd http:\/\/t.co\/XdNnUAYa #Readcast",
  "id" : 164736829889855488,
  "created_at" : "2012-02-01 15:48:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Word Magazine",
      "screen_name" : "DailyWordMag",
      "indices" : [ 3, 16 ],
      "id_str" : "38060989",
      "id" : 38060989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DailyWord",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/aLNvxmQc",
      "expanded_url" : "http:\/\/www.dailyword.com\/dailyword\/52195",
      "display_url" : "dailyword.com\/dailyword\/52195"
    } ]
  },
  "geo" : { },
  "id_str" : "164735826067070977",
  "text" : "RT @DailyWordMag: Today's #DailyWord is Enter - With peace in my heart, I step forward on my life's journey. http:\/\/t.co\/aLNvxmQc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DailyWord",
        "indices" : [ 8, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/aLNvxmQc",
        "expanded_url" : "http:\/\/www.dailyword.com\/dailyword\/52195",
        "display_url" : "dailyword.com\/dailyword\/52195"
      } ]
    },
    "geo" : { },
    "id_str" : "164735419563515904",
    "text" : "Today's #DailyWord is Enter - With peace in my heart, I step forward on my life's journey. http:\/\/t.co\/aLNvxmQc",
    "id" : 164735419563515904,
    "created_at" : "2012-02-01 15:42:39 +0000",
    "user" : {
      "name" : "Daily Word Magazine",
      "screen_name" : "DailyWordMag",
      "protected" : false,
      "id_str" : "38060989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520305558453108736\/7I3IDB72_normal.jpeg",
      "id" : 38060989,
      "verified" : false
    }
  },
  "id" : 164735826067070977,
  "created_at" : "2012-02-01 15:44:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 2, 16 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164732636781232128",
  "geo" : { },
  "id_str" : "164734770356551683",
  "in_reply_to_user_id" : 113395189,
  "text" : ". @ThisBlueWorld reading ACIM did that for me.. gave me a broader perception of bible and world. major aha's w that book! : )",
  "id" : 164734770356551683,
  "in_reply_to_status_id" : 164732636781232128,
  "created_at" : "2012-02-01 15:40:04 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164734096067661825",
  "text" : "RT @ThisBlueWorld: The Universe always works out for the best. The Universe is God, and God loves you. Watch it unfold!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164732526814953473",
    "text" : "The Universe always works out for the best. The Universe is God, and God loves you. Watch it unfold!",
    "id" : 164732526814953473,
    "created_at" : "2012-02-01 15:31:09 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 164734096067661825,
  "created_at" : "2012-02-01 15:37:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164728713936764928",
  "text" : "RT @TheEntertainer: Trailblazing is NOT easy, BUT it IS freakin' COOL. If there isn't a model to follow, CREATE one, it's what I do #Jus ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JustDoYou",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164728479202541570",
    "text" : "Trailblazing is NOT easy, BUT it IS freakin' COOL. If there isn't a model to follow, CREATE one, it's what I do #JustDoYou",
    "id" : 164728479202541570,
    "created_at" : "2012-02-01 15:15:04 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 164728713936764928,
  "created_at" : "2012-02-01 15:16:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]