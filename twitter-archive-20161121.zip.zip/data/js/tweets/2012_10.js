Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263791981577261056",
  "text" : "RT @Soulseedzforall: Love is based on our capacity to trust in a reality beyond fear, to trust a timeless truth bigger than all our diff ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263790839703154689",
    "text" : "Love is based on our capacity to trust in a reality beyond fear, to trust a timeless truth bigger than all our difficulties.  Jack Kornfield",
    "id" : 263790839703154689,
    "created_at" : "2012-10-31 23:53:31 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 263791981577261056,
  "created_at" : "2012-10-31 23:58:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 3, 17 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263770289408704512",
  "text" : "RT @MikeBloomberg: Please join me in saying THANK YOU to the thousands of city employees working around the clock to get NYC back up and ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263768591172767745",
    "text" : "Please join me in saying THANK YOU to the thousands of city employees working around the clock to get NYC back up and running. Please RT.",
    "id" : 263768591172767745,
    "created_at" : "2012-10-31 22:25:07 +0000",
    "user" : {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "protected" : false,
      "id_str" : "16581604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615510114447953920\/_1c4TTMM_normal.jpg",
      "id" : 16581604,
      "verified" : true
    }
  },
  "id" : 263770289408704512,
  "created_at" : "2012-10-31 22:31:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263745268900589568",
  "text" : "i will still try to show kindness and respect but no longer will i remain quiet to avoid stepping on toes...",
  "id" : 263745268900589568,
  "created_at" : "2012-10-31 20:52:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263744795422371840",
  "text" : "life is short, getting shorter. i cant afford to not speak my mind any longer.",
  "id" : 263744795422371840,
  "created_at" : "2012-10-31 20:50:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263742474089009152",
  "geo" : { },
  "id_str" : "263744400683847681",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 heehee.. first thing i thought when i heard christie's praise the other day.",
  "id" : 263744400683847681,
  "in_reply_to_status_id" : 263742474089009152,
  "created_at" : "2012-10-31 20:48:59 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "breaksmyheart",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263716561733427200",
  "text" : "its hard enough losing mom when you're adult, married.. but to still be young.. #breaksmyheart",
  "id" : 263716561733427200,
  "created_at" : "2012-10-31 18:58:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263708470904233986",
  "text" : "just found out an online friend i knew from forums died on sunday. knew she was sick but death unexpected... : (",
  "id" : 263708470904233986,
  "created_at" : "2012-10-31 18:26:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263697776133697537",
  "text" : "the best of humanity will save us. look for it.",
  "id" : 263697776133697537,
  "created_at" : "2012-10-31 17:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263621547632250880",
  "geo" : { },
  "id_str" : "263673265430597633",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks you are awesome!",
  "id" : 263673265430597633,
  "in_reply_to_status_id" : 263621547632250880,
  "created_at" : "2012-10-31 16:06:19 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263671479206572033",
  "geo" : { },
  "id_str" : "263672029700554752",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth always disliked holidays, all the hoopla and socialization.. ugh. but now my parents are gone.. and i miss those times.",
  "id" : 263672029700554752,
  "in_reply_to_status_id" : 263671479206572033,
  "created_at" : "2012-10-31 16:01:25 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263671603508948992",
  "text" : "i love feeding the birds. chirp chirp...",
  "id" : 263671603508948992,
  "created_at" : "2012-10-31 15:59:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263666211856998400",
  "text" : "RT @By_Bashar: Vibration Synchronization is THE law of the Universe. You can only SEE the things you synchronize with. ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263665734238998529",
    "text" : "Vibration Synchronization is THE law of the Universe. You can only SEE the things you synchronize with. ~ bashar",
    "id" : 263665734238998529,
    "created_at" : "2012-10-31 15:36:24 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 263666211856998400,
  "created_at" : "2012-10-31 15:38:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263645194640031744",
  "text" : "RT @ZeitgeistGhost: There are MANY areas where PROFIT is NOT and SHOULD NOT be the motive.  Such as FEMA and our safety net. GREED IS NO ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263644698999128064",
    "text" : "There are MANY areas where PROFIT is NOT and SHOULD NOT be the motive.  Such as FEMA and our safety net. GREED IS NOT GOOD dagnabit",
    "id" : 263644698999128064,
    "created_at" : "2012-10-31 14:12:49 +0000",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 263645194640031744,
  "created_at" : "2012-10-31 14:14:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 3, 19 ],
      "id_str" : "95607516",
      "id" : 95607516
    }, {
      "name" : "Daily Mail Online",
      "screen_name" : "MailOnline",
      "indices" : [ 78, 89 ],
      "id_str" : "15438913",
      "id" : 15438913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/37TEk9jp",
      "expanded_url" : "http:\/\/bit.ly\/Rs50Kg",
      "display_url" : "bit.ly\/Rs50Kg"
    } ]
  },
  "geo" : { },
  "id_str" : "263629287003914240",
  "text" : "RT @DonkeySanctuary: The Donkey that outsang Domingo http:\/\/t.co\/37TEk9jp via @MailOnline",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Mail Online",
        "screen_name" : "MailOnline",
        "indices" : [ 57, 68 ],
        "id_str" : "15438913",
        "id" : 15438913
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/37TEk9jp",
        "expanded_url" : "http:\/\/bit.ly\/Rs50Kg",
        "display_url" : "bit.ly\/Rs50Kg"
      } ]
    },
    "geo" : { },
    "id_str" : "263625607471050752",
    "text" : "The Donkey that outsang Domingo http:\/\/t.co\/37TEk9jp via @MailOnline",
    "id" : 263625607471050752,
    "created_at" : "2012-10-31 12:56:57 +0000",
    "user" : {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "protected" : false,
      "id_str" : "95607516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710457498201952257\/F4zdnP4M_normal.jpg",
      "id" : 95607516,
      "verified" : true
    }
  },
  "id" : 263629287003914240,
  "created_at" : "2012-10-31 13:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263432732292554752",
  "text" : "@statue_dog and what a fine smile it is! smooches!",
  "id" : 263432732292554752,
  "created_at" : "2012-10-31 00:10:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/xaxG9C1T",
      "expanded_url" : "http:\/\/via.me\/-6hwhbbc",
      "display_url" : "via.me\/-6hwhbbc"
    } ]
  },
  "geo" : { },
  "id_str" : "263429241952165888",
  "text" : "Motley eating kibbles n bits day after Hurricane Sandy http:\/\/t.co\/xaxG9C1T",
  "id" : 263429241952165888,
  "created_at" : "2012-10-30 23:56:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263405965821476864",
  "text" : "RT @TheChristianLft: Canada has national health care (universal government backed health care), so does the UK. Are they \u201Csocialist\u201D...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/loXmfTuE",
        "expanded_url" : "http:\/\/fb.me\/1K4lSGUY3",
        "display_url" : "fb.me\/1K4lSGUY3"
      } ]
    },
    "geo" : { },
    "id_str" : "263401863582478337",
    "text" : "Canada has national health care (universal government backed health care), so does the UK. Are they \u201Csocialist\u201D... http:\/\/t.co\/loXmfTuE",
    "id" : 263401863582478337,
    "created_at" : "2012-10-30 22:07:52 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 263405965821476864,
  "created_at" : "2012-10-30 22:24:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Nichols",
      "screen_name" : "NicholsUprising",
      "indices" : [ 3, 19 ],
      "id_str" : "466519303",
      "id" : 466519303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263377593988943875",
  "text" : "RT @NicholsUprising: Wow! Romney ups the lie quotient substantially w\/new OH radio ad that maintains his Toledo\/China deception. @WeGotE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We Got Ed",
        "screen_name" : "WeGotEd",
        "indices" : [ 108, 116 ],
        "id_str" : "3113887713",
        "id" : 3113887713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/tL01vpRw",
        "expanded_url" : "http:\/\/www.thenation.com\/blog\/170905\/yes-romneys-liar-getting-ridiculous#",
        "display_url" : "thenation.com\/blog\/170905\/ye\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "263373009480462336",
    "text" : "Wow! Romney ups the lie quotient substantially w\/new OH radio ad that maintains his Toledo\/China deception. @WeGotEd http:\/\/t.co\/tL01vpRw",
    "id" : 263373009480462336,
    "created_at" : "2012-10-30 20:13:13 +0000",
    "user" : {
      "name" : "John Nichols",
      "screen_name" : "NicholsUprising",
      "protected" : false,
      "id_str" : "466519303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441901473299853312\/KQn3SLti_normal.jpeg",
      "id" : 466519303,
      "verified" : false
    }
  },
  "id" : 263377593988943875,
  "created_at" : "2012-10-30 20:31:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263343658370211842",
  "text" : "RT @CoryBooker: Police have reported ZERO looting or crimes of opportunity in Newark. And ceaseless reports of acts of kindness abound e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gratitude",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263285822160244737",
    "text" : "Police have reported ZERO looting or crimes of opportunity in Newark. And ceaseless reports of acts of kindness abound everywhere #Gratitude",
    "id" : 263285822160244737,
    "created_at" : "2012-10-30 14:26:46 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 263343658370211842,
  "created_at" : "2012-10-30 18:16:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "govchristie",
      "indices" : [ 15, 27 ]
    }, {
      "text" : "sandy",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263335432224403457",
  "text" : "wasnt a fan of #govchristie but respect for the man how he's handling #sandy",
  "id" : 263335432224403457,
  "created_at" : "2012-10-30 17:43:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Christie",
      "screen_name" : "GovChristie",
      "indices" : [ 3, 15 ],
      "id_str" : "90484508",
      "id" : 90484508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263335021333594112",
  "text" : "RT @GovChristie: I don't give a damn about Election Day after what has happened here. I am worried about the people of New Jersey. #Sandy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263293161818955776",
    "text" : "I don't give a damn about Election Day after what has happened here. I am worried about the people of New Jersey. #Sandy",
    "id" : 263293161818955776,
    "created_at" : "2012-10-30 14:55:56 +0000",
    "user" : {
      "name" : "Governor Christie",
      "screen_name" : "GovChristie",
      "protected" : false,
      "id_str" : "90484508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646777986528645120\/TRMcntto_normal.jpg",
      "id" : 90484508,
      "verified" : true
    }
  },
  "id" : 263335021333594112,
  "created_at" : "2012-10-30 17:42:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263301848868454401",
  "geo" : { },
  "id_str" : "263302862656917504",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ohhhh.. ((hugs))",
  "id" : 263302862656917504,
  "in_reply_to_status_id" : 263301848868454401,
  "created_at" : "2012-10-30 15:34:29 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi L",
      "screen_name" : "MzMerica",
      "indices" : [ 3, 12 ],
      "id_str" : "36707981",
      "id" : 36707981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263277825036005376",
  "text" : "RT @MzMerica: @silvermaneman My brother works for MTA and is on 35 hours+ straight so far. #Heroes #MTA #sandy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/WebObjects\/MZStore.woa\/wa\/viewSoftware?id=365306093&mt=8\" rel=\"nofollow\"\u003EApp with no name\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Heroes",
        "indices" : [ 77, 84 ]
      }, {
        "text" : "MTA",
        "indices" : [ 85, 89 ]
      }, {
        "text" : "sandy",
        "indices" : [ 90, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263263810377371650",
    "text" : "@silvermaneman My brother works for MTA and is on 35 hours+ straight so far. #Heroes #MTA #sandy",
    "id" : 263263810377371650,
    "created_at" : "2012-10-30 12:59:18 +0000",
    "user" : {
      "name" : "Mandi L",
      "screen_name" : "MzMerica",
      "protected" : false,
      "id_str" : "36707981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770254503048347648\/DYGexQ_c_normal.jpg",
      "id" : 36707981,
      "verified" : false
    }
  },
  "id" : 263277825036005376,
  "created_at" : "2012-10-30 13:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "indices" : [ 3, 18 ],
      "id_str" : "24165761",
      "id" : 24165761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263277522110795777",
  "text" : "RT @MichaelSkolnik: nurses are manually using ventilators on patients at NYU hospital...taking them down 9 flights of stairs for emergen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263111364594253824",
    "text" : "nurses are manually using ventilators on patients at NYU hospital...taking them down 9 flights of stairs for emergency evacuation. #Sandy",
    "id" : 263111364594253824,
    "created_at" : "2012-10-30 02:53:32 +0000",
    "user" : {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "protected" : false,
      "id_str" : "24165761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738364600220045313\/L-103cVr_normal.jpg",
      "id" : 24165761,
      "verified" : true
    }
  },
  "id" : 263277522110795777,
  "created_at" : "2012-10-30 13:53:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sandy",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263275829864304640",
  "text" : "amazing.. we did not lose electric. seeing the pics of NYC is heartbreaking. #sandy",
  "id" : 263275829864304640,
  "created_at" : "2012-10-30 13:47:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263021552587657218",
  "geo" : { },
  "id_str" : "263053029870297090",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous im sorry : (",
  "id" : 263053029870297090,
  "in_reply_to_status_id" : 263021552587657218,
  "created_at" : "2012-10-29 23:01:44 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263039162603692032",
  "geo" : { },
  "id_str" : "263041421395775488",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth hehe.. im not very sturdy.. not a lot of endurance.. so.. yeah.. lol",
  "id" : 263041421395775488,
  "in_reply_to_status_id" : 263039162603692032,
  "created_at" : "2012-10-29 22:15:36 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263034857058349056",
  "geo" : { },
  "id_str" : "263036721711689728",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth someone needs a (((hug))) : )",
  "id" : 263036721711689728,
  "in_reply_to_status_id" : 263034857058349056,
  "created_at" : "2012-10-29 21:56:56 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263028016995790848",
  "geo" : { },
  "id_str" : "263029242776915968",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth gee, wonder who you're voting for? lol ; )",
  "id" : 263029242776915968,
  "in_reply_to_status_id" : 263028016995790848,
  "created_at" : "2012-10-29 21:27:12 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shay",
      "screen_name" : "cherokee_autumn",
      "indices" : [ 3, 19 ],
      "id_str" : "52973326",
      "id" : 52973326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263009331920924673",
  "text" : "RT @cherokee_autumn: Those weather controlling gays are getting out of hand, aren't they? ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263008678255394817",
    "text" : "Those weather controlling gays are getting out of hand, aren't they? ;)",
    "id" : 263008678255394817,
    "created_at" : "2012-10-29 20:05:30 +0000",
    "user" : {
      "name" : "Shay",
      "screen_name" : "cherokee_autumn",
      "protected" : false,
      "id_str" : "52973326",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792186836776914944\/5sJOE18T_normal.jpg",
      "id" : 52973326,
      "verified" : false
    }
  },
  "id" : 263009331920924673,
  "created_at" : "2012-10-29 20:08:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/5Zr7AH3w",
      "expanded_url" : "http:\/\/huff.to\/SlgJdH",
      "display_url" : "huff.to\/SlgJdH"
    } ]
  },
  "geo" : { },
  "id_str" : "262997092992176128",
  "text" : "Only Love Can Heal Our Prison Problem http:\/\/t.co\/5Zr7AH3w by Ted Dekker",
  "id" : 262997092992176128,
  "created_at" : "2012-10-29 19:19:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262980245974548480",
  "geo" : { },
  "id_str" : "262985946360844288",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh no... ((hugs))",
  "id" : 262985946360844288,
  "in_reply_to_status_id" : 262980245974548480,
  "created_at" : "2012-10-29 18:35:10 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Thrasher",
      "screen_name" : "jthrasher",
      "indices" : [ 3, 13 ],
      "id_str" : "14482155",
      "id" : 14482155
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jthrasher\/status\/262967596989702144\/photo\/1",
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/4W0GoHXc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6Y_ot5CYAExHoF.jpg",
      "id_str" : "262967596993896449",
      "id" : 262967596993896449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6Y_ot5CYAExHoF.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/4W0GoHXc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262978314841493504",
  "text" : "RT @jthrasher: NYC Statue of Liberty getting slammed!! http:\/\/t.co\/4W0GoHXc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jthrasher\/status\/262967596989702144\/photo\/1",
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/4W0GoHXc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6Y_ot5CYAExHoF.jpg",
        "id_str" : "262967596993896449",
        "id" : 262967596993896449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6Y_ot5CYAExHoF.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/4W0GoHXc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262967596989702144",
    "text" : "NYC Statue of Liberty getting slammed!! http:\/\/t.co\/4W0GoHXc",
    "id" : 262967596989702144,
    "created_at" : "2012-10-29 17:22:15 +0000",
    "user" : {
      "name" : "John Thrasher",
      "screen_name" : "jthrasher",
      "protected" : false,
      "id_str" : "14482155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752367377262804992\/Kae1Soru_normal.jpg",
      "id" : 14482155,
      "verified" : true
    }
  },
  "id" : 262978314841493504,
  "created_at" : "2012-10-29 18:04:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/sm9ciTqA",
      "expanded_url" : "http:\/\/shar.es\/ci6EL",
      "display_url" : "shar.es\/ci6EL"
    } ]
  },
  "geo" : { },
  "id_str" : "262977603114246144",
  "text" : "saving moose from swingset - Very Brave Park Ranger! http:\/\/t.co\/sm9ciTqA",
  "id" : 262977603114246144,
  "created_at" : "2012-10-29 18:02:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262969406710247424",
  "text" : "RT @neiltyson: Think Sandy's big? Jupiter's GreatRedSpot is a 400yr raging storm that could fit several entire Earths within it. Just saying",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262966637202907136",
    "text" : "Think Sandy's big? Jupiter's GreatRedSpot is a 400yr raging storm that could fit several entire Earths within it. Just saying",
    "id" : 262966637202907136,
    "created_at" : "2012-10-29 17:18:26 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 262969406710247424,
  "created_at" : "2012-10-29 17:29:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InTime",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262951252055437314",
  "text" : "in that movie, each area of country had specific class of people. you needed credits to pass borders. #InTime",
  "id" : 262951252055437314,
  "created_at" : "2012-10-29 16:17:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mittsworld",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/cxfG1jjZ",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/In_Time",
      "display_url" : "en.wikipedia.org\/wiki\/In_Time"
    } ]
  },
  "geo" : { },
  "id_str" : "262950617314631682",
  "text" : "the movie \"In Time\" #mittsworld http:\/\/t.co\/cxfG1jjZ",
  "id" : 262950617314631682,
  "created_at" : "2012-10-29 16:14:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Gunter",
      "screen_name" : "DrJenGunter",
      "indices" : [ 3, 15 ],
      "id_str" : "25728193",
      "id" : 25728193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/KtZnGeZ5",
      "expanded_url" : "http:\/\/shar.es\/czekl",
      "display_url" : "shar.es\/czekl"
    } ]
  },
  "geo" : { },
  "id_str" : "262949572677099520",
  "text" : "RT @DrJenGunter: Raped by My Stepfather: A Survivor of Illegal Abortion On Why Safe, Legal Abortion is Essential http:\/\/t.co\/KtZnGeZ5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/KtZnGeZ5",
        "expanded_url" : "http:\/\/shar.es\/czekl",
        "display_url" : "shar.es\/czekl"
      } ]
    },
    "geo" : { },
    "id_str" : "262907531964329987",
    "text" : "Raped by My Stepfather: A Survivor of Illegal Abortion On Why Safe, Legal Abortion is Essential http:\/\/t.co\/KtZnGeZ5",
    "id" : 262907531964329987,
    "created_at" : "2012-10-29 13:23:34 +0000",
    "user" : {
      "name" : "Jennifer Gunter",
      "screen_name" : "DrJenGunter",
      "protected" : false,
      "id_str" : "25728193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796420677280481280\/pcr2NZ_i_normal.jpg",
      "id" : 25728193,
      "verified" : false
    }
  },
  "id" : 262949572677099520,
  "created_at" : "2012-10-29 16:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Hughes",
      "screen_name" : "peterhguk",
      "indices" : [ 3, 13 ],
      "id_str" : "573955594",
      "id" : 573955594
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/peterhguk\/status\/262927722681090048\/photo\/1",
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/SHAUSde3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6YbXuiCQAAmCKu.jpg",
      "id_str" : "262927722689478656",
      "id" : 262927722689478656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6YbXuiCQAAmCKu.jpg",
      "sizes" : [ {
        "h" : 807,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 714
      } ],
      "display_url" : "pic.twitter.com\/SHAUSde3"
    } ],
    "hashtags" : [ {
      "text" : "PetesPics",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262938824886341633",
  "text" : "RT @peterhguk: Field Mouse on Blackberries #PetesPics http:\/\/t.co\/SHAUSde3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/peterhguk\/status\/262927722681090048\/photo\/1",
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/SHAUSde3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6YbXuiCQAAmCKu.jpg",
        "id_str" : "262927722689478656",
        "id" : 262927722689478656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6YbXuiCQAAmCKu.jpg",
        "sizes" : [ {
          "h" : 807,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 714
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 714
        } ],
        "display_url" : "pic.twitter.com\/SHAUSde3"
      } ],
      "hashtags" : [ {
        "text" : "PetesPics",
        "indices" : [ 28, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262927722681090048",
    "text" : "Field Mouse on Blackberries #PetesPics http:\/\/t.co\/SHAUSde3",
    "id" : 262927722681090048,
    "created_at" : "2012-10-29 14:43:49 +0000",
    "user" : {
      "name" : "Peter Hughes",
      "screen_name" : "peterhguk",
      "protected" : false,
      "id_str" : "573955594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2203036565\/IMG_0769_Square2_normal.jpg",
      "id" : 573955594,
      "verified" : false
    }
  },
  "id" : 262938824886341633,
  "created_at" : "2012-10-29 15:27:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma White",
      "screen_name" : "TheRealSupermum",
      "indices" : [ 3, 19 ],
      "id_str" : "254781401",
      "id" : 254781401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262718375074070528",
  "text" : "RT @TheRealSupermum: If you feel like nothing is going right... Go left. :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262599610562928640",
    "text" : "If you feel like nothing is going right... Go left. :)",
    "id" : 262599610562928640,
    "created_at" : "2012-10-28 17:00:00 +0000",
    "user" : {
      "name" : "Emma White",
      "screen_name" : "TheRealSupermum",
      "protected" : false,
      "id_str" : "254781401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653490744687243264\/I7UirP7N_normal.jpg",
      "id" : 254781401,
      "verified" : false
    }
  },
  "id" : 262718375074070528,
  "created_at" : "2012-10-29 00:51:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phineas",
      "screen_name" : "PhineastheShiba",
      "indices" : [ 3, 19 ],
      "id_str" : "97585336",
      "id" : 97585336
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PhineastheShiba\/status\/262702709545766912\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/Ooqo5XxM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6VOuPSCEAAC6PI.jpg",
      "id_str" : "262702709554155520",
      "id" : 262702709554155520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6VOuPSCEAAC6PI.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com\/Ooqo5XxM"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262704191770861568",
  "text" : "RT @PhineastheShiba: I am ready for you #Sandy. I have my Search &amp; Rescue gear. http:\/\/t.co\/Ooqo5XxM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PhineastheShiba\/status\/262702709545766912\/photo\/1",
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/Ooqo5XxM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6VOuPSCEAAC6PI.jpg",
        "id_str" : "262702709554155520",
        "id" : 262702709554155520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6VOuPSCEAAC6PI.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 568
        } ],
        "display_url" : "pic.twitter.com\/Ooqo5XxM"
      } ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 19, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262702709545766912",
    "text" : "I am ready for you #Sandy. I have my Search &amp; Rescue gear. http:\/\/t.co\/Ooqo5XxM",
    "id" : 262702709545766912,
    "created_at" : "2012-10-28 23:49:41 +0000",
    "user" : {
      "name" : "Phineas",
      "screen_name" : "PhineastheShiba",
      "protected" : false,
      "id_str" : "97585336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2967991829\/8bba92fadf8ab29bbe65bec0fc05ad1a_normal.jpeg",
      "id" : 97585336,
      "verified" : false
    }
  },
  "id" : 262704191770861568,
  "created_at" : "2012-10-28 23:55:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262688216539344896",
  "text" : "RT @Seeds4Parents: When I despair, I remember that all through history the way of truth and love have always won. Gandhi, http:\/\/t.co\/Sh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/Sh0RVFnm",
        "expanded_url" : "http:\/\/tinyurl.com\/8rb8yq4",
        "display_url" : "tinyurl.com\/8rb8yq4"
      } ]
    },
    "geo" : { },
    "id_str" : "262669387155263488",
    "text" : "When I despair, I remember that all through history the way of truth and love have always won. Gandhi, http:\/\/t.co\/Sh0RVFnm",
    "id" : 262669387155263488,
    "created_at" : "2012-10-28 21:37:16 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 262688216539344896,
  "created_at" : "2012-10-28 22:52:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262683191322767360",
  "geo" : { },
  "id_str" : "262686007055495169",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker LOL",
  "id" : 262686007055495169,
  "in_reply_to_status_id" : 262683191322767360,
  "created_at" : "2012-10-28 22:43:19 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262684730246434816",
  "geo" : { },
  "id_str" : "262685675676119040",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker Canada is always so kind to us... : )",
  "id" : 262685675676119040,
  "in_reply_to_status_id" : 262684730246434816,
  "created_at" : "2012-10-28 22:42:00 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Izikio",
      "screen_name" : "zakaraya",
      "indices" : [ 0, 9 ],
      "id_str" : "24639845",
      "id" : 24639845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262640640549064705",
  "geo" : { },
  "id_str" : "262642638598057984",
  "in_reply_to_user_id" : 24639845,
  "text" : "@zakaraya looks like Chartreux (blue cat w gold eyes)",
  "id" : 262642638598057984,
  "in_reply_to_status_id" : 262640640549064705,
  "created_at" : "2012-10-28 19:50:59 +0000",
  "in_reply_to_screen_name" : "zakaraya",
  "in_reply_to_user_id_str" : "24639845",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/fFB6go7b",
      "expanded_url" : "http:\/\/thkpr.gs\/m6Wbo5",
      "display_url" : "thkpr.gs\/m6Wbo5"
    } ]
  },
  "geo" : { },
  "id_str" : "262635682848202753",
  "text" : "send to States(they hv more $$?)&gt;&gt;Mitt Romney: Federal Disaster Relief Is Immoral http:\/\/t.co\/fFB6go7b",
  "id" : 262635682848202753,
  "created_at" : "2012-10-28 19:23:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "Alexander Higgins",
      "screen_name" : "kr3at",
      "indices" : [ 18, 24 ],
      "id_str" : "139283160",
      "id" : 139283160
    }, {
      "name" : "Alexander Higgins",
      "screen_name" : "kr3at",
      "indices" : [ 118, 124 ],
      "id_str" : "139283160",
      "id" : 139283160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/gIKxTlGm",
      "expanded_url" : "http:\/\/bit.ly\/PZQIC4",
      "display_url" : "bit.ly\/PZQIC4"
    } ]
  },
  "geo" : { },
  "id_str" : "262619055280766976",
  "text" : "RT @Jamiastar: RT @kr3at: Have Voting Machines Already Made their Choice for Prez? (video) http:\/\/t.co\/gIKxTlGm\u00A0\n via @kr3at headlines",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexander Higgins",
        "screen_name" : "kr3at",
        "indices" : [ 3, 9 ],
        "id_str" : "139283160",
        "id" : 139283160
      }, {
        "name" : "Alexander Higgins",
        "screen_name" : "kr3at",
        "indices" : [ 103, 109 ],
        "id_str" : "139283160",
        "id" : 139283160
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/gIKxTlGm",
        "expanded_url" : "http:\/\/bit.ly\/PZQIC4",
        "display_url" : "bit.ly\/PZQIC4"
      } ]
    },
    "geo" : { },
    "id_str" : "262617061312831489",
    "text" : "RT @kr3at: Have Voting Machines Already Made their Choice for Prez? (video) http:\/\/t.co\/gIKxTlGm\u00A0\n via @kr3at headlines",
    "id" : 262617061312831489,
    "created_at" : "2012-10-28 18:09:21 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 262619055280766976,
  "created_at" : "2012-10-28 18:17:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/3DWQbLKg",
      "expanded_url" : "http:\/\/cheezburger.com\/43683073",
      "display_url" : "cheezburger.com\/43683073"
    } ]
  },
  "geo" : { },
  "id_str" : "262616678284808192",
  "text" : "RT @grouchypuppy: Senior dogs are smart! Watch this one \"fetch\" We approve :0)  http:\/\/t.co\/3DWQbLKg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/3DWQbLKg",
        "expanded_url" : "http:\/\/cheezburger.com\/43683073",
        "display_url" : "cheezburger.com\/43683073"
      } ]
    },
    "geo" : { },
    "id_str" : "262616172552388608",
    "text" : "Senior dogs are smart! Watch this one \"fetch\" We approve :0)  http:\/\/t.co\/3DWQbLKg",
    "id" : 262616172552388608,
    "created_at" : "2012-10-28 18:05:49 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 262616678284808192,
  "created_at" : "2012-10-28 18:07:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262615543784280064",
  "text" : "all he does is work. his weekends are often ruined or interrupted. his weekdays are long and stressful. it was not supposed to be like this.",
  "id" : 262615543784280064,
  "created_at" : "2012-10-28 18:03:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262615197758406656",
  "text" : "hubby's missing out on football game due to chris christie's hurricane update : (",
  "id" : 262615197758406656,
  "created_at" : "2012-10-28 18:01:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "middleagedandmenopausal",
      "indices" : [ 29, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262614832333864960",
  "text" : "my hormones are in an uproar #middleagedandmenopausal",
  "id" : 262614832333864960,
  "created_at" : "2012-10-28 18:00:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262613893380202497",
  "text" : "all this 2012 stuff is making me itch and break out...",
  "id" : 262613893380202497,
  "created_at" : "2012-10-28 17:56:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262604256513757184",
  "text" : "RT @RichardWiseman: Trying to arrange for everyone along east coast to aim their hair dryers out to sea and set on max. Together we can  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262603493251117056",
    "text" : "Trying to arrange for everyone along east coast to aim their hair dryers out to sea and set on max. Together we can do this.",
    "id" : 262603493251117056,
    "created_at" : "2012-10-28 17:15:26 +0000",
    "user" : {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "protected" : false,
      "id_str" : "19512493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3225534671\/ef59c3b397d28dacb74034b47d8cd9e2_normal.jpeg",
      "id" : 19512493,
      "verified" : true
    }
  },
  "id" : 262604256513757184,
  "created_at" : "2012-10-28 17:18:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262592438210809856",
  "text" : "im not better off than i was 25 years ago...",
  "id" : 262592438210809856,
  "created_at" : "2012-10-28 16:31:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 3, 14 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262357135986413568",
  "text" : "RT @ggreenwald: For the collective mental health of the nation, this election needs to be over as soon as possible.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262327849065775104",
    "text" : "For the collective mental health of the nation, this election needs to be over as soon as possible.",
    "id" : 262327849065775104,
    "created_at" : "2012-10-27 23:00:07 +0000",
    "user" : {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "protected" : false,
      "id_str" : "16076032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659383028771364869\/G9HHnjiI_normal.jpg",
      "id" : 16076032,
      "verified" : true
    }
  },
  "id" : 262357135986413568,
  "created_at" : "2012-10-28 00:56:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262346564503228416",
  "text" : "@1stCitizenKane LOL .. THIS!",
  "id" : 262346564503228416,
  "created_at" : "2012-10-28 00:14:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262339975264231425",
  "text" : "Jump aboard the L\u2665VE TRAIN!",
  "id" : 262339975264231425,
  "created_at" : "2012-10-27 23:48:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262337183480946688",
  "geo" : { },
  "id_str" : "262338982535389184",
  "in_reply_to_user_id" : 140291463,
  "text" : "@SkypilotOfHope oh precious! : )",
  "id" : 262338982535389184,
  "in_reply_to_status_id" : 262337183480946688,
  "created_at" : "2012-10-27 23:44:22 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262335157221085184",
  "text" : "RT @Buddhaworld: Its all about freedom from delusion.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262333942554849280",
    "text" : "Its all about freedom from delusion.",
    "id" : 262333942554849280,
    "created_at" : "2012-10-27 23:24:20 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 262335157221085184,
  "created_at" : "2012-10-27 23:29:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NRDC",
      "screen_name" : "NRDC",
      "indices" : [ 3, 8 ],
      "id_str" : "18713552",
      "id" : 18713552
    }, {
      "name" : "\u0413\u0435\u043D\u0430 \u041A\u043E\u043D\u043E\u0432\u0430\u043B\u043E\u0432",
      "screen_name" : "nrdcbiogems",
      "indices" : [ 13, 25 ],
      "id_str" : "2885746833",
      "id" : 2885746833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sweden",
      "indices" : [ 27, 34 ]
    }, {
      "text" : "energy",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262332412304973824",
  "text" : "RT @NRDC: RT @NRDCBioGems: #Sweden has started to IMPORT other countries' trash because it has turned all it's got into #energy: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0413\u0435\u043D\u0430 \u041A\u043E\u043D\u043E\u0432\u0430\u043B\u043E\u0432",
        "screen_name" : "nrdcbiogems",
        "indices" : [ 3, 15 ],
        "id_str" : "2885746833",
        "id" : 2885746833
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sweden",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "energy",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/0yMRssuz",
        "expanded_url" : "http:\/\/j.mp\/SfFk4v",
        "display_url" : "j.mp\/SfFk4v"
      } ]
    },
    "geo" : { },
    "id_str" : "262319540912930817",
    "text" : "RT @NRDCBioGems: #Sweden has started to IMPORT other countries' trash because it has turned all it's got into #energy: http:\/\/t.co\/0yMRssuz",
    "id" : 262319540912930817,
    "created_at" : "2012-10-27 22:27:06 +0000",
    "user" : {
      "name" : "NRDC",
      "screen_name" : "NRDC",
      "protected" : false,
      "id_str" : "18713552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794273578644635649\/f3KN7xeK_normal.jpg",
      "id" : 18713552,
      "verified" : true
    }
  },
  "id" : 262332412304973824,
  "created_at" : "2012-10-27 23:18:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262317614662041600",
  "geo" : { },
  "id_str" : "262319497334116352",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep LOLOL",
  "id" : 262319497334116352,
  "in_reply_to_status_id" : 262317614662041600,
  "created_at" : "2012-10-27 22:26:56 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262310988328611840",
  "text" : "RT @Jamiastar: The $1.5 trillion proposed for F-35 warplane is enough to put a solar array on every home and fund 43 million $27,000 ele ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262308516444901377",
    "text" : "The $1.5 trillion proposed for F-35 warplane is enough to put a solar array on every home and fund 43 million $27,000 electric car vouchers",
    "id" : 262308516444901377,
    "created_at" : "2012-10-27 21:43:18 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 262310988328611840,
  "created_at" : "2012-10-27 21:53:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Light",
      "indices" : [ 17, 23 ]
    }, {
      "text" : "photo",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "nature",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/56uBHGQX",
      "expanded_url" : "http:\/\/bit.ly\/XwiRRY",
      "display_url" : "bit.ly\/XwiRRY"
    } ]
  },
  "geo" : { },
  "id_str" : "262310917323255808",
  "text" : "RT @MartinBelan: #Light at the end of the Path http:\/\/t.co\/56uBHGQX #photo #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Light",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "photo",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "nature",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http:\/\/t.co\/56uBHGQX",
        "expanded_url" : "http:\/\/bit.ly\/XwiRRY",
        "display_url" : "bit.ly\/XwiRRY"
      } ]
    },
    "geo" : { },
    "id_str" : "262308695415861249",
    "text" : "#Light at the end of the Path http:\/\/t.co\/56uBHGQX #photo #nature",
    "id" : 262308695415861249,
    "created_at" : "2012-10-27 21:44:01 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 262310917323255808,
  "created_at" : "2012-10-27 21:52:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262279162469949441",
  "geo" : { },
  "id_str" : "262280414884950017",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker LOL : )",
  "id" : 262280414884950017,
  "in_reply_to_status_id" : 262279162469949441,
  "created_at" : "2012-10-27 19:51:38 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262279280011116544",
  "text" : "RT @LSFProgram: Don't compare your life to others. You have no idea what their journey is all about.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262278795904565248",
    "text" : "Don't compare your life to others. You have no idea what their journey is all about.",
    "id" : 262278795904565248,
    "created_at" : "2012-10-27 19:45:12 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 262279280011116544,
  "created_at" : "2012-10-27 19:47:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 2, 17 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262276878243602432",
  "text" : ". @1stCitizenKane does this mean The End is soon.. cuz im getting tired...",
  "id" : 262276878243602432,
  "created_at" : "2012-10-27 19:37:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262271583601717248",
  "text" : "RT @SenSanders: Spending from outside groups in the 2012 election has now exceeded that of the 2010, 2008 and 2006 elections combined. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/kt6aYQwI",
        "expanded_url" : "http:\/\/www.opensecrets.org\/outsidespending\/cycle_tots.php?cycle=2012&view=A&chart=N#viewpt",
        "display_url" : "opensecrets.org\/outsidespendin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "262271347919572992",
    "text" : "Spending from outside groups in the 2012 election has now exceeded that of the 2010, 2008 and 2006 elections combined. http:\/\/t.co\/kt6aYQwI",
    "id" : 262271347919572992,
    "created_at" : "2012-10-27 19:15:36 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 262271583601717248,
  "created_at" : "2012-10-27 19:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Shabbir",
      "screen_name" : "shabzcohelp",
      "indices" : [ 52, 64 ],
      "id_str" : "19052397",
      "id" : 19052397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262263302074269696",
  "geo" : { },
  "id_str" : "262266221783810048",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray huh.. well I still dont like him..lol @shabzcohelp",
  "id" : 262266221783810048,
  "in_reply_to_status_id" : 262263302074269696,
  "created_at" : "2012-10-27 18:55:14 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262259855916687360",
  "text" : "we are on the precipice facing the most daunting challenge asked of humanity.. can we do it?",
  "id" : 262259855916687360,
  "created_at" : "2012-10-27 18:29:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262259579868549120",
  "text" : "we are all under pressure.. as a society.. as humanity. only love will save us now.",
  "id" : 262259579868549120,
  "created_at" : "2012-10-27 18:28:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262259304059514880",
  "text" : "RT @DeepakChopra: Spaceship earth is about to crash. Global crew is needed for course correction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262259054913679360",
    "text" : "Spaceship earth is about to crash. Global crew is needed for course correction",
    "id" : 262259054913679360,
    "created_at" : "2012-10-27 18:26:45 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 262259304059514880,
  "created_at" : "2012-10-27 18:27:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262257950402441216",
  "text" : "RT @DeepakChopra: When insanity &amp; collective psychosis become the norm humanity is risking collective suicide. Only a collective awa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262257661188399104",
    "text" : "When insanity &amp; collective psychosis become the norm humanity is risking collective suicide. Only a collective awakening can restore life",
    "id" : 262257661188399104,
    "created_at" : "2012-10-27 18:21:13 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 262257950402441216,
  "created_at" : "2012-10-27 18:22:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262257646164398083",
  "text" : "RT @DeepakChopra: Let us use these social networks to go beyond tribal identities &amp; become global citizens",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262256230427398145",
    "text" : "Let us use these social networks to go beyond tribal identities &amp; become global citizens",
    "id" : 262256230427398145,
    "created_at" : "2012-10-27 18:15:32 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 262257646164398083,
  "created_at" : "2012-10-27 18:21:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shabbir",
      "screen_name" : "shabzcohelp",
      "indices" : [ 3, 15 ],
      "id_str" : "19052397",
      "id" : 19052397
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 33, 45 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262257433433489408",
  "text" : "RT @shabzcohelp: Mitt Romney vs. @BarackObama via @EatPastha http:\/\/t.co\/ZgvzjkqV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 16, 28 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/ZgvzjkqV",
        "expanded_url" : "http:\/\/img.ly\/oZIu",
        "display_url" : "img.ly\/oZIu"
      } ]
    },
    "geo" : { },
    "id_str" : "262253132510281728",
    "text" : "Mitt Romney vs. @BarackObama via @EatPastha http:\/\/t.co\/ZgvzjkqV",
    "id" : 262253132510281728,
    "created_at" : "2012-10-27 18:03:13 +0000",
    "user" : {
      "name" : "Shabbir",
      "screen_name" : "shabzcohelp",
      "protected" : false,
      "id_str" : "19052397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704802233276194816\/R2Wg52yI_normal.jpg",
      "id" : 19052397,
      "verified" : false
    }
  },
  "id" : 262257433433489408,
  "created_at" : "2012-10-27 18:20:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shabbir",
      "screen_name" : "shabzcohelp",
      "indices" : [ 2, 14 ],
      "id_str" : "19052397",
      "id" : 19052397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262253132510281728",
  "geo" : { },
  "id_str" : "262256638499639296",
  "in_reply_to_user_id" : 19052397,
  "text" : ". @shabzcohelp hehe.. yup.. excellent analogy!",
  "id" : 262256638499639296,
  "in_reply_to_status_id" : 262253132510281728,
  "created_at" : "2012-10-27 18:17:09 +0000",
  "in_reply_to_screen_name" : "shabzcohelp",
  "in_reply_to_user_id_str" : "19052397",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262255607267094528",
  "text" : "\"And love dares you to care for\nThe people on the edge of the night\" - Under Pressure",
  "id" : 262255607267094528,
  "created_at" : "2012-10-27 18:13:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262234501323829248",
  "text" : "i dont like all those crazy fair rides.. why the hell would i sign up for 2012? better be damn good prize waiting for me..lol",
  "id" : 262234501323829248,
  "created_at" : "2012-10-27 16:49:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262232857441865730",
  "geo" : { },
  "id_str" : "262233222031761408",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin sounds like a lot of work... ugh.",
  "id" : 262233222031761408,
  "in_reply_to_status_id" : 262232857441865730,
  "created_at" : "2012-10-27 16:44:06 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262232898281816064",
  "text" : "@ThePlushGourmet wow.. cool : )",
  "id" : 262232898281816064,
  "created_at" : "2012-10-27 16:42:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262226949961818113",
  "text" : "now more than ever, need to focus on the light. its my job. who knew it would be this difficult!",
  "id" : 262226949961818113,
  "created_at" : "2012-10-27 16:19:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262226194852888577",
  "text" : "hubby's annoying me w leaf blower and im still drinking bad coffee...",
  "id" : 262226194852888577,
  "created_at" : "2012-10-27 16:16:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262225676864745472",
  "text" : "@iEyeAyes hmm.. maybe thats the point. need to start anew?",
  "id" : 262225676864745472,
  "created_at" : "2012-10-27 16:14:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nickole Rinde",
      "screen_name" : "dragonweasle",
      "indices" : [ 3, 16 ],
      "id_str" : "24480551",
      "id" : 24480551
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dragonweasle\/status\/262220363449106432\/photo\/1",
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/POBaKtlz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6OYCADCAAAlY69.jpg",
      "id_str" : "262220363457495040",
      "id" : 262220363457495040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6OYCADCAAAlY69.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/POBaKtlz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262223014958100480",
  "text" : "RT @dragonweasle: So much for reading lol http:\/\/t.co\/POBaKtlz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dragonweasle\/status\/262220363449106432\/photo\/1",
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/POBaKtlz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6OYCADCAAAlY69.jpg",
        "id_str" : "262220363457495040",
        "id" : 262220363457495040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6OYCADCAAAlY69.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/POBaKtlz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262220363449106432",
    "text" : "So much for reading lol http:\/\/t.co\/POBaKtlz",
    "id" : 262220363449106432,
    "created_at" : "2012-10-27 15:53:01 +0000",
    "user" : {
      "name" : "Nickole Rinde",
      "screen_name" : "dragonweasle",
      "protected" : false,
      "id_str" : "24480551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601760399050969089\/T_ldOFVo_normal.jpg",
      "id" : 24480551,
      "verified" : false
    }
  },
  "id" : 262223014958100480,
  "created_at" : "2012-10-27 16:03:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "indices" : [ 3, 18 ],
      "id_str" : "17376893",
      "id" : 17376893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262222901044973570",
  "text" : "RT @RightWingWatch: Without a hint of irony, Glenn Beck says anyone who is willing to openly lie must have \"deep psychological problems\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/9iAacakt",
        "expanded_url" : "http:\/\/bit.ly\/Se3GeO",
        "display_url" : "bit.ly\/Se3GeO"
      } ]
    },
    "geo" : { },
    "id_str" : "261912128708030464",
    "text" : "Without a hint of irony, Glenn Beck says anyone who is willing to openly lie must have \"deep psychological problems\": http:\/\/t.co\/9iAacakt",
    "id" : 261912128708030464,
    "created_at" : "2012-10-26 19:28:12 +0000",
    "user" : {
      "name" : "Right Wing Watch",
      "screen_name" : "RightWingWatch",
      "protected" : false,
      "id_str" : "17376893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/64767765\/rww-twitter130_normal.jpg",
      "id" : 17376893,
      "verified" : false
    }
  },
  "id" : 262222901044973570,
  "created_at" : "2012-10-27 16:03:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262222318712004609",
  "text" : "@iEyeAyes oh, the koch brothers.. yeah, saw a doc on that recently. weird.",
  "id" : 262222318712004609,
  "created_at" : "2012-10-27 16:00:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262222037999824896",
  "text" : "@iEyeAyes did i miss something?",
  "id" : 262222037999824896,
  "created_at" : "2012-10-27 15:59:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262221343234330624",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses you're too funny..lol. enjoy yr trip. looks like storm will be up my way so you should be ok.",
  "id" : 262221343234330624,
  "created_at" : "2012-10-27 15:56:54 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ECHOisthename\u2122 \uD83C\uDDE9\uD83C\uDDF4",
      "screen_name" : "ECHOisthename",
      "indices" : [ 3, 17 ],
      "id_str" : "22086087",
      "id" : 22086087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262007646754852864",
  "text" : "RT @ECHOisthename: emotions are energy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261988832533151746",
    "text" : "emotions are energy.",
    "id" : 261988832533151746,
    "created_at" : "2012-10-27 00:32:59 +0000",
    "user" : {
      "name" : "ECHOisthename\u2122 \uD83C\uDDE9\uD83C\uDDF4",
      "screen_name" : "ECHOisthename",
      "protected" : false,
      "id_str" : "22086087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800125864574795776\/jbblt98a_normal.jpg",
      "id" : 22086087,
      "verified" : false
    }
  },
  "id" : 262007646754852864,
  "created_at" : "2012-10-27 01:47:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261990911649644544",
  "text" : "im not sure i'll survive elections.. so much tension in the air.",
  "id" : 261990911649644544,
  "created_at" : "2012-10-27 00:41:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261986076024000513",
  "text" : "i dunno WTH is wrong w stray.. yesterday I gave him food, he was fine.. then while eating he darted. today darts when i look at him. wacky!",
  "id" : 261986076024000513,
  "created_at" : "2012-10-27 00:22:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261971618639798273",
  "geo" : { },
  "id_str" : "261971844154941440",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker wow, what an awesome view!",
  "id" : 261971844154941440,
  "in_reply_to_status_id" : 261971618639798273,
  "created_at" : "2012-10-26 23:25:29 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261970746534944768",
  "geo" : { },
  "id_str" : "261971442751660032",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker cool beans! : )",
  "id" : 261971442751660032,
  "in_reply_to_status_id" : 261970746534944768,
  "created_at" : "2012-10-26 23:23:53 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261968862839463939",
  "geo" : { },
  "id_str" : "261969324670078976",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker ahh.. sounds interesting! ; )",
  "id" : 261969324670078976,
  "in_reply_to_status_id" : 261968862839463939,
  "created_at" : "2012-10-26 23:15:28 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Nation",
      "screen_name" : "thenation",
      "indices" : [ 3, 13 ],
      "id_str" : "1947301",
      "id" : 1947301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/1nFeteZa",
      "expanded_url" : "http:\/\/tnat.in\/eNviU",
      "display_url" : "tnat.in\/eNviU"
    } ]
  },
  "geo" : { },
  "id_str" : "261967875324116993",
  "text" : "RT @thenation: Paul Ryan wants us to believe that the \u201Cwar on poverty\u201D is what\u2019s causing poverty. Seriously. http:\/\/t.co\/1nFeteZa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/1nFeteZa",
        "expanded_url" : "http:\/\/tnat.in\/eNviU",
        "display_url" : "tnat.in\/eNviU"
      } ]
    },
    "geo" : { },
    "id_str" : "261965746475778048",
    "text" : "Paul Ryan wants us to believe that the \u201Cwar on poverty\u201D is what\u2019s causing poverty. Seriously. http:\/\/t.co\/1nFeteZa",
    "id" : 261965746475778048,
    "created_at" : "2012-10-26 23:01:15 +0000",
    "user" : {
      "name" : "The Nation",
      "screen_name" : "thenation",
      "protected" : false,
      "id_str" : "1947301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750809171080151040\/e0P0Yzbv_normal.jpg",
      "id" : 1947301,
      "verified" : true
    }
  },
  "id" : 261967875324116993,
  "created_at" : "2012-10-26 23:09:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261939331395104768",
  "geo" : { },
  "id_str" : "261940490784624640",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses lol.. cute!",
  "id" : 261940490784624640,
  "in_reply_to_status_id" : 261939331395104768,
  "created_at" : "2012-10-26 21:20:54 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261937724162994176",
  "text" : "RT @CharlesBivona: In the '80s, they said I'd have a flying car by the year 2000. In 2012, they say I should prepare to live without ele ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261937336236007424",
    "text" : "In the '80s, they said I'd have a flying car by the year 2000. In 2012, they say I should prepare to live without electricity for 7-10 days.",
    "id" : 261937336236007424,
    "created_at" : "2012-10-26 21:08:22 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 261937724162994176,
  "created_at" : "2012-10-26 21:09:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faith in Fiction",
      "screen_name" : "FictionFaith",
      "indices" : [ 0, 13 ],
      "id_str" : "494383730",
      "id" : 494383730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261936568682565633",
  "geo" : { },
  "id_str" : "261937108309114880",
  "in_reply_to_user_id" : 494383730,
  "text" : "@FictionFaith good to hear. cant blame her for being nervous, poor babe.",
  "id" : 261937108309114880,
  "in_reply_to_status_id" : 261936568682565633,
  "created_at" : "2012-10-26 21:07:27 +0000",
  "in_reply_to_screen_name" : "FictionFaith",
  "in_reply_to_user_id_str" : "494383730",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faith in Fiction",
      "screen_name" : "FictionFaith",
      "indices" : [ 0, 13 ],
      "id_str" : "494383730",
      "id" : 494383730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261935878342078465",
  "in_reply_to_user_id" : 494383730,
  "text" : "@FictionFaith how is your daughter doing?",
  "id" : 261935878342078465,
  "created_at" : "2012-10-26 21:02:34 +0000",
  "in_reply_to_screen_name" : "FictionFaith",
  "in_reply_to_user_id_str" : "494383730",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261928727036952576",
  "geo" : { },
  "id_str" : "261929916348641280",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep WOW!! lol",
  "id" : 261929916348641280,
  "in_reply_to_status_id" : 261928727036952576,
  "created_at" : "2012-10-26 20:38:53 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261926406466977792",
  "geo" : { },
  "id_str" : "261928248160706562",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep i think hubby finally realizes we do one store OR another. cant do multiple stops..lol. i cant be rushed : ) (coffee sounds good!)",
  "id" : 261928248160706562,
  "in_reply_to_status_id" : 261926406466977792,
  "created_at" : "2012-10-26 20:32:15 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261924549870899202",
  "geo" : { },
  "id_str" : "261925835966128128",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep used to love \"malling\" when younger but dont have endurance anymore...",
  "id" : 261925835966128128,
  "in_reply_to_status_id" : 261924549870899202,
  "created_at" : "2012-10-26 20:22:40 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/3kvE5cBc",
      "expanded_url" : "http:\/\/huff.to\/RPxvQi",
      "display_url" : "huff.to\/RPxvQi"
    } ]
  },
  "geo" : { },
  "id_str" : "261915829791236096",
  "text" : "RT @LaughingBaba: Romney: 'Some Gays Are Actually Having Children. It's Not Right on Paper. It's Not... http:\/\/t.co\/3kvE5cBc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-huffington-post\/id306621789?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Huffington Post on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/3kvE5cBc",
        "expanded_url" : "http:\/\/huff.to\/RPxvQi",
        "display_url" : "huff.to\/RPxvQi"
      } ]
    },
    "geo" : { },
    "id_str" : "261914589762039808",
    "text" : "Romney: 'Some Gays Are Actually Having Children. It's Not Right on Paper. It's Not... http:\/\/t.co\/3kvE5cBc",
    "id" : 261914589762039808,
    "created_at" : "2012-10-26 19:37:58 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 261915829791236096,
  "created_at" : "2012-10-26 19:42:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mychal Denzel Smith",
      "screen_name" : "mychalsmith",
      "indices" : [ 3, 15 ],
      "id_str" : "136417827",
      "id" : 136417827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261885814848491520",
  "text" : "RT @mychalsmith: How Mandatory Minimums Forced Me to Send More Than 1,000 Nonviolent Drug Offenders to Federal Prison  | The Nation http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/5fa8j1dc",
        "expanded_url" : "http:\/\/www.thenation.com\/article\/170815\/how-mandatory-minimums-forced-me-send-more-1000-nonviolent-drug-offenders-federal-pri",
        "display_url" : "thenation.com\/article\/170815\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261873314602037248",
    "text" : "How Mandatory Minimums Forced Me to Send More Than 1,000 Nonviolent Drug Offenders to Federal Prison  | The Nation http:\/\/t.co\/5fa8j1dc",
    "id" : 261873314602037248,
    "created_at" : "2012-10-26 16:53:58 +0000",
    "user" : {
      "name" : "Mychal Denzel Smith",
      "screen_name" : "mychalsmith",
      "protected" : false,
      "id_str" : "136417827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798954526950780928\/qeS67ioE_normal.jpg",
      "id" : 136417827,
      "verified" : false
    }
  },
  "id" : 261885814848491520,
  "created_at" : "2012-10-26 17:43:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "indices" : [ 3, 16 ],
      "id_str" : "43640071",
      "id" : 43640071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261856364622671873",
  "text" : "RT @LaughingBaba: Sending positive thoughts to this Twitter community!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261855339954180096",
    "text" : "Sending positive thoughts to this Twitter community!",
    "id" : 261855339954180096,
    "created_at" : "2012-10-26 15:42:32 +0000",
    "user" : {
      "name" : "Louis J. Guadagnino",
      "screen_name" : "LaughingBaba",
      "protected" : false,
      "id_str" : "43640071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2755811196\/a7f4abce83475191f574c5aba9f687ac_normal.jpeg",
      "id" : 43640071,
      "verified" : false
    }
  },
  "id" : 261856364622671873,
  "created_at" : "2012-10-26 15:46:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261854339520417792",
  "geo" : { },
  "id_str" : "261855956751761410",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth i'll keep an eye out for it.. interested in what he comes up with..lol",
  "id" : 261855956751761410,
  "in_reply_to_status_id" : 261854339520417792,
  "created_at" : "2012-10-26 15:44:59 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261854458068217857",
  "text" : "RT @TyrusBooks: Dear Video Ads Automatically Playing on Websites -- STOP IT! I HATE YOU! YOU WILL NEVER SELL ME ANYTHING, EVER!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261850734067322881",
    "text" : "Dear Video Ads Automatically Playing on Websites -- STOP IT! I HATE YOU! YOU WILL NEVER SELL ME ANYTHING, EVER!",
    "id" : 261850734067322881,
    "created_at" : "2012-10-26 15:24:14 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 261854458068217857,
  "created_at" : "2012-10-26 15:39:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261852065939197952",
  "geo" : { },
  "id_str" : "261854153674997761",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth wait.. what?",
  "id" : 261854153674997761,
  "in_reply_to_status_id" : 261852065939197952,
  "created_at" : "2012-10-26 15:37:49 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261835177389617152",
  "geo" : { },
  "id_str" : "261838878154039297",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible \"Doctrine over people? You betcha. Easy decision.\" wow.. Jesus was FOR the people. He was all about the people!",
  "id" : 261838878154039297,
  "in_reply_to_status_id" : 261835177389617152,
  "created_at" : "2012-10-26 14:37:07 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lyme",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/G1qwyet9",
      "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2012\/10\/121025174140.htm#.UIqas687tDI.twitter",
      "display_url" : "sciencedaily.com\/releases\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261833680534777857",
  "text" : "RT @DarciaHelle: Scientists step up hunt for bacterial genes tied to #lyme disease: http:\/\/t.co\/G1qwyet9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lyme",
        "indices" : [ 52, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/G1qwyet9",
        "expanded_url" : "http:\/\/www.sciencedaily.com\/releases\/2012\/10\/121025174140.htm#.UIqas687tDI.twitter",
        "display_url" : "sciencedaily.com\/releases\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261833191797710849",
    "text" : "Scientists step up hunt for bacterial genes tied to #lyme disease: http:\/\/t.co\/G1qwyet9",
    "id" : 261833191797710849,
    "created_at" : "2012-10-26 14:14:32 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 261833680534777857,
  "created_at" : "2012-10-26 14:16:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261831065356877825",
  "geo" : { },
  "id_str" : "261831520606638080",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses aww.. you're a good egg : ) #kindness",
  "id" : 261831520606638080,
  "in_reply_to_status_id" : 261831065356877825,
  "created_at" : "2012-10-26 14:07:53 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261830082363019264",
  "geo" : { },
  "id_str" : "261831225566703616",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ugh.. that's not right. if the kid would rather stay and read, one thing.. but becuz no dollar is wrong.",
  "id" : 261831225566703616,
  "in_reply_to_status_id" : 261830082363019264,
  "created_at" : "2012-10-26 14:06:43 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 3, 9 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/2hziqS1r",
      "expanded_url" : "http:\/\/m.dailykos.com\/story\/2012\/10\/09\/1142432\/-The-Reason-s-McCain-Chose-Palin-Over-Romney",
      "display_url" : "m.dailykos.com\/story\/2012\/10\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261827223198253058",
  "text" : "RT @sacca: Why didn't McCain choose Romney as his running mate? This leaked file has all the details: http:\/\/t.co\/2hziqS1r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/2hziqS1r",
        "expanded_url" : "http:\/\/m.dailykos.com\/story\/2012\/10\/09\/1142432\/-The-Reason-s-McCain-Chose-Palin-Over-Romney",
        "display_url" : "m.dailykos.com\/story\/2012\/10\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261822722240286720",
    "text" : "Why didn't McCain choose Romney as his running mate? This leaked file has all the details: http:\/\/t.co\/2hziqS1r",
    "id" : 261822722240286720,
    "created_at" : "2012-10-26 13:32:56 +0000",
    "user" : {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "protected" : false,
      "id_str" : "586",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668902554957316096\/IpjBGyjC_normal.jpg",
      "id" : 586,
      "verified" : true
    }
  },
  "id" : 261827223198253058,
  "created_at" : "2012-10-26 13:50:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "G and M Aldridge",
      "screen_name" : "Twitridge",
      "indices" : [ 22, 32 ],
      "id_str" : "21568162",
      "id" : 21568162
    }, {
      "name" : "getaclewis",
      "screen_name" : "getaclewis",
      "indices" : [ 45, 56 ],
      "id_str" : "16297250",
      "id" : 16297250
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/KO9oC4el",
      "expanded_url" : "http:\/\/instagr.am\/p\/RPdVrnujbJ\/",
      "display_url" : "instagr.am\/p\/RPdVrnujbJ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "261819451819823104",
  "text" : "RT @KerriFar: WOW! RT @twitridge: Lovely! RT @getaclewis Sunrise on Lookout Mountain http:\/\/t.co\/KO9oC4el",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "G and M Aldridge",
        "screen_name" : "Twitridge",
        "indices" : [ 8, 18 ],
        "id_str" : "21568162",
        "id" : 21568162
      }, {
        "name" : "getaclewis",
        "screen_name" : "getaclewis",
        "indices" : [ 31, 42 ],
        "id_str" : "16297250",
        "id" : 16297250
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/KO9oC4el",
        "expanded_url" : "http:\/\/instagr.am\/p\/RPdVrnujbJ\/",
        "display_url" : "instagr.am\/p\/RPdVrnujbJ\/"
      } ]
    },
    "geo" : { },
    "id_str" : "261816453303504896",
    "text" : "WOW! RT @twitridge: Lovely! RT @getaclewis Sunrise on Lookout Mountain http:\/\/t.co\/KO9oC4el",
    "id" : 261816453303504896,
    "created_at" : "2012-10-26 13:08:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 261819451819823104,
  "created_at" : "2012-10-26 13:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261814286224072704",
  "text" : "this coffee sucks. not worth getting up for...",
  "id" : 261814286224072704,
  "created_at" : "2012-10-26 12:59:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2Bits  Semi-Poet \u2629",
      "screen_name" : "1stCitizenKane",
      "indices" : [ 0, 15 ],
      "id_str" : "1071113395",
      "id" : 1071113395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261614325528158208",
  "text" : "@1stCitizenKane my thought as well (consciousness is God)",
  "id" : 261614325528158208,
  "created_at" : "2012-10-25 23:44:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Kroese",
      "screen_name" : "robkroese",
      "indices" : [ 0, 10 ],
      "id_str" : "27142719",
      "id" : 27142719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261594278340464641",
  "geo" : { },
  "id_str" : "261595210369351680",
  "in_reply_to_user_id" : 27142719,
  "text" : "@robkroese i use \"send to kindle for google chrome\" to send web articles to my kindle. it has worked well so far.",
  "id" : 261595210369351680,
  "in_reply_to_status_id" : 261594278340464641,
  "created_at" : "2012-10-25 22:28:53 +0000",
  "in_reply_to_screen_name" : "robkroese",
  "in_reply_to_user_id_str" : "27142719",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261593450166755328",
  "geo" : { },
  "id_str" : "261593740676841473",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep i would, too..lol",
  "id" : 261593740676841473,
  "in_reply_to_status_id" : 261593450166755328,
  "created_at" : "2012-10-25 22:23:02 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail Nugent",
      "screen_name" : "GailNugent1",
      "indices" : [ 3, 15 ],
      "id_str" : "626018123",
      "id" : 626018123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/jDAxrotM",
      "expanded_url" : "http:\/\/www.politicususa.com\/bernie-sanders-exposes-18-ceos-trillions-bailouts-evaded-taxes-outsourced-jobs.html",
      "display_url" : "politicususa.com\/bernie-sanders\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261587642888617984",
  "text" : "RT @GailNugent1: Bernie Sanders Exposes 18 CEOs who took Trillions in Bailouts, Evaded Taxes and Outsourced Jobs http:\/\/t.co\/jDAxrotM vi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PoliticusUSA",
        "screen_name" : "politicususa",
        "indices" : [ 121, 134 ],
        "id_str" : "14792049",
        "id" : 14792049
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/jDAxrotM",
        "expanded_url" : "http:\/\/www.politicususa.com\/bernie-sanders-exposes-18-ceos-trillions-bailouts-evaded-taxes-outsourced-jobs.html",
        "display_url" : "politicususa.com\/bernie-sanders\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261577974132899841",
    "text" : "Bernie Sanders Exposes 18 CEOs who took Trillions in Bailouts, Evaded Taxes and Outsourced Jobs http:\/\/t.co\/jDAxrotM via @politicususa",
    "id" : 261577974132899841,
    "created_at" : "2012-10-25 21:20:23 +0000",
    "user" : {
      "name" : "Gail Nugent",
      "screen_name" : "GailNugent1",
      "protected" : false,
      "id_str" : "626018123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774698922149285888\/n6foNu_e_normal.jpg",
      "id" : 626018123,
      "verified" : false
    }
  },
  "id" : 261587642888617984,
  "created_at" : "2012-10-25 21:58:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 13, 28 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261585450546917377",
  "geo" : { },
  "id_str" : "261587220291538944",
  "in_reply_to_user_id" : 7981702,
  "text" : "LOVE! : ) RT @TheEntertainer What's the good word?",
  "id" : 261587220291538944,
  "in_reply_to_status_id" : 261585450546917377,
  "created_at" : "2012-10-25 21:57:08 +0000",
  "in_reply_to_screen_name" : "TheEntertainer",
  "in_reply_to_user_id_str" : "7981702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafalca Romney",
      "screen_name" : "RafalcaRomney",
      "indices" : [ 3, 17 ],
      "id_str" : "559914794",
      "id" : 559914794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261566489843359744",
  "text" : "RT @RafalcaRomney: Paul Ryan says the way to help poor people is to cut the programs that help poor people. Makes perfect sense, eh?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261232225503301632",
    "text" : "Paul Ryan says the way to help poor people is to cut the programs that help poor people. Makes perfect sense, eh?",
    "id" : 261232225503301632,
    "created_at" : "2012-10-24 22:26:30 +0000",
    "user" : {
      "name" : "Rafalca Romney",
      "screen_name" : "RafalcaRomney",
      "protected" : false,
      "id_str" : "559914794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411356732\/e8b1b7f0bd07d4d948cb2da25e221673_normal.jpeg",
      "id" : 559914794,
      "verified" : false
    }
  },
  "id" : 261566489843359744,
  "created_at" : "2012-10-25 20:34:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 3, 16 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/eM3e1oo4",
      "expanded_url" : "http:\/\/twitpic.com\/b7ci0v",
      "display_url" : "twitpic.com\/b7ci0v"
    } ]
  },
  "geo" : { },
  "id_str" : "261565136391774209",
  "text" : "RT @wildwitchyju: Don't take life too seriously...  watching smiley squirrel play http:\/\/t.co\/eM3e1oo4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/eM3e1oo4",
        "expanded_url" : "http:\/\/twitpic.com\/b7ci0v",
        "display_url" : "twitpic.com\/b7ci0v"
      } ]
    },
    "geo" : { },
    "id_str" : "261564247773937664",
    "text" : "Don't take life too seriously...  watching smiley squirrel play http:\/\/t.co\/eM3e1oo4",
    "id" : 261564247773937664,
    "created_at" : "2012-10-25 20:25:50 +0000",
    "user" : {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "protected" : false,
      "id_str" : "67346912",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785223952150978560\/s2BxTDpr_normal.jpg",
      "id" : 67346912,
      "verified" : false
    }
  },
  "id" : 261565136391774209,
  "created_at" : "2012-10-25 20:29:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261564575592374272",
  "geo" : { },
  "id_str" : "261565016610832386",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 LOL",
  "id" : 261565016610832386,
  "in_reply_to_status_id" : 261564575592374272,
  "created_at" : "2012-10-25 20:28:54 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    }, {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 31, 45 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/RfvisTfG",
      "expanded_url" : "http:\/\/thkpr.gs\/R2YMgs",
      "display_url" : "thkpr.gs\/R2YMgs"
    } ]
  },
  "geo" : { },
  "id_str" : "261560678060527616",
  "text" : "RT @Squirrely007: What???   RT @thinkprogress: Top Romney adviser: If you own a microwave, you aren't really poor http:\/\/t.co\/RfvisTfG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 13, 27 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/RfvisTfG",
        "expanded_url" : "http:\/\/thkpr.gs\/R2YMgs",
        "display_url" : "thkpr.gs\/R2YMgs"
      } ]
    },
    "geo" : { },
    "id_str" : "261560584376573952",
    "text" : "What???   RT @thinkprogress: Top Romney adviser: If you own a microwave, you aren't really poor http:\/\/t.co\/RfvisTfG",
    "id" : 261560584376573952,
    "created_at" : "2012-10-25 20:11:17 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 261560678060527616,
  "created_at" : "2012-10-25 20:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261540241985392640",
  "geo" : { },
  "id_str" : "261542383211122688",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses aww.. shoot, i hope not!",
  "id" : 261542383211122688,
  "in_reply_to_status_id" : 261540241985392640,
  "created_at" : "2012-10-25 18:58:58 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261511338545795073",
  "text" : "RT @TrishScott: If we don't need a president during the last year of his 1st term while he spends all his energy being re-elected, why d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261510348539047936",
    "text" : "If we don't need a president during the last year of his 1st term while he spends all his energy being re-elected, why do we need 1 at all?",
    "id" : 261510348539047936,
    "created_at" : "2012-10-25 16:51:40 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 261511338545795073,
  "created_at" : "2012-10-25 16:55:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261501610159665153",
  "text" : "RT @TheGoldenMirror: The mind can be used to either be creative or destructive. The choice is ours.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261500719843143680",
    "text" : "The mind can be used to either be creative or destructive. The choice is ours.",
    "id" : 261500719843143680,
    "created_at" : "2012-10-25 16:13:24 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 261501610159665153,
  "created_at" : "2012-10-25 16:16:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261501574503882752",
  "text" : "RT @dhammagirl: Were all doing our best given the shells were in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261500786360610818",
    "text" : "Were all doing our best given the shells were in.",
    "id" : 261500786360610818,
    "created_at" : "2012-10-25 16:13:40 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 261501574503882752,
  "created_at" : "2012-10-25 16:16:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261501536516063232",
  "text" : "RT @TheEntertainer: Let's DO this sh*t.\n\nHow bad do YOU want the TRUTH in YOU and ALL over this\ncrazy ass planet to come true once... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/1FjeQgU8",
        "expanded_url" : "http:\/\/fb.me\/VOezo6x8",
        "display_url" : "fb.me\/VOezo6x8"
      } ]
    },
    "geo" : { },
    "id_str" : "261500908339351554",
    "text" : "Let's DO this sh*t.\n\nHow bad do YOU want the TRUTH in YOU and ALL over this\ncrazy ass planet to come true once... http:\/\/t.co\/1FjeQgU8",
    "id" : 261500908339351554,
    "created_at" : "2012-10-25 16:14:09 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 261501536516063232,
  "created_at" : "2012-10-25 16:16:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261498049233293312",
  "geo" : { },
  "id_str" : "261500980124868608",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time yup,just went away. thought maybe blood sugar drop but eat\/drink didnt help. very strange feeling.",
  "id" : 261500980124868608,
  "in_reply_to_status_id" : 261498049233293312,
  "created_at" : "2012-10-25 16:14:26 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261499305171513344",
  "text" : "RT @TrishScott: RT @ieyeayes: Live streaming consciousness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261494612194099200",
    "text" : "RT @ieyeayes: Live streaming consciousness.",
    "id" : 261494612194099200,
    "created_at" : "2012-10-25 15:49:08 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 261499305171513344,
  "created_at" : "2012-10-25 16:07:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261496192746262529",
  "text" : "RT @LOLGOP: Is there anyone alive who is shocked that the guys who thought the Iraq War was god's will think the same thing about a preg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261489241383645184",
    "text" : "Is there anyone alive who is shocked that the guys who thought the Iraq War was god's will think the same thing about a pregnancy from rape?",
    "id" : 261489241383645184,
    "created_at" : "2012-10-25 15:27:48 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649031186845560832\/c385MSMQ_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 261496192746262529,
  "created_at" : "2012-10-25 15:55:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261495097538011137",
  "text" : "RT @JohnCali: Turning up the love. Turns on everything else. Love up, The Universe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261492847944015872",
    "text" : "Turning up the love. Turns on everything else. Love up, The Universe",
    "id" : 261492847944015872,
    "created_at" : "2012-10-25 15:42:07 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 261495097538011137,
  "created_at" : "2012-10-25 15:51:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261487897042108416",
  "text" : "RT @dhammagirl: Life: Gateway drug to ---&gt; Death",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261487611770703872",
    "text" : "Life: Gateway drug to ---&gt; Death",
    "id" : 261487611770703872,
    "created_at" : "2012-10-25 15:21:19 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 261487897042108416,
  "created_at" : "2012-10-25 15:22:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/KF2i3WnG",
      "expanded_url" : "http:\/\/huff.to\/QHXb1x",
      "display_url" : "huff.to\/QHXb1x"
    } ]
  },
  "geo" : { },
  "id_str" : "261487248736935936",
  "text" : "RT @HuffPostWeird: Wow, this thief is a FOX http:\/\/t.co\/KF2i3WnG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/KF2i3WnG",
        "expanded_url" : "http:\/\/huff.to\/QHXb1x",
        "display_url" : "huff.to\/QHXb1x"
      } ]
    },
    "geo" : { },
    "id_str" : "261486096649699328",
    "text" : "Wow, this thief is a FOX http:\/\/t.co\/KF2i3WnG",
    "id" : 261486096649699328,
    "created_at" : "2012-10-25 15:15:18 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 261487248736935936,
  "created_at" : "2012-10-25 15:19:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261484495654514688",
  "text" : "RT @TheGoldenMirror: We're all human. We're all on the same side.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261484390939508737",
    "text" : "We're all human. We're all on the same side.",
    "id" : 261484390939508737,
    "created_at" : "2012-10-25 15:08:31 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 261484495654514688,
  "created_at" : "2012-10-25 15:08:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261481541618790400",
  "text" : "hard work does not = better life!!",
  "id" : 261481541618790400,
  "created_at" : "2012-10-25 14:57:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261469821408010240",
  "text" : "voting should be mandatory then ballots should include: undecided, dont care, dont like the choices given.",
  "id" : 261469821408010240,
  "created_at" : "2012-10-25 14:10:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261468868227244032",
  "text" : "my coffee ran out so im drinking diff coffee.. not happy..lol",
  "id" : 261468868227244032,
  "created_at" : "2012-10-25 14:06:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/f6y8sVai",
      "expanded_url" : "http:\/\/j.mp\/TCMJg0",
      "display_url" : "j.mp\/TCMJg0"
    } ]
  },
  "geo" : { },
  "id_str" : "261463512835055620",
  "text" : "Is Your Food Making You Sick? http:\/\/t.co\/f6y8sVai \"anyone lacking cilium in their digestive tract should not eat gluten\"",
  "id" : 261463512835055620,
  "created_at" : "2012-10-25 13:45:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafalca Romney",
      "screen_name" : "RafalcaRomney",
      "indices" : [ 3, 17 ],
      "id_str" : "559914794",
      "id" : 559914794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261203922595766272",
  "text" : "RT @RafalcaRomney: At what point did the GOP decide to bag all that \"separation of church and state\" nonsense the Founding Fathers presc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261197058394976256",
    "text" : "At what point did the GOP decide to bag all that \"separation of church and state\" nonsense the Founding Fathers prescribed? #tcot",
    "id" : 261197058394976256,
    "created_at" : "2012-10-24 20:06:46 +0000",
    "user" : {
      "name" : "Rafalca Romney",
      "screen_name" : "RafalcaRomney",
      "protected" : false,
      "id_str" : "559914794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411356732\/e8b1b7f0bd07d4d948cb2da25e221673_normal.jpeg",
      "id" : 559914794,
      "verified" : false
    }
  },
  "id" : 261203922595766272,
  "created_at" : "2012-10-24 20:34:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faith in Fiction",
      "screen_name" : "FictionFaith",
      "indices" : [ 0, 13 ],
      "id_str" : "494383730",
      "id" : 494383730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261180353866264576",
  "geo" : { },
  "id_str" : "261181673012604929",
  "in_reply_to_user_id" : 494383730,
  "text" : "@FictionFaith ((hugs))",
  "id" : 261181673012604929,
  "in_reply_to_status_id" : 261180353866264576,
  "created_at" : "2012-10-24 19:05:38 +0000",
  "in_reply_to_screen_name" : "FictionFaith",
  "in_reply_to_user_id_str" : "494383730",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun King",
      "screen_name" : "ShaunKing",
      "indices" : [ 0, 10 ],
      "id_str" : "755113",
      "id" : 755113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261166199113658368",
  "geo" : { },
  "id_str" : "261170802911764480",
  "in_reply_to_user_id" : 755113,
  "text" : "@ShaunKing can say the same about those who feel same about romney...",
  "id" : 261170802911764480,
  "in_reply_to_status_id" : 261166199113658368,
  "created_at" : "2012-10-24 18:22:26 +0000",
  "in_reply_to_screen_name" : "ShaunKing",
  "in_reply_to_user_id_str" : "755113",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 3, 13 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261164408045199361",
  "text" : "RT @MakeUseOf: Did you tell us about your favorite eReader yet? Tell us &amp; you can win it! Try to stick to e-ink readers please. Cont ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sendible.com\" rel=\"nofollow\"\u003ESendible\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261163951721689088",
    "text" : "Did you tell us about your favorite eReader yet? Tell us &amp; you can win it! Try to stick to e-ink readers please. Contest is closing soon!",
    "id" : 261163951721689088,
    "created_at" : "2012-10-24 17:55:12 +0000",
    "user" : {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "protected" : false,
      "id_str" : "63043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771290297255006208\/qJzhURwu_normal.jpg",
      "id" : 63043,
      "verified" : true
    }
  },
  "id" : 261164408045199361,
  "created_at" : "2012-10-24 17:57:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/RZnMSGAy",
      "expanded_url" : "http:\/\/bit.ly\/RCftAZ",
      "display_url" : "bit.ly\/RCftAZ"
    } ]
  },
  "geo" : { },
  "id_str" : "261162282367721472",
  "text" : "RT @micahjmurray: 16 Ways I Blew My Marriage: http:\/\/t.co\/RZnMSGAy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/RZnMSGAy",
        "expanded_url" : "http:\/\/bit.ly\/RCftAZ",
        "display_url" : "bit.ly\/RCftAZ"
      } ]
    },
    "geo" : { },
    "id_str" : "261160202265575424",
    "text" : "16 Ways I Blew My Marriage: http:\/\/t.co\/RZnMSGAy",
    "id" : 261160202265575424,
    "created_at" : "2012-10-24 17:40:18 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 261162282367721472,
  "created_at" : "2012-10-24 17:48:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261161061602955264",
  "geo" : { },
  "id_str" : "261161666119598081",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ive had a couple of episodes like that (spread out over a few years) .. it is very weird. assumed strange virus.",
  "id" : 261161666119598081,
  "in_reply_to_status_id" : 261161061602955264,
  "created_at" : "2012-10-24 17:46:08 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261159676094316544",
  "text" : "at least that would take care of the \"against employer morals\" argument...",
  "id" : 261159676094316544,
  "created_at" : "2012-10-24 17:38:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261159164183736320",
  "text" : "i dont think health insurance should be tied to employment.",
  "id" : 261159164183736320,
  "created_at" : "2012-10-24 17:36:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Celtic MoonDance",
      "screen_name" : "CelticMoonDance",
      "indices" : [ 3, 19 ],
      "id_str" : "503129866",
      "id" : 503129866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261158586934243332",
  "text" : "RT @CelticMoonDance: In every loss there is something to be gained. Find it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260869100711059456",
    "text" : "In every loss there is something to be gained. Find it.",
    "id" : 260869100711059456,
    "created_at" : "2012-10-23 22:23:34 +0000",
    "user" : {
      "name" : "Celtic MoonDance",
      "screen_name" : "CelticMoonDance",
      "protected" : false,
      "id_str" : "503129866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791308686685773824\/MLUz0Ypc_normal.jpg",
      "id" : 503129866,
      "verified" : false
    }
  },
  "id" : 261158586934243332,
  "created_at" : "2012-10-24 17:33:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "indices" : [ 3, 16 ],
      "id_str" : "179732982",
      "id" : 179732982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261142006892462080",
  "text" : "RT @TheDailyEdge: That awkward moment when President Romney slashes Medicaid to toughen up poor children, seniors and disabled moochers  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/9RRwqJVt",
        "expanded_url" : "http:\/\/www.nytimes.com\/2012\/09\/01\/us\/politics\/campaigns-have-sharply-different-visions-for-medicaid.html?_r=0",
        "display_url" : "nytimes.com\/2012\/09\/01\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261120787342323713",
    "text" : "That awkward moment when President Romney slashes Medicaid to toughen up poor children, seniors and disabled moochers http:\/\/t.co\/9RRwqJVt",
    "id" : 261120787342323713,
    "created_at" : "2012-10-24 15:03:41 +0000",
    "user" : {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "protected" : false,
      "id_str" : "179732982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655073745510510592\/FX6VgfRw_normal.png",
      "id" : 179732982,
      "verified" : false
    }
  },
  "id" : 261142006892462080,
  "created_at" : "2012-10-24 16:28:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261131326755860480",
  "geo" : { },
  "id_str" : "261131952118181888",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields while im liberal as one can be, i dont neccessarily agree w many things said by other liberals\/democrats...",
  "id" : 261131952118181888,
  "in_reply_to_status_id" : 261131326755860480,
  "created_at" : "2012-10-24 15:48:03 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261131126486208512",
  "text" : "i dont agree w picking on romneys sons not doing military.",
  "id" : 261131126486208512,
  "created_at" : "2012-10-24 15:44:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261122424576286720",
  "geo" : { },
  "id_str" : "261125812424687616",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray beautiful!",
  "id" : 261125812424687616,
  "in_reply_to_status_id" : 261122424576286720,
  "created_at" : "2012-10-24 15:23:39 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Ann Coulter",
      "screen_name" : "AnnCoulter",
      "indices" : [ 37, 48 ],
      "id_str" : "196168350",
      "id" : 196168350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/E0SFSvf1",
      "expanded_url" : "http:\/\/bit.ly\/S4vFxv",
      "display_url" : "bit.ly\/S4vFxv"
    } ]
  },
  "geo" : { },
  "id_str" : "261125677267431424",
  "text" : "RT @micahjmurray: A wise response to @AnnCoulter's ignorant, offensive \"Obama is a retard\" statement: http:\/\/t.co\/E0SFSvf1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ann Coulter",
        "screen_name" : "AnnCoulter",
        "indices" : [ 19, 30 ],
        "id_str" : "196168350",
        "id" : 196168350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/E0SFSvf1",
        "expanded_url" : "http:\/\/bit.ly\/S4vFxv",
        "display_url" : "bit.ly\/S4vFxv"
      } ]
    },
    "geo" : { },
    "id_str" : "261122424576286720",
    "text" : "A wise response to @AnnCoulter's ignorant, offensive \"Obama is a retard\" statement: http:\/\/t.co\/E0SFSvf1",
    "id" : 261122424576286720,
    "created_at" : "2012-10-24 15:10:12 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 261125677267431424,
  "created_at" : "2012-10-24 15:23:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260892841381879808",
  "text" : "RT @bunnybuddhism: It is easy to see another bunny's faults and difficult to face one's own.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260889267650322432",
    "text" : "It is easy to see another bunny's faults and difficult to face one's own.",
    "id" : 260889267650322432,
    "created_at" : "2012-10-23 23:43:43 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 260892841381879808,
  "created_at" : "2012-10-23 23:57:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260862884769329153",
  "text" : "RT @petsalive: Our friends at Mid Hudson Animal Aid got a call today about a stray \"dinosaur\".  And people wonder why we drink.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260859709366599681",
    "text" : "Our friends at Mid Hudson Animal Aid got a call today about a stray \"dinosaur\".  And people wonder why we drink.",
    "id" : 260859709366599681,
    "created_at" : "2012-10-23 21:46:15 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 260862884769329153,
  "created_at" : "2012-10-23 21:58:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheNewDeal",
      "screen_name" : "TheNewDeal",
      "indices" : [ 3, 14 ],
      "id_str" : "78569026",
      "id" : 78569026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260862696965156864",
  "text" : "RT @TheNewDeal: America Should Not Be Run by a Guy Who Got Rich Sending Jobs to China &amp; Invests His Money Everywhere but America. #R ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RomneyNotReady",
        "indices" : [ 118, 133 ]
      }, {
        "text" : "p2",
        "indices" : [ 134, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260860626224689152",
    "text" : "America Should Not Be Run by a Guy Who Got Rich Sending Jobs to China &amp; Invests His Money Everywhere but America. #RomneyNotReady #p2",
    "id" : 260860626224689152,
    "created_at" : "2012-10-23 21:49:54 +0000",
    "user" : {
      "name" : "TheNewDeal",
      "screen_name" : "TheNewDeal",
      "protected" : false,
      "id_str" : "78569026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769416370\/fdr-smile_normal.jpg",
      "id" : 78569026,
      "verified" : false
    }
  },
  "id" : 260862696965156864,
  "created_at" : "2012-10-23 21:58:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260830734699339777",
  "text" : "RT @UndertheNeonSky: Peeves do not make very good pets. Bo Bennett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260830562749669376",
    "text" : "Peeves do not make very good pets. Bo Bennett",
    "id" : 260830562749669376,
    "created_at" : "2012-10-23 19:50:26 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 260830734699339777,
  "created_at" : "2012-10-23 19:51:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260824996144881664",
  "text" : "RT @UnshackleUS: Why would you believe that a person who\u2019d disenfranchise you to gain POWER would be interested in your RIGHTS after he  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260525337442660352",
    "text" : "Why would you believe that a person who\u2019d disenfranchise you to gain POWER would be interested in your RIGHTS after he got what he WANTED?",
    "id" : 260525337442660352,
    "created_at" : "2012-10-22 23:37:35 +0000",
    "user" : {
      "name" : "Captain Clarion",
      "screen_name" : "citizensrock",
      "protected" : false,
      "id_str" : "271030180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500767478197153792\/necyH3Wl_normal.png",
      "id" : 271030180,
      "verified" : false
    }
  },
  "id" : 260824996144881664,
  "created_at" : "2012-10-23 19:28:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YOU'RE GONNA...WIN?",
      "screen_name" : "Bro_Pair",
      "indices" : [ 3, 12 ],
      "id_str" : "56309136",
      "id" : 56309136
    }, {
      "name" : "Zynga",
      "screen_name" : "zynga",
      "indices" : [ 41, 47 ],
      "id_str" : "22728255",
      "id" : 22728255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260815165530984448",
  "text" : "RT @Bro_Pair: stupid facebook game maker @Zynga is laying off all their staff with 2 hour notice to vacate offices DURING the apple thin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zynga",
        "screen_name" : "zynga",
        "indices" : [ 27, 33 ],
        "id_str" : "22728255",
        "id" : 22728255
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260806273468096513",
    "text" : "stupid facebook game maker @Zynga is laying off all their staff with 2 hour notice to vacate offices DURING the apple thing so no 1 notices",
    "id" : 260806273468096513,
    "created_at" : "2012-10-23 18:13:55 +0000",
    "user" : {
      "name" : "YOU'RE GONNA...WIN?",
      "screen_name" : "Bro_Pair",
      "protected" : false,
      "id_str" : "56309136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2019195495\/mabuse_normal.gif",
      "id" : 56309136,
      "verified" : false
    }
  },
  "id" : 260815165530984448,
  "created_at" : "2012-10-23 18:49:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260813947844829186",
  "geo" : { },
  "id_str" : "260814998501220352",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon whats FPTP?",
  "id" : 260814998501220352,
  "in_reply_to_status_id" : 260813947844829186,
  "created_at" : "2012-10-23 18:48:36 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 0, 11 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260806870799876096",
  "geo" : { },
  "id_str" : "260807780078866432",
  "in_reply_to_user_id" : 141944109,
  "text" : "@LSFProgram THIS!!",
  "id" : 260807780078866432,
  "in_reply_to_status_id" : 260806870799876096,
  "created_at" : "2012-10-23 18:19:55 +0000",
  "in_reply_to_screen_name" : "LSFProgram",
  "in_reply_to_user_id_str" : "141944109",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260806657343361025",
  "text" : "ok ppl.. get this straight.. ipads, kindle fires, etc are NOT ereaders!!",
  "id" : 260806657343361025,
  "created_at" : "2012-10-23 18:15:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 2, 14 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260801192450465793",
  "geo" : { },
  "id_str" : "260801719066296320",
  "in_reply_to_user_id" : 118573185,
  "text" : ". @CoyoteSings well, that's not very... hopeful. hmm.. perhaps by all of us not being hopeful, laying down to die, will be what changes us.",
  "id" : 260801719066296320,
  "in_reply_to_status_id" : 260801192450465793,
  "created_at" : "2012-10-23 17:55:49 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260800509747798018",
  "geo" : { },
  "id_str" : "260800995808903168",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings how do we change this?",
  "id" : 260800995808903168,
  "in_reply_to_status_id" : 260800509747798018,
  "created_at" : "2012-10-23 17:52:57 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260796579219390464",
  "text" : "RT @LukeRomyn: Welcome to Twitter. Now you can never leave.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260796214176518144",
    "text" : "Welcome to Twitter. Now you can never leave.",
    "id" : 260796214176518144,
    "created_at" : "2012-10-23 17:33:57 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 260796579219390464,
  "created_at" : "2012-10-23 17:35:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    }, {
      "name" : "LIFE & DOG",
      "screen_name" : "LifeandDog",
      "indices" : [ 33, 44 ],
      "id_str" : "191691662",
      "id" : 191691662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/ujKOrHaS",
      "expanded_url" : "http:\/\/instagr.am\/p\/RIWmsHhwfH\/",
      "display_url" : "instagr.am\/p\/RIWmsHhwfH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "260795130250944512",
  "text" : "RT @grouchypuppy: So cute! Love .@lifeanddog photo :0) http:\/\/t.co\/ujKOrHaS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/instagram\/id389801252?mt=8&uo=4\" rel=\"nofollow\"\u003EInstagram on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LIFE & DOG",
        "screen_name" : "LifeandDog",
        "indices" : [ 15, 26 ],
        "id_str" : "191691662",
        "id" : 191691662
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/ujKOrHaS",
        "expanded_url" : "http:\/\/instagr.am\/p\/RIWmsHhwfH\/",
        "display_url" : "instagr.am\/p\/RIWmsHhwfH\/"
      } ]
    },
    "geo" : { },
    "id_str" : "260794492041457664",
    "text" : "So cute! Love .@lifeanddog photo :0) http:\/\/t.co\/ujKOrHaS",
    "id" : 260794492041457664,
    "created_at" : "2012-10-23 17:27:06 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 260795130250944512,
  "created_at" : "2012-10-23 17:29:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260794437842657280",
  "text" : "RT @ChristianDems: We must fight for the rights of others, even those whom we disagree with, if we want to also keep our rights as well. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/GkCypBvp",
        "expanded_url" : "http:\/\/ow.ly\/eHPUm",
        "display_url" : "ow.ly\/eHPUm"
      } ]
    },
    "geo" : { },
    "id_str" : "260794063924654080",
    "text" : "We must fight for the rights of others, even those whom we disagree with, if we want to also keep our rights as well. http:\/\/t.co\/GkCypBvp",
    "id" : 260794063924654080,
    "created_at" : "2012-10-23 17:25:24 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 260794437842657280,
  "created_at" : "2012-10-23 17:26:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/GNswz5lT",
      "expanded_url" : "http:\/\/ow.ly\/eHP8O",
      "display_url" : "ow.ly\/eHP8O"
    } ]
  },
  "geo" : { },
  "id_str" : "260792935501668353",
  "text" : "RT @DuttonBooks: \"It's called 'reading.' It's how people install new software into their brains.\" http:\/\/t.co\/GNswz5lT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/GNswz5lT",
        "expanded_url" : "http:\/\/ow.ly\/eHP8O",
        "display_url" : "ow.ly\/eHP8O"
      } ]
    },
    "geo" : { },
    "id_str" : "260792657771630592",
    "text" : "\"It's called 'reading.' It's how people install new software into their brains.\" http:\/\/t.co\/GNswz5lT",
    "id" : 260792657771630592,
    "created_at" : "2012-10-23 17:19:49 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 260792935501668353,
  "created_at" : "2012-10-23 17:20:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "birds",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/2G24e1cF",
      "expanded_url" : "http:\/\/goo.gl\/BQw6S",
      "display_url" : "goo.gl\/BQw6S"
    } ]
  },
  "geo" : { },
  "id_str" : "260792507766562817",
  "text" : "RT @KerriFar: A Very Wet Dove ~  http:\/\/t.co\/2G24e1cF  ~ #nature #birds",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 43, 50 ]
      }, {
        "text" : "birds",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 19, 39 ],
        "url" : "http:\/\/t.co\/2G24e1cF",
        "expanded_url" : "http:\/\/goo.gl\/BQw6S",
        "display_url" : "goo.gl\/BQw6S"
      } ]
    },
    "geo" : { },
    "id_str" : "260791697812885504",
    "text" : "A Very Wet Dove ~  http:\/\/t.co\/2G24e1cF  ~ #nature #birds",
    "id" : 260791697812885504,
    "created_at" : "2012-10-23 17:16:00 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 260792507766562817,
  "created_at" : "2012-10-23 17:19:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/SphtfNLT",
      "expanded_url" : "http:\/\/youtu.be\/6wYYX0mZsQA",
      "display_url" : "youtu.be\/6wYYX0mZsQA"
    } ]
  },
  "geo" : { },
  "id_str" : "260792107344732160",
  "text" : "Grover Norquist - We just need a President to sign this stuff: http:\/\/t.co\/SphtfNLT",
  "id" : 260792107344732160,
  "created_at" : "2012-10-23 17:17:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260791352328081408",
  "text" : "RT @CaroleODell: Trust me. You only want to have people who have \"opted in\" to receive marketing emails. Otherwise it's spam. Yes. Spam.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260789907646210048",
    "text" : "Trust me. You only want to have people who have \"opted in\" to receive marketing emails. Otherwise it's spam. Yes. Spam.",
    "id" : 260789907646210048,
    "created_at" : "2012-10-23 17:08:53 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 260791352328081408,
  "created_at" : "2012-10-23 17:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 2, 11 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260783864849506305",
  "geo" : { },
  "id_str" : "260786077432946688",
  "in_reply_to_user_id" : 46760072,
  "text" : ". @WahminSC this election is bringing out so many emotions. its knoocked me on my kiester (sp?). having 2nd my cup now : )",
  "id" : 260786077432946688,
  "in_reply_to_status_id" : 260783864849506305,
  "created_at" : "2012-10-23 16:53:40 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260785668853227520",
  "text" : "RT @BrianMerritt: Does a dollar really matter when the whole world burns?  SOJA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260784575645622272",
    "text" : "Does a dollar really matter when the whole world burns?  SOJA",
    "id" : 260784575645622272,
    "created_at" : "2012-10-23 16:47:42 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 260785668853227520,
  "created_at" : "2012-10-23 16:52:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 2, 13 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260784593823748096",
  "geo" : { },
  "id_str" : "260785642831753216",
  "in_reply_to_user_id" : 141944109,
  "text" : ". @LSFProgram im struggling w this ATM w the election coming up... sigh.",
  "id" : 260785642831753216,
  "in_reply_to_status_id" : 260784593823748096,
  "created_at" : "2012-10-23 16:51:57 +0000",
  "in_reply_to_screen_name" : "LSFProgram",
  "in_reply_to_user_id_str" : "141944109",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260785440083283969",
  "text" : "RT @LSFProgram: Do not give importance to that which is temporary. Take it lightly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260784593823748096",
    "text" : "Do not give importance to that which is temporary. Take it lightly.",
    "id" : 260784593823748096,
    "created_at" : "2012-10-23 16:47:46 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 260785440083283969,
  "created_at" : "2012-10-23 16:51:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260785201070886912",
  "text" : "america worships the dead not the living...",
  "id" : 260785201070886912,
  "created_at" : "2012-10-23 16:50:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260783606300037120",
  "text" : "i can understand why ppl died before 2012 cuz this sh*t is exhausting...",
  "id" : 260783606300037120,
  "created_at" : "2012-10-23 16:43:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260569043457691650",
  "text" : "RT @abandontheherd: Instead of holding on tightly to how life \"should\" be, unclench your fist and let go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260568155745824768",
    "text" : "Instead of holding on tightly to how life \"should\" be, unclench your fist and let go.",
    "id" : 260568155745824768,
    "created_at" : "2012-10-23 02:27:44 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 260569043457691650,
  "created_at" : "2012-10-23 02:31:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "indices" : [ 3, 14 ],
      "id_str" : "15767534",
      "id" : 15767534
    }, {
      "name" : "Occupy Wall Street",
      "screen_name" : "OccupyWallSt",
      "indices" : [ 19, 32 ],
      "id_str" : "335369838",
      "id" : 335369838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260561199949828098",
  "text" : "RT @micahbales: RT @OccupyWallSt: While our gov't officials brag about whose sanctions will be tougher, it's left to the PEOPLE to take  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Occupy Wall Street",
        "screen_name" : "OccupyWallSt",
        "indices" : [ 3, 16 ],
        "id_str" : "335369838",
        "id" : 335369838
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260560230126075904",
    "text" : "RT @OccupyWallSt: While our gov't officials brag about whose sanctions will be tougher, it's left to the PEOPLE to take care of each other.",
    "id" : 260560230126075904,
    "created_at" : "2012-10-23 01:56:14 +0000",
    "user" : {
      "name" : "Micah Bales",
      "screen_name" : "micahbales",
      "protected" : false,
      "id_str" : "15767534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523109819654230017\/RlmyhCrv_normal.png",
      "id" : 15767534,
      "verified" : false
    }
  },
  "id" : 260561199949828098,
  "created_at" : "2012-10-23 02:00:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260550503149228033",
  "text" : "RT @bunnybuddhism: Bunniness can never come at the expense of another bunny.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260549491491483649",
    "text" : "Bunniness can never come at the expense of another bunny.",
    "id" : 260549491491483649,
    "created_at" : "2012-10-23 01:13:34 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 260550503149228033,
  "created_at" : "2012-10-23 01:17:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/rwYwliBx",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2012\/10\/20\/1147581\/--I-thought-Please-proceed-CEO-and-he-did-Fire-people-with-Obama-stickers",
      "display_url" : "dailykos.com\/story\/2012\/10\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260503699976241152",
  "text" : "RT @Jamiastar: Daily Kos: I thought: \"Please proceed, CEO\", and he did: \"Fire people with Obama stickers\" http:\/\/t.co\/rwYwliBx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/rwYwliBx",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2012\/10\/20\/1147581\/--I-thought-Please-proceed-CEO-and-he-did-Fire-people-with-Obama-stickers",
        "display_url" : "dailykos.com\/story\/2012\/10\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "260501444514435072",
    "text" : "Daily Kos: I thought: \"Please proceed, CEO\", and he did: \"Fire people with Obama stickers\" http:\/\/t.co\/rwYwliBx",
    "id" : 260501444514435072,
    "created_at" : "2012-10-22 22:02:38 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 260503699976241152,
  "created_at" : "2012-10-22 22:11:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    }, {
      "name" : "Laura Roberts",
      "screen_name" : "llr517",
      "indices" : [ 56, 63 ],
      "id_str" : "62298413",
      "id" : 62298413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260480211282432000",
  "geo" : { },
  "id_str" : "260481646506156034",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 im still having trouble with this concept..lol @llr517",
  "id" : 260481646506156034,
  "in_reply_to_status_id" : 260480211282432000,
  "created_at" : "2012-10-22 20:43:58 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "indices" : [ 3, 13 ],
      "id_str" : "20001303",
      "id" : 20001303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DRM",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260470949919465472",
  "text" : "RT @HoodedMan: Ppl having their Kindle account closed illustrates the PROBLEM with both #DRM and #ebooks You don't own your purchase, wh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DRM",
        "indices" : [ 73, 77 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260470390655180800",
    "text" : "Ppl having their Kindle account closed illustrates the PROBLEM with both #DRM and #ebooks You don't own your purchase, which is unacceptable",
    "id" : 260470390655180800,
    "created_at" : "2012-10-22 19:59:15 +0000",
    "user" : {
      "name" : "Amos Keppler",
      "screen_name" : "HoodedMan",
      "protected" : false,
      "id_str" : "20001303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2081858364\/amoskeppler_normal.jpg",
      "id" : 20001303,
      "verified" : false
    }
  },
  "id" : 260470949919465472,
  "created_at" : "2012-10-22 20:01:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260465024173219840",
  "text" : "my DD is such a hoot.. she's a rebel. what a good girl! : )",
  "id" : 260465024173219840,
  "created_at" : "2012-10-22 19:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "indices" : [ 3, 19 ],
      "id_str" : "478216296",
      "id" : 478216296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260431477748150275",
  "text" : "RT @JesusWithIssues: Guys, I cannot wait to hear how I'm consulted before any big decisions are made on foreign policy tonight.  Glory!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260430563402465281",
    "text" : "Guys, I cannot wait to hear how I'm consulted before any big decisions are made on foreign policy tonight.  Glory!",
    "id" : 260430563402465281,
    "created_at" : "2012-10-22 17:20:59 +0000",
    "user" : {
      "name" : "Jesus With Issues",
      "screen_name" : "JesusWithIssues",
      "protected" : false,
      "id_str" : "478216296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2229020646\/jesus_leopard_normal.jpg",
      "id" : 478216296,
      "verified" : false
    }
  },
  "id" : 260431477748150275,
  "created_at" : "2012-10-22 17:24:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260422234273873924",
  "geo" : { },
  "id_str" : "260423342010560512",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth no i dont see bible as word of god. my view of \"god\" has changed.. im more \"the universe\" type now..lol",
  "id" : 260423342010560512,
  "in_reply_to_status_id" : 260422234273873924,
  "created_at" : "2012-10-22 16:52:17 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260422234273873924",
  "geo" : { },
  "id_str" : "260423027051859968",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth im mostly a christian mutt..lol. never officially thought of myself as \"a christian\" &gt;&gt; no hell, saved from what?",
  "id" : 260423027051859968,
  "in_reply_to_status_id" : 260422234273873924,
  "created_at" : "2012-10-22 16:51:02 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260419634325491712",
  "geo" : { },
  "id_str" : "260421684128002048",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth its what i consider myself, i suppose. i define it as anyone who doesnt fit into any of the religious moulds...",
  "id" : 260421684128002048,
  "in_reply_to_status_id" : 260419634325491712,
  "created_at" : "2012-10-22 16:45:42 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pruitt",
      "screen_name" : "neoookami",
      "indices" : [ 3, 13 ],
      "id_str" : "38671125",
      "id" : 38671125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/7MfS1dWf",
      "expanded_url" : "http:\/\/xkcd.com\/1124\/",
      "display_url" : "xkcd.com\/1124\/"
    } ]
  },
  "geo" : { },
  "id_str" : "260405377064108033",
  "text" : "RT @neoookami: It's true. http:\/\/t.co\/7MfS1dWf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/hotot.org\" rel=\"nofollow\"\u003EHotot for Chrome\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/7MfS1dWf",
        "expanded_url" : "http:\/\/xkcd.com\/1124\/",
        "display_url" : "xkcd.com\/1124\/"
      } ]
    },
    "geo" : { },
    "id_str" : "260404981969063936",
    "text" : "It's true. http:\/\/t.co\/7MfS1dWf",
    "id" : 260404981969063936,
    "created_at" : "2012-10-22 15:39:20 +0000",
    "user" : {
      "name" : "Michael Pruitt",
      "screen_name" : "neoookami",
      "protected" : false,
      "id_str" : "38671125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797427401491959808\/ARvKhKSX_normal.jpg",
      "id" : 38671125,
      "verified" : false
    }
  },
  "id" : 260405377064108033,
  "created_at" : "2012-10-22 15:40:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EnvatoWebDev",
      "screen_name" : "envatowebdev",
      "indices" : [ 3, 16 ],
      "id_str" : "223770428",
      "id" : 223770428
    }, {
      "name" : "Tuts+ Premium",
      "screen_name" : "TutsPremium",
      "indices" : [ 110, 122 ],
      "id_str" : "347033890",
      "id" : 347033890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260401508225515521",
  "text" : "RT @envatowebdev: I'm looking for someone with a solid computer science background to create some courses for @tutspremium. Any interest ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tuts+ Premium",
        "screen_name" : "TutsPremium",
        "indices" : [ 92, 104 ],
        "id_str" : "347033890",
        "id" : 347033890
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260400535633547264",
    "text" : "I'm looking for someone with a solid computer science background to create some courses for @tutspremium. Any interest? Pay well!",
    "id" : 260400535633547264,
    "created_at" : "2012-10-22 15:21:40 +0000",
    "user" : {
      "name" : "Envato Tuts+ Code",
      "screen_name" : "TutsPlusCode",
      "protected" : false,
      "id_str" : "14490962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440360139866910721\/CSiOk6MT_normal.png",
      "id" : 14490962,
      "verified" : false
    }
  },
  "id" : 260401508225515521,
  "created_at" : "2012-10-22 15:25:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260392428832428032",
  "text" : "we're all brainwashed.. every single one of us..",
  "id" : 260392428832428032,
  "created_at" : "2012-10-22 14:49:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Free Press",
      "screen_name" : "freepress",
      "indices" : [ 3, 13 ],
      "id_str" : "14292458",
      "id" : 14292458
    }, {
      "name" : "Josh Stearns",
      "screen_name" : "jcstearns",
      "indices" : [ 18, 28 ],
      "id_str" : "14302121",
      "id" : 14302121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260390900163817472",
  "text" : "RT @freepress: RT @jcstearns: The $3.3 billion being spent on political ads in 2012 could put more than 60k students through four years  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Stearns",
        "screen_name" : "jcstearns",
        "indices" : [ 3, 13 ],
        "id_str" : "14302121",
        "id" : 14302121
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260387459957923842",
    "text" : "RT @jcstearns: The $3.3 billion being spent on political ads in 2012 could put more than 60k students through four years of state college.",
    "id" : 260387459957923842,
    "created_at" : "2012-10-22 14:29:42 +0000",
    "user" : {
      "name" : "Free Press",
      "screen_name" : "freepress",
      "protected" : false,
      "id_str" : "14292458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511921068475310080\/BZ0ei_kE_normal.png",
      "id" : 14292458,
      "verified" : false
    }
  },
  "id" : 260390900163817472,
  "created_at" : "2012-10-22 14:43:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260153281169469440",
  "geo" : { },
  "id_str" : "260154090762432512",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves don't we all? but we wouldn't listen anyway... nice looking young man there : )",
  "id" : 260154090762432512,
  "in_reply_to_status_id" : 260153281169469440,
  "created_at" : "2012-10-21 23:02:23 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260147902981230592",
  "geo" : { },
  "id_str" : "260148451159990272",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu hmm.. not sure where i would fall.. strongly believe in social safety nets yet also think we have way too many laws..",
  "id" : 260148451159990272,
  "in_reply_to_status_id" : 260147902981230592,
  "created_at" : "2012-10-21 22:39:58 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260145393218764801",
  "geo" : { },
  "id_str" : "260146362581123072",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu whats neo? classical?",
  "id" : 260146362581123072,
  "in_reply_to_status_id" : 260145393218764801,
  "created_at" : "2012-10-21 22:31:40 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260145562513453056",
  "geo" : { },
  "id_str" : "260146016525885440",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth yay! : )",
  "id" : 260146016525885440,
  "in_reply_to_status_id" : 260145562513453056,
  "created_at" : "2012-10-21 22:30:18 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260143661768138754",
  "geo" : { },
  "id_str" : "260144567385464832",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu you horrible liberal you.. wanting ppl to have freedom and choice! ; )",
  "id" : 260144567385464832,
  "in_reply_to_status_id" : 260143661768138754,
  "created_at" : "2012-10-21 22:24:32 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260136860293160960",
  "geo" : { },
  "id_str" : "260138080986619904",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses LOL",
  "id" : 260138080986619904,
  "in_reply_to_status_id" : 260136860293160960,
  "created_at" : "2012-10-21 21:58:46 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260128909444657152",
  "geo" : { },
  "id_str" : "260129442729431040",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible im tryin'.. really i am..",
  "id" : 260129442729431040,
  "in_reply_to_status_id" : 260128909444657152,
  "created_at" : "2012-10-21 21:24:26 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260128946606178304",
  "text" : "the world is so topsyturvy..",
  "id" : 260128946606178304,
  "created_at" : "2012-10-21 21:22:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    }, {
      "name" : "Quick Revenue",
      "screen_name" : "jillstein2012",
      "indices" : [ 43, 57 ],
      "id_str" : "2210205158",
      "id" : 2210205158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260128456841506816",
  "text" : "RT @davidpakmanshow: We're trying to reach @jillstein2012 for an interview but not able to get anyone so far. Can anybody help?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quick Revenue",
        "screen_name" : "jillstein2012",
        "indices" : [ 22, 36 ],
        "id_str" : "2210205158",
        "id" : 2210205158
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260126203632050176",
    "text" : "We're trying to reach @jillstein2012 for an interview but not able to get anyone so far. Can anybody help?",
    "id" : 260126203632050176,
    "created_at" : "2012-10-21 21:11:34 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 260128456841506816,
  "created_at" : "2012-10-21 21:20:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Doc Holly)))",
      "screen_name" : "docholly",
      "indices" : [ 0, 9 ],
      "id_str" : "7573442",
      "id" : 7573442
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 10, 24 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/gZ6WFqcv",
      "expanded_url" : "http:\/\/www.veteranstoday.com\/2012\/10\/15\/breaking-romneys-bain-capitol-drug-front-for-bush-cartel-video\/",
      "display_url" : "veteranstoday.com\/2012\/10\/15\/bre\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "260123256911175680",
  "geo" : { },
  "id_str" : "260127826815102976",
  "in_reply_to_user_id" : 7573442,
  "text" : "@docholly @CharlesBivona did you see this &gt;&gt; http:\/\/t.co\/gZ6WFqcv - i watched but dont know what to think...",
  "id" : 260127826815102976,
  "in_reply_to_status_id" : 260123256911175680,
  "created_at" : "2012-10-21 21:18:01 +0000",
  "in_reply_to_screen_name" : "docholly",
  "in_reply_to_user_id_str" : "7573442",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 0, 14 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "(((Doc Holly)))",
      "screen_name" : "docholly",
      "indices" : [ 63, 72 ],
      "id_str" : "7573442",
      "id" : 7573442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260125580014526464",
  "geo" : { },
  "id_str" : "260126905167142912",
  "in_reply_to_user_id" : 45254966,
  "text" : "@CharlesBivona i think thats basically what i got out of it... @docholly",
  "id" : 260126905167142912,
  "in_reply_to_status_id" : 260125580014526464,
  "created_at" : "2012-10-21 21:14:21 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 0, 14 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260112937274970112",
  "geo" : { },
  "id_str" : "260120520064909312",
  "in_reply_to_user_id" : 45254966,
  "text" : "@CharlesBivona i saw that movie.. i didnt get the big hoopla. then again, im not all that smart...",
  "id" : 260120520064909312,
  "in_reply_to_status_id" : 260112937274970112,
  "created_at" : "2012-10-21 20:48:59 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romney",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "Romney",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260120232310484993",
  "text" : "RT @MWM4444: Ann #Romney says Mitt has always been no-choice; he just lied to get MA votes. IOW, #Romney will tell ANY lie to get electe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Romney",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "Romney",
        "indices" : [ 84, 91 ]
      }, {
        "text" : "p2",
        "indices" : [ 126, 129 ]
      }, {
        "text" : "tcot",
        "indices" : [ 130, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260113636666769409",
    "text" : "Ann #Romney says Mitt has always been no-choice; he just lied to get MA votes. IOW, #Romney will tell ANY lie to get elected. #p2 #tcot",
    "id" : 260113636666769409,
    "created_at" : "2012-10-21 20:21:38 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 260120232310484993,
  "created_at" : "2012-10-21 20:47:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260119980870352896",
  "text" : "RT @MWM4444: Jesus: I was hungry &amp; you said \"Eat cake.\" I was imprisoned &amp; you called me a parasite. I was sick &amp; you called ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260114942663995393",
    "text" : "Jesus: I was hungry &amp; you said \"Eat cake.\" I was imprisoned &amp; you called me a parasite. I was sick &amp; you called it preexisting.",
    "id" : 260114942663995393,
    "created_at" : "2012-10-21 20:26:49 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 260119980870352896,
  "created_at" : "2012-10-21 20:46:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Wendig",
      "screen_name" : "ChuckWendig",
      "indices" : [ 0, 12 ],
      "id_str" : "26029878",
      "id" : 26029878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260113576172326913",
  "geo" : { },
  "id_str" : "260119892089507840",
  "in_reply_to_user_id" : 26029878,
  "text" : "@ChuckWendig he's such a ((inserthorriblewordhere)) !!",
  "id" : 260119892089507840,
  "in_reply_to_status_id" : 260113576172326913,
  "created_at" : "2012-10-21 20:46:29 +0000",
  "in_reply_to_screen_name" : "ChuckWendig",
  "in_reply_to_user_id_str" : "26029878",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260109801311313920",
  "text" : "RT @ChristianDems: Matt 25: 36 Jesus says \"I needed clothes and you clothed me, I was sick and you looked after me, I was in prison and  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260109567927668736",
    "text" : "Matt 25: 36 Jesus says \"I needed clothes and you clothed me, I was sick and you looked after me, I was in prison and you came to visit me.'",
    "id" : 260109567927668736,
    "created_at" : "2012-10-21 20:05:28 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 260109801311313920,
  "created_at" : "2012-10-21 20:06:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260096649974648832",
  "text" : "there is no truth...",
  "id" : 260096649974648832,
  "created_at" : "2012-10-21 19:14:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtaining Bank",
      "screen_name" : "ak2sandiego",
      "indices" : [ 3, 15 ],
      "id_str" : "2185772580",
      "id" : 2185772580
    }, {
      "name" : "MoveOn.org",
      "screen_name" : "MoveOn",
      "indices" : [ 106, 113 ],
      "id_str" : "26657119",
      "id" : 26657119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/WbAIWysA",
      "expanded_url" : "http:\/\/www.moveon.org\/r?r=283089",
      "display_url" : "moveon.org\/r?r=283089"
    } ]
  },
  "geo" : { },
  "id_str" : "260089626113474560",
  "text" : "RT @ak2sandiego: Kevin Bacon Knows Exactly How To Destroy The GOP's War On Women http:\/\/t.co\/WbAIWysA via @moveon \/\/ I just love this! A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MoveOn.org",
        "screen_name" : "MoveOn",
        "indices" : [ 89, 96 ],
        "id_str" : "26657119",
        "id" : 26657119
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/WbAIWysA",
        "expanded_url" : "http:\/\/www.moveon.org\/r?r=283089",
        "display_url" : "moveon.org\/r?r=283089"
      } ]
    },
    "geo" : { },
    "id_str" : "260084370587664384",
    "text" : "Kevin Bacon Knows Exactly How To Destroy The GOP's War On Women http:\/\/t.co\/WbAIWysA via @moveon \/\/ I just love this! A must watch!",
    "id" : 260084370587664384,
    "created_at" : "2012-10-21 18:25:20 +0000",
    "user" : {
      "name" : "Alasscan\u21222018 Focus!",
      "screen_name" : "Alasscan_",
      "protected" : false,
      "id_str" : "26070572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796254636176879616\/bbqLGWVX_normal.jpg",
      "id" : 26070572,
      "verified" : false
    }
  },
  "id" : 260089626113474560,
  "created_at" : "2012-10-21 18:46:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260080593482698752",
  "text" : "RT @JosephRanseth: Instead of thinking in terms of good and bad, think in terms or creative or destructive.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260078151240122368",
    "text" : "Instead of thinking in terms of good and bad, think in terms or creative or destructive.",
    "id" : 260078151240122368,
    "created_at" : "2012-10-21 18:00:37 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 260080593482698752,
  "created_at" : "2012-10-21 18:10:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 0, 10 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260076192051392512",
  "geo" : { },
  "id_str" : "260077753666260992",
  "in_reply_to_user_id" : 82447359,
  "text" : "@ScottBaio aww.. daddy and his girl!",
  "id" : 260077753666260992,
  "in_reply_to_status_id" : 260076192051392512,
  "created_at" : "2012-10-21 17:59:03 +0000",
  "in_reply_to_screen_name" : "ScottBaio",
  "in_reply_to_user_id_str" : "82447359",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260076653844258816",
  "text" : "RT @TyrusBooks: I have found a portal to Heaven. It is Mount Dora, Florida. Don't remember the last time I was this at peace.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260075543737810945",
    "text" : "I have found a portal to Heaven. It is Mount Dora, Florida. Don't remember the last time I was this at peace.",
    "id" : 260075543737810945,
    "created_at" : "2012-10-21 17:50:16 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 260076653844258816,
  "created_at" : "2012-10-21 17:54:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SocialSecurity",
      "indices" : [ 58, 73 ]
    }, {
      "text" : "Medicare",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "budget",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/YMKYvV9V",
      "expanded_url" : "http:\/\/ow.ly\/eDPSw",
      "display_url" : "ow.ly\/eDPSw"
    } ]
  },
  "geo" : { },
  "id_str" : "260066131384082434",
  "text" : "RT @SenSanders: Sign here if you do not want cuts made to #SocialSecurity or #Medicare: http:\/\/t.co\/YMKYvV9V #budget",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SocialSecurity",
        "indices" : [ 42, 57 ]
      }, {
        "text" : "Medicare",
        "indices" : [ 61, 70 ]
      }, {
        "text" : "budget",
        "indices" : [ 93, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/YMKYvV9V",
        "expanded_url" : "http:\/\/ow.ly\/eDPSw",
        "display_url" : "ow.ly\/eDPSw"
      } ]
    },
    "geo" : { },
    "id_str" : "260064275568156672",
    "text" : "Sign here if you do not want cuts made to #SocialSecurity or #Medicare: http:\/\/t.co\/YMKYvV9V #budget",
    "id" : 260064275568156672,
    "created_at" : "2012-10-21 17:05:29 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 260066131384082434,
  "created_at" : "2012-10-21 17:12:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260065821978673152",
  "text" : "doesnt twitter archive our entire twitter history? but we can only access the last 3200? hmm...",
  "id" : 260065821978673152,
  "created_at" : "2012-10-21 17:11:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetbackup.com\" rel=\"nofollow\"\u003ETweetBackup\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tweetbackup",
      "screen_name" : "tweetbackup",
      "indices" : [ 10, 22 ],
      "id_str" : "18344173",
      "id" : 18344173
    }, {
      "name" : "Backupify",
      "screen_name" : "Backupify",
      "indices" : [ 26, 36 ],
      "id_str" : "3344387717",
      "id" : 3344387717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/NFrLL7Vw",
      "expanded_url" : "http:\/\/tweetbackup.com",
      "display_url" : "tweetbackup.com"
    } ]
  },
  "geo" : { },
  "id_str" : "260064121633001473",
  "text" : "I'm using @TweetBackup by @backupify to archive my tweets http:\/\/t.co\/NFrLL7Vw",
  "id" : 260064121633001473,
  "created_at" : "2012-10-21 17:04:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0950wizardparadox\u0950",
      "screen_name" : "wizard_paradox",
      "indices" : [ 3, 18 ],
      "id_str" : "125039271",
      "id" : 125039271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/e6chqf0Y",
      "expanded_url" : "http:\/\/fb.me\/1HvKf6uLB",
      "display_url" : "fb.me\/1HvKf6uLB"
    } ]
  },
  "geo" : { },
  "id_str" : "259815558474772481",
  "text" : "RT @wizard_paradox: Silly bunch of Kochs http:\/\/t.co\/e6chqf0Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/e6chqf0Y",
        "expanded_url" : "http:\/\/fb.me\/1HvKf6uLB",
        "display_url" : "fb.me\/1HvKf6uLB"
      } ]
    },
    "geo" : { },
    "id_str" : "259813220443897856",
    "text" : "Silly bunch of Kochs http:\/\/t.co\/e6chqf0Y",
    "id" : 259813220443897856,
    "created_at" : "2012-10-21 00:27:53 +0000",
    "user" : {
      "name" : "\u0950wizardparadox\u0950",
      "screen_name" : "wizard_paradox",
      "protected" : false,
      "id_str" : "125039271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2629926276\/d66caef6a8d1a1f4a50ba0af7343fc54_normal.jpeg",
      "id" : 125039271,
      "verified" : false
    }
  },
  "id" : 259815558474772481,
  "created_at" : "2012-10-21 00:37:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259796934225702912",
  "text" : "DD had a wonderful time and she made a new friend! Cousin wants to take her to more cons. : )",
  "id" : 259796934225702912,
  "created_at" : "2012-10-20 23:23:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259775715740884992",
  "geo" : { },
  "id_str" : "259779984921604097",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ((grumblegrumblegrumble)) lol",
  "id" : 259779984921604097,
  "in_reply_to_status_id" : 259775715740884992,
  "created_at" : "2012-10-20 22:15:49 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259775713413058560",
  "text" : "@SamsaricWarrior that looks familiar.. Claire's? lol looks good on you actually! : )",
  "id" : 259775713413058560,
  "created_at" : "2012-10-20 21:58:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259756518222733312",
  "text" : "RT @BeasBookNook: I fed the cat. That should buy me 5 minutes of peace. Maybe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259755926830080001",
    "text" : "I fed the cat. That should buy me 5 minutes of peace. Maybe.",
    "id" : 259755926830080001,
    "created_at" : "2012-10-20 20:40:13 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 259756518222733312,
  "created_at" : "2012-10-20 20:42:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259756362723119104",
  "text" : "only thing i can do is leave it up to the universe..lol.",
  "id" : 259756362723119104,
  "created_at" : "2012-10-20 20:41:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Jones",
      "screen_name" : "mattjonesisdead",
      "indices" : [ 3, 19 ],
      "id_str" : "239542695",
      "id" : 239542695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259739468926431232",
  "text" : "RT @mattjonesisdead: How do people not realize that Gordon Gecko is running for president?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259736262611722240",
    "text" : "How do people not realize that Gordon Gecko is running for president?",
    "id" : 259736262611722240,
    "created_at" : "2012-10-20 19:22:05 +0000",
    "user" : {
      "name" : "Matt Jones",
      "screen_name" : "mattjonesisdead",
      "protected" : false,
      "id_str" : "239542695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587475338852048898\/6RrYpLwR_normal.jpg",
      "id" : 239542695,
      "verified" : true
    }
  },
  "id" : 259739468926431232,
  "created_at" : "2012-10-20 19:34:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AspirantSG",
      "screen_name" : "AspirantSG",
      "indices" : [ 3, 14 ],
      "id_str" : "138594249",
      "id" : 138594249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "halfcar",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/n0N2DS1f",
      "expanded_url" : "http:\/\/bit.ly\/ViN3Sm",
      "display_url" : "bit.ly\/ViN3Sm"
    } ]
  },
  "geo" : { },
  "id_str" : "259735470261563392",
  "text" : "RT @AspirantSG: RT Pls! OMG, #halfcar spotted at Expo! How did a car get cut into half?!?! Spooky .... view via http:\/\/t.co\/n0N2DS1f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "halfcar",
        "indices" : [ 13, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/n0N2DS1f",
        "expanded_url" : "http:\/\/bit.ly\/ViN3Sm",
        "display_url" : "bit.ly\/ViN3Sm"
      } ]
    },
    "geo" : { },
    "id_str" : "259486738504892416",
    "text" : "RT Pls! OMG, #halfcar spotted at Expo! How did a car get cut into half?!?! Spooky .... view via http:\/\/t.co\/n0N2DS1f",
    "id" : 259486738504892416,
    "created_at" : "2012-10-20 02:50:34 +0000",
    "user" : {
      "name" : "AspirantSG",
      "screen_name" : "AspirantSG",
      "protected" : false,
      "id_str" : "138594249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701397899624644609\/gjGFsogE_normal.png",
      "id" : 138594249,
      "verified" : false
    }
  },
  "id" : 259735470261563392,
  "created_at" : "2012-10-20 19:18:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/HP3Zu0oL",
      "expanded_url" : "http:\/\/billmoyers.com\/segment\/matt-taibbi-and-chrystia-freeland-on-the-one-percents-power-and-privileges\/#.UILc2kwvKEO.twitter",
      "display_url" : "billmoyers.com\/segment\/matt-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "259722600555630592",
  "text" : "Matt Taibbi and Chrystia Freeland on the One Percent\u2019s Power and Privileges http:\/\/t.co\/HP3Zu0oL",
  "id" : 259722600555630592,
  "created_at" : "2012-10-20 18:27:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259720529706090496",
  "text" : "omg.. my DD made a friend at the cos con.. im so excited..lol",
  "id" : 259720529706090496,
  "created_at" : "2012-10-20 18:19:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259708711948394496",
  "text" : "RT @kimmy_cupcakes_: In sickness, health &amp; wanting to claw each others eyes out",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259690323335331840",
    "text" : "In sickness, health &amp; wanting to claw each others eyes out",
    "id" : 259690323335331840,
    "created_at" : "2012-10-20 16:19:32 +0000",
    "user" : {
      "name" : "Kim",
      "screen_name" : "Kim_pulsive",
      "protected" : false,
      "id_str" : "19187478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454458747805396992\/1rx9k3js_normal.jpeg",
      "id" : 19187478,
      "verified" : false
    }
  },
  "id" : 259708711948394496,
  "created_at" : "2012-10-20 17:32:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259703653869432832",
  "text" : "RT @TheGoldenMirror: Don't question how it works. Trust in that it does.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259703186879807490",
    "text" : "Don't question how it works. Trust in that it does.",
    "id" : 259703186879807490,
    "created_at" : "2012-10-20 17:10:39 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 259703653869432832,
  "created_at" : "2012-10-20 17:12:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/qfkZ605p",
      "expanded_url" : "http:\/\/youtu.be\/fnuwFx0mpns",
      "display_url" : "youtu.be\/fnuwFx0mpns"
    } ]
  },
  "geo" : { },
  "id_str" : "259691297022025728",
  "text" : "interesting point: freedom of religion vs freedom of worship 38:16 to 41:12 http:\/\/t.co\/qfkZ605p",
  "id" : 259691297022025728,
  "created_at" : "2012-10-20 16:23:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Alter",
      "screen_name" : "jonathanalter",
      "indices" : [ 3, 17 ],
      "id_str" : "21844854",
      "id" : 21844854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259688440143163392",
  "text" : "RT @jonathanalter: Is it really ok for Tagg Romney to have stake in voting machine co with no transparency in battleground states?  http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/eU1xwJOt",
        "expanded_url" : "http:\/\/www.allvoices.com\/contributed-news\/13221476-romney-family-buys-voting-machines-through-bain-capital-investment",
        "display_url" : "allvoices.com\/contributed-ne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "259492367730634753",
    "text" : "Is it really ok for Tagg Romney to have stake in voting machine co with no transparency in battleground states?  http:\/\/t.co\/eU1xwJOt",
    "id" : 259492367730634753,
    "created_at" : "2012-10-20 03:12:56 +0000",
    "user" : {
      "name" : "Jonathan Alter",
      "screen_name" : "jonathanalter",
      "protected" : false,
      "id_str" : "21844854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544309342661398528\/DrZa5EUZ_normal.jpeg",
      "id" : 21844854,
      "verified" : true
    }
  },
  "id" : 259688440143163392,
  "created_at" : "2012-10-20 16:12:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259688298358906881",
  "text" : "poor hubby. he's such a good man and he's stuck w.. me. im often unwell.",
  "id" : 259688298358906881,
  "created_at" : "2012-10-20 16:11:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259685496719020032",
  "text" : "have been breaking out in various spots past week. today feel a bit sick. bleh.",
  "id" : 259685496719020032,
  "created_at" : "2012-10-20 16:00:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259672080147161088",
  "text" : "RT @luminanceriver: We are each piece of a grander puzzle.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259671452087906304",
    "text" : "We are each piece of a grander puzzle.",
    "id" : 259671452087906304,
    "created_at" : "2012-10-20 15:04:33 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 259672080147161088,
  "created_at" : "2012-10-20 15:07:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259664344344850432",
  "text" : "RT @TheGodLight: If something angers you, think again, this is where your lesson lies, in understanding why!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259662586650447874",
    "text" : "If something angers you, think again, this is where your lesson lies, in understanding why!",
    "id" : 259662586650447874,
    "created_at" : "2012-10-20 14:29:19 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 259664344344850432,
  "created_at" : "2012-10-20 14:36:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "indices" : [ 3, 19 ],
      "id_str" : "179121328",
      "id" : 179121328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/rYAqbUyy",
      "expanded_url" : "http:\/\/gaw.kr\/T3wwtQ",
      "display_url" : "gaw.kr\/T3wwtQ"
    } ]
  },
  "geo" : { },
  "id_str" : "259663639152316416",
  "text" : "RT @thesilverspiral: http:\/\/t.co\/rYAqbUyy This MO pastor speaking out about gay marriage has a stunning twist at the end. Watch the whol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lgbt",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/rYAqbUyy",
        "expanded_url" : "http:\/\/gaw.kr\/T3wwtQ",
        "display_url" : "gaw.kr\/T3wwtQ"
      } ]
    },
    "geo" : { },
    "id_str" : "259657382332882944",
    "text" : "http:\/\/t.co\/rYAqbUyy This MO pastor speaking out about gay marriage has a stunning twist at the end. Watch the whole thing. APPLAUSE. #lgbt",
    "id" : 259657382332882944,
    "created_at" : "2012-10-20 14:08:38 +0000",
    "user" : {
      "name" : "Naya Aerodiode",
      "screen_name" : "thesilverspiral",
      "protected" : false,
      "id_str" : "179121328",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476331163322052609\/9eQZmrqN_normal.jpeg",
      "id" : 179121328,
      "verified" : false
    }
  },
  "id" : 259663639152316416,
  "created_at" : "2012-10-20 14:33:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259661685663625216",
  "text" : "DD is at her 1st cos-con today w her cousin. she dressed up as Shadow.",
  "id" : 259661685663625216,
  "created_at" : "2012-10-20 14:25:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259661327025463296",
  "text" : "@SamsaricWarrior awesome! my DD would love that!",
  "id" : 259661327025463296,
  "created_at" : "2012-10-20 14:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259659523348897792",
  "geo" : { },
  "id_str" : "259661077481127936",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell i love biscuits! lol",
  "id" : 259661077481127936,
  "in_reply_to_status_id" : 259659523348897792,
  "created_at" : "2012-10-20 14:23:19 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259360808310546432",
  "geo" : { },
  "id_str" : "259659790685466624",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep i knew i shouldnt have used that word..lol : )",
  "id" : 259659790685466624,
  "in_reply_to_status_id" : 259360808310546432,
  "created_at" : "2012-10-20 14:18:13 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "indices" : [ 3, 17 ],
      "id_str" : "102651839",
      "id" : 102651839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "God",
      "indices" : [ 19, 23 ]
    }, {
      "text" : "Love",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259445475558694912",
  "text" : "RT @ificouldtellu: #God cares little about our religious affiliation or church\nmembership. #Love is not limited to any one religion or e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "God",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "Love",
        "indices" : [ 72, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259445207890817024",
    "text" : "#God cares little about our religious affiliation or church\nmembership. #Love is not limited to any one religion or even religion at\nall.",
    "id" : 259445207890817024,
    "created_at" : "2012-10-20 00:05:32 +0000",
    "user" : {
      "name" : "Joy",
      "screen_name" : "ificouldtellu",
      "protected" : false,
      "id_str" : "102651839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3467164841\/122f1ba6b66d9a508ca9cabe911847d8_normal.jpeg",
      "id" : 102651839,
      "verified" : false
    }
  },
  "id" : 259445475558694912,
  "created_at" : "2012-10-20 00:06:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bainport.com",
      "screen_name" : "SaveSensataJobs",
      "indices" : [ 3, 19 ],
      "id_str" : "761709210",
      "id" : 761709210
    }, {
      "name" : "Ustream",
      "screen_name" : "Ustream",
      "indices" : [ 76, 84 ],
      "id_str" : "5490392",
      "id" : 5490392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bainport",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/qkaSdnkF",
      "expanded_url" : "http:\/\/ustre.am\/PI1P",
      "display_url" : "ustre.am\/PI1P"
    } ]
  },
  "geo" : { },
  "id_str" : "259444224464932864",
  "text" : "RT @SaveSensataJobs: I'm broadcasting \"Live from #Bainport Ed Show\" live on @Ustream. Come watch and chat! - http:\/\/t.co\/qkaSdnkF (6:39pm)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ustream.tv\" rel=\"nofollow\"\u003EUstream.TV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ustream",
        "screen_name" : "Ustream",
        "indices" : [ 55, 63 ],
        "id_str" : "5490392",
        "id" : 5490392
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bainport",
        "indices" : [ 28, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/qkaSdnkF",
        "expanded_url" : "http:\/\/ustre.am\/PI1P",
        "display_url" : "ustre.am\/PI1P"
      } ]
    },
    "geo" : { },
    "id_str" : "259438693037780992",
    "text" : "I'm broadcasting \"Live from #Bainport Ed Show\" live on @Ustream. Come watch and chat! - http:\/\/t.co\/qkaSdnkF (6:39pm)",
    "id" : 259438693037780992,
    "created_at" : "2012-10-19 23:39:39 +0000",
    "user" : {
      "name" : "Bainport.com",
      "screen_name" : "SaveSensataJobs",
      "protected" : false,
      "id_str" : "761709210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2642442612\/b16543919541e7da3ff4f7aa95696954_normal.jpeg",
      "id" : 761709210,
      "verified" : false
    }
  },
  "id" : 259444224464932864,
  "created_at" : "2012-10-20 00:01:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259443754824503296",
  "text" : "RT @Buddhaworld: you can not step out of your mind, that means there will never be a proof of an outside world. Volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259441594720190465",
    "text" : "you can not step out of your mind, that means there will never be a proof of an outside world. Volko",
    "id" : 259441594720190465,
    "created_at" : "2012-10-19 23:51:11 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 259443754824503296,
  "created_at" : "2012-10-19 23:59:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Soulseeds",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/5UCgiUOn",
      "expanded_url" : "http:\/\/tinyurl.com\/9839xox",
      "display_url" : "tinyurl.com\/9839xox"
    } ]
  },
  "geo" : { },
  "id_str" : "259408819384369152",
  "text" : "RT @Soulseedzforall: Not helping is sometimes the most helpful way to help people help themselves. #Soulseeds http:\/\/t.co\/5UCgiUOn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Soulseeds",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/5UCgiUOn",
        "expanded_url" : "http:\/\/tinyurl.com\/9839xox",
        "display_url" : "tinyurl.com\/9839xox"
      } ]
    },
    "geo" : { },
    "id_str" : "259408270748442625",
    "text" : "Not helping is sometimes the most helpful way to help people help themselves. #Soulseeds http:\/\/t.co\/5UCgiUOn",
    "id" : 259408270748442625,
    "created_at" : "2012-10-19 21:38:45 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 259408819384369152,
  "created_at" : "2012-10-19 21:40:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259398843223900160",
  "geo" : { },
  "id_str" : "259401789961535488",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible what?! romney \/wants\/ us in war w iran!",
  "id" : 259401789961535488,
  "in_reply_to_status_id" : 259398843223900160,
  "created_at" : "2012-10-19 21:13:00 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 0, 9 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "Tessa Triplett",
      "screen_name" : "SociologyGirl",
      "indices" : [ 10, 24 ],
      "id_str" : "23808511",
      "id" : 23808511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259399280404619264",
  "geo" : { },
  "id_str" : "259401414063845376",
  "in_reply_to_user_id" : 184401626,
  "text" : "@AniKnits @SociologyGirl im INFP : ) (and introvert does not = shy.. just means you need down time to regenerate)",
  "id" : 259401414063845376,
  "in_reply_to_status_id" : 259399280404619264,
  "created_at" : "2012-10-19 21:11:31 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Damico",
      "screen_name" : "DCofStaff",
      "indices" : [ 3, 13 ],
      "id_str" : "25001165",
      "id" : 25001165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/S7LArRE9",
      "expanded_url" : "http:\/\/www.veteranstoday.com\/2012\/10\/15\/breaking-romneys-bain-capitol-drug-front-for-bush-cartel-video\/",
      "display_url" : "veteranstoday.com\/2012\/10\/15\/bre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "259398763221757952",
  "text" : "RT @DCofStaff: Breaking:  Romney\u2019s \u201CBain Capital\u201D Drug Front For Bush Cartel (Video)  http:\/\/t.co\/S7LArRE9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/S7LArRE9",
        "expanded_url" : "http:\/\/www.veteranstoday.com\/2012\/10\/15\/breaking-romneys-bain-capitol-drug-front-for-bush-cartel-video\/",
        "display_url" : "veteranstoday.com\/2012\/10\/15\/bre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "259377113130491904",
    "text" : "Breaking:  Romney\u2019s \u201CBain Capital\u201D Drug Front For Bush Cartel (Video)  http:\/\/t.co\/S7LArRE9",
    "id" : 259377113130491904,
    "created_at" : "2012-10-19 19:34:57 +0000",
    "user" : {
      "name" : "Michael Damico",
      "screen_name" : "DCofStaff",
      "protected" : false,
      "id_str" : "25001165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/181994509\/Michael_Damico_7_normal.jpg",
      "id" : 25001165,
      "verified" : false
    }
  },
  "id" : 259398763221757952,
  "created_at" : "2012-10-19 21:00:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moosep",
      "screen_name" : "moosep",
      "indices" : [ 0, 7 ],
      "id_str" : "13118692",
      "id" : 13118692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259348493192294401",
  "geo" : { },
  "id_str" : "259352453768699904",
  "in_reply_to_user_id" : 13118692,
  "text" : "@moosep you look distinguished! : )",
  "id" : 259352453768699904,
  "in_reply_to_status_id" : 259348493192294401,
  "created_at" : "2012-10-19 17:56:58 +0000",
  "in_reply_to_screen_name" : "moosep",
  "in_reply_to_user_id_str" : "13118692",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgia Lewis",
      "screen_name" : "georgialewis76",
      "indices" : [ 0, 15 ],
      "id_str" : "233956511",
      "id" : 233956511
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 78, 90 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259308740619157504",
  "geo" : { },
  "id_str" : "259312528562208768",
  "in_reply_to_user_id" : 233956511,
  "text" : "@georgialewis76 LOL.. me, too! i love VJ.. he's like my twitter brother..lol  @VirgoJohnny",
  "id" : 259312528562208768,
  "in_reply_to_status_id" : 259308740619157504,
  "created_at" : "2012-10-19 15:18:19 +0000",
  "in_reply_to_screen_name" : "georgialewis76",
  "in_reply_to_user_id_str" : "233956511",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Georgia Lewis",
      "screen_name" : "georgialewis76",
      "indices" : [ 13, 28 ],
      "id_str" : "233956511",
      "id" : 233956511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259307214576156673",
  "geo" : { },
  "id_str" : "259308039537041408",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny @georgialewis76 think im getting jealous here..lol ; )",
  "id" : 259308039537041408,
  "in_reply_to_status_id" : 259307214576156673,
  "created_at" : "2012-10-19 15:00:28 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259296711451762688",
  "geo" : { },
  "id_str" : "259297718890024960",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses yeah.. he's not hyper.. but productive. i just dont care about certain stuff. im also very.. anal in way i do things..lol",
  "id" : 259297718890024960,
  "in_reply_to_status_id" : 259296711451762688,
  "created_at" : "2012-10-19 14:19:28 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259295872129564672",
  "text" : "RT @ShipsofSong: There are many paths to enlightenment.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259295586853982208",
    "text" : "There are many paths to enlightenment.",
    "id" : 259295586853982208,
    "created_at" : "2012-10-19 14:11:00 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 259295872129564672,
  "created_at" : "2012-10-19 14:12:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259288914580365312",
  "geo" : { },
  "id_str" : "259294539473371136",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses dh and i are similar to that. he's the worker bee and im the sloth..lol",
  "id" : 259294539473371136,
  "in_reply_to_status_id" : 259288914580365312,
  "created_at" : "2012-10-19 14:06:50 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabby Bernstein",
      "screen_name" : "GabbyBernstein",
      "indices" : [ 3, 18 ],
      "id_str" : "20522531",
      "id" : 20522531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpiritJunkie",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259114100938928128",
  "text" : "RT @GabbyBernstein: Forgiveness helps us detach from the negative energy cord that ties us to our enemies. #SpiritJunkie http:\/\/t.co\/hfY ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SpiritJunkie",
        "indices" : [ 87, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/hfYvPnWf",
        "expanded_url" : "http:\/\/www.gabbyb.tv",
        "display_url" : "gabbyb.tv"
      } ]
    },
    "geo" : { },
    "id_str" : "259112456926945280",
    "text" : "Forgiveness helps us detach from the negative energy cord that ties us to our enemies. #SpiritJunkie http:\/\/t.co\/hfYvPnWf",
    "id" : 259112456926945280,
    "created_at" : "2012-10-19 02:03:18 +0000",
    "user" : {
      "name" : "Gabby Bernstein",
      "screen_name" : "GabbyBernstein",
      "protected" : false,
      "id_str" : "20522531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619291111647916033\/0C7Uq_-T_normal.jpg",
      "id" : 20522531,
      "verified" : true
    }
  },
  "id" : 259114100938928128,
  "created_at" : "2012-10-19 02:09:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    }, {
      "name" : "Rick Santorum",
      "screen_name" : "RickSantorum",
      "indices" : [ 40, 53 ],
      "id_str" : "58379000",
      "id" : 58379000
    }, {
      "name" : "Howard Dean",
      "screen_name" : "GovHowardDean",
      "indices" : [ 90, 104 ],
      "id_str" : "603025587",
      "id" : 603025587
    }, {
      "name" : "Cornell University",
      "screen_name" : "Cornell",
      "indices" : [ 108, 116 ],
      "id_str" : "17369110",
      "id" : 17369110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259089186596999168",
  "text" : "RT @LOLGOP: Please proceed, Senator. MT @RickSantorum: I'm looking forward to my debate w @GovHowardDean at @Cornell 8pm ET http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Santorum",
        "screen_name" : "RickSantorum",
        "indices" : [ 28, 41 ],
        "id_str" : "58379000",
        "id" : 58379000
      }, {
        "name" : "Howard Dean",
        "screen_name" : "GovHowardDean",
        "indices" : [ 78, 92 ],
        "id_str" : "603025587",
        "id" : 603025587
      }, {
        "name" : "Cornell University",
        "screen_name" : "Cornell",
        "indices" : [ 96, 104 ],
        "id_str" : "17369110",
        "id" : 17369110
      }, {
        "name" : "YAF",
        "screen_name" : "yaf",
        "indices" : [ 133, 137 ],
        "id_str" : "16148677",
        "id" : 16148677
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/xATlYJ5J",
        "expanded_url" : "http:\/\/ptrtvoic.es\/RIKYZ9",
        "display_url" : "ptrtvoic.es\/RIKYZ9"
      } ]
    },
    "geo" : { },
    "id_str" : "259074326710583296",
    "text" : "Please proceed, Senator. MT @RickSantorum: I'm looking forward to my debate w @GovHowardDean at @Cornell 8pm ET http:\/\/t.co\/xATlYJ5J @YAF",
    "id" : 259074326710583296,
    "created_at" : "2012-10-18 23:31:47 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649031186845560832\/c385MSMQ_normal.jpg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 259089186596999168,
  "created_at" : "2012-10-19 00:30:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259086622522474496",
  "text" : "RT @davidpakmanshow: Does anyone know a real undecided voter that we could interview?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259085938335039488",
    "text" : "Does anyone know a real undecided voter that we could interview?",
    "id" : 259085938335039488,
    "created_at" : "2012-10-19 00:17:55 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 259086622522474496,
  "created_at" : "2012-10-19 00:20:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moxie Hart",
      "screen_name" : "moxie_hart",
      "indices" : [ 3, 14 ],
      "id_str" : "17165443",
      "id" : 17165443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259086322625560576",
  "text" : "RT @moxie_hart: I just read that \"sex is a luxury that should be earned if you are physically attractive or fiscally responsible\" on tum ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/janetter.net\/\" rel=\"nofollow\"\u003EJanetter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259085232832126976",
    "text" : "I just read that \"sex is a luxury that should be earned if you are physically attractive or fiscally responsible\" on tumblr.... sigh.",
    "id" : 259085232832126976,
    "created_at" : "2012-10-19 00:15:07 +0000",
    "user" : {
      "name" : "Moxie Hart",
      "screen_name" : "moxie_hart",
      "protected" : false,
      "id_str" : "17165443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787765007673069568\/KoX_CNph_normal.jpg",
      "id" : 17165443,
      "verified" : false
    }
  },
  "id" : 259086322625560576,
  "created_at" : "2012-10-19 00:19:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IVNetwork is now IVN",
      "screen_name" : "ivnetwork",
      "indices" : [ 3, 13 ],
      "id_str" : "2648924264",
      "id" : 2648924264
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indyvote",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259076573712482304",
  "text" : "RT @IVNetwork: Stein's rebuttal: \"Move to a medicare for all to remove the massive red tape and bureaucracy\"  #indyvote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetchat.com\/\" rel=\"nofollow\"\u003ETweetChat\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indyvote",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259074853288685568",
    "text" : "Stein's rebuttal: \"Move to a medicare for all to remove the massive red tape and bureaucracy\"  #indyvote",
    "id" : 259074853288685568,
    "created_at" : "2012-10-18 23:33:53 +0000",
    "user" : {
      "name" : "Independent Voter",
      "screen_name" : "ivn",
      "protected" : false,
      "id_str" : "16545933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2945892490\/043a08c1f442f18fdb637ac52aa46586_normal.jpeg",
      "id" : 16545933,
      "verified" : true
    }
  },
  "id" : 259076573712482304,
  "created_at" : "2012-10-18 23:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259075896705683456",
  "geo" : { },
  "id_str" : "259076382221541376",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell im with you on that..lol",
  "id" : 259076382221541376,
  "in_reply_to_status_id" : 259075896705683456,
  "created_at" : "2012-10-18 23:39:57 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259018315178065920",
  "geo" : { },
  "id_str" : "259030821657272320",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH he's so damn arrogant... and no compassion.",
  "id" : 259030821657272320,
  "in_reply_to_status_id" : 259018315178065920,
  "created_at" : "2012-10-18 20:38:55 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lam",
      "indices" : [ 76, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/KPVAURkB",
      "expanded_url" : "http:\/\/bit.ly\/VeEeJk",
      "display_url" : "bit.ly\/VeEeJk"
    } ]
  },
  "geo" : { },
  "id_str" : "258968115629666304",
  "text" : "RT @aliceinthewater: Gays Ruined Canadian Thanksgiving\nhttp:\/\/t.co\/KPVAURkB #lam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lam",
        "indices" : [ 55, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/KPVAURkB",
        "expanded_url" : "http:\/\/bit.ly\/VeEeJk",
        "display_url" : "bit.ly\/VeEeJk"
      } ]
    },
    "geo" : { },
    "id_str" : "258967460705882112",
    "text" : "Gays Ruined Canadian Thanksgiving\nhttp:\/\/t.co\/KPVAURkB #lam",
    "id" : 258967460705882112,
    "created_at" : "2012-10-18 16:27:08 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 258968115629666304,
  "created_at" : "2012-10-18 16:29:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258966899004678144",
  "geo" : { },
  "id_str" : "258967314878324736",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater on fire with anger maybe? LOL",
  "id" : 258967314878324736,
  "in_reply_to_status_id" : 258966899004678144,
  "created_at" : "2012-10-18 16:26:33 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0435\u043F\u043E\u043C\u043D\u044F\u0449\u0438\u0445 \u0412\u0438\u043A\u0442\u043E\u0440",
      "screen_name" : "glassdimlyfaith",
      "indices" : [ 3, 19 ],
      "id_str" : "2826504890",
      "id" : 2826504890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258944167781220353",
  "text" : "RT @glassdimlyfaith: It seems our society has forgotten that the moral\/character dimension is more important to goodness and success tha ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258943950268821504",
    "text" : "It seems our society has forgotten that the moral\/character dimension is more important to goodness and success than standardized testing.",
    "id" : 258943950268821504,
    "created_at" : "2012-10-18 14:53:43 +0000",
    "user" : {
      "name" : "Jeremy John",
      "screen_name" : "glassdimly",
      "protected" : false,
      "id_str" : "247971836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/411886255576592384\/HounElWp_normal.jpeg",
      "id" : 247971836,
      "verified" : false
    }
  },
  "id" : 258944167781220353,
  "created_at" : "2012-10-18 14:54:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/yOafpTYu",
      "expanded_url" : "http:\/\/www.cnn.com\/2012\/10\/18\/travel\/australia-yacht-rescue\/index.html?hpt=hp_t3",
      "display_url" : "cnn.com\/2012\/10\/18\/tra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258938606964584448",
  "text" : "RT @JacksonPearce: Way to go, Canadians! http:\/\/t.co\/yOafpTYu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 42 ],
        "url" : "http:\/\/t.co\/yOafpTYu",
        "expanded_url" : "http:\/\/www.cnn.com\/2012\/10\/18\/travel\/australia-yacht-rescue\/index.html?hpt=hp_t3",
        "display_url" : "cnn.com\/2012\/10\/18\/tra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258937960878202881",
    "text" : "Way to go, Canadians! http:\/\/t.co\/yOafpTYu",
    "id" : 258937960878202881,
    "created_at" : "2012-10-18 14:29:55 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 258938606964584448,
  "created_at" : "2012-10-18 14:32:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258924625751310337",
  "geo" : { },
  "id_str" : "258927937275965440",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time woohoo!!! ((jumpingaround)) you go, girl!! : )",
  "id" : 258927937275965440,
  "in_reply_to_status_id" : 258924625751310337,
  "created_at" : "2012-10-18 13:50:05 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    }, {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 116, 132 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/v4lARkKI",
      "expanded_url" : "http:\/\/wp.me\/p2H7Jj-1uj",
      "display_url" : "wp.me\/p2H7Jj-1uj"
    } ]
  },
  "geo" : { },
  "id_str" : "258923521395261440",
  "text" : "RT @oceanshaman: Chris Hayes: How Romney broke the rules of the debate, and why it matters http:\/\/t.co\/v4lARkKI via @wordpressdotcom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 99, 115 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/v4lARkKI",
        "expanded_url" : "http:\/\/wp.me\/p2H7Jj-1uj",
        "display_url" : "wp.me\/p2H7Jj-1uj"
      } ]
    },
    "geo" : { },
    "id_str" : "258921002153697280",
    "text" : "Chris Hayes: How Romney broke the rules of the debate, and why it matters http:\/\/t.co\/v4lARkKI via @wordpressdotcom",
    "id" : 258921002153697280,
    "created_at" : "2012-10-18 13:22:32 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 258923521395261440,
  "created_at" : "2012-10-18 13:32:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    }, {
      "name" : "Debbi Myers",
      "screen_name" : "OhioDebbi",
      "indices" : [ 22, 32 ],
      "id_str" : "44146672",
      "id" : 44146672
    }, {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 34, 48 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Christians4Obama",
      "indices" : [ 78, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258921321382170625",
  "text" : "RT @ChristianDems: RT @ohiodebbi: @ChristianDems How does one \"Look illegal?\" #Christians4Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Debbi Myers",
        "screen_name" : "OhioDebbi",
        "indices" : [ 3, 13 ],
        "id_str" : "44146672",
        "id" : 44146672
      }, {
        "name" : "Christian Democrats",
        "screen_name" : "ChristianDems",
        "indices" : [ 15, 29 ],
        "id_str" : "27392088",
        "id" : 27392088
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Christians4Obama",
        "indices" : [ 59, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258399731481448448",
    "text" : "RT @ohiodebbi: @ChristianDems How does one \"Look illegal?\" #Christians4Obama",
    "id" : 258399731481448448,
    "created_at" : "2012-10-17 02:51:11 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 258921321382170625,
  "created_at" : "2012-10-18 13:23:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258735971317735424",
  "geo" : { },
  "id_str" : "258736991213076480",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth uh-oh.. lol",
  "id" : 258736991213076480,
  "in_reply_to_status_id" : 258735971317735424,
  "created_at" : "2012-10-18 01:11:20 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258729349199572994",
  "text" : "RT @wakeupchat: The quote from Mitt that SHOULD be getting more press: \"If you're going to have women in the workforce\". Speaks volumes. #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 121, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258729040351997952",
    "text" : "The quote from Mitt that SHOULD be getting more press: \"If you're going to have women in the workforce\". Speaks volumes. #p2",
    "id" : 258729040351997952,
    "created_at" : "2012-10-18 00:39:44 +0000",
    "user" : {
      "name" : "Lauri",
      "screen_name" : "CmonPeopleNow",
      "protected" : false,
      "id_str" : "185242957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795782571720372225\/F8kNpdqr_normal.jpg",
      "id" : 185242957,
      "verified" : false
    }
  },
  "id" : 258729349199572994,
  "created_at" : "2012-10-18 00:40:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "116807098",
      "id" : 116807098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258717494452305920",
  "geo" : { },
  "id_str" : "258723102966566912",
  "in_reply_to_user_id" : 116807098,
  "text" : "@_CabinGirl aww.. what a cutie. hope he'll be okay.",
  "id" : 258723102966566912,
  "in_reply_to_status_id" : 258717494452305920,
  "created_at" : "2012-10-18 00:16:09 +0000",
  "in_reply_to_screen_name" : "_CabinGirl",
  "in_reply_to_user_id_str" : "116807098",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "116807098",
      "id" : 116807098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258722481337167872",
  "text" : "RT @_CabinGirl: Just had most bizarre experience: went to mailbox and something b&amp;w hissed at me. Feral cat? Nope. Wounded Ruddy Duc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/_CabinGirl\/status\/258717494452305920\/photo\/1",
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/clbl60Mg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A5cmMMJCQAE8AF0.jpg",
        "id_str" : "258717494456500225",
        "id" : 258717494456500225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5cmMMJCQAE8AF0.jpg",
        "sizes" : [ {
          "h" : 1840,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/clbl60Mg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258717494452305920",
    "text" : "Just had most bizarre experience: went to mailbox and something b&amp;w hissed at me. Feral cat? Nope. Wounded Ruddy Duck! http:\/\/t.co\/clbl60Mg",
    "id" : 258717494452305920,
    "created_at" : "2012-10-17 23:53:53 +0000",
    "user" : {
      "name" : "Tami Vogel",
      "screen_name" : "_CabinGirl",
      "protected" : false,
      "id_str" : "116807098",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713963701\/me_and_fawnsm_normal.jpg",
      "id" : 116807098,
      "verified" : false
    }
  },
  "id" : 258722481337167872,
  "created_at" : "2012-10-18 00:13:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Weinstein",
      "screen_name" : "AdamWeinstein",
      "indices" : [ 3, 17 ],
      "id_str" : "20725994",
      "id" : 20725994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258722048157835264",
  "text" : "RT @AdamWeinstein: What if a \"religious employer\" decided  that women &amp; blacks shouldn't work outside the home? Would GOPers protect ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258709965731160064",
    "text" : "What if a \"religious employer\" decided  that women &amp; blacks shouldn't work outside the home? Would GOPers protect those \"religious rights\"?",
    "id" : 258709965731160064,
    "created_at" : "2012-10-17 23:23:57 +0000",
    "user" : {
      "name" : "Adam Weinstein",
      "screen_name" : "AdamWeinstein",
      "protected" : false,
      "id_str" : "20725994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795067297278918656\/FJI-_YlH_normal.jpg",
      "id" : 20725994,
      "verified" : true
    }
  },
  "id" : 258722048157835264,
  "created_at" : "2012-10-18 00:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258719361559310336",
  "text" : "RT @UnshackleUS: Economic FREEDOM doesn\u2019t mean that a corporation in search of short-term profits is free to do long-term damage to ever ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258714170277634049",
    "text" : "Economic FREEDOM doesn\u2019t mean that a corporation in search of short-term profits is free to do long-term damage to everybody\u2019s environment.",
    "id" : 258714170277634049,
    "created_at" : "2012-10-17 23:40:39 +0000",
    "user" : {
      "name" : "Captain Clarion",
      "screen_name" : "citizensrock",
      "protected" : false,
      "id_str" : "271030180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500767478197153792\/necyH3Wl_normal.png",
      "id" : 271030180,
      "verified" : false
    }
  },
  "id" : 258719361559310336,
  "created_at" : "2012-10-18 00:01:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    }, {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 21, 35 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "icymi",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/7b6NzgGK",
      "expanded_url" : "http:\/\/thkpr.gs\/RFs09b",
      "display_url" : "thkpr.gs\/RFs09b"
    } ]
  },
  "geo" : { },
  "id_str" : "258718808494178304",
  "text" : "RT @Squirrely007: RT @thinkprogress: The five ways Romney alienated women last night http:\/\/t.co\/7b6NzgGK #icymi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 3, 17 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "icymi",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/7b6NzgGK",
        "expanded_url" : "http:\/\/thkpr.gs\/RFs09b",
        "display_url" : "thkpr.gs\/RFs09b"
      } ]
    },
    "geo" : { },
    "id_str" : "258715447489339392",
    "text" : "RT @thinkprogress: The five ways Romney alienated women last night http:\/\/t.co\/7b6NzgGK #icymi",
    "id" : 258715447489339392,
    "created_at" : "2012-10-17 23:45:44 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 258718808494178304,
  "created_at" : "2012-10-17 23:59:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    }, {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 24, 35 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258718503916429312",
  "text" : "RT @ZeitgeistGhost: Hey @MittRomney you and your 1% WS\/CEO class buddies ARE WHAT IS WRONG WITH THE COUNTRY.  Greedy, selfish, uncaring, ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitt Romney",
        "screen_name" : "MittRomney",
        "indices" : [ 4, 15 ],
        "id_str" : "50055701",
        "id" : 50055701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258716155890499584",
    "text" : "Hey @MittRomney you and your 1% WS\/CEO class buddies ARE WHAT IS WRONG WITH THE COUNTRY.  Greedy, selfish, uncaring, oblivious 2 real life",
    "id" : 258716155890499584,
    "created_at" : "2012-10-17 23:48:32 +0000",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 258718503916429312,
  "created_at" : "2012-10-17 23:57:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 0, 15 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258716667436224515",
  "geo" : { },
  "id_str" : "258718308990349312",
  "in_reply_to_user_id" : 18538833,
  "text" : "@ZeitgeistGhost ((thumbsup))",
  "id" : 258718308990349312,
  "in_reply_to_status_id" : 258716667436224515,
  "created_at" : "2012-10-17 23:57:06 +0000",
  "in_reply_to_screen_name" : "ZeitgeistGhost",
  "in_reply_to_user_id_str" : "18538833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258712264629174273",
  "text" : "RT @CelticCamera: So, what was the best thing *before* sliced bread?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258709729923190784",
    "text" : "So, what was the best thing *before* sliced bread?",
    "id" : 258709729923190784,
    "created_at" : "2012-10-17 23:23:00 +0000",
    "user" : {
      "name" : "Gareth Glynn Ash",
      "screen_name" : "GarethGlynnAsh",
      "protected" : false,
      "id_str" : "21884322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714154956157227009\/p5XPCMj1_normal.jpg",
      "id" : 21884322,
      "verified" : false
    }
  },
  "id" : 258712264629174273,
  "created_at" : "2012-10-17 23:33:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258696944774418432",
  "text" : "RT @ZachsMind: Terrorism. Drugs. Obesity. Why have these wars failed? Cuz you can't wage war against emotions, inanimate objects &amp; a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258696333735624704",
    "text" : "Terrorism. Drugs. Obesity. Why have these wars failed? Cuz you can't wage war against emotions, inanimate objects &amp; abstract concepts. .",
    "id" : 258696333735624704,
    "created_at" : "2012-10-17 22:29:46 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 258696944774418432,
  "created_at" : "2012-10-17 22:32:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Amor Petrov",
      "screen_name" : "laprofe63",
      "indices" : [ 0, 10 ],
      "id_str" : "410135192",
      "id" : 410135192
    }, {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 11, 26 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258692981115195394",
  "geo" : { },
  "id_str" : "258696792781238272",
  "in_reply_to_user_id" : 410135192,
  "text" : "@laprofe63 @ZeitgeistGhost most americans live paycheck to paycheck",
  "id" : 258696792781238272,
  "in_reply_to_status_id" : 258692981115195394,
  "created_at" : "2012-10-17 22:31:36 +0000",
  "in_reply_to_screen_name" : "laprofe63",
  "in_reply_to_user_id_str" : "410135192",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laffy",
      "screen_name" : "GottaLaff",
      "indices" : [ 3, 13 ],
      "id_str" : "15368940",
      "id" : 15368940
    }, {
      "name" : "Kenneth Bernstein",
      "screen_name" : "teacherken",
      "indices" : [ 18, 29 ],
      "id_str" : "30686025",
      "id" : 30686025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258687707528716288",
  "text" : "RT @GottaLaff: RT @teacherken: \"America is now faced with a very clear choice - does it want a president or a boss?\"  - James Lipton on  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kenneth Bernstein",
        "screen_name" : "teacherken",
        "indices" : [ 3, 14 ],
        "id_str" : "30686025",
        "id" : 30686025
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hardball",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258686986322321408",
    "text" : "RT @teacherken: \"America is now faced with a very clear choice - does it want a president or a boss?\"  - James Lipton on #Hardball",
    "id" : 258686986322321408,
    "created_at" : "2012-10-17 21:52:38 +0000",
    "user" : {
      "name" : "Laffy",
      "screen_name" : "GottaLaff",
      "protected" : false,
      "id_str" : "15368940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744981043778772992\/Et1n4zy7_normal.jpg",
      "id" : 15368940,
      "verified" : false
    }
  },
  "id" : 258687707528716288,
  "created_at" : "2012-10-17 21:55:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258687405991809025",
  "text" : "\"does america want a president or a boss?\" (james lipton on hardball w chris matthews)",
  "id" : 258687405991809025,
  "created_at" : "2012-10-17 21:54:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greed",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258675984885219330",
  "geo" : { },
  "id_str" : "258677093930500097",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible sensata represents how romney made his money. taking over company and squeezing cash regardless of human cost #greed",
  "id" : 258677093930500097,
  "in_reply_to_status_id" : 258675984885219330,
  "created_at" : "2012-10-17 21:13:19 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258672751978614784",
  "geo" : { },
  "id_str" : "258673695273406464",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth me, either.. his outright lies are what get me (like he did NOT ask for more women.. he was told to hire more)",
  "id" : 258673695273406464,
  "in_reply_to_status_id" : 258672751978614784,
  "created_at" : "2012-10-17 20:59:49 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258671260299579392",
  "geo" : { },
  "id_str" : "258673020934164480",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray good point..",
  "id" : 258673020934164480,
  "in_reply_to_status_id" : 258671260299579392,
  "created_at" : "2012-10-17 20:57:08 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 24, 39 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romney",
      "indices" : [ 40, 47 ]
    }, {
      "text" : "Sensata",
      "indices" : [ 73, 81 ]
    }, {
      "text" : "Obama",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258670762628632576",
  "geo" : { },
  "id_str" : "258672252281815041",
  "in_reply_to_user_id" : 242204735,
  "text" : "true or not? anyone? RT @AnnotatedBible #Romney has no more control over #Sensata than #Obama does.",
  "id" : 258672252281815041,
  "in_reply_to_status_id" : 258670762628632576,
  "created_at" : "2012-10-17 20:54:05 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/l6ArvTX3",
      "expanded_url" : "http:\/\/www.adampknave.com\/2012\/01\/03\/maybe-this-will-help-you-understand-the-problem\/",
      "display_url" : "adampknave.com\/2012\/01\/03\/may\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258671796868485120",
  "text" : "RT @adampknave: This still might help explain why things are the way they are: http:\/\/t.co\/l6ArvTX3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/l6ArvTX3",
        "expanded_url" : "http:\/\/www.adampknave.com\/2012\/01\/03\/maybe-this-will-help-you-understand-the-problem\/",
        "display_url" : "adampknave.com\/2012\/01\/03\/may\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258670504058167296",
    "text" : "This still might help explain why things are the way they are: http:\/\/t.co\/l6ArvTX3",
    "id" : 258670504058167296,
    "created_at" : "2012-10-17 20:47:08 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 258671796868485120,
  "created_at" : "2012-10-17 20:52:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258669592723992576",
  "geo" : { },
  "id_str" : "258670368368242688",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth i go with that... separation of church and state FTW!",
  "id" : 258670368368242688,
  "in_reply_to_status_id" : 258669592723992576,
  "created_at" : "2012-10-17 20:46:36 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258664684394262528",
  "geo" : { },
  "id_str" : "258666934957142016",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen (((hugs)))",
  "id" : 258666934957142016,
  "in_reply_to_status_id" : 258664684394262528,
  "created_at" : "2012-10-17 20:32:57 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil S.",
      "screen_name" : "fireflyphil",
      "indices" : [ 3, 15 ],
      "id_str" : "271629654",
      "id" : 271629654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258666308441362436",
  "text" : "RT @fireflyphil: ATTENTION, PLEASE! In the interests of energy conservation, the light at the end of the tunnel will be SWITCHED OFF unt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258580343584612352",
    "text" : "ATTENTION, PLEASE! In the interests of energy conservation, the light at the end of the tunnel will be SWITCHED OFF until further notice.",
    "id" : 258580343584612352,
    "created_at" : "2012-10-17 14:48:52 +0000",
    "user" : {
      "name" : "Phil S.",
      "screen_name" : "fireflyphil",
      "protected" : false,
      "id_str" : "271629654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1291750999\/Twit1_normal.JPG",
      "id" : 271629654,
      "verified" : false
    }
  },
  "id" : 258666308441362436,
  "created_at" : "2012-10-17 20:30:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    }, {
      "name" : "Tess Bereczky",
      "screen_name" : "tessbereczky",
      "indices" : [ 89, 102 ],
      "id_str" : "25448196",
      "id" : 25448196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258660650102947840",
  "geo" : { },
  "id_str" : "258665786502172672",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible in the infamous 47% vid, he spoke of looking at a chinese factory to buy @tessbereczky",
  "id" : 258665786502172672,
  "in_reply_to_status_id" : 258660650102947840,
  "created_at" : "2012-10-17 20:28:23 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 21, 32 ],
      "id_str" : "50055701",
      "id" : 50055701
    }, {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 111, 125 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "women",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/nbELsWek",
      "expanded_url" : "http:\/\/thkpr.gs\/RGjkPS",
      "display_url" : "thkpr.gs\/RGjkPS"
    } ]
  },
  "geo" : { },
  "id_str" : "258657508367929344",
  "text" : "RT @ReverendSue: Why @MittRomney doesn't support equal pay for #women, in one picture http:\/\/t.co\/nbELsWek via @thinkprogress",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitt Romney",
        "screen_name" : "MittRomney",
        "indices" : [ 4, 15 ],
        "id_str" : "50055701",
        "id" : 50055701
      }, {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 94, 108 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "women",
        "indices" : [ 46, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/nbELsWek",
        "expanded_url" : "http:\/\/thkpr.gs\/RGjkPS",
        "display_url" : "thkpr.gs\/RGjkPS"
      } ]
    },
    "in_reply_to_status_id_str" : "258643647950639104",
    "geo" : { },
    "id_str" : "258656873576820736",
    "in_reply_to_user_id" : 55355654,
    "text" : "Why @MittRomney doesn't support equal pay for #women, in one picture http:\/\/t.co\/nbELsWek via @thinkprogress",
    "id" : 258656873576820736,
    "in_reply_to_status_id" : 258643647950639104,
    "created_at" : "2012-10-17 19:52:58 +0000",
    "in_reply_to_screen_name" : "thinkprogress",
    "in_reply_to_user_id_str" : "55355654",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 258657508367929344,
  "created_at" : "2012-10-17 19:55:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 3, 18 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258649117444681728",
  "text" : "RT @LoveHonorTruth: We need better daycare services and more flexible hours for everyone, not just women. Men are part of the family too.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258648182257508353",
    "text" : "We need better daycare services and more flexible hours for everyone, not just women. Men are part of the family too.",
    "id" : 258648182257508353,
    "created_at" : "2012-10-17 19:18:26 +0000",
    "user" : {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "protected" : false,
      "id_str" : "167958125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525129289336107008\/HMsrT9oV_normal.jpeg",
      "id" : 167958125,
      "verified" : false
    }
  },
  "id" : 258649117444681728,
  "created_at" : "2012-10-17 19:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VT",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258648049449046016",
  "text" : "RT @SenSanders: Someday generations of Americans will look back with disbelief at a time when health care was not a universal right. #VT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VT",
        "indices" : [ 117, 120 ]
      }, {
        "text" : "HCR",
        "indices" : [ 121, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258647858624999424",
    "text" : "Someday generations of Americans will look back with disbelief at a time when health care was not a universal right. #VT #HCR",
    "id" : 258647858624999424,
    "created_at" : "2012-10-17 19:17:09 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 258648049449046016,
  "created_at" : "2012-10-17 19:17:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258643638182096897",
  "text" : "romney is owned by koch brothers whom are wildly wealthy and have no interest in helping others.. only in protecting their assets.",
  "id" : 258643638182096897,
  "created_at" : "2012-10-17 19:00:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258641478123913217",
  "text" : "its hard for me.. becuz altho i appear fairly intelligent, i barely graduated HS. lots of stuff i could not grasp.",
  "id" : 258641478123913217,
  "created_at" : "2012-10-17 18:51:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 2, 11 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258634560483495936",
  "geo" : { },
  "id_str" : "258640223175581696",
  "in_reply_to_user_id" : 184401626,
  "text" : ". @AniKnits ppl like that are lacking self esteem and bolster it by finding any way to see others as \"less than\"",
  "id" : 258640223175581696,
  "in_reply_to_status_id" : 258634560483495936,
  "created_at" : "2012-10-17 18:46:49 +0000",
  "in_reply_to_screen_name" : "AniKnits",
  "in_reply_to_user_id_str" : "184401626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258639564011356160",
  "text" : "RT @CelticCamera: The game is rigged, folks -&gt;\n\n\"Citigroup CEO Walks Off With $260 Million After His Bank Loses 88 Percent Of Its Val ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/8sQtU73O",
        "expanded_url" : "http:\/\/bit.ly\/U51uYM",
        "display_url" : "bit.ly\/U51uYM"
      } ]
    },
    "geo" : { },
    "id_str" : "258636469743280128",
    "text" : "The game is rigged, folks -&gt;\n\n\"Citigroup CEO Walks Off With $260 Million After His Bank Loses 88 Percent Of Its Value\u201D\n\nhttp:\/\/t.co\/8sQtU73O",
    "id" : 258636469743280128,
    "created_at" : "2012-10-17 18:31:54 +0000",
    "user" : {
      "name" : "Gareth Glynn Ash",
      "screen_name" : "GarethGlynnAsh",
      "protected" : false,
      "id_str" : "21884322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714154956157227009\/p5XPCMj1_normal.jpg",
      "id" : 21884322,
      "verified" : false
    }
  },
  "id" : 258639564011356160,
  "created_at" : "2012-10-17 18:44:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 2, 17 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258636592791580673",
  "geo" : { },
  "id_str" : "258639499624599552",
  "in_reply_to_user_id" : 63804234,
  "text" : ". @PeggySueCusses whats in it? i did see it but didnt understand what the deal was...",
  "id" : 258639499624599552,
  "in_reply_to_status_id" : 258636592791580673,
  "created_at" : "2012-10-17 18:43:56 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258612653763731456",
  "geo" : { },
  "id_str" : "258621001443729408",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny no.. he's koch brothers robot..",
  "id" : 258621001443729408,
  "in_reply_to_status_id" : 258612653763731456,
  "created_at" : "2012-10-17 17:30:26 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258614435546021888",
  "geo" : { },
  "id_str" : "258615465771933697",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth im really confused that christians like him when he idolizes ayn rand...",
  "id" : 258615465771933697,
  "in_reply_to_status_id" : 258614435546021888,
  "created_at" : "2012-10-17 17:08:26 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258613074607616000",
  "geo" : { },
  "id_str" : "258613591991799808",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth what did he say?",
  "id" : 258613591991799808,
  "in_reply_to_status_id" : 258613074607616000,
  "created_at" : "2012-10-17 17:00:59 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258605644851077120",
  "geo" : { },
  "id_str" : "258611851976400897",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny frankly, romney could offer free healthcare for all and i'd still go for obama. because to me, romney has no compassion.",
  "id" : 258611851976400897,
  "in_reply_to_status_id" : 258605644851077120,
  "created_at" : "2012-10-17 16:54:04 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258605644851077120",
  "geo" : { },
  "id_str" : "258611457443364865",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny the thing is.. ppl compartmentalize. they take better (to them) candidate and brain ignores what they dont like.",
  "id" : 258611457443364865,
  "in_reply_to_status_id" : 258605644851077120,
  "created_at" : "2012-10-17 16:52:30 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258604395367895041",
  "geo" : { },
  "id_str" : "258605097649577984",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny omg'ness.. i was like a sports fan in front of tv. i was bouncing around and whooping..lol",
  "id" : 258605097649577984,
  "in_reply_to_status_id" : 258604395367895041,
  "created_at" : "2012-10-17 16:27:14 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258602729935630336",
  "geo" : { },
  "id_str" : "258603228990693377",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny ((highfive)) SNAP! lol",
  "id" : 258603228990693377,
  "in_reply_to_status_id" : 258602729935630336,
  "created_at" : "2012-10-17 16:19:49 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258582025055916032",
  "geo" : { },
  "id_str" : "258582730470735872",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater awesomesauce!",
  "id" : 258582730470735872,
  "in_reply_to_status_id" : 258582025055916032,
  "created_at" : "2012-10-17 14:58:21 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Pollock",
      "screen_name" : "Jason_Pollock",
      "indices" : [ 3, 17 ],
      "id_str" : "18363508",
      "id" : 18363508
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258582157004525569",
  "text" : "RT @Jason_Pollock: I want to live in a world where our teachers are considered ROCK STARS.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258581105060495361",
    "text" : "I want to live in a world where our teachers are considered ROCK STARS.",
    "id" : 258581105060495361,
    "created_at" : "2012-10-17 14:51:54 +0000",
    "user" : {
      "name" : "Jason Pollock",
      "screen_name" : "Jason_Pollock",
      "protected" : false,
      "id_str" : "18363508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646682632634396672\/AUWQ6v71_normal.jpg",
      "id" : 18363508,
      "verified" : true
    }
  },
  "id" : 258582157004525569,
  "created_at" : "2012-10-17 14:56:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "AlterNet",
      "screen_name" : "AlterNet",
      "indices" : [ 18, 27 ],
      "id_str" : "18851248",
      "id" : 18851248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/73lHIhnw",
      "expanded_url" : "http:\/\/www.alternet.org\/romneys-binder-full-women-story-may-be-funny-its-also-not-true",
      "display_url" : "alternet.org\/romneys-binder\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258575370972962817",
  "text" : "RT @Jamiastar: RT @AlterNet: Romney's \"Binder Full of Women Story\" May Be Funny; It's Also Not True http:\/\/t.co\/73lHIhnw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AlterNet",
        "screen_name" : "AlterNet",
        "indices" : [ 3, 12 ],
        "id_str" : "18851248",
        "id" : 18851248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/73lHIhnw",
        "expanded_url" : "http:\/\/www.alternet.org\/romneys-binder-full-women-story-may-be-funny-its-also-not-true",
        "display_url" : "alternet.org\/romneys-binder\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258574733598142464",
    "text" : "RT @AlterNet: Romney's \"Binder Full of Women Story\" May Be Funny; It's Also Not True http:\/\/t.co\/73lHIhnw",
    "id" : 258574733598142464,
    "created_at" : "2012-10-17 14:26:35 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 258575370972962817,
  "created_at" : "2012-10-17 14:29:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WitchinWebs \u263E",
      "screen_name" : "WitchinWebs",
      "indices" : [ 3, 15 ],
      "id_str" : "33900739",
      "id" : 33900739
    }, {
      "name" : "Life Advice\u2122",
      "screen_name" : "ozlifeadvice",
      "indices" : [ 20, 33 ],
      "id_str" : "337009521",
      "id" : 337009521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258574422364000256",
  "text" : "RT @WitchinWebs: RT @ozlifeadvice Arguing politics is like trying to convince someone that their baby isn't cute.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Life Advice\u2122",
        "screen_name" : "ozlifeadvice",
        "indices" : [ 3, 16 ],
        "id_str" : "337009521",
        "id" : 337009521
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "258570310847188992",
    "geo" : { },
    "id_str" : "258573123618738176",
    "in_reply_to_user_id" : 337009521,
    "text" : "RT @ozlifeadvice Arguing politics is like trying to convince someone that their baby isn't cute.",
    "id" : 258573123618738176,
    "in_reply_to_status_id" : 258570310847188992,
    "created_at" : "2012-10-17 14:20:11 +0000",
    "in_reply_to_screen_name" : "ozlifeadvice",
    "in_reply_to_user_id_str" : "337009521",
    "user" : {
      "name" : "WitchinWebs \u263E",
      "screen_name" : "WitchinWebs",
      "protected" : false,
      "id_str" : "33900739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2825062281\/5af4585de71515ca828c742b1326704b_normal.jpeg",
      "id" : 33900739,
      "verified" : false
    }
  },
  "id" : 258574422364000256,
  "created_at" : "2012-10-17 14:25:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janet Myatt",
      "screen_name" : "janet_myatt",
      "indices" : [ 3, 15 ],
      "id_str" : "565902906",
      "id" : 565902906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258563800347860992",
  "text" : "RT @janet_myatt: Choose love over fear and miracles happen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258548544812773376",
    "text" : "Choose love over fear and miracles happen",
    "id" : 258548544812773376,
    "created_at" : "2012-10-17 12:42:31 +0000",
    "user" : {
      "name" : "Janet Myatt",
      "screen_name" : "janet_myatt",
      "protected" : false,
      "id_str" : "565902906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733468618676047875\/2nBDbjU2_normal.jpg",
      "id" : 565902906,
      "verified" : false
    }
  },
  "id" : 258563800347860992,
  "created_at" : "2012-10-17 13:43:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258397241604177920",
  "text" : "dont worry ppl. its all gonna be ok. good night my peeps.",
  "id" : 258397241604177920,
  "created_at" : "2012-10-17 02:41:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258390647709503489",
  "text" : "RT @dhammagirl: Can we please stop calling people illegals!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258388550700122115",
    "text" : "Can we please stop calling people illegals!",
    "id" : 258388550700122115,
    "created_at" : "2012-10-17 02:06:45 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 258390647709503489,
  "created_at" : "2012-10-17 02:15:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debate",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258380081372737537",
  "text" : "i think i understand why ppl love watching sports now! #debate",
  "id" : 258380081372737537,
  "created_at" : "2012-10-17 01:33:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cubey",
      "screen_name" : "CubeMelon",
      "indices" : [ 0, 10 ],
      "id_str" : "4719914581",
      "id" : 4719914581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258378162025664512",
  "geo" : { },
  "id_str" : "258379055823478785",
  "in_reply_to_user_id" : 16639123,
  "text" : "@CubeMelon love that analogy! @HeadOnAHinge",
  "id" : 258379055823478785,
  "in_reply_to_status_id" : 258378162025664512,
  "created_at" : "2012-10-17 01:29:02 +0000",
  "in_reply_to_screen_name" : "ElectrumCube",
  "in_reply_to_user_id_str" : "16639123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Debate2012",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258375489469698050",
  "text" : "RT @micahjmurray: \"Let's use the money we've been spending on war over the last decade to rebuild America.\" -Obama #Debate2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Debate2012",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258373881730043904",
    "text" : "\"Let's use the money we've been spending on war over the last decade to rebuild America.\" -Obama #Debate2012",
    "id" : 258373881730043904,
    "created_at" : "2012-10-17 01:08:28 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 258375489469698050,
  "created_at" : "2012-10-17 01:14:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258371304196022273",
  "geo" : { },
  "id_str" : "258372208332775424",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver lol.. they are good. keeping me on my toes (the wildlife..making sure everyone gets some..lol)",
  "id" : 258372208332775424,
  "in_reply_to_status_id" : 258371304196022273,
  "created_at" : "2012-10-17 01:01:49 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258365027868889088",
  "text" : "RT @luminanceriver: You are loved and appreciated for your beingness! woo hoo!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258364339143192578",
    "text" : "You are loved and appreciated for your beingness! woo hoo!",
    "id" : 258364339143192578,
    "created_at" : "2012-10-17 00:30:33 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 258365027868889088,
  "created_at" : "2012-10-17 00:33:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/JxRYWYnO",
      "expanded_url" : "http:\/\/nestbirds1.com\/yum-yums-for-eastern-bluebirds\/",
      "display_url" : "nestbirds1.com\/yum-yums-for-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258364779821944832",
  "text" : "Yum \u2013 Yums for Eastern Bluebirds! http:\/\/t.co\/JxRYWYnO",
  "id" : 258364779821944832,
  "created_at" : "2012-10-17 00:32:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 3, 12 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrepperTalk",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/7KhFBeyQ",
      "expanded_url" : "http:\/\/earthquake.usgs.gov\/earthquakes\/eventpage\/usb000d75b#summary",
      "display_url" : "earthquake.usgs.gov\/earthquakes\/ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258348738530123777",
  "text" : "RT @Fernwise: Maine Earthquake http:\/\/t.co\/7KhFBeyQ #PrepperTalk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrepperTalk",
        "indices" : [ 38, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/7KhFBeyQ",
        "expanded_url" : "http:\/\/earthquake.usgs.gov\/earthquakes\/eventpage\/usb000d75b#summary",
        "display_url" : "earthquake.usgs.gov\/earthquakes\/ev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258347887497445377",
    "text" : "Maine Earthquake http:\/\/t.co\/7KhFBeyQ #PrepperTalk",
    "id" : 258347887497445377,
    "created_at" : "2012-10-16 23:25:10 +0000",
    "user" : {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "protected" : false,
      "id_str" : "23538653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/253664055\/FernForTwitter_normal.png",
      "id" : 23538653,
      "verified" : false
    }
  },
  "id" : 258348738530123777,
  "created_at" : "2012-10-16 23:28:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258339500181291009",
  "geo" : { },
  "id_str" : "258340310646673408",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i had some of the unspoiled stew hubby made that was in fridge. (other portion still in crockpot smelled bad)",
  "id" : 258340310646673408,
  "in_reply_to_status_id" : 258339500181291009,
  "created_at" : "2012-10-16 22:55:04 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258330244329635840",
  "geo" : { },
  "id_str" : "258330966836273152",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell the debate? 9pm EST : )",
  "id" : 258330966836273152,
  "in_reply_to_status_id" : 258330244329635840,
  "created_at" : "2012-10-16 22:17:56 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258299054163898368",
  "text" : "RT @SenSanders: It is about time that Congress start representing the interests of all Americans, not just the wealthy and powerful. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSanders\/status\/258293746972647424\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/9e0IqxWx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A5Wky1xCYAAAUxR.jpg",
        "id_str" : "258293746976841728",
        "id" : 258293746976841728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5Wky1xCYAAAUxR.jpg",
        "sizes" : [ {
          "h" : 658,
          "resize" : "fit",
          "w" : 1063
        }, {
          "h" : 634,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 371,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9e0IqxWx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258293746972647424",
    "text" : "It is about time that Congress start representing the interests of all Americans, not just the wealthy and powerful. http:\/\/t.co\/9e0IqxWx",
    "id" : 258293746972647424,
    "created_at" : "2012-10-16 19:50:03 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 258299054163898368,
  "created_at" : "2012-10-16 20:11:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258298379296186368",
  "text" : "poor hubs stew went rogue. smells like sour milk. decided not to eat it. (it was fine the day B4)",
  "id" : 258298379296186368,
  "created_at" : "2012-10-16 20:08:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258280749403357184",
  "text" : "RT @DwayneReaves: Is preparing for a debate like preparing for an argument with the ex? Like, what I am I gonna say when she brings this ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258280294975680514",
    "text" : "Is preparing for a debate like preparing for an argument with the ex? Like, what I am I gonna say when she brings this up? LOL",
    "id" : 258280294975680514,
    "created_at" : "2012-10-16 18:56:35 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 258280749403357184,
  "created_at" : "2012-10-16 18:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 68, 80 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Bill",
      "screen_name" : "billk77",
      "indices" : [ 86, 94 ],
      "id_str" : "19436163",
      "id" : 19436163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258209049131241472",
  "geo" : { },
  "id_str" : "258280155238244353",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker for some reason, made me chuckle.. and reminds me of @virgojohnny..lol @billk77",
  "id" : 258280155238244353,
  "in_reply_to_status_id" : 258209049131241472,
  "created_at" : "2012-10-16 18:56:02 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Brewery",
      "screen_name" : "TheBreweryCC",
      "indices" : [ 3, 16 ],
      "id_str" : "471535186",
      "id" : 471535186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258273538681753600",
  "text" : "RT @TheBreweryCC: What is broken will be fixed. This is the message of the gospels to believe in mercy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258271977842806785",
    "text" : "What is broken will be fixed. This is the message of the gospels to believe in mercy.",
    "id" : 258271977842806785,
    "created_at" : "2012-10-16 18:23:32 +0000",
    "user" : {
      "name" : "The Brewery",
      "screen_name" : "TheBreweryCC",
      "protected" : false,
      "id_str" : "471535186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1774253830\/40155_163109870380989_108296399195670_426368_1882929_n_normal.jpg",
      "id" : 471535186,
      "verified" : false
    }
  },
  "id" : 258273538681753600,
  "created_at" : "2012-10-16 18:29:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 3, 16 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "america",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "emerging",
      "indices" : [ 105, 114 ]
    }, {
      "text" : "free",
      "indices" : [ 115, 120 ]
    }, {
      "text" : "spirits",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258259628557750272",
  "text" : "RT @worldtreeman: i think #america has got what it takes to become a shining beacon of hope in the world #emerging #free #spirits",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "america",
        "indices" : [ 8, 16 ]
      }, {
        "text" : "emerging",
        "indices" : [ 87, 96 ]
      }, {
        "text" : "free",
        "indices" : [ 97, 102 ]
      }, {
        "text" : "spirits",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258259428317462528",
    "text" : "i think #america has got what it takes to become a shining beacon of hope in the world #emerging #free #spirits",
    "id" : 258259428317462528,
    "created_at" : "2012-10-16 17:33:40 +0000",
    "user" : {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "protected" : false,
      "id_str" : "85400142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459790852911407104\/3m_th7xJ_normal.jpeg",
      "id" : 85400142,
      "verified" : false
    }
  },
  "id" : 258259628557750272,
  "created_at" : "2012-10-16 17:34:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "forprofithealthcarestinks",
      "indices" : [ 74, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258254073541849088",
  "text" : "watching show about healthcare. $50k us vs $9K india for hip operation... #forprofithealthcarestinks",
  "id" : 258254073541849088,
  "created_at" : "2012-10-16 17:12:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/q2PiAqoY",
      "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
      "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258252695675224064",
  "text" : "RT @PeggySueCusses: Do you love bags? How about totes? Check out the totes I make in my Artfire shop. http:\/\/t.co\/q2PiAqoY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/q2PiAqoY",
        "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
        "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258247860997476354",
    "text" : "Do you love bags? How about totes? Check out the totes I make in my Artfire shop. http:\/\/t.co\/q2PiAqoY",
    "id" : 258247860997476354,
    "created_at" : "2012-10-16 16:47:42 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 258252695675224064,
  "created_at" : "2012-10-16 17:06:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258233867838828545",
  "text" : "and they could say same about me and my views...",
  "id" : 258233867838828545,
  "created_at" : "2012-10-16 15:52:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258233645721059329",
  "text" : "i am liberal. pro-obama. but i dont think its right to call pro-romney ppl dumb. their perspective is diff. not seeing what i see.",
  "id" : 258233645721059329,
  "created_at" : "2012-10-16 15:51:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258233187409469442",
  "text" : "labels are a way for us to live in the world but dont use them to define ppl.",
  "id" : 258233187409469442,
  "created_at" : "2012-10-16 15:49:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258232414801887232",
  "text" : "RT @LukeRomyn: The quickest route to world peace is to kill all the people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258232127794077696",
    "text" : "The quickest route to world peace is to kill all the people.",
    "id" : 258232127794077696,
    "created_at" : "2012-10-16 15:45:11 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 258232414801887232,
  "created_at" : "2012-10-16 15:46:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 13, 25 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257997039969923073",
  "geo" : { },
  "id_str" : "258007655199698945",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell @CaroleODell at first I wasnt too interested.. then I saw his view and I was like.. wow.. lol. very cool. : )",
  "id" : 258007655199698945,
  "in_reply_to_status_id" : 257997039969923073,
  "created_at" : "2012-10-16 00:53:13 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257994556442816512",
  "text" : "my poor stray kitty keeps getting interrupted by the raccoons.. o-O",
  "id" : 257994556442816512,
  "created_at" : "2012-10-16 00:01:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257978902943776768",
  "text" : "@statue_dog what a wonderful anniversary present! : )",
  "id" : 257978902943776768,
  "created_at" : "2012-10-15 22:58:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adam_zander",
      "screen_name" : "adam_zander",
      "indices" : [ 3, 15 ],
      "id_str" : "519076313",
      "id" : 519076313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257965138928353280",
  "text" : "RT @adam_zander: I've Hit The Sensata Motherlode !!! - Lots Of Links, And Check Out The First Comment... - Democratic Underground http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/cCE9WJ3q",
        "expanded_url" : "http:\/\/demu.gr\/10021543175",
        "display_url" : "demu.gr\/10021543175"
      } ]
    },
    "geo" : { },
    "id_str" : "257948343655866368",
    "text" : "I've Hit The Sensata Motherlode !!! - Lots Of Links, And Check Out The First Comment... - Democratic Underground http:\/\/t.co\/cCE9WJ3q",
    "id" : 257948343655866368,
    "created_at" : "2012-10-15 20:57:32 +0000",
    "user" : {
      "name" : "adam_zander",
      "screen_name" : "adam_zander",
      "protected" : false,
      "id_str" : "519076313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1882762664\/main_drag_normal.jpg",
      "id" : 519076313,
      "verified" : false
    }
  },
  "id" : 257965138928353280,
  "created_at" : "2012-10-15 22:04:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/ZmPl3pLO",
      "expanded_url" : "http:\/\/www.nationalpopularvote.com\/ma\/",
      "display_url" : "nationalpopularvote.com\/ma\/"
    } ]
  },
  "geo" : { },
  "id_str" : "257963140610928642",
  "text" : "RT @Jamiastar: National Popular Vote -- Electoral college reform by direct election of the President http:\/\/t.co\/ZmPl3pLO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/ZmPl3pLO",
        "expanded_url" : "http:\/\/www.nationalpopularvote.com\/ma\/",
        "display_url" : "nationalpopularvote.com\/ma\/"
      } ]
    },
    "geo" : { },
    "id_str" : "257960184494833664",
    "text" : "National Popular Vote -- Electoral college reform by direct election of the President http:\/\/t.co\/ZmPl3pLO",
    "id" : 257960184494833664,
    "created_at" : "2012-10-15 21:44:35 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 257963140610928642,
  "created_at" : "2012-10-15 21:56:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/qfEFb0EK",
      "expanded_url" : "http:\/\/www.thenation.com\/article\/170562\/playing-voter-id-card?utm_medium=email&utm_source=HeadlineNation&utm_term=&utm_campaign=",
      "display_url" : "thenation.com\/article\/170562\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257959788590297089",
  "text" : "RT @Jamiastar: Former voter ID supporter realizes the real racial motive behind supposedly \"common sense\" reforms   http:\/\/t.co\/qfEFb0EK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/qfEFb0EK",
        "expanded_url" : "http:\/\/www.thenation.com\/article\/170562\/playing-voter-id-card?utm_medium=email&utm_source=HeadlineNation&utm_term=&utm_campaign=",
        "display_url" : "thenation.com\/article\/170562\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "257958718988226560",
    "text" : "Former voter ID supporter realizes the real racial motive behind supposedly \"common sense\" reforms   http:\/\/t.co\/qfEFb0EK",
    "id" : 257958718988226560,
    "created_at" : "2012-10-15 21:38:45 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 257959788590297089,
  "created_at" : "2012-10-15 21:43:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 0, 15 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257942929115578368",
  "geo" : { },
  "id_str" : "257944151344173056",
  "in_reply_to_user_id" : 18538833,
  "text" : "@ZeitgeistGhost i'd like to believe he's evil but I think he's very intelligent, ambitious and wants the title.. not the job.",
  "id" : 257944151344173056,
  "in_reply_to_status_id" : 257942929115578368,
  "created_at" : "2012-10-15 20:40:52 +0000",
  "in_reply_to_screen_name" : "ZeitgeistGhost",
  "in_reply_to_user_id_str" : "18538833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Armstrong",
      "screen_name" : "marioarmstrong",
      "indices" : [ 3, 18 ],
      "id_str" : "7392512",
      "id" : 7392512
    }, {
      "name" : "Sony",
      "screen_name" : "Sony",
      "indices" : [ 30, 35 ],
      "id_str" : "34442404",
      "id" : 34442404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/btD3hnvT",
      "expanded_url" : "http:\/\/www.marioarmstrong.com\/2012\/10\/15\/enter-to-win-a-free-sony-reader\/",
      "display_url" : "marioarmstrong.com\/2012\/10\/15\/ent\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257941769843523584",
  "text" : "RT @marioarmstrong: win a hot @Sony eReader with a tweet? i'm practically giving this thing away!!! chk it http:\/\/t.co\/btD3hnvT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sony",
        "screen_name" : "Sony",
        "indices" : [ 10, 15 ],
        "id_str" : "34442404",
        "id" : 34442404
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/btD3hnvT",
        "expanded_url" : "http:\/\/www.marioarmstrong.com\/2012\/10\/15\/enter-to-win-a-free-sony-reader\/",
        "display_url" : "marioarmstrong.com\/2012\/10\/15\/ent\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "257931006563213312",
    "text" : "win a hot @Sony eReader with a tweet? i'm practically giving this thing away!!! chk it http:\/\/t.co\/btD3hnvT",
    "id" : 257931006563213312,
    "created_at" : "2012-10-15 19:48:38 +0000",
    "user" : {
      "name" : "Mario Armstrong",
      "screen_name" : "marioarmstrong",
      "protected" : false,
      "id_str" : "7392512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756020844648857600\/nBdFwFEk_normal.jpg",
      "id" : 7392512,
      "verified" : true
    }
  },
  "id" : 257941769843523584,
  "created_at" : "2012-10-15 20:31:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257926309345386497",
  "geo" : { },
  "id_str" : "257928760949620736",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses that sounds good to me : )",
  "id" : 257928760949620736,
  "in_reply_to_status_id" : 257926309345386497,
  "created_at" : "2012-10-15 19:39:43 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eowyn Ivey",
      "screen_name" : "EowynIvey",
      "indices" : [ 3, 13 ],
      "id_str" : "288936981",
      "id" : 288936981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/5338Pg35",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vBabWaELGz4",
      "display_url" : "youtube.com\/watch?v=vBabWa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257913166850306049",
  "text" : "RT @EowynIvey: Alaska Bull Moose street fighting http:\/\/t.co\/5338Pg35",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/5338Pg35",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vBabWaELGz4",
        "display_url" : "youtube.com\/watch?v=vBabWa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "257912897982844928",
    "text" : "Alaska Bull Moose street fighting http:\/\/t.co\/5338Pg35",
    "id" : 257912897982844928,
    "created_at" : "2012-10-15 18:36:41 +0000",
    "user" : {
      "name" : "Eowyn Ivey",
      "screen_name" : "EowynIvey",
      "protected" : false,
      "id_str" : "288936981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765585378388635648\/Rw1GeNG8_normal.jpg",
      "id" : 288936981,
      "verified" : false
    }
  },
  "id" : 257913166850306049,
  "created_at" : "2012-10-15 18:37:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257907655891378177",
  "text" : "at least we'd all get swimming pools.. i think?",
  "id" : 257907655891378177,
  "created_at" : "2012-10-15 18:15:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257907003790348288",
  "text" : "the ducks are going to take over... hmm.. interesting view.",
  "id" : 257907003790348288,
  "created_at" : "2012-10-15 18:13:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 3, 17 ],
      "id_str" : "16901470",
      "id" : 16901470
    }, {
      "name" : "Gawker",
      "screen_name" : "Gawker",
      "indices" : [ 43, 50 ],
      "id_str" : "8936082",
      "id" : 8936082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257906675464417280",
  "text" : "RT @johnnie_cakes: Dear god, not ducks! RT @Gawker: Homeschooled teen says ducks will enslave humanity if homosexuality allowed to sprea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gawker",
        "screen_name" : "Gawker",
        "indices" : [ 24, 31 ],
        "id_str" : "8936082",
        "id" : 8936082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/k73QvuOR",
        "expanded_url" : "http:\/\/gaw.kr\/i1Kxjr",
        "display_url" : "gaw.kr\/i1Kxjr"
      } ]
    },
    "geo" : { },
    "id_str" : "257906128988561409",
    "text" : "Dear god, not ducks! RT @Gawker: Homeschooled teen says ducks will enslave humanity if homosexuality allowed to spread http:\/\/t.co\/k73QvuOR",
    "id" : 257906128988561409,
    "created_at" : "2012-10-15 18:09:47 +0000",
    "user" : {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "protected" : false,
      "id_str" : "16901470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765066200657166336\/h3XngAjO_normal.jpg",
      "id" : 16901470,
      "verified" : false
    }
  },
  "id" : 257906675464417280,
  "created_at" : "2012-10-15 18:11:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Silvercrone\/status\/257905673906577408\/photo\/1",
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/pBCzXI8h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5RD2A8CYAA-ili.jpg",
      "id_str" : "257905673910771712",
      "id" : 257905673910771712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5RD2A8CYAA-ili.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 428
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 428
      } ],
      "display_url" : "pic.twitter.com\/pBCzXI8h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257906055575654401",
  "text" : "RT @Silvercrone: Your Focus. What IS it? http:\/\/t.co\/pBCzXI8h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Silvercrone\/status\/257905673906577408\/photo\/1",
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/pBCzXI8h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A5RD2A8CYAA-ili.jpg",
        "id_str" : "257905673910771712",
        "id" : 257905673910771712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5RD2A8CYAA-ili.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 428
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 428
        } ],
        "display_url" : "pic.twitter.com\/pBCzXI8h"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257905673906577408",
    "text" : "Your Focus. What IS it? http:\/\/t.co\/pBCzXI8h",
    "id" : 257905673906577408,
    "created_at" : "2012-10-15 18:07:59 +0000",
    "user" : {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "protected" : false,
      "id_str" : "20929609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762392864085147648\/1cejAvKU_normal.jpg",
      "id" : 20929609,
      "verified" : false
    }
  },
  "id" : 257906055575654401,
  "created_at" : "2012-10-15 18:09:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257901733269876736",
  "geo" : { },
  "id_str" : "257902129128300545",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny : P ((hugs)) lol",
  "id" : 257902129128300545,
  "in_reply_to_status_id" : 257901733269876736,
  "created_at" : "2012-10-15 17:53:53 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/xdRokGwO",
      "expanded_url" : "http:\/\/www.smh.com.au\/lifestyle\/bitter-pills-20121008-277yj.html",
      "display_url" : "smh.com.au\/lifestyle\/bitt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257901097560182784",
  "text" : "RT @LyricTehUnicorn: Parents have kids taken away for refusing to subject them to mainstream medical treatments http:\/\/t.co\/xdRokGwO Sto ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/xdRokGwO",
        "expanded_url" : "http:\/\/www.smh.com.au\/lifestyle\/bitter-pills-20121008-277yj.html",
        "display_url" : "smh.com.au\/lifestyle\/bitt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "257886900856180736",
    "text" : "Parents have kids taken away for refusing to subject them to mainstream medical treatments http:\/\/t.co\/xdRokGwO Stories are depressing :(",
    "id" : 257886900856180736,
    "created_at" : "2012-10-15 16:53:23 +0000",
    "user" : {
      "name" : "Lyric #MniWiconi",
      "screen_name" : "IchBinLyric",
      "protected" : false,
      "id_str" : "32614203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726542762808463360\/60DwyaPl_normal.jpg",
      "id" : 32614203,
      "verified" : false
    }
  },
  "id" : 257901097560182784,
  "created_at" : "2012-10-15 17:49:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Nordby",
      "screen_name" : "JacobNordby",
      "indices" : [ 3, 15 ],
      "id_str" : "14443463",
      "id" : 14443463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257894871241732097",
  "text" : "RT @JacobNordby: Blessed are the weird people! do you have the \"gift of NOT fitting in...\"? Join us for a sneak peek at http:\/\/t.co\/lBTS ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAN1",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/lBTShOd9",
        "expanded_url" : "http:\/\/www.BlessedAreTheWeird.com",
        "display_url" : "BlessedAreTheWeird.com"
      } ]
    },
    "geo" : { },
    "id_str" : "257886204043866112",
    "text" : "Blessed are the weird people! do you have the \"gift of NOT fitting in...\"? Join us for a sneak peek at http:\/\/t.co\/lBTShOd9 #IAN1",
    "id" : 257886204043866112,
    "created_at" : "2012-10-15 16:50:36 +0000",
    "user" : {
      "name" : "Jacob Nordby",
      "screen_name" : "JacobNordby",
      "protected" : false,
      "id_str" : "14443463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779852669250777088\/79-e7WnY_normal.jpg",
      "id" : 14443463,
      "verified" : false
    }
  },
  "id" : 257894871241732097,
  "created_at" : "2012-10-15 17:25:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chab(just one snake)",
      "screen_name" : "themoshe",
      "indices" : [ 3, 12 ],
      "id_str" : "108622155",
      "id" : 108622155
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/themoshe\/status\/257886856690147328\/photo\/1",
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/Lhu6FxS0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5QyutWCIAAr1Y7.jpg",
      "id_str" : "257886856694341632",
      "id" : 257886856694341632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5QyutWCIAAr1Y7.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 426
      } ],
      "display_url" : "pic.twitter.com\/Lhu6FxS0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257887560783773697",
  "text" : "RT @themoshe: Florida wildlife http:\/\/t.co\/Lhu6FxS0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/themoshe\/status\/257886856690147328\/photo\/1",
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/Lhu6FxS0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A5QyutWCIAAr1Y7.jpg",
        "id_str" : "257886856694341632",
        "id" : 257886856694341632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5QyutWCIAAr1Y7.jpg",
        "sizes" : [ {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 426
        } ],
        "display_url" : "pic.twitter.com\/Lhu6FxS0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257886856690147328",
    "text" : "Florida wildlife http:\/\/t.co\/Lhu6FxS0",
    "id" : 257886856690147328,
    "created_at" : "2012-10-15 16:53:12 +0000",
    "user" : {
      "name" : "Chab(just one snake)",
      "screen_name" : "themoshe",
      "protected" : false,
      "id_str" : "108622155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000483854263\/35cb136454787f31fc56414c44890a6e_normal.jpeg",
      "id" : 108622155,
      "verified" : false
    }
  },
  "id" : 257887560783773697,
  "created_at" : "2012-10-15 16:56:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Chris Dashiell",
      "screen_name" : "cdashiell",
      "indices" : [ 19, 29 ],
      "id_str" : "26670829",
      "id" : 26670829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257882945686233088",
  "text" : "RT @TrishScott: RT @cdashiell: What is a right to life without a right to food, shelter, health care, and education?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Dashiell",
        "screen_name" : "cdashiell",
        "indices" : [ 3, 13 ],
        "id_str" : "26670829",
        "id" : 26670829
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257882556056358912",
    "text" : "RT @cdashiell: What is a right to life without a right to food, shelter, health care, and education?",
    "id" : 257882556056358912,
    "created_at" : "2012-10-15 16:36:07 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 257882945686233088,
  "created_at" : "2012-10-15 16:37:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 6, 16 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257877309380505601",
  "geo" : { },
  "id_str" : "257878545395769344",
  "in_reply_to_user_id" : 16181537,
  "text" : "sorry @ZachsMind you are smart if you are the one who writes those blog posts. i can search but i cannot express ideas like you do. : )",
  "id" : 257878545395769344,
  "in_reply_to_status_id" : 257877309380505601,
  "created_at" : "2012-10-15 16:20:11 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Opinionista",
      "screen_name" : "TheOpinionista",
      "indices" : [ 38, 53 ],
      "id_str" : "377188795",
      "id" : 377188795
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 55, 69 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romney",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/SNKo17Db",
      "expanded_url" : "http:\/\/bit.ly\/Rxon52",
      "display_url" : "bit.ly\/Rxon52"
    } ]
  },
  "geo" : { },
  "id_str" : "257877787321438209",
  "text" : "RT @CharlesBivona: Left a comment. RT @theopinionista: @CharlesBivona #Romney CANNOT win http:\/\/t.co\/SNKo17Db",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Opinionista",
        "screen_name" : "TheOpinionista",
        "indices" : [ 19, 34 ],
        "id_str" : "377188795",
        "id" : 377188795
      }, {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 36, 50 ],
        "id_str" : "45254966",
        "id" : 45254966
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Romney",
        "indices" : [ 51, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/SNKo17Db",
        "expanded_url" : "http:\/\/bit.ly\/Rxon52",
        "display_url" : "bit.ly\/Rxon52"
      } ]
    },
    "geo" : { },
    "id_str" : "257876848434896896",
    "text" : "Left a comment. RT @theopinionista: @CharlesBivona #Romney CANNOT win http:\/\/t.co\/SNKo17Db",
    "id" : 257876848434896896,
    "created_at" : "2012-10-15 16:13:26 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 257877787321438209,
  "created_at" : "2012-10-15 16:17:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257876689495941120",
  "text" : "RT @ZachsMind: So what we think we are experiencing is actually what happened a few nanoseconds ago. Nothing is as it seems.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257875810298523648",
    "text" : "So what we think we are experiencing is actually what happened a few nanoseconds ago. Nothing is as it seems.",
    "id" : 257875810298523648,
    "created_at" : "2012-10-15 16:09:18 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 257876689495941120,
  "created_at" : "2012-10-15 16:12:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257874849068892160",
  "geo" : { },
  "id_str" : "257876368338075649",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind have you ever taken an iq test? often genius's are thought of as crazy..lol. imho, you are quite wise.",
  "id" : 257876368338075649,
  "in_reply_to_status_id" : 257874849068892160,
  "created_at" : "2012-10-15 16:11:31 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 72, 82 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257873496443600897",
  "text" : "@Skeptical_Lady well, man came first so he's in charge.. wait.. i think @zachsmind proved that wrong on his blog! lol xx\/xy",
  "id" : 257873496443600897,
  "created_at" : "2012-10-15 16:00:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Husband",
      "screen_name" : "Brain_Explained",
      "indices" : [ 3, 19 ],
      "id_str" : "483045795",
      "id" : 483045795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brains",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257871597254369281",
  "text" : "RT @Brain_Explained: Followers might know I love (&amp; study) bird #brains; latest, Crows suspicious about unusual events - causal reas ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brains",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 141 ],
        "url" : "http:\/\/t.co\/FltSSDkm",
        "expanded_url" : "http:\/\/bit.ly\/RZuTB4",
        "display_url" : "bit.ly\/RZuTB4"
      } ]
    },
    "geo" : { },
    "id_str" : "257853052277641217",
    "text" : "Followers might know I love (&amp; study) bird #brains; latest, Crows suspicious about unusual events - causal reasoning\nhttp:\/\/t.co\/FltSSDkm",
    "id" : 257853052277641217,
    "created_at" : "2012-10-15 14:38:53 +0000",
    "user" : {
      "name" : "Scott Husband",
      "screen_name" : "Brain_Explained",
      "protected" : false,
      "id_str" : "483045795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1803767371\/twitter_profile_sm_normal.jpg",
      "id" : 483045795,
      "verified" : false
    }
  },
  "id" : 257871597254369281,
  "created_at" : "2012-10-15 15:52:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257861996421206018",
  "text" : "@Skeptical_Lady by golly, only men are allowed to choose when to have sex, with whom and whether it creates children...",
  "id" : 257861996421206018,
  "created_at" : "2012-10-15 15:14:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "as Brian Greene",
      "screen_name" : "BrianGreene",
      "indices" : [ 3, 15 ],
      "id_str" : "813670",
      "id" : 813670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257857873365835776",
  "text" : "RT @BrianGreene: why would I want 2000 more followers? I have trouble enough trying to annoy the 2000+ I already have.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257857361996283904",
    "text" : "why would I want 2000 more followers? I have trouble enough trying to annoy the 2000+ I already have.",
    "id" : 257857361996283904,
    "created_at" : "2012-10-15 14:56:00 +0000",
    "user" : {
      "name" : "as Brian Greene",
      "screen_name" : "BrianGreene",
      "protected" : false,
      "id_str" : "813670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800963724056072192\/gyk_Cmgd_normal.jpg",
      "id" : 813670,
      "verified" : false
    }
  },
  "id" : 257857873365835776,
  "created_at" : "2012-10-15 14:58:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/JkhQWQaq",
      "expanded_url" : "http:\/\/ow.ly\/eqooE",
      "display_url" : "ow.ly\/eqooE"
    } ]
  },
  "geo" : { },
  "id_str" : "257845897017303041",
  "text" : "RT @davidpakmanshow: Romney surrogates admits that yes, Mitt's just flip flopping to gain votes http:\/\/t.co\/JkhQWQaq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/JkhQWQaq",
        "expanded_url" : "http:\/\/ow.ly\/eqooE",
        "display_url" : "ow.ly\/eqooE"
      } ]
    },
    "geo" : { },
    "id_str" : "257844509294088192",
    "text" : "Romney surrogates admits that yes, Mitt's just flip flopping to gain votes http:\/\/t.co\/JkhQWQaq",
    "id" : 257844509294088192,
    "created_at" : "2012-10-15 14:04:56 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 257845897017303041,
  "created_at" : "2012-10-15 14:10:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257651357157298176",
  "geo" : { },
  "id_str" : "257837972416765952",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin i tell hubby he must have been very very bad in a prev life and now pays penance taking care of me..LOL",
  "id" : 257837972416765952,
  "in_reply_to_status_id" : 257651357157298176,
  "created_at" : "2012-10-15 13:38:57 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 2, 15 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257635119605624833",
  "geo" : { },
  "id_str" : "257837678035365888",
  "in_reply_to_user_id" : 94619438,
  "text" : ". @micahjmurray imho he made his money unethically. i dont trust him as far as i can throw a stick (which isnt far..lol)",
  "id" : 257837678035365888,
  "in_reply_to_status_id" : 257635119605624833,
  "created_at" : "2012-10-15 13:37:47 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257641852608589825",
  "text" : "2012 - the world is ending. but not how you think... focus on the light. it will all be ok : )",
  "id" : 257641852608589825,
  "created_at" : "2012-10-15 00:39:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257639246079332352",
  "geo" : { },
  "id_str" : "257640291509620736",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin hubby makes good soups, stews and chili. he seems to do everything well...lol.. unlike me.",
  "id" : 257640291509620736,
  "in_reply_to_status_id" : 257639246079332352,
  "created_at" : "2012-10-15 00:33:26 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "indices" : [ 3, 16 ],
      "id_str" : "179732982",
      "id" : 179732982
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romney",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257631248820871168",
  "text" : "RT @TheDailyEdge: #Romney and Bain made 900% profit bankrupting KB Toys. Employees didn't get a single day's severance http:\/\/t.co\/YeKrt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Romney",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "Sensata",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/YeKrtB87",
        "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/greed-and-debt-the-true-story-of-mitt-romney-and-bain-capital-20120829",
        "display_url" : "rollingstone.com\/politics\/news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "257626025310187520",
    "text" : "#Romney and Bain made 900% profit bankrupting KB Toys. Employees didn't get a single day's severance http:\/\/t.co\/YeKrtB87 #Sensata",
    "id" : 257626025310187520,
    "created_at" : "2012-10-14 23:36:45 +0000",
    "user" : {
      "name" : "The Daily Edge",
      "screen_name" : "TheDailyEdge",
      "protected" : false,
      "id_str" : "179732982",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655073745510510592\/FX6VgfRw_normal.png",
      "id" : 179732982,
      "verified" : false
    }
  },
  "id" : 257631248820871168,
  "created_at" : "2012-10-14 23:57:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1stdonoharm",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257614480123514880",
  "text" : "watch that prev tweet (vid) .. dare you not to cry... #1stdonoharm",
  "id" : 257614480123514880,
  "created_at" : "2012-10-14 22:50:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/nFKlnq8M",
      "expanded_url" : "http:\/\/youtu.be\/BLWnB9FGmWE",
      "display_url" : "youtu.be\/BLWnB9FGmWE"
    } ]
  },
  "geo" : { },
  "id_str" : "257607908810956802",
  "text" : "When Mitt Romney Came To Town \u2014 Full, complete version: http:\/\/t.co\/nFKlnq8M",
  "id" : 257607908810956802,
  "created_at" : "2012-10-14 22:24:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarbTheF*ckUP!",
      "screen_name" : "MsNatTurner",
      "indices" : [ 3, 15 ],
      "id_str" : "21974380",
      "id" : 21974380
    }, {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 29, 40 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257602068712402944",
  "text" : "RT @MsNatTurner: Gingrich on @MittRomney: \"Somebody who will lie to you to get to be President will lie to you when they are President.\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mitt Romney",
        "screen_name" : "MittRomney",
        "indices" : [ 12, 23 ],
        "id_str" : "50055701",
        "id" : 50055701
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/tI0mSqYV",
        "expanded_url" : "http:\/\/ow.ly\/cSDXC",
        "display_url" : "ow.ly\/cSDXC"
      } ]
    },
    "geo" : { },
    "id_str" : "257598720999317504",
    "text" : "Gingrich on @MittRomney: \"Somebody who will lie to you to get to be President will lie to you when they are President.\" http:\/\/t.co\/tI0mSqYV",
    "id" : 257598720999317504,
    "created_at" : "2012-10-14 21:48:15 +0000",
    "user" : {
      "name" : "CarbTheF*ckUP!",
      "screen_name" : "MsNatTurner",
      "protected" : false,
      "id_str" : "21974380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800862429148303360\/RuneTQAv_normal.jpg",
      "id" : 21974380,
      "verified" : false
    }
  },
  "id" : 257602068712402944,
  "created_at" : "2012-10-14 22:01:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marwa Kilani, M.D.",
      "screen_name" : "kilani19",
      "indices" : [ 3, 12 ],
      "id_str" : "519740228",
      "id" : 519740228
    }, {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 14, 26 ],
      "id_str" : "17004618",
      "id" : 17004618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romney",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257566292494663680",
  "text" : "RT @kilani19: @NickKristof you should send a signed copy to #Romney to read. \"Nobody dies due to lack of insurance\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas Kristof",
        "screen_name" : "NickKristof",
        "indices" : [ 0, 12 ],
        "id_str" : "17004618",
        "id" : 17004618
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Romney",
        "indices" : [ 46, 53 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "257461743155019776",
    "geo" : { },
    "id_str" : "257563195668041728",
    "in_reply_to_user_id" : 17004618,
    "text" : "@NickKristof you should send a signed copy to #Romney to read. \"Nobody dies due to lack of insurance\".",
    "id" : 257563195668041728,
    "in_reply_to_status_id" : 257461743155019776,
    "created_at" : "2012-10-14 19:27:05 +0000",
    "in_reply_to_screen_name" : "NickKristof",
    "in_reply_to_user_id_str" : "17004618",
    "user" : {
      "name" : "Marwa Kilani, M.D.",
      "screen_name" : "kilani19",
      "protected" : false,
      "id_str" : "519740228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1907287300\/image_normal.jpg",
      "id" : 519740228,
      "verified" : false
    }
  },
  "id" : 257566292494663680,
  "created_at" : "2012-10-14 19:39:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257535934424289280",
  "text" : "RT @Buddhaworld: freedom means: letting go. Volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257535320512421888",
    "text" : "freedom means: letting go. Volko",
    "id" : 257535320512421888,
    "created_at" : "2012-10-14 17:36:19 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 257535934424289280,
  "created_at" : "2012-10-14 17:38:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Fulgham",
      "screen_name" : "shanecrash",
      "indices" : [ 0, 11 ],
      "id_str" : "25030624",
      "id" : 25030624
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257529535736733696",
  "geo" : { },
  "id_str" : "257532065115934720",
  "in_reply_to_user_id" : 25030624,
  "text" : "@shanecrash i loved it.. but i also loved A Course In Miracles..",
  "id" : 257532065115934720,
  "in_reply_to_status_id" : 257529535736733696,
  "created_at" : "2012-10-14 17:23:23 +0000",
  "in_reply_to_screen_name" : "shanecrash",
  "in_reply_to_user_id_str" : "25030624",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "possessed",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257523125938425856",
  "text" : "that microwave has got to go.. omg.. scared me half to death! #possessed",
  "id" : 257523125938425856,
  "created_at" : "2012-10-14 16:47:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Js_Dark_Reality",
      "screen_name" : "Js_Dark_Reality",
      "indices" : [ 3, 19 ],
      "id_str" : "595805979",
      "id" : 595805979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257512649984724992",
  "text" : "RT @Js_Dark_Reality: How about we forget happily ever after, and just skip to happy right now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255846312744988672",
    "text" : "How about we forget happily ever after, and just skip to happy right now.",
    "id" : 255846312744988672,
    "created_at" : "2012-10-10 01:44:49 +0000",
    "user" : {
      "name" : "Js_Dark_Reality",
      "screen_name" : "Js_Dark_Reality",
      "protected" : false,
      "id_str" : "595805979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/457289169656885248\/1XVRYUpJ_normal.jpeg",
      "id" : 595805979,
      "verified" : false
    }
  },
  "id" : 257512649984724992,
  "created_at" : "2012-10-14 16:06:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chopper",
      "screen_name" : "chopper4jk",
      "indices" : [ 3, 14 ],
      "id_str" : "222234833",
      "id" : 222234833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257511437168156672",
  "text" : "RT @chopper4jk: If you could see the scars on the inside, you\u2019d never judge anyone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257365482590584833",
    "text" : "If you could see the scars on the inside, you\u2019d never judge anyone.",
    "id" : 257365482590584833,
    "created_at" : "2012-10-14 06:21:27 +0000",
    "user" : {
      "name" : "Chopper",
      "screen_name" : "chopper4jk",
      "protected" : false,
      "id_str" : "222234833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550157396845162496\/qGfo9azw_normal.jpeg",
      "id" : 222234833,
      "verified" : false
    }
  },
  "id" : 257511437168156672,
  "created_at" : "2012-10-14 16:01:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257498435622674432",
  "text" : "RT @libfirebrand: No, Mr. Ryan, Voters and Legislatures Should NOT Make Medical Decisions for Women | The People's View: http:\/\/t.co\/nHE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/nHEDzvhs",
        "expanded_url" : "http:\/\/www.thepeoplesview.net\/2012\/10\/no-mr-ryan-voters-and-legislatures.html#.UHrR1g328tU.twitter",
        "display_url" : "thepeoplesview.net\/2012\/10\/no-mr-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "257494371753160704",
    "text" : "No, Mr. Ryan, Voters and Legislatures Should NOT Make Medical Decisions for Women | The People's View: http:\/\/t.co\/nHEDzvhs",
    "id" : 257494371753160704,
    "created_at" : "2012-10-14 14:53:36 +0000",
    "user" : {
      "name" : "Craig",
      "screen_name" : "WorkingDemocrat",
      "protected" : false,
      "id_str" : "295783332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456091293907566592\/hiG6cHn3_normal.jpeg",
      "id" : 295783332,
      "verified" : false
    }
  },
  "id" : 257498435622674432,
  "created_at" : "2012-10-14 15:09:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257493957938909184",
  "text" : "i am part of \"we\". i am part of \"them\". cannot be separated.",
  "id" : 257493957938909184,
  "created_at" : "2012-10-14 14:51:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257493533240459264",
  "text" : "RT @abandontheherd: F____ it: The mantra of surrender",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257493144885686273",
    "text" : "F____ it: The mantra of surrender",
    "id" : 257493144885686273,
    "created_at" : "2012-10-14 14:48:44 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 257493533240459264,
  "created_at" : "2012-10-14 14:50:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257493045216419840",
  "text" : "@BibleAlsoSays we dont live in a vacuum.. yes, we are affected by others. we must learn to help each other.",
  "id" : 257493045216419840,
  "created_at" : "2012-10-14 14:48:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bainport.com",
      "screen_name" : "SaveSensataJobs",
      "indices" : [ 3, 19 ],
      "id_str" : "761709210",
      "id" : 761709210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/T4stD5VP",
      "expanded_url" : "http:\/\/tmblr.co\/ZjVuFuVGkjq6",
      "display_url" : "tmblr.co\/ZjVuFuVGkjq6"
    } ]
  },
  "geo" : { },
  "id_str" : "257491327619571713",
  "text" : "RT @SaveSensataJobs: Is This Why Romney Won't Talk to Sensata Workers Whose Jobs Are Being Shipped to China? http:\/\/t.co\/T4stD5VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/T4stD5VP",
        "expanded_url" : "http:\/\/tmblr.co\/ZjVuFuVGkjq6",
        "display_url" : "tmblr.co\/ZjVuFuVGkjq6"
      } ]
    },
    "geo" : { },
    "id_str" : "257489915007336448",
    "text" : "Is This Why Romney Won't Talk to Sensata Workers Whose Jobs Are Being Shipped to China? http:\/\/t.co\/T4stD5VP",
    "id" : 257489915007336448,
    "created_at" : "2012-10-14 14:35:54 +0000",
    "user" : {
      "name" : "Bainport.com",
      "screen_name" : "SaveSensataJobs",
      "protected" : false,
      "id_str" : "761709210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2642442612\/b16543919541e7da3ff4f7aa95696954_normal.jpeg",
      "id" : 761709210,
      "verified" : false
    }
  },
  "id" : 257491327619571713,
  "created_at" : "2012-10-14 14:41:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257490411327721472",
  "text" : "@BibleAlsoSays children are often wiser than adults.. they have not yet accumulated baggage to fog their view : )",
  "id" : 257490411327721472,
  "created_at" : "2012-10-14 14:37:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257489595481079808",
  "text" : "watching koch brothers exposed on current tv...",
  "id" : 257489595481079808,
  "created_at" : "2012-10-14 14:34:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257481625661739009",
  "geo" : { },
  "id_str" : "257482866429136898",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time clink! .. and now to get my 2nd cup : )",
  "id" : 257482866429136898,
  "in_reply_to_status_id" : 257481625661739009,
  "created_at" : "2012-10-14 14:07:53 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257480507254767616",
  "text" : "RT @TheGodLight: No belief is 100% watertight, there will always be an argument for &amp; against whatever you think or say.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257477561133703168",
    "text" : "No belief is 100% watertight, there will always be an argument for &amp; against whatever you think or say.",
    "id" : 257477561133703168,
    "created_at" : "2012-10-14 13:46:48 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 257480507254767616,
  "created_at" : "2012-10-14 13:58:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257480386978918401",
  "text" : "RT @parkstepp: Fear is the emotion that comes forth when you are choosing a thought... - john449: Fear is the emotion that c\u2026 http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/yY5RE0J2",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyVGcg3q",
        "display_url" : "tmblr.co\/ZwrrNyVGcg3q"
      } ]
    },
    "geo" : { },
    "id_str" : "257478224748113922",
    "text" : "Fear is the emotion that comes forth when you are choosing a thought... - john449: Fear is the emotion that c\u2026 http:\/\/t.co\/yY5RE0J2",
    "id" : 257478224748113922,
    "created_at" : "2012-10-14 13:49:27 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 257480386978918401,
  "created_at" : "2012-10-14 13:58:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257480178366820352",
  "text" : "RT @ZachsMind: Try this. Doubt Paris. What would it mean if Paris really didn't exist? What kind of conspiracy must there be to make you ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257478317979099136",
    "text" : "Try this. Doubt Paris. What would it mean if Paris really didn't exist? What kind of conspiracy must there be to make you believe it does?",
    "id" : 257478317979099136,
    "created_at" : "2012-10-14 13:49:49 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 257480178366820352,
  "created_at" : "2012-10-14 13:57:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/K8gI5DOW",
      "expanded_url" : "http:\/\/www.cnn.com\/2012\/10\/08\/world\/india-love-commandos\/index.html?hpt=hp_c2",
      "display_url" : "cnn.com\/2012\/10\/08\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257268407144181762",
  "text" : "RT @JacksonPearce: Someone has got to write a book about this. http:\/\/t.co\/K8gI5DOW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/K8gI5DOW",
        "expanded_url" : "http:\/\/www.cnn.com\/2012\/10\/08\/world\/india-love-commandos\/index.html?hpt=hp_c2",
        "display_url" : "cnn.com\/2012\/10\/08\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "257267030829453312",
    "text" : "Someone has got to write a book about this. http:\/\/t.co\/K8gI5DOW",
    "id" : 257267030829453312,
    "created_at" : "2012-10-13 23:50:14 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 257268407144181762,
  "created_at" : "2012-10-13 23:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((M. Markman)))",
      "screen_name" : "Mickeleh",
      "indices" : [ 3, 12 ],
      "id_str" : "13413",
      "id" : 13413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257249680017203200",
  "text" : "RT @Mickeleh: Remember the part where Romney said he needs new accountants because he never heard of tax break from moving jobs overseas ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sensata",
        "indices" : [ 124, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257237298607955968",
    "text" : "Remember the part where Romney said he needs new accountants because he never heard of tax break from moving jobs overseas? #Sensata",
    "id" : 257237298607955968,
    "created_at" : "2012-10-13 21:52:05 +0000",
    "user" : {
      "name" : "(((M. Markman)))",
      "screen_name" : "Mickeleh",
      "protected" : false,
      "id_str" : "13413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615313818923577344\/w1qh3_eE_normal.png",
      "id" : 13413,
      "verified" : false
    }
  },
  "id" : 257249680017203200,
  "created_at" : "2012-10-13 22:41:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela Weintraub",
      "screen_name" : "pam3001",
      "indices" : [ 3, 11 ],
      "id_str" : "22315090",
      "id" : 22315090
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PANDAS",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "Lyme",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257241138828824577",
  "text" : "RT @pam3001: parents of sick girl lose custody over treatment conflict in #PANDAS and #Lyme  to docs at Boston Children's Hospital.\nhttp ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PANDAS",
        "indices" : [ 61, 68 ]
      }, {
        "text" : "Lyme",
        "indices" : [ 73, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/8CdOXAwO",
        "expanded_url" : "http:\/\/chickiepea.wordpress.com\/2012\/10\/10\/words-fail-me\/",
        "display_url" : "chickiepea.wordpress.com\/2012\/10\/10\/wor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256224008385748992",
    "text" : "parents of sick girl lose custody over treatment conflict in #PANDAS and #Lyme  to docs at Boston Children's Hospital.\nhttp:\/\/t.co\/8CdOXAwO",
    "id" : 256224008385748992,
    "created_at" : "2012-10-11 02:45:38 +0000",
    "user" : {
      "name" : "Pamela Weintraub",
      "screen_name" : "pam3001",
      "protected" : false,
      "id_str" : "22315090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542191126824759297\/moZVt7vH_normal.jpeg",
      "id" : 22315090,
      "verified" : false
    }
  },
  "id" : 257241138828824577,
  "created_at" : "2012-10-13 22:07:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TinyMarkTwain",
      "screen_name" : "TinyMarkTwain",
      "indices" : [ 3, 17 ],
      "id_str" : "529561675",
      "id" : 529561675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257223378149187585",
  "text" : "RT @TinyMarkTwain: if you can't help people, at least don't hurt them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256984723077865472",
    "text" : "if you can't help people, at least don't hurt them.",
    "id" : 256984723077865472,
    "created_at" : "2012-10-13 05:08:27 +0000",
    "user" : {
      "name" : "TinyMarkTwain",
      "screen_name" : "TinyMarkTwain",
      "protected" : false,
      "id_str" : "529561675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789440986388701184\/juUKfbyH_normal.jpg",
      "id" : 529561675,
      "verified" : false
    }
  },
  "id" : 257223378149187585,
  "created_at" : "2012-10-13 20:56:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257203093480038400",
  "geo" : { },
  "id_str" : "257203894017458176",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell sounds lovely. goes perfect w your pic : )",
  "id" : 257203894017458176,
  "in_reply_to_status_id" : 257203093480038400,
  "created_at" : "2012-10-13 19:39:21 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257199587180306432",
  "geo" : { },
  "id_str" : "257201097385582592",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell whats the temp? im cold up here..lol",
  "id" : 257201097385582592,
  "in_reply_to_status_id" : 257199587180306432,
  "created_at" : "2012-10-13 19:28:14 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Piatt",
      "screen_name" : "christianpiatt",
      "indices" : [ 74, 89 ],
      "id_str" : "18725718",
      "id" : 18725718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/0XoQULBa",
      "expanded_url" : "http:\/\/shar.es\/5ROJn",
      "display_url" : "shar.es\/5ROJn"
    } ]
  },
  "geo" : { },
  "id_str" : "257189848883032064",
  "text" : "Louis C.K. on Our Neighbor\u2019s Bowl and What \u201CFair\u201D Is http:\/\/t.co\/0XoQULBa @christianpiatt",
  "id" : 257189848883032064,
  "created_at" : "2012-10-13 18:43:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257128224755159041",
  "text" : "i really cant blame ppl for voting for romney because they hate obama. im in reverse...",
  "id" : 257128224755159041,
  "created_at" : "2012-10-13 14:38:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257127248912580608",
  "text" : "what is the freakin big deal about birth control? humans have sex.. its part of being human!",
  "id" : 257127248912580608,
  "created_at" : "2012-10-13 14:34:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Joseph Mercola",
      "screen_name" : "mercola",
      "indices" : [ 96, 104 ],
      "id_str" : "12524522",
      "id" : 12524522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/3auvhhyI",
      "expanded_url" : "http:\/\/articles.mercola.com\/sites\/articles\/archive\/2012\/10\/13\/under-our-skin-documentary.aspx",
      "display_url" : "articles.mercola.com\/sites\/articles\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257126351025340417",
  "text" : "view for free-1 week: Under Our Skin: The Untold Story of Lyme Disease http:\/\/t.co\/3auvhhyI via @mercola",
  "id" : 257126351025340417,
  "created_at" : "2012-10-13 14:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257119656077299712",
  "text" : "@Skeptical_Lady omg'ness.. you need a ((hug))",
  "id" : 257119656077299712,
  "created_at" : "2012-10-13 14:04:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257110332684783618",
  "text" : "my dear stray kitty was hanging out on the porch last night. he watched raccoons from atop the chair. later on, curled up.",
  "id" : 257110332684783618,
  "created_at" : "2012-10-13 13:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/UrJokTrC",
      "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwVCI5Ud",
      "display_url" : "tmblr.co\/ZYrEZwVCI5Ud"
    } ]
  },
  "geo" : { },
  "id_str" : "257109528515067904",
  "text" : "RT @GeneDoucette: Romney: wizard? http:\/\/t.co\/UrJokTrC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 36 ],
        "url" : "http:\/\/t.co\/UrJokTrC",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwVCI5Ud",
        "display_url" : "tmblr.co\/ZYrEZwVCI5Ud"
      } ]
    },
    "geo" : { },
    "id_str" : "257107316535599104",
    "text" : "Romney: wizard? http:\/\/t.co\/UrJokTrC",
    "id" : 257107316535599104,
    "created_at" : "2012-10-13 13:15:35 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 257109528515067904,
  "created_at" : "2012-10-13 13:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hodgman",
      "screen_name" : "hodgman",
      "indices" : [ 3, 11 ],
      "id_str" : "14348594",
      "id" : 14348594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257108561107251200",
  "text" : "RT @hodgman: The idea that Romney \"misspoke\" his 47% line is so dumb. He outlined a whole thesis of 47% percenterism.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256597362175246336",
    "text" : "The idea that Romney \"misspoke\" his 47% line is so dumb. He outlined a whole thesis of 47% percenterism.",
    "id" : 256597362175246336,
    "created_at" : "2012-10-12 03:29:13 +0000",
    "user" : {
      "name" : "John Hodgman",
      "screen_name" : "hodgman",
      "protected" : false,
      "id_str" : "14348594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697809830698811392\/4DPUk7-a_normal.jpg",
      "id" : 14348594,
      "verified" : true
    }
  },
  "id" : 257108561107251200,
  "created_at" : "2012-10-13 13:20:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave The Hut",
      "screen_name" : "davethehut",
      "indices" : [ 0, 11 ],
      "id_str" : "4861845071",
      "id" : 4861845071
    }, {
      "name" : "Kenny Wyland",
      "screen_name" : "kennywyland",
      "indices" : [ 90, 102 ],
      "id_str" : "17197717",
      "id" : 17197717
    }, {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 103, 118 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257108096273506304",
  "text" : "@davethehut absolutely but the church ppl seem to think opposite; therin lies the problem @kennywyland @LoveHonorTruth",
  "id" : 257108096273506304,
  "created_at" : "2012-10-13 13:18:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255731373212569600",
  "geo" : { },
  "id_str" : "256920746662707201",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 sending good vibes to you. ((hugs))",
  "id" : 256920746662707201,
  "in_reply_to_status_id" : 255731373212569600,
  "created_at" : "2012-10-13 00:54:14 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256907256954777600",
  "geo" : { },
  "id_str" : "256908007001169920",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny does it have a marshmallow on it? lol",
  "id" : 256908007001169920,
  "in_reply_to_status_id" : 256907256954777600,
  "created_at" : "2012-10-13 00:03:36 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256858318847504384",
  "geo" : { },
  "id_str" : "256906462314524672",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny we are all energy giving off vibrations. the ppl i like vibrate on a similar freq. yes, I blv in woowoo : )",
  "id" : 256906462314524672,
  "in_reply_to_status_id" : 256858318847504384,
  "created_at" : "2012-10-12 23:57:28 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256903200559480832",
  "text" : "i love my possums. im always so happy to see them.",
  "id" : 256903200559480832,
  "created_at" : "2012-10-12 23:44:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256897369268961280",
  "text" : "follow the light, not the fear. its scary at first but it does get easier!",
  "id" : 256897369268961280,
  "created_at" : "2012-10-12 23:21:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256895535938670592",
  "geo" : { },
  "id_str" : "256896619893637120",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time i think life does begin at conception but not necessarily with soul. until that life lives outside the womb, mom 1st!",
  "id" : 256896619893637120,
  "in_reply_to_status_id" : 256895535938670592,
  "created_at" : "2012-10-12 23:18:21 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256887006045536256",
  "text" : "RT @oceanshaman: \"I got left behind!\" A tiny hatchling needed rescue.Psychologist Harlow knew babies need snuggly friends! http:\/\/t.co\/w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/wBdTuKjr",
        "expanded_url" : "http:\/\/twitpic.com\/b3jasu",
        "display_url" : "twitpic.com\/b3jasu"
      } ]
    },
    "geo" : { },
    "id_str" : "256886167537078274",
    "text" : "\"I got left behind!\" A tiny hatchling needed rescue.Psychologist Harlow knew babies need snuggly friends! http:\/\/t.co\/wBdTuKjr",
    "id" : 256886167537078274,
    "created_at" : "2012-10-12 22:36:49 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 256887006045536256,
  "created_at" : "2012-10-12 22:40:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Soulseeds",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/lN237Tx5",
      "expanded_url" : "http:\/\/tinyurl.com\/9ak9pj9",
      "display_url" : "tinyurl.com\/9ak9pj9"
    } ]
  },
  "geo" : { },
  "id_str" : "256885407868911617",
  "text" : "RT @Seeds4Parents: We learn something from everyone who passes through our lives. #Soulseeds http:\/\/t.co\/lN237Tx5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Soulseeds",
        "indices" : [ 63, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/lN237Tx5",
        "expanded_url" : "http:\/\/tinyurl.com\/9ak9pj9",
        "display_url" : "tinyurl.com\/9ak9pj9"
      } ]
    },
    "geo" : { },
    "id_str" : "256884981283041280",
    "text" : "We learn something from everyone who passes through our lives. #Soulseeds http:\/\/t.co\/lN237Tx5",
    "id" : 256884981283041280,
    "created_at" : "2012-10-12 22:32:06 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 256885407868911617,
  "created_at" : "2012-10-12 22:33:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daisy Harris",
      "screen_name" : "thedaisyharris",
      "indices" : [ 3, 18 ],
      "id_str" : "20724472",
      "id" : 20724472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256861270433751040",
  "text" : "RT @thedaisyharris: Funniest thing heard today at anti-gay-marriage rally: \"If this referendum passes, next thing we know, every bathroo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256860214236692481",
    "text" : "Funniest thing heard today at anti-gay-marriage rally: \"If this referendum passes, next thing we know, every bathroom in WA will be unisex!\"",
    "id" : 256860214236692481,
    "created_at" : "2012-10-12 20:53:41 +0000",
    "user" : {
      "name" : "Daisy Harris",
      "screen_name" : "thedaisyharris",
      "protected" : false,
      "id_str" : "20724472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735147605865299968\/N5OZ0l6Q_normal.jpg",
      "id" : 20724472,
      "verified" : false
    }
  },
  "id" : 256861270433751040,
  "created_at" : "2012-10-12 20:57:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LyinRyan",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256860074629283840",
  "text" : "RT @MWM4444: #LyinRyan: We don't think \"unelected judges\" should decide; we think women don't HAVE any right to control their own bodies ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LyinRyan",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "p2",
        "indices" : [ 125, 128 ]
      }, {
        "text" : "tcot",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256859585493737473",
    "text" : "#LyinRyan: We don't think \"unelected judges\" should decide; we think women don't HAVE any right to control their own bodies. #p2 #tcot",
    "id" : 256859585493737473,
    "created_at" : "2012-10-12 20:51:12 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 256860074629283840,
  "created_at" : "2012-10-12 20:53:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256853093189287936",
  "text" : "RT @SenSanders: The Ryan budget would kick up to 10 million Americans off Food Stamps, by cutting the program by more than $125 billion  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256852510692749312",
    "text" : "The Ryan budget would kick up to 10 million Americans off Food Stamps, by cutting the program by more than $125 billion over 10 years.",
    "id" : 256852510692749312,
    "created_at" : "2012-10-12 20:23:05 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 256853093189287936,
  "created_at" : "2012-10-12 20:25:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 0, 10 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256843751014678530",
  "geo" : { },
  "id_str" : "256844912086106112",
  "in_reply_to_user_id" : 14428947,
  "text" : "@bcmystery LOL.. be very careful! pod ppl can be tricky",
  "id" : 256844912086106112,
  "in_reply_to_status_id" : 256843751014678530,
  "created_at" : "2012-10-12 19:52:53 +0000",
  "in_reply_to_screen_name" : "bcmystery",
  "in_reply_to_user_id_str" : "14428947",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256842976360296449",
  "text" : "DD says im \"unbearably weird\" .. mission complete!",
  "id" : 256842976360296449,
  "created_at" : "2012-10-12 19:45:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "\u2020 Love an Atheist \u2020",
      "screen_name" : "Loveanatheist",
      "indices" : [ 37, 51 ],
      "id_str" : "419300133",
      "id" : 419300133
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256837280700973056",
  "geo" : { },
  "id_str" : "256841340183277569",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny basic law of attraction @Loveanatheist",
  "id" : 256841340183277569,
  "in_reply_to_status_id" : 256837280700973056,
  "created_at" : "2012-10-12 19:38:42 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256826674845450240",
  "geo" : { },
  "id_str" : "256827467145285632",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth ahh.. ok. . gotchya.",
  "id" : 256827467145285632,
  "in_reply_to_status_id" : 256826674845450240,
  "created_at" : "2012-10-12 18:43:34 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256826784430039040",
  "geo" : { },
  "id_str" : "256827151842693120",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth good to hear! : )",
  "id" : 256827151842693120,
  "in_reply_to_status_id" : 256826784430039040,
  "created_at" : "2012-10-12 18:42:19 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256819588916981760",
  "geo" : { },
  "id_str" : "256826534789251072",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth plus you were feeling under the weather yesterday. ((hugs))",
  "id" : 256826534789251072,
  "in_reply_to_status_id" : 256819588916981760,
  "created_at" : "2012-10-12 18:39:52 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    }, {
      "name" : "Kenny Wyland",
      "screen_name" : "kennywyland",
      "indices" : [ 34, 46 ],
      "id_str" : "17197717",
      "id" : 17197717
    }, {
      "name" : "Bill Maher",
      "screen_name" : "billmaher",
      "indices" : [ 47, 57 ],
      "id_str" : "19697415",
      "id" : 19697415
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256822381618790401",
  "geo" : { },
  "id_str" : "256826245680078849",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth what msg is that? @kennywyland @billmaher",
  "id" : 256826245680078849,
  "in_reply_to_status_id" : 256822381618790401,
  "created_at" : "2012-10-12 18:38:43 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256820961427484672",
  "text" : "RT @TheGoldenMirror: We can't always change the world, but we can always change the way we see it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256820565535498240",
    "text" : "We can't always change the world, but we can always change the way we see it.",
    "id" : 256820565535498240,
    "created_at" : "2012-10-12 18:16:08 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 256820961427484672,
  "created_at" : "2012-10-12 18:17:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256817325712494593",
  "text" : "RT @davidpakmanshow: Shocking that House SCIENCE committee member thinks evolution &amp; embryology are from the \"pit of hell\" http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/P87zLuWe",
        "expanded_url" : "http:\/\/ow.ly\/eqnpp",
        "display_url" : "ow.ly\/eqnpp"
      } ]
    },
    "geo" : { },
    "id_str" : "256816890410848256",
    "text" : "Shocking that House SCIENCE committee member thinks evolution &amp; embryology are from the \"pit of hell\" http:\/\/t.co\/P87zLuWe",
    "id" : 256816890410848256,
    "created_at" : "2012-10-12 18:01:32 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 256817325712494593,
  "created_at" : "2012-10-12 18:03:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Religion",
      "screen_name" : "HuffPostRelig",
      "indices" : [ 3, 17 ],
      "id_str" : "117189136",
      "id" : 117189136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256810945001684992",
  "text" : "RT @HuffPostRelig: \u201CThe moment God is figured out with nice neat lines and definitions, we are no longer dealing with God.\u201D -- Rob Bell",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256582466645663744",
    "text" : "\u201CThe moment God is figured out with nice neat lines and definitions, we are no longer dealing with God.\u201D -- Rob Bell",
    "id" : 256582466645663744,
    "created_at" : "2012-10-12 02:30:01 +0000",
    "user" : {
      "name" : "HuffPost Religion",
      "screen_name" : "HuffPostRelig",
      "protected" : false,
      "id_str" : "117189136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1184014153\/religion_tw_normal.png",
      "id" : 117189136,
      "verified" : true
    }
  },
  "id" : 256810945001684992,
  "created_at" : "2012-10-12 17:37:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purplepoetry77",
      "screen_name" : "purplepoetry77",
      "indices" : [ 3, 18 ],
      "id_str" : "2511633660",
      "id" : 2511633660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sixwords",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256806511920173056",
  "text" : "RT @purplepoetry77: I refuse to live in fear #sixwords",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sixwords",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256805476145176578",
    "text" : "I refuse to live in fear #sixwords",
    "id" : 256805476145176578,
    "created_at" : "2012-10-12 17:16:11 +0000",
    "user" : {
      "name" : "poemscape",
      "screen_name" : "poemscape",
      "protected" : true,
      "id_str" : "310624642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552530565875105796\/G7vcRm1e_normal.jpeg",
      "id" : 310624642,
      "verified" : false
    }
  },
  "id" : 256806511920173056,
  "created_at" : "2012-10-12 17:20:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256794333011918849",
  "text" : "whats important to me may not be whats important to you...",
  "id" : 256794333011918849,
  "created_at" : "2012-10-12 16:31:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/o640dvYc",
      "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwV8buoW",
      "display_url" : "tmblr.co\/ZYrEZwV8buoW"
    } ]
  },
  "geo" : { },
  "id_str" : "256769485904691200",
  "text" : "RT @GeneDoucette: Biden rude? http:\/\/t.co\/o640dvYc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 32 ],
        "url" : "http:\/\/t.co\/o640dvYc",
        "expanded_url" : "http:\/\/tmblr.co\/ZYrEZwV8buoW",
        "display_url" : "tmblr.co\/ZYrEZwV8buoW"
      } ]
    },
    "geo" : { },
    "id_str" : "256768675107966976",
    "text" : "Biden rude? http:\/\/t.co\/o640dvYc",
    "id" : 256768675107966976,
    "created_at" : "2012-10-12 14:49:57 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 256769485904691200,
  "created_at" : "2012-10-12 14:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256765964996186112",
  "text" : "RT @JohnCali: It is not insult from another that causes you pain. It is the part of your mind that agrees with the insult. ~ Alan Cohen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256764142562705409",
    "text" : "It is not insult from another that causes you pain. It is the part of your mind that agrees with the insult. ~ Alan Cohen",
    "id" : 256764142562705409,
    "created_at" : "2012-10-12 14:31:56 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 256765964996186112,
  "created_at" : "2012-10-12 14:39:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256765922474344448",
  "text" : "RT @JohnCali: There's nothing unpleasant, unkind, or unjust that has ever happened within all of time &amp; space that I won't eventuall ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256764316617957376",
    "text" : "There's nothing unpleasant, unkind, or unjust that has ever happened within all of time &amp; space that I won't eventually undo.. The Universe",
    "id" : 256764316617957376,
    "created_at" : "2012-10-12 14:32:38 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 256765922474344448,
  "created_at" : "2012-10-12 14:39:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256762186062516224",
  "geo" : { },
  "id_str" : "256762593530744832",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses i noticed! LOL",
  "id" : 256762593530744832,
  "in_reply_to_status_id" : 256762186062516224,
  "created_at" : "2012-10-12 14:25:47 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CHAD MICAH JOHNSON",
      "screen_name" : "153grover",
      "indices" : [ 3, 13 ],
      "id_str" : "28173386",
      "id" : 28173386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "centerthedebate",
      "indices" : [ 15, 31 ]
    }, {
      "text" : "biden",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256760148788408322",
  "text" : "RT @153grover: #centerthedebate its presidential for romney to interupt telling lies and its rude for #biden to interupt to stop the lie ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "centerthedebate",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "biden",
        "indices" : [ 87, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256749353543294976",
    "text" : "#centerthedebate its presidential for romney to interupt telling lies and its rude for #biden to interupt to stop the lies? i dont get it.",
    "id" : 256749353543294976,
    "created_at" : "2012-10-12 13:33:10 +0000",
    "user" : {
      "name" : "CHAD MICAH JOHNSON",
      "screen_name" : "153grover",
      "protected" : false,
      "id_str" : "28173386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/683842710453669888\/-1vvfQ9t_normal.jpg",
      "id" : 28173386,
      "verified" : false
    }
  },
  "id" : 256760148788408322,
  "created_at" : "2012-10-12 14:16:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "indices" : [ 3, 13 ],
      "id_str" : "41457590",
      "id" : 41457590
    }, {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 22, 35 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256749341610500097",
  "text" : "RT @38harmony: :)  RT @earthXplorer: \"We taste &amp; feel &amp; see the truth. We do not reason ourselves into it\" ~W.B. Yeats",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JD ANDREWS",
        "screen_name" : "earthXplorer",
        "indices" : [ 7, 20 ],
        "id_str" : "7350962",
        "id" : 7350962
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256749225390510080",
    "text" : ":)  RT @earthXplorer: \"We taste &amp; feel &amp; see the truth. We do not reason ourselves into it\" ~W.B. Yeats",
    "id" : 256749225390510080,
    "created_at" : "2012-10-12 13:32:40 +0000",
    "user" : {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "protected" : false,
      "id_str" : "41457590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1671334755\/2-HH-5-27-7_normal.jpg",
      "id" : 41457590,
      "verified" : false
    }
  },
  "id" : 256749341610500097,
  "created_at" : "2012-10-12 13:33:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "indices" : [ 3, 11 ],
      "id_str" : "50815971",
      "id" : 50815971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256749281380294656",
  "text" : "RT @Palidan: \"Most of us don't realize what an impact we have on the world around us. A positive energy field affects others beneficiall ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256748823056097281",
    "text" : "\"Most of us don't realize what an impact we have on the world around us. A positive energy field affects others beneficially.\" L. LaRoche",
    "id" : 256748823056097281,
    "created_at" : "2012-10-12 13:31:04 +0000",
    "user" : {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "protected" : false,
      "id_str" : "50815971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747718513\/twitter_background_normal.jpg",
      "id" : 50815971,
      "verified" : false
    }
  },
  "id" : 256749281380294656,
  "created_at" : "2012-10-12 13:32:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 71, 84 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256748373145702400",
  "text" : "RT @gemswinc: Nature lover, App developer, &amp; great guy.. Check out @MyNatureApps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeff",
        "screen_name" : "MyNatureApps",
        "indices" : [ 57, 70 ],
        "id_str" : "93072985",
        "id" : 93072985
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256748109680496641",
    "text" : "Nature lover, App developer, &amp; great guy.. Check out @MyNatureApps",
    "id" : 256748109680496641,
    "created_at" : "2012-10-12 13:28:14 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 256748373145702400,
  "created_at" : "2012-10-12 13:29:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256747076153638913",
  "text" : "some ppl thought biden came across rude. i felt same way about romney. #debates",
  "id" : 256747076153638913,
  "created_at" : "2012-10-12 13:24:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256742554668789760",
  "geo" : { },
  "id_str" : "256745140624953345",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses french toast!",
  "id" : 256745140624953345,
  "in_reply_to_status_id" : 256742554668789760,
  "created_at" : "2012-10-12 13:16:26 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yankeluh",
      "screen_name" : "Yankeluh",
      "indices" : [ 3, 12 ],
      "id_str" : "20792672",
      "id" : 20792672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256739365030608896",
  "text" : "RT @Yankeluh: RichAssholes think everyone else gets free medcareWhy don't they drop their insurance and get the same FREE healthcare? ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/56uftpWL",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2012\/10\/11\/mitt-romney-health-insurance_n_1957419.html?ncid=edlinkusaolp00000003",
        "display_url" : "huffingtonpost.com\/2012\/10\/11\/mit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256738021184004096",
    "text" : "RichAssholes think everyone else gets free medcareWhy don't they drop their insurance and get the same FREE healthcare? http:\/\/t.co\/56uftpWL",
    "id" : 256738021184004096,
    "created_at" : "2012-10-12 12:48:08 +0000",
    "user" : {
      "name" : "Yankeluh",
      "screen_name" : "Yankeluh",
      "protected" : false,
      "id_str" : "20792672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/201778335\/counter_normal.jpg",
      "id" : 20792672,
      "verified" : false
    }
  },
  "id" : 256739365030608896,
  "created_at" : "2012-10-12 12:53:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256736049693331456",
  "text" : "im a curious sort and keep peering into the darkness.. then i get off track. just follow the light and all will be fine. : )",
  "id" : 256736049693331456,
  "created_at" : "2012-10-12 12:40:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256580268910071808",
  "geo" : { },
  "id_str" : "256580786227118080",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny LOLOL.. i'll take that.. : )",
  "id" : 256580786227118080,
  "in_reply_to_status_id" : 256580268910071808,
  "created_at" : "2012-10-12 02:23:21 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256573835543969793",
  "geo" : { },
  "id_str" : "256576983058771968",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny not me.. ive superglued myself to your pant leg.. hehe",
  "id" : 256576983058771968,
  "in_reply_to_status_id" : 256573835543969793,
  "created_at" : "2012-10-12 02:08:14 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256568073912479744",
  "geo" : { },
  "id_str" : "256568902203604992",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time omg! 1st thing I said to hubby when this debate started.. LOL",
  "id" : 256568902203604992,
  "in_reply_to_status_id" : 256568073912479744,
  "created_at" : "2012-10-12 01:36:07 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela Cummins",
      "screen_name" : "RevPamela",
      "indices" : [ 3, 13 ],
      "id_str" : "385484516",
      "id" : 385484516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256566800383344640",
  "text" : "RT @RevPamela: Choose love over fear!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256512445546369024",
    "text" : "Choose love over fear!",
    "id" : 256512445546369024,
    "created_at" : "2012-10-11 21:51:47 +0000",
    "user" : {
      "name" : "Pamela Cummins",
      "screen_name" : "RevPamela",
      "protected" : false,
      "id_str" : "385484516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3226728558\/f7ef88f9fd24cbe2d65cc045b0693889_normal.jpeg",
      "id" : 385484516,
      "verified" : false
    }
  },
  "id" : 256566800383344640,
  "created_at" : "2012-10-12 01:27:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256566565225496576",
  "text" : "RT @TyrusBooks: I'm four years closer to my death. Why hasn't the government stopped this?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256565116588412928",
    "text" : "I'm four years closer to my death. Why hasn't the government stopped this?",
    "id" : 256565116588412928,
    "created_at" : "2012-10-12 01:21:05 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 256566565225496576,
  "created_at" : "2012-10-12 01:26:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "indices" : [ 3, 17 ],
      "id_str" : "38596022",
      "id" : 38596022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256559298044379136",
  "text" : "RT @livingthepoem: And scores of angels watched, in great anticipation...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256559115046879232",
    "text" : "And scores of angels watched, in great anticipation...",
    "id" : 256559115046879232,
    "created_at" : "2012-10-12 00:57:14 +0000",
    "user" : {
      "name" : "Steve Robison",
      "screen_name" : "livingthepoem",
      "protected" : false,
      "id_str" : "38596022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741293678854086656\/P_FDuZdJ_normal.jpg",
      "id" : 38596022,
      "verified" : false
    }
  },
  "id" : 256559298044379136,
  "created_at" : "2012-10-12 00:57:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256554476800987136",
  "geo" : { },
  "id_str" : "256554921896325120",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt LOL",
  "id" : 256554921896325120,
  "in_reply_to_status_id" : 256554476800987136,
  "created_at" : "2012-10-12 00:40:34 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256543768679968768",
  "text" : "i turn my back and the raccoons  take over. had to get kitty 2nd meal. then poor possum shows up but he runs. he'll come back.",
  "id" : 256543768679968768,
  "created_at" : "2012-10-11 23:56:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256526147469324288",
  "text" : "healthcare is not a service or product for convenience. it should not be privatized.",
  "id" : 256526147469324288,
  "created_at" : "2012-10-11 22:46:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "about.me",
      "screen_name" : "aboutdotme",
      "indices" : [ 0, 11 ],
      "id_str" : "115304519",
      "id" : 115304519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/4LSTWNQY",
      "expanded_url" : "http:\/\/abfabgab.com",
      "display_url" : "abfabgab.com"
    }, {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/T2IOtN9z",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "256519251274387456",
  "in_reply_to_user_id" : 115304519,
  "text" : "@aboutdotme i added the widget to both my blogs.. http:\/\/t.co\/4LSTWNQY and http:\/\/t.co\/T2IOtN9z .. I like it!",
  "id" : 256519251274387456,
  "created_at" : "2012-10-11 22:18:50 +0000",
  "in_reply_to_screen_name" : "aboutdotme",
  "in_reply_to_user_id_str" : "115304519",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "indices" : [ 3, 14 ],
      "id_str" : "29442313",
      "id" : 29442313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256518037908357120",
  "text" : "RT @SenSanders: Slashing Medicaid as Paul Ryan wants to do could cost more than 2 million private-sector jobs over the next 5 years alone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256517336884981762",
    "text" : "Slashing Medicaid as Paul Ryan wants to do could cost more than 2 million private-sector jobs over the next 5 years alone.",
    "id" : 256517336884981762,
    "created_at" : "2012-10-11 22:11:13 +0000",
    "user" : {
      "name" : "Bernie Sanders",
      "screen_name" : "SenSanders",
      "protected" : false,
      "id_str" : "29442313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794619281271033856\/Fs0QQaH7_normal.jpg",
      "id" : 29442313,
      "verified" : true
    }
  },
  "id" : 256518037908357120,
  "created_at" : "2012-10-11 22:14:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256515898830094337",
  "text" : "we just did a family sing along to \"here, have some wine!\" LOL",
  "id" : 256515898830094337,
  "created_at" : "2012-10-11 22:05:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 0, 15 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256513896163188736",
  "geo" : { },
  "id_str" : "256514518807609344",
  "in_reply_to_user_id" : 7981702,
  "text" : "@TheEntertainer HELL YEAH! : )",
  "id" : 256514518807609344,
  "in_reply_to_status_id" : 256513896163188736,
  "created_at" : "2012-10-11 22:00:01 +0000",
  "in_reply_to_screen_name" : "TheEntertainer",
  "in_reply_to_user_id_str" : "7981702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256512878566309888",
  "geo" : { },
  "id_str" : "256513664457265152",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater heehee : D",
  "id" : 256513664457265152,
  "in_reply_to_status_id" : 256512878566309888,
  "created_at" : "2012-10-11 21:56:38 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256510620281761792",
  "text" : "RT @BrianMerritt: It is time to realize that freedom can neither be given by humans or taken by them either.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256500662060326912",
    "text" : "It is time to realize that freedom can neither be given by humans or taken by them either.",
    "id" : 256500662060326912,
    "created_at" : "2012-10-11 21:04:58 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 256510620281761792,
  "created_at" : "2012-10-11 21:44:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256501356586737664",
  "geo" : { },
  "id_str" : "256510483228659712",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench how I hate that when hubby does not \"cooperate\" .. LOL",
  "id" : 256510483228659712,
  "in_reply_to_status_id" : 256501356586737664,
  "created_at" : "2012-10-11 21:43:59 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 3, 18 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256509994948784128",
  "text" : "RT @LoveHonorTruth: If you are prochoice and are not voting for Obama this election, this could cause a conservative supreme court justi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256503707737419776",
    "text" : "If you are prochoice and are not voting for Obama this election, this could cause a conservative supreme court justice to be appointed.",
    "id" : 256503707737419776,
    "created_at" : "2012-10-11 21:17:04 +0000",
    "user" : {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "protected" : false,
      "id_str" : "167958125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525129289336107008\/HMsrT9oV_normal.jpeg",
      "id" : 167958125,
      "verified" : false
    }
  },
  "id" : 256509994948784128,
  "created_at" : "2012-10-11 21:42:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    }, {
      "name" : "mae brown",
      "screen_name" : "jesseimae",
      "indices" : [ 18, 28 ],
      "id_str" : "279870995",
      "id" : 279870995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256481535572721664",
  "text" : "RT @Jamiastar: RT @jesseimae: Why do humans need to rule each other Why can't they just be?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mae brown",
        "screen_name" : "jesseimae",
        "indices" : [ 3, 13 ],
        "id_str" : "279870995",
        "id" : 279870995
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256481300343562240",
    "text" : "RT @jesseimae: Why do humans need to rule each other Why can't they just be?",
    "id" : 256481300343562240,
    "created_at" : "2012-10-11 19:48:01 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 256481535572721664,
  "created_at" : "2012-10-11 19:48:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256460117543899136",
  "text" : "calling ppl dumb does not help matters any...",
  "id" : 256460117543899136,
  "created_at" : "2012-10-11 18:23:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bainport.com",
      "screen_name" : "SaveSensataJobs",
      "indices" : [ 3, 19 ],
      "id_str" : "761709210",
      "id" : 761709210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256448235642699776",
  "text" : "RT @SaveSensataJobs: \u201CMitt Romney likes to say that he knows nothing about tax breaks for off-shoring American jobs, or that h\u2026\u201D http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/R4qz7V4p",
        "expanded_url" : "http:\/\/tmblr.co\/ZjVuFuV56jd-",
        "display_url" : "tmblr.co\/ZjVuFuV56jd-"
      } ]
    },
    "geo" : { },
    "id_str" : "256447634426978306",
    "text" : "\u201CMitt Romney likes to say that he knows nothing about tax breaks for off-shoring American jobs, or that h\u2026\u201D http:\/\/t.co\/R4qz7V4p",
    "id" : 256447634426978306,
    "created_at" : "2012-10-11 17:34:15 +0000",
    "user" : {
      "name" : "Bainport.com",
      "screen_name" : "SaveSensataJobs",
      "protected" : false,
      "id_str" : "761709210",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2642442612\/b16543919541e7da3ff4f7aa95696954_normal.jpeg",
      "id" : 761709210,
      "verified" : false
    }
  },
  "id" : 256448235642699776,
  "created_at" : "2012-10-11 17:36:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Jon Husband",
      "screen_name" : "jonhusband",
      "indices" : [ 42, 53 ],
      "id_str" : "13298",
      "id" : 13298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256420787496550400",
  "geo" : { },
  "id_str" : "256424478190473216",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen ultimate \"life\" tool! : ) @jonhusband",
  "id" : 256424478190473216,
  "in_reply_to_status_id" : 256420787496550400,
  "created_at" : "2012-10-11 16:02:14 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256421174102351872",
  "geo" : { },
  "id_str" : "256424253480640512",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth ick! feel better soon! ((hugs))",
  "id" : 256424253480640512,
  "in_reply_to_status_id" : 256421174102351872,
  "created_at" : "2012-10-11 16:01:20 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/4LSTWNQY",
      "expanded_url" : "http:\/\/abfabgab.com",
      "display_url" : "abfabgab.com"
    }, {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/T2IOtN9z",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "256415258275631105",
  "text" : "added the about.me widget to both http:\/\/t.co\/4LSTWNQY and http:\/\/t.co\/T2IOtN9z",
  "id" : 256415258275631105,
  "created_at" : "2012-10-11 15:25:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256403136435060737",
  "geo" : { },
  "id_str" : "256403480800014336",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie ahh.. yes, it does make small cups..",
  "id" : 256403480800014336,
  "in_reply_to_status_id" : 256403136435060737,
  "created_at" : "2012-10-11 14:38:48 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256401371740393472",
  "geo" : { },
  "id_str" : "256402314930302979",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie we have a keurig. we got a refillable kcup so we can use our own coffee...",
  "id" : 256402314930302979,
  "in_reply_to_status_id" : 256401371740393472,
  "created_at" : "2012-10-11 14:34:10 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/256399131227090944\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/I1EFYj2V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A47ppsICcAAAmuk.jpg",
      "id_str" : "256399131235479552",
      "id" : 256399131235479552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A47ppsICcAAAmuk.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/I1EFYj2V"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/ftKN6eM9",
      "expanded_url" : "http:\/\/www.dailygalaxy.com\/my_weblog\/2012\/10\/new-math-allows-for-travel-beyond-speed-of-light.html",
      "display_url" : "dailygalaxy.com\/my_weblog\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256399588515258369",
  "text" : "RT @dailygalaxy: New Math Breakthrough Allows for Travel Beyond Speed of Light\nhttp:\/\/t.co\/ftKN6eM9 http:\/\/t.co\/I1EFYj2V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/256399131227090944\/photo\/1",
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/I1EFYj2V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A47ppsICcAAAmuk.jpg",
        "id_str" : "256399131235479552",
        "id" : 256399131235479552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A47ppsICcAAAmuk.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/I1EFYj2V"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/ftKN6eM9",
        "expanded_url" : "http:\/\/www.dailygalaxy.com\/my_weblog\/2012\/10\/new-math-allows-for-travel-beyond-speed-of-light.html",
        "display_url" : "dailygalaxy.com\/my_weblog\/2012\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256399131227090944",
    "text" : "New Math Breakthrough Allows for Travel Beyond Speed of Light\nhttp:\/\/t.co\/ftKN6eM9 http:\/\/t.co\/I1EFYj2V",
    "id" : 256399131227090944,
    "created_at" : "2012-10-11 14:21:31 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 256399588515258369,
  "created_at" : "2012-10-11 14:23:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256398936724606976",
  "text" : "so proud of myself.. i switched out batteries for my m-edge light for my kindle.. woohoo!",
  "id" : 256398936724606976,
  "created_at" : "2012-10-11 14:20:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256394052524703744",
  "geo" : { },
  "id_str" : "256396302408105986",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks lots of aha moments. clarified my world view. everything is perception. we all uniquely perceive.",
  "id" : 256396302408105986,
  "in_reply_to_status_id" : 256394052524703744,
  "created_at" : "2012-10-11 14:10:16 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256393083015528448",
  "geo" : { },
  "id_str" : "256393723682885633",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks A Course in Miracles, 5yrs ago, yes (til I die)",
  "id" : 256393723682885633,
  "in_reply_to_status_id" : 256393083015528448,
  "created_at" : "2012-10-11 14:00:01 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "\u266ABlue Vino\u266B\uD83D\uDC38",
      "screen_name" : "BlueVino",
      "indices" : [ 79, 88 ],
      "id_str" : "41271900",
      "id" : 41271900
    }, {
      "name" : "Ian Gibson",
      "screen_name" : "SlagBass",
      "indices" : [ 89, 98 ],
      "id_str" : "21755936",
      "id" : 21755936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256392732719849472",
  "text" : "@BibleAlsoSays you remind me of the tough little terrier that wont let go! : ) @BlueVino @SlagBass",
  "id" : 256392732719849472,
  "created_at" : "2012-10-11 13:56:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u266ABlue Vino\u266B\uD83D\uDC38",
      "screen_name" : "BlueVino",
      "indices" : [ 0, 9 ],
      "id_str" : "41271900",
      "id" : 41271900
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 39, 53 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Ian Gibson",
      "screen_name" : "SlagBass",
      "indices" : [ 54, 63 ],
      "id_str" : "21755936",
      "id" : 21755936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256047413553414144",
  "geo" : { },
  "id_str" : "256387800730046464",
  "in_reply_to_user_id" : 41271900,
  "text" : "@BlueVino LOLOL (i love this comment!) @BibleAlsoSays @SlagBass",
  "id" : 256387800730046464,
  "in_reply_to_status_id" : 256047413553414144,
  "created_at" : "2012-10-11 13:36:29 +0000",
  "in_reply_to_screen_name" : "BlueVino",
  "in_reply_to_user_id_str" : "41271900",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dream",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256386840016343040",
  "text" : "zombies last night.. huh.. #dream",
  "id" : 256386840016343040,
  "created_at" : "2012-10-11 13:32:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256176155160363008",
  "text" : "RT @earthXplorer: You are what you Tweet! :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256175676128899072",
    "text" : "You are what you Tweet! :)",
    "id" : 256175676128899072,
    "created_at" : "2012-10-10 23:33:35 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 256176155160363008,
  "created_at" : "2012-10-10 23:35:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256159791100067841",
  "text" : "@Skeptical_Lady awww.. precious!",
  "id" : 256159791100067841,
  "created_at" : "2012-10-10 22:30:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256159540985331713",
  "text" : "RT @gemswinc: Twitter is my psycotherapist :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256159475399016449",
    "text" : "Twitter is my psycotherapist :-)",
    "id" : 256159475399016449,
    "created_at" : "2012-10-10 22:29:12 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 256159540985331713,
  "created_at" : "2012-10-10 22:29:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "laetitia Marchbank",
      "screen_name" : "LMarchbank",
      "indices" : [ 17, 28 ],
      "id_str" : "1875847746",
      "id" : 1875847746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256134163869081603",
  "text" : "RT @CoyoteSings: @lmarchbank I *expect* children to be intolerable. I expect adults to have learned a thing or two about patience along  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "laetitia Marchbank",
        "screen_name" : "LMarchbank",
        "indices" : [ 0, 11 ],
        "id_str" : "1875847746",
        "id" : 1875847746
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "256130655283453952",
    "geo" : { },
    "id_str" : "256131072440549376",
    "in_reply_to_user_id" : 465711806,
    "text" : "@lmarchbank I *expect* children to be intolerable. I expect adults to have learned a thing or two about patience along the way.",
    "id" : 256131072440549376,
    "in_reply_to_status_id" : 256130655283453952,
    "created_at" : "2012-10-10 20:36:21 +0000",
    "in_reply_to_screen_name" : "llpot",
    "in_reply_to_user_id_str" : "465711806",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 256134163869081603,
  "created_at" : "2012-10-10 20:48:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Wright",
      "screen_name" : "StephBWright",
      "indices" : [ 3, 16 ],
      "id_str" : "264808483",
      "id" : 264808483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256130223404355585",
  "text" : "RT @StephBWright: Sorry, but your password must contain an uppercase letter, a number, a punctuation mark, a gang sign, an extinct mamma ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256029401546895360",
    "text" : "Sorry, but your password must contain an uppercase letter, a number, a punctuation mark, a gang sign, an extinct mammal and a hieroglyph.",
    "id" : 256029401546895360,
    "created_at" : "2012-10-10 13:52:20 +0000",
    "user" : {
      "name" : "Stephanie Wright",
      "screen_name" : "StephBWright",
      "protected" : false,
      "id_str" : "264808483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561200891475148801\/7NPA54Ul_normal.jpeg",
      "id" : 264808483,
      "verified" : false
    }
  },
  "id" : 256130223404355585,
  "created_at" : "2012-10-10 20:32:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256129982416424960",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings when my DD was small, I was told to spank.. but it seemed hypocritical when we teach kids \"hitting is bad\"",
  "id" : 256129982416424960,
  "created_at" : "2012-10-10 20:32:01 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256123088494792704",
  "geo" : { },
  "id_str" : "256125341901406211",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott this was in my TL earlier but in condescending manner..",
  "id" : 256125341901406211,
  "in_reply_to_status_id" : 256123088494792704,
  "created_at" : "2012-10-10 20:13:34 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnneOnymous670",
      "screen_name" : "AnneOnymous670",
      "indices" : [ 3, 18 ],
      "id_str" : "784794524",
      "id" : 784794524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/hcqteVOY",
      "expanded_url" : "http:\/\/www.globallabourrights.org\/reports?id=0653#.UHXEm2Epbow.twitter",
      "display_url" : "globallabourrights.org\/reports?id=065\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256114610158071808",
  "text" : "RT @AnneOnymous670: What Does Romney's Bain Capital\/Sensata Technologies Have to Hide? http:\/\/t.co\/hcqteVOY Updated Report",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/hcqteVOY",
        "expanded_url" : "http:\/\/www.globallabourrights.org\/reports?id=0653#.UHXEm2Epbow.twitter",
        "display_url" : "globallabourrights.org\/reports?id=065\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256109521850740737",
    "text" : "What Does Romney's Bain Capital\/Sensata Technologies Have to Hide? http:\/\/t.co\/hcqteVOY Updated Report",
    "id" : 256109521850740737,
    "created_at" : "2012-10-10 19:10:42 +0000",
    "user" : {
      "name" : "AnneOnymous670",
      "screen_name" : "AnneOnymous670",
      "protected" : false,
      "id_str" : "784794524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565233323920732160\/wYFPwogL_normal.jpeg",
      "id" : 784794524,
      "verified" : false
    }
  },
  "id" : 256114610158071808,
  "created_at" : "2012-10-10 19:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256107825061822464",
  "geo" : { },
  "id_str" : "256108479071260672",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen ive sat outside in yard w book.. maybe 2 hrs at most, tho.",
  "id" : 256108479071260672,
  "in_reply_to_status_id" : 256107825061822464,
  "created_at" : "2012-10-10 19:06:34 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "court",
      "screen_name" : "TeaLeafEmpress_",
      "indices" : [ 3, 19 ],
      "id_str" : "20627148",
      "id" : 20627148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256107843890057217",
  "text" : "RT @TeaLeafEmpress_: \"One tragedy of being inwardly asleep is that an awakened man does not exist to our perception, therefore his aid i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256102717481697280",
    "text" : "\"One tragedy of being inwardly asleep is that an awakened man does not exist to our perception, therefore his aid is ignored.\"",
    "id" : 256102717481697280,
    "created_at" : "2012-10-10 18:43:40 +0000",
    "user" : {
      "name" : "court",
      "screen_name" : "TeaLeafEmpress_",
      "protected" : false,
      "id_str" : "20627148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734188075484598272\/AFH1a-lI_normal.jpg",
      "id" : 20627148,
      "verified" : false
    }
  },
  "id" : 256107843890057217,
  "created_at" : "2012-10-10 19:04:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256105113112956929",
  "geo" : { },
  "id_str" : "256106662321082369",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen for the most part, yes I think so..lol",
  "id" : 256106662321082369,
  "in_reply_to_status_id" : 256105113112956929,
  "created_at" : "2012-10-10 18:59:21 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256104793095950337",
  "geo" : { },
  "id_str" : "256106097579020288",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen also I believe I get delayed emotional responses sometimes...",
  "id" : 256106097579020288,
  "in_reply_to_status_id" : 256104793095950337,
  "created_at" : "2012-10-10 18:57:06 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256104793095950337",
  "geo" : { },
  "id_str" : "256105782712619008",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen dont like laughing either.. if I laugh too much it goes into hysterics.. very strange. think my emotion neurons are whacked!",
  "id" : 256105782712619008,
  "in_reply_to_status_id" : 256104793095950337,
  "created_at" : "2012-10-10 18:55:51 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256102525374169088",
  "geo" : { },
  "id_str" : "256103675796267008",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen you are correct, of course : ) i usually try to stay away from that word...",
  "id" : 256103675796267008,
  "in_reply_to_status_id" : 256102525374169088,
  "created_at" : "2012-10-10 18:47:29 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256102690797531139",
  "geo" : { },
  "id_str" : "256103203731562496",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms hmm.. good question! it does make me uncomfortable...",
  "id" : 256103203731562496,
  "in_reply_to_status_id" : 256102690797531139,
  "created_at" : "2012-10-10 18:45:36 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256101231666266112",
  "text" : "i hate emotions. i dont like feeling them. i avoid them...",
  "id" : 256101231666266112,
  "created_at" : "2012-10-10 18:37:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/xN6tRI2X",
      "expanded_url" : "http:\/\/shar.es\/5Efic",
      "display_url" : "shar.es\/5Efic"
    } ]
  },
  "geo" : { },
  "id_str" : "256084250258976768",
  "text" : "hubby says i'm trevor.. LOL &gt;&gt; Im Telling You The Man And The Dog Are Working Together http:\/\/t.co\/xN6tRI2X",
  "id" : 256084250258976768,
  "created_at" : "2012-10-10 17:30:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Pluck",
      "screen_name" : "tommysalami",
      "indices" : [ 3, 15 ],
      "id_str" : "261888721",
      "id" : 261888721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256055964803948544",
  "text" : "RT @tommysalami: I can understand if you don't like Obama. But trusting Romney is beyond me. He changes positions faster than a Kama Sut ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256055819181895682",
    "text" : "I can understand if you don't like Obama. But trusting Romney is beyond me. He changes positions faster than a Kama Sutra flipbook.",
    "id" : 256055819181895682,
    "created_at" : "2012-10-10 15:37:19 +0000",
    "user" : {
      "name" : "Thomas Pluck",
      "screen_name" : "thomaspluck",
      "protected" : false,
      "id_str" : "17592150",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797948304390819844\/7ZpaX6sr_normal.jpg",
      "id" : 17592150,
      "verified" : false
    }
  },
  "id" : 256055964803948544,
  "created_at" : "2012-10-10 15:37:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256053660096794624",
  "text" : "dont pick on things just for the sake of picking..",
  "id" : 256053660096794624,
  "created_at" : "2012-10-10 15:28:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256052223136641024",
  "text" : "sometimes i do get pissed w atheists who think everything is a scam, sham.. like only their view is valid.",
  "id" : 256052223136641024,
  "created_at" : "2012-10-10 15:23:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256048915655323650",
  "geo" : { },
  "id_str" : "256051798106849280",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth yes.. and.. no.. becuz she saw you in person. that in itself can give information to ppl sensitive to it.",
  "id" : 256051798106849280,
  "in_reply_to_status_id" : 256048915655323650,
  "created_at" : "2012-10-10 15:21:20 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "indices" : [ 3, 15 ],
      "id_str" : "65045121",
      "id" : 65045121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256048966754525185",
  "text" : "RT @OwenJones84: Cameron says work is the only way out of poverty. He neglects to mention that most households in poverty are working ho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cpc12",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255987187147997184",
    "text" : "Cameron says work is the only way out of poverty. He neglects to mention that most households in poverty are working households #cpc12",
    "id" : 255987187147997184,
    "created_at" : "2012-10-10 11:04:36 +0000",
    "user" : {
      "name" : "Owen Jones",
      "screen_name" : "OwenJones84",
      "protected" : false,
      "id_str" : "65045121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681493332678291457\/swHdHJNr_normal.jpg",
      "id" : 65045121,
      "verified" : true
    }
  },
  "id" : 256048966754525185,
  "created_at" : "2012-10-10 15:10:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256048384304091137",
  "geo" : { },
  "id_str" : "256048779545948160",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth from your tweets, i would agree w her : )",
  "id" : 256048779545948160,
  "in_reply_to_status_id" : 256048384304091137,
  "created_at" : "2012-10-10 15:09:20 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256040764172300288",
  "text" : "i cant stand the negativity and fear... O!M!G! .. i just cant deal..",
  "id" : 256040764172300288,
  "created_at" : "2012-10-10 14:37:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 0, 12 ],
      "id_str" : "31282286",
      "id" : 31282286
    }, {
      "name" : "Lisa",
      "screen_name" : "Litzz11",
      "indices" : [ 18, 26 ],
      "id_str" : "24408575",
      "id" : 24408575
    }, {
      "name" : "SlyMagellen",
      "screen_name" : "sylviamagallan",
      "indices" : [ 27, 42 ],
      "id_str" : "253865917",
      "id" : 253865917
    }, {
      "name" : "Oregonemom",
      "screen_name" : "Oregonemom",
      "indices" : [ 43, 54 ],
      "id_str" : "118272507",
      "id" : 118272507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255832325240287232",
  "geo" : { },
  "id_str" : "255832593721872384",
  "in_reply_to_user_id" : 31282286,
  "text" : "@TheOracle13 Yes! @Litzz11 @sylviamagallan @Oregonemom",
  "id" : 255832593721872384,
  "in_reply_to_status_id" : 255832325240287232,
  "created_at" : "2012-10-10 00:50:18 +0000",
  "in_reply_to_screen_name" : "TheOracle13",
  "in_reply_to_user_id_str" : "31282286",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255827522921574400",
  "geo" : { },
  "id_str" : "255828536412233729",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny yes you are.. a closet mushheart ; )",
  "id" : 255828536412233729,
  "in_reply_to_status_id" : 255827522921574400,
  "created_at" : "2012-10-10 00:34:10 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misha",
      "screen_name" : "mbuggie42",
      "indices" : [ 3, 13 ],
      "id_str" : "33838330",
      "id" : 33838330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255746709915856897",
  "text" : "RT @mbuggie42: Note to self: do not read the comments. Do not read the comments. Never read the stupid fucking comments. People are idio ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255745671347453954",
    "text" : "Note to self: do not read the comments. Do not read the comments. Never read the stupid fucking comments. People are idiots. Seriously.",
    "id" : 255745671347453954,
    "created_at" : "2012-10-09 19:04:54 +0000",
    "user" : {
      "name" : "Misha",
      "screen_name" : "mbuggie42",
      "protected" : false,
      "id_str" : "33838330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793584011264286720\/SsJMHwFH_normal.jpg",
      "id" : 33838330,
      "verified" : false
    }
  },
  "id" : 255746709915856897,
  "created_at" : "2012-10-09 19:09:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/gsyMSTll",
      "expanded_url" : "http:\/\/fb.me\/1D1be5PKu",
      "display_url" : "fb.me\/1D1be5PKu"
    } ]
  },
  "geo" : { },
  "id_str" : "255734748721336321",
  "text" : "RT @LukeRomyn: You need to believe this with every breath you draw. http:\/\/t.co\/gsyMSTll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/gsyMSTll",
        "expanded_url" : "http:\/\/fb.me\/1D1be5PKu",
        "display_url" : "fb.me\/1D1be5PKu"
      } ]
    },
    "geo" : { },
    "id_str" : "255734303605018624",
    "text" : "You need to believe this with every breath you draw. http:\/\/t.co\/gsyMSTll",
    "id" : 255734303605018624,
    "created_at" : "2012-10-09 18:19:43 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 255734748721336321,
  "created_at" : "2012-10-09 18:21:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 3, 12 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/x5KxFVTJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/Qkh95xIhlH\/",
      "display_url" : "instagr.am\/p\/Qkh95xIhlH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "255729372483444737",
  "text" : "RT @BCBerrie: Today's society for you.... http:\/\/t.co\/x5KxFVTJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/x5KxFVTJ",
        "expanded_url" : "http:\/\/instagr.am\/p\/Qkh95xIhlH\/",
        "display_url" : "instagr.am\/p\/Qkh95xIhlH\/"
      } ]
    },
    "geo" : { },
    "id_str" : "255729129087959041",
    "text" : "Today's society for you.... http:\/\/t.co\/x5KxFVTJ",
    "id" : 255729129087959041,
    "created_at" : "2012-10-09 17:59:10 +0000",
    "user" : {
      "name" : "\uD83C\uDF3A\u026E\u0105w~\u0273\u00E9e\uD83C\uDF3A",
      "screen_name" : "BCBawnee",
      "protected" : false,
      "id_str" : "24500414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707344203278200833\/yTRgqHSe_normal.jpg",
      "id" : 24500414,
      "verified" : false
    }
  },
  "id" : 255729372483444737,
  "created_at" : "2012-10-09 18:00:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Soulseeds",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/jwHISkG4",
      "expanded_url" : "http:\/\/tinyurl.com\/chxqvyz",
      "display_url" : "tinyurl.com\/chxqvyz"
    } ]
  },
  "geo" : { },
  "id_str" : "255728966554513409",
  "text" : "RT @Soulseedzforall: Flock with people you are in sync with, who lift you up, and help you to fly higher. #Soulseeds http:\/\/t.co\/jwHISkG4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Soulseeds",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/jwHISkG4",
        "expanded_url" : "http:\/\/tinyurl.com\/chxqvyz",
        "display_url" : "tinyurl.com\/chxqvyz"
      } ]
    },
    "geo" : { },
    "id_str" : "255727879483166721",
    "text" : "Flock with people you are in sync with, who lift you up, and help you to fly higher. #Soulseeds http:\/\/t.co\/jwHISkG4",
    "id" : 255727879483166721,
    "created_at" : "2012-10-09 17:54:12 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 255728966554513409,
  "created_at" : "2012-10-09 17:58:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255723637527699457",
  "text" : "put no person upon a pedestal. it's not fair to them or yourself. human is human after all.",
  "id" : 255723637527699457,
  "created_at" : "2012-10-09 17:37:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase Goforth",
      "screen_name" : "chasegoforth",
      "indices" : [ 0, 13 ],
      "id_str" : "17888833",
      "id" : 17888833
    }, {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 43, 56 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252849023608832000",
  "geo" : { },
  "id_str" : "255722796863336448",
  "in_reply_to_user_id" : 17888833,
  "text" : "@chasegoforth this comment surprised me... @DeepakChopra",
  "id" : 255722796863336448,
  "in_reply_to_status_id" : 252849023608832000,
  "created_at" : "2012-10-09 17:34:00 +0000",
  "in_reply_to_screen_name" : "chasegoforth",
  "in_reply_to_user_id_str" : "17888833",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 0, 13 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "confused",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252822392697659392",
  "geo" : { },
  "id_str" : "255722342502789122",
  "in_reply_to_user_id" : 15588657,
  "text" : "@DeepakChopra This does not sound like something I'd expect from you. Could you clarify? #confused",
  "id" : 255722342502789122,
  "in_reply_to_status_id" : 252822392697659392,
  "created_at" : "2012-10-09 17:32:12 +0000",
  "in_reply_to_screen_name" : "DeepakChopra",
  "in_reply_to_user_id_str" : "15588657",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/cuo4Zjwz",
      "expanded_url" : "http:\/\/tl.gd\/jjavh3",
      "display_url" : "tl.gd\/jjavh3"
    } ]
  },
  "geo" : { },
  "id_str" : "255720915948675072",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible (cont) http:\/\/t.co\/cuo4Zjwz",
  "id" : 255720915948675072,
  "created_at" : "2012-10-09 17:26:32 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/bF6vplZi",
      "expanded_url" : "http:\/\/www.rollingstone.com\/politics\/news\/greed-and-debt-the-true-story-of-mitt-romney-and-bain-capital-20120829",
      "display_url" : "rollingstone.com\/politics\/news\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "255717931604930560",
  "geo" : { },
  "id_str" : "255720440515944448",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible http:\/\/t.co\/bF6vplZi",
  "id" : 255720440515944448,
  "in_reply_to_status_id" : 255717931604930560,
  "created_at" : "2012-10-09 17:24:38 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255717515316060161",
  "geo" : { },
  "id_str" : "255718339589066753",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible also my gripe w him is he keeps talking morals and doing right thing yet whole bain thing smells...",
  "id" : 255718339589066753,
  "in_reply_to_status_id" : 255717515316060161,
  "created_at" : "2012-10-09 17:16:17 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FusionTheism.com",
      "screen_name" : "AnnotatedBible",
      "indices" : [ 0, 15 ],
      "id_str" : "242204735",
      "id" : 242204735
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255717515316060161",
  "geo" : { },
  "id_str" : "255718123787923456",
  "in_reply_to_user_id" : 242204735,
  "text" : "@AnnotatedBible (good point) possibly.. but Bain knew how to go after the company (take adv of weakness)",
  "id" : 255718123787923456,
  "in_reply_to_status_id" : 255717515316060161,
  "created_at" : "2012-10-09 17:15:26 +0000",
  "in_reply_to_screen_name" : "AnnotatedBible",
  "in_reply_to_user_id_str" : "242204735",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ummm",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/UBIvdYmD",
      "expanded_url" : "http:\/\/youtu.be\/aOH6wwWEJZ0",
      "display_url" : "youtu.be\/aOH6wwWEJZ0"
    } ]
  },
  "geo" : { },
  "id_str" : "255716189932773377",
  "text" : "Just Say No To Free Birth Control: http:\/\/t.co\/UBIvdYmD #ummm",
  "id" : 255716189932773377,
  "created_at" : "2012-10-09 17:07:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255705797202423811",
  "geo" : { },
  "id_str" : "255706593306505216",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous LOL",
  "id" : 255706593306505216,
  "in_reply_to_status_id" : 255705797202423811,
  "created_at" : "2012-10-09 16:29:37 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/q2PiAqoY",
      "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
      "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255706190187753472",
  "text" : "RT @PeggySueCusses: Looking for a gift for the special lady? If she loves totes, here is a site for you. http:\/\/t.co\/q2PiAqoY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/q2PiAqoY",
        "expanded_url" : "http:\/\/www.artfire.com\/ext\/shop\/studio\/KatelynsKrafts",
        "display_url" : "artfire.com\/ext\/shop\/studi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "255703092132192256",
    "text" : "Looking for a gift for the special lady? If she loves totes, here is a site for you. http:\/\/t.co\/q2PiAqoY",
    "id" : 255703092132192256,
    "created_at" : "2012-10-09 16:15:42 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 255706190187753472,
  "created_at" : "2012-10-09 16:28:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255705076524535810",
  "geo" : { },
  "id_str" : "255705672157638656",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny : ) ((hugs))",
  "id" : 255705672157638656,
  "in_reply_to_status_id" : 255705076524535810,
  "created_at" : "2012-10-09 16:25:57 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255704853005881344",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny 2 ladies were saying not to put beliefs on neighbors, not their place to judge...",
  "id" : 255704853005881344,
  "created_at" : "2012-10-09 16:22:42 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255704492614508544",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny i thought of you during bible study this am..lol. think it was the conversation..",
  "id" : 255704492614508544,
  "created_at" : "2012-10-09 16:21:16 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255658748964642817",
  "text" : "RT @ShipsofSong: The challenges each of you face is not necessarily to escape them but to transform them and create a different reality.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255658469850484737",
    "text" : "The challenges each of you face is not necessarily to escape them but to transform them and create a different reality.",
    "id" : 255658469850484737,
    "created_at" : "2012-10-09 13:18:23 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 255658748964642817,
  "created_at" : "2012-10-09 13:19:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liveandletlive",
      "indices" : [ 24, 39 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255657746089795584",
  "geo" : { },
  "id_str" : "255658467774324738",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny me, too... #liveandletlive",
  "id" : 255658467774324738,
  "in_reply_to_status_id" : 255657746089795584,
  "created_at" : "2012-10-09 13:18:23 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255656857421639681",
  "text" : "RT @TheGoldenMirror: Look beyond what you want to see in order to see what you need to see.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255656627783475200",
    "text" : "Look beyond what you want to see in order to see what you need to see.",
    "id" : 255656627783475200,
    "created_at" : "2012-10-09 13:11:04 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 255656857421639681,
  "created_at" : "2012-10-09 13:11:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greytdog",
      "screen_name" : "Greytdog",
      "indices" : [ 3, 12 ],
      "id_str" : "17141349",
      "id" : 17141349
    }, {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 19, 31 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/S35c9U2W",
      "expanded_url" : "http:\/\/twitpic.com\/b2k463",
      "display_url" : "twitpic.com\/b2k463"
    } ]
  },
  "geo" : { },
  "id_str" : "255656742640304128",
  "text" : "RT @Greytdog: From @GeorgeTakei: your morning snicker  http:\/\/t.co\/S35c9U2W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George Takei",
        "screen_name" : "GeorgeTakei",
        "indices" : [ 5, 17 ],
        "id_str" : "237845487",
        "id" : 237845487
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/S35c9U2W",
        "expanded_url" : "http:\/\/twitpic.com\/b2k463",
        "display_url" : "twitpic.com\/b2k463"
      } ]
    },
    "geo" : { },
    "id_str" : "255656399219093504",
    "text" : "From @GeorgeTakei: your morning snicker  http:\/\/t.co\/S35c9U2W",
    "id" : 255656399219093504,
    "created_at" : "2012-10-09 13:10:10 +0000",
    "user" : {
      "name" : "Greytdog",
      "screen_name" : "Greytdog",
      "protected" : false,
      "id_str" : "17141349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800712966274478082\/4hurAvEV_normal.jpg",
      "id" : 17141349,
      "verified" : false
    }
  },
  "id" : 255656742640304128,
  "created_at" : "2012-10-09 13:11:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255654847926382593",
  "geo" : { },
  "id_str" : "255656306680135680",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny also, i dont consider myself a christian per se but i am a theist...",
  "id" : 255656306680135680,
  "in_reply_to_status_id" : 255654847926382593,
  "created_at" : "2012-10-09 13:09:48 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liberal",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255654847926382593",
  "geo" : { },
  "id_str" : "255656124185980928",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny im so far left.. ive fallen off the chart! lol #liberal",
  "id" : 255656124185980928,
  "in_reply_to_status_id" : 255654847926382593,
  "created_at" : "2012-10-09 13:09:04 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255654643571511296",
  "text" : "ive crossed lines and the sky didnt fall. thats how i learned nothing really matters. life is life.. its what you see it as...",
  "id" : 255654643571511296,
  "created_at" : "2012-10-09 13:03:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Birkenmeyer",
      "screen_name" : "metalpalace",
      "indices" : [ 3, 15 ],
      "id_str" : "17779151",
      "id" : 17779151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255654107262615553",
  "text" : "RT @metalpalace: if you cross a line and nothing happens, the line loses meaning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255649246055890944",
    "text" : "if you cross a line and nothing happens, the line loses meaning.",
    "id" : 255649246055890944,
    "created_at" : "2012-10-09 12:41:44 +0000",
    "user" : {
      "name" : "Tom Birkenmeyer",
      "screen_name" : "metalpalace",
      "protected" : false,
      "id_str" : "17779151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639148341163655168\/mmdvcmQf_normal.jpg",
      "id" : 17779151,
      "verified" : false
    }
  },
  "id" : 255654107262615553,
  "created_at" : "2012-10-09 13:01:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255653172083843072",
  "text" : "my MIL is a hoot.. she doesnt want to go to bible study but it looks bad if i go and she doesnt..lol",
  "id" : 255653172083843072,
  "created_at" : "2012-10-09 12:57:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dream",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255652708835524609",
  "text" : "i was comforting a girl who lost her mother. i think i was comforting myself... #dream",
  "id" : 255652708835524609,
  "created_at" : "2012-10-09 12:55:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "LexxiSaal",
      "screen_name" : "LexxiSaal",
      "indices" : [ 54, 64 ],
      "id_str" : "28328725",
      "id" : 28328725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254049793528197120",
  "geo" : { },
  "id_str" : "255466829248598017",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves wow! go Diana! she's an amazing kid : ) @LexxiSaal",
  "id" : 255466829248598017,
  "in_reply_to_status_id" : 254049793528197120,
  "created_at" : "2012-10-09 00:36:53 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255457831145308160",
  "geo" : { },
  "id_str" : "255465468595425281",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves its good to see you still on my timeline! : ) tho i havent seen you a lot..lol. im good. just returned from adk weekend...",
  "id" : 255465468595425281,
  "in_reply_to_status_id" : 255457831145308160,
  "created_at" : "2012-10-09 00:31:28 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255450746789691393",
  "text" : "now we've got 3 baby raccoons each pulling at the kibble dish..lol",
  "id" : 255450746789691393,
  "created_at" : "2012-10-08 23:32:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255446618973822976",
  "text" : "2nd visitor.. our smaller jr possum. black cat didnt eat much (if any) kibble.",
  "id" : 255446618973822976,
  "created_at" : "2012-10-08 23:16:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255444433263263745",
  "text" : "1st visitor this eve.. large black cat w speck of white.. one of our new diner customers.",
  "id" : 255444433263263745,
  "created_at" : "2012-10-08 23:07:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/6Azi4AzV",
      "expanded_url" : "http:\/\/bit.ly\/TcrcF1",
      "display_url" : "bit.ly\/TcrcF1"
    } ]
  },
  "geo" : { },
  "id_str" : "255430777741914114",
  "text" : "RT @micahjmurray: This video of my baby laughing will make your day 100% better or your money back guaranteed. . http:\/\/t.co\/6Azi4AzV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/6Azi4AzV",
        "expanded_url" : "http:\/\/bit.ly\/TcrcF1",
        "display_url" : "bit.ly\/TcrcF1"
      } ]
    },
    "geo" : { },
    "id_str" : "255429033788059648",
    "text" : "This video of my baby laughing will make your day 100% better or your money back guaranteed. . http:\/\/t.co\/6Azi4AzV",
    "id" : 255429033788059648,
    "created_at" : "2012-10-08 22:06:41 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 255430777741914114,
  "created_at" : "2012-10-08 22:13:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255428366746910720",
  "text" : "DD loves Fill or Bust card\/dice game!",
  "id" : 255428366746910720,
  "created_at" : "2012-10-08 22:04:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255428047447158785",
  "text" : "saw a license plate today \"ibemeubeu\"",
  "id" : 255428047447158785,
  "created_at" : "2012-10-08 22:02:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255425681071153152",
  "text" : "we had a good time but i dont recommend going to a rustic cabin w outhouse when you're sick...",
  "id" : 255425681071153152,
  "created_at" : "2012-10-08 21:53:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254374595581337600",
  "geo" : { },
  "id_str" : "254376891853713409",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 well, that just sucks! ((hugs))",
  "id" : 254376891853713409,
  "in_reply_to_status_id" : 254374595581337600,
  "created_at" : "2012-10-06 00:25:51 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "araminta's sh0tgun",
      "screen_name" : "LordeBarrington",
      "indices" : [ 3, 19 ],
      "id_str" : "46571401",
      "id" : 46571401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254341249920819200",
  "text" : "RT @LordeBarrington: The potential cutting of PBS and other arts programs that barely affect the budget at all should cause folks to ask ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254338803421040640",
    "text" : "The potential cutting of PBS and other arts programs that barely affect the budget at all should cause folks to ask what the real agenda is?",
    "id" : 254338803421040640,
    "created_at" : "2012-10-05 21:54:30 +0000",
    "user" : {
      "name" : "araminta's sh0tgun",
      "screen_name" : "LordeBarrington",
      "protected" : false,
      "id_str" : "46571401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797673022345924608\/egrFazcY_normal.jpg",
      "id" : 46571401,
      "verified" : false
    }
  },
  "id" : 254341249920819200,
  "created_at" : "2012-10-05 22:04:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "indices" : [ 3, 17 ],
      "id_str" : "195173057",
      "id" : 195173057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/hf0toczd",
      "expanded_url" : "http:\/\/buff.ly\/PWCygR",
      "display_url" : "buff.ly\/PWCygR"
    } ]
  },
  "geo" : { },
  "id_str" : "254303024510533632",
  "text" : "RT @lindapoitevin: Walter the crow becomes part of Ottawa family - Ottawa - CBC News http:\/\/t.co\/hf0toczd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/hf0toczd",
        "expanded_url" : "http:\/\/buff.ly\/PWCygR",
        "display_url" : "buff.ly\/PWCygR"
      } ]
    },
    "geo" : { },
    "id_str" : "254301857848127489",
    "text" : "Walter the crow becomes part of Ottawa family - Ottawa - CBC News http:\/\/t.co\/hf0toczd",
    "id" : 254301857848127489,
    "created_at" : "2012-10-05 19:27:42 +0000",
    "user" : {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "protected" : false,
      "id_str" : "195173057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653593067958571008\/PyqlHnTV_normal.jpg",
      "id" : 195173057,
      "verified" : false
    }
  },
  "id" : 254303024510533632,
  "created_at" : "2012-10-05 19:32:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u043E\u0441\u043E\u0432 \u041D\u0438\u043A\u043E\u043B\u0430\u0439",
      "screen_name" : "allmysteryenews",
      "indices" : [ 3, 19 ],
      "id_str" : "4636186576",
      "id" : 4636186576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/Fyu9ucqF",
      "expanded_url" : "http:\/\/www.nightowlreviews.com\/nor\/Pages\/FullMoonDetails.aspx#scavengerhunt",
      "display_url" : "nightowlreviews.com\/nor\/Pages\/Full\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "254302933506727937",
  "text" : "RT @allmysteryenews: Win my Prize $100 Amazon gift cert at Online Halloween Scaven... http:\/\/t.co\/Fyu9ucqF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sendible.com\" rel=\"nofollow\"\u003ESendible\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/Fyu9ucqF",
        "expanded_url" : "http:\/\/www.nightowlreviews.com\/nor\/Pages\/FullMoonDetails.aspx#scavengerhunt",
        "display_url" : "nightowlreviews.com\/nor\/Pages\/Full\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "254281073129820161",
    "text" : "Win my Prize $100 Amazon gift cert at Online Halloween Scaven... http:\/\/t.co\/Fyu9ucqF",
    "id" : 254281073129820161,
    "created_at" : "2012-10-05 18:05:06 +0000",
    "user" : {
      "name" : "All Mystery news",
      "screen_name" : "allmysterynews",
      "protected" : false,
      "id_str" : "178117116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1414092030\/logo_twitter_normal.jpg",
      "id" : 178117116,
      "verified" : false
    }
  },
  "id" : 254302933506727937,
  "created_at" : "2012-10-05 19:31:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 0, 14 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254281320199503873",
  "geo" : { },
  "id_str" : "254282210792853504",
  "in_reply_to_user_id" : 113395189,
  "text" : "@ThisBlueWorld take a chance on me by abba : )",
  "id" : 254282210792853504,
  "in_reply_to_status_id" : 254281320199503873,
  "created_at" : "2012-10-05 18:09:38 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Hartmann",
      "screen_name" : "Thom_Hartmann",
      "indices" : [ 3, 17 ],
      "id_str" : "21414576",
      "id" : 21414576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/rTuwhfLc",
      "expanded_url" : "http:\/\/ow.ly\/efPPd",
      "display_url" : "ow.ly\/efPPd"
    } ]
  },
  "geo" : { },
  "id_str" : "254272117972017154",
  "text" : "RT @Thom_Hartmann: Hey Media - How can Romney lie constantly &amp; then be declared the winner? http:\/\/t.co\/rTuwhfLc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/rTuwhfLc",
        "expanded_url" : "http:\/\/ow.ly\/efPPd",
        "display_url" : "ow.ly\/efPPd"
      } ]
    },
    "geo" : { },
    "id_str" : "254270527710064641",
    "text" : "Hey Media - How can Romney lie constantly &amp; then be declared the winner? http:\/\/t.co\/rTuwhfLc",
    "id" : 254270527710064641,
    "created_at" : "2012-10-05 17:23:12 +0000",
    "user" : {
      "name" : "Thom Hartmann",
      "screen_name" : "Thom_Hartmann",
      "protected" : false,
      "id_str" : "21414576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1284920980\/thom-2011-150_normal.jpg",
      "id" : 21414576,
      "verified" : true
    }
  },
  "id" : 254272117972017154,
  "created_at" : "2012-10-05 17:29:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 3, 18 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/i3f1zXz8",
      "expanded_url" : "http:\/\/huff.to\/REyCDR",
      "display_url" : "huff.to\/REyCDR"
    } ]
  },
  "geo" : { },
  "id_str" : "254257094956548096",
  "text" : "RT @HuffingtonPost: AWESOME: South African motorcyclist stops mid-race to rescue baby calf http:\/\/t.co\/i3f1zXz8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/i3f1zXz8",
        "expanded_url" : "http:\/\/huff.to\/REyCDR",
        "display_url" : "huff.to\/REyCDR"
      } ]
    },
    "geo" : { },
    "id_str" : "254253914252259328",
    "text" : "AWESOME: South African motorcyclist stops mid-race to rescue baby calf http:\/\/t.co\/i3f1zXz8",
    "id" : 254253914252259328,
    "created_at" : "2012-10-05 16:17:11 +0000",
    "user" : {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "protected" : false,
      "id_str" : "14511951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720642862551928832\/I58EQMCH_normal.jpg",
      "id" : 14511951,
      "verified" : true
    }
  },
  "id" : 254257094956548096,
  "created_at" : "2012-10-05 16:29:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254253071666925569",
  "text" : "RT @TheGoldenMirror: Fear is a magnifying glass. It makes you think your obstacles are bigger than they are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254253008878194689",
    "text" : "Fear is a magnifying glass. It makes you think your obstacles are bigger than they are.",
    "id" : 254253008878194689,
    "created_at" : "2012-10-05 16:13:35 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 254253071666925569,
  "created_at" : "2012-10-05 16:13:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254249854472159232",
  "text" : "RT @DoreenVirtue444: God\u2019s caring for you is unconditional, limitless, and all-compassing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254249257840812032",
    "text" : "God\u2019s caring for you is unconditional, limitless, and all-compassing.",
    "id" : 254249257840812032,
    "created_at" : "2012-10-05 15:58:41 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 254249854472159232,
  "created_at" : "2012-10-05 16:01:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254248463737421825",
  "text" : "@SamsaricWarrior love this. beautiful!",
  "id" : 254248463737421825,
  "created_at" : "2012-10-05 15:55:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254235086361354240",
  "text" : "i wish ppl wouldnt tell me things they know will upset me!",
  "id" : 254235086361354240,
  "created_at" : "2012-10-05 15:02:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254234240043057152",
  "text" : "sometimes ppl you love dearly can sorely disappoint you... sigh.",
  "id" : 254234240043057152,
  "created_at" : "2012-10-05 14:59:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254209345716375552",
  "text" : "@Skeptical_Lady ((((((hugs))))))",
  "id" : 254209345716375552,
  "created_at" : "2012-10-05 13:20:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254199536539557889",
  "text" : "i am still sick ((whine)) but I am very grateful its something I can deal with and function with...",
  "id" : 254199536539557889,
  "created_at" : "2012-10-05 12:41:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253918440245579776",
  "text" : "RT @CharlesBivona: \"The for-profit insurance industry to provide health care...we need to get rid of that.\" -Rocky Anderson http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Debate2012",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/v0H2zzSA",
        "expanded_url" : "http:\/\/bit.ly\/RfAQaP",
        "display_url" : "bit.ly\/RfAQaP"
      } ]
    },
    "geo" : { },
    "id_str" : "253917912866373633",
    "text" : "\"The for-profit insurance industry to provide health care...we need to get rid of that.\" -Rocky Anderson http:\/\/t.co\/v0H2zzSA #Debate2012",
    "id" : 253917912866373633,
    "created_at" : "2012-10-04 18:02:02 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 253918440245579776,
  "created_at" : "2012-10-04 18:04:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hollywood Dogs",
      "screen_name" : "HollywoodDogs",
      "indices" : [ 3, 17 ],
      "id_str" : "54033567",
      "id" : 54033567
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kansas",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/xV3UO1k4",
      "expanded_url" : "http:\/\/tinyurl.com\/9yf46ao",
      "display_url" : "tinyurl.com\/9yf46ao"
    } ]
  },
  "geo" : { },
  "id_str" : "253913533765541888",
  "text" : "RT @HollywoodDogs: Ginger, a beautiful Alaskan Malamute mix at a shelter in Emporia #Kansas, needs a forever home http:\/\/t.co\/xV3UO1k4 U ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kansas",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/xV3UO1k4",
        "expanded_url" : "http:\/\/tinyurl.com\/9yf46ao",
        "display_url" : "tinyurl.com\/9yf46ao"
      } ]
    },
    "geo" : { },
    "id_str" : "253911744437710848",
    "text" : "Ginger, a beautiful Alaskan Malamute mix at a shelter in Emporia #Kansas, needs a forever home http:\/\/t.co\/xV3UO1k4 URGENT",
    "id" : 253911744437710848,
    "created_at" : "2012-10-04 17:37:31 +0000",
    "user" : {
      "name" : "Hollywood Dogs",
      "screen_name" : "HollywoodDogs",
      "protected" : false,
      "id_str" : "54033567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3783236136\/b77c7e240e1cf967fe051a9de2a24cfb_normal.jpeg",
      "id" : 54033567,
      "verified" : false
    }
  },
  "id" : 253913533765541888,
  "created_at" : "2012-10-04 17:44:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253895823476289537",
  "text" : "\"don't boo.. vote.\" - pbo",
  "id" : 253895823476289537,
  "created_at" : "2012-10-04 16:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sickandwhining",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253889751654998017",
  "text" : "nasty cold.. feel like crap today. can hardly think.. (wait..that's not far from normal..lol) #sickandwhining",
  "id" : 253889751654998017,
  "created_at" : "2012-10-04 16:10:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lam",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/WG28nhYA",
      "expanded_url" : "http:\/\/bit.ly\/VlitGo",
      "display_url" : "bit.ly\/VlitGo"
    } ]
  },
  "geo" : { },
  "id_str" : "253888270126166018",
  "text" : "RT @aliceinthewater: DEBATE WATCH: Mitt Romney Lied About Pre-Existing Conditions\nhttp:\/\/t.co\/WG28nhYA #lam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lam",
        "indices" : [ 82, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/WG28nhYA",
        "expanded_url" : "http:\/\/bit.ly\/VlitGo",
        "display_url" : "bit.ly\/VlitGo"
      } ]
    },
    "geo" : { },
    "id_str" : "253886742854254592",
    "text" : "DEBATE WATCH: Mitt Romney Lied About Pre-Existing Conditions\nhttp:\/\/t.co\/WG28nhYA #lam",
    "id" : 253886742854254592,
    "created_at" : "2012-10-04 15:58:11 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 253888270126166018,
  "created_at" : "2012-10-04 16:04:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "isthatdeep",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253876269001887744",
  "geo" : { },
  "id_str" : "253877373911592960",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater it never stops falling. it is eternally in falling mode. #isthatdeep?",
  "id" : 253877373911592960,
  "in_reply_to_status_id" : 253876269001887744,
  "created_at" : "2012-10-04 15:20:57 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253876037069455361",
  "text" : "RT @TheGoldenMirror: When you keep calling it hard, it will never get easy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253874236299554816",
    "text" : "When you keep calling it hard, it will never get easy.",
    "id" : 253874236299554816,
    "created_at" : "2012-10-04 15:08:29 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 253876037069455361,
  "created_at" : "2012-10-04 15:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindness",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253875798195449856",
  "text" : "RT @earthXplorer: Make #kindness go viral :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindness",
        "indices" : [ 5, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253875088947032064",
    "text" : "Make #kindness go viral :)",
    "id" : 253875088947032064,
    "created_at" : "2012-10-04 15:11:52 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 253875798195449856,
  "created_at" : "2012-10-04 15:14:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253863091723444224",
  "text" : "RT @TheEntertainer: Love is the drug AND the cure.\n\nScrew drama, fear, anger, and ALL its cousins, it's just ego in disguise... http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/Zqc8vS4I",
        "expanded_url" : "http:\/\/fb.me\/1F1NkEJXH",
        "display_url" : "fb.me\/1F1NkEJXH"
      } ]
    },
    "geo" : { },
    "id_str" : "253856100863057920",
    "text" : "Love is the drug AND the cure.\n\nScrew drama, fear, anger, and ALL its cousins, it's just ego in disguise... http:\/\/t.co\/Zqc8vS4I",
    "id" : 253856100863057920,
    "created_at" : "2012-10-04 13:56:25 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 253863091723444224,
  "created_at" : "2012-10-04 14:24:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa",
      "screen_name" : "Litzz11",
      "indices" : [ 0, 8 ],
      "id_str" : "24408575",
      "id" : 24408575
    }, {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 33, 46 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253848767655186433",
  "geo" : { },
  "id_str" : "253850388527185920",
  "in_reply_to_user_id" : 24408575,
  "text" : "@Litzz11 aha! said so perfectly! @BrianMerritt",
  "id" : 253850388527185920,
  "in_reply_to_status_id" : 253848767655186433,
  "created_at" : "2012-10-04 13:33:43 +0000",
  "in_reply_to_screen_name" : "Litzz11",
  "in_reply_to_user_id_str" : "24408575",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253848323201581057",
  "geo" : { },
  "id_str" : "253850093520830464",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt something that has helped me.. \"reach for the better feeling\" (abraham-hicks) i find it getting easier 2 get out of my fear.",
  "id" : 253850093520830464,
  "in_reply_to_status_id" : 253848323201581057,
  "created_at" : "2012-10-04 13:32:33 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253847930845413376",
  "geo" : { },
  "id_str" : "253848429669781504",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt BINGO!",
  "id" : 253848429669781504,
  "in_reply_to_status_id" : 253847930845413376,
  "created_at" : "2012-10-04 13:25:56 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253848145908346881",
  "text" : "RT @BrianMerritt: The reason I don't like politics is that it is based on fear.  I read so much by people \"advocating\" that is really pr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253847930845413376",
    "text" : "The reason I don't like politics is that it is based on fear.  I read so much by people \"advocating\" that is really projected fear.",
    "id" : 253847930845413376,
    "created_at" : "2012-10-04 13:23:57 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 253848145908346881,
  "created_at" : "2012-10-04 13:24:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253847998747013120",
  "text" : "humans like to belong. its so easy to get caught up on \"sides\" ..",
  "id" : 253847998747013120,
  "created_at" : "2012-10-04 13:24:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253846940842860544",
  "text" : "RT @TheGoldenMirror: In order to see how much you've grown, look back on how you were before.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253844583866302465",
    "text" : "In order to see how much you've grown, look back on how you were before.",
    "id" : 253844583866302465,
    "created_at" : "2012-10-04 13:10:39 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 253846940842860544,
  "created_at" : "2012-10-04 13:20:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253846079173435392",
  "text" : "this does not mean i discount ppl who are pro romney. obv, they see him in a different light than I do.",
  "id" : 253846079173435392,
  "created_at" : "2012-10-04 13:16:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253845765762461696",
  "text" : "i dont like or trust romney. i think he lies. i dont like what he did at bain. he wants bigger military and repeal roe-wade.",
  "id" : 253845765762461696,
  "created_at" : "2012-10-04 13:15:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andie Redwine",
      "screen_name" : "AndieRedwine",
      "indices" : [ 3, 16 ],
      "id_str" : "14586373",
      "id" : 14586373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253681721587953664",
  "text" : "RT @AndieRedwine: How about we end a war to save real money instead of getting rid of children's programming? Bird seed for all! #Suppor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SupportBigBird",
        "indices" : [ 111, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253681489181556738",
    "text" : "How about we end a war to save real money instead of getting rid of children's programming? Bird seed for all! #SupportBigBird",
    "id" : 253681489181556738,
    "created_at" : "2012-10-04 02:22:34 +0000",
    "user" : {
      "name" : "Andie Redwine",
      "screen_name" : "AndieRedwine",
      "protected" : false,
      "id_str" : "14586373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701584336127037440\/3KYEojVz_normal.jpg",
      "id" : 14586373,
      "verified" : false
    }
  },
  "id" : 253681721587953664,
  "created_at" : "2012-10-04 02:23:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Rampell",
      "screen_name" : "crampell",
      "indices" : [ 3, 12 ],
      "id_str" : "14348157",
      "id" : 14348157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253681123257892864",
  "text" : "RT @crampell: if the private sector is so good at bringing down health care costs, why hasn't it brought down health care costs?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253677811880042497",
    "text" : "if the private sector is so good at bringing down health care costs, why hasn't it brought down health care costs?",
    "id" : 253677811880042497,
    "created_at" : "2012-10-04 02:07:58 +0000",
    "user" : {
      "name" : "Catherine Rampell",
      "screen_name" : "crampell",
      "protected" : false,
      "id_str" : "14348157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531821532972986368\/WqfzPQ9b_normal.jpeg",
      "id" : 14348157,
      "verified" : true
    }
  },
  "id" : 253681123257892864,
  "created_at" : "2012-10-04 02:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253674651287433217",
  "text" : "RT @dubiouslygreat: \"Private insurers have to make a profit.\" EXACTLY. When will we learn that a profit motive is not compatible with pe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debate",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253673521908154368",
    "text" : "\"Private insurers have to make a profit.\" EXACTLY. When will we learn that a profit motive is not compatible with people's health? #debate",
    "id" : 253673521908154368,
    "created_at" : "2012-10-04 01:50:55 +0000",
    "user" : {
      "name" : "Amanda",
      "screen_name" : "andalongjacket",
      "protected" : false,
      "id_str" : "15151023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606568621041545216\/LRWZ61Lq_normal.jpg",
      "id" : 15151023,
      "verified" : false
    }
  },
  "id" : 253674651287433217,
  "created_at" : "2012-10-04 01:55:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253667597738987520",
  "text" : "one word pops up when romney talks about jobs for struggling americans... bain.",
  "id" : 253667597738987520,
  "created_at" : "2012-10-04 01:27:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253602160468709377",
  "geo" : { },
  "id_str" : "253642508498788352",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu we get possum and cat together but not with raccoons. we have 1 reg stray and odd ones pop up.",
  "id" : 253642508498788352,
  "in_reply_to_status_id" : 253602160468709377,
  "created_at" : "2012-10-03 23:47:41 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom",
      "screen_name" : "TomEcho6",
      "indices" : [ 0, 9 ],
      "id_str" : "37208927",
      "id" : 37208927
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 16, 28 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253514762661531649",
  "geo" : { },
  "id_str" : "253558719604985856",
  "in_reply_to_user_id" : 37208927,
  "text" : "@TomEcho6 hmm.. @virgojohnny I think im part of the babble group?",
  "id" : 253558719604985856,
  "in_reply_to_status_id" : 253514762661531649,
  "created_at" : "2012-10-03 18:14:44 +0000",
  "in_reply_to_screen_name" : "TomEcho6",
  "in_reply_to_user_id_str" : "37208927",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "indices" : [ 3, 17 ],
      "id_str" : "125567504",
      "id" : 125567504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/SfaJgVUD",
      "expanded_url" : "http:\/\/huff.to\/Vh4FNk",
      "display_url" : "huff.to\/Vh4FNk"
    } ]
  },
  "geo" : { },
  "id_str" : "253545852155613184",
  "text" : "RT @HuffPostWeird: Vodka company pours drinks over naked models before bottling http:\/\/t.co\/SfaJgVUD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/SfaJgVUD",
        "expanded_url" : "http:\/\/huff.to\/Vh4FNk",
        "display_url" : "huff.to\/Vh4FNk"
      } ]
    },
    "geo" : { },
    "id_str" : "253545029266718721",
    "text" : "Vodka company pours drinks over naked models before bottling http:\/\/t.co\/SfaJgVUD",
    "id" : 253545029266718721,
    "created_at" : "2012-10-03 17:20:20 +0000",
    "user" : {
      "name" : "HuffPost Weird News",
      "screen_name" : "HuffPostWeird",
      "protected" : false,
      "id_str" : "125567504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727529759320641536\/eb1jlM9W_normal.jpg",
      "id" : 125567504,
      "verified" : true
    }
  },
  "id" : 253545852155613184,
  "created_at" : "2012-10-03 17:23:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 0, 8 ],
      "id_str" : "59574144",
      "id" : 59574144
    }, {
      "name" : "Steve Marmel",
      "screen_name" : "Marmel",
      "indices" : [ 38, 45 ],
      "id_str" : "5513002",
      "id" : 5513002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253526537628954624",
  "geo" : { },
  "id_str" : "253527704954101760",
  "in_reply_to_user_id" : 59574144,
  "text" : "@MWM4444 oh my..lol.. quite a vision! @Marmel",
  "id" : 253527704954101760,
  "in_reply_to_status_id" : 253526537628954624,
  "created_at" : "2012-10-03 16:11:29 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/8HYgsxKf",
      "expanded_url" : "http:\/\/youtu.be\/bmmQ6OWMHTI",
      "display_url" : "youtu.be\/bmmQ6OWMHTI"
    } ]
  },
  "geo" : { },
  "id_str" : "253513127935758338",
  "text" : "very interesting... Directed Energy Technology: http:\/\/t.co\/8HYgsxKf",
  "id" : 253513127935758338,
  "created_at" : "2012-10-03 15:13:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253493133801840641",
  "geo" : { },
  "id_str" : "253494748956995584",
  "in_reply_to_user_id" : 204947822,
  "text" : "@WTBuster ((hugs)) we got furbabies.. we understand..",
  "id" : 253494748956995584,
  "in_reply_to_status_id" : 253493133801840641,
  "created_at" : "2012-10-03 14:00:32 +0000",
  "in_reply_to_screen_name" : "wtb6chiny",
  "in_reply_to_user_id_str" : "204947822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253482967517769728",
  "geo" : { },
  "id_str" : "253494383649894400",
  "in_reply_to_user_id" : 204947822,
  "text" : "@WTBuster poor baby : (",
  "id" : 253494383649894400,
  "in_reply_to_status_id" : 253482967517769728,
  "created_at" : "2012-10-03 13:59:05 +0000",
  "in_reply_to_screen_name" : "wtb6chiny",
  "in_reply_to_user_id_str" : "204947822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "indices" : [ 3, 15 ],
      "id_str" : "229428507",
      "id" : 229428507
    }, {
      "name" : "colleen miller Grant",
      "screen_name" : "Cmarie3D",
      "indices" : [ 17, 26 ],
      "id_str" : "827285430",
      "id" : 827285430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/mhJaEy4J",
      "expanded_url" : "http:\/\/goo.gl\/tPSoL",
      "display_url" : "goo.gl\/tPSoL"
    } ]
  },
  "geo" : { },
  "id_str" : "253490507538395136",
  "text" : "RT @Floridaline: @Cmarie3D Helping the Poor is Now Apparently Anti-Bible http:\/\/t.co\/mhJaEy4J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "colleen miller Grant",
        "screen_name" : "Cmarie3D",
        "indices" : [ 0, 9 ],
        "id_str" : "827285430",
        "id" : 827285430
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/mhJaEy4J",
        "expanded_url" : "http:\/\/goo.gl\/tPSoL",
        "display_url" : "goo.gl\/tPSoL"
      } ]
    },
    "in_reply_to_status_id_str" : "253263380301881344",
    "geo" : { },
    "id_str" : "253268456034680832",
    "in_reply_to_user_id" : 827285430,
    "text" : "@Cmarie3D Helping the Poor is Now Apparently Anti-Bible http:\/\/t.co\/mhJaEy4J",
    "id" : 253268456034680832,
    "in_reply_to_status_id" : 253263380301881344,
    "created_at" : "2012-10-02 23:01:20 +0000",
    "in_reply_to_screen_name" : "Cmarie3D",
    "in_reply_to_user_id_str" : "827285430",
    "user" : {
      "name" : "FloridaLine",
      "screen_name" : "Floridaline",
      "protected" : false,
      "id_str" : "229428507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3742826729\/d28316627e55cb78cf1faffad3f83584_normal.jpeg",
      "id" : 229428507,
      "verified" : false
    }
  },
  "id" : 253490507538395136,
  "created_at" : "2012-10-03 13:43:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 2, 17 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253481354984030209",
  "geo" : { },
  "id_str" : "253482823829307392",
  "in_reply_to_user_id" : 105049016,
  "text" : ". @richarddoetsch it seems that education is good 4 ppl, so, good 4 society.. society should want educated ppl.",
  "id" : 253482823829307392,
  "in_reply_to_status_id" : 253481354984030209,
  "created_at" : "2012-10-03 13:13:09 +0000",
  "in_reply_to_screen_name" : "richarddoetsch",
  "in_reply_to_user_id_str" : "105049016",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Saddington",
      "screen_name" : "saddington",
      "indices" : [ 3, 14 ],
      "id_str" : "14363167",
      "id" : 14363167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/mTVAnA95",
      "expanded_url" : "http:\/\/tentblogger.com\/goodbye-facebook-page\/",
      "display_url" : "tentblogger.com\/goodbye-facebo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253480318487642112",
  "text" : "RT @saddington: The Reason I'm Closing Down Our Facebook Fan Page: http:\/\/t.co\/mTVAnA95",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/mTVAnA95",
        "expanded_url" : "http:\/\/tentblogger.com\/goodbye-facebook-page\/",
        "display_url" : "tentblogger.com\/goodbye-facebo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253452839303667713",
    "text" : "The Reason I'm Closing Down Our Facebook Fan Page: http:\/\/t.co\/mTVAnA95",
    "id" : 253452839303667713,
    "created_at" : "2012-10-03 11:14:00 +0000",
    "user" : {
      "name" : "John Saddington",
      "screen_name" : "saddington",
      "protected" : false,
      "id_str" : "14363167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639826093973749760\/EaFQlNcw_normal.jpg",
      "id" : 14363167,
      "verified" : false
    }
  },
  "id" : 253480318487642112,
  "created_at" : "2012-10-03 13:03:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeschool",
      "indices" : [ 106, 117 ]
    }, {
      "text" : "unschool",
      "indices" : [ 118, 127 ]
    }, {
      "text" : "spd",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/YDhcaduy",
      "expanded_url" : "http:\/\/ow.ly\/1OKfjH",
      "display_url" : "ow.ly\/1OKfjH"
    } ]
  },
  "geo" : { },
  "id_str" : "253465487420297216",
  "text" : "RT @AniKnits: \u007BI even blogged about it\u007D When Homeschooling Your Child Equals Neglect http:\/\/t.co\/YDhcaduy #homeschool #unschool #spd #as ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "homeschool",
        "indices" : [ 92, 103 ]
      }, {
        "text" : "unschool",
        "indices" : [ 104, 113 ]
      }, {
        "text" : "spd",
        "indices" : [ 114, 118 ]
      }, {
        "text" : "asd",
        "indices" : [ 119, 123 ]
      }, {
        "text" : "adhd",
        "indices" : [ 124, 129 ]
      }, {
        "text" : "autism",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/YDhcaduy",
        "expanded_url" : "http:\/\/ow.ly\/1OKfjH",
        "display_url" : "ow.ly\/1OKfjH"
      } ]
    },
    "geo" : { },
    "id_str" : "253464795234332672",
    "text" : "\u007BI even blogged about it\u007D When Homeschooling Your Child Equals Neglect http:\/\/t.co\/YDhcaduy #homeschool #unschool #spd #asd #adhd #autism",
    "id" : 253464795234332672,
    "created_at" : "2012-10-03 12:01:30 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 253465487420297216,
  "created_at" : "2012-10-03 12:04:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCowan",
      "screen_name" : "muichimotsu",
      "indices" : [ 0, 12 ],
      "id_str" : "14676842",
      "id" : 14676842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253319065056182273",
  "geo" : { },
  "id_str" : "253461575757864960",
  "in_reply_to_user_id" : 14676842,
  "text" : "@muichimotsu we had a full house last night.. 7 raccoons (set of 3, set of 4,) 2 young possums and 2 cats (1 regular, 1 new.)",
  "id" : 253461575757864960,
  "in_reply_to_status_id" : 253319065056182273,
  "created_at" : "2012-10-03 11:48:43 +0000",
  "in_reply_to_screen_name" : "muichimotsu",
  "in_reply_to_user_id_str" : "14676842",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/via.me\" rel=\"nofollow\"\u003EVia.Me\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/QCJx3ODR",
      "expanded_url" : "http:\/\/via.me\/-5nr9v5m",
      "display_url" : "via.me\/-5nr9v5m"
    } ]
  },
  "geo" : { },
  "id_str" : "253310623134384128",
  "text" : "Possum and kitty sharing meal time : ) http:\/\/t.co\/QCJx3ODR",
  "id" : 253310623134384128,
  "created_at" : "2012-10-03 01:48:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253308427739217920",
  "text" : "i need to put out a schedule for these critters.. trying to make sure everyone gets something! : )",
  "id" : 253308427739217920,
  "created_at" : "2012-10-03 01:40:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253307876498616320",
  "text" : "we have 2 possums! sometimes i dont realize differences..lol",
  "id" : 253307876498616320,
  "created_at" : "2012-10-03 01:37:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253297293103611904",
  "text" : "RT @abandontheherd: You are already incredible. Let your light shine!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253296942107467779",
    "text" : "You are already incredible. Let your light shine!",
    "id" : 253296942107467779,
    "created_at" : "2012-10-03 00:54:31 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 253297293103611904,
  "created_at" : "2012-10-03 00:55:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "Susan Critelli",
      "screen_name" : "momzilla54",
      "indices" : [ 24, 35 ],
      "id_str" : "14357626",
      "id" : 14357626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeschooling",
      "indices" : [ 37, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/RUzvonpq",
      "expanded_url" : "http:\/\/flpbd.it\/QCXl3",
      "display_url" : "flpbd.it\/QCXl3"
    } ]
  },
  "geo" : { },
  "id_str" : "253295877714755584",
  "text" : "RT @AniKnits: FFS!!! RT @momzilla54: #homeschooling Judge: Homeschooling \u201CDamages\u201D Kids http:\/\/t.co\/RUzvonpq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.flipboard.com\" rel=\"nofollow\"\u003EFlipboard\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Critelli",
        "screen_name" : "momzilla54",
        "indices" : [ 10, 21 ],
        "id_str" : "14357626",
        "id" : 14357626
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "homeschooling",
        "indices" : [ 23, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/RUzvonpq",
        "expanded_url" : "http:\/\/flpbd.it\/QCXl3",
        "display_url" : "flpbd.it\/QCXl3"
      } ]
    },
    "geo" : { },
    "id_str" : "253295023276318721",
    "text" : "FFS!!! RT @momzilla54: #homeschooling Judge: Homeschooling \u201CDamages\u201D Kids http:\/\/t.co\/RUzvonpq",
    "id" : 253295023276318721,
    "created_at" : "2012-10-03 00:46:54 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 253295877714755584,
  "created_at" : "2012-10-03 00:50:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 0, 15 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253290659459497985",
  "geo" : { },
  "id_str" : "253292498628276225",
  "in_reply_to_user_id" : 96152195,
  "text" : "@luminanceriver is this why i keep having dreams of infants? lol",
  "id" : 253292498628276225,
  "in_reply_to_status_id" : 253290659459497985,
  "created_at" : "2012-10-03 00:36:52 +0000",
  "in_reply_to_screen_name" : "luminanceriver",
  "in_reply_to_user_id_str" : "96152195",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vulture",
      "indices" : [ 24, 32 ]
    }, {
      "text" : "Portrait",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "photo",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "nature",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/NtoMw7s0",
      "expanded_url" : "http:\/\/bit.ly\/Ss4jgd",
      "display_url" : "bit.ly\/Ss4jgd"
    } ]
  },
  "in_reply_to_status_id_str" : "253288558633312256",
  "geo" : { },
  "id_str" : "253290960392441856",
  "in_reply_to_user_id" : 28461779,
  "text" : "RT @MartinBelan: Turkey #Vulture #Portrait. http:\/\/t.co\/NtoMw7s0  #photo #nature",
  "id" : 253290960392441856,
  "in_reply_to_status_id" : 253288558633312256,
  "created_at" : "2012-10-03 00:30:45 +0000",
  "in_reply_to_screen_name" : "MartinBelan",
  "in_reply_to_user_id_str" : "28461779",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253287193978732545",
  "text" : "now we got 3 bigger raccoons on the porch. this is diff than mama w three juniors...",
  "id" : 253287193978732545,
  "created_at" : "2012-10-03 00:15:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 28, 37 ],
      "id_str" : "184401626",
      "id" : 184401626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "canhappentoanyone",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/Xx7gMzo2",
      "expanded_url" : "http:\/\/www.thesimpleboxcar.com\/2012\/06\/bringnickhome.html",
      "display_url" : "thesimpleboxcar.com\/2012\/06\/bringn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253278962900422656",
  "text" : "if you havent yet, plz read @AniKnits story http:\/\/t.co\/Xx7gMzo2 Social Services has her son STILL!! #canhappentoanyone",
  "id" : 253278962900422656,
  "created_at" : "2012-10-02 23:43:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253179027899183105",
  "geo" : { },
  "id_str" : "253227997102997504",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses ohh we want to see that one, too! \"they tried to stone me but it didn't work\" LOL",
  "id" : 253227997102997504,
  "in_reply_to_status_id" : 253179027899183105,
  "created_at" : "2012-10-02 20:20:33 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 0, 8 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253223885305176064",
  "geo" : { },
  "id_str" : "253225038285770752",
  "in_reply_to_user_id" : 14653298,
  "text" : "@CandyTX isnt that a felony or something? lol",
  "id" : 253225038285770752,
  "in_reply_to_status_id" : 253223885305176064,
  "created_at" : "2012-10-02 20:08:48 +0000",
  "in_reply_to_screen_name" : "CandyTX",
  "in_reply_to_user_id_str" : "14653298",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253187988123684864",
  "text" : "i hate the new bitly.. bleh.",
  "id" : 253187988123684864,
  "created_at" : "2012-10-02 17:41:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2012election",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "politics",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "society",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/fPb1hOII",
      "expanded_url" : "http:\/\/bit.ly\/UE5BGP",
      "display_url" : "bit.ly\/UE5BGP"
    } ]
  },
  "geo" : { },
  "id_str" : "253187447008157697",
  "text" : "#2012election #politics #society @warriorbanker http:\/\/t.co\/fPb1hOII",
  "id" : 253187447008157697,
  "created_at" : "2012-10-02 17:39:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "30steps",
      "screen_name" : "JeremiahBilas",
      "indices" : [ 3, 17 ],
      "id_str" : "142393765",
      "id" : 142393765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/V0V9gQ5g",
      "expanded_url" : "http:\/\/tinyurl.com\/8ob7ylt",
      "display_url" : "tinyurl.com\/8ob7ylt"
    } ]
  },
  "geo" : { },
  "id_str" : "253185225671188481",
  "text" : "RT @JeremiahBilas: NASA discovers that Earth is singing http:\/\/t.co\/V0V9gQ5g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/V0V9gQ5g",
        "expanded_url" : "http:\/\/tinyurl.com\/8ob7ylt",
        "display_url" : "tinyurl.com\/8ob7ylt"
      } ]
    },
    "geo" : { },
    "id_str" : "253184761495973888",
    "text" : "NASA discovers that Earth is singing http:\/\/t.co\/V0V9gQ5g",
    "id" : 253184761495973888,
    "created_at" : "2012-10-02 17:28:45 +0000",
    "user" : {
      "name" : "30steps",
      "screen_name" : "JeremiahBilas",
      "protected" : false,
      "id_str" : "142393765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2188701998\/downloadfile_normal.jpeg",
      "id" : 142393765,
      "verified" : false
    }
  },
  "id" : 253185225671188481,
  "created_at" : "2012-10-02 17:30:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 3, 17 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/HjL3hheM",
      "expanded_url" : "http:\/\/thkpr.gs\/QKruX6",
      "display_url" : "thkpr.gs\/QKruX6"
    } ]
  },
  "geo" : { },
  "id_str" : "253184427738411008",
  "text" : "RT @thinkprogress: Billionaire businessman says government assistance for the poor makes people lazy http:\/\/t.co\/HjL3hheM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/HjL3hheM",
        "expanded_url" : "http:\/\/thkpr.gs\/QKruX6",
        "display_url" : "thkpr.gs\/QKruX6"
      } ]
    },
    "geo" : { },
    "id_str" : "253124992034824192",
    "text" : "Billionaire businessman says government assistance for the poor makes people lazy http:\/\/t.co\/HjL3hheM",
    "id" : 253124992034824192,
    "created_at" : "2012-10-02 13:31:15 +0000",
    "user" : {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "protected" : false,
      "id_str" : "55355654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762609394265632768\/H_UR_W7r_normal.jpg",
      "id" : 55355654,
      "verified" : true
    }
  },
  "id" : 253184427738411008,
  "created_at" : "2012-10-02 17:27:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253184232057344000",
  "text" : "know y women live longer? cuz they are too smart to get caught...",
  "id" : 253184232057344000,
  "created_at" : "2012-10-02 17:26:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253181824589778944",
  "geo" : { },
  "id_str" : "253182406054522880",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker : )",
  "id" : 253182406054522880,
  "in_reply_to_status_id" : 253181824589778944,
  "created_at" : "2012-10-02 17:19:24 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253180418516459520",
  "text" : "ohhh, im feeling stabby today...",
  "id" : 253180418516459520,
  "created_at" : "2012-10-02 17:11:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253123521419546624",
  "text" : "i have a date with my MIL this am..lol",
  "id" : 253123521419546624,
  "created_at" : "2012-10-02 13:25:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/alxUISbH",
      "expanded_url" : "http:\/\/tinyurl.com\/6zkn9bk",
      "display_url" : "tinyurl.com\/6zkn9bk"
    } ]
  },
  "geo" : { },
  "id_str" : "252914348283019264",
  "text" : "RT @Soulseedzforall: Life is too short and fragile to waste a moment in fear and hatred. Article on love and fear http:\/\/t.co\/alxUISbH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/alxUISbH",
        "expanded_url" : "http:\/\/tinyurl.com\/6zkn9bk",
        "display_url" : "tinyurl.com\/6zkn9bk"
      } ]
    },
    "geo" : { },
    "id_str" : "252913725277872129",
    "text" : "Life is too short and fragile to waste a moment in fear and hatred. Article on love and fear http:\/\/t.co\/alxUISbH",
    "id" : 252913725277872129,
    "created_at" : "2012-10-01 23:31:45 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 252914348283019264,
  "created_at" : "2012-10-01 23:34:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 3, 16 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252897417744244737",
  "text" : "RT @adamrshields: Facebook is Becoming a Problem - Boing Boing is reporting only 15% of fan page updates reach users, but more if you pa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/qJoHqL0h",
        "expanded_url" : "http:\/\/bookwi.se\/facebook\/",
        "display_url" : "bookwi.se\/facebook\/"
      } ]
    },
    "geo" : { },
    "id_str" : "252896973542285312",
    "text" : "Facebook is Becoming a Problem - Boing Boing is reporting only 15% of fan page updates reach users, but more if you pay http:\/\/t.co\/qJoHqL0h",
    "id" : 252896973542285312,
    "created_at" : "2012-10-01 22:25:11 +0000",
    "user" : {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "protected" : false,
      "id_str" : "14835882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738932114603806720\/XlBtfxj0_normal.jpg",
      "id" : 14835882,
      "verified" : false
    }
  },
  "id" : 252897417744244737,
  "created_at" : "2012-10-01 22:26:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 3, 12 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    }, {
      "name" : "Mercougar",
      "screen_name" : "Mercougar",
      "indices" : [ 15, 25 ],
      "id_str" : "25737965",
      "id" : 25737965
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Mercougar\/status\/252882474110185472\/photo\/1",
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/JLzr0Svk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4JrRTeCcAA10ei.jpg",
      "id_str" : "252882474114379776",
      "id" : 252882474114379776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4JrRTeCcAA10ei.jpg",
      "sizes" : [ {
        "h" : 440,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 588
      } ],
      "display_url" : "pic.twitter.com\/JLzr0Svk"
    } ],
    "hashtags" : [ {
      "text" : "awesomesauce",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252884142159716352",
  "text" : "RT @BCBerrie: \u201C@Mercougar: Lol they used beach balls.. http:\/\/t.co\/JLzr0Svk\u201D. #awesomesauce",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mercougar",
        "screen_name" : "Mercougar",
        "indices" : [ 1, 11 ],
        "id_str" : "25737965",
        "id" : 25737965
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Mercougar\/status\/252882474110185472\/photo\/1",
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/JLzr0Svk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A4JrRTeCcAA10ei.jpg",
        "id_str" : "252882474114379776",
        "id" : 252882474114379776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4JrRTeCcAA10ei.jpg",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 588
        } ],
        "display_url" : "pic.twitter.com\/JLzr0Svk"
      } ],
      "hashtags" : [ {
        "text" : "awesomesauce",
        "indices" : [ 64, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252883814609731584",
    "text" : "\u201C@Mercougar: Lol they used beach balls.. http:\/\/t.co\/JLzr0Svk\u201D. #awesomesauce",
    "id" : 252883814609731584,
    "created_at" : "2012-10-01 21:32:54 +0000",
    "user" : {
      "name" : "\uD83C\uDF3A\u026E\u0105w~\u0273\u00E9e\uD83C\uDF3A",
      "screen_name" : "BCBawnee",
      "protected" : false,
      "id_str" : "24500414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707344203278200833\/yTRgqHSe_normal.jpg",
      "id" : 24500414,
      "verified" : false
    }
  },
  "id" : 252884142159716352,
  "created_at" : "2012-10-01 21:34:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rocky",
      "screen_name" : "LoveHonorTruth",
      "indices" : [ 0, 15 ],
      "id_str" : "167958125",
      "id" : 167958125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252882548315795458",
  "geo" : { },
  "id_str" : "252883732111978496",
  "in_reply_to_user_id" : 167958125,
  "text" : "@LoveHonorTruth bad hair day.. maybe?",
  "id" : 252883732111978496,
  "in_reply_to_status_id" : 252882548315795458,
  "created_at" : "2012-10-01 21:32:34 +0000",
  "in_reply_to_screen_name" : "LoveHonorTruth",
  "in_reply_to_user_id_str" : "167958125",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252883547587751936",
  "text" : "@BibleAlsoSays you were in nyc? im upstate ny in the country. city is nice to visit but im a country gal..lol",
  "id" : 252883547587751936,
  "created_at" : "2012-10-01 21:31:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252881853688737792",
  "text" : "@BibleAlsoSays ny? and you didnt stop in for a visit? lol hope it was a good trip : )",
  "id" : 252881853688737792,
  "created_at" : "2012-10-01 21:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252878173748994048",
  "text" : "@BibleAlsoSays hmm.. if he did, i didnt notice.. welcome back from.. wherever you were! lol",
  "id" : 252878173748994048,
  "created_at" : "2012-10-01 21:10:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny B.",
      "screen_name" : "HiFromHere",
      "indices" : [ 0, 11 ],
      "id_str" : "3148075960",
      "id" : 3148075960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252847526095499264",
  "text" : "@HiFromHere ((facepalm))",
  "id" : 252847526095499264,
  "created_at" : "2012-10-01 19:08:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harvesting Bank",
      "screen_name" : "Jamiastar",
      "indices" : [ 3, 13 ],
      "id_str" : "2499245011",
      "id" : 2499245011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/qtNtrwUL",
      "expanded_url" : "http:\/\/su.pr\/AjXgzr",
      "display_url" : "su.pr\/AjXgzr"
    } ]
  },
  "geo" : { },
  "id_str" : "252812595357159424",
  "text" : "RT @Jamiastar: What Living On $7 An Hour Actually Means http:\/\/t.co\/qtNtrwUL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/qtNtrwUL",
        "expanded_url" : "http:\/\/su.pr\/AjXgzr",
        "display_url" : "su.pr\/AjXgzr"
      } ]
    },
    "geo" : { },
    "id_str" : "252802091679109120",
    "text" : "What Living On $7 An Hour Actually Means http:\/\/t.co\/qtNtrwUL",
    "id" : 252802091679109120,
    "created_at" : "2012-10-01 16:08:10 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 252812595357159424,
  "created_at" : "2012-10-01 16:49:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AynRandPaulRyan",
      "screen_name" : "AynRandPaulRyan",
      "indices" : [ 3, 19 ],
      "id_str" : "755835576",
      "id" : 755835576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "47Percent",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252808042469539840",
  "text" : "RT @AynRandPaulRyan: Hey moms! Mitt Romney says that mothers are deadbeats without dignity. Even worse than the #47Percent: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "47Percent",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/m0i5XXfF",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kPVeFNqjAig&feature=player_embedded",
        "display_url" : "youtube.com\/watch?v=kPVeFN\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "252803335957139456",
    "text" : "Hey moms! Mitt Romney says that mothers are deadbeats without dignity. Even worse than the #47Percent: http:\/\/t.co\/m0i5XXfF",
    "id" : 252803335957139456,
    "created_at" : "2012-10-01 16:13:06 +0000",
    "user" : {
      "name" : "AynRandPaulRyan",
      "screen_name" : "AynRandPaulRyan",
      "protected" : false,
      "id_str" : "755835576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000387001217\/9728ab97d89d0c7bae8373814d1c3e18_normal.jpeg",
      "id" : 755835576,
      "verified" : false
    }
  },
  "id" : 252808042469539840,
  "created_at" : "2012-10-01 16:31:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny B.",
      "screen_name" : "HiFromHere",
      "indices" : [ 0, 11 ],
      "id_str" : "3148075960",
      "id" : 3148075960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252807929152028672",
  "text" : "@HiFromHere she made a career choice? being a parent is not a career choice. mitt says her job more imp but wants poor kids in daycare o-O",
  "id" : 252807929152028672,
  "created_at" : "2012-10-01 16:31:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 34, 46 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "birds",
      "indices" : [ 92, 98 ]
    }, {
      "text" : "ducks",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/J1ih8GcK",
      "expanded_url" : "http:\/\/bit.ly\/PEk7NR",
      "display_url" : "bit.ly\/PEk7NR"
    } ]
  },
  "geo" : { },
  "id_str" : "252803766972207104",
  "text" : "RT @KerriFar: Oh he's lovely!! RT @martinbelan: American Wigeon http:\/\/t.co\/J1ih8GcK #photo #birds #ducks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Martin Belan",
        "screen_name" : "MartinBelan",
        "indices" : [ 20, 32 ],
        "id_str" : "28461779",
        "id" : 28461779
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 71, 77 ]
      }, {
        "text" : "birds",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "ducks",
        "indices" : [ 85, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/J1ih8GcK",
        "expanded_url" : "http:\/\/bit.ly\/PEk7NR",
        "display_url" : "bit.ly\/PEk7NR"
      } ]
    },
    "geo" : { },
    "id_str" : "252803242159898624",
    "text" : "Oh he's lovely!! RT @martinbelan: American Wigeon http:\/\/t.co\/J1ih8GcK #photo #birds #ducks",
    "id" : 252803242159898624,
    "created_at" : "2012-10-01 16:12:44 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 252803766972207104,
  "created_at" : "2012-10-01 16:14:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mondaygiveaway",
      "indices" : [ 25, 40 ]
    }, {
      "text" : "win",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252797733574963200",
  "text" : "RT @DuttonBooks: Today's #Mondaygiveaway: an awesome military thriller that's not coming out until January.  Your chance to #win an earl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mondaygiveaway",
        "indices" : [ 8, 23 ]
      }, {
        "text" : "win",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252797554213937152",
    "text" : "Today's #Mondaygiveaway: an awesome military thriller that's not coming out until January.  Your chance to #win an early copy at 3pm EST.",
    "id" : 252797554213937152,
    "created_at" : "2012-10-01 15:50:08 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 252797733574963200,
  "created_at" : "2012-10-01 15:50:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mittens",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252792600132734976",
  "text" : "RT @ZeitgeistGhost: NEVER FORGET:  #Mittens ran the LEVERAGED BUYOUT\/HOSTILE TAKEOVER part of Bain.  He harvested retirement funds, jobs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mittens",
        "indices" : [ 15, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252790591145013249",
    "text" : "NEVER FORGET:  #Mittens ran the LEVERAGED BUYOUT\/HOSTILE TAKEOVER part of Bain.  He harvested retirement funds, jobs, plants... for profit",
    "id" : 252790591145013249,
    "created_at" : "2012-10-01 15:22:28 +0000",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 252792600132734976,
  "created_at" : "2012-10-01 15:30:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252781067315052545",
  "text" : "@Skeptical_Lady totally agree which is why I dont donate. tho many look at me crosseyed if I say so...",
  "id" : 252781067315052545,
  "created_at" : "2012-10-01 14:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252779352318689281",
  "text" : "RT @BrianMerritt: Forgive us our debts as we forgive our debtors.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252778326077349888",
    "text" : "Forgive us our debts as we forgive our debtors.",
    "id" : 252778326077349888,
    "created_at" : "2012-10-01 14:33:43 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 252779352318689281,
  "created_at" : "2012-10-01 14:37:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "indices" : [ 3, 19 ],
      "id_str" : "140060120",
      "id" : 140060120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252772000592973825",
  "text" : "RT @davidpakmanshow: Great interview with Iraq War vet Paul Chappell talking about how ineffective war is at bringing peace http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/L2qB8h0G",
        "expanded_url" : "http:\/\/ow.ly\/e44qS",
        "display_url" : "ow.ly\/e44qS"
      } ]
    },
    "geo" : { },
    "id_str" : "252770135771860992",
    "text" : "Great interview with Iraq War vet Paul Chappell talking about how ineffective war is at bringing peace http:\/\/t.co\/L2qB8h0G",
    "id" : 252770135771860992,
    "created_at" : "2012-10-01 14:01:11 +0000",
    "user" : {
      "name" : "David Pakman Show",
      "screen_name" : "davidpakmanshow",
      "protected" : false,
      "id_str" : "140060120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1844159071\/tdps512-black_normal.png",
      "id" : 140060120,
      "verified" : false
    }
  },
  "id" : 252772000592973825,
  "created_at" : "2012-10-01 14:08:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hail-Track",
      "screen_name" : "HailTrac",
      "indices" : [ 3, 12 ],
      "id_str" : "460645635",
      "id" : 460645635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252762169706430465",
  "text" : "RT @HailTrac: Hail Storm, Rhinebeck, NY: This video was shot in Rhinebeck New York at the Rhinebeck Crafts Fair on Sunday, Sep... http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/obJl8O40",
        "expanded_url" : "http:\/\/bit.ly\/V5Mqu9",
        "display_url" : "bit.ly\/V5Mqu9"
      } ]
    },
    "geo" : { },
    "id_str" : "252754431634976768",
    "text" : "Hail Storm, Rhinebeck, NY: This video was shot in Rhinebeck New York at the Rhinebeck Crafts Fair on Sunday, Sep... http:\/\/t.co\/obJl8O40",
    "id" : 252754431634976768,
    "created_at" : "2012-10-01 12:58:47 +0000",
    "user" : {
      "name" : "Hail-Track",
      "screen_name" : "HailTrac",
      "protected" : false,
      "id_str" : "460645635",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2466341018\/2l3x292g2m1oj1xau514_normal.png",
      "id" : 460645635,
      "verified" : false
    }
  },
  "id" : 252762169706430465,
  "created_at" : "2012-10-01 13:29:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252755642379538432",
  "geo" : { },
  "id_str" : "252758600643145728",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind that was a good line..lol. i think i'll stop my memory there..",
  "id" : 252758600643145728,
  "in_reply_to_status_id" : 252755642379538432,
  "created_at" : "2012-10-01 13:15:21 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252755106699821057",
  "text" : "im very blessed to have married a good man. when we're dead, he'll live in a mansion while im in a box..lol",
  "id" : 252755106699821057,
  "created_at" : "2012-10-01 13:01:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "indices" : [ 3, 12 ],
      "id_str" : "184401626",
      "id" : 184401626
    }, {
      "name" : "Linda Joy",
      "screen_name" : "LindaJoy",
      "indices" : [ 17, 26 ],
      "id_str" : "90412353",
      "id" : 90412353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soul",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "love",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252754452317089792",
  "text" : "RT @AniKnits: RT @LindaJoy \"If you meet someone whose #soul is not aligned with yours, send them #love and move along.\" Wayne Dyer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Linda Joy",
        "screen_name" : "LindaJoy",
        "indices" : [ 3, 12 ],
        "id_str" : "90412353",
        "id" : 90412353
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "soul",
        "indices" : [ 40, 45 ]
      }, {
        "text" : "love",
        "indices" : [ 83, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252753930767974400",
    "text" : "RT @LindaJoy \"If you meet someone whose #soul is not aligned with yours, send them #love and move along.\" Wayne Dyer",
    "id" : 252753930767974400,
    "created_at" : "2012-10-01 12:56:47 +0000",
    "user" : {
      "name" : "aniknits",
      "screen_name" : "AniKnits",
      "protected" : true,
      "id_str" : "184401626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788592798924673024\/e8fBbmhW_normal.jpg",
      "id" : 184401626,
      "verified" : false
    }
  },
  "id" : 252754452317089792,
  "created_at" : "2012-10-01 12:58:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252735636585472000",
  "geo" : { },
  "id_str" : "252742481790251008",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time omg.. i never used to.. but apparently my mother has taken over..lol.. ive got it scheduled!",
  "id" : 252742481790251008,
  "in_reply_to_status_id" : 252735636585472000,
  "created_at" : "2012-10-01 12:11:18 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252741787611975681",
  "text" : "RT @bend_time: beautiful autumn day. leaves becoming brilliant, sun rising, will warm us to 70 degrees. not a bad planet at all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252737565826895872",
    "text" : "beautiful autumn day. leaves becoming brilliant, sun rising, will warm us to 70 degrees. not a bad planet at all.",
    "id" : 252737565826895872,
    "created_at" : "2012-10-01 11:51:45 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 252741787611975681,
  "created_at" : "2012-10-01 12:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]